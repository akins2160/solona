# Deduplication Guidelines

The selected Sherlock [judging guidelines](judging-guidelines.md#xii-duplication-guidelines) govern duplication. This document is a source-referenced application aid and does not replace or override them.

## Merge Requirements

Evaluate a **potential duplicate** against a **target issue**. The potential duplicate is merged only when it does all three:

1. Identifies the root cause.
2. Identifies at least a Low impact under the complete [severity set](severity-set.json).
3. Identifies a valid attack path or vulnerability path.

If any requirement is absent, do not merge it with that target; it may still be judged independently, duplicated with another issue, dismissed, or assigned another severity. When reports are duplicates, all duplicates receive the highest severity identified among them.

Source: [judging-guidelines.md, §XII, lines 170–180](judging-guidelines.md#xii-duplication-guidelines).

## Root-Cause Grouping

Issues in different locations or contracts may share a root cause when they contain the same logic mistake, the same conceptual mistake, or fall within the listed categories of slippage protection, reentrancy, access control, or front-running/sandwich behavior. They may remain separate when the underlying implementation, impact, or fix differs.

For reentrancy, different scenarios of the same listed reentrancy type within the codebase share a root cause. For front-running, sandwich, and slippage-protection issues, group reports whose fix is slippage protection or a commit-reveal mechanism as described in the source.

Source: [judging-guidelines.md, §XII, lines 182–213](judging-guidelines.md#xii-duplication-guidelines).

Prior-disclosure matching and report-to-report duplication are separate assessments. Do not infer an additional rule for duplicate-of-known findings; apply the [prior-disclosure sources](known-issues.md) for known status and the selected Sherlock rules above for merging reports.

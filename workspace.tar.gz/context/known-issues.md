# Prior Disclosures

This is a locator index. Use the linked supplied sources for exact preconditions, affected code, impact, recommendations, conditions, and exceptions.

## Certora Review

[Protocol documentation §5](protocol_docs.md#5-previous-audits) states that every issue in the September 2026 Certora report is treated as known, that acknowledged-but-unfixed issues are not valid as new findings, and that no finding was disputed. The report audited commit `95760c4dc16f52031d9d6971be42a1d4f2e3505b`; the current engagement is pinned to `2fbe82b37c06282d86992a4ce17bc4ffa701f845` by [scope.json](scope.json).

Status below reproduces the later [customer triage](CERTORA-TRIAGE-2026-09-21.md). It is disclosure status, not an independent verification of the pinned code.

| ID | Report title | Disclosed status | Source location |
| --- | --- | --- | --- |
| M-01 | Performance fee has no high-water mark, so the same interest is charged again after a drawdown | Fixed here | Report lines 614–729; triage line 3 |
| M-02 | Klend oracle reconfiguration can prevent MetaVault from unwinding obligation positions | Acknowledged | Report lines 730–810; triage line 27 |
| M-03 | Mutable ownership of thawed share accounts bypasses permissioned-vault gating | Partially fixed here | Report lines 811–845; triage line 4 |
| M-04 | Rebalance swaps have no aggregate loss cap across a rebalance episode - only a per-swap slippage cap | Fixed here | Report lines 846–894; triage line 5 |
| M-05 | Shares are priced against pre-fee AUM, so large deposits recapture most of their deposit fee | Fixed here | Report lines 895–959; triage line 6 |
| L-01 | CPI guard prevents administration through on-chain multisigs | Fixed here | Report lines 960–1024; triage line 7 |
| L-02 | Cumulative earned interest excludes AUM gained during value-moving operations | Fixed here | Report lines 1025–1084; triage line 8 |
| L-03 | Updating a rolling-cap interval can revive an already expired window | Fixed here | Report lines 1085–1121; triage line 9 |
| L-04 | Buy and withdraw can revive a completed rebalance at a mature auction price | Fixed here | Report lines 1122–1171; triage line 10 |
| L-05 | Pre-funding the deterministic shares-mint PDA can block a specific `init_vault` tx | Fixed here | Report lines 1172–1207; triage line 11 |
| L-06 | All-available obligation operations ignore the MetaVault LTV ceiling | Acknowledged | Report lines 1208–1251; triage line 28 |
| L-07 | `rebase_perf_fee_checkpoint` reads `prev_aum` as if it were current, so a config update while net AUM is negative lowers the performance-fee checkpoint and makes the whole recovery chargeable | Fixed here | Report lines 1252–1286; triage line 12 |
| L-08 | No path to harvest farm rewards accrued by vault obligations | Acknowledged | Report lines 1287–1349; triage line 29 |
| L-09 | External share burns are never reconciled, permanently stranding a proportion of the vault | Acknowledged | Report lines 1350–1385; triage line 30 |
| L-10 | Shares ACL deletion has no corresponding re-enable path, permanently disabling permissioning | Acknowledged | Report lines 1386–1419; triage line 31 |
| L-11 | Mid-window depositors are charged performance fees on appreciation their capital never earned | Acknowledged | Report lines 1420–1452; triage line 32 |
| L-12 | Mid-window management-fee minting silently shrinks the performance fee collected at the next | Fixed here | Report lines 1453–1514; triage line 13 |
| I-01 | Token account fields named `ata` are not constrained to be associated token accounts | Acknowledged | Report lines 1515–1589; triage line 33 |
| I-02 | Rebalance target recalculation in obligation operations is unreachable | Fixed before review ended by `99f0648` | Report lines 1590–1658; triage line 21 |
| I-03 | Obligation AUM assumes every lending market uses the same quote currency | Fixed before review ended by `99f0648` | Report lines 1659–1755; triage line 22 |
| I-04 | Dead `xmsg!`/`dbg_msg!` logging macros are unused and unreachable | Fixed here | Report lines 1756–1791; triage line 14 |
| I-05 | Asymmetric zero-amount CPI guard between the two token-transfer helpers | Fixed here | Report lines 1792–1825; triage line 15 |
| I-06 | Withdraw lacks the same frozen-shares-account UX check as deposit | Acknowledged | Report lines 1826–1859; triage line 34 |
| I-07 | Repay reverts on reserves that charge an early-repay penalty | Acknowledged | Report lines 1860–1894; triage line 35 |
| I-08 | Permissionless thaw, enabled by default at vault creation, lets a frozen holder immediately undo the emergency council's freeze | Acknowledged | Report lines 1895–1929; triage line 36 |
| I-09 | Missing signer requirement on `vault_state` allows front-running of `init_vault` | Acknowledged | Report lines 1930–1962; triage line 37 |
| I-10 | `init_obligation` lacks a rebalance-state guard, breaking in-flight solver transactions | Fixed here | Report lines 1963–1995; triage line 16 |
| I-11 | Withdraw-and-reenter timing around the fee cooldown lets holders dodge the performance fee entirely | Acknowledged | Report lines 1996–2029; triage line 38 |
| I-12 | Vault-side and reserve-side oracle configs can diverge, letting AUM blend two inconsistent price bases | Fixed before review ended by `99f0648` | Report lines 2030–2064; triage line 23 |
| I-13 | A normative `CONTEXT.md` spec is cited throughout the code but absent from the repository | Fixed here | Report lines 2065–2099; triage line 17 |

Complete sources: [original PDF](<Certora - Kamino - Metavault - Draft Report.pdf>), [searchable supplied conversion](<Certora - Kamino - Metavault - Draft Report.md>), and [customer triage](CERTORA-TRIAGE-2026-09-21.md).

## Intended And Accepted Behavior

[Protocol documentation §6.1](protocol_docs.md#61-design-decisions-by-component) declares the following behaviors to be intended behavior that can look like a bug; §6 states that items in §6.1 are not valid findings. Search the exact bold title in the source for the full qualification.

| Component | Disclosed behavior | Source lines |
| --- | --- | --- |
| Vault core | Flow fees are donated to the vault, not collected. | 810–812 |
| Vault core | Depositors are priced against post-fee AUM. | 814–819 |
| Vault core | Withdrawers burn shares against the gross amount. | 821–824 |
| Vault core | The two zero conventions are inverted. | 826–828 |
| Vault core | Deposits and withdrawals halt at non-positive net AUM. | 830–834 |
| Vault core | Direct transfers to the vault are not counted. | 836–840 |
| Vault core | The seed deposit is valued at a mocked $1 per whole token. | 842–846 |
| Fees | Performance is charged on appreciation from any source. | 850–853 |
| Fees | Performance-fee boundaries have timing effects, in both directions. | 855–863 |
| Fees | The checkpoint is a high-water mark and never ratchets down on a drawdown. | 865–868 |
| Fees | Changing the performance fee rate forgives in-window gain. | 870–874 |
| Fees | Waiving fees requires blocked deposits, and a sandwich residual remains. | 876–879 |
| Fees | A long gap between fee charges is capped. | 881–884 |
| Fees | Fee accrual is only as current as the last touch. | 886–888 |
| AUM/oracles | Vault liveness is coupled to its weakest input. | 892–897 |
| AUM/oracles | klend's cached reserve price is never an AUM input. | 899–902 |
| Rebalancing | A fill's `amount_in` is clamped down to the remaining deficit. | 906–909 |
| Rebalancing | `requested_out_amount` is an exact payout, not a minimum. | 911–913 |
| Rebalancing | Restarting a rebalance resets its loss accumulator. | 915–918 |
| Rebalancing | Anyone can end a rebalance early by making it unfillable. | 920–926 |
| Rebalancing | Obligation operations wait for a rebalance. | 928–932 |
| Orders | A withdraw order releases a slice of every free token, wanted or not. | 936–940 |
| Orders | A deposit order settles for whatever the target bounds admit, and refunds the rest. | 942–945 |
| Orders | Order settles are permissionless, and deposit settles re-price at settle time. | 947–950 |
| Orders | Deposit orders follow the vault's live weights and dutch scales. | 952–955 |
| Orders | `block_deposits` and `block_withdraws` gate only the half of an order that mints or burns. | 957–963 |
| Klend allocation | MetaVault models klend's maths and reverts on a token-movement mismatch. | 967–971 |
| Klend allocation | Repay and deposit-collateral are never blocked by the LTV ceiling. | 973–976 |
| Klend allocation | Borrow-all and full repay lose sub-lamport amounts. | 978–981 |
| Controls | Emergency mode does not stop allocation or administration. | 985–989 |
| Controls | The emergency council can block exits, and cannot clear its own flags. | 991–995 |
| Controls | Removing permissioning leaves frozen accounts frozen. | 997–1000 |
| Controls | `vault_farm` is configurable but inert. | 1002–1005 |
| Controls | The CPI guard covers user flow, not administration. | 1007–1012 |

The same section declares findings premised on a compromised vault admin out of scope. Its listed vault-admin-only vectors are:

- adding a token with an arbitrary oracle mapping;
- opening an obligation in an arbitrary Klend lending market;
- setting an admin-controlled `swap_authority` and filling auctions within admin-set bounds;
- setting management, performance, and flow fees to their caps; and
- disabling the listed deviation, LTV, loss, cap, and cooldown bounds.

The exact limits, exceptions, and operational mitigation are at [protocol_docs.md lines 1014–1030](protocol_docs.md#trust-model-consequences-vault-admin-is-trusted--see-41).

## Explicit Known Issues

[Protocol documentation §6.2](protocol_docs.md#62-known-issues) declares both items below known issues in the pinned revision; §6 states that they are not valid findings.

| Known issue | Conditions retained in source | Source lines |
| --- | --- | --- |
| Flow is not blocked while an obligation can be liquidated. | Includes pending liquidation bonus or `socialize_loss`, price moves through the LTV threshold, and non-LTV liquidation triggers; the planned flow-blocking fix does not yet cover every trigger. | 1034–1042 |
| Repaying fixed-term debt before its term ends reverts. | Klend's early-repay penalty is not modeled, causing `BalanceAfterObligationCpiMismatch` until the term ends. | 1044–1047 |

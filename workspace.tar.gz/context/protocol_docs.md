# Kamino MetaVault — Protocol Documentation

**Scope:** `programs/metavault/` (the on-chain program only).
**Commit:** `2fbe82b37c06282d86992a4ce17bc4ffa701f845`, branch `jakub/be-2507-harden-metavault-account-validation-before-bug-bounty`.
**Program id:** `MeVaiz8VbU5n33rFnRsopxBAtiaxQeZf9Qct1kskFZk` (mainnet) / `SKMjNveD9w7mCVN2m3bQu99shKu2vZRD6Q37wdqGxFg` (staging, `--features staging`).
**Out of scope:** the off-chain bots (keeper, cranker, solver; on a separate branch) and
`libs/client/` (Rust CLI/SDK). Their behaviour is described in §4.3 as operational assumptions, not
as reviewable code.

---

## 1. Protocol Overview

### 1.1 Summary

MetaVault is a multi-asset Solana vault. Users deposit any one of the vault's enabled tokens and
receive a fungible Token-2022 share; the share's price is net AUM divided by supply, where net AUM
is the Scope-priced value of the tokens the vault holds plus the net value of the positions it holds
in Kamino Lending (klend) obligations. Two kinds of yield reach holders: interest earned on klend
deposits (optionally levered, by borrowing against that collateral and re-depositing), and deposit/
withdrawal fees, which stay in the vault and raise the share price for everyone else. The protocol
takes a management fee (per-annum on AUM) and a performance fee (on per-share appreciation above a
high-water mark), both charged as new shares accrued to `pending_fees` (and later minted to the
vault admin) rather than by moving tokens.

The vault holds its tokens at configured **target weights**. Moving the real balances toward those
weights is a **rebalance**: the allocation authority opens a time-boxed window, and third-party
fillers trade against the vault along a per-token dutch-auction price curve. The same auction
machinery also serves user flow at size: a depositor can lock a basket of tokens in a **deposit
order** and let fillers convert it into the vault's weights before it is absorbed for shares, and a
withdrawer can take a pro-rata slice of every liquid vault token as a **withdraw order** and have it
auctioned into the token mix they choose.

The reference model is **kvault** (`Kamino-Finance/kvault`), Kamino's single-token lending vault.
MetaVault keeps kvault's share-issuance rounding (§2.1) and its `VaultConfigField` update pattern.
Everything else is new, fee accounting included (§2.2).

### 1.2 Key Design Changes / Novel Mechanisms

Everything in this list is new relative to kvault.

- **Multi-token baskets with target weights.** MetaVault holds up to 10 tokens
  (`MAX_TOKENS_PER_VAULT`) at target weights, where kvault held one token across many reserves.
  Deposits and withdrawals are clamped by a per-token deviation band (§2.1).
- **Dutch-auction rebalancing with third-party fillers.** There is no DEX integration and no
  router. `rebalance_swap` is an atomic two-leg transfer priced off Scope with a time-decaying
  scale; the counterparty is whoever sends the instruction.
- **Direct klend obligation allocation, including leverage.** The vault owns up to 3 klend
  obligations (`MAX_OBLIGATIONS_PER_VAULT`) and drives them by CPI. Token-moving operations predict
  their effect in-program and verify it against the observed balance deltas (§2.6).
- **Price-basis coherence gate.** All AUM, obligation legs included, is valued at the vault's own
  Scope prices. A per-token `max_price_divergence_bps` bounds how far klend's cached price may drift
  from Scope, checked on every AUM load (§2.3).
- **Performance-fee high-water mark in share-price terms.** The checkpoint is a per-share price, not
  an AUM figure, so capital flows do not move it (§2.2).
- **Deposit and withdraw orders.** User-owned baskets held inside the vault's own token accounts,
  tracked by `VaultToken::locked_total`, auctioned under limits the owner chooses, and settled
  separately from the fill.
- **Permissioned shares via Token-2022 + Token ACL (sRFC-37).** A vault may be created with
  frozen-by-default share accounts that holders thaw through a gating program (§2.7).
- **krfq venue gate.** A vault may require each `rebalance_swap` to be co-signed by the krfq auction
  server, bound to one basket and mint pair by a PDA fill marker (§2.4).
- **Rate limits on allocation and flow.** A start-to-start rebalance cooldown, a per-obligation LTV
  ceiling, an AUM cap checked on deposits, and tumbling-window USD caps on deposit and withdraw
  flow.

### 1.3 Actors

- **Depositor / withdrawer** — holds shares. Goal: AUM-proportional exposure to the basket plus
  klend yield. Interacts via `buy`/`sell`, or via orders at size.
- **Vault admin** (`vault_admin_authority`) — creates and configures the vault, sets weights, fees,
  oracle mappings, caps and limits, and receives the fee shares. Fully trusted; see §4.1.
- **Allocation delegate** (`allocation_admin_authority`) — optional key the vault admin may appoint
  to run rebalances, set `TokenWeights`, and run klend obligation operations (except
  `init_obligation`) without holding admin rights.
- **Filler / solver** — trades against a live auction (the vault's own basket or an order's) via
  `rebalance_swap`. Permissionless unless the vault sets a `swap_authority` and/or the krfq gate.
- **krfq auction server** — holds `GlobalConfig::krfq_swap_authority`; co-signs and submits fills on
  gated vaults.
- **Cranker** — permissionless liveness actor: calls `refresh_vault` and settles orders whose
  auctions are over. Holds nothing, is owed nothing.
- **Emergency council / unfreeze authority** — optional vault-level keys that can respectively raise
  and lower the emergency flags, and freeze/thaw individual share accounts.
- **Global admin** (`GlobalConfig::global_admin`) — sets protocol-wide minimum flow fees and the
  krfq server key.

### 1.4 Core User Flows

All flows are synchronous Solana transactions unless stated. Every AUM-touching instruction takes
the price and obligation accounts described in §2.3.

- **Deposit** — `buy(max_amount, min_shares_out)`. `handler_deposit` → `charge_fees` →
  target-bound clamp → fee → `get_shares_to_mint` → SPL transfer in → mint shares. Synchronous.
- **Withdraw** — `sell(shares_amount, min_tokens_out)`. `handler_withdraw` → `charge_fees` →
  target-bound clamp → fee → burn shares → SPL transfer out. Pays in exactly one token, limited to
  that token's free balance. Synchronous.
- **Deposit at size** — `open_deposit_order(id, amounts, duration, min_shares_out, …)` locks a
  basket, fillers call `rebalance_swap` against it, then anyone calls `settle_deposit_order` once
  the auction is over. The owner may `cancel_deposit_order` at any time (except under
  `emergency_mode`). Asynchronous.
- **Withdraw at size** — `open_withdraw_order(id, shares_amount, weights, duration, min_tokens_out,
  …)` burns shares immediately and releases their claim on net AUM (obligations included) as a
  pro-rata slice of every free token balance; fillers auction it into the owner's chosen weights,
  `settle_withdraw_order` pays out. Asynchronous.
- **Rebalance** — `start_rebalance(duration)` → N × `rebalance_swap(amount_in,
  requested_out_amount)` → `stop_rebalance`, or the window elapses or no fill can make progress,
  and the next AUM-touching instruction closes it.
- **Allocate to klend** — `init_obligation` (admin only) → `deposit_obligation_collateral` →
  (`borrow_obligation_liquidity` → rebalance into the collateral token →
  `deposit_obligation_collateral`)* to lever up; reverse to unwind.
- **Collect fees** — `withdraw_pending_fees` mints the accrued whole fee shares to the admin. The
  admin may instead `give_up_pending_fees` to waive them back to holders (only while deposits are
  blocked).
- **Views** — `aum` and `exchange_rate` return a value and mutate nothing. `refresh_vault` is
  *not* a view: it accrues fees and closes a finished rebalance. It takes **no signer at all** and
  is callable by anyone (top-level only: it rejects CPI).

### 1.5 Solvency Invariants

These hold on every path. Values are at the vault's validated Scope prices and its net AUM at the
moment of the operation; `S` is `shares_issued`.

1. **No user gets more shares than their deposit is worth.** `buy` and `settle_deposit_order` mint
   at most `S × value_in / pricing_aum`, where `value_in` is what the vault receives net of the
   deposit fee, and `pricing_aum` is net AUM with that fee already in it.
2. **No user burns fewer shares than their withdrawal is worth.** `sell` and `open_withdraw_order`
   burn at least `S × value_out / net_aum`, where `value_out` is the gross value released, the
   withdrawal fee included.
3. **Every rounding step favours the vault.** Where one side of an exchange is derived from the
   other, the derived side rounds against the user: shares minted for tokens round down, tokens
   taken for shares round up, tokens paid out for shares round down, shares burned for tokens round
   up, and flow fees round up. Net AUM rounds up as a deposit's denominator and down for a
   withdrawal. Fills value the input floor and price the output ceil; obligation legs value
   collateral floor and debt ceil.
4. **No user can steer the inputs to 1–3.** Token balances are tracked internally, so a direct
   transfer moves neither `token_available` nor AUM (§6.1), and the 1000 seed shares, held by no
   one, keep supply from returning to zero (§2.1). Each price must come from the token's configured
   Scope feed and pass its age, TWAP-age and TWAP-divergence checks; obligation legs are valued
   from refreshed klend quantities at that price, never at klend's cached price (§2.3). Any way to
   make MetaVault value a deposit, a withdrawal or the vault on other inputs breaks this invariant:
   a substituted, stale or unrefreshed account, another token's feed, an uncounted transfer, or an
   ordering of instructions within or across transactions.
5. **A fill cannot take more than its auction allows.** `rebalance_swap` pays out exactly its ask,
   and only if the ask is within the curve output for the clamped input, the basket's excess of
   `token_out`, and the per-fill and per-auction loss limits (§2.4).
6. **The vault's token accounts cover what it owes.** For every vault token, the token account
   balance is at least `token_available + locked_total`.

---

## 2. Detailed Breakdown by Component

Ordered most-central (funds and accounting) to most-peripheral. Intended behaviour that can look
like a bug is listed once, per component, in §6.1.

### 2.1 Vault Core & Share Accounting

**Purpose.** Owns `MetavaultState` and the per-token `VaultToken` records: what the vault holds
(`token_available`), what live orders lock in the same token accounts (`locked_total`, never part
of `token_available`), how many shares exist (`shares_issued`), and the config that governs flow.
It mints and burns shares against deposits and withdrawals at the current share price, enforces the
per-token target-weight bounds, the AUM cap (checked on deposits only) and the tumbling-window flow
caps, and charges the flow fees. It is *not* responsible for valuing the vault (§2.3) or for
deciding allocation (§2.4, §2.6).

**Lineage.** The share-issuance shape is kvault's (floor shares, then recompute the token amount
from the shares with ceiling). New: multi-token accounting, `locked_total`, target-weight bounds,
the AUM and rolling caps.

**Mechanics & math.**

- A vault is seeded at `init_vault` with `INITIAL_DEPOSIT_SIZE = 1000` lamports of its first token
  for 1000 shares (1:1). The seed shares are recorded in `shares_issued` but never minted to anyone,
  so they act as dead shares. `init_vault` takes no oracle account, so the seed is valued at a
  mocked $1 per whole token; that value only seeds the performance checkpoint.
- Deposit: `shares = floor(S · deposit_aum / pricing_aum)`, then the token amount is recomputed from
  those shares with ceiling and clamped to `min(max_amount, target bound)`. `pricing_aum = net_aum +
  value(deposit_fee)`, so the fee lands entirely on existing holders (§6.1).
- Withdraw: the user's gross claim is `floor(net_aum · shares/S)`, converted to tokens, clamped to
  `token_available` and to the withdraw target bound. The fee is taken from the gross; shares are
  burned against the **gross** AUM with ceiling, capped at the shares requested.
- Target bounds: a deposit may not push the deposited token's post-deposit weight above `target +
  max_deviation_bps`; a withdraw may not push the withdrawn token's weight below `target −
  max_deviation_bps`. Only the transacted token is bounded, and weights are measured against free
  AUM (`token_available` only; obligations and order-locked tokens excluded). `open_withdraw_order`
  applies no bound. The deposit ceiling solves `excess/(1−upper)`; because that amplification can
  exceed `u64` for a cheap high-decimal token, it saturates to `TokenAmount::MAX` (a vacuous bound)
  rather than panicking.
- Rounding on user flows is vault-favourable: floor on anything credited to the user, ceil on
  anything charged to them, with the free-AUM rounding direction chosen per call site to match.
  The exceptions are dust-level, where a cap binds (`max_amount`, requested shares). Fee accrual
  rounds in the fee recipient's favour.

**Expected inputs & caller responsibilities.**

- Callers MUST set `min_shares_out` / `min_tokens_out` from an independently obtained price. Zero is
  a caller mistake, not a protocol vulnerability.
- Callers MUST pass the price and obligation accounts described in §2.3. A missing or stale account
  fails closed.
- The vault pays withdrawals in one token out of free balance only. A withdrawer wanting a different
  mix, or more than that token's free balance, is expected to use a withdraw order.

**Invariants.** §1.5 (1)–(4) and (6) apply to `buy` and `sell`; the rounding bullet above is (3)
in detail.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- `locked_total` bookkeeping across the order lifecycle (open → fill → settle/cancel) — the newest
  accounting in the program, and the one place where two independent baskets write the same token
  account.
- The target-bound solve at near-unity `target + deviation`, and the saturation fallback on the
  deposit bound: a bound that silently becomes vacuous is indistinguishable from one that was never
  set.
- Share rounding at very small supply or very large per-share value, especially the deposit
  round-trip (floor shares → ceil tokens → clamp to `max_amount`).

### 2.2 Fee Accrual (Management & Performance)

**Purpose.** Accrues management and performance fees as newly minted shares credited to
`pending_fees`, maintains the performance **checkpoint**, and provides the waiver path.
`charge_fees` runs before any share or AUM change in: `buy`, `sell`, `refresh_vault`,
`start_rebalance`, `rebalance_swap` (vault fills only), `settle_deposit_order`,
`open_withdraw_order`, the four token-moving obligation operations, `withdraw_pending_fees`,
`give_up_pending_fees`, and `update_vault_config` for the two fee-rate fields. It does **not** run
in `settle_withdraw_order`, `open_deposit_order`, `cancel_deposit_order`, order fills,
`stop_rebalance`, `init_obligation`, `request_elevation_group`, or other config updates (including
`VaultTokenScope`).

**Lineage.** New. kvault books fees as a token amount and pays them out in tokens; MetaVault charges
them by minting shares, and measures performance against a per-share checkpoint, not an AUM delta.

**Mechanics & math.**

- Shares to mint for a fee of effective rate `F` on supply `S` is `NS = S·F/(1−F)` — i.e. `F` is the
  post-mint ownership fraction, not a fraction of the pre-mint supply. `F` is clamped at
  `MAX_CHARGED_RATE_FOR_VAULT_FEE = 50%` separately for each fee, per call, before `F/(1−F)` is
  taken; `NS` rounds up.
- Management: `F = management_fee_bps × Δt / YEAR`, `YEAR = 31_556_925 s`. Charged on every
  `charge_fees`, no cooldown.
- Performance: charged only when `now − last_perf_fee_charge >= PERF_FEE_COOLDOWN_SECONDS` (24 h).
  `F = performance_fee_bps × perf_earned_interest / new_aum`, where `perf_earned_interest =
  max(0, new_aum − checkpoint_price · S)` and the base supply includes the management charge just
  computed.
- The checkpoint is written in these places:
  1. **New high-water mark** at a cooldown boundary (`new_aum >= checkpoint_value`): re-anchored to
     `new_aum / shares_after_mint`, i.e. the *post*-mint price, so the dilution just charged is not
     read as next window's loss.
  2. **Supply change with no boundary gain** — a drawdown observed at a boundary, or a mid-window
     management mint: the checkpoint *value* is carried across the supply change
     (`SharePrice::of(old_value, new_supply, Ceil)`), so the aggregate is conserved. This makes it
     a high-water mark, and stops free-minted fee shares from inflating the fee base (Certora M-01,
     L-12).
  3. **Valuation-basis change** — a Scope feed swap re-anchors it in either direction (without
     charging fees first), because a checkpoint left above an unreachable new basis would never be
     cleared again.
  4. **Fee waiver** — `give_up_pending_fees` burns fee shares, which raises the share price without
     adding capital, so the checkpoint is scaled by the same conservation rule; otherwise the
     waiver would be re-charged as performance at the next boundary.
  5. **Performance-rate update** — raised (never lowered) to the current price (§6.1).
  6. **Seeding** — at `init_vault`, at the mocked $1 seed price (§2.1), together with both fee
     timestamps; both fee rates must be 0 at init. Lazily on the first `charge_fees` if it is zero.
     The `last_fee_charge_timestamp == 0` branch (seed only, no charge) is a fallback for state that
     was never seeded.
- A negative net AUM short-circuits the whole function: no accrual, the checkpoint is preserved at
  its pre-loss value, and only the two timestamps advance.
- `withdraw_pending_fees` accrues first, then mints every whole pending fee share to the admin; the
  fractional remainder stays in `pending_fees`.
- `prev_aum` is kept for observability only; no fee or share computation reads it.

**Expected inputs & caller responsibilities.** `charge_fees` is internal; it is reached only through
instructions that have already validated their price and obligation accounts.

**Invariants.** Fee accrual is the stated exception to §1.5 (3): it rounds in the fee recipient's
favour.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- The checkpoint rebasing arithmetic across combinations of mint and burn in one transaction — a
  settle that mints shares inside a `charge_fees`-bracketed flow, or a fee charge in the same
  instruction as a give-up.
- Rounding direction on `perf_checkpoint_value` (floor) against `new_aum` (ceil): both favour the
  fee recipient, and they sit directly on the charge/no-charge boundary.

### 2.3 AUM Valuation & Oracles

**Purpose.** Produces the single number everything else is denominated in: net AUM = Scope-priced
value of free balances + net value of every obligation. Loads and validates one Scope price per
enabled token, enforcing price age, TWAP age and TWAP divergence (there is no confidence-interval
check). On every AUM load it also enforces that klend's cached price for each active obligation leg
has not drifted too far from the vault's own.

**Lineage.** Scope loading and `get_validated_price_with_args` are klend's, used unchanged. The
price-basis gate is new.

**Mechanics & math.**

- `VaultScopePrices::load_and_validate_from_remaining_accounts` walks the enabled tokens in dense
  order, pairs each with the next `remaining_account`, and requires: the account is the token's
  configured `scope_configuration.price_feed`, it is owned by the Scope program, the price passes
  `ALL_METAVAULT_PRICE_CHECKS` (`PRICE_LOADED | PRICE_AGE_CHECKED | TWAP_AGE_CHECKED |
  TWAP_CHECKED`), and the price is non-zero. **All-or-nothing**: one bad feed fails the whole load.
- Per-token freshness config: `max_age_price_seconds`, `max_age_twap_seconds`,
  `max_twap_divergence_bps` (`0` disables TWAP checking for that token; defaults are 60 s / 60 s /
  100 bps).
- Obligation legs are valued by taking klend's *quantities* — ctoken amounts converted through the
  reserve's own collateral/liquidity exchange rate, and fractional debt — and pricing them at the
  **vault's** Scope price. klend's cached `reserve.liquidity.get_market_price()` is never multiplied
  into AUM.
- The price-basis gate (`ReservePriceMismatch`) computes `rel_diff(klend_cached_price,
  scope_price)` and requires it `<= max_price_divergence_bps`; `0` means an exact match is required
  (fail-closed). It runs inside the shared AUM loader for every active leg reserve, and again on the
  target reserve of deposit/withdraw collateral, borrow and repay. It does not run on
  `init_obligation` or `request_elevation_group`.
- Free-AUM rounding is chosen per call site (ceil where the figure is a denominator or a cap, floor
  where it is a user credit). Obligation AUM is always computed vault-favourably (collateral floor,
  debt ceil), even where the call site rounds free AUM up.

**Expected inputs & caller responsibilities.**

- Every AUM-touching instruction takes, in `remaining_accounts`: one Scope price account per enabled
  token in dense token order (all tokens, not just the one being moved), then every registered
  obligation (empty ones included), then the reserve of each active obligation leg. Order fills,
  `open_deposit_order` and `settle_withdraw_order` take Scope prices only.
- Every registered obligation and active leg reserve must be refreshed by klend
  (`refresh_obligation`, `refresh_reserve`) in the same slot, `buy` and `sell` included. The
  program checks `last_update.is_stale(slot, PriceStatusFlags::ALL_CHECKS)` and rejects with
  `ReserveStale` / `ObligationStale` rather than reading stale values.

**Invariants.** §1.5 (4) rests on this component: every AUM figure in (1)–(3) comes from the
validated loader described here.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- The price-basis gate on tokens where klend and Scope genuinely co-enable different feeds — the
  tolerance has to be wide enough to not brick the vault and tight enough to still bound the basis
  mismatch. The field defaults to `0` (exact match required).
- Exposure to a wrong Scope price. In klend a feed several percent off is absorbed by the LTV
  buffer; here every price feeds share pricing directly, so a mispriced token is extractable at
  once: deposit it while overpriced for extra shares, withdraw it while underpriced for extra
  tokens, or buy it below value from a rebalance or order auction. The rebalance loss limits are
  measured at the same Scope prices, so they do not catch a wrong one. On-chain, only the
  freshness and TWAP checks, flow fees, target-weight bounds and USD caps limit the exposure.

### 2.4 Rebalancing & the Dutch Auction

**Purpose.** Moves the vault's free balances toward its target weights by selling what it has too
much of and buying what it has too little of, through third-party fillers, inside a bounded time
window and under explicit loss limits. There is no DEX integration: a fill is a two-leg SPL
transfer, and the filler *is* the counterparty.

**Lineage.** Entirely new; kvault has no equivalent.

**Mechanics & math.**

- `start_rebalance(duration)` snapshots the window `[now, now+duration)`, the current
  `rebalance_limits`, and a loss ceiling of `max_loss_bps × basket value at start`. Duration must be
  within `[600 s, 604 800 s]`. It is refused if a rebalance is still fillable, if the weights sum to
  zero, or if no fill could make progress at current prices (`VaultAlreadyRebalanced`).
- **Targets are never stored.** Each token's target is recomputed on every read as its weight's
  share of the basket's *current* value at *current* prices.
- A token is in **deficit** if it is below target by more than
  `REBALANCE_SETTLED_TOLERANCE_LAMPORTS = 1000`, in **excess** if above by more than that, and
  otherwise **settled** — and a settled token is refused as either side of a fill. A zero target has
  no tolerance: any balance at all is excess.
- A fill names `token_in` (must be in deficit), `token_out` (must be in excess), `amount_in` and
  `requested_out_amount`. `amount_in` must be at least `MIN_REBALANCE_SWAP_AMOUNT_LAMPORTS = 1000`
  and is then **clamped down** to the remaining deficit; a static assertion pins
  `REBALANCE_SETTLED_TOLERANCE >= MIN_REBALANCE_SWAP_AMOUNT` so the clamp can never land under the
  dust floor.
- The **ask** (`requested_out_amount`) is paid out *exactly*. It must clear three independent
  ceilings: the dutch curve's output for the clamped input, the basket's excess of `token_out`, and
  the loss limits. Any surplus stays in the basket.
- The curve: `price_rate(t) = start·(1−t) + end·t` over the window, applied as a bps multiplier to
  the Scope price. Selling scales must not increase (`start >= end`) and buying scales must not
  decrease (`end >= start`), both within `[5000, 30000]` bps. Validation enforces only that range
  and direction, not that an auction opens on the vault's favourable side; the default is a flat
  1.0x. Buy-side price rounds floor and sell-side ceil, both basket-favourable.
- **Loss limits**, fixed at start and applied per fill in `RebalanceState::record_fill`:
  - per fill: `value_before − value_after <= max_fill_slippage_bps × value_in`;
  - per auction: cumulative loss `<= min(ceiling_at_start, max_loss_bps × (value_before + losses so
    far))`. Adding the prior losses back stops the losses from shrinking their own allowance; the
    `min` against `ceiling_at_start` stops an inflow from raising the ceiling mid-auction.
  `0 bps` means no loss at all is tolerated. `FULL_BPS` means no limit for `max_loss_bps`; for the
  per-fill limit it still caps a fill's loss at its input value.
- Counterparty gating composes two independent rules, both applied to every fill (vault and order
  baskets alike): `swap_authority` (unset = anyone) decides *who* may be the counterparty, and the
  krfq gate (`krfq_enabled`) decides *how* the fill reaches the chain. When krfq is on,
  `GlobalConfig::krfq_swap_authority` must co-sign and a PDA fill marker seeded on `["krfq_fill",
  basket, token_in_mint, token_out_mint]` must be passed, where `basket` is the vault or the order
  being filled. The marker does not bind amounts or the counterparty.

**Expected inputs & caller responsibilities.**

- Fillers are expected to quote the curve themselves before submitting; the program reverts rather
  than partially filling an over-ask (`SlippageExceeded`, `RequestedOutExceedsExcess`).
- The vault admin is expected to set `max_fill_slippage_bps` and `max_loss_bps` to real values.
  `FULL_BPS` on both is a legal configuration and is the operator's risk.
- The dutch scales are per *token*, not per pair, and apply to every basket in the vault, including
  users' orders.

**Invariants.** §1.5 (3) and (5) apply to every fill, on the vault's basket and on orders alike.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- Many small fills against the loss accounting: the per-fill limit is relative to *that fill's*
  input, so a sequence of individually-compliant fills is bounded only by the auction ceiling, and
  the ceiling's "add the losses back" term is the subtle part.
- The clamp-then-quote ordering: `amount_in` is clamped to the deficit *before* the curve prices it,
  so the filler's economics change between what they quoted and what executes.
- The fill-marker derivation, and the hard-coded account index `KRFQ_FILL_MARKER_ACCOUNT_INDEX = 14`
  that krfq reads positionally from the message. The program itself never reads these indices; a
  unit test pins them against the generated account metas.

### 2.5 Deposit & Withdraw Orders

**Purpose.** User-owned baskets, physically held in the vault's own token accounts but accounted
separately via `OrderBase::locked_amounts` and `VaultToken::locked_total`, auctioned by the same
`rebalance_swap` machinery under limits the owner picks, and settled in a separate instruction.
A **deposit order** is converted into the vault's weights then absorbed for shares; a **withdraw
order** is a pro-rata slice of every liquid vault token, released for already-burned shares, then
converted into weights the owner chose.

**Lineage.** Entirely new. This is the most recently written code in the program.

**Mechanics & math.**

- PDAs seeded `["deposit_order"|"withdraw_order", vault, owner, id]` with `id <
  MAX_ORDERS_PER_OWNER = 4`, so a client can enumerate an owner's orders by derivation.
- Auction duration is `[300 s, 86 400 s]`. Each order carries its own `RebalanceState` with its own
  loss limits, independent of the vault's.
- `open_deposit_order` locks the given per-token amounts (refusing tokens the vault has zeroed),
  requires the basket's value to clear `order_min_open_usd_sf`, and converts `min_shares_out` into a
  stored `max_share_price` ceiling checked at settle.
- `settle_deposit_order` absorbs **the largest part the vault's target-weight bounds admit**, which
  is a coupled solve: each token's admitted value depends on the total absorbed (because absorbing
  grows the vault the weights are measured against). `max_absorbable_aum` solves it exactly
  (piecewise-linear). It collects the breakpoints where a token starts to be admitted (its growing
  ceiling reaches its current holding) and where it runs out (holding plus locked). It then finds
  the last covered breakpoint and the next one, and interpolates linearly between them. Whatever is
  not absorbed is refunded.
- Settle uses the same pricing rule as a plain deposit (`pricing_aum = net_aum + fee_value`) and
  runs the deposit caps on the **gross** value while minting against the net. It differs in that it
  absorbs the full admitted amount and mints floored shares (the sub-share remainder stays in the
  vault), allows a leg that is all fee, skips `min_deposit_amount`, and checks `max_share_price`
  against the net value.
- `open_withdraw_order` burns the shares immediately and releases their claim on net AUM
  (obligations included) as a pro-rata slice of *every* free token balance, net of the withdrawal
  fee. Only the shares the release is worth are burned, which can be fewer than requested.
- Settle is open to anyone once the auction is over; the owner may settle a withdraw order (not a
  deposit order) early. A settle sent by anyone other than the owner must pay token payouts to the
  owner's **associated** token accounts (`PayoutNotToAssociatedAccount`); deposit-settle shares go
  to any shares account the owner owns.
- Five independent config flags gate the lifecycle: deposit creation / fill / settle, withdraw
  creation / fill. `block_deposits` and `block_withdraws` also apply (§6.1), and `emergency_mode`
  blocks all five order instructions.

**Expected inputs & caller responsibilities.**

- `amounts`, `weights` and `min_tokens_out` are one entry per *enabled* token in dense token order.
  A length mismatch is rejected (`TokenArrayLengthMismatch`), but the ordering is the caller's
  responsibility.
- Settling requires passing accounts covering every token the order actually holds
  (`OrderTokensNotCovered`), which is not the same set as the order's target weights.
- A fill names at most one order; passing both a deposit and a withdraw order is rejected
  (`InconsistentOrderAccounts`).

**Invariants.** §1.5 (1)–(4) apply to `settle_deposit_order` and `open_withdraw_order` as they do
to `buy` and `sell`, (5) to every order fill, and (6) to `locked_total` across the order lifecycle.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- The `max_absorbable_aum` breakpoint solve — an interpolation over a piecewise-linear coverage
  function, with saturating arithmetic throughout.
- `locked_total` versus `token_available` under concurrent activity: a vault rebalance and an order
  auction can be live simultaneously against the same token accounts.

### 2.6 klend Obligation Allocation

**Purpose.** Lets the vault put its idle tokens to work in Kamino Lending, optionally levered, and
brings the resulting position into AUM. Six instructions manage obligations by CPI into klend:
`init_obligation`, `deposit_obligation_collateral`, `withdraw_obligation_collateral`,
`borrow_obligation_liquidity`, `repay_obligation_liquidity` and `request_elevation_group`.
`init_vault` also CPIs klend `init_user_metadata`.

**Lineage.** New. kvault invested into klend *reserves* via `invest`; MetaVault owns full
obligations and can borrow against them.

**Mechanics & math.**

- Each of the four token-moving operations predicts its effect in-program (`compute_*_effects`,
  built mostly on the pinned klend crate's own functions), applies that prediction to internal
  accounting, performs the CPI, and then asserts the observed SPL token-balance deltas match the
  prediction (`BalanceAfterObligationCpiMismatch`). `init_obligation` and `request_elevation_group`
  have no prediction and no balance check.
- `compute_max_redeemable_ctoken_amount` for an all-available withdrawal replicates klend's sizing
  bit-exactly, including truncating the ratio to `Fraction` precision *before* multiplying — a
  full-precision ratio yields one more ctoken than klend will burn.
- **Obligation LTV ceiling** (`max_unhealthy_ltv_fraction_bps`, per obligation, `0` disables):
  predicted post-operation borrow-factor-adjusted debt must not exceed that fraction of the
  obligation's unhealthy (liquidation) borrow value. It gates `borrow`,
  `withdraw_obligation_collateral` and `request_elevation_group`, never repay or deposit-collateral.
- The vault never sets a referrer on its obligations; the predicted referrer fee must be zero
  (`UnexpectedReferrerFee`, a defensive check on the model).

**Expected inputs & caller responsibilities.**

- Same-slot klend refreshes as in §2.3. `init_obligation` needs none; for `request_elevation_group`,
  klend itself enforces freshness.
- For deposit/withdraw collateral, borrow and repay, the target reserve's `scope_configuration`
  must match the vault token's (`ReserveScopeMismatch`), and the price-basis gate (§2.3) must pass.
- `init_obligation` is vault-admin only; the other five are for the vault admin or allocation
  delegate. None is user-facing.

**Invariants.** Obligation operations mint and burn no shares. §1.5 (3) applies to how their legs
are valued, and (4) to the freshness and price-basis checks every AUM load runs on them.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- Every `compute_*_effects` models klend as of `klend-private @ 7f795c2`. Any klend behaviour this
  model does not reproduce turns into a revert at best and an accounting drift at worst; §6.2 lists
  the known instance.
- The LTV ceiling is a *predicted* post-op check against klend's *refreshed* values; how those two
  snapshots relate under an adverse price move inside one transaction is worth checking.
- `request_elevation_group` changes the LTV parameters of an existing position rather than its size,
  so the ceiling check has to re-derive everything from the new group.

### 2.7 Permissioned Shares, Admin & Emergency Controls

**Purpose.** Share-mint access control (Token-2022 `DefaultAccountState` + Token ACL / sRFC-37),
authority management for the vault and the global config, and the emergency levers.

**Lineage.** New; kvault shares are plain SPL and always transferable.

**Mechanics & math.**

- A vault created with a gating program is **permissioned**: the share mint carries
  `DefaultAccountState = Frozen`, so a freshly created share account is unusable until thawed
  through the Token ACL program (`TACLkU6CiCdkQN2MjoyDkVg2yAH9zkxiHDsiztQ52TP`). The real freeze
  authority is the Token ACL `MintConfig` PDA; the vault drives it by hand-rolled CPI, because the
  upstream client crate cannot link against this workspace's Solana 1.17 / borsh 0.10 stack.
- `validate_permissioned_vault_accounts` requires `shares_permissioned == 1`, the passed account to
  be the canonical `MintConfig` PDA owned by Token ACL, and its `config_admin` to be the vault's
  `base_vault_authority`. On a permissioned vault, the program requires a share account to carry the
  Token-2022 `ImmutableOwner` extension (`SharesAccountOwnerMutable`) on its own paths (`buy`,
  `sell`, `open_withdraw_order`, `settle_deposit_order`, `withdraw_pending_fees`,
  `thaw_shares_account`), so a thawed account cannot be handed to an ungated owner. Token ACL's
  permissionless thaw never enters the program, so there the gating program must enforce it.
- `init_vault` enables Token ACL **permissionless thaw** on permissioned vaults: a holder the gating
  program approves can thaw their own account without the vault. The vault admin can toggle
  permissionless freeze/thaw (`toggle_shares_permissionless`), change the gate
  (`set_shares_gating_program`), and remove permissioning once (`delete_shares_config`, §6.1).
- Admin handoff is two-step: set `pending_admin`, then the pending key calls `apply_pending_admin`
  (vault) or `update_global_config_admin` (global). `apply_pending_admin` also clears
  `allocation_admin_authority`. All other authorities (council, unfreeze, swap, allocation, krfq)
  are set in one step.
- Emergency flags: `emergency_mode`, `block_deposits`, `block_withdraws`. The vault admin may set
  any of them either way. The **emergency council** may only set them to `1`; the **unfreeze
  authority** may only set them to `0`. The council may freeze an individual share account but may
  not thaw it through the vault; the vault admin always holds both freeze and thaw.
- `emergency_mode == 1` blocks, via `#[access_control]`, the same nine instructions that carry the
  `check_cpi!` guard against invocation by CPI: `buy`, `sell`, `refresh_vault`, `rebalance_swap`,
  and the five order instructions (§6.1).
- These are refused while a rebalance is *within its window*, since they would re-price in-flight
  fills: `VaultTokenScope`, `VaultTokenMaxAgePriceSeconds`, `VaultTokenMaxAgeTwapSeconds`,
  `VaultTokenMaxTwapDivergenceBps`, `VaultTokenMaxPriceDivergenceBps`,
  `VaultTokenDutchAuctionBounds`, `TokenWeights`, plus the `add_vault_token` and `init_obligation`
  instructions. Other fields, including the rebalance limits, are not refused; a running rebalance
  keeps the limits it started with.

**Expected inputs & caller responsibilities.**

- A permissioned vault's integrators must create share accounts with `ImmutableOwner` and route them
  through the gating program before transfer.
- `update_vault_config` takes a `VaultConfigField` discriminant plus a raw little-endian byte
  payload; per-token and per-obligation fields prefix the payload with the 32-byte mint or
  obligation address. The caller is responsible for the encoding.

**Edge cases & intentional behaviour.** See §6.1.

**Areas of concern.**

- The hand-rolled Token ACL wire encoding: discriminators and account orders are pinned only by the
  tests against the `token_acl.so` fixture (`tests_token_acl_harness.rs`,
  `tests_permissioned_shares.rs`, `tests_security/tests_security_shares_acl.rs`). A Token ACL
  upgrade that reorders accounts would be silently mis-encoded.
- The freeze/thaw authority split between vault admin, emergency council, unfreeze authority and
  Token ACL's permissionless paths, and what each can do to a holder who is not misbehaving.

---

## 3. Deployment Environment

### 3.1 Supported Chains

Solana mainnet-beta only. There is no multi-chain deployment and no cross-chain messaging.

### 3.2 Tokens

**Vault tokens:** allow-listed per vault by the vault admin via `init_vault` / `add_vault_token` —
up to 10 per vault. Both SPL Token and Token-2022 mints are accepted, restricted to klend's supported
extension set (`check_only_supported_liquidity_token_extensions`, inherited unchanged): notably a
Token-2022 mint with a **non-zero transfer fee is rejected**, and a transfer hook is accepted only
with no hook program set. Mints with 6–18 decimals are in scope; nothing else is. This is a scope
policy, not a program constraint: the program rejects only a 0-decimal first token. Rebasing
tokens, fee-on-transfer tokens and blocklist/pausable behaviour beyond USDC/USDT's are **not**
supported and findings premised on them are out of scope. The token list and oracle mappings are
trusted admin inputs (§4.1).

**Share tokens:** always Token-2022, minted by the program, with a self-referential
`MetadataPointer` and `DefaultAccountState` (Initialized on open vaults, Frozen on permissioned
vaults). Share decimals equal the first token's decimals.

### 3.3 External Integrations & Dependencies

- **Kamino Lending (klend)**, pinned at `klend-private @ 7f795c2`. Used for all yield generation:
  obligations, reserves, collateral exchange rates, elevation groups, and the borrow/repay maths
  MetaVault models (mostly by calling the pinned crate). Trusted to behave as that revision does.
- **Scope** (`scope-types`, branch `anchor_0.29_idl`). The sole price source for AUM. Trusted to
  publish correct prices; the program enforces age, TWAP age and TWAP divergence on top.
- **Token ACL / sRFC-37** (`TACLkU6CiCdkQN2MjoyDkVg2yAH9zkxiHDsiztQ52TP`). Freeze/thaw gating for
  permissioned share mints. Trusted; its `MintConfig` is the canonical source of the gating program.
- **SPL Token-2022** (Kamino-patched `v0.9.0`). Share mints and any Token-2022 vault token.
- **Kamino Farms (kfarms).** Address-pinned; farm accounts are forwarded to klend on the four
  token-moving obligation operations.
- **krfq auction server.** Off-chain; see §4.3.

---

## 4. Roles, Permissions & Trust Model

### 4.1 Privileged Roles

- **`vault_admin_authority` — Fully trusted** (toward its own vault's depositors). It sets weights,
  fees, oracle mappings, caps, limits, authorities, and runs allocation. `init_vault` is
  technically permissionless, but **third-party vault creation is not a supported product surface**:
  all production vaults are created and operated by Kamino, and only Kamino-operated vaults are
  surfaced to users. Findings whose precondition is a malicious or careless vault admin are out of
  scope; §6.1 lists the specific vectors.

- **`allocation_admin_authority` — Partially trusted.** An optional delegate appointed by the vault
  admin. It may call `start_rebalance`/`stop_rebalance`, the five obligation operations other than
  `init_obligation`, and `update_vault_config` for `TokenWeights` only (no cooldown; refused only
  inside a rebalance window). It is *expected* to allocate sensibly and rebalance in good faith. It
  is *bounded* on-chain by: the rebalance cooldown (start-to-start, survives stop-then-restart,
  bypassed only by the exact vault admin key), the per-fill and per-auction loss limits, the
  dutch-auction scale range `[0.5x, 3.0x]`, the per-obligation LTV ceiling, the price-basis gate,
  and the rule that obligation inventory cannot move during a rebalance. **It must not be able to
  exceed any of those bounds, or to move value out of the vault to an address of its choosing.** A
  finding showing it can is in scope at full severity.

- **krfq auction server** (`GlobalConfig::krfq_swap_authority`) — **Partially trusted.** On a
  krfq-gated vault it decides which bid reaches the chain, and is expected to select the best one.
  It is bounded by the same dutch-auction scales and loss limits as any other fill, and by the fill
  marker, which binds one co-signature to exactly one basket (vault or order) and ordered mint pair.
  **It must not be able to exceed the loss limits, nor to have a co-signature apply to a basket or
  pair other than the one its marker names.** `Pubkey::default` means unset, and a gated vault then
  rejects every fill, order fills included (fail-closed).

- **`swap_authority` — Untrusted, and it is the counterparty.** When set, only this key may fill
  the vault's auctions, including users' order auctions. It funds the fill and receives the
  proceeds, so it is an economic adversary by construction; the loss limits and auction bounds are
  what constrain it. Unset means anyone may fill (subject to the krfq gate, if enabled).

- **`emergency_council` — Partially trusted.** May set `emergency_mode` / `block_deposits` /
  `block_withdraws` to `1` only, and may freeze an individual share account. It cannot clear any
  flag and cannot thaw. Expected to act only in an incident; its worst case is griefing (blocking
  exits), never theft.

- **`unfreeze_authority` — Partially trusted.** The mirror image: may clear the emergency flags and
  thaw share accounts. The vault admin holds the same powers whether or not this key is set.

- **`GlobalConfig::global_admin` — Fully trusted.** Sets protocol-wide *minimum* deposit and
  withdrawal fees (which compose as `max(global, per-token)`) and the krfq server key. Currently
  `AUPgveiZz7XUe6SmYg17SMa3zhhcEQpjagdGsk8koj2G`.

- **Order owner — Untrusted.** Any user. Chooses their order's auction duration, loss limits,
  slippage floors and (withdraw orders only) target weights. Must not be able to affect any other
  order, the vault's own basket, or another user's funds.

- **Filler / cranker — Untrusted.** Permissionless by default. Must not be able to extract more than
  the loss limits allow, settle an order to an address other than the owner's associated accounts,
  or make any order unsettleable.

### 4.2 Configurable Parameters & Valid Ranges

"Intended" is the operating target. † = refused while a rebalance window is open (§2.7).

**Global (`GlobalConfig`, `B5tBsfPF2FXcNbAcrvFBje6d47qw6h27wztaKNwPmAFc`)**

| Parameter | Setter (role) | Valid range | Intended |
|---|---|---|---|
| `deposit_fee_bps` | `update_global_config` (global admin) | 0–1000 (10%) | 0 |
| `deposit_fee_lamports` | ″ | 0–10 000 | 0 |
| `withdrawal_fee_bps` | ″ | 0–1000 (10%) | 0 |
| `withdrawal_fee_lamports` | ″ | 0–10 000 | 0 |
| `krfq_swap_authority` | ″ | any `Pubkey`; default = unset (fail-closed) | set before enabling krfq |

**Vault-level (`update_vault_config`, vault admin unless noted)**

| Parameter | Valid range | Intended |
|---|---|---|
| `performance_fee_bps` | 0–5000 (`MAX_PERF_FEE`, 50%) | 1000–2000 |
| `management_fee_bps` | 0–1000 (`MAX_MGMT_FEE`, 10%) | 0–100 |
| `rebalance_cooldown_seconds` | 0–2 592 000 (30 d); `0` disables | hours, if a delegate is set |
| `deposit_cap_usd_sf` | any `u128`; `0` disables | per-strategy |
| `rolling_{deposit,withdraw}_cap.{interval_seconds, max_usd_sf}` | interval 0–604 800 (7 d), `0` disables; max any `u128` | per-strategy |
| `rebalance_limits.max_fill_slippage_bps` | 0–10 000; `0` = no loss, `10000` = loss up to the fill's input value | 10–100 |
| `rebalance_limits.max_loss_bps` | 0–10 000; `10000` = no limit | tightened before launch |
| `order_min_open_usd_sf` | any `u128`; `0` = no minimum | per-strategy |
| `emergency_mode` / `block_deposits` / `block_withdraws` | `0` or `1`; council may set to `1`, unfreeze authority to `0` | 0 |
| `emergency_council` | any `Pubkey`; default = unset | multisig |
| `unfreeze_authority` | any `Pubkey`; default = unset (the vault admin always holds these powers) | — |
| `swap_authority` | any `Pubkey`; default = anyone may fill | unset (krfq instead) |
| `allocation_admin_authority` | any `Pubkey`; default = admin only | bot key |
| `krfq_enabled` | `0` or `1` | 1 on gated vaults |
| `deposit_order_{creation,fill,settle}_enabled` | `0` or `1` | 1 |
| `withdraw_order_{creation,fill}_enabled` | `0` or `1` | 1 |
| `TokenWeights` † (vault admin **or allocation delegate**) | must sum non-zero, fit `u64` | per-strategy |

**Per-token (`VaultToken`, addressed by mint)**

| Parameter | Valid range | Intended |
|---|---|---|
| `deposit_fee_bps` / `withdraw_fee_bps` | 0–1000 each | per-strategy |
| `deposit_fee_lamports` / `withdraw_fee_lamports` | 0–10 000 each | per-strategy |
| `min_deposit_amount` / `min_withdraw_amount` | 0–1000 lamports each | dust floor |
| `max_deviation_bps` | 0–10 000; **`0` disables the bound** | 100–500 |
| `max_price_divergence_bps` † | 0–10 000; **`0` requires an exact match (fail-closed)** | set per token before enabling borrows |
| `max_twap_divergence_bps` † | 0–10 000; `0` disables TWAP checking; default 100 | 100 |
| `max_age_price_seconds` / `max_age_twap_seconds` † | 1–86 400; default 60 | 60–120 |
| `dutch_auction_scales` † (4 × bps) | each 5000–30 000; selling non-increasing, buying non-decreasing | ±0.4–0.75%, e.g. USDC `[10040, 9960, 9960, 10040]` |
| `scope_configuration` † | not validated when set at `init_vault`/`add_vault_token`; every price load checks it | per token |

**Per-obligation**

| Parameter | Valid range | Intended |
|---|---|---|
| `max_unhealthy_ltv_fraction_bps` | 0–10 000; `0` disables | 7000–9000 |

**Compile-time constants (not configurable)**

`MAX_TOKENS_PER_VAULT = 10` · `MAX_OBLIGATIONS_PER_VAULT = 3` · `MAX_ORDERS_PER_OWNER = 4` ·
`INITIAL_DEPOSIT_SIZE = 1000` · `PERF_FEE_COOLDOWN_SECONDS = 86 400` ·
`MAX_CHARGED_RATE_FOR_VAULT_FEE = 5000 bps` · rebalance duration `[600, 604 800] s` ·
order auction duration `[300, 86 400] s` · `REBALANCE_SETTLED_TOLERANCE = 1000 lamports` ·
`MIN_REBALANCE_SWAP_AMOUNT = 1000 lamports` · `YEAR = 31 556 925 s`.

### 4.3 Off-Chain Components & Operational Assumptions

All of these are out of audit scope. They are assumed to run reliably and honestly; where one can
fail, the consequence is stated.

- **Cranker** — calls `refresh_vault` to keep fee accrual current, closes elapsed rebalances, and
  settles orders whose auctions are over. Signs and pays for those transactions; never fills, never
  advertises. **Liveness only**: both actions are permissionless, so if the cranker stops, anyone
  can perform them. An order whose auction is over stays settleable indefinitely.
- **Keeper** — the sole advertiser of auction opportunities, for krfq-gated vaults only. Posts one
  pair per basket (the largest fillable at post time). Holds no funds, signs nothing, never bids.
  If it stops, fills simply stop being advertised; nothing on-chain degrades.
- **krfq auction server** — ranks bids, co-signs the winner with `krfq_swap_authority`, and submits.
  If it stops, a krfq-gated vault cannot be rebalanced, and its order auctions cannot be filled,
  until the server returns, the admin clears `krfq_enabled`, or the global admin rotates
  `krfq_swap_authority` (fail-closed).
- **Solver / filler bots** — untrusted third parties. Expected to be economically rational and
  absent when unprofitable. The protocol must remain safe with zero fillers: an unfilled auction
  simply expires.
- **Scope price crank** — Scope feeds must be kept fresh within each token's `max_age_price_seconds`,
  or the vault halts (§6.1). Some strategies price a token (e.g. cTokens) off a dedicated Scope
  chain that requires its own permanently-running crank. This is the single largest operational
  dependency in the system.
- **Multisig governance** — `global_admin` and the production vault admins are intended to be
  multisigs, which is why administrative instructions stay CPI-callable (§6.1).

---

## 5. Previous Audits

- **Certora — "Kamino – Metavault – Draft Report", September 2026.** 30 findings (5 Medium, 12 Low,
  13 Informational) against commit `95760c4`. Report and our full written response are provided
  alongside this document (`Certora - Kamino - Metavault - Draft Report.pdf`,
  `CERTORA-TRIAGE-2026-09-21.md`). 14 fixed, 1 partially fixed, 3 fixed before the review concluded,
  12 acknowledged and not fixed. No finding was disputed. Per the engagement rules, every issue in
  that report is treated as known, and the acknowledged-but-unfixed ones are not valid as new
  findings.

---

## 6. Known Issues, Accepted Risks & Design Decisions

§6.1 lists **intended behaviour that can look like a bug**; §6.2 lists **known issues** in the code
under review. Items in either are not valid findings. (Issues from the Certora report are covered by
§5 and are not repeated.)

### 6.1 Design Decisions by Component

#### Vault Core & Share Accounting

**Flow fees are donated to the vault, not collected.**
Deposit and withdrawal fees stay in `token_available` and raise the share price for remaining
holders. There is no fee recipient for them and no accounting line tracking them.

**Depositors are priced against post-fee AUM.**
Shares for a deposit are minted against `net_aum + value(deposit_fee)`, not against `net_aum`.
Pricing against pre-fee AUM would give the entrant a pro-rata claim on their own fee the moment they
receive shares, cutting the realised fee rate to `nominal × A/(A+N)` and weakening the fee as a
barrier to atomic manipulation (Certora M-05). A depositor's post-deposit stake is therefore worth
exactly their net contribution, and the fee lands entirely on existing holders.

**Withdrawers burn shares against the gross amount.**
Share burn is computed on the pre-fee redemption value with ceiling rounding, so the withdrawer
keeps no claim on the fee they donate. `shares_to_burn = min(theoretical, requested)`, so a
withdrawer never burns more shares than they asked to.

**The two zero conventions are inverted.**
`max_deviation_bps == 0` disables the target bound; `max_price_divergence_bps == 0` requires an
exact price match. A weight bound defaults to absent, a price-basis bound to strictest.

**Deposits and withdrawals halt at non-positive net AUM.**
A levered vault that goes underwater refuses `buy`, `sell`, `open_withdraw_order` and
`settle_deposit_order` (`check_positive`), and the `aum` and `exchange_rate` views fail with it.
`cancel_deposit_order` and `settle_withdraw_order` need no net AUM, so open orders can still be
exited. Obligation operations stay open, so the position can be unwound before flow resumes.

**Direct transfers to the vault are not counted.**
A token account's balance is at least `token_available + locked_total`; anything above that is
untracked surplus and counts toward neither the token's balance nor AUM.
`check_vault_balance_covers_locked` asserts the lower bound on `sell`, `open_deposit_order`,
`rebalance_swap` and order payouts.

**The seed deposit is valued at a mocked $1 per whole token.**
The 1000 seed shares are dead shares (§2.1), and the mocked value seeds the performance checkpoint.
For a first token priced below $1, the checkpoint starts above the real share price, so no
performance fee is charged until the share price passes it or a Scope feed change re-anchors it.
Only the fee recipient bears this.

#### Fee Accrual

**Performance is charged on appreciation from any source.**
Market yield, donated flow fees and rounding all count; waived fee shares do not (the checkpoint is
scaled on a give-up). "Performance" means per-share price appreciation above the checkpoint, not
realised investment profit.

**Performance-fee boundaries have timing effects, in both directions.**
Performance is charged only at a cooldown boundary: the first fee-charging touch at least 24 h after
the last performance charge, so whoever touches the vault first picks it. (a) A holder who withdraws
shortly before a boundary and stays out across it never pays on their accrued gain (*exit dodge*).
(b) A holder who deposits mid-window and is present at the boundary is charged against a checkpoint
set before they arrived (*mid-window charging*). Both follow from charging a per-share high-water
mark at discrete boundaries; pro-rating per holder would need a per-account cost basis, which these
fungible shares do not carry. A deposit-then-withdraw round trip does not change the boundary
charge; a blended checkpoint was rejected because it would.

**The checkpoint is a high-water mark and never ratchets down on a drawdown.**
After a loss, no performance fee is charged until net AUM exceeds the carried checkpoint value — the
recovery is free — and losses are never charged back. A Scope feed change is the one event that
re-anchors the checkpoint value downward, because it changes the valuation basis, not the value.

**Changing the performance fee rate forgives in-window gain.**
The update runs `charge_fees` at the old rate, then raises the checkpoint to the current price
(raise-only; a no-op below the checkpoint or at negative AUM). Mid-window gain under the old rate is
forgiven rather than charged at the new one; charging it on demand would let a config change bypass
the cooldown.

**Waiving fees requires blocked deposits, and a sandwich residual remains.**
`give_up_pending_fees` requires `block_deposits != 0`, so no deposit can mint shares while the
waiver is pending. A deposit placed just before the blocking transaction, followed by a later
withdrawal, can still capture part of the waiver.

**A long gap between fee charges is capped.**
Each fee is clamped at a 50% post-mint ownership fraction per `charge_fees` call, so one call can
dilute holders by up to 75% in total. Only the management fee can reach the clamp (after more than
five years untouched at the 10% maximum); the excess is forgiven, not carried.

**Fee accrual is only as current as the last touch.**
Nothing accrues autonomously. `refresh_vault` is permissionless so that anyone, not only the fee
recipient, can force accrual.

#### AUM Valuation & Oracles

**Vault liveness is coupled to its weakest input.**
Any of these halts every AUM-touching instruction on the vault, deposits and withdrawals included:
one stale or failing Scope feed; on a vault with obligations, a klend obligation or leg reserve not
refreshed in the same slot; or a leg reserve whose cached price is outside
`max_price_divergence_bps` of Scope (any difference at the default `0`). The vault refuses to price
itself on inputs it does not trust.

**klend's cached reserve price is never an AUM input.**
Obligation legs are valued at the vault's own Scope price, with klend supplying quantities only. The
price-basis gate bounds how far the two views may diverge; it is not a fallback to klend's price.
klend-basis values do drive the LTV ceiling and all-available withdraw/borrow sizing.

#### Rebalancing & the Dutch Auction

**A fill's `amount_in` is clamped down to the remaining deficit.**
An oversized `amount_in` is not rejected — it is silently reduced. The filler still receives exactly
its `requested_out_amount`, which must fit under the curve output for the *reduced* input, or the
fill reverts (`SlippageExceeded`). This is a property of the fill, not a partial-fill protocol.

**`requested_out_amount` is an exact payout, not a minimum.**
A filler asking for less than the three ceilings allow simply leaves the surplus in the basket. The
program never scales the ask up or down.

**Restarting a rebalance resets its loss accumulator.**
The loss ceiling is per auction, not per period. The start-to-start rebalance cooldown rate-limits
restarts and binds only the allocation delegate; the exact vault admin key bypasses it, though an
admin start still re-arms the anchor.

**Anyone can end a rebalance early by making it unfillable.**
A rebalance ends when its window elapses or no fill can make progress at current prices, and the next
AUM-touching instruction, a user's deposit included, closes it lazily. Any deposit or withdrawal can
make the vault unfillable, so a delegate's auction can be cut short and the delegate must then wait
out the start-anchored cooldown. Mitigation: keep `rebalance_cooldown_seconds` to hours on
delegating vaults. Config changes are refused only while `now` is inside the window, so an elapsed
window does not block them even before it is closed.

**Obligation operations wait for a rebalance.**
Moving inventory in or out of klend shifts free AUM and therefore every target. The four
token-moving operations close a rebalance that is over and are refused while it can still be filled
(`ObligationOperationDuringRebalance`). `init_obligation` is refused for the whole window, even when
the rebalance is unfillable. `request_elevation_group` is not gated.

#### Deposit & Withdraw Orders

**A withdraw order releases a slice of every free token, wanted or not.**
`open_withdraw_order` burns shares for their claim on net AUM, released as a pro-rata slice of *all*
free vault token balances, including ones the owner's chosen weights set to zero. Converting that
slice into the owner's weights is what the subsequent auction is for; an order that nobody fills
settles as the raw pro-rata mix.

**A deposit order settles for whatever the target bounds admit, and refunds the rest.**
If the vault's weight ceilings only admit part of the basket, the rest is returned and the owner's
shares reflect only the absorbed part. An absorb worth less than one whole share mints and absorbs
nothing. A breached `max_share_price` or deposit cap reverts the whole settle instead.

**Order settles are permissionless, and deposit settles re-price at settle time.**
Anyone may settle once the auction is over. A deposit order's share price at settle is not the price
at open; `max_share_price`, fixed at open, bounds it. A withdraw order is priced once, when its
shares burn at open (`min_tokens_out`). For both, the owner's loss limits bound the auction.

**Deposit orders follow the vault's live weights and dutch scales.**
Only the loss limits are a deposit-order owner's own; the order is auctioned into the vault's current
weights, so a weight change steers running orders. Withdraw-order owners choose their weights. All
orders are priced on the vault's per-token dutch scales.

**`block_deposits` and `block_withdraws` gate only the half of an order that mints or burns.**
`block_deposits` stops `settle_deposit_order` but not `open_deposit_order`; `block_withdraws` stops
`open_withdraw_order` but not its settle. `cancel_deposit_order` and `settle_withdraw_order` have no
order-specific switch, so outside `emergency_mode` an owner can always retrieve what an order holds:
a withdraw order's owner can settle at any time, a deposit order's owner can cancel mid-auction. A
deposit settle can still be blocked by its flag, `block_deposits`, a frozen shares account,
`max_share_price` or the deposit caps.

#### klend Obligation Allocation

**MetaVault models klend's maths and reverts on a token-movement mismatch.**
Each token-moving obligation operation predicts its own effect and asserts the post-CPI SPL balance
deltas match (`BalanceAfterObligationCpiMismatch`), so a klend behaviour the model does not reproduce
in transferred amounts shows up as a revert rather than silent corruption. Reports that a klend
configuration causes such a revert describe this guard working; §6.2 lists the known instance.

**Repay and deposit-collateral are never blocked by the LTV ceiling.**
Only `borrow`, `withdraw_obligation_collateral` and `request_elevation_group` are gated, so the
ceiling never blocks a rescue. Repay and deposit-collateral remain subject to freshness,
price-basis, scope-match and no-fillable-rebalance preconditions.

**Borrow-all and full repay lose sub-lamport amounts.**
An all-available borrow lowers AUM slightly more than an exact borrow, because klend books a
sub-lamport part it never transfers. On a full repay, the sub-lamport difference goes to the
reserve rather than to AUM.

#### Permissioned Shares, Admin & Emergency Controls

**Emergency mode does not stop allocation or administration.**
It blocks user flow, fills and all order instructions (including `cancel_deposit_order` and
`settle_withdraw_order`). Obligation operations, `start_rebalance`/`stop_rebalance`, fee withdrawal
and configuration all remain available, so an incident can be unwound while flow is halted, except
for steps that need a `rebalance_swap`.

**The emergency council can block exits, and cannot clear its own flags.**
Clearing the flags requires the vault admin or the `unfreeze_authority`. A council freeze of a share
account holds only if the vault admin has disabled Token ACL permissionless thaw; otherwise a holder
the gate approves can undo it. A compromised council key is therefore a griefing risk (blocked
withdrawals), not a theft risk. Accepted as the price of a fast, low-privilege incident lever.

**Removing permissioning leaves frozen accounts frozen.**
`delete_shares_config` (vault admin, one-way) deletes the Token ACL `MintConfig`, sets the share
mint's default state to Initialized and clears `shares_permissioned`. No instruction re-enables
permissioning, and accounts frozen at that moment stay frozen.

**`vault_farm` is configurable but inert.**
Shares are Token-2022 mints; kfarms accepts only legacy SPL on the stake side and rejects
`DefaultAccountState` on rewards. A configured farm cannot stake these shares until kfarms is
extended. The field is retained for layout stability.

**The CPI guard covers user flow, not administration.**
The nine user-flow and fill instructions (§2.7) cannot be invoked from another program; they can
still share a transaction with other programs' top-level instructions. Administrative instructions
and all obligation operations stay CPI-callable so that on-chain multisigs can administer the vault.
Their `instruction_sysvar_account` is kept for IDL and client stability; the vault does not read it
(the four token-moving obligation operations forward it to klend).

#### Trust-model consequences (vault admin is trusted — see §4.1)

The following are reachable **only** by the vault admin key and are out of scope:

- Adding a token with an arbitrary oracle mapping. Nothing binds a mint to a particular Scope feed,
  so an admin can price a worthless token off a valuable feed.
- Opening an obligation in an arbitrary klend lending market, including one the admin controls.
- Setting `swap_authority` to a key the admin controls and filling the vault's own auctions, bounded
  only by the admin-set loss limits and auction scales (both of which the admin may set to their
  most permissive values).
- Setting fees to their caps (10% management, 50% performance, and on flow
  `max(10%, 10 000 base units)` per operation).
- Disabling every bound: `max_deviation_bps = 0`, `max_unhealthy_ltv_fraction_bps = 0`,
  `max_loss_bps = 10000`, no caps, no cooldown.

No on-chain allow-list or timelock constrains these; the mitigation is operational (Kamino-operated,
multisig-held admin keys). Findings premised on a compromised vault admin key are out of scope.

### 6.2 Known Issues

**Flow is not blocked while an obligation can be liquidated.**
`buy`, `sell`, `open_withdraw_order` and `settle_deposit_order` do not check obligation health. A
pending liquidation's bonus, or a pending `socialize_loss` on a reserve the vault supplies, is a
loss the share price does not show until it lands: a holder who sees it coming can exit at the
pre-loss price and leave the loss to the remaining holders. The LTV ceiling (§2.6) limits how close
the vault borrows to the threshold but cannot stop a price move from crossing it. Liquidations klend
triggers without an LTV breach (individual or market-wide deleveraging, debt term reached) have the
same effect. Planned fix: block deposits and withdrawals while any registered obligation is
liquidatable; the non-LTV triggers are harder to detect in advance and are not yet covered.

**Repaying fixed-term debt before its term ends reverts.**
klend's fixed-term early-repay penalty (present in the pinned revision) is not modelled, so the
transfer never matches the prediction and `repay_obligation_liquidity` always reverts
(`BalanceAfterObligationCpiMismatch`) until the term ends.

---

## 7. Build, Test & PoC Setup

**Toolchain.** Rust 1.74.1 (`rust-toolchain.toml`), Solana CLI 1.17.x (CI uses 1.17.34; crates are
locked at 1.17.18), Anchor 0.29.0. Agave 2.x/3.x will not build this workspace.

**Access.** Two dependencies are private and fetched over SSH: `kamino_lending`
(`ssh://git@github.com/Kamino-Finance/klend-private.git`, used by the program and its
dev-dependencies) and `orbit-link` (`ssh://git@github.com/Kamino-Finance/scope-private.git`, used by
the `libs/client` workspace member; Cargo resolves the whole workspace for any command). Researchers
need read access to both; configure an SSH key for `github.com` before building.
`Cargo.lock` pins klend at `7f795c2`, the revision the obligation maths in §2.6 is written against.
Build with `--locked` and never run `cargo update`, which would move the pin.

Build:

```bash
cargo build-sbf --manifest-path ./programs/metavault/Cargo.toml
cargo clippy --all-targets -- -D warnings   # what CI runs
```

Run the test suite:

```bash
cargo test -p metavault --lib                    # all pure-logic unit tests
cargo test -p metavault --lib tests_rebalance    # one module
RUST_MIN_STACK=83886080 cargo test -p metavault --test tests_rebalance_swap   # one integration file
RUST_MIN_STACK=83886080 cargo test -p metavault --test tests_withdraw_orders -- test_open_fill_settle_lifecycle
```

`RUST_MIN_STACK=83886080` is required for integration tests. Run integration test files **one at a
time**, as CI does: each debug test binary is about 0.9 GB, so building the whole suite needs about
30 GB of disk. `tests_security/` is a directory of modules built as one target
(`--test tests_security`).

No RPC URL, fork, or `.env` is needed. Under `cargo test`, metavault, klend and kfarms run as native
builtins compiled from source inside an in-process `solana-program-test` bank. Scope is not loaded as
a program: price accounts are written directly (`setup::update_scope_px_and_twap`). Only Token ACL
and the test gate programs load from `programs/metavault/tests/fixtures/*.so`.

**Where to put a PoC.** Two harnesses, pick by what you need to show.

*Operations-level* — for accounting, fee, rounding and auction-maths bugs. Fastest loop; no runtime,
no CPI. Add a file under `programs/metavault/src/operations/tests/`, declare it in that directory's
`mod.rs`, and drive the operations directly. `setup_vault_with_tokens` builds a `MetavaultState`
plus matching synthetic `VaultScopePrices`, registers all tokens in name order, and seeds the first
one, mirroring the state changes of `handler_init_vault`:

```rust
// Run with: cargo test -p metavault --lib poc_
use std::collections::HashMap;

use crate::operations::tests::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig};
use crate::operations::vault_operations;
use crate::types::{NetAum, Timestamp, TokenAmount};
use crate::GlobalConfig;

#[test]
fn poc_describes_the_bug() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (mut vault, prices) = setup_vault_with_tokens(&tokens);
    let config = GlobalConfig::default();
    let usdc = tokens["USDC"].mint; // vault_tokens are in name order: [0] is SOL

    let effects = vault_operations::deposit(
        &mut vault,
        &prices,
        NetAum::ZERO,                      // no obligations
        &config,
        usdc,
        TokenAmount::new(1_000_000),
        Timestamp::from(1),
    )
    .unwrap();

    // ... assert the broken invariant on `effects` / `vault`
}
```

Other helpers in `tests_utils.rs`: `TokenConfig::with_price`,
`TokenConfig::with_weight_price_available_decimals` (for weighted/rebalance setups),
`setup_vault_with_tokens_and_config(tokens, withdrawal_fee_lamports, withdrawal_fee_bps)` (sets
global withdrawal fees; returns `(vault, GlobalConfig, prices)`), `make_vault_with_tokens` (no seed
deposit), the `UserState` struct (tracks a simulated user's balances across operations), and
`token_by_id`.

*Full-runtime* — for anything involving accounts, CPI, klend, Token-2022 or signer checks. Add a
file under `programs/metavault/tests/` and build on the shared fixtures:

```rust
// Run with: RUST_MIN_STACK=83886080 cargo test -p metavault --test tests_poc
use kamino_lending::program_test::common::types::{MSpec, MarketsSpec, MintSpec, RSpec};
use maplit::hashmap;
use metavault::program_test::{client, fixtures::setup_markets_with_weights, VaultDepositorAccounts};
use solana_program_test::tokio;

#[tokio::test]
async fn poc_describes_the_bug() {
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string()  => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![RSpec::new("USDC", 0), RSpec::new("SOL", 0)])],
        },
        vec![5_000, 5_000], // target weights, in the vault's dense token order (USDC first)
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 100_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 100_000_000).await;
    // ctx.fast_forward_seconds(60).await;
    // metavault::program_test::setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 110.0, 110.0).await;
    // ... assert the broken invariant via vault.state(&mut ctx).await / vault.balances(&mut ctx)
}
```

What each `programs/metavault/src/program_test/` module gives you:

- `fixtures.rs` — one-call environments: `setup_markets_and_reserves(n)` (simplest: vault + klend
  market + reserves + owner), `setup_markets_with_weights`, `setup_balanced_vault`,
  `setup_markets_and_reserves_permissioned`, `…_with_yield` (to make the vault appreciate).
- `client.rs` — high-level actions: `deposit`, `withdraw`, `refresh_vault`, `start_rebalance`,
  `rebalance_swap` / `try_rebalance_swap`, `update_vault_config(UpdateVaultConfigParams::…)`,
  the order instructions, and the obligation instructions.
- `instructions.rs` — raw instruction builders, for when the PoC needs malformed or substituted
  accounts.
- `setup.rs` — `update_scope_px_and_twap` and friends, to move oracle prices mid-test.
- `token_acl.rs` — permissioned-share (freeze / thaw / gating program) setup.

Useful existing tests to copy from: `tests_rebalance_swap.rs` (auction fills),
`tests_deposit_orders.rs` / `tests_withdraw_orders.rs` (order lifecycle), `tests_obligations.rs`
(klend CPI and LTV ceiling), `tests_price_basis.rs` (the price-basis gate),
`tests_permissioned_shares.rs` (Token ACL), `tests_security/` (access control; target
`tests_security`),
`tests_inflated_share_price.rs` (share-price manipulation),
`tests_random_deposit_invest_withdraw.rs` (randomised flow).

Property-based tests using `proptest` already exist for the share maths, target bounds and
obligation effects (`*_proptest.rs`); extending one of those is often a stronger demonstration than
a single example.

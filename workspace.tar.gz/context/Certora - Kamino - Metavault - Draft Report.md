<watermark>
D R A F T
</watermark>

logo: certora

# Security Assessment
# Draft Report

logo: Kamino

## Kamino – Metavault

September 2026
Prepared for Kamino

---


logo: certora logo: Kamino Finance

<watermark>
DRAFT
</watermark>

# Table of Contents

**Project Summary**..................................................................................................................................................**4**
Project Scope.................................................................................................................................................. 4
Project Overview............................................................................................................................................. 4
Protocol Overview........................................................................................................................................... 4
**Assessment Methodology**..................................................................................................................................**5**
**Threat and Security Overview**............................................................................................................................**6**
1. System and assets...................................................................................................................................... 6
Accounting model....................................................................................................................................... 7
2. Actors, authority, and trust boundaries...................................................................................................... 8
Economic boundaries requiring explicit review......................................................................................... 11
3. Critical runtime verification points............................................................................................................ 13
3.1 Every borrowed position must have a funded and reachable unwind path....................................... 13
3.2 Klend must price a reserve from the same feed MetaVault uses....................................................... 13
3.3 The vault LTV ceiling and Klend's own limits must both bind............................................................ 14
3.4 shares_issued must equal mint supply plus pending fees................................................................. 14
**Findings Summary**............................................................................................................................................ **15**
Severity Matrix.............................................................................................................................................. 15
**Detailed Findings**.............................................................................................................................................. **16**
Medium Severity Issues................................................................................................................................ 20
M-01: Performance fee has no high-water mark, so the same interest is charged again after a
drawdown................................................................................................................................................ 20
M-02: Klend oracle reconfiguration can prevent MetaVault from unwinding obligation positions........... 23
M-03: Mutable ownership of thawed share accounts bypasses permissioned-vault gating.................... 25
M-04: Rebalance swaps have no aggregate loss cap across a rebalance episode - only a per-swap
slippage cap............................................................................................................................................. 26
M-05: Shares are priced against pre-fee AUM, so large deposits recapture most of their deposit fee... 27
Low Severity Issues....................................................................................................................................... 29
L-01: CPI guard prevents administration through on-chain multisigs..................................................... 29
L-02: Cumulative earned interest excludes AUM gained during value-moving operations.................... 31
L-03: Updating a rolling-cap interval can revive an already expired window......................................... 33
L-04: Buy and withdraw can revive a completed rebalance at a mature auction price.......................... 34
L-05: Pre-funding the deterministic shares-mint PDA can block a specific init_vault tx......................... 36
L-06: All-available obligation operations ignore the MetaVault LTV ceiling........................................... 37
L-07: rebase_perf_fee_checkpoint reads prev_aum as if it were current, so a config update while net
AUM is negative lowers the performance-fee checkpoint and makes the whole recovery chargeable... 38
L-08: No path to harvest farm rewards accrued by vault obligations..................................................... 39
L-09: External share burns are never reconciled, permanently stranding a proportion of the vault........ 41
L-10: Shares ACL deletion has no corresponding re-enable path, permanently disabling permissioning..
42

2


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

L-11: Mid-window depositors are charged performance fees on appreciation their capital never earned 43
L-12: Mid-window management-fee minting silently shrinks the performance fee collected at the next 44
**Informational Severity Issues** 46
I-01: Token account fields named ata are not constrained to be associated token accounts 46
I-02: Rebalance target recalculation in obligation operations is unreachable 48
I-03: Obligation AUM assumes every lending market uses the same quote currency 50
I-04: Dead xmsg!/dbg_msg! logging macros are unused and unreachable 53
I-05: Asymmetric zero-amount CPI guard between the two token-transfer helpers 54
I-06: Withdraw lacks the same frozen-shares-account UX check as deposit 55
I-07: Repay reverts on reserves that charge an early repay penalty 56
I-08: Permissionless thaw, enabled by default at vault creation, lets a frozen holder immediately undo the emergency council's freeze 57
I-09: Missing signer requirement on vault_state allows front-running of init_vault 58
I-10: init_obligation lacks a rebalance-state guard, breaking in-flight solver transactions 59
I-11: Withdraw-and-reenter timing around the fee cooldown lets holders dodge the performance fee entirely 60
I-12: Vault-side and reserve-side oracle configs can diverge, letting AUM blend two inconsistent price bases 61
I-13: A normative CONTEXT.md spec is cited throughout the code but absent from the repository 62
**Disclaimer** 63
**About Certora** 63

3

---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

# Project Summary

### Project Scope

| Project Name       | Repository Link                                                                                                | Commit Hash                              | Platform |
| ------------------ | -------------------------------------------------------------------------------------------------------------- | ---------------------------------------- | -------- |
| Kamino - Metavault | \[https\://github.com/Kamino-Finance/metavault-private]\(https\://github.com/Kamino-Finance/metavault-private) | 95760c4dc16f52031d9d6971be42a1d4f2e3505b | Solana   |


### Project Overview

This document describes the security review of **Kamino - Metavault**. The work was undertaken from **August 14th, 2026** to **September 18th, 2026**.

The following contract list is included in our scope:

programs/metavault/src/**

The team performed a manual audit of all the files in scope. During the manual audit, the Certora team discovered bugs in the code, as listed on the following page.

### Protocol Overview

MetaVault is a managed, multi-token Solana vault. Users exchange one supported token at a time for Token-2022 shares. Managers allocate idle assets into Klend obligations, borrow against collateral, and initiate oracle-priced Dutch-auction rebalances of idle inventory. It is not a direct user-controlled lending account: shareholders depend on management for lending-position unwinds and the restoration of withdrawal liquidity.

The implemented limits are ten configured token mints and three registered obligations per vault. These are capacity limits, not an asset allowlist or a guarantee that a maximally populated transaction fits runtime limits. No concrete production mint list is established by this repository. A mint is admitted by the vault administrator, and its denomination, decimals, oracle chain, issuer powers, liquidity, and lending compatibility become part of that vault's trust assumptions.

4

---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

# Assessment Methodology

Our assessment approach combines design level analysis with a deep review of the implementation to ensure that a protocol is secure, economically sound, and behaves as intended under realistic conditions.

At the design level, we evaluate the architecture, the economic assumptions behind the protocol, and the safety properties that should hold independently of a specific chain or environment. This process includes reviewing internal and cross protocol interactions, state transition flows, trust boundaries, and any mechanism that could be exploited to extract value, deny service, or alter core system behavior. At this stage, a focused threat modelling exercise helps identify key attack surfaces and adversarial capabilities relevant to the system. Design level issues often relate to incentive structures, governance implications, or systemic behavior that emerges under adversarial conditions.

Implementation analysis focuses on the concrete behavior of the code within the execution model of the target chain. This involves reviewing the correctness of logic, access control, state handling, arithmetic behavior, and the nuanced behaviors of the chain environment. Familiar classes of vulnerabilities such as reentrancy conditions, faulty permission checks, precision issues, or unsafe assumptions often surface at this layer. These findings require context aware reasoning that takes into account both the code and the architectural intent.

To support this analysis, the codebase is examined through repeated manual passes and supplemented by automated tools when appropriate. High-risk logic areas receive deeper scrutiny, invariants are validated against both design intent and actual implementation, and potential vulnerability leads are thoroughly investigated. Automated techniques such as static analysis, fuzzing, or symbolic execution may be used to complement manual review and provide additional insight.

Collaboration with the development team plays an important role throughout the audit. This helps confirm expected behaviors, clarify design assumptions, and ensure an accurate understanding of the protocol’s intended operation. All findings are documented with clear reasoning, reproducible examples, and actionable recommendations. A follow up review is conducted to validate the applied fixes and verify that no regressions or secondary issues have been introduced.

5


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

# Threat and Security Overview

## 1. System and assets

| Asset / security object                  | Custody or representation                                                                                                       | Required property and main exposure                                                                                                                                            |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Idle underlying tokens                   | Per-mint token-account PDA, derived from token\_vault, mint, and vault-state address; token authority is base\_vault\_authority | Only authorized program paths spend them; actual transfers agree with accounting. These tokens fund redemptions, swaps, collateral deposits, and repayments.                   |
| Invested collateral and outstanding debt | Klend-owned obligations controlled by the vault authority PDA, and Klend reserve escrows                                        | Net position value is priced consistently; debt remains within configured risk limits; collateral and repayment remain accessible.                                             |
| Shareholder claims                       | Token-2022 share mint, user token accounts, and internal shares\_issued                                                         | Minting, burning, and fee dilution preserve claim value. Internal shares are not identical to SPL supply. Frozen accounts and externally burned shares affect claim usability. |
| Manager fee entitlement                  | Fractional pending shares, cumulative counters, and                                                                             | Fees are charged once on the intended basis, retained fractions are                                                                                                            |


6


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

<table>
  <tbody>
    <tr>
        <td> </td>
<td>admin share account after fee collection</td>
<td>conserved, and collection does not dilute holders a second time.</td>
    </tr>
<tr>
        <td>Auction execution rights</td>
<td>Weights, target quantities, start/duration, authority settings, loss bound</td>
<td>Only the intended inventory trades, at an admissible price, during the intended auction lifecycle.</td>
    </tr>
<tr>
        <td>Administrative and access-control state</td>
<td>Vault/global admins, delegates, emergency roles, Token ACL configuration, mint metadata</td>
<td>Role separation, safe handover, recoverable freezes, and accurate integration information. SOL used for rent and transaction fees is operational funding, not the vault's token AUM.</td>
    </tr>
  </tbody>
</table>

## Accounting model

Obligation AUM uses raw debt market value, whereas the LTV safety check uses borrow-factor-adjusted debt against a fraction of the unhealthy borrow value. These serve different purposes. Net AUM can be negative; user deposits and withdrawals require strictly positive net AUM. Positive net AUM does not imply redeemable liquidity or a safe individual obligation.

Free AUM uses recorded `token_available`, not a fresh read of all token-account balances. Unsolicited transfers to a vault token account therefore do not automatically increase reported AUM; `refresh_vault` refreshes prices, fees, and rebalance state, not SPL-balance reconciliation.

7


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## 2. Actors, authority, and trust boundaries

| Actor                     | Actual authority                                                                                                               | Trust / abuse assumption                                                                                                                   |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------ |
| User / shareholder        | Top-level buy and sell using owned token accounts; ordinary share transfers and token-program burns where token state permits  | Untrusted inputs, account substitution, rounding exploitation, strategic entry/exit, and transaction ordering must be considered.          |
| Solver                    | Supplies deficit token and receives excess token through rebalance\_swap                                                       | Permissionless when swap\_authority is zero; otherwise only that signer. A solver is an economic counterparty, not a trusted price setter. |
| Keeper / arbitrary caller | refresh\_vault, conditional finish\_rebalance, and read-only queries                                                           | May choose when to crystallize fees or complete an auction. Lack of a keeper can delay progress.                                           |
| Vault administrator       | Chooses tokens and markets; configures fees, oracles, risk limits, roles and share gating; manages metadata and fee collection | Highly trusted economic controller. A malicious or compromised admin can expose holders through permitted configuration and allocation.    |


8

---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

<table>
  <tbody>
    <tr>
        <td>Allocation delegate</td>
<td>Changes token weights; starts/stops rebalances; performs the four lending token-flow operations and changes elevation group</td>
<td>Cannot add tokens, initialize obligations, collect fees, or change risk ceilings merely by holding this role. Can take material strategy risk inside admitted markets. A zero delegate disables delegation.</td>
    </tr>
<tr>
        <td>Emergency council</td>
<td>Sets emergency/deposit/withdraw blocking flags to 1; freezes permissioned share accounts</td>
<td>Defensive authority can deny access. Cannot clear flags or thaw by this role alone.</td>
    </tr>
<tr>
        <td>Unfreeze authority</td>
<td>Clears those flags to 0; may thaw permissioned share accounts</td>
<td>Can restore access and bypass a gate through the privileged thaw path. The admin also retains these powers.</td>
    </tr>
<tr>
        <td>Global administrator</td>
<td>Sets global minimum deposit/withdraw fee components and nominates a successor</td>
<td>Can change effective user fees across vaults within bounds. Global fees are floors for vault-retained fees, not a separate protocol treasury transfer.</td>
    </tr>
<tr>
        <td>Klend market owner / dependency operators</td>
<td>Configure reserve pricing, lending parameters, market state; dependency upgrade authorities can change semantics if upgrades remain possible</td>
<td>Being owned by Klend does not make a market's economic policy immutable or trustworthy. Admission by the vault admin is a critical boundary.</td>
    </tr>
  </tbody>
</table>

9


---


logo: certora logo: Klend

<watermark>
DRAFT
</watermark>

| Liquidator / external Klend participant | Interacts with Klend under its own rules, outside MetaVault entry points | Liquidation, reserve utilization, interest, or loss socialization can change vault economics without a MetaVault call. |
| --------------------------------------- | ------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- |


The main trust boundaries are:

1. **Caller to MetaVault**: signer, owner, discriminator, mint, token-program, PDA, and stored-key constraints bind caller-controlled accounts to the intended vault. Remaining accounts are a separate untrusted input surface.
2. **MetaVault to token programs**: PDA-authorized transfers and share issuance must preserve exact balance effects. The extension checker restricts behavior but does not remove issuer powers.
3. **MetaVault to Scope**: correct account ownership, configured address/chains, age and TWAP policy establish admissible token prices, not absolute market truth.
4. **MetaVault to Klend**: typed accounts and a fixed program ID establish program provenance; reserve policy, oracle choice, units, health calculations, and repayment semantics remain external dependencies.

10


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## Economic boundaries requiring explicit review

| Boundary                                  | Security objective                                                                      | Current limitation / finding                                                                                        |
| ----------------------------------------- | --------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Price inputs → net AUM                    | Values share one denomination and reliable price basis, with complete fresh inputs      | Klend's cached values are trusted directly; Scope equality does not pin the selected Klend oracle. (M2)             |
| Deposited principal → newly issued claims | Conservative rounding and equitable fee incidence                                       | Entry fees stay in the vault; a large depositor recaptures a fraction through its own shares. (M5)                  |
| Burned claims → user payout               | Correct gross claim burn, net payout and residual ownership                             | Exits can be partial; fee incidence depends on remaining ownership; external burns bypass internal accounting. (L9) |
| Elapsed time / gains → fee claims         | Correct management accrual, fee checkpoint, rounding and dilution                       | Performance checkpoint is not a high-water mark; timing around its cooldown matters. (M1, *L12*)                    |
| Idle liquidity ↔ lending position         | Match actual reserve effects, include fees, and enforce both layers of risk constraints | Max-amount sentinel omits vault ceiling during selection; early-repayment penalty omitted. (L6)                     |


11


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

<table>
  <tbody>
    <tr>
        <td>Configuration → future execution</td>
<td>Changing policy preserves accrued obligations and valid exits</td>
<td>External oracle reconfiguration, rolling-window changes, role/gate changes can block flows. (L3)</td>
    </tr>
<tr>
        <td>Earned value → reporting / realization</td>
<td>Principal, profit, fees, losses and rewards remain distinguishable</td>
<td>Cumulative interest omits operation-generated deltas and clips losses; pending rewards are off-book. (L8)</td>
    </tr>
  </tbody>
</table>

12


---

<watermark>
D R A F T
</watermark>

logo: certora logo: k

## 3. Critical runtime verification points

Each item below is a concrete invariant evaluable against live state. None is enforced end to end by the program: each rests on a trusted party — vault admin, operator, or an external dependency's own governance — staying inside an assumption the code does not check. A violation is not by itself an exploit. It is a signal that the protocol has moved into a configuration where an ordinary event becomes damaging.

### 3.1 Every borrowed position must have a funded and reachable unwind path

**Invariant.** For each obligation carrying debt in mint M, either token_available(M) covers the projected repayment, or a rebalance able to acquire M can be started inside the window the position can tolerate.

Repaying a Klend obligation moves M out of the vault's token account; the vault cannot repay debt in an asset it does not hold. Obtaining M means idle balance or a rebalance swap, and start_rebalance is gated by rebalance_cooldown_seconds, which the admin may set as high as MAX_REBALANCE_COOLDOWN — 30 days. Allocation change is therefore not instantaneous, and a healthy aggregate AUM says nothing about whether the one asset needed is obtainable before the position must be defended.

**What a breach signals.** Debt denominated in a mint the vault holds little or no idle balance of, combined with a long cooldown, means the position cannot be unwound on demand. This is a liquidation-risk amplifier that neither an AUM reading nor an LTV reading exposes, because both are satisfied right up to the moment deleveraging is attempted. Re-evaluate at every borrow, every allocation change, and every cooldown config change — not only when the position is opened.

### 3.2 Klend must price a reserve from the same feed MetaVault uses

**Invariant.** The price source Klend actually resolves for a reserve equals the Scope feed MetaVault uses for the same mint.

has_matching_scope_config compares vault_token.scope_configuration against reserve.config.token_info.scope_configuration and nothing else. Klend's token_info can

13


---

<watermark>
DRAFT
</watermark>

logo: certora
logo: Kamino Finance

carry Pyth and Switchboard configurations alongside Scope, and equality on the Scope field does not establish that Scope is the feed Klend consults. Obligation values and free-AUM values can therefore be denominated by different oracles while every in-program check passes.

**What a breach signals.** The LTV headroom MetaVault computes is not the headroom Klend enforces. Under calm conditions the feeds track each other and the divergence is invisible; it materialises precisely during volatility or a feed outage, which is when liquidation headroom is the only thing that matters. Verify the resolved feed per reserve, not the configured Scope field.

### 3.3 The vault LTV ceiling and Klend's own limits must both bind

Invariant. Predicted post-operation LTV satisfies check_obligation_ltv_ceiling and Klend's liquidation threshold for the active elevation group.

The two are computed from different inputs and can move independently: an elevation-group change, a reserve parameter update, or a max_unhealthy_ltv config change can relax one while the other still binds. A zero max_unhealthy_ltv_fraction disables the vault-side check outright.

**What a breach signals.** The vault ceiling is being treated as the operative risk limit when Klend's is in fact tighter, or the reverse. Either way the operator's stated risk budget is not the enforced one.

### 3.4 shares_issued must equal mint supply plus pending fees

Invariant. shares_issued == spl_supply + pending_fees.

post_withdraw_pending_fees_check asserts only >=, deliberately tolerating external SPL burns that reduce supply without touching the mirror. Nothing ever reconciles the two, and no admin path exists to correct the gap.

**What a breach signals.** A nonzero gap is a permanently stranded proportion of the vault: every redemption divides by the inflated count, so the burned shares' backing is never redistributed and the shortfall scales with AUM indefinitely. Track the gap as an absolute figure and as a fraction of supply.

14

---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## Findings Summary

The table below summarizes the findings of the review, including type and severity details.

| Severity      | Discovered | Confirmed | Fixed |
| ------------- | ---------- | --------- | ----- |
| Critical      | -          | -         | -     |
| High          | -          | -         | -     |
| Medium        | 5          | -         | -     |
| Low           | 12         | -         | -     |
| Informational | 13         | -         | -     |
| Total         | 30         | -         | -     |


## Severity Matrix

|        | High       | Medium | High   | Critical |
| ------ | ---------- | ------ | ------ | -------- |
| Impact | Medium     | Low    | Medium | High     |
|        | Low        | Low    | Low    | Medium   |
|        | Low        | Medium | High   |          |
|        | Likelihood |        |        |          |


15


---


logo: certora logo: k

# Detailed Findings

<watermark>
D R A F T
</watermark>

| ID     | Title                                                                                                        | Severity | Status  |
| ------ | ------------------------------------------------------------------------------------------------------------ | -------- | ------- |
| *M-01* | Performance fee has no high-water mark, so the<br/>same interest is charged again after a drawdown           | Medium   | Pending |
| *M-02* | Klend oracle reconfiguration can prevent<br/>MetaVault from unwinding obligation positions                   | Medium   | Pending |
| *M-03* | Mutable ownership of thawed share accounts<br/>bypasses permissioned-vault gating                            | Medium   | Pending |
| *M-04* | Rebalance swaps have no aggregate loss cap<br/>across a rebalance episode - only a per-swap<br/>slippage cap | Medium   | Pending |
| *M-05* | Shares are priced against pre-fee AUM, so large<br/>deposits recapture most of their deposit fee             | Medium   | Pending |
| *L-01* | CPI guard prevents administration through<br/>on-chain multisigs                                             | Low      | Pending |
| *L-02* | Cumulative earned interest excludes AUM gained<br/>during value-moving operations                            | Low      | Pending |
| *L-03* | Updating a rolling-cap interval can revive an<br/>already expired window                                     | Low      | Pending |


16


---

<watermark>
DRAFT
</watermark>

logo: certora

<table>
  <tbody>
    <tr>
        <td><u>L-04</u></td>
<td>Buy and withdraw can revive a completed<br/>rebalance at a mature auction price</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-05</u></td>
<td>Pre-funding the deterministic shares-mint PDA<br/>can block a specific `init_vault` tx</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-06</u></td>
<td>All-available obligation operations ignore the<br/>MetaVault LTV ceiling</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-07</u></td>
<td>rebase_perf_fee_checkpoint reads prev_aum<br/>as if it were current, so a config update while net<br/>AUM is negative lowers the performance-fee<br/>checkpoint and makes the whole recovery<br/>chargeable</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-08</u></td>
<td>No path to harvest farm rewards accrued by<br/>vault obligations</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-09</u></td>
<td>External share burns are never reconciled,<br/>permanently stranding a proportion of the vault</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-10</u></td>
<td>Shares ACL deletion has no corresponding<br/>re-enable path, permanently disabling<br/>permissioning</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-11</u></td>
<td>Mid-window depositors are charged<br/>performance fees on appreciation their capital<br/>never earned</td>
<td>Low</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>L-12</u></td>
<td>Mid-window management-fee minting silently<br/>shrinks the performance fee collected at the<br/>next</td>
<td>Low</td>
<td>Pending</td>
    </tr>
  </tbody>
</table>

17

---

<watermark>
D R A F T
</watermark>

logo: certora logo: k

| *I-01* | Token account fields named ata are not<br/>constrained to be associated token accounts                                                  | Informational | Pending |
| ------ | --------------------------------------------------------------------------------------------------------------------------------------- | ------------- | ------- |
| *I-02* | Rebalance target recalculation in obligation<br/>operations is unreachable                                                              | Informational | Pending |
| *I-03* | Obligation AUM assumes every lending market<br/>uses the same quote currency                                                            | Informational | Pending |
| *I-04* | Dead \`xmsg!\`/\`dbg\_msg!\` logging macros are<br/>unused and unreachable                                                              | Informational | Pending |
| *I-05* | Asymmetric zero-amount CPI guard between the<br/>two token-transfer helpers                                                             | Informational | Pending |
| *I-06* | Withdraw lacks the same frozen-shares-account<br/>UX check as deposit                                                                   | Informational | Pending |
| *I-07* | Repay reverts on reserves that charge an early<br/>repay penalty                                                                        | Informational | Pending |
| *I-08* | Permissionless thaw, enabled by default at vault<br/>creation, lets a frozen holder immediately undo<br/>the emergency council's freeze | Informational | Pending |
| *I-09* | Missing signer requirement on vault\_state allows<br/>front-running of init\_vault                                                      | Informational | Pending |
| *I-10* | init\_obligation lacks a rebalance-state guard,<br/>breaking in-flight solver transactions                                              | Informational | Pending |


18


---


logo: certora logo: K

<watermark>
DRAFT
</watermark>

<table>
  <tbody>
    <tr>
        <td><u>I-11</u></td>
<td>Withdraw-and-reenter timing around the fee cooldown lets holders dodge the performance fee entirely</td>
<td>Informational</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>I-12</u></td>
<td>Vault-side and reserve-side oracle configs can diverge, letting AUM blend two inconsistent price bases</td>
<td>Informational</td>
<td>Pending</td>
    </tr>
<tr>
        <td><u>I-13</u></td>
<td>A normative CONTEXT.md spec is cited throughout the code but absent from the repository</td>
<td>Informational</td>
<td>Pending</td>
    </tr>
  </tbody>
</table>

19


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## Medium Severity Issues

### M-01: Performance fee has no high-water mark, so the same interest is charged again after a drawdown

<table>
  <thead>
    <tr>
        <th>Severity: Medium</th>
        <th>Impact: Medium</th>
        <th>Likelihood: Medium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Files:<br/>programs/metavault/src/operations/vault_operations.rs</td>
<td>Status: Pending</td>
<td> </td>
    </tr>
  </tbody>
</table>

**Description:**

The performance-fee checkpoint (last_perf_fee_price) is rewritten to the current share price on every cooldown-boundary charge, including when the vault is in a drawdown. Losses are never charged, but the checkpoint ratchets *down* to the depressed price, so the subsequent recovery back to the previous level is treated as fresh performance and charged again. Interest that already paid a performance fee therefore pays a second time on every drawdown/recovery round-trip observed at a cooldown boundary, and depositors pay a performance fee merely for returning to break-even. Over repeated volatility cycles the effective fee rate is unbounded above the configured performance_fee_bps.

**Root Cause**

charge_perf_now is gated on the cooldown alone, and the checkpoint write sits inside that gate with no comparison against the previous checkpoint:

```rust
let charge_perf_now = time_since_last_perf_fee >= PERF_FEE_COOLDOWN_SECONDS
    && !new_aum.is_zero()
    && !total_shares_issued.is_zero();
...
if charge_perf_now {
    vault.set_last_perf_fee_price(SharePrice::of(
            new_aum,
            vault.shares_issued_amount(),
            RoundingMethod::Floor,
    ));
```

20


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

}

When `new_aum` is below the checkpoint value, `perf_earned_interest` saturates to zero — no fee is charged, correctly — but the checkpoint is still overwritten with the lower price and `last_perf_fee_charge` is bumped. The fee base is a rolling per-window low rather than a high-water mark: losses are not charged, but they are not carried forward either.

A drawdown that occurs and recovers entirely *within* one cooldown window is unaffected, since an in-cooldown call does not touch the checkpoint (asserted by `test_perf_charge_zero_after_underwater_deposit_and_recovery`). The problem is specific to a drawdown observed by any `charge_fees` call at or after the cooldown boundary — a permissionless `refresh_vault`, or any deposit/withdraw.

A second path reaches the same state: `rebase_perf_fee_checkpoint`, called on a `performance_fee_bps` or Scope-feed update, sets the checkpoint from `prev_aum`, and `prev_aum` tracks AUM downward on every deposit/withdraw/refresh. An admin config update while the vault is underwater therefore also re-arms the fee on the recovery.

### Attack Scenario

No attacker is required — normal market movement is sufficient. Metavault AUM is dollar-denominated across multiple tokens and net of klend obligation debt, so it moves with token prices and borrow interest, not only with yield.

Vault with a 10% performance fee, management fee ignored for clarity:

| Time     | AUM             | Checkpoint value         | Perf base | Fee charged |
| -------- | --------------- | ------------------------ | --------- | ----------- |
| t0       | $100            | $100                     | —         | —           |
| t0 + 24h | $120            | $100                     | $20       | $2          |
| t0 + 48h | $110 (drawdown) | $120 → reset to **$110** | $0        | $0          |
| t0 + 72h | $120 (recovery) | $110                     | $10       | **$1**      |


21


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

Total interest earned since t0 is $20, but $3 of performance fee was paid — an effective 15% rate on a 10% configured fee. Each additional drawdown/recovery cycle adds another charge on the same interest.

Because `refresh_vault` is permissionless and carries no signer, a fee recipient (or a bot acting for them) can choose the observation point and maximize the effect deterministically:

* Wait for the cooldown to elapse, then call `refresh_vault` at a local AUM minimum — this charges nothing but ratchets the checkpoint down to the trough.
* Wait one cooldown, then call `refresh_vault` at a local maximum — the full rebound from the trough is charged as performance.
* Repeat once per cooldown; each cycle converts price noise into fee shares at the depositors' expense.

**Recommendations:**

Set a high watermark price variable and take it into account when charging fees.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

22

---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## M-02: Klend oracle reconfiguration can prevent MetaVault from unwinding obligation positions

<table>
    <tr>
        <td>Severity: Medium</td>
<td>Impact: High</td>
<td>Likelihood: Low</td>
    </tr>
<tr>
        <td>**Files:**<br/>programs/metavault/src/operations/vault_checks.rs</td>
<td>**Status:** Pending</td>
<td></td>
    </tr>
</table>

**Description:**

The owner of a mutable Klend lending market can enable Pyth or Switchboard and then disable Scope on a reserve that already holds active MetaVault positions; Klend permits this as long as one oracle remains enabled, and does not require the reserve to be free of obligations. MetaVault requires the reserve's Scope configuration to exactly equal the vault token's before every obligation deposit, withdrawal, borrow, and repayment, and cannot configure a vault token against a disabled Scope source. Collateral then becomes inaccessible and repayment is blocked until the Klend owner restores a compatible configuration, while the outstanding debt keeps accruing interest and may be liquidated.

**Root Cause**

MetaVault treats the external reserve's Scope configuration as an immutable compatibility invariant:

```rust
Ok(vault.get_vault_token_by_mint(mint)?.scope_configuration
 == reserve.config.token_info.scope_configuration)
```

The invariant is mutable by the Klend market owner after MetaVault has opened a position, and the equality check gates risk-reducing operations as well as risk-increasing ones. Klend supports three oracle providers, whereas MetaVault requires an enabled Scope configuration — so the MetaVault administrator cannot update the vault token to match a reserve whose Scope source has been disabled.

**Attack Scenario**

1. MetaVault deposits collateral into a Klend reserve and borrows against it.

23


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

2. As part of a legitimate oracle migration, the Klend market owner enables Pyth or Switchboard and disables Scope on the collateral or debt reserve.

3. Klend continues operating once the reserve and obligation are refreshed against the alternative oracle.

4. MetaVault attempts to repay the debt or withdraw the collateral; the instruction fails with ReserveScopeMismatch before invoking Klend.

5. The position cannot be unwound unless the Klend owner restores Scope or the MetaVault program is upgraded, and may accrue interest or be liquidated while recovery is pending.

The vault is not immediately disabled: AUM, deposits, withdrawals, and rebalancing can continue while MetaVault's original Scope feed remains valid and idle liquidity is sufficient. Funds held in the mismatched reserve stay inaccessible, and if the old Scope feed is retired or goes stale, the broader AUM-dependent instruction set becomes unavailable too.

**Recommendations:**

Keep the exact oracle-configuration check for risk-increasing operations such as collateral deposits and borrowing, but provide a risk-reducing emergency path for repayment and collateral withdrawal after an external oracle migration. That path should still validate the lending market, reserve, obligation, mint, and balance changes, and should safely refresh or rebaseline AUM so a change in oracle basis is not treated as vault performance.

Additionally, either support the same alternative oracle sources in MetaVault or restrict allocations to Klend reserves whose oracle configuration is immutable. Monitoring reserve configuration changes and requiring the Klend market owner to retain a compatible Scope source reduces operational risk, but provides no trustless recovery path.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

24


---


logo: certora logo: K

<watermark>
DRAFT
</watermark>

## M-03: Mutable ownership of thawed share accounts bypasses permissioned-vault gating

| Severity: Medium                                           | Impact: Medium  | Likelihood: Medium |
| ---------------------------------------------------------- | --------------- | ------------------ |
| Files:<br/>programs/metavault/src/utils<br/>/token\_acl.rs | Status: Pending |                    |


**Description:**

Permissioned vaults rely on Token-2022's frozen account state: new share accounts are frozen, and an account becomes usable after the gate or an administrator thaws it. However, the program accepts arbitrary Token-2022 share accounts rather than requiring canonical associated token accounts or the ImmutableOwner extension. An approved user can create a non-ATA Token-2022 account without ImmutableOwner, have it thawed, and then invoke Token-2022 SetAuthority(AccountOwner) to transfer ownership of the still-thawed account to an unapproved address. The new owner can freely call buy and sell.

**Recommendations:**

Require every share account used by thaw, deposit, withdrawal, and fee operations to be a canonical Token-2022 associated token account, or deserialize its extensions and require ImmutableOwner.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

25


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## M-04: Rebalance swaps have no aggregate loss cap across a rebalance episode - only a per-swap slippage cap

<table>
  <thead>
    <tr>
        <th>Severity: Medium</th>
        <th>Impact: Medium</th>
        <th>Likelihood: Medium</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Files:<br/>programs/metavault/src/operations/rebalance_operations.rs:</td>
<td>Status: Pending</td>
<td> </td>
    </tr>
  </tbody>
</table>

**Description:**

`calculate_rebalance_swap` only bounds loss per swap: allowed_loss = input_value * max_rebalance_swap_slippage_bps, checked against that swap's own AUM delta. There is no cap on cumulative loss across a whole rebalance episode (up to MAX_REBALANCE_DURATION = 7 days), unlike deposits/withdrawals, which get an explicit RollingDepositCap/RollingWithdrawCap.

recalculate_rebalance_targets recomputes every token's target from live free-AUM and oracle prices on every swap *and* every deposit/withdrawal, since each target is weight / total_weight * free_aum. Deposits/withdrawals are not blocked during an active rebalance, and withdraw explicitly re-triggers this recalculation - so a deposit/withdrawal into one token can shift the shared free_aum denominator and un-settle other tokens that had already converged.

As a result, ordinary deposit/withdrawal activity plus normal price movement over the auction's life can repeatedly reopen "settled" tokens, each reopening buying another slippage-capped round of swaps - with no limit on the sum of those rounds over one episode.

**Recommendations:**

Track cumulative AUM loss (or volume) since rebalance_start_timestamp and cap it, analogous to RollingDepositCap/RollingWithdrawCap.

**Customer Response:**

Awaiting a response

**Fix Review:**

26


---


logo: certora logo: K

<watermark>
DRAFT
</watermark>

## M-05: Shares are priced against pre-fee AUM, so large deposits recapture most of their deposit fee

| Severity: Medium                                                  | Impact: Medium  | Likelihood: High |
| ----------------------------------------------------------------- | --------------- | ---------------- |
| Files:<br/>programs/metavault/src/operations/vault\_operations.rs | Status: Pending |                  |


**Description:**

Deposit and withdraw fees are left inside token_available and shares are priced against AUM that excludes the fee. Because the payer holds shares immediately after the donation, they recapture their own fee pro-rata. On deposit the realized fee is nominal × A/(A+N), which tends to zero as the deposit grows relative to AUM. On withdraw a holder can shed most of the fee by splitting the exit into tranches. Nothing is stolen and the vault stays solvent — the fee simply does not reach the amount configured.

**Attack Scenario**

Vault at $10,000 / 10,000 shares, 50 bps each way. An attacker needs momentary large ownership of the vault for some manipulation (oracle-window, rebalance, rounding, fee-checkpoint):

* Flash loan $1,000,000 and deposit in a single instruction. Nominal fee $5,000; realized fee $50 because the attacker now owns 99% of the vault and 99% of the donation flows back to their own shares.
* Perform the manipulation while holding ~99% of the shares.
* Exit across 20 withdraw instructions in the same transaction rather than one. Each tranche's donated fee lands partly on the attacker's still-unburned shares and is re-withdrawn at only 50 bps, so the withdraw cost decays geometrically instead of being paid once in full.
* Repay the flash loan. Total round-trip cost $469 rather than the ~$10,000 the configured rates imply.

27


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

The attacker never profits from the fee mechanism itself — the cost is always positive. The issue is that the threshold a manipulation must clear to be profitable is roughly 20x lower than the configured fees suggest.

**Impact Description**

The headline consequence is that entry/exit fees stop functioning as an economic barrier against atomic manipulation. Deposit and withdraw fees are the standard backstop that makes flash-loan round trips unprofitable: any attack that must enter the vault, act, and leave pays the round-trip fee, which sets a floor on the profit an attacker needs to clear. That floor is not the configured one, and it collapses precisely as the flash loan gets larger — the attacker recaptures their own deposit fee in proportion to how much of the vault they momentarily own, and can shed the withdraw fee by splitting the exit across instructions in the same transaction.

The same collapse increases the chance of large depositors sandwiching the performance fee charge. It is charged only at discrete boundaries once PERF_FEE_COOLDOWN_SECONDS has elapsed, and last_perf_fee_charge_timestamp is public. So if deposit + withdraw resulting fees are less than the fee that will be charged on the yield gained of the depositor share, it's more profitable to redeposit.

**Recommendations:**

Price the shares against post-fee AUM so the fee always accrues to the existing depositors at the configured rate, independent of deposit size. Solving m/(S+m)·(A+G) = N gives m = N·S/(A+f) — the existing LP share price then rises by exactly f/S on every deposit.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

28


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## Low Severity Issues

### L-01: CPI guard prevents administration through on-chain multisigs

| Severity: Low                                                  | Impact: Low             | Likelihood: Medium |
| -------------------------------------------------------------- | ----------------------- | ------------------ |
| \*\*Files:\*\*<br/>programs/metavault/src/utils<br/>/macros.rs | \*\*Status:\*\* Pending |                    |


**Description:**

Most state-changing instructions call `check_cpi!(ctx)`, which rejects any invocation made through CPI. On-chain multisigs and governance programs such as Squads execute approved instructions through CPI using a vault PDA as the signer. If a MetaVault admin is set to such a PDA, the multisig cannot execute protected administrative operations — they fail with `CpiDisabled`. Off-chain and MPC multisigs are unaffected, since they produce a normal signature for a top-level MetaVault instruction.

**Root Cause**

The guard rejects any invocation whose stack height is above the transaction level, which is exactly how a multisig PDA executes an approved instruction:

```rust
fn is_forbidden_cpi_call(&self) -> Result<bool> {
    let current_index = self.load_current_index()? as usize;
    let current_ix = self.load_instruction_at(current_index)?;

    if current_ix.program_id != crate::ID {
        return Ok(true);
    }

    Ok(self.stack_height() > TRANSACTION_LEVEL_STACK_HEIGHT)
}
```

29


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

The guard is applied uniformly to administrative handlers, where top-level execution is not a security requirement — the existing signer and has_one authority checks already authenticate the caller.

**Recommendations:**

Do not apply the CPI restriction to administrative instructions unless top-level execution is specifically required — the existing signer and authority checks can authenticate a multisig PDA signing through CPI. If CPI-based administration is intentionally unsupported, document the restriction and prevent on-chain multisig PDAs from being configured as administrators.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

30


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## L-02: Cumulative earned interest excludes AUM gained during value-moving operations

| Severity: Low                                      | Impact: Low             | Likelihood: Medium |
| -------------------------------------------------- | ----------------------- | ------------------ |
| \*\*Files:\*\*<br/>programs/metavault/src/state.rs | \*\*Status:\*\* Pending |                    |


**Description:**

`cumulative_earned_interest_sf` is documented as the vault's raw total interest earned, but it only accumulates `new_aum - prev_aum` as measured inside `charge_fees`. Every value-moving operation resets `prev_aum` to its own post-operation AUM before returning, so any AUM the operation itself created or destroyed is absorbed and never reaches the counter. Rebalance auction spread, donated deposit and withdrawal fees, and obligation-operation deltas are all silently excluded, and the omission compounds over the vault's life. Fee correctness is unaffected — the performance fee is anchored to `last_perf_fee_price`, a separate field that no `prev_aum` write can move.

`prev_aum` serves two purposes that pull against each other. As a flow separator it must be reset after deposits and withdrawals so that user principal is not mistaken for yield, which is why every AUM-touching operation ends with `update_prev_aum_if_not_negative`. As the baseline for `earned_interest` it should only advance once the delta has been booked. Because the reset is unconditional, an operation that both moves principal and changes AUM has its AUM change swallowed along with the principal.

A vault holding $1,000 across 1,000 shares, with the price checkpoint at $1.00:

1. A rebalance swap captures $10 of auction spread; AUM becomes $1,010.
2. `calculate_rebalance_swap` ends with `update_prev_aum_if_not_negative`, setting `prev_aum` to $1,010.
3. The next `charge_fees` computes `earned_interest = 1,010 - 1,010 = 0`, so the counter gains nothing.

31


---


logo: certora logo: Kamino Finance

<watermark>
DRAFT
</watermark>

4. The same call computes `perf_earned_interest = 1,010 - 1,000 = 10` from the untouched checkpoint, so the performance fee on the spread is charged correctly.

The counter is accurate only for a vault whose sole activity between charges is `refresh_vault`, where the delta really is passive yield and price movement.

**Recommendations:**

Book the delta before resetting the baseline. Each value-moving operation already has both sides available — `calculate_rebalance_swap` computes `pre_swap_net_aum` and `post_swap_net_aum` explicitly — so the operation-generated change can be added to `cumulative_earned_interest` prior to calling `update_prev_aum_if_not_negative`.

If the counter is instead intended to track only passive yield accrued between touches, rename it and correct the comment at `state.rs:350` so that integrators do not read it as total vault profit. The local `earned_interest` binding and the `earned_interest` field in the `kmsg_sized!` log carry the same implication and should be renamed with it.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

32


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## L-03: Updating a rolling-cap interval can revive an already expired window

| Severity: Low                              | Impact: Low     | Likelihood: Low |
| ------------------------------------------ | --------------- | --------------- |
| Files:<br/>programs/metavault/src/state.rs | Status: Pending |                 |


**Description:**

Rolling-cap windows are updated lazily on the next deposit or withdrawal. When the administrator changes interval_seconds, the program preserves the old accumulator and anchor without first settling the window under the old interval. A longer new interval can therefore make an already expired window active again, unexpectedly blocking deposits or withdrawals until the extended deadline.

For example, an exhausted one-hour window may already be two hours old but remain stored because no flow triggered its lazy rollover. If the administrator changes its interval to seven days, the next flow evaluates the old anchor against seven days rather than first recognizing that the one-hour window had expired. The stale accumulator remains active and the flow is rejected.

**Recommendations:**

Before applying a new rolling-cap configuration, call tumble_window_if_needed with the current timestamp while the old interval is still installed.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

33


---

<watermark>
DRAFT
</watermark>

logo: certora
logo: k

## L-04: Buy and withdraw can revive a completed rebalance at a mature auction price

| Severity: Low                                                          | Impact: Low     | Likelihood: Medium |
| ---------------------------------------------------------------------- | --------------- | ------------------ |
| Files:<br/>programs/metavault/src/ope<br/>rations/vault\_operations.rs | Status: Pending |                    |


**Description:**

A buy or withdrawal can make an active rebalance logically complete by bringing enough tokens within their targets or by leaving active tokens on only one side of the excess/deficit pair. The operation then skips target recalculation, but it does not persist completion by calling `finish_rebalance_if_completed`. Consequently, a later buy or withdrawal can make the vault logically unbalanced again and resume the same rebalance using its original `rebalance_start_timestamp`, exposing the vault to the later and less favorable portion of the Dutch auction.

After changing token balances, both flows only recalculate targets when `is_vault_rebalanced` returns false. If the balance change makes that predicate true, the vault remains stored as ACTIVE and retains its auction start time. An immediate swap is rejected while the vault is logically complete, but another user flow can restore both an excess and a deficit. Target recalculation then reactivates the auction without resetting its clock, allowing swaps at a price intended for a much later stage of the original rebalance.

Although anyone can subsequently call `finish_rebalance`, users have no direct incentive to append that instruction to their buy or withdrawal, and another flow may arrive first.

**Recommendations:**

At the end of both buy and withdrawal, call `finish_rebalance_if_completed` after handling rebalance targets. This atomically clears the active state and auction timestamps whenever the flow completes the rebalance. Any later user flow may unbalance the vault again, but using Dutch-auction execution would then require an authorized party to start a new rebalance with a fresh auction schedule.

34


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

35


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## L-05: Pre-funding the deterministic shares-mint PDA can block a specific init_vault tx

| Severity: Low                                                    | Impact: Medium  | Likelihood: Low |
| ---------------------------------------------------------------- | --------------- | --------------- |
| Files:<br/>programs/metavault/src/utils<br/>/token\_ops.rs:34-62 | Status: Pending |                 |


**Description:**

`create_mint` creates `shares_mint` (seeds = `[SHARES_SEEDS, vault_state.key()]`) via an unconditional `system_instruction::create_account`, which fails if the destination already holds lamports. An attacker spotting a pending `init_vault` transaction can front-run it with a 1-lamport transfer to the derived address, failing that attempt.

Impact is capped: `vault_state` is a fresh deployer-generated keypair, so the PDA isn't predictable in advance, and retrying with a new keypair sidesteps the grief. The codebase already has the fix elsewhere - `initialize_pda_token_account` (used for `token_vault` PDAs) delegates to klend's `create_pda_account`, which clears any pre-existing balance before calling `create_account`; `create_mint` didn't carry that pattern over.

**Recommendations:**

Have `create_mint` transfer out and clear any pre-existing lamports on `shares_mint` before `create_account`, mirroring `create_pda_account`.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

36


---

<watermark>
DRAFT
</watermark>

logo: certora logo: Klend

## L-06: All-available obligation operations ignore the MetaVault LTV ceiling

<table>
    <tr>
        <th>Severity: Low</th>
        <th>Impact: Low</th>
        <th>Likelihood: Medium</th>
    </tr>
<tr>
        <td>**Files:**<br/>programs/metavault/src/operations/obligation_operations.rs</td>
<td>**Status:** Pending</td>
<td></td>
    </tr>
</table>

**Description:**

When borrow_obligation_liquidity or withdraw_obligation_collateral receives u64::MAX, MetaVault interprets it as AllAvailable. The maximum amount is calculated using only Klend's native limits, without incorporating the obligation's configured max_unhealthy_ltv_fraction_bps.

The Klend-selected amount is executed through CPI, after which MetaVault applies its stricter LTV ceiling. If the amount permitted by Klend exceeds the amount permitted by MetaVault, the post-CPI check fails and the entire transaction rolls back. Consequently, AllAvailable means "maximum permitted by Klend," rather than "maximum permitted by the combined Klend and MetaVault constraints." Automated allocation workflows must calculate an exact smaller amount and retry instead of relying on the all-available sentinel.

The MetaVault ceiling is implemented as a post-operation invariant, but it is not included in the AllAvailable amount calculations. Klend therefore selects an amount up to its own max LTV or reserve capacity even when MetaVault permits less.

**Recommendations:**

For AllAvailable, compute the maximum amount allowed by both Klend and max_unhealthy_ltv_fraction_bps, pass the smaller amount explicitly to the CPI, and retain the post-CPI ceiling check as defense in depth. Use conservative rounding when converting the remaining adjusted-debt or unhealthy-value capacity into token amounts.

**Customer Response:**

Awaiting a response

**Fix Review:**

37


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## L-07: rebase_perf_fee_checkpoint reads prev_aum as if it were current, so a config update while net AUM is negative lowers the performance-fee checkpoint and makes the whole recovery chargeable

| Severity: Low                                                                             | Impact: Medium          | Likelihood: Low |
| ----------------------------------------------------------------------------------------- | ----------------------- | --------------- |
| \*\*Files:\*\*<br/>programs/metavault/src/handlers/handler<br/>\_update\_vault\_config.rs | \*\*Status: Pending\*\* |                 |


**Description:**

rebase_perf_fee_checkpoint sets last_perf_fee_price from prev_aum (vault_operations.rs:741). That is only correct when charge_fees has just written prev_aum on line 723.

When net AUM is negative, charge_fees returns early without charing fees. That early return is deliberate: it keeps last_perf_fee_price at its pre-loss value so the recovery from the loss is not charged a performance fee. handler_update_vault_config runs the rebase anyway on a PerformanceFeeBps update (line 47), and it overwrites last_perf_fee_price with the stale prev_aum, which is the last AUM before the vault went negative. The recovery is then charged. The VaultTokenScope branch (handler_update_vault_config.rs) has the same problem and does not call charge_fees at all.

**Recommendations:**

Skip the rebase while the net AUM is negative. charge_fees returns ShareAmount::ZERO for the negative early return, the first-call early return and an ordinary zero-fee charge alike, so the handler cannot tell from the return value which one happened. It has to compute the net AUM itself, which it can, because vault_scope_prices and obligations_aum are already in scope in both branches.

**Customer Response:**

Awaiting a response

**Fix Review:**

38


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## L-08: No path to harvest farm rewards accrued by vault obligations

<table>
    <tr>
        <th>Severity: Low</th>
        <th>Impact: Medium</th>
        <th>Likelihood: Medium</th>
    </tr>
<tr>
        <td>**Files:**<br/>programs/metavault/src/lib.rs</td>
<td>**Status:** Pending</td>
<td></td>
    </tr>
</table>

**Description:**

MetaVault forwards the kfarms account pair to klend on every obligation operation, so the vault's obligations participate in reserve farms and accrue rewards. It ships no instruction that harvests them. kfarms `HarvestReward` requires the UserState owner to sign, and that owner is base_vault_authority — a PDA only MetaVault can sign for. The rewards are therefore unclaimable by anyone, and because AUM is derived solely from vault token balances and obligation deposits/borrows, nothing in the accounting reveals that value is accruing off-book.

**Attack Scenario**

Not an exploit of current code — a distributional consequence of adding the missing feature later:

* Depositor A holds shares while the vault's obligations accrue farm rewards. AUM excludes those rewards, so A's share price does not reflect them.
* A withdraws, and is paid out at a price that omits every reward their capital helped earn.
* A harvest path is later added and run. The full accumulated accrual arrives in one transaction.
* Free AUM jumps by the whole historical amount; the share price steps up discontinuously.
* Holders at that instant capture the entire back-history, including the portion attributable to A.

**Recommendations:**

Read the kfarms UserState during AUM computation so the share price tracks accrual rather than claim timing, at the cost of extra accounts and a price feed per reward mint, or block reserves with active farms set.

39


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

40


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## L-09: External share burns are never reconciled, permanently stranding a proportion of the vault

| Severity: Low                                      | Impact: Low             | Likelihood: Low |
| -------------------------------------------------- | ----------------------- | --------------- |
| \*\*Files:\*\*<br/>programs/metavault/src/state.rs | \*\*Status:\*\* Pending |                 |


**Description:**

shares_issued is a stored mirror of the share supply, written only by mint_shares and burn_shares. A direct SPL burn reduces the real mint supply without touching it, and nothing ever reconciles the two. The excess is permanently counted in every redemption denominator, so the burned shares' backing is never redistributed to remaining holders and cannot be recovered. The realistic trigger is not malice but an integrating protocol treating vault shares as an ordinary SPL token in a redemption or cleanup flow.

Anyone can burn their shares directly through the SPL token program. shares_issued does not move, so the burned shares become a phantom position that never redeems, and every redemption keeps dividing by the inflated count. The locked fraction is fixed at the moment of the burn and its dollar value scales with the vault forever — burning 20% of supply in a $10,000 vault leaves $2,000 unclaimable, which becomes $20,000 once AUM reaches $100,000.

**Recommendations:**

Add an admin-controlled instruction that clamps shares_issued down to the real supply.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

41


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## L-10: Shares ACL deletion has no corresponding re-enable path, permanently disabling permissioning

| Severity: Low                                                                                                                                                         | Impact: Medium  | Likelihood: Low |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- | --------------- |
| Files:<br/>programs/metavault/src/han<br/>dlers/handler\_delete\_shares<br/>\_config.rs<br/>programs/metavault/src/han<br/>dlers/handler\_init\_vault.rs:10<br/>6-123 | Status: Pending |                 |


**Description:**

delete_shares_config deletes the Token ACL MintConfig and sets shares_permissioned = 0. Its comment frames this as reversible, since the freeze authority stays on base_vault_authority, but the only code path that calls cpi_create_config is handler_init_vault.rs, which cannot be re-run on an initialized vault. No other instruction recreates the MintConfig or restores the mint's frozen default state. Using deletion as an emergency reopen therefore permanently disables permissioning.

**Recommendations:**

Add an admin-authorized re-permissioning instruction that atomically restores the frozen default account state, recreates the Token ACL config, restores metadata keys, and sets shares_permissioned back to 1.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

42


---

logo: certora logo: k

<watermark>
DRAFT
</watermark>

## L-11: Mid-window depositors are charged performance fees on appreciation their capital never earned

| Severity: Low                                                                     | Impact: Low             | Likelihood: Medium |
| --------------------------------------------------------------------------------- | ----------------------- | ------------------ |
| \*\*Files:\*\*<br/>programs/metavault/src/operations/vault\_operations.rs:587-718 | \*\*Status:\*\* Pending |                    |


**Description:**

charge_fees reconstructs the performance-fee checkpoint by multiplying the stored per-share checkpoint price by the *current* share count. A depositor entering mid-window, after price has already risen, is priced fairly for their own shares, but at the next charge their shares get folded into the checkpoint as if they'd existed - at the old, lower price - since the last checkpoint. This understates the baseline and overstates earned interest by exactly that gap, so the fee minted as dilution against all holders includes gains the new depositor's capital never produced. No timing sophistication required - it happens automatically on any mid-window deposit.

**Recommendations:**

Track the fee basis per capital cohort rather than a single global checkpoint, or crystallise the outstanding liability inside deposit() before mint_shares, so an entrant's basis is the price they actually paid.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

43

---

<watermark>
DRAFT
</watermark>

logo: certora

## L-12: Mid-window management-fee minting silently shrinks the performance fee collected at the next

| Severity: Low                                                                     | Impact: Low             | Likelihood: Medium |
| --------------------------------------------------------------------------------- | ----------------------- | ------------------ |
| \*\*Files:\*\*<br/>programs/metavault/src/operations/vault\_operations.rs:587-718 | \*\*Status:\*\* Pending |                    |


**Description:**

The performance checkpoint (`last_perf_fee_price`) is a per-share price. Management fee mints on every `charge_fees` call regardless of the performance cooldown, but if that mint happens on a call where `charge_perf_now` is false, the checkpoint price is left untouched. At the next performance charge, the checkpoint value is reconstructed as old price * current share count - implicitly giving the mid-window management-fee shares the old, pre-dilution basis even though they were minted for free, not purchased. This inflates the baseline and understates earned interest by `(shares minted mid-window) * (old checkpoint price)`, erasing that much yield from the performance-fee basis. Mirror image of the mid-window-deposit finding above: same root cause, opposite direction - here the manager under-collects and existing holders keep an unintended windfall.

Example: AUM grows $100 → $200, users hold 100 shares, management fees mint 10 shares mid-window, performance rate 10%.

|                    | Minted in the same call as the perf charge | Minted earlier, mid-window |
| ------------------ | ------------------------------------------ | -------------------------- |
| Management shares  | $17.27                                     | $17.36                     |
| Performance shares | $10.00                                     | $9.00                      |
| Recipient total    | $27.27                                     | $26.36                     |


44


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

|              | Minted in the same call as the perf charge | Minted earlier, mid-window |
| ------------ | ------------------------------------------ | -------------------------- |
| Users retain | $172.73                                    | $173.64                    |


**Recommendations:**

Rescale `last_perf_fee_price` whenever management-fee shares are minted, keeping the aggregate checkpoint value constant across the supply increase, rounding conservatively.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

45


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## Informational Severity Issues

### I-01: Token account fields named ata are not constrained to be associated token accounts

**Files:**

programs/metavault/src/handlers/handler_deposit.rs:192-197
programs/metavault/src/handlers/handler_deposit.rs:199-204
programs/metavault/src/handlers/handler_withdraw.rs:175-180
programs/metavault/src/handlers/handler_withdraw.rs:188-193
programs/metavault/src/handlers/handler_rebalance_swap.rs:174-179
programs/metavault/src/handlers/handler_rebalance_swap.rs:193-198
programs/metavault/src/handlers/handler_withdraw_pending_fees.rs:83-88
programs/metavault/src/events.rs:4-7
programs/metavault/src/operations/vault_checks.rs:200-208

**Description:**

Several account fields in the instruction contexts are named `*_ata`, implying they must be Associated Token Accounts. None of them carries an `associated_token::` constraint — they are validated on mint, authority, and token program only, so any token account owned by the expected authority is accepted. The naming misleads integrators and reviewers into assuming an ATA-derivation check exists where it does not. Renaming these fields from `ata` to `ta` would make the actual constraint set self-documenting.

**Root Cause**

The constraints applied to these accounts validate mint, authority, and token program only:

```rust
#[account(mut,
    token::mint = token_mint,
    token::authority = user,
    token::token_program = token_program,
)]
pub user_token_ata: Box<InterfaceAccount<'info, TokenAccount>>,
```

46


---

<watermark>
DRAFT
</watermark>

logo: certora

No `associated_token::mint` / `associated_token::authority` constraint exists anywhere in the program — the only ATA derivation in the repo is in the test client (`programs/metavault/src/program_test/instructions.rs`). Passing a non-ATA token account owned by user is valid and intended, so this is a naming issue rather than a missing check: mint + authority + token program are sufficient for the program's logic.

**Recommendations:**

Rename the fields so the name reflects the actual requirement:

*   user_token_ata → user_token_ta
*   user_shares_ata → user_shares_ta
*   user_token_in_ata / user_token_out_ata → user_token_in_ta / user_token_out_ta
*   admin_shares_ata → admin_shares_ta
*   DepositUserAtaBalanceEvent / user_ata_balance → DepositUserTaBalanceEvent / user_ta_balance
*   user_ata_increase → user_ta_increase

Renaming context fields changes the IDL account names, so downstream SDK/client code must be updated in the same change. Alternatively, if ATAs are meant to be enforced, add the associated_token:: constraints instead — but that would break integrators who currently pass non-ATA token accounts.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

47

---

<watermark>
DRAFT
</watermark>

logo: certora logo: Kamino

## I-02: Rebalance target recalculation in obligation operations is unreachable

**Files:**

programs/metavault/src/operations/obligation_operations.rs:29-35
programs/metavault/src/operations/obligation_operations.rs:69-71
programs/metavault/src/operations/obligation_operations.rs:118-120
programs/metavault/src/operations/obligation_operations.rs:165-167
programs/metavault/src/operations/obligation_operations.rs:213-215
programs/metavault/src/operations/obligation_operations.rs:260-262
programs/metavault/src/state.rs:1041-1044

**Description:**

Every obligation operation first requires the vault's rebalance state to be inactive, then conditionally recalculates rebalance targets when `is_vault_rebalanced()` returns false. That condition is unsatisfiable: `is_vault_rebalanced()` always returns true while the rebalance state is inactive. The five recalculation branches are dead code, and their presence implies obligation operations are supported during an active rebalance when they are not.

**Root Cause**

The two checks establish contradictory conditions:

```rust
require_no_active_rebalance(vault)?;

// ...

if !vault.is_vault_rebalanced(timestamp) {
    recalculate_rebalance_targets(vault, vault_scope_prices);
}
```

After `require_no_active_rebalance()` succeeds, `vault.rebalance_state.is_active()` is false, so the first branch of `is_vault_rebalanced()` returns true and its negation is false. Git history shows the recalculation predates the blanket restriction introduced in commit `95760c4` and was not removed when obligation operations were blocked during rebalances.

**Recommendations:**

48


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

Remove the unreachable `is_vault_rebalanced()` and `recalculate_rebalance_targets()` blocks from the four obligation operations and the withdrawal reconciliation path, along with the now-unused import. The reconciliation path's `timestamp` argument becomes unused and can be dropped as well.

If obligation operations are intentionally permitted during active rebalances in the future, restore target recalculation as part of that design change and test the resulting state transitions explicitly.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

49


---

<watermark>
D R A F T
</watermark>

logo: certora logo: k

## I-03: Obligation AUM assumes every lending market uses the same quote currency

**Files:**

programs/metavault/src/handlers/handler_init_obligation.rs:37-56
programs/metavault/src/utils/consts.rs programs/metavault/src/state.rs:1378-1394
programs/metavault/src/utils/obligations.rs:10-41 programs/metavault/src/state.rs:544-565
programs/metavault/src/operations/vault_operations.rs:280-323
programs/metavault/src/state.rs:608-612
programs/metavault/src/handlers/handler_deposit_obligation_collateral.rs:42-49

**Description:**

MetaVault may register up to three Klend obligations, each potentially in a different lending market. The AUM loader adds every obligation's cached deposit and borrow values directly as DollarValue, without loading the corresponding markets, comparing their quote currencies, or normalizing between them. If two obligations' reserves report market values in different numeraires, the resulting AUM is dimensionally invalid: a position expressed in a numerically larger unit inflates the reported AUM and share price, letting a shareholder redeem correctly priced idle assets from another token vault while burning disproportionately few shares.

Registering an obligation or adding a vault token requires the exact vault_admin_authority — a delegated allocation_admin_authority cannot. The administrator is also treated as an allocation authority and can perform the full sequence, so this is a configuration and trust-boundary concern rather than an allocator-only attack.

**Root Cause**

Klend documents reserve and obligation market values as values in the lending market's quote currency. MetaVault reinterprets their fixed-point bits as dollars:

```rust
total_deposited += DollarValue::from_bits(obligation.deposited_value_sf);
total_borrowed +=
DollarValue::from_bits(obligation.borrowed_assets_market_value_sf);
```

50


---


logo: certora logo: Kamino Finance

<watermark>
DRAFT
</watermark>

No account in this path identifies the obligation's lending market, and VaultObligation does not retain it, so neither the markets' quote_currency metadata nor the actual oracle denomination can be compared.

The Scope-configuration equality check on obligation operations does not establish this invariant: Klend can select a fresher Pyth or Switchboard price while the matching Scope configuration is retained, and general AUM loading reads only the refreshed obligation totals. Klend also does not bind quote_currency to the denomination of the configured feeds — relabelling alone causes no manipulation, since the reserve price must actually be expressed in an incompatible unit.

An on-chain scan of the production Klend program found no lending market declaring another non-zero quote currency: of the 38 markets in Kamino's public registry, 25 declare USD and 13 leave quote_currency unset. No alternate-currency instance exists today, but the common-USD invariant is not established by the metadata either.

**Attack Scenario**

Assume fees and withdrawal caps are disabled for clarity:

1. Honest users own 99 of 100 shares; the attacker's single share was acquired for $10. The vault holds $900 of idle USDC and another asset worth $100.
2. The attacker controls or coordinates with the vault administrator, which registers an obligation in a mutable or custom Klend market. The reserve retains the Scope configuration MetaVault expects, but the price Klend selects expresses the deposited asset in another unit. A delegated allocator cannot perform this step.
3. Using the administrator's allocation authority — or an already-authorized delegated allocator — the $100 asset is deposited into the obligation. Klend reports its value as 100,000 units of the other currency.
4. load_obligations_aum treats those units as $100,000, producing a reported net AUM of $100,900 against a true $1,000.
5. The attacker's one-percent balance is quoted at $1,009. The USDC withdrawal is clamped to the $900 available in that token vault, but shares burned come from the corrupted ratio: 900 / 100,900 * 100, or roughly 0.892 shares.

51


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

6. The attacker receives $900 of correctly priced USDC for a $10 contribution, leaving the remaining shareholders with the obligation position and the accounting loss.

Target-deviation bounds and rolling withdrawal caps may restrict or slow the redemption where configured, but establish no common quote currency. Withdrawals are confined to token vaults derived from the same MetaVault state, so a separate MetaVault instance cannot be drained.

**Recommendations:**

Define one canonical quote denomination for each MetaVault and enforce it for every AUM component. At obligation initialization, store and validate the corresponding lending market, and restrict registrations to an approved set of markets. Checking `quote_currency == USD` alone is insufficient, since the field is unset on several active markets and is not tied to oracle semantics.

For stronger protection, validate that every enabled reserve oracle resolves the reserve mint into the vault's canonical quote unit, or calculate obligation AUM from the underlying positions using MetaVault-approved prices. At minimum, compare each refreshed reserve market price against the corresponding MetaVault price within a configured tolerance, and monitor subsequent Klend oracle reconfiguration.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

52


---


logo: certora logo: K

<watermark>
DRAFT
</watermark>

## I-04: Dead xmsg!/dbg_msg! logging macros are unused and unreachable

**Files:**

programs/metavault/src/utils/macros.rs:17-56

**Description:**

Kvault runs a two-tier logging convention: kmsg!/kmsg_sized! (arrform!-backed, stack-allocated, capacity-bounded) for frequent, fixed-shape logs, and xmsg! (heap format!) for rare, admin-only logs with variable/Debug-formatted content that's awkward to capacity-bound.

Metavault inherited both macros but reproduces only the first tier's macro name - for the "rare, variable-content" tier (e.g. handler_update_vault_config.rs:51, the per-field diffs in state.rs, handler_apply_pending_admin.rs) it calls Anchor's msg! directly instead of xmsg!, even though both do the same sol_log(&format!(...)) internally. As a result, xmsg! is only reachable via dbg_msg!, which is itself never called anywhere in Metavault.

**Recommendations:**

Consider removing xmsg! and dbg_msg! from macros.rs to drop the unreachable boilerplate and avoid ambiguity about the intended logging convention, or otherwise use the unused macros where appropriate (e.g. the rare/admin, variable-content msg! call sites noted above).

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

53


---


logo: certora logo: K

<watermark>
DRAFT
</watermark>

## I-05: Asymmetric zero-amount CPI guard between the two token-transfer helpers

**Files:**

programs/metavault/src/utils/token_ops.rs:172-222

**Description:**

transfer_to_token_account skips the transfer_checked CPI entirely when amount.is_zero(), but its counterpart transfer_to_vault has no equivalent guard - it always issues the CPI regardless of amount. Every current call site already prevents a zero amount upstream (explicit require_gt!/require! checks before either helper is reached, e.g. handler_rebalance_swap.rs's require_gt!(amount_in, 0, ...)), so this has no live impact today. It's an inconsistent pattern between two structurally identical helper functions, though, and a future call site that isn't as careful about pre-validating its amount would hit the two helpers differently for the same zero-amount case.

**Recommendations:**

Add the same zero-amount guard to transfer_to_vault for consistency with transfer_to_token_account, or document why the two are allowed to differ.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

54


---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## I-06: Withdraw lacks the same frozen-shares-account UX check as deposit

**Files:**

programs/metavault/src/handlers/handler_withdraw.rs
programs/metavault/src/handlers/handler_deposit.rs

**Description:**

`handler_deposit.rs` has an explicit pre-check - `require!(!ctx.accounts.user_shares_ata.is_frozen(), SharesAccountFrozen)` - with a comment explaining it exists purely to surface an actionable error instead of Token-2022's raw `AccountFrozen` bubbling up from inside the `mint_to` CPI. `handler_withdraw.rs` has no equivalent check before `shares::burn`. Burning from a frozen account is also rejected by Token-2022 itself, so this isn't a security gap - the withdrawal still correctly fails - but a user attempting to withdraw through a frozen (not-yet-thawed) shares account gets a raw, less-actionable Token-2022 program error instead of the friendlier custom error deposit users get for the identical underlying condition.

**Recommendations:**

Add the same `is_frozen()` pre-check to `handler_withdraw.rs` for consistent, actionable error messaging across both entry points.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

55


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## I-07: Repay reverts on reserves that charge an early repay penalty

**Files:**

programs/metavault/src/operations/obligation_operations.rs

**Description:**

`compute_repay_obligation_liquidity_effects` predicts the repay transfer using only klend's `calculate_repay`, omitting the early repay penalty that klend adds on top. Klend transfers `repay_amount + early_repay_penalty`, while MetaVault's post-CPI checks require both the vault outflow and the reserve inflow to equal the penalty-free prediction. Any repay against a reserve that charges the penalty therefore fails the balance assertion and the entire instruction rolls back. The comment at the prediction site already acknowledges the omission.

MetaVault can enter a fixed-term borrow but cannot exit it. The position stays open until the debt term elapses, by which point the debt is past maturity and exposed to liquidation. No funds are lost directly — every attempt reverts atomically — but the obligation cannot be deleveraged or unwound through the vault for the duration of the term.

**Recommendations:**

Mirror klend's penalty in the prediction: derive the early repay penalty from the repay reserve's debt-term configuration and the obligation's `last_borrowed_at_timestamp`, add it to `liquidity_to_repay`, and keep the post-CPI equality checks as they are.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

56


---

<watermark>
D R A F T
</watermark>

logo: certora logo: k

## I-08: Permissionless thaw, enabled by default at vault creation, lets a frozen holder immediately undo the emergency council's freeze

**Files:**

programs/metavault/src/handlers/handler_init_vault.rs:102-123
programs/metavault/src/handlers/handler_freeze_shares_account.rs
programs/metavault/src/handlers/handler_toggle_shares_permissionless.rs

**Description:**

For permissioned vaults, init_vault unconditionally enables permissionless_thaw_enabled on the Token ACL MintConfig. The emergency council can freeze an individual share account as a defensive action, but the frozen holder can immediately call Token ACL's permissionless Thaw and un-freeze themselves, as long as the gating program still approves them - true for any freeze whose reason isn't reflected in the gating program's (typically static, compliance-oriented) criteria, e.g. an incident-response freeze. toggle_shares_permissionless, the only way to disable this, requires the full vault admin, not the council - so the council has no path to make its own freeze stick unilaterally.

**Recommendations:**

Have freeze_shares_account also disable permissionless_thaw_enabled, or grant the emergency council authority over toggle_shares_permissionless.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

57

---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## I-09: Missing signer requirement on vault_state allows front-running of init_vault

**Files:**

programs/metavault/src/handlers/handler_init_vault.rs:234-237

**Description:**

vault_state is constrained only with `#[account(zero)]` and isn't required to sign init_vault. Since the 31,600-byte account must generally be created in a separate prior step, any caller who spots a zeroed, correctly-sized, program-owned account before the legitimate deployer's init_vault lands can submit their own first, with their own admin_authority. Such accounts are trivially discoverable via a plain getProgramAccounts scan - no mempool access needed.

**Recommendations:**

Require vault_state to sign initialization. Clients should also create and initialize the state account atomically in one transaction.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

58


---

<watermark>
DRAFT
</watermark>

logo: certora logo: K

## I-10: init_obligation lacks a rebalance-state guard, breaking in-flight solver transactions

**Files:**

programs/metavault/src/handlers/handler_init_obligation.rs

**Description:**

init_obligation adds a new obligation slot with no rebalance-state check at all. Every AUM-computing instruction (rebalance_swap, start_rebalance, refresh_vault, deposit, withdraw) requires remaining_accounts.len() to exactly match tokens_count + obligations_count. Adding an obligation mid-auction changes that count immediately, so any in-flight solver transaction sized against the old layout reverts until it's updated.

**Recommendations:**

Reject init_obligation during an active rebalance, matching the guard add_vault_token_if_not_present already applies.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

59

---


logo: certora logo: k

<watermark>
DRAFT
</watermark>

## I-11: Withdraw-and-reenter timing around the fee cooldown lets holders dodge the performance fee entirely

**Files:**

programs/metavault/src/operations/vault_operations.rs:587-718
programs/metavault/src/handlers/handler_refresh_vault.rs

**Description:**

The performance fee materialises in a single instant - the first charge_fees call after PERF_FEE_COOLDOWN_SECONDS - against whatever shares are outstanding right then. Since last_perf_fee_charge_timestamp and AUM are both public, a holder can withdraw right before that boundary, then submit [refresh_vault, deposit] right after it, skipping the fee for the whole preceding window while passive LPs bear the full rate. charge_fees already carries a comment acknowledging this general class of evasion.

**Recommendations:**

Accrue the fee on a per-holder or flow-weighted basis, or at minimum charge it on shares burned during any withdrawal inside an open performance window.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

60


---

<watermark>
D R A F T
</watermark>

logo: certora logo: k

## I-12: Vault-side and reserve-side oracle configs can diverge, letting AUM blend two inconsistent price bases

**Files:**

programs/metavault/src/state.rs:719-743
programs/metavault/src/utils/obligations.rs
programs/metavault/src/operations/vault_checks.rs:28-35

**Description:**

Updating VaultTokenScope changes only the vault's own pricing config for a mint's free balance - it has no effect on the Klend reserve's independently-owned oracle config, which drives obligation.deposited_value_sf/borrowed_assets_market_value_sf for the same mint when held as obligation collateral or debt. load_obligations_aum reads those values checking only staleness, never a scope match. has_matching_scope_config is only wired into the four obligation-mutating handlers, never the AUM-aggregation path every deposit, withdraw, refresh, and rebalance goes through - so compute_net_aum can silently blend two unreconciled price bases for the same mint, not just during a migration but for as long as the two configs simply disagree. Users can transact against this inconsistent AUM.

**Recommendations:**

Extend a has_matching_scope_config-style check onto the AUM-aggregation path itself, so any mismatch reverts rather than silently blends. Disallowing a VaultTokenScope change while an active obligation references that mint is a useful additional guard but doesn't cover mismatches introduced from the reserve side alone.

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

61


---

<watermark>
DRAFT
</watermark>

logo: certora logo: Kamino Finance

## I-13: A normative CONTEXT.md spec is cited throughout the code but absent from the repository

**Files:**

programs/metavault/src/state.rs:407,413,1380
programs/metavault/src/operations/vault_checks.rs:424
programs/metavault/src/handlers/handler_init_vault.rs:35,105,125

**Description:**

Several invariants - including the rebalance cooldown, the obligation LTV ceiling, and the setup invariants re-verified post-CPI in `init_vault` (referenced as §5.4, §9) - are justified in comments by citing a CONTEXT.md document with numbered sections. It doesn't exist anywhere in this repository. This isn't isolated to one subsystem - it's cited for rebalance cooldown, obligation LTV ceiling, and the permissioned-shares setup flow alike.

**Recommendations:**

Include CONTEXT.md in the repository, or point the comments at wherever it actually lives, since the code clearly treats it as authoritative

**Customer Response:**

Awaiting a response

**Fix Review:**

Awaiting a response

62


---

<watermark>
DRAFT
</watermark>

logo: certora logo: k

## Disclaimer

Even though we hope this information is helpful, we provide no warranty of any kind, explicit or implied. The contents of this report should not be construed as a complete guarantee that the contract is secure in all dimensions. In no event shall Certora or any of its employees be liable for any claim, damages, or other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the results reported here.

## About Certora

Certora is a Web3 security company that provides industry-leading formal verification tools and smart contract audits. Certora's flagship security product, Certora Prover, is a unique SaaS product that automatically locates even the most rare & hard-to-find bugs on your smart contracts or mathematically proves their absence. The Certora Prover plugs into your standard deployment pipeline and is widely used by developers and security researchers during audits and bug bounties.

Certora also provides architectural design reviews, where researchers analyze system design and trust boundaries early to identify structural risks and reduce complexity before implementation.

Certora conducts off-chain audits covering backend services, APIs, frontend, and mobile applications, focusing on vulnerabilities in authentication, data handling, key management, and wallet-related workflows.

Certora also offers Penetration Testing and Red Teaming to simulate real-world attacks and uncover exploitable weaknesses across infrastructure, applications, and business logic.

In addition, Certora provides operational security (OpSec) assessments, reviewing key management, access controls, and operational processes to strengthen overall security posture.

63

# Context Map

## Engagement Controls

- [scope.json](scope.json) is the unchanged pinned file list and revision identity. It is the source for repository scope.
- [entries.json](entries.json) is the compact inventory of applicable scope, validity, known-status, severity, and background instructions. Each entry cites a published source and location.
- [judging-guidelines.md](judging-guidelines.md) is the complete selected Sherlock guidance, preserved exactly.
- [severity-set.json](severity-set.json) is the complete ordered severity array. [severities.md](severities.md) is the supplied human-readable rendering.
- [deduplication-guidelines.md](deduplication-guidelines.md) extracts the applicable merge rules and links back to the complete guidelines.

## Scope And Qualification

- The audited code is [../Kamino-Finance__metavault-private/](../Kamino-Finance__metavault-private/) at the revision recorded in [scope.json](scope.json).
- [protocol_docs.md](protocol_docs.md) supplies the current-revision architecture, trust model, out-of-scope operational components, accepted design behavior, and build/PoC instructions.
- The exact qualification entries are in [entries.json](entries.json); use source locations there when applying a condition.

## Prior Disclosures

- [known-issues.md](known-issues.md) is the compact lookup index for every Certora finding and every disclosure in protocol documentation §6.
- [Certora report PDF](<Certora - Kamino - Metavault - Draft Report.pdf>) is the unchanged original.
- [Certora report Markdown](<Certora - Kamino - Metavault - Draft Report.md>) is the unchanged supplied conversion used for search and citation.
- [CERTORA-TRIAGE-2026-09-21.md](CERTORA-TRIAGE-2026-09-21.md) is the unchanged customer triage/status statement.

## Querying

Search exact disclosure identifiers or source phrases rather than relying only on summaries:

```sh
rg -n 'M-02|Flow is not blocked|vault_admin_authority' context/
python -m json.tool context/scope.json
python -m json.tool context/entries.json
```

`entries.json` dimensions are `tf` (validity), `scope`, `known`, and `severity`; an empty array marks background or operational guidance. Generated summaries are locators. The cited supplied source retains the complete conditions and exceptions.

** Fixed here:**

- **M-01** — perf-fee checkpoint is now a high-water mark; a drawdown no longer lets the recovery be charged twice
- **M-03** _(partial)_ — `ImmutableOwner` required on permissioned share accounts at thaw + deposit
- **M-04** — per-episode cumulative rebalance loss cap, budget snapshotted at `start_rebalance`
- **M-05** — deposit shares priced against post-fee AUM, so the fee no longer decays with deposit size
- **L-01** — CPI guard now only on `buy`/`sell`/`rebalance_swap`/`refresh_vault`/`finish_rebalance`; admin instructions work through a multisig PDA
- **L-02** — `cumulative_earned_interest` documented as passive-yield-only, not total profit
- **L-03** — rolling-cap window settles under the old interval before a new one is installed
- **L-04** — `buy`/`sell` persist rebalance completion instead of leaving a stale auction resumable
- **L-05** — `create_mint` sweeps pre-funded lamports, so the shares-mint PDA can't be grief-blocked
- **L-07** — checkpoint rebase reads live net AUM and skips when negative; raise-only on rate changes
- **L-12** — fee-share mints conserve the checkpoint's aggregate value instead of inflating the fee base
- **I-04** — dead `xmsg!`/`dbg_msg!` macros deleted
- **I-05** — zero-amount CPI guard made symmetric across both transfer helpers
- **I-10** — `init_obligation` rejected during an active rebalance
- **I-13** — absent-spec citations (`CONTEXT.md`, `§5.4`, `§9`) replaced with inline reasoning

**Already fixed before the review ended (3), by `99f0648`:**

- **I-02** — unreachable rebalance recalculation in obligation ops removed
- **I-03** — obligation AUM no longer reads klend's market values, so mixed quote currencies can't corrupt it
- **I-12** — price-basis gate applied on the AUM aggregation path itself

**Acknowledged:**

- **M-02** — not supported by klend in the future, right now not used by any reserve
- **L-06** — usability, not safety — automation must compute an exact amount
- **L-08** — big change with multiple new accounts, for now we are deferring. adding one later hands the whole back-history to whoever holds shares at that instant
- **L-09** — not something we want to add right now
- **L-10** — needs a re-permissioning instruction, but will not add right now. we will know which vaults needs permissioning or not from the start
- **L-11** — a blended checkpoint isn't conserved across a round trip, halving the next fee. too much code change needed
- **I-01** — non-ATA accounts are intended, will rename in a later refactor
- **I-06** — cosmetic, the withdrawal still fails correctly
- **I-07** — repay reverts on reserves charging an early-repay penalty. No reserve in use sets `debt_term_seconds`. will add support later
 - **I-08** — different from what council freeze does
- **I-09** — retry sidesteps it
- **I-11** — inherent to discrete charging, same state-model change as L-11. fees make this unsustainable
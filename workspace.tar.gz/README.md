# Kamino MetaVault Security Engagement

The audited repository is [Kamino-Finance__metavault-private](Kamino-Finance__metavault-private/), pinned to commit `2fbe82b37c06282d86992a4ce17bc4ffa701f845` on branch `jakub/be-2507-harden-metavault-account-validation-before-bug-bounty`. Only the files enumerated in the [pinned scope manifest](context/scope.json) are in scope.

Authoritative engagement references:

- [Context map](context/README.md) — structured files, supplied sources, and query guidance.
- [Scope and qualification entries](context/entries.json) — scope, trust assumptions, validity conditions, known status, and source locations.
- [Prior disclosures](context/known-issues.md) — all 30 Certora findings, triage status, accepted design decisions, and explicit known issues.
- [Protocol documentation](context/protocol_docs.md) — current-revision design, trust model, operational assumptions, and build/PoC setup.
- [Sherlock judging guidelines](context/judging-guidelines.md) — complete selected validity, scope, severity, and duplication rules.
- [Severity set](context/severity-set.json) — complete ordered severity definitions.
- [Deduplication guidelines](context/deduplication-guidelines.md) — source-referenced merge conditions.

The Certora report concerns the earlier commit `95760c4dc16f52031d9d6971be42a1d4f2e3505b`; it is supplied as prior disclosure, not as the scope manifest for this engagement. Use the current [scope manifest](context/scope.json) for code and revision scope.

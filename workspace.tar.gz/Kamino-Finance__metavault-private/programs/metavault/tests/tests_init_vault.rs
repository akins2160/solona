use kamino_lending::{
    assert_fuzzy_eq,
    program_test::common::{
        math::usdc_decimal_to_u64,
        types::{MSpec, MarketsSpec, MintSpec, RSpec},
    },
    utils::to_sf,
};
use maplit::hashmap;
use metavault::program_test::{
    client::{self, UpdateVaultConfigParams},
    fixtures, VaultDepositorAccounts,
};
use metavault::{program_test::fixtures::setup_markets, utils::consts::INITIAL_DEPOSIT_SIZE};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;

use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_init_vault() {
    let (mut ctx, markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "USDC".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("SOL", 0),
        ])],
    })
    .await;

    let mint = markets.mints.get("USDC").unwrap();
    let timestamp_now = ctx.get_clock().await.unix_timestamp as u64;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_admin_authority,
        ctx.initial_market_owner.pubkey()
    );
    assert_eq!(vault_state.base_vault_authority, vault.base_vault_authority);
    assert_eq!(
        vault_state.base_vault_authority_bump,
        vault.base_vault_authority_bump
    );
    assert_eq!(vault_state.vault_tokens[0].mint, mint.mint);
    assert_eq!(
        vault_state.vault_tokens[0].vault,
        vault.vault_tokens["USDC"].token_vault
    );
    assert_eq!(
        vault_state.vault_tokens[0].token_program,
        mint.token_program
    );
    assert_eq!(vault_state.shares_mint, vault.shares_mint);
    assert_eq!(vault_state.shares_mint_decimals, 6);
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
    assert_eq!(vault_state.performance_fee_bps, 0);
    assert_eq!(vault_state.management_fee_bps, 0);
    assert_eq!(vault_state.last_fee_charge_timestamp, timestamp_now); // the last fee charge timestamp is set as current timestamp
    assert_eq!(
        vault_state.prev_aum_sf,
        to_sf(INITIAL_DEPOSIT_SIZE) / 1_000_000 + 1
    ); // divide by 10^usdc_decimals, +1 from fixed-point rounding
    assert_eq!(vault_state.creation_timestamp, timestamp_now);

    // Verify token vault account was properly initialized
    let token_vault_authority = ctx
        .get_token_account_authority(vault.vault_tokens["USDC"].token_vault)
        .await;
    assert_eq!(token_vault_authority, vault.base_vault_authority);

    let token_vault_mint = ctx
        .get_token_account_mint(vault.vault_tokens["USDC"].token_vault)
        .await;
    assert_eq!(token_vault_mint, mint.mint);
}

#[tokio::test]
async fn test_vault_deposit_withdraw_cycle() {
    let (mut ctx, vault, _owner, _, _) = fixtures::setup_markets_and_reserves_with_yield(1).await;

    let deposit = usdc(100.0);
    // create an user and deposit
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit + 1).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit + 1);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.shares, usdc_decimal_to_u64(100.0) - 1);
    assert_eq!(balances_after.tokens["USDC"], 1);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit + INITIAL_DEPOSIT_SIZE
    );

    // // withdraw from all the reserves
    for token_name in vault.vault_tokens.keys() {
        client::withdraw(
            &mut ctx,
            &vault,
            &depositor,
            vault_state.shares_issued,
            token_name,
        )
        .await;
    }

    let vault_state = vault.state(&mut ctx).await;
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);

    // check user balances
    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.shares, 0);
    assert_eq!(balances_after.tokens["USDC"], deposit);

    // update a vault config fee
    let performance_fee_bps = 100;
    client::update_vault_config(
        &mut ctx,
        &_owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(performance_fee_bps),
    )
    .await;

    // do another deposit
    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], usdc(0.0));
    let vault_state = vault.state(&mut ctx).await;

    // withdraw all reserves
    for token_name in vault.vault_tokens.keys() {
        client::withdraw(
            &mut ctx,
            &vault,
            &depositor,
            vault_state.shares_issued,
            token_name,
        )
        .await;
    }

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
}

#[tokio::test]
async fn test_vault_with_max_tokens_deposit_withdraw() {
    let token_specs: Vec<(&str, u8, f64)> = vec![
        ("USDC", 6, 1.0),
        ("SOL", 9, 100.0),
        ("ETH", 8, 2000.0),
        ("BTC", 8, 50000.0),
        ("JTO", 6, 2.0),
        ("PYTH", 6, 0.5),
        ("JUP", 6, 1.5),
        ("RAY", 6, 3.0),
        ("ORCA", 6, 0.8),
        ("BONK", 5, 0.1),
    ];

    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: token_specs
            .iter()
            .map(|(name, dec, px)| (name.to_string(), MintSpec::spl(*dec, *px)))
            .collect(),
        markets: vec![MSpec::new(
            token_specs
                .iter()
                .map(|(name, _, _)| RSpec::new(name, 0))
                .collect(),
        )],
    })
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state
            .vault_tokens
            .iter()
            .filter(|t| t.is_valid())
            .count(),
        10
    );

    // Deposit USDC - AUM computation iterates over all 10 token scope feeds
    let deposit = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // Withdraw all shares - also iterates over all 10 token scope feeds
    client::withdraw(&mut ctx, &vault, &depositor, balances_after.shares, "USDC").await;

    let balances_final = depositor.balances(&mut ctx).await;
    assert_eq!(balances_final.shares, 0);
    assert_fuzzy_eq!(balances_final.tokens["USDC"], deposit, 1);
}

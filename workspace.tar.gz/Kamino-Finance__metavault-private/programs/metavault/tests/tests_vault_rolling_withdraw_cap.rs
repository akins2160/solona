//! BPF integration tests for the rolling withdraw cap (tumbling-window USD rate-limit).

use ::metavault::program_test::{VaultAccounts, VaultDepositorAccounts};
use kamino_lending::{
    program_test::common::{math::usdc_decimal_to_u64, types::TestContext},
    utils::to_sf,
};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

const HOUR: u64 = 3600;

/// Deposits into the vault and returns the depositor accounts holding the resulting shares.
async fn deposit_and_get_depositor(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    deposit_usdc: u64,
) -> VaultDepositorAccounts {
    let depositor = VaultDepositorAccounts::new(ctx, vault, "USDC", deposit_usdc).await;
    client::deposit(ctx, vault, &depositor, "USDC", deposit_usdc).await;
    depositor
}

#[tokio::test]
async fn test_disabled_default_allows_any_withdraw() {
    let (mut ctx, vault, _owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let state = vault.state(&mut ctx).await;
    assert!(state.rolling_withdraw_cap.is_disabled());

    let depositor = deposit_and_get_depositor(&mut ctx, &vault, usdc(10_000.0)).await;
    let shares = depositor.balances(&mut ctx).await.shares;
    // No cap → full withdraw must succeed.
    client::withdraw(&mut ctx, &vault, &depositor, shares, "USDC").await;
}

#[tokio::test]
async fn test_cap_exhausted_blocks_further_withdraws() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let depositor = deposit_and_get_depositor(&mut ctx, &vault, usdc(3000.0)).await;
    let shares = depositor.balances(&mut ctx).await.shares;
    let one_dollar_of_shares = shares / 3000;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingWithdrawCap {
            max_usd_sf: to_sf(1000u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    // Withdraw shares worth ~$600 then ~$400 — both pass within the $1000 window.
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        600 * one_dollar_of_shares,
        "USDC",
    )
    .await;
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        400 * one_dollar_of_shares,
        "USDC",
    )
    .await;

    // Even one more $1 worth of shares must fail.
    let res = client::try_withdraw(
        &mut ctx,
        &vault,
        &depositor,
        one_dollar_of_shares,
        "USDC",
        0,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RollingWithdrawCapExceeded, 1)
    );
}

#[tokio::test]
async fn test_clock_warp_past_interval_resets_capacity() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let depositor = deposit_and_get_depositor(&mut ctx, &vault, usdc(3000.0)).await;
    let shares = depositor.balances(&mut ctx).await.shares;
    let one_dollar_of_shares = shares / 3000;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingWithdrawCap {
            max_usd_sf: to_sf(1000u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    // Saturate the cap.
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        1000 * one_dollar_of_shares,
        "USDC",
    )
    .await;

    // One more share fails immediately.
    let res = client::try_withdraw(
        &mut ctx,
        &vault,
        &depositor,
        one_dollar_of_shares,
        "USDC",
        0,
    )
    .await;
    assert!(res.is_err());

    // Advance past the interval — the next withdraw tumbles the window and succeeds.
    ctx.fast_forward_seconds(HOUR + 1).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        500 * one_dollar_of_shares,
        "USDC",
    )
    .await;
}

/// Cross-cap independence: saturating the deposit cap must NOT bump the withdraw accumulator.
/// This is the spec-level "gross-flow / no offsetting" guarantee.
#[tokio::test]
async fn test_deposit_cap_does_not_affect_withdraw_cap() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    // Set both caps so the test exercises both accumulators.
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(500u64),
            interval_seconds: HOUR,
        },
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingWithdrawCap {
            max_usd_sf: to_sf(500u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    let depositor = deposit_and_get_depositor(&mut ctx, &vault, usdc(500.0)).await;
    let shares = depositor.balances(&mut ctx).await.shares;

    // After this deposit: deposit_cap accumulator is at ~$500. Withdraw accumulator stays at $0.
    let state = vault.state(&mut ctx).await;
    assert_eq!(state.rolling_withdraw_cap.accumulated_usd_sf, 0);
    assert!(state.rolling_deposit_cap.accumulated_usd_sf > 0);

    // A withdraw of all shares (worth ~$500) must succeed — withdraw cap is independently full.
    client::withdraw(&mut ctx, &vault, &depositor, shares, "USDC").await;
}

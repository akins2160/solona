use kamino_lending::program_test::common::types::{MSpec, MarketsSpec, MintSpec, RSpec};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{
            self, start_rebalance, try_update_vault_config, update_vault_config,
            UpdateVaultConfigParams,
        },
        fixtures::{setup_markets, setup_markets_with_weights},
        VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;

#[tokio::test]
async fn test_update_token_weights_success() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
            RSpec::new("SOL", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();
    // Update token weights to 30%, 50%, 20% ratio (3:5:2)
    let weights = vec![3u64, 5u64, 2u64];
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    // Verify weights were set correctly
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].weight, 3);
    assert_eq!(vault_state.vault_tokens[1].weight, 5);
    assert_eq!(vault_state.vault_tokens[2].weight, 2);
}

#[tokio::test]
async fn test_update_token_weights_invalid_sum() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();

    // Try to update with invalid sum (zero sum)
    let weights = vec![0u64, 0u64];
    let result = try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidWeightsSum, 1)
    );
}

#[tokio::test]
async fn test_update_token_weights_array_smaller() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();

    // Try to update with fewer weights than tokens (array too small)
    let weights = vec![1u64];
    let result = try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TokenArrayLengthMismatch, 1)
    );
}

#[tokio::test]
async fn test_update_token_weights_array_bigger() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();

    // Try to update with more weights than tokens (array too big) - must fail
    let weights = vec![3u64, 4u64, 5u64];
    let result = try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TokenArrayLengthMismatch, 1)
    );
}

#[tokio::test]
async fn test_update_token_weights_single_token() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![RSpec::new("USDC", 0)])],
    })
    .await;

    // Update weight for single token (100%)
    let weights = vec![10000];
    let owner = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    // Verify weight was set correctly
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].weight, 10000);
}

#[tokio::test]
async fn test_update_token_weights_equal_distribution() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
            "DAI".to_string() => MintSpec::spl(6, 1.0),
            "BUSD".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
            RSpec::new("DAI", 0),
            RSpec::new("BUSD", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();
    // Update weights to equal distribution (25% each)
    let weights = vec![2500, 2500, 2500, 2500];
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    // Verify all weights are equal
    let vault_state = vault.state(&mut ctx).await;
    for i in 0..4 {
        assert_eq!(vault_state.vault_tokens[i].weight, 2500);
    }
}

#[tokio::test]
async fn test_update_token_weights_zero_weights() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
            RSpec::new("SOL", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();

    // Update weights with some zero values
    let weights = vec![0, 10000, 0];
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights.clone()),
    )
    .await;

    // Verify weights match what was set
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].weight, 0);
    assert_eq!(vault_state.vault_tokens[1].weight, 10000);
    assert_eq!(vault_state.vault_tokens[2].weight, 0);
}

#[tokio::test]
async fn test_update_token_weights_rejected_during_active_rebalance() {
    let weights = vec![2u64, 3u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("USDT", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;

    // Start rebalance
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Verify rebalance is active
    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.rebalance.is_unfinished());

    // Try to update weights during active rebalance - should fail
    let result = try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1, 1]),
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::CannotUpdateWeightsDuringRebalance, 1)
    );
}

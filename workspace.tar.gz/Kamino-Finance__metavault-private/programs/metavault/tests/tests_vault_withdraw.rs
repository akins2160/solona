use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{assert_fuzzy_eq, program_test::common::math::usdc_decimal_to_u64};
use metavault::{
    program_test::{client, fixtures},
    utils::consts::INITIAL_DEPOSIT_SIZE,
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_vault_withdraw_with_multiple_deposits() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(15.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = usdc(10.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before.tokens["USDC"] - deposit
    );
    assert_eq!(balances_after.shares, deposit - 1); // as it has 6 decimals

    let second_deposit = topup - deposit;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", second_deposit).await;
    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, topup - 2);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        topup + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state.shares_issued, topup - 2 + INITIAL_DEPOSIT_SIZE);

    let withdraw = usdc(4.0);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_first_withdraw.shares, topup - 2 - withdraw);
    assert_eq!(balances_after_first_withdraw.tokens["USDC"], withdraw);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        topup + INITIAL_DEPOSIT_SIZE - withdraw
    );
    assert_eq!(
        vault_state.shares_issued,
        topup - 2 - withdraw + INITIAL_DEPOSIT_SIZE
    );

    // withdraw 1$ more which is everything that is available
    let second_withdraw = usdc(1.0);
    client::withdraw(&mut ctx, &vault, &depositor, second_withdraw, "USDC").await;

    let balances_after_second_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after_second_withdraw.shares,
        balances_after_first_withdraw.shares - second_withdraw
    );
    assert_eq!(
        balances_after_second_withdraw.tokens["USDC"],
        withdraw + second_withdraw
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        topup - withdraw - second_withdraw + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(
        vault_state.shares_issued,
        topup - 2 - withdraw - second_withdraw + INITIAL_DEPOSIT_SIZE
    );

    // withdraw the rest
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        balances_after_second_withdraw.shares,
        "USDC",
    )
    .await;

    let balances_after_final_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_final_withdraw.shares, 0);
    assert_eq!(balances_after_final_withdraw.tokens["USDC"], topup - 1);

    let vault_state = vault.state(&mut ctx).await;
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
}

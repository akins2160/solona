use borsh::BorshDeserialize;
use kamino_lending::{
    fraction::Fraction,
    program_test::common::{
        math::usdc_decimal_to_u64,
        setup::KP,
        types::{MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    },
    send_transaction,
};
use maplit::hashmap;
use metavault::{
    program_test::{
        client::{self, get_ordered_scope_and_obligation_accounts},
        fixtures::{
            setup_markets_and_reserves_with_dependencies,
            setup_markets_with_weights_and_dependencies, ProgramDependency,
        },
        instructions,
        test_cpi_caller::TEST_CPI_CALLER_ID,
        VaultAccounts, VaultDepositorAccounts,
    },
    ExchangeRateWithDecimals, GlobalConfig,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    account::AccountSharedData,
    instruction::{AccountMeta, Instruction},
    signature::{Keypair, Signer},
};
use usdc_decimal_to_u64 as usdc;

async fn expected_usdc_free_aum_bits(ctx: &mut TestContext, vault: &VaultAccounts) -> u128 {
    let state = vault.state(ctx).await;
    (Fraction::from(state.vault_tokens[0].token_available) / Fraction::from(1_000_000u64)).to_bits()
}

async fn call_readonly_via_cpi<T: BorshDeserialize>(
    ctx: &mut TestContext,
    payer: &KP,
    inner_ix: Instruction,
) -> Result<std::result::Result<T, String>, BanksClientError> {
    call_readonly_via_cpi_with_prelude(ctx, payer, vec![], inner_ix).await
}

async fn call_readonly_via_cpi_with_prelude<T: BorshDeserialize>(
    ctx: &mut TestContext,
    payer: &KP,
    mut prelude: Vec<Instruction>,
    inner_ix: Instruction,
) -> Result<std::result::Result<T, String>, BanksClientError> {
    let return_data_account = Keypair::new();
    let account = AccountSharedData::new(1_000_000, 1024, &TEST_CPI_CALLER_ID);
    ctx.set_account(&return_data_account.pubkey(), account);

    let mut accounts = Vec::with_capacity(inner_ix.accounts.len() + 2);
    accounts.push(AccountMeta::new_readonly(metavault::ID, false));
    accounts.push(AccountMeta::new(return_data_account.pubkey(), false));
    accounts.extend(inner_ix.accounts);

    let mut data = Vec::with_capacity(inner_ix.data.len() + 1);
    data.push(1);
    data.extend(inner_ix.data);

    let cpi_ix = Instruction {
        program_id: TEST_CPI_CALLER_ID,
        accounts,
        data,
    };
    prelude.push(cpi_ix);
    let tx = ctx.create_transaction_with_payer(prelude, payer).await;
    send_transaction!(ctx, tx)?;

    let account = ctx
        .get_account(return_data_account.pubkey())
        .await?
        .expect("return data account must exist");
    let len = u32::from_le_bytes(account.data[..4].try_into().unwrap()) as usize;
    Ok(std::result::Result::<T, String>::try_from_slice(&account.data[4..4 + len]).unwrap())
}

async fn readonly_aum(
    ctx: &mut TestContext,
    payer: &KP,
    vault: &VaultAccounts,
) -> std::result::Result<u128, String> {
    let accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let ix = instructions::aum_ix(metavault::ID, vault, accounts);
    call_readonly_via_cpi(ctx, payer, ix).await.unwrap()
}

async fn readonly_exchange_rate(
    ctx: &mut TestContext,
    payer: &KP,
    vault: &VaultAccounts,
) -> std::result::Result<ExchangeRateWithDecimals, String> {
    let accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let ix = instructions::exchange_rate_ix(
        metavault::ID,
        vault,
        vault.vault_tokens["USDC"].token_mint,
        accounts,
    );
    call_readonly_via_cpi(ctx, payer, ix).await.unwrap()
}

fn obligation_backed_aum_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

#[tokio::test]
async fn tests_readonly_aum_returns_initial_and_deposited_net_aum() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves_with_dependencies(
        1,
        Some(vec![ProgramDependency::TestCpiCaller]),
        None,
    )
    .await;

    let direct_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::aum(&mut ctx, &owner, &vault, direct_accounts).await;
    send_transaction!(ctx, tx).unwrap();

    let initial = readonly_aum(&mut ctx, &owner, &vault).await.unwrap();
    assert_eq!(initial, expected_usdc_free_aum_bits(&mut ctx, &vault).await);

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(10.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0)).await;

    let deposited = readonly_aum(&mut ctx, &owner, &vault).await.unwrap();
    assert_eq!(
        deposited,
        expected_usdc_free_aum_bits(&mut ctx, &vault).await
    );
}

#[tokio::test]
async fn tests_readonly_exchange_rate_returns_expected_net_rate_with_withdrawal_fee() {
    let global_config = GlobalConfig {
        withdrawal_fee_bps: 1_000,
        ..Default::default()
    };
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves_with_dependencies(
        1,
        Some(vec![ProgramDependency::TestCpiCaller]),
        Some(global_config),
    )
    .await;

    let direct_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::exchange_rate(
        &mut ctx,
        &owner,
        &vault,
        vault.vault_tokens["USDC"].token_mint,
        direct_accounts,
    )
    .await;
    send_transaction!(ctx, tx).unwrap();

    let quote = readonly_exchange_rate(&mut ctx, &owner, &vault)
        .await
        .unwrap();
    // Redeeming the full 1_000-share supply yields 999 USDC lamports gross; the 10% fee rounds up to
    // 100 -> 899 net. Scaled to one whole share (10^6 share lamports): 899 * 10^6 / 1_000 = 899_000
    // token lamports per whole share (i.e. 0.899 whole USDC once divided by 10^token_mint_decimals).
    let expected_sf = Fraction::from(899_000u64).to_bits();
    assert_eq!(quote.exchange_rate_sf, expected_sf);
    assert_eq!(quote.token_mint_decimals, 6);

    let vault_before = vault.state(&mut ctx).await;
    let _ = readonly_exchange_rate(&mut ctx, &owner, &vault)
        .await
        .unwrap();
    let vault_after = vault.state(&mut ctx).await;
    assert_eq!(vault_after.shares_issued, vault_before.shares_issued);
    assert_eq!(
        vault_after.vault_tokens[0].token_available,
        vault_before.vault_tokens[0].token_available
    );
    assert_eq!(vault_after.prev_aum_sf, vault_before.prev_aum_sf);
}

#[tokio::test]
async fn tests_readonly_aum_includes_refreshed_obligation_value() {
    let (mut ctx, mkts, vault) = setup_markets_with_weights_and_dependencies(
        &obligation_backed_aum_spec(),
        vec![5u64, 5u64],
        Some(vec![ProgramDependency::TestCpiCaller]),
    )
    .await;
    let owner = ctx.initial_market_owner.clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;

    let before = readonly_aum(&mut ctx, &owner, &vault).await.unwrap();
    let sol_balance_before = vault.balances(&mut ctx).await.token_vaults["SOL"];
    let market = &mkts.markets[0].primary_market;
    let reserve = &mkts.markets[0].reserves["SOL"];
    client::init_obligation(&mut ctx, &owner, &vault, market, 0).await;
    let obligation =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &owner,
        &vault,
        market,
        reserve,
        obligation,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let stale_result = readonly_aum(&mut ctx, &owner, &vault).await;
    assert!(stale_result.unwrap_err().contains("ObligationStale"));

    let accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let ix = instructions::aum_ix(metavault::ID, &vault, accounts);
    let after = call_readonly_via_cpi_with_prelude::<u128>(
        &mut ctx,
        &owner,
        vec![
            instructions::build_klend_refresh_reserve_ix(reserve),
            instructions::build_klend_refresh_obligation_ix(
                obligation,
                market.market.pubkey(),
                &[reserve],
                &[],
            ),
        ],
        ix,
    )
    .await
    .unwrap()
    .unwrap();
    let sol_balance_after = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert_eq!(after, before);
    assert_eq!(sol_balance_after, sol_balance_before - 5_000_000_000);
}

#[tokio::test]
async fn tests_readonly_malformed_remaining_accounts_returns_inner_err_and_keeps_state() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves_with_dependencies(
        1,
        Some(vec![ProgramDependency::TestCpiCaller]),
        None,
    )
    .await;
    let vault_before = vault.state(&mut ctx).await;

    let ix = instructions::aum_ix(metavault::ID, &vault, vec![]);
    let result = call_readonly_via_cpi::<u128>(&mut ctx, &owner, ix)
        .await
        .unwrap();

    // No remaining accounts at all: the scope-price segment comes first and runs dry first.
    assert!(result.unwrap_err().contains("NotEnoughAccountKeys"));
    let vault_after = vault.state(&mut ctx).await;
    assert_eq!(vault_after.shares_issued, vault_before.shares_issued);
    assert_eq!(
        vault_after.vault_tokens[0].token_available,
        vault_before.vault_tokens[0].token_available
    );
    assert_eq!(vault_after.prev_aum_sf, vault_before.prev_aum_sf);
}

use kamino_lending::{
    assert_fuzzy_eq,
    fraction::{Fraction, FractionExtra},
    program_test::common::{
        setup::{funded_new_kp, kp, KP},
        token_operations,
        types::{MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    },
    send_transaction,
    utils::{to_sf, FULL_BPS},
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    order::DepositOrder,
    program_test::{
        client::{
            add_priced_spl_token, assert_vault_covers_locked, available_of, cancel_deposit_order,
            deposit, deposit_order_pda, deposit_order_state, fill_deposit_order,
            get_ordered_scope_accounts, init_obligation, lamports_of, locked_amount_of,
            locked_total, open_and_settle_deposit_order, open_deposit_order,
            order_rebalance_target, rebalance_swap, settle_deposit_order, skip, start_rebalance,
            token_holder, try_borrow_obligation_liquidity, try_cancel_deposit_order,
            try_cancel_deposit_order_raw, try_deposit_obligation_collateral,
            try_deposit_order_state, try_fill_deposit_order,
            try_fill_deposit_order_with_krfq_marker, try_open_and_settle_deposit_order,
            try_open_and_settle_deposit_order_raw,
            try_open_and_settle_deposit_order_with_min_shares, try_open_deposit_order,
            try_settle_deposit_order, try_settle_deposit_order_raw, update_vault_config,
            usdc_holder, withdraw, KrfqMarker, RequestedOut, UpdateVaultConfigParams,
        },
        fixtures::{self, set_global_config, setup_markets_with_weights},
        instructions::{self, OrderTokenAccounts},
        setup, VaultAccounts, VaultDepositorAccounts,
    },
    utils::{consts::MAX_FEE_LAMPORTS, pda},
    GlobalConfig, KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    instruction::InstructionError, native_token::LAMPORTS_PER_SOL, pubkey::Pubkey, signer::Signer,
    system_instruction::SystemError, transaction::TransactionError,
};

const USDC: u64 = 1_000_000;
const SOL: u64 = 1_000_000_000;
const ETH: u64 = 100_000_000;
const HOUR: u64 = 3600;

#[tokio::test]
async fn test_open_at_the_vaults_weights_absorbs_everything_like_a_deposit() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 50 * USDC, "SOL".to_string() => SOL / 2 },
    )
    .await;
    let shares_before = vault.balances(&mut ctx).await.shares_supply;

    // $50 + $50 on a $2000 50/50 vault is already at its weights, so no fill can improve it: the
    // auction is over before it starts and a settle composed behind the open takes it whole.
    let order = open_and_settle_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 50 * USDC), ("SOL", SOL / 2)],
        HOUR,
    )
    .await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());

    let order_shares = depositor.balances(&mut ctx).await.shares;
    deposit(&mut ctx, &vault, &lp, "USDC", 100 * USDC).await;
    let deposit_shares =
        vault.balances(&mut ctx).await.shares_supply - shares_before - order_shares;
    assert_fuzzy_eq!(order_shares, deposit_shares, 10);
    assert_vault_covers_locked(&mut ctx, &vault).await;
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
}

#[tokio::test]
async fn test_a_basket_balanced_at_open_stays_settleable_whatever_the_prices_do() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 50 * USDC, "SOL".to_string() => SOL / 2 },
    )
    .await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);

    // At the vault's weights at open, the auction is over there and then: a later SOL move that
    // would make the basket fillable again cannot reopen it, and anyone may settle.
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 50 * USDC), ("SOL", SOL / 2)],
        HOUR,
    )
    .await;
    assert_eq!(
        deposit_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 110.0, 110.0).await;
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_open_fill_settle_lifecycle() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let shares_before = vault.balances(&mut ctx).await.shares_supply;

    // Open locks the whole basket and auctions it. Nothing is absorbed and no share is minted
    // until it is settled, which cannot happen while a fill could still improve the basket.
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    let state = deposit_order_state(&mut ctx, order).await;
    assert_eq!(state.base.owner, depositor.owner.pubkey());
    assert_eq!(state.base.id, 0);
    assert_ne!(state.base.rebalance.end_timestamp, 0);
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_eq!(depositor.balances(&mut ctx).await.shares, 0);
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 2000 * USDC);
    assert_eq!(vault_balances.token_vaults["SOL"], 10 * SOL);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // $1000 at the vault's weights is 500 USDC + 5 SOL.
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "USDC").await,
        500 * USDC
    );
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        5 * SOL
    );

    // Fill: a solver sells 5 SOL for the 500 USDC the order wants to shed. Nothing the vault
    // itself owns moves.
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        5 * SOL,
        RequestedOut::AtCurve,
    )
    .await;
    let solver_balances = solver.balances(&mut ctx).await;
    assert_eq!(solver_balances.tokens["USDC"], 500 * USDC);
    assert_eq!(solver_balances.tokens["SOL"], 5 * SOL);
    let state = deposit_order_state(&mut ctx, order).await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 500 * USDC);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 5 * SOL);
    assert_eq!(
        state.base.rebalance.end_timestamp, 0,
        "the auction completed"
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 500 * USDC);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 5 * SOL);
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 1500 * USDC);
    assert_eq!(vault_balances.token_vaults["SOL"], 15 * SOL);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_eq!(available_of(&mut ctx, &vault, "SOL").await, 10 * SOL);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // Settle by a stranger: a basket at the vault's weights is admitted whole, the shares go to
    // the owner and the account is gone, its rent with it.
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let owner_lamports_before = lamports_of(&mut ctx, depositor.owner.pubkey()).await;
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert!(lamports_of(&mut ctx, depositor.owner.pubkey()).await > owner_lamports_before);
    let shares_total = depositor.balances(&mut ctx).await.shares;
    assert_fuzzy_eq!(shares_total, shares_before / 2, 1000); // $1000 on $2000
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1500 * USDC);
    assert_eq!(available_of(&mut ctx, &vault, "SOL").await, 15 * SOL);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_fill_in_parts() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    let state = deposit_order_state(&mut ctx, order).await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 900 * USDC);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, SOL);
    assert_ne!(state.base.rebalance.end_timestamp, 0, "still 4 SOL short");

    // An oversized input is clamped to the remaining deficit.
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        5 * SOL,
        RequestedOut::AtCurve,
    )
    .await;
    let state = deposit_order_state(&mut ctx, order).await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 500 * USDC);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 5 * SOL);
    assert_eq!(state.base.rebalance.end_timestamp, 0);
    assert_eq!(solver.balances(&mut ctx).await.tokens["SOL"], 5 * SOL);
}

#[tokio::test]
async fn test_settle_absorbs_the_admissible_part_of_each_token_and_returns_the_rest() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 1000 * USDC, "SOL".to_string() => 2 * SOL },
    )
    .await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        3,
        &[("USDC", 1000 * USDC), ("SOL", 2 * SOL)],
        HOUR,
    )
    .await;
    assert_eq!(deposit_order_state(&mut ctx, order).await.base.id, 3);
    skip(&mut ctx, &vault, HOUR + 1).await;

    // $1000 USDC + $200 SOL on a $2000 vault: SOL fits whole, USDC is cut to the 60% bound of the
    // vault as it will be with both in: (0.6 * 2200 - 1000) / 0.4 = 800. The 200 USDC the bound
    // refuses go straight back to the owner.
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.tokens["USDC"], 200 * USDC);
    assert_eq!(balances.tokens["SOL"], 0);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1800 * USDC);
    assert_eq!(available_of(&mut ctx, &vault, "SOL").await, 12 * SOL);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_fill_rejections() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    // The order sheds USDC; buying USDC from it is the wrong direction.
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );

    // Asking for more than the curve pays.
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::Exact(101 * USDC),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );

    // Dust input.
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        0,
        RequestedOut::Exact(0),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAmountsZero, 1)
    );

    // Past the window.
    skip(&mut ctx, &vault, HOUR + 1).await;
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceNotInProgress, 1)
    );
}

#[tokio::test]
async fn test_order_auction_curve_and_loss_cap() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;

    // The vault pays 5% over oracle for the SOL it buys, throughout: a fill hands the basket SOL
    // and takes USDC, so it is SOL's buying curve that prices it.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            vault.vault_tokens["SOL"].token_mint,
            10_000,
            10_000,
            10_500,
            10_500,
        ),
    )
    .await;

    // An order capping its loss per fill at 1% will not pay that curve.
    try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
        100,
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceSwapExceedsMaxLoss, 1)
    );

    // The same curve under a 10% cap, for a smaller basket.
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 500 * USDC)],
        HOUR,
        1000,
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 500 * USDC);

    // The curve pays 262.5 USDC for the 2.5 SOL deficit, but the order only has 250 to shed.
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        25 * SOL / 10,
        RequestedOut::Exact(255 * USDC),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RequestedOutExceedsExcess, 1)
    );

    // The solver gets 105 USDC per SOL.
    let usdc_before = solver.balances(&mut ctx).await.tokens["USDC"];
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    let usdc_after = solver.balances(&mut ctx).await.tokens["USDC"];
    assert_fuzzy_eq!(usdc_after - usdc_before, 105 * USDC, 2);
}

#[tokio::test]
async fn test_open_validation() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    async fn open(
        ctx: &mut TestContext,
        vault: &VaultAccounts,
        depositor: &VaultDepositorAccounts,
        id: u8,
        amount: u64,
        duration: u64,
    ) -> Result<(), BanksClientError> {
        try_open_deposit_order(
            ctx,
            vault,
            depositor,
            id,
            &[("USDC", amount)],
            duration,
            u64::from(FULL_BPS),
            u64::from(FULL_BPS),
        )
        .await
    }

    let res = open(&mut ctx, &vault, &depositor, 10, 1000 * USDC, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidOrderId, 1)
    );
    for duration in [0, 299, 86_401] {
        let res = open(&mut ctx, &vault, &depositor, 0, 1000 * USDC, duration).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidOrderAuctionDuration, 1)
        );
    }
    let res = open(&mut ctx, &vault, &depositor, 0, 0, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAmountsZero, 1)
    );
    let res = try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
        u64::from(FULL_BPS) + 1,
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSValueTooBig, 1)
    );
    let res = try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS) + 1,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSValueTooBig, 1)
    );

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::OrderMinOpenUsd(to_sf(1001u64)),
    )
    .await;
    let res = open(&mut ctx, &vault, &depositor, 0, 1000 * USDC, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderBelowMinValue, 1)
    );
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::OrderMinOpenUsd(0),
    )
    .await;

    // Blocking the plain deposit leaves the open alone (nothing enters the vault before the
    // settle, which it does stop); the owner can always take the basket back.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    open(&mut ctx, &vault, &depositor, 0, 1000 * USDC, HOUR)
        .await
        .unwrap();
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    skip(&mut ctx, &vault, HOUR + 1).await;
    let res = try_settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultDepositsBlocked, 1)
    );
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(false),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositOrderCreationEnabled(false),
    )
    .await;
    let res = open(&mut ctx, &vault, &depositor, 0, 1000 * USDC, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositOrderCreationDisabled, 1)
    );
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
    )
    .await;

    // Nothing above left an order behind.
    assert!(try_deposit_order_state(
        &mut ctx,
        deposit_order_pda(&vault, &depositor.owner.pubkey(), 0)
    )
    .await
    .is_none());
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    // `FULL_BPS` (no limit) is the highest either limit may be:
    try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn test_open_rejects_wrong_accounts() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let usdc = vault.vault_tokens["USDC"].clone();
    let sol = vault.vault_tokens["SOL"].clone();
    let accounts_of = |token, owner_ata| OrderTokenAccounts { token, owner_ata };

    // One amount per enabled token, no more, no less.
    for amounts in [vec![1000 * USDC], vec![1000 * USDC, 0, 0]] {
        let res = try_open_and_settle_deposit_order_raw(
            &mut ctx,
            &vault,
            &depositor,
            0,
            &[accounts_of(usdc.clone(), depositor.token_atas["USDC"])],
            amounts,
            HOUR,
            u64::from(FULL_BPS),
            u64::from(FULL_BPS),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::TokenArrayLengthMismatch, 1)
        );
    }

    // A token's accounts naming another token.
    let res = try_open_and_settle_deposit_order_raw(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[accounts_of(sol.clone(), depositor.token_atas["USDC"])],
        vec![1000 * USDC, 0],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 1)
    );

    // Accounts for a token with nothing to deposit, where the price accounts should be.
    let res = try_open_and_settle_deposit_order_raw(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[
            accounts_of(usdc.clone(), depositor.token_atas["USDC"]),
            accounts_of(sol, depositor.token_atas["USDC"]),
        ],
        vec![1000 * USDC, 0],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidScopePriceAccount, 1)
    );

    // Anything past the price accounts.
    let mut scope_accounts = get_ordered_scope_accounts(&mut ctx, &vault).await;
    scope_accounts.push(scope_accounts[0]);
    let tx = instructions::open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        deposit_order_pda(&vault, &depositor.owner.pubkey(), 0),
        0,
        &[accounts_of(usdc, depositor.token_atas["USDC"])],
        vec![1000 * USDC, 0],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
        0,
        scope_accounts,
    )
    .await;
    assert_eq!(
        send_transaction!(ctx, tx).unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::UnexpectedRemainingAccounts, 1)
    );
}

#[tokio::test]
async fn test_expired_order_is_settled_by_anyone_but_cancelled_only_by_its_owner() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    // Handing the basket back is the owner's call; a stranger may only settle.
    let res = try_cancel_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );
    // And a stranger's refund goes to the owner's associated accounts only.
    let side_account = kp();
    token_operations::create_token_account(
        &mut ctx,
        cranker.clone(),
        &side_account,
        &vault.vault_tokens["USDC"].token_mint,
        &depositor.owner.pubkey(),
    )
    .await
    .unwrap();
    let res = try_settle_deposit_order_raw(
        &mut ctx,
        &cranker,
        &vault,
        order,
        depositor.owner.pubkey(),
        &[OrderTokenAccounts {
            token: vault.vault_tokens["USDC"].clone(),
            owner_ata: side_account.pubkey(),
        }],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::PayoutNotToAssociatedAccount, 1)
    );

    // The settle takes the 500 USDC the 60% bound admits, mints for them, and hands the rest
    // straight back.
    let shares_before = depositor.balances(&mut ctx).await.shares;
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert!(depositor.balances(&mut ctx).await.shares > shares_before);
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        500 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1500 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_expired_order_cancel_refunds_the_owner() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    assert_eq!(depositor.balances(&mut ctx).await.tokens["USDC"], 0);
    skip(&mut ctx, &vault, HOUR + 1).await;

    // Nothing was ever absorbed, so the whole basket comes back.
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        1000 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 1000 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_only_the_owner_may_cancel_a_live_auction() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let stranger = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;

    // Mid-auction a stranger cannot take the basket back.
    let res = try_cancel_deposit_order(&mut ctx, &stranger, &vault, order).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );

    // The owner cancels: everything the auction had made of the basket comes back as it stands.
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.tokens["USDC"], 900 * USDC);
    assert_eq!(balances.tokens["SOL"], SOL);
    assert_eq!(balances.shares, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_that_absorbs_nothing_still_ends_the_order() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 2000 * USDC).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let first = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    let second = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        1,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    // The first settle takes the 500 USDC of room there was, leaving the vault exactly at its
    // 60% USDC bound.
    settle_deposit_order(&mut ctx, &cranker, &vault, first).await;
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1500 * USDC);

    // So the second is admitted nothing at all, and is still ended: its basket comes back whole.
    let shares_before = depositor.balances(&mut ctx).await.shares;
    settle_deposit_order(&mut ctx, &cranker, &vault, second).await;
    assert!(try_deposit_order_state(&mut ctx, second).await.is_none());
    assert_eq!(depositor.balances(&mut ctx).await.shares, shares_before);
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        1500 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1500 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_restarting_an_order_is_a_cancel_and_an_open() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 2000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    // An id in use cannot be opened again, live or expired: the account exists.
    for wait in [0, HOUR + 1] {
        skip(&mut ctx, &vault, wait).await;
        let res = try_open_and_settle_deposit_order(
            &mut ctx,
            &vault,
            &depositor,
            0,
            &[("USDC", 100 * USDC)],
            HOUR,
            u64::from(FULL_BPS),
            u64::from(FULL_BPS),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            TransactionError::InstructionError(
                1,
                InstructionError::Custom(SystemError::AccountAlreadyInUse as u32) // Anchor's `init`
            )
        );
    }
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );

    // The owner cancels the expired basket and opens afresh with part of it, on a new clock.
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    let shares_before = depositor.balances(&mut ctx).await.shares;
    open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 600 * USDC)],
        2 * HOUR,
    )
    .await;
    let state = deposit_order_state(&mut ctx, order).await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 600 * USDC);
    assert_eq!(depositor.balances(&mut ctx).await.shares, shares_before);
    let now = ctx.get_clock().await.unix_timestamp as u64;
    assert_eq!(state.base.rebalance.start_timestamp, now);
    assert_eq!(state.base.rebalance.end_timestamp, now + 2 * HOUR);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 600 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_locked_amounts_are_not_the_vaults_to_pay_out() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 0),
    )
    .await;

    // The LP takes everything the vault will pay in USDC: the order's 1000 stay put.
    let lp_shares = lp.balances(&mut ctx).await.shares;
    withdraw(&mut ctx, &vault, &lp, lp_shares, "USDC").await;
    let vault_balances = vault.balances(&mut ctx).await;
    assert!(vault_balances.token_vaults["USDC"] >= 1000 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    skip(&mut ctx, &vault, HOUR + 1).await;
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        1000 * USDC
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_two_orders_of_one_owner() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 2000 * USDC).await;
    let first = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    // Neither open absorbs anything: both baskets are locked whole, awaiting their auctions.
    let second = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        1,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    assert_ne!(first, second);
    assert_eq!(
        locked_of(&mut ctx, &vault, second, "USDC").await,
        1000 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 2000 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, second).await;
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_eq!(
        locked_of(&mut ctx, &vault, first, "USDC").await,
        1000 * USDC
    );
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        1000 * USDC
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_cancel_needs_every_held_token() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    let res = try_cancel_deposit_order_raw(&mut ctx, &depositor.owner, &vault, order, &[]).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderTokensNotCovered, 1)
    );

    // Someone else's token account is not where the refund goes.
    let other = usdc_holder(&mut ctx, &vault, 0).await;
    let res = try_cancel_deposit_order_raw(
        &mut ctx,
        &depositor.owner,
        &vault,
        order,
        &[OrderTokenAccounts {
            token: vault.vault_tokens["USDC"].clone(),
            owner_ata: other.token_atas["USDC"],
        }],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );
}

#[tokio::test]
async fn test_settle_needs_every_held_token() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    // The settle hands back what the vault will not take, so it needs the accounts of every token
    // the order holds -- even the part it is about to absorb.
    let res = try_settle_deposit_order_raw(
        &mut ctx,
        &depositor.owner,
        &vault,
        order,
        depositor.owner.pubkey(),
        &[],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderTokensNotCovered, 1)
    );

    // Someone else's token account is not where the refund goes.
    let other = usdc_holder(&mut ctx, &vault, 0).await;
    let res = try_settle_deposit_order_raw(
        &mut ctx,
        &depositor.owner,
        &vault,
        order,
        depositor.owner.pubkey(),
        &[OrderTokenAccounts {
            token: vault.vault_tokens["USDC"].clone(),
            owner_ata: other.token_atas["USDC"],
        }],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );

    // Nothing moved through either attempt.
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_deposit_cap_applies_to_what_is_absorbed() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(to_sf(2050u64)),
    )
    .await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 50 * USDC, "SOL".to_string() => SOL / 2 },
    )
    .await;
    let basket = [("USDC", 50 * USDC), ("SOL", SOL / 2)];

    // $100 at the vault's weights settles in the same transaction as the open, so it is the
    // absorbing instruction that trips the cap the $2000 vault has no room under.
    let res =
        try_open_and_settle_deposit_order(&mut ctx, &vault, &depositor, 0, &basket, HOUR, 0, 0)
            .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAumCapExceeded, 2)
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(to_sf(2100u64)),
    )
    .await;
    open_and_settle_deposit_order(&mut ctx, &vault, &depositor, 0, &basket, HOUR).await;
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_emergency_mode_blocks_every_order_instruction() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 2000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;

    let expected = metavault_error!(KaminoVaultError::VaultEmergencyMode, 1);
    let res = try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        1,
        &[("USDC", 1000 * USDC)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
    let res = try_settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
    let res = try_cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
}

#[tokio::test]
async fn test_krfq_gate_keys_the_fill_on_the_order() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    let krfq_server = kp();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::KrfqEnabled(true),
    )
    .await;
    set_global_config(
        &mut ctx,
        &GlobalConfig {
            krfq_swap_authority: krfq_server.pubkey(),
            ..Default::default()
        },
    );

    async fn fill(
        ctx: &mut TestContext,
        vault: &VaultAccounts,
        solver: &VaultDepositorAccounts,
        order: Pubkey,
        krfq_authority: Option<&KP>,
        marker: KrfqMarker,
    ) -> Result<(), BanksClientError> {
        try_fill_deposit_order_with_krfq_marker(
            ctx,
            &solver.owner,
            vault,
            order,
            "SOL",
            "USDC",
            SOL,
            RequestedOut::AtCurve,
            krfq_authority,
            pda::global_config(),
            marker,
        )
        .await
    }
    let res = fill(&mut ctx, &vault, &solver, order, None, KrfqMarker::Derived).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqAuthorityMissing, 1)
    );
    let res = fill(
        &mut ctx,
        &vault,
        &solver,
        order,
        Some(&krfq_server),
        KrfqMarker::Omitted,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqFillMarkerMissing, 1)
    );
    // The vault's own marker for the same pair authorizes a different fill.
    let vault_marker = pda::krfq_fill_marker(
        &vault.vault_state.pubkey(),
        &vault.vault_tokens["SOL"].token_mint,
        &vault.vault_tokens["USDC"].token_mint,
    );
    let res = fill(
        &mut ctx,
        &vault,
        &solver,
        order,
        Some(&krfq_server),
        KrfqMarker::Wrong(vault_marker),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqFillMarkerIncorrect, 1)
    );
    fill(
        &mut ctx,
        &vault,
        &solver,
        order,
        Some(&krfq_server),
        KrfqMarker::Derived,
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn test_vault_rebalance_and_orders_do_not_interfere() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10 * SOL, "USDC".to_string() => 1000 * USDC },
    )
    .await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    // The vault goes 100% USDC by weight while the order still wants 50/50 of its own.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, HOUR).await;
    assert!(vault.state(&mut ctx).await.rebalance.is_unfinished());
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );
    // The vault's own fill leaves the order's lock alone.
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "USDC",
        "SOL",
        1000 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_token_added_to_the_vault_joins_live_orders() {
    let (mut ctx, mut vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    // ETH at $2000 joins the vault while the order's auction runs; nothing blocks that. Weighted
    // at zero it is settled at zero in every basket, the order's included.
    add_priced_spl_token(&mut ctx, &mut vault, "ETH", 8, 2000.0).await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1, 0]),
    )
    .await;
    // The settle hands back whatever it does not absorb, so the owner needs somewhere to receive
    // a token their order can only have picked up after it opened.
    token_operations::create_ata_if_not_exists(
        &mut ctx,
        &depositor.owner,
        &vault.vault_tokens["ETH"].token_mint,
    )
    .await;
    let solver = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10 * SOL,
            "ETH".to_string() => ETH,
            "USDC".to_string() => 0,
        },
    )
    .await;
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "ETH").await,
        0
    );
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "ETH",
        "USDC",
        ETH / 100,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );

    // Weighted 2/2/1, the order now wants a fifth of its $1000 in ETH: 0.1 ETH.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![2, 2, 1]),
    )
    .await;
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "ETH").await,
        ETH / 10
    );
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "ETH",
        "USDC",
        ETH / 10,
        RequestedOut::AtCurve,
    )
    .await;
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        4 * SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 400 * USDC);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 4 * SOL);
    assert_eq!(locked_of(&mut ctx, &vault, order, "ETH").await, ETH / 10);
    assert_eq!(
        deposit_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    assert_eq!(locked_total(&mut ctx, &vault, "ETH").await, ETH / 10);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // The basket now sits at the vault's weights, so every token goes in and the vault's whole ETH
    // position is born from the order.
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1400 * USDC);
    assert_eq!(available_of(&mut ctx, &vault, "SOL").await, 14 * SOL);
    assert_eq!(available_of(&mut ctx, &vault, "ETH").await, ETH / 10);
    assert_eq!(locked_total(&mut ctx, &vault, "ETH").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // A new order takes the new token as an input like any other, under its own bound: an ETH
    // basket nobody bids on is cut to what that bound admits, and the rest handed back.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(
            vault.vault_tokens["ETH"].token_mint,
            1000,
        ),
    )
    .await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "ETH".to_string() => ETH, "USDC".to_string() => 0, "SOL".to_string() => 0 },
    )
    .await;
    let order = open_deposit_order(&mut ctx, &vault, &depositor, 0, &[("ETH", ETH)], HOUR).await;
    skip(&mut ctx, &vault, HOUR + 1).await;
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    let handed_back = depositor.balances(&mut ctx).await.tokens["ETH"];
    assert!(handed_back > 0 && handed_back < ETH, "{handed_back}");
    assert_eq!(
        handed_back + available_of(&mut ctx, &vault, "ETH").await,
        ETH + ETH / 10
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_weight_change_moves_a_live_orders_targets() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;

    // The vault goes 100% USDC by weight mid-auction. The order follows: its 1 SOL is now the
    // excess and USDC the deficit, so the direction flips and the earlier fill stands.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        0
    );
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );
    let buyer = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 1000 * USDC, "SOL".to_string() => 0 },
    )
    .await;
    fill_deposit_order(
        &mut ctx,
        &buyer.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 0);
    assert_eq!(
        deposit_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_weight_churn_cannot_bleed_an_order_past_its_loss_ceiling() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    // The vault overpays 4% for whatever it buys, in both directions.
    for token in ["SOL", "USDC"] {
        update_vault_config(
            &mut ctx,
            &admin,
            &vault,
            UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
                vault.vault_tokens[token].token_mint,
                10_000,
                10_000,
                10_400,
                10_400,
            ),
        )
        .await;
    }
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let buyer = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 1000 * USDC, "SOL".to_string() => 0 },
    )
    .await;
    // $1000 of USDC: each fill may cost it up to 10%, but the whole auction only 0.5% ($5), set
    // by the order alone (the vault's own rebalances may lose nothing).
    try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
        1000,
        50,
    )
    .await
    .unwrap();
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);

    // 0.5 SOL in at 104%: $2 lost.
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL / 2,
        RequestedOut::AtCurve,
    )
    .await;
    // The weights flip, so does the order, and each re-opening buys another round of fills:
    // 25 USDC in at 104%, $1 lost ($3 in total).
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    fill_deposit_order(
        &mut ctx,
        &buyer.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        25 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![5, 5]),
    )
    .await;

    // Another $3 would pass the per-fill cap, but not the auction's loss ceiling ($6 > 0.5% of
    // ~$997).
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        3 * SOL / 4,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceLossCeilingExceeded, 1)
    );
    // What is left under the ceiling still buys a smaller fill ($1, $4 in total).
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL / 4,
        RequestedOut::AtCurve,
    )
    .await;
    // 0.5% of the $1000 opened.
    let rebalance = deposit_order_state(&mut ctx, order).await.base.rebalance;
    assert_fuzzy_eq!(
        Fraction::from_bits(rebalance.ceiling_at_start_usd_sf).to_floor::<u64>(),
        5,
        1
    );
    assert_fuzzy_eq!(
        Fraction::from_bits(rebalance.lost_usd_sf).to_floor::<u64>(),
        4,
        1
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_token_the_vault_targets_none_of_can_no_longer_be_locked() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 1000 * USDC, "SOL".to_string() => SOL },
    )
    .await;

    // The vault goes 100% USDC by weight, so it takes no more SOL: by order as by plain deposit.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    let res = try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC), ("SOL", SOL)],
        HOUR,
        100,
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TokenWeightZeroed, 1)
    );

    // A basket leaving the zeroed token out is still welcome, and no order can hold it any more.
    open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC)],
        HOUR,
    )
    .await;
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_token_the_vault_stops_wanting_is_handed_back_instead_of_absorbed() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 1000 * USDC, "SOL".to_string() => SOL },
    )
    .await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC), ("SOL", SOL)],
        HOUR,
    )
    .await;

    // The vault stops wanting SOL once the basket is already locked, and nobody buys the SOL out.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;

    // So the USDC goes in for shares and the SOL comes back whole: a zero weight admits nothing.
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.tokens["SOL"], SOL);
    assert_eq!(balances.tokens["USDC"], 900 * USDC);
    assert!(balances.shares > 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_dust_left_by_fills_goes_in_with_the_rest() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    // A fill 900 lamports short of the deficit leaves 90 lamports of USDC excess: within the
    // settled tolerance, so no fill can take it, and the auction is over.
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        5 * SOL - 900,
        RequestedOut::AtCurve,
    )
    .await;
    let state = deposit_order_state(&mut ctx, order).await;
    assert_eq!(state.base.rebalance.end_timestamp, 0);
    let usdc_left = locked_of(&mut ctx, &vault, order, "USDC").await;
    assert_fuzzy_eq!(usdc_left, 500 * USDC + 90, 1);

    // Room for everything: the SOL and USDC absorb whole, the 90 lamports carried in with
    // them by an absorb that is worth plenty of shares, and the order is done.
    deposit(&mut ctx, &vault, &lp, "SOL", 10 * SOL).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_is_refused_while_a_fill_could_still_improve_the_basket() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let shares_before = depositor.balances(&mut ctx).await.shares;

    // The open locks the whole basket and mints nothing.
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_eq!(depositor.balances(&mut ctx).await.shares, shares_before);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // Nobody may settle while a fill could still better the basket (the owner's way out is to
    // cancel).
    for signer in [&depositor.owner, &cranker] {
        let res = try_settle_deposit_order(&mut ctx, signer, &vault, order).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAuctionStillRunning, 1)
        );
    }

    // Once the window is past, the same settle goes through.
    skip(&mut ctx, &vault, HOUR + 1).await;
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert!(depositor.balances(&mut ctx).await.shares > shares_before);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_fill_switch_stops_order_fills_but_not_the_vaults_own() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10 * SOL, "USDC".to_string() => 1000 * USDC },
    )
    .await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositOrderFillEnabled(false),
    )
    .await;
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositOrderFillDisabled, 1)
    );

    // The vault's own rebalance fills are a different arm and answer to none of the order switches.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, HOUR).await;
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "USDC",
        "SOL",
        1000 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_switch_stops_absorbing() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositOrderSettleEnabled(false),
    )
    .await;
    let res = try_settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositOrderSettleDisabled, 1)
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::DepositOrderSettleEnabled(true),
    )
    .await;
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        500 * USDC
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_cancel_answers_to_none_of_the_switches() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    for switch in [
        UpdateVaultConfigParams::DepositOrderCreationEnabled(false),
        UpdateVaultConfigParams::DepositOrderFillEnabled(false),
        UpdateVaultConfigParams::DepositOrderSettleEnabled(false),
    ] {
        update_vault_config(&mut ctx, &admin, &vault, switch).await;
    }

    // Whatever the switches say, the owner takes back what the order still holds.
    cancel_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        1000 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_absorb_refuses_to_buy_a_share_above_the_price_asked_for() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 100 * USDC, "SOL".to_string() => SOL },
    )
    .await;
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    let basket = [("USDC", 50 * USDC), ("SOL", SOL / 2)];

    // Asking a $100 basket for more shares than the vault has ever issued prices the share far
    // under what it costs, so the absorb is refused -- and with it the open, leaving nothing.
    let res = try_open_and_settle_deposit_order_with_min_shares(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &basket,
        HOUR,
        u64::MAX / 2,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 2)
    );
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_eq!(
        depositor.balances(&mut ctx).await.tokens["USDC"],
        100 * USDC
    );

    // A price the vault clears lets the same basket through, whole.
    let shares_before = depositor.balances(&mut ctx).await.shares;
    try_open_and_settle_deposit_order_with_min_shares(
        &mut ctx, &vault, &depositor, 0, &basket, HOUR, 1,
    )
    .await
    .unwrap();
    assert!(depositor.balances(&mut ctx).await.shares > shares_before);
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_an_absorb_not_worth_a_share_takes_nothing() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => SOL, "USDC".to_string() => 0 },
    )
    .await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);

    // One SOL lamport is worth a tenth of a share lamport here, so there is nothing a share can
    // be minted for -- and a basket this small sits inside the settled tolerance, so its auction
    // is over before it starts.
    let order = open_deposit_order(&mut ctx, &vault, &depositor, 0, &[("SOL", 1)], HOUR).await;
    let shares_before = depositor.balances(&mut ctx).await.shares;

    // The vault takes nothing rather than taking it for nothing, and the lamport goes home.
    settle_deposit_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(depositor.balances(&mut ctx).await.shares, shares_before);
    assert_eq!(depositor.balances(&mut ctx).await.tokens["SOL"], SOL);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_leg_not_worth_its_fee_is_all_fee() {
    // A sliver of SOL under the vault's fee floor (the highest one allowed): the plain deposit
    // would refuse it; the settle takes it whole as fee and mints for the USDC alone.
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = token_holder(&mut ctx, &vault, 1000 * USDC, SOL).await;
    let fee_floor = u64::from(MAX_FEE_LAMPORTS);
    let sliver = fee_floor / 2;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["SOL"].token_mint,
            fee_floor,
        ),
    )
    .await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC), ("SOL", sliver)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    let before = depositor.balances(&mut ctx).await;
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    let after = depositor.balances(&mut ctx).await;
    assert_eq!(after.tokens["SOL"], before.tokens["SOL"]);
    assert_eq!(after.tokens["USDC"], before.tokens["USDC"]);
    // 100 USDC of a $2000 vault (with the $0.0005 sliver fee in) behind 1,999,999,998 shares,
    // floored; nothing for the sliver.
    assert_eq!(after.shares, before.shares + 99_999_974);
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL + sliver
    );
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_prices_the_shares_with_the_fee_in_the_vault() {
    // Like a plain deposit: the fee goes to the holders, none of it buys the owner shares.
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            1000,
        ),
    )
    .await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    let before = depositor.balances(&mut ctx).await;
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    let after = depositor.balances(&mut ctx).await;
    // $90 net of the 10% fee, against the $2010 a $2000 vault holds with the $10 fee in, behind
    // 1,999,999,998 shares, floored (without the fee in: 89,999,999).
    assert_eq!(after.shares, before.shares + 89_552_238);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1100 * USDC);
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_prices_the_shares_on_the_net_aum_with_obligations() {
    // A vault that also lends: 5 SOL and 0.25 ETH sit in klend as collateral against a 100 USDC
    // borrow. The absorb prices the shares on the net AUM, obligation included, as a deposit does.
    let spec = MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "ETH".to_string() => MintSpec::spl(8, 2000.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("ETH", 0),
        ])],
    };
    let (mut ctx, markets, vault) = setup_markets_with_weights(&spec, vec![1, 1, 1]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let eth_reserve = markets.markets[0].reserves["ETH"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let lp = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 4000 * USDC,
            "SOL".to_string() => 20 * SOL,
            "ETH".to_string() => 5 * ETH,
        },
    )
    .await;
    deposit(&mut ctx, &vault, &lp, "USDC", 2000 * USDC).await;
    deposit(&mut ctx, &vault, &lp, "SOL", 10 * SOL).await;
    deposit(&mut ctx, &vault, &lp, "ETH", ETH / 2).await;
    init_obligation(&mut ctx, &admin, &vault, &market, 0).await;
    let obligation =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation,
        "SOL",
        5 * SOL,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &eth_reserve,
        obligation,
        "ETH",
        ETH / 4,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation,
        "USDC",
        100 * USDC,
        vec![&sol_reserve, &eth_reserve],
        vec![],
    )
    .await
    .unwrap();
    for switch in [
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderSettleEnabled(true),
    ] {
        update_vault_config(&mut ctx, &admin, &vault, switch).await;
    }
    // The collateral left the vault's own balance (up to klend's cToken rounding) and the borrow
    // joined it (less klend's origination fee):
    assert_fuzzy_eq!(available_of(&mut ctx, &vault, "SOL").await, 5 * SOL, 10);
    assert_fuzzy_eq!(
        available_of(&mut ctx, &vault, "USDC").await,
        2100 * USDC,
        USDC
    );

    let depositor = usdc_holder(&mut ctx, &vault, 200 * USDC).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC)],
        HOUR,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;
    // The settle reads the obligation, which klend must have refreshed in the same slot:
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation,
        vec![&sol_reserve, &eth_reserve],
        vec![&usdc_reserve],
    )
    .await;
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    let order_shares = depositor.balances(&mut ctx).await.shares;

    // The same 100 USDC through the plain deposit, at the same clock and prices:
    let supply_before = vault.balances(&mut ctx).await.shares_supply;
    deposit(&mut ctx, &vault, &depositor, "USDC", 100 * USDC).await;
    let deposit_shares = vault.balances(&mut ctx).await.shares_supply - supply_before;
    assert_fuzzy_eq!(order_shares, deposit_shares, 10);
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_tight_slippage_order_only_takes_fills_at_the_oracle() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;

    // An order accepting a loss of one basis point per fill.
    try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
        1,
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);

    // The default curve pays the oracle price throughout, so a fill at the curve loses nothing:
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, SOL);
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 900 * USDC);

    // One percent over the oracle for the SOL the basket buys is a hundred times the order's cap:
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            vault.vault_tokens["SOL"].token_mint,
            10_000,
            10_000,
            10_100,
            10_100,
        ),
    )
    .await;
    let res = try_fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceSwapExceedsMaxLoss, 1)
    );
    // A solver asking the oracle's 100 USDC for its SOL is under the cap, curve or not:
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::Exact(100 * USDC),
    )
    .await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 2 * SOL);
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 800 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_price_move_after_the_open_reprices_the_fill_and_the_settle() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1100 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        5 * SOL
    );

    // SOL rises 10% after the open. The targets derive from the basket's value at today's prices:
    // $1000 split 50/50 wants 500 / 110 SOL now, not the 5 SOL of the open.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 110.0, 110.0).await;
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        4_545_454_545
    );
    // A solver offering 5 SOL is clamped to that deficit and paid the oracle's USDC for it:
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        5 * SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        4_545_454_545
    );
    assert_fuzzy_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        500 * USDC,
        2
    );

    // That fill left nothing to do, so the auction is over and anyone may settle at once. The
    // settle prices the $1000 basket at today's share price (the performance fee on SOL's gain
    // charged first): a $100 deposit right behind it is the yardstick.
    assert_eq!(
        deposit_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    let shares = depositor.balances(&mut ctx).await.shares;
    let supply = vault.balances(&mut ctx).await.shares_supply;
    deposit(&mut ctx, &vault, &depositor, "USDC", 100 * USDC).await;
    let per_100_usd = vault.balances(&mut ctx).await.shares_supply - supply;
    assert_fuzzy_eq!(shares, 10 * per_100_usd, 100);
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_half_filled_before_and_half_after_a_price_move() {
    let (mut ctx, vault, _lp) = setup_balanced_vault().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1100 * USDC).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;

    // Half of the 5 SOL deficit at $100: 2.5 SOL for 250 USDC.
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        5 * SOL / 2,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 5 * SOL / 2);
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 750 * USDC);

    // SOL rises to $110: the basket is worth $1025, so SOL's target is 512.5 / 110 and the rest
    // of the deficit shrinks from 2.5 SOL to about 2.16.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 110.0, 110.0).await;
    assert_eq!(
        order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        4_659_090_909
    );
    fill_deposit_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        5 * SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        4_659_090_909
    );
    assert_fuzzy_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        512_500_000,
        2
    );

    // The second fill left nothing to do either. The $1025 basket at today's share price, a $100
    // deposit right behind as the yardstick:
    assert_eq!(
        deposit_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    let shares = depositor.balances(&mut ctx).await.shares;
    let supply = vault.balances(&mut ctx).await.shares_supply;
    deposit(&mut ctx, &vault, &depositor, "USDC", 100 * USDC).await;
    let per_100_usd = vault.balances(&mut ctx).await.shares_supply - supply;
    assert_fuzzy_eq!(shares, per_100_usd * 1025 / 100, 100);
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_rolling_deposit_cap_counts_the_settle_not_the_open() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(1000u64),
            interval_seconds: HOUR,
        },
    )
    .await;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "USDC".to_string() => 500 * USDC, "SOL".to_string() => 5 * SOL },
    )
    .await;

    // A $1000 basket at the vault's weights: settleable right away, but the open counts nothing
    // against the window, so a $600 deposit still fits behind it.
    let order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 500 * USDC), ("SOL", 5 * SOL)],
        HOUR,
    )
    .await;
    deposit(&mut ctx, &vault, &lp, "USDC", 600 * USDC).await;

    // The settle is what the cap counts, and $600 + $1000 is over it:
    let res = try_settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RollingDepositCapExceeded, 1)
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 500 * USDC);

    // The window tumbles with the clock, and the settle goes through:
    skip(&mut ctx, &vault, HOUR + 1).await;
    settle_deposit_order(&mut ctx, &depositor.owner, &vault, order).await;
    assert!(try_deposit_order_state(&mut ctx, order).await.is_none());
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

// ── Helpers ──────────────────────────────────────────────────────────

async fn setup_balanced_vault() -> (TestContext, VaultAccounts, VaultDepositorAccounts) {
    fixtures::setup_balanced_vault(vec![
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderFillEnabled(true),
        UpdateVaultConfigParams::DepositOrderSettleEnabled(true),
    ])
    .await
}

async fn locked_of(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    order: Pubkey,
    token: &str,
) -> u64 {
    locked_amount_of::<DepositOrder>(ctx, vault, order, token).await
}

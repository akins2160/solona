use anchor_lang::{system_program::System, Id, InstructionData, ToAccountMetas};
use kamino_lending::{
    assert_gt, assert_gte, assert_lte,
    fraction::Fraction,
    program_test::common::{
        fixtures::setup_reserves_with_elevation_groups,
        setup::{update_reserve, KP},
        types::{KaminoMarkets, MSpec, MarketsSpec, MintSpec, RSpec, ReserveAccounts, TestContext},
    },
    send_transaction,
    state::ElevationGroup,
    LendingError, Obligation, Reserve, ReserveFarmKind,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{
            self, get_ordered_scope_accounts, get_ordered_scope_and_obligation_accounts,
            RequestedOut, UpdateVaultConfigParams,
        },
        event_authority_pda,
        fixtures::setup_markets_with_weights,
        instructions::{
            build_klend_refresh_obligation_ix, build_klend_refresh_reserve_ix,
            vault_obligation_pda, withdraw_ix, FARMS_PROGRAM_ID,
        },
        klend_error, setup, VaultAccounts, VaultDepositorAccounts,
    },
    utils::pda::vault_user_metadata,
    KaminoVaultError, MetavaultState,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    account::AccountSharedData,
    compute_budget::ComputeBudgetInstruction,
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    signer::Signer,
};

#[tokio::test]
async fn test_obligation_full_lifecycle() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;

    let balances = vault.balances(&mut ctx).await;
    let vault_sol_before = balances.token_vaults["SOL"];
    assert!(vault_sol_before >= 9_000_000_000);

    // UserMetadata PDA is created during vault init.
    let user_metadata_pk = vault_user_metadata(&vault.base_vault_authority);
    assert!(ctx.get_account(user_metadata_pk).await.unwrap().is_some());

    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    assert!(ctx.get_account(obligation_pk).await.unwrap().is_some());
    let state: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state.obligations[0].obligation, obligation_pk);
    assert_eq!(state.get_obligations_count(), 1);

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_after_deposit = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert_eq!(vault_sol_after_deposit, vault_sol_before - 5_000_000_000);

    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_usdc_after_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert!(vault_usdc_after_borrow > 2_000_000_000);

    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    let vault_sol_after_withdraw = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert!(vault_sol_after_withdraw > vault_sol_after_deposit);
}

#[tokio::test]
async fn test_obligation_ops_forward_farm_accounts() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let mut sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let mut usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    ctx.init_farms(market, &mut sol_reserve, u64::MAX)
        .await
        .unwrap();
    ctx.init_farms(market, &mut usdc_reserve, u64::MAX)
        .await
        .unwrap();
    init_metavault_obligation_farm_for_reserve(
        &mut ctx,
        &admin,
        &sol_reserve,
        vault.base_vault_authority,
        obligation_pk,
        ReserveFarmKind::Collateral,
    )
    .await;
    init_metavault_obligation_farm_for_reserve(
        &mut ctx,
        &admin,
        &usdc_reserve,
        vault.base_vault_authority,
        obligation_pk,
        ReserveFarmKind::Debt,
    )
    .await;

    let vault_sol_before = vault.balances(&mut ctx).await.token_vaults["SOL"];
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    let vault_sol_after_deposit = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert_eq!(vault_sol_after_deposit, vault_sol_before - 5_000_000_000);

    let vault_usdc_before_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    let vault_usdc_after_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_gt!(vault_usdc_after_borrow, vault_usdc_before_borrow);

    let vault_usdc_before_repay = vault.balances(&mut ctx).await.token_vaults["USDC"];
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    let vault_usdc_after_repay = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_gt!(vault_usdc_before_repay, vault_usdc_after_repay);

    let vault_sol_before_withdraw = vault.balances(&mut ctx).await.token_vaults["SOL"];
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    let vault_sol_after_withdraw = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert_gt!(vault_sol_after_withdraw, vault_sol_before_withdraw);
}

#[tokio::test]
async fn test_borrow_without_deposit_reserves_outside_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    assert_obligation_elevation_group(&mut ctx, obligation_pk, 0).await;
    let vault_usdc_before_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    borrow_obligation_liquidity_with_forwarded_deposit_reserves(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
        vec![],
    )
    .await
    .unwrap();
    let vault_usdc_after_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_gt!(vault_usdc_after_borrow, vault_usdc_before_borrow);
}

#[tokio::test]
async fn test_repay_without_deposit_reserves_outside_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    assert_obligation_elevation_group(&mut ctx, obligation_pk, 0).await;
    let vault_usdc_before_repay = vault.balances(&mut ctx).await.token_vaults["USDC"];
    repay_obligation_liquidity_with_forwarded_deposit_reserves(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
        vec![],
    )
    .await
    .unwrap();
    let vault_usdc_after_repay = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_gt!(vault_usdc_before_repay, vault_usdc_after_repay);
}

#[tokio::test]
async fn test_obligation_ops_require_accounts_for_target_farm_kind_only() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    set_onchain_reserve_farms(
        &mut ctx,
        &sol_reserve,
        Pubkey::new_unique(),
        Pubkey::default(),
    )
    .await;
    let res = client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationAccountMissing, 3),
    );

    set_onchain_reserve_farms(&mut ctx, &sol_reserve, Pubkey::default(), Pubkey::default()).await;
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    set_onchain_reserve_farms(
        &mut ctx,
        &sol_reserve,
        Pubkey::new_unique(),
        Pubkey::default(),
    )
    .await;
    let res = client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationAccountMissing, 3),
    );

    set_onchain_reserve_farms(&mut ctx, &sol_reserve, Pubkey::default(), Pubkey::default()).await;
    set_onchain_reserve_farms(
        &mut ctx,
        &usdc_reserve,
        Pubkey::default(),
        Pubkey::new_unique(),
    )
    .await;
    let res = client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationAccountMissing, 4),
    );

    set_onchain_reserve_farms(
        &mut ctx,
        &usdc_reserve,
        Pubkey::default(),
        Pubkey::default(),
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    set_onchain_reserve_farms(
        &mut ctx,
        &usdc_reserve,
        Pubkey::default(),
        Pubkey::new_unique(),
    )
    .await;
    let res = client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationAccountMissing, 4),
    );
}

#[tokio::test]
async fn test_multi_collateral_obligation_ops_forward_only_target_farm_accounts() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_three_reserve_spec(), vec![5, 5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let mut sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let mut usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let mut usdt_reserve = markets.markets[0].reserves["USDT"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
            "USDT".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    ctx.init_farms(market, &mut sol_reserve, u64::MAX)
        .await
        .unwrap();
    ctx.init_farms(market, &mut usdc_reserve, u64::MAX)
        .await
        .unwrap();
    ctx.init_farms(market, &mut usdt_reserve, u64::MAX)
        .await
        .unwrap();
    init_metavault_obligation_farm_for_reserve(
        &mut ctx,
        &admin,
        &sol_reserve,
        vault.base_vault_authority,
        obligation_pk,
        ReserveFarmKind::Collateral,
    )
    .await;
    init_metavault_obligation_farm_for_reserve(
        &mut ctx,
        &admin,
        &usdt_reserve,
        vault.base_vault_authority,
        obligation_pk,
        ReserveFarmKind::Collateral,
    )
    .await;
    init_metavault_obligation_farm_for_reserve(
        &mut ctx,
        &admin,
        &usdc_reserve,
        vault.base_vault_authority,
        obligation_pk,
        ReserveFarmKind::Debt,
    )
    .await;

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_pk,
        "USDT",
        500_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve, &usdt_reserve],
        vec![],
    )
    .await
    .unwrap();
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve, &usdt_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    let vault_usdt_before = vault.balances(&mut ctx).await.token_vaults["USDT"];
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_pk,
        "USDT",
        100_000_000,
        vec![&sol_reserve, &usdt_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    let vault_usdt_after = vault.balances(&mut ctx).await.token_vaults["USDT"];
    assert_gt!(vault_usdt_after, vault_usdt_before);
}

#[tokio::test]
async fn test_two_obligations_with_distinct_farms_and_one_elevation_group() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_four_reserve_spec(), vec![5, 5, 5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let mut sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let mut usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let mut usdt_reserve = markets.markets[0].reserves["USDT"].clone();
    let mut pyusd_reserve = markets.markets[0].reserves["PYUSD"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
            "USDT".to_string() => 2_000_000_000,
            "PYUSD".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "PYUSD", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_a =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    let usdc_reserve_pk = usdc_reserve.address.pubkey();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[ElevationGroup {
            id: TEST_ELEVATION_GROUP_ID,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 1,
            debt_reserve: usdc_reserve_pk,
            ..Default::default()
        }],
    )
    .await;

    ctx.init_farms(market, &mut sol_reserve, u64::MAX)
        .await
        .unwrap();
    ctx.init_farms(market, &mut usdc_reserve, u64::MAX)
        .await
        .unwrap();
    ctx.init_farms(market, &mut usdt_reserve, u64::MAX)
        .await
        .unwrap();
    ctx.init_farms(market, &mut pyusd_reserve, u64::MAX)
        .await
        .unwrap();
    for (obligation, reserve, farm_kind) in [
        (obligation_a, &sol_reserve, ReserveFarmKind::Collateral),
        (obligation_a, &usdc_reserve, ReserveFarmKind::Debt),
    ] {
        init_metavault_obligation_farm_for_reserve(
            &mut ctx,
            &admin,
            reserve,
            vault.base_vault_authority,
            obligation,
            farm_kind,
        )
        .await;
    }

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_a,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_a,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_a,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_a,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_a,
        "SOL",
        1_000_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    client::init_obligation(&mut ctx, &admin, &vault, market, 1).await;
    let obligation_b =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 1);
    for (reserve, farm_kind) in [
        (&usdt_reserve, ReserveFarmKind::Collateral),
        (&pyusd_reserve, ReserveFarmKind::Debt),
    ] {
        init_metavault_obligation_farm_for_reserve(
            &mut ctx,
            &admin,
            reserve,
            vault.base_vault_authority,
            obligation_b,
            farm_kind,
        )
        .await;
    }
    refresh_obligation_for_test(
        &mut ctx,
        &admin,
        market.market.pubkey(),
        obligation_a,
        &[&sol_reserve],
        &[&usdc_reserve],
    )
    .await
    .unwrap();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_b,
        "USDT",
        500_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &pyusd_reserve,
        obligation_b,
        "PYUSD",
        100_000_000,
        vec![&usdt_reserve],
        vec![],
    )
    .await
    .unwrap();
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &pyusd_reserve,
        obligation_b,
        "PYUSD",
        50_000_000,
        vec![&usdt_reserve],
        vec![&pyusd_reserve],
    )
    .await
    .unwrap();
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_b,
        "USDT",
        100_000_000,
        vec![&usdt_reserve],
        vec![&pyusd_reserve],
    )
    .await
    .unwrap();

    refresh_obligation_for_test(
        &mut ctx,
        &admin,
        market.market.pubkey(),
        obligation_b,
        &[&usdt_reserve],
        &[&pyusd_reserve],
    )
    .await
    .unwrap();
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_a,
        "USDC",
        10_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    let state = vault.state(&mut ctx).await;
    assert_eq!(state.get_obligations_count(), 2);
    assert_obligation_elevation_group(&mut ctx, obligation_a, TEST_ELEVATION_GROUP_ID).await;
    assert_obligation_elevation_group(&mut ctx, obligation_b, 0).await;
}

#[tokio::test]
async fn test_init_obligation_max_slots() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    // MAX_OBLIGATIONS_PER_VAULT = 3
    for id in 0..3 {
        client::init_obligation(&mut ctx, &admin, &vault, market, id).await;
    }

    let state = vault.state(&mut ctx).await;
    assert_eq!(state.get_obligations_count(), 3);

    let err = client::try_init_obligation(&mut ctx, &admin, &vault, market, 3).await;
    assert_eq!(
        err.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationsSpaceExhausted, 1)
    );
}

// `u64::MAX` with no active borrows → full collateral returned.
#[tokio::test]
async fn test_withdraw_obligation_collateral_max_no_borrows() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_before = vault.balances(&mut ctx).await.token_vaults["SOL"];

    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        u64::MAX,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_after = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert_eq!(
        vault_sol_after - vault_sol_before,
        5_000_000_000,
        "u64::MAX with no borrows should return full collateral",
    );
}

// `u64::MAX` with active borrows → klend's LTV-bounded ratio. 5 SOL ($500) collateral at 70% LTV
// with a 100 USDC ($100) debt allows up to ($350 - $100) * 100/70 = $357.14 of collateral value
// to be released, i.e. ~71.43% of the deposit (~3.571 SOL).
#[tokio::test]
async fn test_withdraw_obligation_collateral_max_with_borrows() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_before = vault.balances(&mut ctx).await.token_vaults["SOL"];

    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        u64::MAX,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    let vault_sol_after = vault.balances(&mut ctx).await.token_vaults["SOL"];
    let withdrawn = vault_sol_after - vault_sol_before;
    // Deterministic in this fixture: 5 SOL × $100 collateral against $100 debt at 70% max-LTV →
    // remaining collateral must be ≥ $100 / 0.70 = $142.857 = 1.42857 SOL → withdrawable =
    // 5 − 1.42857 = 3.57143 SOL, rounded down by klend's ctoken/value math.
    assert_eq!(withdrawn, 3_571_428_428);
}

// `collateral_amount > deposited_amount` (and not `u64::MAX`) → klend silently caps and returns
// the full deposited collateral (no borrows → no LTV constraint).
#[tokio::test]
async fn test_withdraw_obligation_collateral_silent_cap() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_before = vault.balances(&mut ctx).await.token_vaults["SOL"];

    // Request 10 SOL when only 5 SOL is deposited; klend silently caps.
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        10_000_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_after = vault.balances(&mut ctx).await.token_vaults["SOL"];
    assert_eq!(
        vault_sol_after - vault_sol_before,
        5_000_000_000,
        "request > deposited should silently cap to deposited",
    );
}

// `u64::MAX` → `BorrowSize::AllAvailable`: bounded by LTV + reserve capacity. With 5 SOL ($500)
// collateral at 70% LTV, the max borrow value is $350 (~350 USDC).
#[tokio::test]
async fn test_borrow_obligation_liquidity_max() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let vault_usdc_before = vault.balances(&mut ctx).await.token_vaults["USDC"];

    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_usdc_after = vault.balances(&mut ctx).await.token_vaults["USDC"];
    let received = vault_usdc_after - vault_usdc_before;
    // Deterministic in this fixture: 5 SOL × $100 = $500 collateral × 70% max-LTV = $350 borrow
    // budget. Klend books a $350M-lamport gross debt and nets a tiny origination fee, so the
    // vault receives 349_999_964 USDC lamports (35 lamport fee on a $350 borrow).
    assert_eq!(received, 349_999_964);
}

// `u64::MAX` → settle the full outstanding debt via `Reserve::calculate_repay`.
#[tokio::test]
async fn test_repay_obligation_liquidity_max() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_usdc_before = vault.balances(&mut ctx).await.token_vaults["USDC"];

    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    let vault_usdc_after = vault.balances(&mut ctx).await.token_vaults["USDC"];
    let sent = vault_usdc_before - vault_usdc_after;
    // Borrowed 100 USDC; ceil(borrowed_amount_f) ≈ 100 USDC plus any tiny origination fee
    // klend's default reserve config layers on (~10 base units).
    assert_gte!(sent, 100_000_000u64);
    assert_gt!(100_001_000u64, sent);
}

// After a full repay (`u64::MAX`), the obligation's `has_debt` flag must clear and a subsequent
// borrow against the same collateral must succeed — proving the new `repay_obligation_liquidity`
// ops fn updates `obligation.has_debt` / clears the borrow entry properly.
#[tokio::test]
async fn test_borrow_repay_borrow_cycle() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    // Borrow 100 USDC, then settle the full debt with u64::MAX.
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    // Borrow again — fails if klend still thinks there's outstanding debt, or if metavault left
    // stale borrow state behind.
    let vault_usdc_before = vault.balances(&mut ctx).await.token_vaults["USDC"];
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    let vault_usdc_after = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_gt!(vault_usdc_after, vault_usdc_before);
}

// Ceiling checks bind the predicted post-op position: with a low ceiling the max-budget borrow
// that succeeds in `test_borrow_obligation_liquidity_max` must now fail.
#[tokio::test]
async fn test_borrow_blocked_by_obligation_ltv_ceiling() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation_pk, 1_000),
    )
    .await
    .unwrap();

    let res = client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationLtvCeilingExceeded, 4)
    );
}

// A generous ceiling must leave klend's own max-LTV borrow budget reachable (regression: the
// check must not bind when configured above the position klend permits).
#[tokio::test]
async fn test_borrow_within_generous_obligation_ltv_ceiling_succeeds() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation_pk, 10_000),
    )
    .await
    .unwrap();

    let vault_usdc_before = vault.balances(&mut ctx).await.token_vaults["USDC"];

    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let vault_usdc_after = vault.balances(&mut ctx).await.token_vaults["USDC"];
    let received = vault_usdc_after - vault_usdc_before;
    // Same fixture and budget as `test_borrow_obligation_liquidity_max`: a 10_000 bps (100%)
    // ceiling must not shave anything off klend's own $350 max-LTV borrow budget.
    assert_eq!(received, 349_999_964);
}

// Withdrawing collateral out from under debt must respect the ceiling.
#[tokio::test]
async fn test_withdraw_collateral_blocked_by_obligation_ltv_ceiling() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    // Tight ceiling set *after* the borrow: the existing position is now near/over it, so
    // removing collateral must be rejected while a repay stays legal.
    client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation_pk, 3_000),
    )
    .await
    .unwrap();

    // Both the deposit and borrow reserves must be forwarded so klend's `refresh_obligation` can
    // recompute the aggregates our ceiling check reads (mirrors
    // `test_withdraw_obligation_collateral_max_with_borrows`, which carries the same debt shape).
    //
    // The amount (2 SOL = $200) is deliberately kept under klend's own native max-LTV withdraw cap
    // (~$357 here) so this test isolates the vault's ceiling. Enforcement is now post-CPI: where
    // klend's own limits also bind (e.g. withdrawing most of the collateral), klend's own error
    // fires first and this vault-level check never gets a chance to run.
    let res = client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationLtvCeilingExceeded, 4)
    );

    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
}

// The allocation admin can manage token weights (see `test_security_update_vault_config_allocation_admin`)
// but must not be able to piggyback that role onto the obligation LTV ceiling field.
#[tokio::test]
async fn test_update_obligation_ltv_ceiling_wrong_authority() {
    let (mut ctx, _markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    let res = client::try_update_vault_config(
        &mut ctx,
        &allocation_admin,
        &vault,
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation_pk, 1_000),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );
}

// Withdrawing all collateral with no active borrows triggers klend to close the obligation
// account. Metavault must detect this post-CPI and drop the dangling pubkey from
// `MetavaultState.obligations`, otherwise the next `AumAccounts::parse`
// would fail and the vault would be unusable.
#[tokio::test]
async fn test_withdraw_obligation_collateral_closes_and_removes_slot() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    // Withdraw u64::MAX with no active borrows → klend returns full collateral AND closes the
    // obligation account.
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        u64::MAX,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    // Metavault's slot for this obligation must now be cleared (so loading the vault next time
    // doesn't trip on a dangling pubkey).
    let state: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state.get_obligations_count(), 0);
    assert!(!state.obligations[0].is_set());

    // And the on-chain obligation account is genuinely closed (zero lamports).
    let acct = ctx.get_account(obligation_pk).await.unwrap();
    let was_closed = match acct {
        None => true,
        Some(a) => a.lamports == 0,
    };
    assert!(
        was_closed,
        "klend should have closed the obligation account"
    );
}

// After the close-and-remove from the previous test, the same slot index must accept a brand-new
// obligation init. Klend re-derives the PDA from `(tag=0, id=0, ...)`, so the obligation address
// will be the same as the closed one — and klend creates a fresh account at that PDA.
#[tokio::test]
async fn test_close_then_reinit_same_slot() {
    let (mut ctx, markets, vault, obligation_pk_first) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk_first,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk_first,
        "SOL",
        u64::MAX,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    assert_eq!(vault.state(&mut ctx).await.get_obligations_count(), 0);

    // Klend's PDA is derived from `(tag, id, owner, lending_market, ...)` — all identical to the
    // closed obligation, so the new obligation's pubkey collides and klend recreates the account.
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk_second =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    assert_eq!(obligation_pk_first, obligation_pk_second);

    let state: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state.get_obligations_count(), 1);
    assert_eq!(state.obligations[0].obligation, obligation_pk_second);

    // The fresh obligation is usable.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk_second,
        "SOL",
        1_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
}

// `prev_aum` must refresh after a borrow — net AUM drops by exactly the origination fee.
#[tokio::test]
async fn test_borrow_obligation_refreshes_prev_aum() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let prev_aum_before = vault.state(&mut ctx).await.prev_aum();

    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    // Net AUM drops by exactly the origination fee (vault gains `liquidity_to_receive`; obligation
    // gains `liquidity_to_receive + origination_fee` of debt), so prev_aum drops by the same.
    let prev_aum_after = vault.state(&mut ctx).await.prev_aum();
    assert_gt!(prev_aum_before, prev_aum_after);
}

// Partial withdrawal must NOT trip the close-detection path: the obligation account stays alive
// and metavault's slot stays populated.
#[tokio::test]
async fn test_withdraw_obligation_collateral_partial_keeps_slot_populated() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    // Withdraw HALF, no active borrows: collateral remains in the obligation; klend does not
    // close.
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_500_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let state: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state.get_obligations_count(), 1);
    assert_eq!(state.obligations[0].obligation, obligation_pk);
    let acct = ctx.get_account(obligation_pk).await.unwrap();
    // Obligation account should remain alive after a partial withdraw.
    let lamports = acct.expect("obligation account must exist").lamports;
    assert_gt!(lamports, 0);
}

// `u64::MAX` withdrawal with an ACTIVE BORROW returns the LTV-bounded portion. Klend leaves the
// obligation populated (borrows are still outstanding), so metavault's slot must also stay.
#[tokio::test]
async fn test_withdraw_obligation_collateral_max_with_borrows_keeps_slot_populated() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        u64::MAX,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();

    let state: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state.get_obligations_count(), 1);
}

// When the vault has locked most of one mint's liquidity into an obligation as collateral, a user
// withdraw against that mint is capped at what's still free in `vault_token.available()`. The
// user burns shares only against the portion they actually received.
#[tokio::test]
async fn test_withdraw_blocked_when_liquidity_locked_in_obligation() {
    // Inlined setup: `client::try_withdraw` builds a bare withdraw and doesn't include an
    // obligation-refresh prelude, so post-init_obligation user ops trip `ObligationStale`. The
    // depositor + initial deposit must therefore happen BEFORE init_obligation.
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    // Lock 8 of the vault's 10 SOL into the obligation as collateral; only 2 SOL remain free.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        8_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let vault_sol_free_before = vault.balances(&mut ctx).await.token_vaults["SOL"];
    let depositor_sol_ata = *depositor.token_atas.get("SOL").unwrap();
    let depositor_sol_before = ctx
        .get_account(depositor_sol_ata)
        .await
        .unwrap()
        .map(|a| a.lamports)
        .unwrap_or(0);

    // Withdraw the full share balance against SOL — far more notional value than `vault_sol_free`.
    // Expected: partial fill, proportionally fewer shares burned.
    let shares_before = depositor.balances(&mut ctx).await.shares;
    withdraw_with_obligation_refresh_prelude(
        &mut ctx,
        &vault,
        &depositor,
        &sol_reserve,
        obligation_pk,
        market.market.pubkey(),
        shares_before,
        "SOL",
    )
    .await
    .unwrap();

    let vault_sol_free_after = vault.balances(&mut ctx).await.token_vaults["SOL"];
    let depositor_sol_after = ctx
        .get_account(depositor_sol_ata)
        .await
        .unwrap()
        .map(|a| a.lamports)
        .unwrap_or(0);
    let depositor_received = depositor_sol_after - depositor_sol_before;
    assert_lte!(depositor_received, vault_sol_free_before);
    assert_gt!(vault_sol_free_before, vault_sol_free_after);

    // Only a fraction of `shares_before` got burned (depositor's full share entitlement was
    // ~$3000 but only the free SOL was deliverable).
    let shares_after = depositor.balances(&mut ctx).await.shares;
    assert_gt!(shares_after, 0);
    assert_gt!(shares_before, shares_after);
}

// --- Negative-AUM integration tests ---
//
// Crashing the on-chain price through klend's oracle pipeline is too much setup for the marginal
// coverage. Instead `force_obligation_into_negative_aum` injects a synthetic borrow leg (on the
// obligation's own deposit reserve, so no extra reserve account is needed) with an oversized
// `borrowed_amount_sf` and marks both the obligation and that reserve fresh directly, so user-side
// ops (which have no refresh-obligation prelude) recompute AUM on this leg verbatim via
// `load_scope_prices_and_obligations_aum` — which values legs itself rather than trusting
// klend's cached obligation-level aggregates.

#[tokio::test]
async fn test_user_withdraw_under_negative_net_aum_fails() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    // Phantom debt (raw liquidity units, dominates any plausible SOL price) flips net AUM negative.
    let huge_borrowed_amount_sf = (Fraction::from_num(1_000_000_000_000_000_000_u64)).to_bits();
    force_obligation_into_negative_aum(
        &mut ctx,
        obligation_pk,
        sol_reserve.address.pubkey(),
        huge_borrowed_amount_sf,
    )
    .await;

    let shares = depositor.balances(&mut ctx).await.shares;
    let res = client::try_withdraw(&mut ctx, &vault, &depositor, shares, "SOL", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultAUMZero, 1),
    );
}

// `give_up_pending_fee` is the admin escape valve for absorbing a loss: it burns the vault's
// pending fee shares against the share supply to restore per-share value. The op must work even
// when net AUM is negative (that's its raison d'être) — and once the loss is reversed (here
// simulated by restoring the obligation's debt-value), subsequent user ops should resume normally.
#[tokio::test]
async fn test_give_up_pending_fee_under_negative_aum_and_recover() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    // Vault is now strictly net-negative on AUM.
    let huge_borrowed_amount_sf = (Fraction::from_num(1_000_000_000_000_000_000_u64)).to_bits();
    force_obligation_into_negative_aum(
        &mut ctx,
        obligation_pk,
        sol_reserve.address.pubkey(),
        huge_borrowed_amount_sf,
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;

    // Negative AUM → `charge_fees` inside takes the no-accrual branch; the give-up itself operates
    // on `pending_fees` (zero here, so effectively a no-op) and must not blow up.
    client::try_give_up_pending_fees(&mut ctx, &vault, &admin, u64::MAX)
        .await
        .unwrap();

    // Restore the phantom borrow leg to a dust amount → recovery. Our test depositor's ATAs are
    // drained, so we observe recovery at the state level: another no-op give_up_pending_fees call
    // must succeed and the obligations_aum read via `load_scope_prices_and_obligations_aum`
    // is non-negative again.
    let dust_borrowed_amount_sf = (Fraction::from_num(10_u64)).to_bits();
    force_obligation_into_negative_aum(
        &mut ctx,
        obligation_pk,
        sol_reserve.address.pubkey(),
        dust_borrowed_amount_sf,
    )
    .await;

    client::try_give_up_pending_fees(&mut ctx, &vault, &admin, u64::MAX)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_user_deposit_under_negative_net_aum_fails() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let huge_borrowed_amount_sf = (Fraction::from_num(1_000_000_000_000_000_000_u64)).to_bits();
    force_obligation_into_negative_aum(
        &mut ctx,
        obligation_pk,
        sol_reserve.address.pubkey(),
        huge_borrowed_amount_sf,
    )
    .await;

    let res = client::try_deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultAUMZero, 1),
    );
}

// Klend's liquidation reduces `deposits[i].deposited_amount` (seized) and
// `borrows[j].borrowed_amount_sf` (cleared) in lockstep. Driving the full liquidator pipeline
// would need price-oracle plumbing — `simulate_partial_liquidation` injects the *effect* directly.
#[tokio::test]
async fn test_partial_liquidation_of_obligation_keeps_slot_usable() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let state_before: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state_before.get_obligations_count(), 1);

    // Partial liquidation: 1 SOL out of 5 seized, ~$20 of debt cleared.
    let seized = 1_000_000_000;
    let cleared_debt_sf = (Fraction::from_num(20_u64)).to_bits();
    simulate_partial_liquidation(&mut ctx, obligation_pk, seized, cleared_debt_sf).await;

    let state_after_liq: MetavaultState = vault.state(&mut ctx).await;
    assert_eq!(state_after_liq.get_obligations_count(), 1);
    assert_eq!(state_after_liq.obligations[0].obligation, obligation_pk);

    // A subsequent obligation op (top-up collateral) against the partially-liquidated obligation
    // still succeeds. The obligation now has both a SOL deposit and a USDC borrow, so the refresh
    // prelude must include both reserves.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        500_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
}

// AUM-loader (`AumAccounts::parse` + `load_obligations_aum`) err-path tests:
//   - `ObligationStale`         — every registered obligation must be klend-refreshed in the
//                                  current slot, with all `PriceStatusFlags` bits set.
//   - `ObligationAccountMissing` — the remaining accounts must carry every obligation and leg
//                                  reserve slot.
//   - `RemainingAccountKeyMismatch` — each such slot must hold the account the vault registered.

#[tokio::test]
async fn test_obligations_aum_load_rejects_stale_obligation() {
    // User-side `deposit` builds a bare tx (no refresh prelude); once an obligation is registered
    // and a slot elapses, the staleness check in
    // `load_scope_prices_and_obligations_aum` fires.
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10_000_000_000 },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;

    let res = client::try_deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationStale, 1),
    );
}

#[tokio::test]
async fn test_obligations_aum_load_rejects_wrong_remaining_accounts_count() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10_000_000_000 },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;

    // Pass scope-only `remaining_accounts` so the length check fires before staleness can.
    let vault_token = vault.vault_tokens.get("SOL").unwrap();
    let scope_only = get_ordered_scope_accounts(&mut ctx, &vault).await;
    let bad_tx = metavault::program_test::instructions::deposit(
        &mut ctx,
        &vault,
        &depositor,
        vault_token,
        "SOL",
        scope_only,
        1_000_000_000,
        0,
    )
    .await;

    // Instruction index 1: metavault buy ix (after the leading compute-budget ix).
    let res = send_transaction!(ctx, bad_tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationAccountMissing, 1),
    );
}

// Trailing-account obligation pubkey doesn't match the vault's registered obligation — load fails
// at the `require_keys_eq` (length check passes; the key mismatch fires).
#[tokio::test]
async fn test_obligations_aum_load_rejects_wrong_obligation_pubkey() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10_000_000_000 },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;

    // A real klend obligation owned by an unrelated borrower — survives klend's account
    // resolution but is not in the vault's `iter_enabled_obligations()` set.
    let stranger =
        kamino_lending::program_test::common::setup::new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;

    let vault_state = vault.state(&mut ctx).await;
    let mut scope_and_obligation =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    // Index the obligation slot explicitly (right after the scope segment): if the fixture ever
    // grows obligation legs, `last_mut()` would land on a leg reserve instead and this test
    // would silently stop covering the obligation key check.
    scope_and_obligation[vault_state.get_tokens_count()] = stranger.obligation;

    let vault_token = vault.vault_tokens.get("SOL").unwrap();
    let bad_tx = metavault::program_test::instructions::deposit(
        &mut ctx,
        &vault,
        &depositor,
        vault_token,
        "SOL",
        scope_and_obligation,
        1_000_000_000,
        0,
    )
    .await;
    let res = send_transaction!(ctx, bad_tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 1),
    );
}

// User-side `withdraw` mirrors `deposit`: once an obligation is registered it must be refreshed
// in the same slot, else the staleness gate trips.
#[tokio::test]
async fn test_obligations_aum_load_rejects_stale_obligation_on_withdraw() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10_000_000_000 },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;

    // Bare withdraw (no refresh prelude) — once obligation registered, staleness gate fires.
    let res = client::try_withdraw(&mut ctx, &vault, &depositor, 1_000_000, "SOL", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationStale, 1),
    );
}

// Mirrors `test_obligations_aum_load_rejects_wrong_obligation_pubkey` for user-side `withdraw`.
#[tokio::test]
async fn test_obligations_aum_load_rejects_wrong_obligation_pubkey_on_withdraw() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! { "SOL".to_string() => 10_000_000_000 },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;

    let stranger =
        kamino_lending::program_test::common::setup::new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;

    let vault_state = vault.state(&mut ctx).await;
    let mut scope_and_obligation =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    // Index the obligation slot explicitly (right after the scope segment) — see
    // `test_obligations_aum_load_rejects_wrong_obligation_pubkey`.
    scope_and_obligation[vault_state.get_tokens_count()] = stranger.obligation;

    let vault_token = vault.vault_tokens.get("SOL").unwrap();
    let bad_ix = withdraw_ix(
        metavault::ID,
        &vault,
        &depositor,
        vault_token,
        "SOL",
        scope_and_obligation,
        1_000_000,
        0,
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    let bad_tx = ctx
        .create_transaction_with_payer([cu_ix, bad_ix], &depositor.owner)
        .await;
    let res = send_transaction!(ctx, bad_tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 1),
    );
}

// Round-trip borrow → time advance → repay; the vault repays strictly more USDC than it
// received, proving the obligation ops fold in accrued interest.
#[tokio::test]
async fn test_borrow_repay_with_interest_accrual() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let usdc_before_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    let usdc_after_borrow = vault.balances(&mut ctx).await.token_vaults["USDC"];
    let usdc_received = usdc_after_borrow - usdc_before_borrow;
    assert_gt!(usdc_received, 0);

    // Advance one day so interest accrues on the outstanding USDC debt. Scope feeds went stale
    // along with the clock, so re-publish them at the same nominal prices before refresh.
    ctx.fast_forward_hours(24).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        u64::MAX,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    let usdc_after_repay = vault.balances(&mut ctx).await.token_vaults["USDC"];
    let usdc_repaid = usdc_after_borrow - usdc_after_repay;

    // Repaid strictly more than received — interest folded into the repay amount.
    assert_gt!(usdc_repaid, usdc_received);
}

// --- Elevation-group integration tests ---

#[tokio::test]
async fn test_deposit_obligation_collateral_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    // Klend requires the obligation to have at least one deposit before joining a group, so seed
    // it with SOL collateral first.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    // Second deposit while already in the group: exercises klend's
    // `update_elevation_group_debt_trackers_on_new_deposit` no-op branch (no outstanding debt).
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        3_000_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let obligation_acct = ctx.get_account(obligation_pk).await.unwrap().unwrap();
    let obligation: &Obligation = bytemuck::from_bytes(&obligation_acct.data[8..]);
    assert_eq!(obligation.elevation_group, TEST_ELEVATION_GROUP_ID);
}

#[tokio::test]
async fn test_withdraw_obligation_collateral_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    // Partial withdraw with no active borrows (group membership must not break the op).
    client::try_withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn test_borrow_obligation_liquidity_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    // Elevation group's higher LTV (90% vs default 70%) lifts the cap above $350.
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        400_000_000, // $400 — would exceed default-LTV cap of $350
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn test_repay_obligation_liquidity_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    // Klend's `update_elevation_group_debt_trackers_on_repay` iterates the obligation's active
    // deposits and requires one matching deposit reserve per active deposit in remaining_accounts.
    // `cpi_repay_obligation_liquidity` now forwards them; the test client passes them as the
    // `obligation_deposit_reserves` arg (same vec already used by the refresh prelude).
    let vault_usdc_before = vault.balances(&mut ctx).await.token_vaults["USDC"];
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    let vault_usdc_after = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_eq!(vault_usdc_after, vault_usdc_before - 50_000_000);
}

// Pins the contract that on repay against an elevation-group obligation, klend asserts pairwise
// equality between `obligation.active_deposits_mut()` and the deposit reserves in
// remaining_accounts — same order, no extras.
#[tokio::test]
async fn test_repay_obligation_liquidity_in_elevation_group_multi_collateral() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_three_reserve_spec(), vec![5, 5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let usdt_reserve = markets.markets[0].reserves["USDT"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
            "USDT".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    // Elevation group covering all three reserves: USDC as debt, SOL + USDT as collateral.
    let usdc_reserve_pk = usdc_reserve.address.pubkey();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC", "USDT"],
        &[ElevationGroup {
            id: TEST_ELEVATION_GROUP_ID,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 2,
            debt_reserve: usdc_reserve_pk,
            ..Default::default()
        }],
    )
    .await;

    // Both collaterals deposited first so `request_elevation_group` sees an obligation satisfying
    // the group's `max_reserves_as_collateral`.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_pk,
        "USDT",
        500_000_000, // $500
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve, &usdt_reserve],
        vec![],
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve, &usdt_reserve],
        vec![],
    )
    .await
    .unwrap();

    // `obligation.deposits[]` is in insertion order (SOL, then USDT); remaining_accounts must
    // match.
    let vault_usdc_before = vault.balances(&mut ctx).await.token_vaults["USDC"];
    client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        vec![&sol_reserve, &usdt_reserve],
        vec![&usdc_reserve],
    )
    .await
    .unwrap();
    let vault_usdc_after = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert_eq!(vault_usdc_after, vault_usdc_before - 50_000_000);
}

// Plain enter: zero → group_id. Asserts the stored elevation_group on the obligation.
#[tokio::test]
async fn test_request_elevation_group_enter() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_obligation_elevation_group(&mut ctx, obligation_pk, TEST_ELEVATION_GROUP_ID).await;
}

// Leave: enter a group, then request `0` to return to no-group. Asserts elevation_group cleared.
#[tokio::test]
async fn test_request_elevation_group_leave() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        0, // ELEVATION_GROUP_NONE
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_obligation_elevation_group(&mut ctx, obligation_pk, 0).await;
}

// Switch directly from one non-zero group to another. Requires the market to register both.
#[tokio::test]
async fn test_request_elevation_group_switch_between_groups() {
    const GROUP_A: u8 = 1;
    const GROUP_B: u8 = 2;
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    let usdc_reserve_pk = usdc_reserve.address.pubkey();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[
            ElevationGroup {
                id: GROUP_A,
                max_liquidation_bonus_bps: 500,
                ltv_pct: 90,
                liquidation_threshold_pct: 95,
                allow_new_loans: 1,
                max_reserves_as_collateral: 1,
                debt_reserve: usdc_reserve_pk,
                ..Default::default()
            },
            ElevationGroup {
                id: GROUP_B,
                max_liquidation_bonus_bps: 500,
                ltv_pct: 85,
                liquidation_threshold_pct: 92,
                allow_new_loans: 1,
                max_reserves_as_collateral: 1,
                debt_reserve: usdc_reserve_pk,
                ..Default::default()
            },
        ],
    )
    .await;

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        GROUP_A,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        GROUP_B,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_obligation_elevation_group(&mut ctx, obligation_pk, GROUP_B).await;
}

// An elevation-group switch changes the exact risk envelope the LTV ceiling measures (liquidation
// thresholds, borrow factors) without moving tokens, and klend only enforces the destination
// group's own max-LTV allowance — which can be looser than the vault ceiling. The switch must
// re-check the configured ceiling against the destination group's aggregates.
//
// Numbers: $200 SOL collateral, $100 USDC debt, ceiling 5_300 bps.
// Group A (threshold 95%): allowed = 0.53 × $190 = $100.70 ≥ $100 — the position is legal.
// Group B (threshold 92%): klend permits the switch (max LTV 0.85 × $200 = $170 ≥ $100), but the
// vault allows only 0.53 × $184 = $97.52 < $100 — the switch must fail and roll back.
#[tokio::test]
async fn test_request_elevation_group_blocked_by_obligation_ltv_ceiling() {
    const GROUP_A: u8 = 1;
    const GROUP_B: u8 = 2;
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    let usdc_reserve_pk = usdc_reserve.address.pubkey();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[
            ElevationGroup {
                id: GROUP_A,
                max_liquidation_bonus_bps: 500,
                ltv_pct: 90,
                liquidation_threshold_pct: 95,
                allow_new_loans: 1,
                max_reserves_as_collateral: 1,
                debt_reserve: usdc_reserve_pk,
                ..Default::default()
            },
            ElevationGroup {
                id: GROUP_B,
                max_liquidation_bonus_bps: 500,
                ltv_pct: 85,
                liquidation_threshold_pct: 92,
                allow_new_loans: 1,
                max_reserves_as_collateral: 1,
                debt_reserve: usdc_reserve_pk,
                ..Default::default()
            },
        ],
    )
    .await;

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        GROUP_A,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation_pk, 5_300),
    )
    .await
    .unwrap();

    let res = client::try_request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        GROUP_B,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    // ix index 4: CU + refresh SOL + refresh USDC + refresh obligation precede the main ix.
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationLtvCeilingExceeded, 4)
    );
    // The failed switch rolls back atomically: still in group A.
    assert_obligation_elevation_group(&mut ctx, obligation_pk, GROUP_A).await;
}

// The mirror direction: a switch that improves the ceiling ratio and lands under the ceiling must
// pass — even from a position currently above it. Same numbers as the blocking test, but the
// position starts in the worse group B ($100 debt > allowed 0.53 × $184 = $97.52, legal to hold
// since the ceiling only gates operations) and moves to group A (allowed 0.53 × $190 = $100.70).
// Also pins that the check evaluates the destination group's aggregates, not the source's.
#[tokio::test]
async fn test_request_elevation_group_improving_switch_within_ceiling_succeeds() {
    const GROUP_A: u8 = 1;
    const GROUP_B: u8 = 2;
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    let usdc_reserve_pk = usdc_reserve.address.pubkey();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[
            ElevationGroup {
                id: GROUP_A,
                max_liquidation_bonus_bps: 500,
                ltv_pct: 90,
                liquidation_threshold_pct: 95,
                allow_new_loans: 1,
                max_reserves_as_collateral: 1,
                debt_reserve: usdc_reserve_pk,
                ..Default::default()
            },
            ElevationGroup {
                id: GROUP_B,
                max_liquidation_bonus_bps: 500,
                ltv_pct: 85,
                liquidation_threshold_pct: 92,
                allow_new_loans: 1,
                max_reserves_as_collateral: 1,
                debt_reserve: usdc_reserve_pk,
                ..Default::default()
            },
        ],
    )
    .await;

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        GROUP_B,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation_pk, 5_300),
    )
    .await
    .unwrap();

    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        GROUP_A,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    assert_obligation_elevation_group(&mut ctx, obligation_pk, GROUP_A).await;
}

// Requesting the group already active is a klend `ElevationGroupAlreadyActivated`.
#[tokio::test]
async fn test_request_elevation_group_rejects_already_activated() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_elevation_group_market().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        2_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    let res = client::try_request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    // ix index 3: main metavault ix sits after CU + refresh_reserve + refresh_obligation.
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::ElevationGroupAlreadyActivated, 3),
    );
}

// Trying to enter a group with `max_reserves_as_collateral` below the obligation's deposit count
// is a klend `ObligationCollateralExceedsElevationGroupLimit`.
#[tokio::test]
async fn test_request_elevation_group_rejects_too_many_collaterals() {
    const NARROW_GROUP: u8 = 1;
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_three_reserve_spec(), vec![5, 5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let usdt_reserve = markets.markets[0].reserves["USDT"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
            "USDT".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC", "USDT"],
        &[ElevationGroup {
            id: NARROW_GROUP,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 1, // narrower than the 2 deposits we'll have
            debt_reserve: usdc_reserve.address.pubkey(),
            ..Default::default()
        }],
    )
    .await;

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_pk,
        "USDT",
        500_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    let res = client::try_request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        NARROW_GROUP,
        vec![&sol_reserve, &usdt_reserve],
        vec![],
    )
    .await;
    // ix index 4: prelude is CU + 2× refresh_reserve + refresh_obligation.
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(
            LendingError::ObligationCollateralExceedsElevationGroupLimit,
            4
        ),
    );
}

// --- Helpers ---

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        // USDC reserve seeded with 10,000 USDC so we can borrow against SOL.
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

// Three-reserve spec used by the multi-collateral elevation-group repay test.
fn make_three_reserve_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("USDT", 0),
        ])],
    }
}

fn make_four_reserve_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
            "PYUSD".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("USDT", 0),
            RSpec::new("PYUSD", 10_000_000_000),
        ])],
    }
}

// Builds a 50/50 SOL/USDC metavault, seeds it with 10 SOL + 2000 USDC, and inits a fresh
// obligation (id 0).
async fn setup_vault_with_obligation() -> (TestContext, KaminoMarkets, VaultAccounts, Pubkey) {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    (ctx, markets, vault, obligation_pk)
}

async fn init_metavault_obligation_farm_for_reserve(
    ctx: &mut TestContext,
    payer: &KP,
    reserve: &ReserveAccounts,
    obligation_owner: Pubkey,
    obligation: Pubkey,
    farm_kind: ReserveFarmKind,
) {
    let reserve_state = ctx.get_reserve(reserve).await;
    let reserve_farm_state = reserve_state.get_farm(farm_kind);
    assert_ne!(reserve_farm_state, Pubkey::default());

    let accounts = kamino_lending::accounts::InitObligationFarmsForReserve {
        payer: payer.pubkey(),
        owner: obligation_owner,
        obligation,
        lending_market: reserve.lending_market,
        lending_market_authority: reserve.lending_market_authority,
        reserve: reserve.address.pubkey(),
        obligation_farm: Pubkey::find_program_address(
            &[b"user", reserve_farm_state.as_ref(), obligation.as_ref()],
            &FARMS_PROGRAM_ID,
        )
        .0,
        reserve_farm_state,
        rent: solana_sdk::sysvar::rent::ID,
        farms_program: FARMS_PROGRAM_ID,
        system_program: System::id(),
    }
    .to_account_metas(None);

    let instruction = Instruction {
        program_id: kamino_lending::ID,
        accounts,
        data: kamino_lending::instruction::InitObligationFarmsForReserve {
            mode: farm_kind as u8,
        }
        .data(),
    };
    let tx = ctx
        .create_transaction_with_payer([instruction], payer)
        .await;
    send_transaction!(ctx, tx).unwrap();
}

async fn set_onchain_reserve_farms(
    ctx: &mut TestContext,
    reserve: &ReserveAccounts,
    collateral_farm: Pubkey,
    debt_farm: Pubkey,
) {
    let mut reserve_state = ctx.get_reserve(reserve).await;
    reserve_state.farm_collateral = collateral_farm;
    reserve_state.farm_debt = debt_farm;
    update_reserve(ctx, &reserve_state, &reserve.address.pubkey()).await;

    let reserve_state = ctx.get_reserve(reserve).await;
    assert_eq!(reserve_state.farm_collateral, collateral_farm);
    assert_eq!(reserve_state.farm_debt, debt_farm);
}

const TEST_ELEVATION_GROUP_ID: u8 = 1;

fn make_test_elevation_group(usdc_reserve_pk: Pubkey) -> ElevationGroup {
    ElevationGroup {
        id: TEST_ELEVATION_GROUP_ID,
        max_liquidation_bonus_bps: 500,
        ltv_pct: 90, // higher than the default reserve LTV (70) — observable effect
        liquidation_threshold_pct: 95,
        allow_new_loans: 1,
        max_reserves_as_collateral: 1,
        debt_reserve: usdc_reserve_pk,
        ..Default::default()
    }
}

// Common setup: standard vault + obligation, market configured with a test elevation group
// covering SOL (collateral) + USDC (debt). The obligation is *not yet* in the group.
async fn setup_vault_with_elevation_group_market(
) -> (TestContext, KaminoMarkets, VaultAccounts, Pubkey) {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let usdc_reserve_pk = markets.markets[0].reserves["USDC"].address.pubkey();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[make_test_elevation_group(usdc_reserve_pk)],
    )
    .await;
    (ctx, markets, vault, obligation_pk)
}

async fn assert_obligation_elevation_group(
    ctx: &mut TestContext,
    obligation_pk: Pubkey,
    expected: u8,
) {
    let acct = ctx.get_account(obligation_pk).await.unwrap().unwrap();
    let obligation: &Obligation = bytemuck::from_bytes(&acct.data[8..]);
    assert_eq!(obligation.elevation_group, expected);
}

#[allow(clippy::too_many_arguments)]
async fn borrow_obligation_liquidity_with_forwarded_deposit_reserves(
    ctx: &mut TestContext,
    vault_admin: &KP,
    vault: &VaultAccounts,
    market: &kamino_lending::program_test::common::types::LendingMarketAccounts,
    borrow_reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    prelude_deposit_reserves: Vec<&ReserveAccounts>,
    prelude_borrow_reserves: Vec<&ReserveAccounts>,
    forwarded_deposit_reserves: Vec<Pubkey>,
) -> Result<(), BanksClientError> {
    let vault_token = vault.vault_tokens.get(token_name).unwrap();
    let mut accounts = metavault::accounts::BorrowObligationLiquidity {
        authority: vault_admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        borrow_reserve: borrow_reserve.address.pubkey(),
        borrow_reserve_liquidity_mint: borrow_reserve.liquidity_mint.pubkey(),
        reserve_source_liquidity: borrow_reserve.liquidity_supply,
        borrow_reserve_liquidity_fee_receiver: borrow_reserve.fee_receiver,
        token_vault: vault_token.token_vault,
        token_program: borrow_reserve.liquidity_mint_token_program,
        instruction_sysvar_account: solana_program::sysvar::instructions::ID,
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
    .to_account_metas(None);

    for account in get_ordered_scope_and_obligation_accounts(ctx, vault).await {
        accounts.push(AccountMeta::new_readonly(account, false));
    }
    for reserve in forwarded_deposit_reserves {
        accounts.push(AccountMeta::new(reserve, false));
    }

    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts,
        data: metavault::instruction::BorrowObligationLiquidity { liquidity_amount }.data(),
    };

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    let mut all_ixs = vec![cu_ix, build_klend_refresh_reserve_ix(borrow_reserve)];
    for reserve in &prelude_deposit_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(reserve));
    }
    for reserve in &prelude_borrow_reserves {
        if reserve.address.pubkey() != borrow_reserve.address.pubkey() {
            all_ixs.push(build_klend_refresh_reserve_ix(reserve));
        }
    }
    all_ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        market.market.pubkey(),
        &prelude_deposit_reserves,
        &prelude_borrow_reserves,
    ));
    all_ixs.push(main_ix);

    let tx = ctx
        .create_transaction_with_payer(all_ixs, vault_admin)
        .await;
    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
async fn repay_obligation_liquidity_with_forwarded_deposit_reserves(
    ctx: &mut TestContext,
    vault_admin: &KP,
    vault: &VaultAccounts,
    market: &kamino_lending::program_test::common::types::LendingMarketAccounts,
    repay_reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    prelude_deposit_reserves: Vec<&ReserveAccounts>,
    prelude_borrow_reserves: Vec<&ReserveAccounts>,
    forwarded_deposit_reserves: Vec<Pubkey>,
) -> Result<(), BanksClientError> {
    let vault_token = vault.vault_tokens.get(token_name).unwrap();
    let mut accounts = metavault::accounts::RepayObligationLiquidity {
        authority: vault_admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        repay_reserve: repay_reserve.address.pubkey(),
        reserve_liquidity_mint: repay_reserve.liquidity_mint.pubkey(),
        reserve_destination_liquidity: repay_reserve.liquidity_supply,
        token_vault: vault_token.token_vault,
        token_program: repay_reserve.liquidity_mint_token_program,
        instruction_sysvar_account: solana_program::sysvar::instructions::ID,
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
    .to_account_metas(None);

    for account in get_ordered_scope_and_obligation_accounts(ctx, vault).await {
        accounts.push(AccountMeta::new_readonly(account, false));
    }
    for reserve in forwarded_deposit_reserves {
        accounts.push(AccountMeta::new(reserve, false));
    }

    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts,
        data: metavault::instruction::RepayObligationLiquidity { liquidity_amount }.data(),
    };

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    let mut all_ixs = vec![cu_ix, build_klend_refresh_reserve_ix(repay_reserve)];
    for reserve in &prelude_deposit_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(reserve));
    }
    for reserve in &prelude_borrow_reserves {
        if reserve.address.pubkey() != repay_reserve.address.pubkey() {
            all_ixs.push(build_klend_refresh_reserve_ix(reserve));
        }
    }
    all_ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        market.market.pubkey(),
        &prelude_deposit_reserves,
        &prelude_borrow_reserves,
    ));
    all_ixs.push(main_ix);

    let tx = ctx
        .create_transaction_with_payer(all_ixs, vault_admin)
        .await;
    send_transaction!(ctx, tx)
}

// Reads the obligation, hands `f` a `&mut Obligation` plus the current root slot, writes back.
// Lets us inject klend-side state we can't easily drive end-to-end (negative-AUM debt, partial
// liquidation).
async fn mutate_obligation<F>(ctx: &mut TestContext, obligation_pk: Pubkey, f: F)
where
    F: FnOnce(&mut Obligation, u64),
{
    let account = ctx
        .get_account(obligation_pk)
        .await
        .unwrap()
        .expect("obligation must exist");
    let current_slot = ctx.get_current_slot().await;
    let mut data = account.data.clone();
    // Anchor layout: 8-byte discriminator + zero-copy Obligation.
    let obligation: &mut Obligation = bytemuck::from_bytes_mut(&mut data[8..]);
    f(obligation, current_slot);
    let mut new_account =
        AccountSharedData::new(account.lamports, account.data.len(), &account.owner);
    new_account.set_data(data);
    ctx.set_account(&obligation_pk, new_account);
}

// Marks the obligation `ALL_CHECKS`-fresh so metavault ops without a refresh prelude pass the
// staleness gate.
fn mark_obligation_fresh(obligation: &mut Obligation, slot: u64) {
    obligation
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());
}

// Mirrors `mutate_obligation` for a klend `Reserve` account — needed because
// `load_scope_prices_and_obligations_aum` reads each leg's reserve directly (not just the
// obligation), so tests that fabricate obligation legs must also mark the referenced reserve fresh.
async fn mutate_reserve<F>(ctx: &mut TestContext, reserve_pk: Pubkey, f: F)
where
    F: FnOnce(&mut Reserve, u64),
{
    let account = ctx
        .get_account(reserve_pk)
        .await
        .unwrap()
        .expect("reserve must exist");
    let current_slot = ctx.get_current_slot().await;
    let mut data = account.data.clone();
    // Anchor layout: 8-byte discriminator + zero-copy Reserve.
    let reserve: &mut Reserve =
        bytemuck::from_bytes_mut(&mut data[8..8 + std::mem::size_of::<Reserve>()]);
    f(reserve, current_slot);
    let mut new_account =
        AccountSharedData::new(account.lamports, account.data.len(), &account.owner);
    new_account.set_data(data);
    ctx.set_account(&reserve_pk, new_account);
}

fn mark_reserve_fresh(reserve: &mut Reserve, slot: u64) {
    reserve
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());
}

// Forces net AUM negative by injecting a synthetic borrow leg on `borrow_reserve_pk` (in practice
// the same reserve the test already used for a deposit leg, so no extra remaining-account is
// needed) with an oversized `borrowed_amount` — raw liquidity units, not a dollar value: the new
// loader converts legs through the reserve's own decimals and the vault's scope price, so the
// amount must be large enough to dominate regardless of that price. Also freshens the reserve
// directly (bypassing klend's real `refresh_reserve`, which would be harmless here but is
// unnecessary plumbing) since the loader now requires every leg reserve to be current-slot-fresh.
async fn force_obligation_into_negative_aum(
    ctx: &mut TestContext,
    obligation_pk: Pubkey,
    borrow_reserve_pk: Pubkey,
    new_borrowed_amount_sf: u128,
) {
    mutate_obligation(ctx, obligation_pk, |obligation, current_slot| {
        obligation.borrows[0] = kamino_lending::ObligationLiquidity {
            borrow_reserve: borrow_reserve_pk,
            borrowed_amount_sf: new_borrowed_amount_sf,
            ..Default::default()
        };
        mark_obligation_fresh(obligation, current_slot);
    })
    .await;
    mutate_reserve(ctx, borrow_reserve_pk, |reserve, current_slot| {
        mark_reserve_fresh(reserve, current_slot);
    })
    .await;
}

async fn simulate_partial_liquidation(
    ctx: &mut TestContext,
    obligation_pk: Pubkey,
    seized_ctokens: u64,
    cleared_debt_amount_sf: u128,
) {
    mutate_obligation(ctx, obligation_pk, |obligation, current_slot| {
        let deposit = obligation
            .deposits
            .iter_mut()
            .find(|d| d.deposit_reserve != Pubkey::default())
            .expect("obligation must have at least one deposit");
        deposit.deposited_amount = deposit.deposited_amount.saturating_sub(seized_ctokens);
        let borrow = obligation
            .borrows
            .iter_mut()
            .find(|b| b.borrow_reserve != Pubkey::default())
            .expect("obligation must have at least one borrow");
        borrow.borrowed_amount_sf = borrow
            .borrowed_amount_sf
            .saturating_sub(cleared_debt_amount_sf);
        mark_obligation_fresh(obligation, current_slot);
    })
    .await;
}

async fn refresh_obligation_for_test(
    ctx: &mut TestContext,
    payer: &KP,
    lending_market: Pubkey,
    obligation: Pubkey,
    deposit_reserves: &[&ReserveAccounts],
    borrow_reserves: &[&ReserveAccounts],
) -> Result<(), BanksClientError> {
    let mut seen = Vec::new();
    let mut ixs = vec![ComputeBudgetInstruction::set_compute_unit_limit(400_000)];
    for reserve in deposit_reserves.iter().chain(borrow_reserves.iter()) {
        let reserve_pk = reserve.address.pubkey();
        if !seen.contains(&reserve_pk) {
            seen.push(reserve_pk);
            ixs.push(build_klend_refresh_reserve_ix(reserve));
        }
    }
    ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        lending_market,
        deposit_reserves,
        borrow_reserves,
    ));
    let tx = ctx.create_transaction_with_payer(ixs, payer).await;
    send_transaction!(ctx, tx)
}

#[tokio::test]
async fn test_emergency_mode_blocks_rebalance_swap_but_allows_admin_obligation_ops() {
    let (mut ctx, markets, vault, obligation_pk) = setup_vault_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;

    // rebalance_swap (permissionless) is frozen during emergency mode.
    let res = client::try_rebalance_swap(
        &mut ctx,
        &admin,
        &vault,
        "SOL",
        "USDC",
        1_000_000,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultEmergencyMode, 1)
    );

    // An admin-gated obligation op still succeeds during emergency mode (stays open).
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
}

// User-side `withdraw` tx with a `refresh_reserve + refresh_obligation` prelude — required once
// any obligation has been registered, else the staleness gate trips. The plain
// `client::try_withdraw` builds a bare tx; production needs the same prelude on the SDK side.
#[allow(clippy::too_many_arguments)]
async fn withdraw_with_obligation_refresh_prelude(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    obligation_deposit_reserve: &kamino_lending::program_test::common::types::ReserveAccounts,
    obligation_pk: Pubkey,
    lending_market_pk: Pubkey,
    shares_amount: u64,
    token_name: &str,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let vault_token = vault.vault_tokens.get(token_name).unwrap();
    let main_ix = withdraw_ix(
        metavault::ID,
        vault,
        depositor,
        vault_token,
        token_name,
        scope_and_obligation_accounts,
        shares_amount,
        /* min_tokens_out */ 0,
    );
    let refresh_reserve = build_klend_refresh_reserve_ix(obligation_deposit_reserve);
    let refresh_obligation = build_klend_refresh_obligation_ix(
        obligation_pk,
        lending_market_pk,
        &[obligation_deposit_reserve],
        &[],
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    let tx = ctx
        .create_transaction_with_payer(
            [cu_ix, refresh_reserve, refresh_obligation, main_ix],
            &depositor.owner,
        )
        .await;
    send_transaction!(ctx, tx)
}

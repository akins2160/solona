use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::program_test::common::math::usdc_decimal_to_u64;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_vault_admin_controls_emergency_council_and_flags() {
    let (mut ctx, vault, admin, council, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let initial_state = vault.state(&mut ctx).await;
    assert_eq!(
        initial_state.emergency_council,
        solana_program::pubkey::Pubkey::default()
    );
    assert_eq!(
        initial_state.unfreeze_authority,
        solana_program::pubkey::Pubkey::default()
    );
    assert_eq!(initial_state.emergency_mode, 0);
    assert_eq!(initial_state.block_deposits, 0);
    assert_eq!(initial_state.block_withdraws, 0);

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyCouncil(council.owner.pubkey()),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(true),
    )
    .await;

    let enabled_state = vault.state(&mut ctx).await;
    assert_eq!(enabled_state.emergency_council, council.owner.pubkey());
    assert_eq!(enabled_state.emergency_mode, 1);
    assert_eq!(enabled_state.block_deposits, 1);
    assert_eq!(enabled_state.block_withdraws, 1);

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(false),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(false),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(false),
    )
    .await;

    let disabled_state = vault.state(&mut ctx).await;
    assert_eq!(disabled_state.emergency_mode, 0);
    assert_eq!(disabled_state.block_deposits, 0);
    assert_eq!(disabled_state.block_withdraws, 0);
}

#[tokio::test]
async fn test_emergency_council_is_enable_only_and_limited() {
    let (mut ctx, vault, admin, council, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyCouncil(council.owner.pubkey()),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &council.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &council.owner,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &council.owner,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(true),
    )
    .await;

    let state = vault.state(&mut ctx).await;
    assert_eq!(state.emergency_mode, 1);
    assert_eq!(state.block_deposits, 1);
    assert_eq!(state.block_withdraws, 1);

    let disable_res = client::try_update_vault_config(
        &mut ctx,
        &council.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(false),
    )
    .await;
    assert_eq!(
        disable_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );

    let set_council_res = client::try_update_vault_config(
        &mut ctx,
        &council.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyCouncil(admin.pubkey()),
    )
    .await;
    assert_eq!(
        set_council_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );

    let unrelated_res = client::try_update_vault_config(
        &mut ctx,
        &council.owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(10),
    )
    .await;
    assert_eq!(
        unrelated_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );
}

#[tokio::test]
async fn test_unfreeze_authority_is_disable_only_and_limited() {
    let (mut ctx, vault, admin, unfreeze_authority, _mkts) =
        fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::UnfreezeAuthority(unfreeze_authority.owner.pubkey()),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(true),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &unfreeze_authority.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(false),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &unfreeze_authority.owner,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(false),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &unfreeze_authority.owner,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(false),
    )
    .await;

    let state = vault.state(&mut ctx).await;
    assert_eq!(state.unfreeze_authority, unfreeze_authority.owner.pubkey());
    assert_eq!(state.emergency_mode, 0);
    assert_eq!(state.block_deposits, 0);
    assert_eq!(state.block_withdraws, 0);

    let freeze_res = client::try_update_vault_config(
        &mut ctx,
        &unfreeze_authority.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;
    assert_eq!(
        freeze_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );

    let rotate_res = client::try_update_vault_config(
        &mut ctx,
        &unfreeze_authority.owner,
        &vault,
        UpdateVaultConfigParams::UnfreezeAuthority(admin.pubkey()),
    )
    .await;
    assert_eq!(
        rotate_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );

    let unrelated_res = client::try_update_vault_config(
        &mut ctx,
        &unfreeze_authority.owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(10),
    )
    .await;
    assert_eq!(
        unrelated_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );
}

#[tokio::test]
async fn test_signer_that_is_council_and_unfreeze_can_set_emergency_flags_both_ways() {
    let (mut ctx, vault, admin, emergency_authority, _mkts) =
        fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyCouncil(emergency_authority.owner.pubkey()),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::UnfreezeAuthority(emergency_authority.owner.pubkey()),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &emergency_authority.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;
    assert_eq!(vault.state(&mut ctx).await.emergency_mode, 1);

    client::update_vault_config(
        &mut ctx,
        &emergency_authority.owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(false),
    )
    .await;
    assert_eq!(vault.state(&mut ctx).await.emergency_mode, 0);
}

#[tokio::test]
async fn test_emergency_flags_block_buy_and_sell() {
    let (mut ctx, vault, admin, _council, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(300.0)).await;

    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    let shares = depositor.balances(&mut ctx).await.shares;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;
    let deposit_res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        deposit_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultEmergencyMode, 1)
    );
    let withdraw_res =
        client::try_withdraw(&mut ctx, &vault, &depositor, shares / 2, "USDC", 0).await;
    assert_eq!(
        withdraw_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultEmergencyMode, 1)
    );

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(false),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    let deposit_res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        deposit_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultDepositsBlocked, 1)
    );

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(false),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(true),
    )
    .await;
    let withdraw_res =
        client::try_withdraw(&mut ctx, &vault, &depositor, shares / 2, "USDC", 0).await;
    assert_eq!(
        withdraw_res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultWithdrawsBlocked, 1)
    );
}

#[tokio::test]
async fn test_emergency_mode_config_recovery_is_open() {
    let (mut ctx, vault, admin, _council, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(300.0)).await;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;

    // Deposits are frozen while emergency mode is on.
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultEmergencyMode, 1)
    );

    // Config update to clear emergency is NOT frozen (recovery path stays open).
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(false),
    )
    .await;
    assert_eq!(vault.state(&mut ctx).await.emergency_mode, 0);

    // Deposits work again after recovery.
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0)).await;
}

use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{
    assert_almost_eq_fraction,
    fraction::Fraction,
    program_test::common::math::usdc_decimal_to_u64,
    utils::{FractionExtra, FULL_BPS},
};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup, usdc_u64_to_decimal,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, MAX_CHARGED_RATE_FOR_VAULT_FEE, YEAR},
    KaminoVaultError,
};

use metavault::types::RoundingMethod;
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_give_up_pending_fees_aum_above_0_only_mgmt_fee() {
    let (mut ctx, vault, owner, _, _) = fixtures::setup_markets_and_reserves(0).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(120),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, topup - 1);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        topup + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state.pending_fees_sf, 0);
    assert_almost_eq_fraction!(
        Fraction::from_num(usdc_u64_to_decimal(topup + INITIAL_DEPOSIT_SIZE)),
        Fraction::from_bits(vault_state.prev_aum_sf)
    );

    // advance 30 days
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    let vault_state = vault.state(&mut ctx).await;
    let mgmt_fee = Fraction::from(120 * u64::from(YEAR) / 12)
        / Fraction::from(u64::from(YEAR) * u64::from(FULL_BPS));
    let expected_mgmt_fee: Fraction = (Fraction::from(vault_state.shares_issued) * mgmt_fee
        / (Fraction::ONE - mgmt_fee))
        .to_floor();

    // user withdraw half of the shares
    let withdraw = depositor.balances(&mut ctx).await.shares / 2;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let expected_user_fee = topup / 1000;
    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        (topup - expected_user_fee) / 2 - 1
    );
    assert_eq!(balances_after.shares, topup - 1 - withdraw);

    let vault_state_before_give_up = vault.state(&mut ctx).await;
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_before_give_up.pending_fees_sf),
        expected_mgmt_fee
    );
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_before_give_up.prev_aum_sf),
        Fraction::from_num(usdc_u64_to_decimal(
            (topup + expected_user_fee) / 2 + INITIAL_DEPOSIT_SIZE * 999 / 1000
        ))
    );

    // give up 10 lamports out of the pending fees
    let amount_to_give_up = 10;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    client::give_up_pending_fees(&mut ctx, &vault, &owner, amount_to_give_up).await;

    let vault_state_after_give_up = vault.state(&mut ctx).await;

    assert_eq!(
        Fraction::from_bits(vault_state_before_give_up.pending_fees_sf),
        Fraction::from_bits(vault_state_after_give_up.pending_fees_sf)
            + Fraction::from_num(amount_to_give_up)
    );
    assert_almost_eq_fraction!(
        Fraction::from_num(usdc_u64_to_decimal(
            (topup + expected_user_fee) / 2 + INITIAL_DEPOSIT_SIZE * 999 / 1000
        )),
        Fraction::from_bits(vault_state_after_give_up.prev_aum_sf)
    );
}

#[tokio::test]
async fn test_give_up_pending_fees_aum_lower_than_pending_fees() {
    let (mut ctx, vault, owner, _, _) = fixtures::setup_markets_and_reserves(0).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
    let vault_state = vault.state(&mut ctx).await;
    let shares_issued_initially = vault_state.shares_issued;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;

    // fast forward 25 years but incrementally so we can charge 50% fee every time,
    // so there are more fees than the AUM
    for _ in 0..5 {
        ctx.fast_forward_seconds(u64::from(YEAR) * 6).await;
        setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
        client::give_up_pending_fees(&mut ctx, &vault, &owner, 1).await;
    }

    // update a random field to trigger a charge fee
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        topup + INITIAL_DEPOSIT_SIZE
    );

    let mgmt_fee = MAX_CHARGED_RATE_FOR_VAULT_FEE.full_mul(Fraction::ONE, RoundingMethod::Floor); // just to express it as a Fraction
    let mut expected_mgmt_fee = Fraction::from(shares_issued_initially);
    let mut expected_tokens_fee = Fraction::ONE;
    for _ in 0..5 {
        expected_mgmt_fee +=
            (expected_mgmt_fee * mgmt_fee / (Fraction::ONE - mgmt_fee)).to_floor::<Fraction>();
        expected_tokens_fee *= mgmt_fee;
    }
    let vault_state_before_give_up = vault.state(&mut ctx).await;
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_before_give_up.pending_fees_sf),
        expected_mgmt_fee - Fraction::from(shares_issued_initially + 5)
    );
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_before_give_up.prev_aum_sf),
        Fraction::from_num(usdc_u64_to_decimal(topup + INITIAL_DEPOSIT_SIZE))
    );

    // give up 10 lamports out of the pending fees
    let amount_to_give_up = 10;
    client::give_up_pending_fees(&mut ctx, &vault, &owner, amount_to_give_up).await;

    let vault_state_after_give_up = vault.state(&mut ctx).await;
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_after_give_up.pending_fees_sf),
        expected_mgmt_fee - Fraction::from(shares_issued_initially + amount_to_give_up + 5)
    );
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_after_give_up.prev_aum_sf),
        Fraction::from_num(usdc_u64_to_decimal(topup + INITIAL_DEPOSIT_SIZE))
    );

    // give up all the pending fees
    client::give_up_pending_fees(&mut ctx, &vault, &owner, expected_mgmt_fee.to_num()).await;

    let vault_state_after_give_up_all = vault.state(&mut ctx).await;
    assert_eq!(vault_state_after_give_up_all.pending_fees_sf, 0);
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state_after_give_up_all.prev_aum_sf),
        Fraction::from_num(usdc_u64_to_decimal(topup + INITIAL_DEPOSIT_SIZE))
    );
}

#[tokio::test]
async fn test_give_up_pending_fees_burns_shares() {
    let (mut ctx, vault, owner, _, _) = fixtures::setup_markets_and_reserves(0).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    // Advance time to accrue fees
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // Trigger charge_fees by doing a small withdraw and redeposit
    let withdraw_amount = depositor.balances(&mut ctx).await.shares / 10;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let vault_state_before = vault.state(&mut ctx).await;
    let shares_before = vault_state_before.shares_issued;
    let pending_fees_before: u64 =
        Fraction::from_bits(vault_state_before.pending_fees_sf).to_floor();

    // Give up some fees
    let amount_to_give_up = 100;
    assert!(
        amount_to_give_up <= pending_fees_before,
        "Test setup: insufficient pending fees"
    );

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    client::give_up_pending_fees(&mut ctx, &vault, &owner, amount_to_give_up).await;

    let vault_state_after = vault.state(&mut ctx).await;
    let shares_after = vault_state_after.shares_issued;

    // Critical regression test: shares_issued must be reduced by amount_to_give_up
    // If this fails, the burn_shares call was removed and depositors are permanently diluted
    assert_eq!(
        shares_before - amount_to_give_up,
        shares_after,
        "give_up_pending_fees must burn shares to reverse fee dilution"
    );

    // Also verify pending_fees_sf was reduced
    let pending_fees_after: u64 = Fraction::from_bits(vault_state_after.pending_fees_sf).to_floor();
    assert!(
        pending_fees_after < pending_fees_before,
        "pending_fees_sf must be reduced"
    );
}

/// P1 coverage: give_up_pending_fees with amount = 0 must fail with CannotGiveUpZeroFees.
#[tokio::test]
async fn test_give_up_pending_fees_zero_amount_rejected() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let res = client::try_give_up_pending_fees(&mut ctx, &vault, &owner, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::CannotGiveUpZeroFees, 0)
    );
}

#[tokio::test]
async fn test_give_up_pending_fees_requires_deposits_blocked() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let res = client::try_give_up_pending_fees(&mut ctx, &vault, &owner, 1).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultDepositsNotBlocked, 0)
    );
}

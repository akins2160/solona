use anchor_spl::token_2022::spl_token_2022::{
    self,
    extension::{immutable_owner::ImmutableOwner, BaseStateWithExtensions, StateWithExtensions},
};
use kamino_lending::{
    program_test::common::{
        fixtures::setup_markets as setup_klend_markets,
        setup::kp,
        token_operations::{self, TokenExtension},
        types::{MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    },
    LendingError,
};
use maplit::hashmap;
use metavault::program_test::{
    client::{self, RequestedOut},
    fixtures::{set_global_config, setup_markets, setup_markets_with_weights},
    klend_error, VaultAccounts, VaultDepositorAccounts,
};
use solana_program_test::{anchor_processor, tokio};
use solana_sdk::signer::Signer;

/// Sets up a basic klend market with a normal SPL token, then creates
/// a separate mint with the given extensions. Returns the test context
/// and VaultAccounts pointing to the unsupported mint.
/// This avoids calling setup_klend_markets with unsupported extensions
/// (which would fail when klend tries to create a reserve for them).
async fn setup_vault_with_extensions(
    extensions: &[TokenExtension],
) -> (TestContext, VaultAccounts) {
    // Set up a normal klend market to get a TestContext with metavault loaded
    let normal_spec = MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![RSpec::new("USDC", 0)])],
    };
    let (mut ctx, markets) = setup_klend_markets(
        None,
        &normal_spec,
        None,
        Some(vec![(
            "metavault",
            metavault::ID,
            anchor_processor!(metavault::entry),
        )]),
    )
    .await;

    // Create a separate mint with unsupported extensions
    let mint_kp = kp();
    let owner = ctx.initial_market_owner.clone();
    token_operations::create_mint(
        &mut ctx,
        &mint_kp,
        6,
        &owner.pubkey(),
        &spl_token_2022::id(),
        Some(extensions.to_vec()),
    )
    .await;

    // Create an ATA for the admin so init_vault's admin_token_account constraint is satisfied
    token_operations::create_ata_if_not_exists(&mut ctx, &owner, &mint_kp.pubkey()).await;

    let vault = VaultAccounts::new(
        &mint_kp.pubkey(),
        "TOKEN",
        &spl_token_2022::id(),
        markets.markets[0].oracles.scope_prices_info,
    );
    set_global_config(&mut ctx, &metavault::GlobalConfig::default());
    (ctx, vault)
}

#[tokio::test]
async fn test_token_2022_init_vault() {
    let (mut ctx, _, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "PYUSD".to_string() => MintSpec::with_extensions(6, 1.0, &[
                TokenExtension::TransferFeeConfig(0),
                TokenExtension::TransferHook(None),
            ]),
        },
        markets: vec![MSpec::new(vec![RSpec::new("PYUSD", 0)])],
    })
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_program,
        vault.vault_tokens["PYUSD"].token_program
    );

    let token_vault_authority = ctx
        .get_token_account_authority(vault.vault_tokens["PYUSD"].token_vault)
        .await;
    assert_eq!(token_vault_authority, vault.base_vault_authority);

    // Verify ImmutableOwner extension is present on the token vault
    let token_vault_account = ctx
        .get_account(vault.vault_tokens["PYUSD"].token_vault)
        .await
        .unwrap()
        .unwrap();

    let token_vault_with_extensions =
        StateWithExtensions::<spl_token_2022::state::Account>::unpack(
            token_vault_account.data.as_slice(),
        )
        .expect("Failed to unpack token vault account");

    token_vault_with_extensions
        .get_extension::<ImmutableOwner>()
        .expect("Token vault missing ImmutableOwner extension");
}

#[tokio::test]
async fn test_token_2022_init_vault_with_supported_extension() {
    let (mut ctx, _, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "TOKEN".to_string() => MintSpec::with_extensions(9, 5.0, &[
                TokenExtension::PermanentDelegate,
            ]),
        },
        markets: vec![MSpec::new(vec![RSpec::new("TOKEN", 0)])],
    })
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_program,
        spl_token_2022::id()
    );

    let token_vault_authority = ctx
        .get_token_account_authority(vault.vault_tokens["TOKEN"].token_vault)
        .await;
    assert_eq!(token_vault_authority, vault.base_vault_authority);
}

#[tokio::test]
async fn test_token_2022_init_vault_unsupported_nonzero_transfer_fee() {
    let (mut ctx, vault) =
        setup_vault_with_extensions(&[TokenExtension::TransferFeeConfig(100)]).await;

    let res = client::init_vault(&mut ctx, &vault).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

#[tokio::test]
async fn test_token_2022_init_vault_unsupported_transfer_hook_with_program() {
    let (mut ctx, vault) = setup_vault_with_extensions(&[TokenExtension::TransferHook(Some(
        solana_program::pubkey::Pubkey::new_unique(),
    ))])
    .await;

    let res = client::init_vault(&mut ctx, &vault).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

/// Sets up an initialized vault with a normal SPL token, then creates
/// a separate mint with the given extensions for use with add_vault_token tests.
async fn setup_initialized_vault_with_extension_mint(
    extensions: &[TokenExtension],
) -> (TestContext, VaultAccounts, solana_program::pubkey::Pubkey) {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![RSpec::new("USDC", 0)])],
    })
    .await;

    let mint_kp = kp();
    let owner = ctx.initial_market_owner.clone();
    token_operations::create_mint(
        &mut ctx,
        &mint_kp,
        6,
        &owner.pubkey(),
        &spl_token_2022::id(),
        Some(extensions.to_vec()),
    )
    .await;

    (ctx, vault, mint_kp.pubkey())
}

#[tokio::test]
async fn test_token_2022_add_vault_token() {
    let (mut ctx, mut vault, mint) = setup_initialized_vault_with_extension_mint(&[
        TokenExtension::TransferFeeConfig(0),
        TokenExtension::TransferHook(None),
    ])
    .await;

    let owner = ctx.initial_market_owner.clone();
    client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "TOKEN",
        mint,
        solana_program::pubkey::Pubkey::default(),
    )
    .await
    .unwrap();

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[1].token_program,
        spl_token_2022::id()
    );
}

#[tokio::test]
async fn test_token_2022_add_vault_token_transfer_fee_zero() {
    let (mut ctx, mut vault, mint) =
        setup_initialized_vault_with_extension_mint(&[TokenExtension::TransferFeeConfig(0)]).await;

    let owner = ctx.initial_market_owner.clone();
    client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "TOKEN",
        mint,
        solana_program::pubkey::Pubkey::default(),
    )
    .await
    .unwrap();

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[1].token_program,
        spl_token_2022::id()
    );
}

#[tokio::test]
async fn test_token_2022_add_vault_token_transfer_hook_none() {
    let (mut ctx, mut vault, mint) =
        setup_initialized_vault_with_extension_mint(&[TokenExtension::TransferHook(None)]).await;

    let owner = ctx.initial_market_owner.clone();
    client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "TOKEN",
        mint,
        solana_program::pubkey::Pubkey::default(),
    )
    .await
    .unwrap();

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[1].token_program,
        spl_token_2022::id()
    );
}

#[tokio::test]
async fn test_token_2022_add_vault_token_unsupported_nonzero_transfer_fee() {
    let (mut ctx, mut vault, mint) =
        setup_initialized_vault_with_extension_mint(&[TokenExtension::TransferFeeConfig(100)])
            .await;

    let owner = ctx.initial_market_owner.clone();
    let res = client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "TOKEN",
        mint,
        solana_program::pubkey::Pubkey::default(),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

#[tokio::test]
async fn test_token_2022_add_vault_token_unsupported_transfer_hook_with_program() {
    let (mut ctx, mut vault, mint) =
        setup_initialized_vault_with_extension_mint(&[TokenExtension::TransferHook(Some(
            solana_program::pubkey::Pubkey::new_unique(),
        ))])
        .await;

    let owner = ctx.initial_market_owner.clone();
    let res = client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "TOKEN",
        mint,
        solana_program::pubkey::Pubkey::default(),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

#[tokio::test]
async fn test_token_2022_deposit_revalidates_mutated_transfer_fee_extension() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "PYUSD".to_string() => MintSpec::with_extensions(6, 1.0, &[
                TokenExtension::TransferFeeConfig(0),
            ]),
        },
        markets: vec![MSpec::new(vec![RSpec::new("PYUSD", 0)])],
    })
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "PYUSD", 2_000_000).await;

    token_operations::set_transfer_fee(&mut ctx, &vault.vault_tokens["PYUSD"].token_mint, 100)
        .await;

    let res = client::try_deposit(&mut ctx, &vault, &depositor, "PYUSD", 1_000_000, 0).await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

#[tokio::test]
async fn test_token_2022_withdraw_revalidates_mutated_transfer_fee_extension() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "PYUSD".to_string() => MintSpec::with_extensions(6, 1.0, &[
                TokenExtension::TransferFeeConfig(0),
            ]),
        },
        markets: vec![MSpec::new(vec![RSpec::new("PYUSD", 0)])],
    })
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "PYUSD", 2_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "PYUSD", 1_000_000).await;

    token_operations::set_transfer_fee(&mut ctx, &vault.vault_tokens["PYUSD"].token_mint, 100)
        .await;

    let shares = depositor.balances(&mut ctx).await.shares;
    let res = client::try_withdraw(&mut ctx, &vault, &depositor, shares, "PYUSD", 0).await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

#[tokio::test]
async fn test_token_2022_rebalance_swap_revalidates_mutated_transfer_fee_extension() {
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "PYUSD".to_string() => MintSpec::with_extensions(6, 1.0, &[
                    TokenExtension::TransferFeeConfig(0),
                ]),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("PYUSD", 0),
            ])],
        },
        vec![5, 5],
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000_000).await;
    client::start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    token_operations::set_transfer_fee(&mut ctx, &vault.vault_tokens["PYUSD"].token_mint, 100)
        .await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "PYUSD".to_string() => 500_000_000,
            "USDC".to_string() => 0,
        },
    )
    .await;

    let res = client::try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "PYUSD",
        "USDC",
        100_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::UnsupportedTokenExtension, 1)
    );
}

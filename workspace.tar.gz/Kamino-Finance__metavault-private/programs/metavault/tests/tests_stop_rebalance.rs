use kamino_lending::program_test::common::types::{MSpec, MarketsSpec, MintSpec, RSpec};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{deposit, start_rebalance, stop_rebalance, try_stop_rebalance},
        fixtures::setup_markets_with_weights,
        VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;

#[tokio::test]
async fn test_stop_rebalance_success() {
    let initial_weights = vec![3u64, 4u64];
    let (mut ctx, _, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;

    // Start rebalance
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Verify rebalance is active
    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.rebalance.is_unfinished());

    // Stop the rebalance
    stop_rebalance(&mut ctx, &admin, &vault).await;

    // Verify rebalance is stopped
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());
    assert_eq!(vault_state.rebalance.end_timestamp, 0);
}

#[tokio::test]
async fn test_stop_rebalance_not_active() {
    let initial_weights = vec![3u64, 4u64];
    let (mut ctx, _, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Try to stop when no rebalance is active
    let res = try_stop_rebalance(&mut ctx, &admin, &vault).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceNotInProgress)
    );
}

#[tokio::test]
async fn test_stop_rebalance_cannot_resume() {
    let initial_weights = vec![3u64, 4u64];
    let (mut ctx, _, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;

    // Start rebalance
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Stop the rebalance
    stop_rebalance(&mut ctx, &admin, &vault).await;

    // Verify can start a new rebalance (not resuming the old one)
    start_rebalance(&mut ctx, &admin, &vault, 1800).await;

    // The new rebalance should have different parameters
    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.rebalance.is_unfinished());
    assert_eq!(
        vault_state.rebalance.end_timestamp - vault_state.rebalance.start_timestamp,
        1800
    ); // New duration, not the old 3600
}

#[tokio::test]
async fn test_stop_rebalance_after_expiry() {
    let initial_weights = vec![3u64, 4u64];
    let (mut ctx, _, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;
    // Start rebalance with short duration and let it expire without anyone closing it
    start_rebalance(&mut ctx, &admin, &vault, 600).await;
    ctx.fast_forward_seconds(601).await;
    assert!(vault.state(&mut ctx).await.rebalance.is_unfinished());

    // Stopping an expired rebalance succeeds: it is ended and reported as expired
    stop_rebalance(&mut ctx, &admin, &vault).await;
    assert!(!vault.state(&mut ctx).await.rebalance.is_unfinished());

    // Stopping again, with nothing running, must fail with RebalanceNotInProgress
    let res = try_stop_rebalance(&mut ctx, &admin, &vault).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceNotInProgress)
    );
}

//! Smoke tests for the Token ACL test harness: prove the token-acl and example-gate
//! `.so` fixtures (built with modern platform-tools) load and execute under this
//! workspace's solana-program-test 1.17, that the in-runtime Token-2022 build processes
//! the DefaultAccountState and MetadataPointer extensions, and pin the hand-rolled
//! instruction encodings of `metavault::program_test::token_acl` against the real
//! programs.

use anchor_spl::token_2022::spl_token_2022;
use kamino_lending::{
    program_test::common::{
        setup::{funded_new_kp, KP},
        token_operations::create_ata_if_not_exists,
    },
    send_transaction,
};
use metavault::program_test::{
    fixtures::ProgramDependency,
    token_acl::{
        self, create_config_ix, delete_config_ix, error_code, freeze_ix, initialize_extra_metas_ix,
        mint_config_pda, resolve_thaw_extra_account_metas, set_authority_ix, set_gating_program_ix,
        start_token_acl_test_bed, thaw_extra_account_metas_pda, thaw_ix, thaw_permissionless_ix,
        toggle_permissionless_ix, MintConfig, TokenAclTestBed,
    },
};
use solana_program::{
    instruction::{Instruction, InstructionError},
    native_token::LAMPORTS_PER_SOL,
    program_pack::Pack,
    pubkey::Pubkey,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    signature::Keypair, signer::Signer, system_instruction, transaction::TransactionError,
};
use spl_token_2022::{
    error::TokenError,
    extension::{
        default_account_state::DefaultAccountState, metadata_pointer::MetadataPointer,
        BaseStateWithExtensions, StateWithExtensions,
    },
    state::{Account as TokenAccount, AccountState, Mint},
};
use spl_token_metadata_interface::state::{Field, TokenMetadata};

async fn get_mint(bed: &mut TokenAclTestBed) -> Vec<u8> {
    bed.ctx.get_account(bed.mint).await.unwrap().unwrap().data
}

fn assert_instruction_error(
    err: BanksClientError,
    expected_index: u8,
    expected_error: InstructionError,
) {
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(expected_index, expected_error)
    );
}

fn assert_custom_error(err: BanksClientError, expected_code: u32) {
    assert_instruction_error(err, 0, InstructionError::Custom(expected_code));
}

async fn send_ix(bed: &mut TokenAclTestBed, ix: Instruction) -> Result<(), BanksClientError> {
    let admin = bed.admin.clone();
    let tx = bed.ctx.create_transaction_with_payer([ix], &admin).await;
    send_transaction!(bed.ctx, tx)
}

async fn send_ix_signed(
    bed: &mut TokenAclTestBed,
    ix: Instruction,
    signer: &KP,
) -> Result<(), BanksClientError> {
    let tx = bed
        .ctx
        .create_transaction_with_payer([ix], signer.as_ref())
        .await;
    send_transaction!(bed.ctx, tx)
}

/// Creates a config for `bed.mint` (admin = `bed.admin`) with the given gate and enables
/// permissionless thaw — the §5 "permissioned vault" posture.
async fn create_config_with_permissionless_thaw(bed: &mut TokenAclTestBed, gate: &Pubkey) {
    let admin = bed.admin.pubkey();
    let mint = bed.mint;
    send_ix(bed, create_config_ix(&admin, &admin, &mint, gate))
        .await
        .unwrap();
    send_ix(bed, toggle_permissionless_ix(&admin, &mint, false, true))
        .await
        .unwrap();
}

/// Funds a fresh user and creates their (frozen-at-birth) shares ATA.
async fn new_user_with_frozen_ata(bed: &mut TokenAclTestBed) -> (KP, Pubkey) {
    let user = funded_new_kp(&mut bed.ctx, 10 * LAMPORTS_PER_SOL);
    let mint = bed.mint;
    let ata = create_ata_if_not_exists(&mut bed.ctx, &user, &mint).await;
    assert_eq!(
        token_account_state(bed, &ata).await,
        AccountState::Frozen,
        "ATA on a DAS-Frozen mint must be born frozen"
    );
    (user, ata)
}

async fn token_account_state(bed: &mut TokenAclTestBed, address: &Pubkey) -> AccountState {
    let data = bed.ctx.get_account(*address).await.unwrap().unwrap().data;
    StateWithExtensions::<TokenAccount>::unpack(&data)
        .unwrap()
        .base
        .state
}

#[tokio::test]
async fn test_t22_mint_with_das_and_metadata_pointer_initializes() {
    let mut bed = start_token_acl_test_bed(vec![], AccountState::Frozen).await;

    let mint_data = get_mint(&mut bed).await;
    let mint = StateWithExtensions::<Mint>::unpack(&mint_data).unwrap();

    assert_eq!(mint.base.decimals, 6);
    assert_eq!(mint.base.mint_authority.unwrap(), bed.admin.pubkey());
    assert_eq!(mint.base.freeze_authority.unwrap(), bed.admin.pubkey());

    let das = mint.get_extension::<DefaultAccountState>().unwrap();
    assert_eq!(das.state, u8::from(AccountState::Frozen));

    let pointer = mint.get_extension::<MetadataPointer>().unwrap();
    assert_eq!(
        Option::<solana_program::pubkey::Pubkey>::from(pointer.metadata_address).unwrap(),
        bed.mint
    );
    assert_eq!(
        Option::<solana_program::pubkey::Pubkey>::from(pointer.authority).unwrap(),
        bed.admin.pubkey()
    );
}

#[tokio::test]
async fn test_token_acl_fixture_executes_create_config() {
    let mut bed = start_token_acl_test_bed(vec![], AccountState::Frozen).await;
    let mint = bed.mint;

    let ix = create_config_ix(
        &bed.admin.pubkey(),
        &bed.admin.pubkey(),
        &mint,
        &token_acl::ALWAYS_ALLOW_GATE_ID,
    );
    let tx = bed
        .ctx
        .create_transaction_with_payer([ix], &bed.admin)
        .await;
    send_transaction!(bed.ctx, tx).unwrap();

    let (mint_config_address, bump) = mint_config_pda(&mint);
    let config_account = bed
        .ctx
        .get_account(mint_config_address)
        .await
        .unwrap()
        .expect("MintConfig account must exist after create_config");
    assert_eq!(config_account.owner, token_acl::TOKEN_ACL_ID);

    let config = MintConfig::unpack(&config_account.data).unwrap();
    assert_eq!(config.bump, bump);
    assert_eq!(config.mint, bed.mint);
    // The MintConfig field named `freeze_authority` holds the config ADMIN.
    assert_eq!(config.config_admin, bed.admin.pubkey());
    assert_eq!(config.gating_program, token_acl::ALWAYS_ALLOW_GATE_ID);
    // Both permissionless toggles are born disabled.
    assert!(!config.permissionless_thaw_enabled);
    assert!(!config.permissionless_freeze_enabled);

    // The mint's freeze authority moved from the admin to the MintConfig PDA.
    let mint_data = get_mint(&mut bed).await;
    let mint = StateWithExtensions::<Mint>::unpack(&mint_data).unwrap();
    assert_eq!(mint.base.freeze_authority.unwrap(), mint_config_address);
}

#[tokio::test]
async fn test_create_config_rejects_mint_without_default_account_state() {
    let mut bed = start_token_acl_test_bed(vec![], AccountState::Frozen).await;

    // A plain T22 mint without the DefaultAccountState extension.
    let plain_mint = Keypair::new();
    let rent = bed.ctx.rent;
    let create = system_instruction::create_account(
        &bed.admin.pubkey(),
        &plain_mint.pubkey(),
        rent.minimum_balance(Mint::LEN),
        Mint::LEN as u64,
        &spl_token_2022::ID,
    );
    let init = spl_token_2022::instruction::initialize_mint2(
        &spl_token_2022::ID,
        &plain_mint.pubkey(),
        &bed.admin.pubkey(),
        Some(&bed.admin.pubkey()),
        6,
    )
    .unwrap();
    let tx = bed
        .ctx
        .create_transaction_with_payer_and_extra_signers([create, init], &bed.admin, [&plain_mint])
        .await;
    send_transaction!(bed.ctx, tx).unwrap();

    let ix = create_config_ix(
        &bed.admin.pubkey(),
        &bed.admin.pubkey(),
        &plain_mint.pubkey(),
        &token_acl::ALWAYS_ALLOW_GATE_ID,
    );
    let tx = bed
        .ctx
        .create_transaction_with_payer([ix], &bed.admin)
        .await;
    let err = send_transaction!(bed.ctx, tx)
        .expect_err("create_config must reject a mint without DefaultAccountState");
    assert_instruction_error(
        err,
        0,
        InstructionError::Custom(error_code::INVALID_TOKEN_MINT),
    );
}

#[tokio::test]
async fn test_permissionless_thaw_via_always_allow_gate() {
    let mut bed = start_token_acl_test_bed(
        vec![ProgramDependency::GateAlwaysAllow],
        AccountState::Frozen,
    )
    .await;
    let mint = bed.mint;
    create_config_with_permissionless_thaw(&mut bed, &token_acl::ALWAYS_ALLOW_GATE_ID).await;
    let (user, ata) = new_user_with_frozen_ata(&mut bed).await;

    // The plain always-allow gate registers no extra-metas account.
    let extra_metas = resolve_thaw_extra_account_metas(
        &mut bed.ctx,
        &token_acl::ALWAYS_ALLOW_GATE_ID,
        &user.pubkey(),
        &ata,
        &mint,
        &user.pubkey(),
    )
    .await;
    assert!(extra_metas.is_empty());

    let ix = thaw_permissionless_ix(
        &user.pubkey(),
        &mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_ALLOW_GATE_ID,
        vec![],
        false,
    );
    send_ix_signed(&mut bed, ix, &user).await.unwrap();
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Initialized
    );

    // The idempotent variant is a no-op on an already-thawed account.
    let ix = thaw_permissionless_ix(
        &user.pubkey(),
        &mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_ALLOW_GATE_ID,
        vec![],
        true,
    );
    send_ix_signed(&mut bed, ix, &user).await.unwrap();
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Initialized
    );
}

#[tokio::test]
async fn test_permissionless_thaw_rejected_by_always_block_gate() {
    let mut bed = start_token_acl_test_bed(
        vec![ProgramDependency::GateAlwaysBlock],
        AccountState::Frozen,
    )
    .await;
    let mint = bed.mint;
    create_config_with_permissionless_thaw(&mut bed, &token_acl::ALWAYS_BLOCK_GATE_ID).await;
    let (user, ata) = new_user_with_frozen_ata(&mut bed).await;

    let ix = thaw_permissionless_ix(
        &user.pubkey(),
        &mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_BLOCK_GATE_ID,
        vec![],
        false,
    );
    let err = send_ix_signed(&mut bed, ix, &user).await.unwrap_err();
    assert_custom_error(err, error_code::GATE_UNSUPPORTED_INSTRUCTION);
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Frozen
    );
}

#[tokio::test]
async fn test_permissionless_thaw_requires_toggle() {
    let mut bed = start_token_acl_test_bed(
        vec![ProgramDependency::GateAlwaysAllow],
        AccountState::Frozen,
    )
    .await;
    let mint = bed.mint;
    // create_config only — permissionless thaw stays at its disabled default.
    let admin = bed.admin.pubkey();
    send_ix(
        &mut bed,
        create_config_ix(&admin, &admin, &mint, &token_acl::ALWAYS_ALLOW_GATE_ID),
    )
    .await
    .unwrap();
    let (user, ata) = new_user_with_frozen_ata(&mut bed).await;

    let ix = thaw_permissionless_ix(
        &user.pubkey(),
        &mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_ALLOW_GATE_ID,
        vec![],
        false,
    );
    let err = send_ix_signed(&mut bed, ix, &user).await.unwrap_err();
    assert_custom_error(err, error_code::PERMISSIONLESS_THAW_NOT_ENABLED);
}

#[tokio::test]
async fn test_permissioned_thaw_and_freeze_do_not_consult_the_gate() {
    // The always-block gate would reject a permissionless thaw; the permissioned
    // Thaw/Freeze (config-admin-signed) never CPI the gate, so they succeed regardless.
    let mut bed = start_token_acl_test_bed(
        vec![ProgramDependency::GateAlwaysBlock],
        AccountState::Frozen,
    )
    .await;
    let mint = bed.mint;
    create_config_with_permissionless_thaw(&mut bed, &token_acl::ALWAYS_BLOCK_GATE_ID).await;
    let (_user, ata) = new_user_with_frozen_ata(&mut bed).await;
    let admin = bed.admin.pubkey();

    send_ix(&mut bed, thaw_ix(&admin, &mint, &ata))
        .await
        .unwrap();
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Initialized
    );

    send_ix(&mut bed, freeze_ix(&admin, &mint, &ata))
        .await
        .unwrap();
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Frozen
    );

    // A non-admin signer is rejected.
    let outsider = funded_new_kp(&mut bed.ctx, LAMPORTS_PER_SOL);
    let ix = thaw_ix(&outsider.pubkey(), &mint, &ata);
    let err = send_ix_signed(&mut bed, ix, &outsider).await.unwrap_err();
    assert_custom_error(err, error_code::INVALID_AUTHORITY);
}

#[tokio::test]
async fn test_set_gating_program_and_set_authority() {
    let mut bed = start_token_acl_test_bed(
        vec![
            ProgramDependency::GateAlwaysAllow,
            ProgramDependency::GateAlwaysBlock,
        ],
        AccountState::Frozen,
    )
    .await;
    let mint = bed.mint;
    create_config_with_permissionless_thaw(&mut bed, &token_acl::ALWAYS_ALLOW_GATE_ID).await;
    let admin = bed.admin.pubkey();

    // Swap the gate to always-block: thaws that would pass now fail.
    send_ix(
        &mut bed,
        set_gating_program_ix(&admin, &mint, &token_acl::ALWAYS_BLOCK_GATE_ID),
    )
    .await
    .unwrap();
    let (user, ata) = new_user_with_frozen_ata(&mut bed).await;
    let ix = thaw_permissionless_ix(
        &user.pubkey(),
        &mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_BLOCK_GATE_ID,
        vec![],
        false,
    );
    let err = send_ix_signed(&mut bed, ix, &user).await.unwrap_err();
    assert_custom_error(err, error_code::GATE_UNSUPPORTED_INSTRUCTION);

    // Only the config admin may reconfigure.
    let outsider = funded_new_kp(&mut bed.ctx, LAMPORTS_PER_SOL);
    let ix = set_gating_program_ix(&outsider.pubkey(), &mint, &token_acl::ALWAYS_ALLOW_GATE_ID);
    let err = send_ix_signed(&mut bed, ix, &outsider).await.unwrap_err();
    assert_custom_error(err, error_code::INVALID_AUTHORITY);

    // Single-step admin handoff: the new admin acts, the old admin is locked out.
    let new_admin = funded_new_kp(&mut bed.ctx, LAMPORTS_PER_SOL);
    send_ix(
        &mut bed,
        set_authority_ix(&admin, &mint, &new_admin.pubkey()),
    )
    .await
    .unwrap();
    let ix = toggle_permissionless_ix(&new_admin.pubkey(), &mint, false, false);
    send_ix_signed(&mut bed, ix, &new_admin).await.unwrap();
    let ix = toggle_permissionless_ix(&admin, &mint, false, true);
    let err = send_ix(&mut bed, ix).await.unwrap_err();
    assert_custom_error(err, error_code::INVALID_AUTHORITY);

    let (config_address, _) = mint_config_pda(&mint);
    let config_data = bed
        .ctx
        .get_account(config_address)
        .await
        .unwrap()
        .unwrap()
        .data;
    let config = MintConfig::unpack(&config_data).unwrap();
    assert_eq!(config.config_admin, new_admin.pubkey());
    assert!(!config.permissionless_thaw_enabled);
}

#[tokio::test]
async fn test_delete_config_restores_freeze_authority_and_pays_rent_to_receiver() {
    let mut bed = start_token_acl_test_bed(vec![], AccountState::Frozen).await;
    let mint = bed.mint;
    let admin = bed.admin.pubkey();
    send_ix(
        &mut bed,
        create_config_ix(&admin, &admin, &mint, &token_acl::ALWAYS_ALLOW_GATE_ID),
    )
    .await
    .unwrap();

    let (config_address, _) = mint_config_pda(&mint);
    let config_lamports = bed
        .ctx
        .get_account(config_address)
        .await
        .unwrap()
        .unwrap()
        .lamports;
    assert!(config_lamports > 0);

    let receiver = Pubkey::new_unique();
    send_ix(&mut bed, delete_config_ix(&admin, &receiver, &mint, &admin))
        .await
        .unwrap();

    // Config closed, rent paid to the receiver, freeze authority handed back.
    assert!(bed.ctx.get_account(config_address).await.unwrap().is_none());
    assert_eq!(
        bed.ctx.context.get_balance(receiver).await.unwrap(),
        config_lamports
    );
    let mint_data = get_mint(&mut bed).await;
    let mint_state = StateWithExtensions::<Mint>::unpack(&mint_data).unwrap();
    assert_eq!(mint_state.base.freeze_authority.unwrap(), admin);

    // Re-permissioning is not blocked: create_config works again on the same mint.
    send_ix(
        &mut bed,
        create_config_ix(&admin, &admin, &mint, &token_acl::ALWAYS_ALLOW_GATE_ID),
    )
    .await
    .unwrap();
    assert!(bed.ctx.get_account(config_address).await.unwrap().is_some());
}

#[tokio::test]
async fn test_permissionless_thaw_with_extra_account_metas_resolution() {
    let mut bed = start_token_acl_test_bed(
        vec![ProgramDependency::GateAlwaysAllowWithDeps],
        AccountState::Frozen,
    )
    .await;
    let mint = bed.mint;
    create_config_with_permissionless_thaw(&mut bed, &token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID)
        .await;

    // Register the gate's non-trivial extra-metas config (fixed pubkeys, a pubkey read
    // from account data, an external ATA PDA, and a PDA on the gate itself).
    let admin = bed.admin.pubkey();
    let ix = initialize_extra_metas_ix(&admin, &mint, &token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID);
    send_ix(&mut bed, ix).await.unwrap();

    let (user, ata) = new_user_with_frozen_ata(&mut bed).await;
    let extra_metas = resolve_thaw_extra_account_metas(
        &mut bed.ctx,
        &token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID,
        &user.pubkey(),
        &ata,
        &mint,
        &user.pubkey(),
    )
    .await;
    // The extra-metas account itself plus the five configured metas.
    assert_eq!(extra_metas.len(), 6);
    let (extra_metas_address, _) =
        thaw_extra_account_metas_pda(&mint, &token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID);
    assert_eq!(extra_metas[0].pubkey, extra_metas_address);
    // The gate cross-checks the resolved ATA against the thawed token account and the
    // owner extracted from its account data — passing proves the resolver is correct.
    assert_eq!(extra_metas[4].pubkey, ata);
    assert_eq!(extra_metas[3].pubkey, user.pubkey());

    let ix = thaw_permissionless_ix(
        &user.pubkey(),
        &mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID,
        extra_metas,
        false,
    );
    send_ix_signed(&mut bed, ix, &user).await.unwrap();
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Initialized
    );

    // Without the resolved extra accounts the gate cannot even deserialize its inputs.
    let (user2, ata2) = new_user_with_frozen_ata(&mut bed).await;
    let ix = thaw_permissionless_ix(
        &user2.pubkey(),
        &mint,
        &ata2,
        &user2.pubkey(),
        &token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID,
        vec![],
        false,
    );
    let err = send_ix_signed(&mut bed, ix, &user2).await.unwrap_err();
    assert_instruction_error(err, 0, InstructionError::NotEnoughAccountKeys);
    assert_eq!(
        token_account_state(&mut bed, &ata2).await,
        AccountState::Frozen
    );
}

#[tokio::test]
async fn test_token_metadata_initialize_and_update_on_t22_mint() {
    let mut bed = start_token_acl_test_bed(vec![], AccountState::Frozen).await;
    let mint = bed.mint;
    let admin = bed.admin.pubkey();

    // TokenMetadata is variable-length: top up the mint's lamports for the realloc.
    let fund = system_instruction::transfer(&admin, &mint, LAMPORTS_PER_SOL / 100);
    let init = spl_token_metadata_interface::instruction::initialize(
        &spl_token_2022::ID,
        &mint,
        &admin,
        &mint,
        &admin,
        "Kamino Vault Shares".to_string(),
        "KVS".to_string(),
        "https://example.com/shares.json".to_string(),
    );
    let bed_admin = bed.admin.clone();
    let tx = bed
        .ctx
        .create_transaction_with_payer([fund, init], &bed_admin)
        .await;
    send_transaction!(bed.ctx, tx).unwrap();

    let mint_data = get_mint(&mut bed).await;
    let mint_state = StateWithExtensions::<Mint>::unpack(&mint_data).unwrap();
    let metadata = mint_state
        .get_variable_len_extension::<TokenMetadata>()
        .unwrap();
    assert_eq!(metadata.name, "Kamino Vault Shares");
    assert_eq!(metadata.symbol, "KVS");
    assert_eq!(metadata.mint, bed.mint);

    // update_field on a standard field and on a custom key — the §7 `token_acl`
    // gate-discovery convention PR 5 relies on.
    let update_name = spl_token_metadata_interface::instruction::update_field(
        &spl_token_2022::ID,
        &mint,
        &admin,
        Field::Name,
        "Renamed Shares".to_string(),
    );
    let update_key = spl_token_metadata_interface::instruction::update_field(
        &spl_token_2022::ID,
        &mint,
        &admin,
        Field::Key("token_acl".to_string()),
        token_acl::ALWAYS_ALLOW_GATE_ID.to_string(),
    );
    let tx = bed
        .ctx
        .create_transaction_with_payer([update_name, update_key], &bed_admin)
        .await;
    send_transaction!(bed.ctx, tx).unwrap();

    let mint_data = get_mint(&mut bed).await;
    let mint_state = StateWithExtensions::<Mint>::unpack(&mint_data).unwrap();
    let metadata = mint_state
        .get_variable_len_extension::<TokenMetadata>()
        .unwrap();
    assert_eq!(metadata.name, "Renamed Shares");
    assert_eq!(
        metadata.additional_metadata,
        vec![(
            "token_acl".to_string(),
            token_acl::ALWAYS_ALLOW_GATE_ID.to_string()
        )]
    );
}

#[tokio::test]
async fn test_default_account_state_flips_only_while_authority_is_home() {
    let mut bed = start_token_acl_test_bed(vec![], AccountState::Frozen).await;
    let mint = bed.mint;
    let admin = bed.admin.pubkey();

    // Before create_config the admin holds the freeze authority: DAS can be flipped and
    // new ATAs are born thawed.
    let flip = spl_token_2022::extension::default_account_state::instruction::update_default_account_state(
        &spl_token_2022::ID,
        &mint,
        &admin,
        &[],
        &AccountState::Initialized,
    )
    .unwrap();
    send_ix(&mut bed, flip).await.unwrap();

    let user = funded_new_kp(&mut bed.ctx, LAMPORTS_PER_SOL);
    let mint = bed.mint;
    let ata = create_ata_if_not_exists(&mut bed.ctx, &user, &mint).await;
    assert_eq!(
        token_account_state(&mut bed, &ata).await,
        AccountState::Initialized
    );

    // Once the config exists the freeze authority lives with the MintConfig PDA and no
    // instruction forwards update_default_account_state — the §2 "authority is home"
    // constraint: flips only before create_config or after delete_config.
    send_ix(
        &mut bed,
        create_config_ix(&admin, &admin, &mint, &token_acl::ALWAYS_ALLOW_GATE_ID),
    )
    .await
    .unwrap();
    let flip = spl_token_2022::extension::default_account_state::instruction::update_default_account_state(
        &spl_token_2022::ID,
        &mint,
        &admin,
        &[],
        &AccountState::Frozen,
    )
    .unwrap();
    let err = send_ix(&mut bed, flip).await.unwrap_err();
    assert_instruction_error(
        err,
        0,
        InstructionError::Custom(TokenError::OwnerMismatch as u32),
    );
}

//! Price-basis gate: AUM-facing ops must see the same price
//! on the vault's scope feed and on klend's cached reserve price, within `max_price_divergence_bps`
//! (default 0 — bit-exact). These tests diverge the two on purpose:
//!
//! 1. Refresh the obligation's reserves in their own transaction (so klend's cache is pinned to
//!    the scope price at that moment).
//! 2. Poke the scope feed out-of-band via `setup::update_scope_px_and_twap` (a `set_account` write
//!    — like a crank landing between transactions), which klend's cache does not see.
//! 3. Run the op **without** a bundled refresh, in the same slot: the gate compares the fresh
//!    scope price against the stale reserve cache and (outside tolerance) rejects.
//!
//! klend's mock Pyth/Switchboard price feeds carry a hardcoded `i64::MAX` "publish time" (see
//! `new_price` in klend's test `setup.rs`), so `refresh_reserve`'s "most recent oracle" tie-break
//! always prefers them over Scope's real-clock timestamp — a Scope-only poke would never be
//! picked up, even by a second refresh. The reserves here have Pyth/Switchboard disabled so
//! Scope is the only enabled price source and refresh genuinely tracks it.
//!
//! Beyond the repay/deposit pair and tolerance window (Task 5), this file covers every other
//! AUM-facing op with the same recipe, the two "first use of a reserve" variants that only the
//! per-handler target-reserve check (not the leg-reserve sweep) can catch, structural mutations
//! of the scope/obligation/leg-reserve account layout, and one end-to-end assertion that the
//! `aum` view is priced on the vault's scope basis rather than klend's cached aggregate.

use borsh::BorshDeserialize;
use kamino_lending::{
    fraction::Fraction,
    program_test::common::{
        setup::{update_reserve, KP},
        token_operations::create_ata,
        types::{
            LendingMarketAccounts, MSpec, MarketsSpec, MintSpec, RSpec, ReserveAccounts,
            TestContext,
        },
    },
    send_transaction,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{
            self, get_ordered_scope_and_obligation_accounts, RequestedOut, UpdateVaultConfigParams,
        },
        fixtures::{setup_markets_with_weights_and_dependencies, ProgramDependency},
        instructions, setup,
        test_cpi_caller::TEST_CPI_CALLER_ID,
        VaultAccounts, VaultDepositorAccounts,
    },
    types::{NetAum, RoundingMethod, TokenPrice},
    utils::consts::YEAR,
    ExchangeRateWithDecimals, KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    account::AccountSharedData,
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    signature::Keypair,
    signer::Signer,
};
use std::collections::HashMap;

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        // USDC reserve seeded with 10,000 USDC so we can borrow against SOL.
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

// Disables the reserve's Pyth and Switchboard oracles on-chain (Scope stays enabled), then
// returns a matching `ReserveAccounts` with the Pyth/Switchboard account fields zeroed so our own
// `build_klend_refresh_reserve_ix` passes klend's "disabled" sentinel for those slots. Without
// this, `refresh_reserve`'s oracle tie-break always keeps Pyth's mock (never-stale) price and a
// Scope poke is never observed.
async fn disable_non_scope_oracles(
    ctx: &mut TestContext,
    reserve: &ReserveAccounts,
) -> ReserveAccounts {
    let mut state = ctx.get_reserve(reserve).await;
    state.config.token_info.pyth_configuration.price = Pubkey::default();
    state
        .config
        .token_info
        .switchboard_configuration
        .price_aggregator = Pubkey::default();
    state
        .config
        .token_info
        .switchboard_configuration
        .twap_aggregator = Pubkey::default();
    update_reserve(ctx, &state, &reserve.address.pubkey()).await;

    ReserveAccounts {
        pyth_price: Pubkey::default(),
        switchboard_feed: Pubkey::default(),
        switchboard_twap_feed: Pubkey::default(),
        ..reserve.clone()
    }
}

// Shared prefix for both obligation fixtures below: a 50/50 SOL/USDC metavault seeded with 10 SOL
// + 2000 USDC, both reserves Scope-only. Neither obligation nor legs exist yet.
async fn setup_vault_and_market(
    program_dependencies: Option<Vec<ProgramDependency>>,
) -> (
    TestContext,
    VaultAccounts,
    LendingMarketAccounts,
    ReserveAccounts,
    ReserveAccounts,
) {
    let (mut ctx, markets, vault) = setup_markets_with_weights_and_dependencies(
        &make_spec(),
        vec![5u64, 5u64],
        program_dependencies,
    )
    .await;
    let market = markets.markets[0].primary_market.clone();
    let sol_reserve =
        disable_non_scope_oracles(&mut ctx, &markets.markets[0].reserves["SOL"]).await;
    let usdc_reserve =
        disable_non_scope_oracles(&mut ctx, &markets.markets[0].reserves["USDC"]).await;

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;

    (ctx, vault, market, sol_reserve, usdc_reserve)
}

// Builds on [setup_vault_and_market]: inits a fresh obligation and leverages it — 5 SOL deposited
// as collateral, 100 USDC borrowed against it. The obligation ends up carrying both a deposit leg
// (SOL) and a borrow leg (USDC). Loads the `test_cpi_caller` dependency so the `aum`/`exchange_rate`
// views can be exercised through it (see `readonly_aum`/`readonly_exchange_rate` below).
async fn setup_vault_with_legs() -> (
    TestContext,
    VaultAccounts,
    LendingMarketAccounts,
    ReserveAccounts,
    ReserveAccounts,
    Pubkey,
) {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve) =
        setup_vault_and_market(Some(vec![ProgramDependency::TestCpiCaller])).await;
    let admin = ctx.initial_market_owner.clone();

    client::init_obligation(&mut ctx, &admin, &vault, &market, 0).await;
    let obligation_pk =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    (ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk)
}

// Builds on [setup_vault_and_market], but only inits the obligation — zero legs. For the
// "first use of a reserve" variants: the leg-reserve sweep sees nothing for a legless obligation,
// so only the per-handler target-reserve check can catch a diverged basis.
async fn setup_vault_and_fresh_obligation() -> (
    TestContext,
    VaultAccounts,
    LendingMarketAccounts,
    ReserveAccounts,
    ReserveAccounts,
    Pubkey,
) {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve) = setup_vault_and_market(None).await;
    let admin = ctx.initial_market_owner.clone();

    client::init_obligation(&mut ctx, &admin, &vault, &market, 0).await;
    let obligation_pk =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    (ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk)
}

// ── Readonly-view test infra (mirrors tests_readonly.rs) ────────────────
//
// `aum`/`exchange_rate` never fail the transaction: their handlers catch every error and encode
// it into the return data as an `Err(String)` (see `AumResult`/`ExchangeRateResult`). Reading
// that return data requires a CPI, since banks-client doesn't otherwise expose it post-execution.

async fn call_readonly_via_cpi<T: BorshDeserialize>(
    ctx: &mut TestContext,
    payer: &KP,
    inner_ix: Instruction,
) -> Result<std::result::Result<T, String>, BanksClientError> {
    call_readonly_via_cpi_with_prelude(ctx, payer, vec![], inner_ix).await
}

async fn call_readonly_via_cpi_with_prelude<T: BorshDeserialize>(
    ctx: &mut TestContext,
    payer: &KP,
    mut prelude: Vec<Instruction>,
    inner_ix: Instruction,
) -> Result<std::result::Result<T, String>, BanksClientError> {
    let return_data_account = Keypair::new();
    let account = AccountSharedData::new(1_000_000, 1024, &TEST_CPI_CALLER_ID);
    ctx.set_account(&return_data_account.pubkey(), account);

    let mut accounts = Vec::with_capacity(inner_ix.accounts.len() + 2);
    accounts.push(AccountMeta::new_readonly(metavault::ID, false));
    accounts.push(AccountMeta::new(return_data_account.pubkey(), false));
    accounts.extend(inner_ix.accounts);

    let mut data = Vec::with_capacity(inner_ix.data.len() + 1);
    data.push(1);
    data.extend(inner_ix.data);

    let cpi_ix = Instruction {
        program_id: TEST_CPI_CALLER_ID,
        accounts,
        data,
    };
    prelude.push(cpi_ix);
    let tx = ctx.create_transaction_with_payer(prelude, payer).await;
    send_transaction!(ctx, tx)?;

    let account = ctx
        .get_account(return_data_account.pubkey())
        .await?
        .expect("return data account must exist");
    let len = u32::from_le_bytes(account.data[..4].try_into().unwrap()) as usize;
    Ok(std::result::Result::<T, String>::try_from_slice(&account.data[4..4 + len]).unwrap())
}

async fn readonly_aum(
    ctx: &mut TestContext,
    payer: &KP,
    vault: &VaultAccounts,
) -> std::result::Result<u128, String> {
    let accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let ix = instructions::aum_ix(metavault::ID, vault, accounts);
    call_readonly_via_cpi(ctx, payer, ix).await.unwrap()
}

async fn readonly_exchange_rate(
    ctx: &mut TestContext,
    payer: &KP,
    vault: &VaultAccounts,
    mint: Pubkey,
) -> std::result::Result<ExchangeRateWithDecimals, String> {
    let accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let ix = instructions::exchange_rate_ix(metavault::ID, vault, mint, accounts);
    call_readonly_via_cpi(ctx, payer, ix).await.unwrap()
}

// ── Task 5: repay/deposit gate pairs + tolerance window ─────────────────

#[tokio::test]
async fn repay_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    // Refresh everything at the current scope price, in its own transaction.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // A scope crank lands: SOL moves one tick; the reserve cache still holds the old price.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    // Same slot, no prelude, default bps = 0 -> the gate fires. Note the diverged token is SOL
    // (a leg reserve) while the op repays USDC — proving the sweep catches non-target legs.
    let scope_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::repay_obligation_liquidity_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000,
        scope_accounts.clone(),
        vec![&sol_reserve],
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    // Re-refresh (re-pulls the moved price) -> the identical op now succeeds.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let tx = instructions::repay_obligation_liquidity_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000,
        scope_accounts,
        vec![&sol_reserve],
    )
    .await;
    send_transaction!(ctx, tx).unwrap();
}

#[tokio::test]
async fn deposit_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // SOL diverges; the vault's regular (non-obligation) deposit flow still recomputes AUM
    // through the obligation's leg reserves, so it trips the same gate. Its builder never
    // bundles a refresh, so no `_no_prelude` variant is needed here.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", 2_000_000_000).await;
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000, 0)
        .await
        .unwrap();
}

#[tokio::test]
async fn deposit_within_divergence_tolerance_succeeds_without_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // Widen SOL's tolerance to 100 bps (1%).
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxPriceDivergenceBps(sol_mint, 100),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", 2_000_000_000).await;

    // +0.5% is within the 1% tolerance: the op succeeds with no re-refresh.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.5, 100.5).await;
    client::try_deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000, 0)
        .await
        .unwrap();

    // +2% breaks the tolerance: the gate fires.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 102.0, 102.0).await;
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );
}

// ── Task 6, Step 1: remaining op pairs ───────────────────────────────────

#[tokio::test]
async fn withdraw_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    // Resync before touching the vault at all: `setup_vault_with_legs` ends mid-obligation-op,
    // and the depositor setup below is itself an AUM-computing deposit that would otherwise
    // trip on stale obligation state left over from the fixture.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 1_000_000_000).await;

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let res = client::try_withdraw(&mut ctx, &vault, &depositor, 1_000, "SOL", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_withdraw(&mut ctx, &vault, &depositor, 1_000, "SOL", 0)
        .await
        .unwrap();
}

#[tokio::test]
async fn borrow_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &usdc_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0001, 1.0001).await;

    let scope_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::borrow_obligation_liquidity_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000,
        scope_accounts.clone(),
        vec![&sol_reserve],
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &usdc_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let tx = instructions::borrow_obligation_liquidity_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000,
        scope_accounts,
        vec![&sol_reserve],
    )
    .await;
    send_transaction!(ctx, tx).unwrap();
}

#[tokio::test]
async fn deposit_obligation_collateral_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let scope_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::deposit_obligation_collateral_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000,
        scope_accounts.clone(),
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let tx = instructions::deposit_obligation_collateral_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000,
        scope_accounts,
    )
    .await;
    send_transaction!(ctx, tx).unwrap();
}

#[tokio::test]
async fn withdraw_obligation_collateral_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let scope_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::withdraw_obligation_collateral_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000,
        scope_accounts.clone(),
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let tx = instructions::withdraw_obligation_collateral_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000,
        scope_accounts,
    )
    .await;
    send_transaction!(ctx, tx).unwrap();
}

#[tokio::test]
async fn start_rebalance_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    // `start_rebalance`'s builder never bundles a refresh (index 0: no compute-budget ix).
    let res = client::try_start_rebalance(&mut ctx, &admin, &vault, 3600).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 0),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_start_rebalance(&mut ctx, &admin, &vault, 3600)
        .await
        .unwrap();
}

#[tokio::test]
async fn rebalance_swap_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    // Resync before touching the vault at all: `start_rebalance` is itself an AUM-computing op
    // and would otherwise trip on stale obligation state left over from the fixture.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // Free-balance exposure (10 SOL / 2000 USDC total, leverage-neutral) is already imbalanced
    // against the 50/50 target, so a rebalance can start and a small SOL->USDC swap has a real
    // deficit to fill.
    client::start_rebalance(&mut ctx, &admin, &vault, 3600).await;
    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 1_000_000_000,
            "USDC".to_string() => 0,
        },
    )
    .await;

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let res = client::try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000,
        RequestedOut::AtCurve,
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn update_vault_config_mgmt_fee_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    // Only the fee-bps fields charge fees (hence recompute AUM) in `update_vault_config`.
    let res = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn withdraw_pending_fees_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    // Resync before touching the vault at all: setting a fee bps recomputes AUM and would
    // otherwise trip on stale obligation state left over from the fixture.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;

    // Let a real management fee accrue, then re-sync everything before diverging.
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let admin_accounts = VaultDepositorAccounts {
        owner: admin.clone(),
        token_atas: HashMap::new(),
        shares_ata: create_ata(&mut ctx, &admin, &vault.shares_mint).await,
    };

    let res = client::try_withdraw_pending_fees(&mut ctx, &vault, &admin_accounts).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 0),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let shares_before = admin_accounts.balances(&mut ctx).await.shares;
    client::try_withdraw_pending_fees(&mut ctx, &vault, &admin_accounts)
        .await
        .unwrap();
    let shares_after = admin_accounts.balances(&mut ctx).await.shares;
    assert!(shares_after > shares_before);
}

#[tokio::test]
async fn give_up_pending_fees_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    // Resync before touching the vault at all: setting a fee bps recomputes AUM and would
    // otherwise trip on stale obligation state left over from the fixture.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;

    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let res = client::try_give_up_pending_fees(&mut ctx, &vault, &admin, 10).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 0),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_give_up_pending_fees(&mut ctx, &vault, &admin, 10)
        .await
        .unwrap();
}

#[tokio::test]
async fn refresh_vault_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let res = client::try_refresh_vault(&mut ctx, &vault, &admin).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 0),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    client::try_refresh_vault(&mut ctx, &vault, &admin)
        .await
        .unwrap();
}

#[tokio::test]
async fn aum_view_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    // The `aum` view never fails its transaction: the error lands in the decoded return data.
    let result = readonly_aum(&mut ctx, &admin, &vault).await;
    // Match the structured `error_name` field of the Debug-rendered AnchorError — a bare
    // substring would also pass on any unrelated error whose message mentions the variant.
    let err = result.unwrap_err();
    let expected = format!(
        r#"error_name: "{}""#,
        KaminoVaultError::ReservePriceMismatch.name()
    );
    assert!(err.contains(&expected), "unexpected error: {err}");

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    readonly_aum(&mut ctx, &admin, &vault).await.unwrap();
}

#[tokio::test]
async fn exchange_rate_view_reverts_on_diverged_basis_then_succeeds_after_refresh() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let result = readonly_exchange_rate(&mut ctx, &admin, &vault, sol_mint).await;
    // Match the structured `error_name` field of the Debug-rendered AnchorError — a bare
    // substring would also pass on any unrelated error whose message mentions the variant.
    let err = result.unwrap_err();
    let expected = format!(
        r#"error_name: "{}""#,
        KaminoVaultError::ReservePriceMismatch.name()
    );
    assert!(err.contains(&expected), "unexpected error: {err}");

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    readonly_exchange_rate(&mut ctx, &admin, &vault, sol_mint)
        .await
        .unwrap();
}

// ── Task 6, Step 2: first-use target-reserve variants ────────────────────

#[tokio::test]
async fn first_deposit_obligation_collateral_reverts_on_diverged_target_reserve() {
    let (mut ctx, vault, market, sol_reserve, _usdc_reserve, obligation_pk) =
        setup_vault_and_fresh_obligation().await;
    let admin = ctx.initial_market_owner.clone();

    // Pin SOL's reserve cache; the obligation has zero legs, so the leg-reserve sweep has
    // nothing to check. Only the handler's own target-reserve check (Task 3) can catch this.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![],
        vec![],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.01, 100.01).await;

    let scope_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::deposit_obligation_collateral_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        scope_accounts.clone(),
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![],
        vec![],
    )
    .await;
    let tx = instructions::deposit_obligation_collateral_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        scope_accounts,
    )
    .await;
    send_transaction!(ctx, tx).unwrap();
}

#[tokio::test]
async fn first_borrow_obligation_liquidity_reverts_on_diverged_target_reserve() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_and_fresh_obligation().await;
    let admin = ctx.initial_market_owner.clone();

    // Establish a healthy SOL collateral leg first (undiverged) so the obligation can borrow.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    // Pin USDC's reserve cache, then diverge it. USDC isn't a leg of any obligation yet (only
    // SOL is), so the leg-reserve sweep can't see this — only the borrow handler's own
    // target-reserve check (Task 3) can.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &usdc_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0001, 1.0001).await;

    let scope_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::borrow_obligation_liquidity_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000_000,
        scope_accounts.clone(),
        vec![&sol_reserve],
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReservePriceMismatch, 1),
    );

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &usdc_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    let tx = instructions::borrow_obligation_liquidity_no_prelude(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000_000,
        scope_accounts,
        vec![&sol_reserve],
    )
    .await;
    send_transaction!(ctx, tx).unwrap();
}

// ── Task 6, Step 3: structural layout tests ──────────────────────────────

#[tokio::test]
async fn refresh_vault_rejects_truncated_leg_reserve_segment() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // Drop the leg-reserve segment entirely, simulating the pre-price-basis-gate two-segment
    // layout (`[scope...][obligation...]` with no trailing leg reserves).
    let full_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let vault_state = vault.state(&mut ctx).await;
    let segment_len = vault_state.get_tokens_count() + vault_state.get_obligations_count();
    let truncated_accounts = full_accounts[..segment_len].to_vec();

    let tx = instructions::refresh_vault(&mut ctx, &admin, &vault, truncated_accounts).await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ObligationAccountMissing, 0),
    );
}

#[tokio::test]
async fn refresh_vault_rejects_swapped_leg_reserve_pubkeys() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // Swap the two leg-reserve entries (deposit leg <-> borrow leg): both key-match checks fail.
    let mut mutated_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let last = mutated_accounts.len();
    mutated_accounts.swap(last - 1, last - 2);

    let tx = instructions::refresh_vault(&mut ctx, &admin, &vault, mutated_accounts).await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 0),
    );
}

#[tokio::test]
async fn refresh_vault_rejects_bogus_trailing_account() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // `refresh_vault` requires full consumption of remaining_accounts: one extra bogus account
    // at the end must be rejected even though the rest of the layout is otherwise valid.
    let mut mutated_accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    mutated_accounts.push(Pubkey::new_unique());

    let tx = instructions::refresh_vault(&mut ctx, &admin, &vault, mutated_accounts).await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::UnexpectedRemainingAccounts, 0),
    );
}

// Marks the obligation `ALL_CHECKS`-fresh in the current slot by direct account mutation —
// klend's real `refresh_obligation` would insist on same-slot-fresh reserves, which is exactly
// what the test below needs to avoid.
async fn force_freshen_obligation(ctx: &mut TestContext, obligation_pk: Pubkey) {
    let account = ctx
        .get_account(obligation_pk)
        .await
        .unwrap()
        .expect("obligation must exist");
    let current_slot = ctx.get_current_slot().await;
    let mut data = account.data.clone();
    // Anchor layout: 8-byte discriminator + zero-copy Obligation.
    let obligation: &mut kamino_lending::Obligation = bytemuck::from_bytes_mut(&mut data[8..]);
    obligation
        .last_update
        .update_slot(current_slot, kamino_lending::PriceStatusFlags::all());
    let mut new_account =
        AccountSharedData::new(account.lamports, account.data.len(), &account.owner);
    new_account.set_data(data);
    ctx.set_account(&obligation_pk, new_account);
}

async fn read_klend_obligation(
    ctx: &mut TestContext,
    obligation_pk: Pubkey,
) -> kamino_lending::Obligation {
    let account = ctx
        .get_account(obligation_pk)
        .await
        .unwrap()
        .expect("obligation must exist");
    bytemuck::pod_read_unaligned(
        &account.data[8..8 + std::mem::size_of::<kamino_lending::Obligation>()],
    )
}

async fn expected_scope_priced_aum_bits(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    obligation_pk: Pubkey,
    sol_reserve: &ReserveAccounts,
    usdc_reserve: &ReserveAccounts,
) -> u128 {
    let vault_state = vault.state(ctx).await;
    let obligation = read_klend_obligation(ctx, obligation_pk).await;
    let sol_reserve_state = ctx.get_reserve(sol_reserve).await;
    let usdc_reserve_state = ctx.get_reserve(usdc_reserve).await;
    let sol_price = TokenPrice::new(
        Fraction::from_num(setup::get_scope_token_price(ctx, vault, "SOL").await),
        sol_reserve_state
            .liquidity
            .mint_decimals
            .try_into()
            .unwrap(),
    );
    let usdc_price = TokenPrice::new(
        Fraction::from_num(setup::get_scope_token_price(ctx, vault, "USDC").await),
        usdc_reserve_state
            .liquidity
            .mint_decimals
            .try_into()
            .unwrap(),
    );

    let sol_mint = sol_reserve.liquidity_mint.pubkey();
    let usdc_mint = usdc_reserve.liquidity_mint.pubkey();
    let free_sol = vault_state
        .iter_enabled_tokens()
        .find(|token| token.mint == sol_mint)
        .unwrap()
        .available()
        .to_aum(&sol_price, RoundingMethod::Floor);
    let free_usdc = vault_state
        .iter_enabled_tokens()
        .find(|token| token.mint == usdc_mint)
        .unwrap()
        .available()
        .to_aum(&usdc_price, RoundingMethod::Floor);

    let sol_collateral = obligation
        .active_deposits()
        .find(|deposit| deposit.deposit_reserve == sol_reserve.address.pubkey())
        .unwrap();
    let deposited_sol_liquidity = sol_reserve_state
        .collateral_exchange_rate()
        .fraction_collateral_to_liquidity(Fraction::from(sol_collateral.deposited_amount));
    let deposited_sol_aum =
        sol_price.fraction_to_aum(deposited_sol_liquidity, RoundingMethod::Floor);

    let usdc_borrow = obligation
        .active_borrows()
        .find(|borrow| borrow.borrow_reserve == usdc_reserve.address.pubkey())
        .unwrap();
    let borrowed_usdc_aum =
        usdc_price.fraction_to_aum(usdc_borrow.borrowed_amount(), RoundingMethod::Ceil);

    let net_aum =
        free_sol + free_usdc + NetAum::net_from_diff(deposited_sol_aum, borrowed_usdc_aum);
    net_aum.check_positive().unwrap().to_bits()
}

// The leg sweep re-checks every leg reserve's klend freshness: a reserve that is key-correct
// and price-matched but refreshed in an earlier slot must be rejected with `ReserveStale`.
#[tokio::test]
async fn refresh_vault_rejects_stale_leg_reserve() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    // A slot later both the obligation and its leg reserves are stale; re-freshen ONLY the
    // obligation, so the loader's per-leg reserve staleness check is the one that fires.
    ctx.fast_forward_seconds(1).await;
    force_freshen_obligation(&mut ctx, obligation_pk).await;

    let accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::refresh_vault(&mut ctx, &admin, &vault, accounts).await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ReserveStale, 0),
    );
}

// ── Task 6, Step 4: scope-basis assertion ────────────────────────────────

#[tokio::test]
async fn aum_view_is_scope_priced_not_reserve_priced_within_tolerance() {
    let (mut ctx, vault, market, sol_reserve, usdc_reserve, obligation_pk) =
        setup_vault_with_legs().await;
    let admin = ctx.initial_market_owner.clone();
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxPriceDivergenceBps(sol_mint, 100),
    )
    .await;

    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let aum_at_baseline = readonly_aum(&mut ctx, &admin, &vault).await.unwrap();

    // +0.5%: within the 1% tolerance, so the view succeeds without a re-refresh. If the AUM
    // computation used klend's stale cached price instead of scope, this reading would be
    // unchanged from the baseline.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.5, 100.5).await;
    let aum_with_stale_reserve_cache = readonly_aum(&mut ctx, &admin, &vault).await.unwrap();
    let expected_scope_priced_aum = expected_scope_priced_aum_bits(
        &mut ctx,
        &vault,
        obligation_pk,
        &sol_reserve,
        &usdc_reserve,
    )
    .await;

    // Re-syncing klend's cache to the same new scope price must not change the reading.
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let aum_after_refresh = readonly_aum(&mut ctx, &admin, &vault).await.unwrap();
    let expected_after_refresh = expected_scope_priced_aum_bits(
        &mut ctx,
        &vault,
        obligation_pk,
        &sol_reserve,
        &usdc_reserve,
    )
    .await;

    assert_ne!(aum_with_stale_reserve_cache, aum_at_baseline);
    assert_eq!(aum_with_stale_reserve_cache, expected_scope_priced_aum);
    assert_eq!(aum_after_refresh, expected_after_refresh);
    assert_eq!(expected_scope_priced_aum, expected_after_refresh);
}

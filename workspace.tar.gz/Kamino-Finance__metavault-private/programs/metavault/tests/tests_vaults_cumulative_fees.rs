//! Fee accounting across deposit/withdraw cycles: what `cumulative_mgmt_fees_sf` and
//! `cumulative_perf_fees_sf` accrue, and that together they equal `pending_fees_sf`.
//!
//! These tests do not check gross vault yield against the fees taken out of it. The identity
//! they used to assert was written against a `cumulative_earned_interest_sf` counter that has
//! since been removed, and no other on-chain value exposes gross yield — reinstating the check
//! means reconstructing yield from token balances and payouts instead.

use ::metavault::program_test::VaultDepositorAccounts;
use fixed::types::U68F60 as Fraction;
use kamino_lending::{
    assert_fuzzy_eq,
    program_test::common::math::usdc_decimal_to_u64,
    utils::{to_sf, FULL_BPS},
};
use metavault::{
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, YEAR},
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_no_yield_no_fees_cumulative_fees_stay_zero() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(50.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    let withdraw = deposit;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));
}

#[tokio::test]
async fn test_no_yield_mgmt_fee_equal_total_fee() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let mgmt_fee_bps = 100;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(mgmt_fee_bps),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));
    assert_eq!(vault_state.pending_fees_sf, 0);

    let balance_after_first_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balance_after_first_deposit.tokens["USDC"], 0);
    assert_eq!(balance_after_first_deposit.shares, deposit - 1);

    // advance a year
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    let vault_state = vault.state(&mut ctx).await;
    let mgmt_fee = Fraction::from(mgmt_fee_bps * u64::from(YEAR))
        / Fraction::from(u64::from(YEAR) * u64::from(FULL_BPS));
    let expected_total_fee: Fraction =
        Fraction::from(vault_state.shares_issued) * mgmt_fee / (Fraction::ONE - mgmt_fee);

    // user withdraws everything and check the management fee was applied and the mgmt fee equals to the negative net yield
    client::withdraw(&mut ctx, &vault, &depositor, deposit, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after_withdraw = depositor.balances(&mut ctx).await;

    assert_fuzzy_eq!(balances_after_withdraw.tokens["USDC"], usdc(99.0), 1);
    assert_eq!(balances_after_withdraw.shares, 0);

    assert_eq!(
        vault_state.shares_issued,
        INITIAL_DEPOSIT_SIZE + Fraction::from_bits(vault_state.pending_fees_sf).to_num::<u64>()
    );
    assert_fuzzy_eq!(
        vault_state.pending_fees_sf,
        to_sf(expected_total_fee),
        to_sf(1)
    );

    assert_fuzzy_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        to_sf(expected_total_fee),
        to_sf(1)
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));
    assert_eq!(
        vault_state.pending_fees_sf,
        vault_state.cumulative_mgmt_fees_sf
    );

    let deposit = usdc(10.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let vault_state = vault.state(&mut ctx).await;
    let balance_after_second_deposit = depositor.balances(&mut ctx).await;
    let _actual_deposit =
        balances_after_withdraw.tokens["USDC"] - balance_after_second_deposit.tokens["USDC"]; // we have some dust as the price is not exactly 1 and we take just enough for the minted shares

    assert!(balance_after_second_deposit.shares > deposit); // get more shares than deposited amount as the share price < 1

    assert_fuzzy_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        to_sf(expected_total_fee),
        to_sf(1)
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));
    assert_eq!(
        vault_state.pending_fees_sf,
        vault_state.cumulative_mgmt_fees_sf
    );

    // advance a year
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    let vault_state = vault.state(&mut ctx).await;
    let new_mgmt_fee = Fraction::from(mgmt_fee_bps * u64::from(YEAR))
        / Fraction::from(u64::from(YEAR) * u64::from(FULL_BPS));
    let new_expected_fee: Fraction =
        Fraction::from(vault_state.shares_issued) * new_mgmt_fee / (Fraction::ONE - new_mgmt_fee);
    // Deposit 10 lamport so that it updates the fee trackers
    client::withdraw(&mut ctx, &vault, &depositor, 10, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let expected_total_fee = expected_total_fee + new_expected_fee;

    assert_fuzzy_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        to_sf(expected_total_fee),
        to_sf(2)
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));
    assert_eq!(
        vault_state.pending_fees_sf,
        vault_state.cumulative_mgmt_fees_sf
    );
}

#[tokio::test]
async fn test_yield_with_no_fees_accrues_entirely_to_holders() {
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    // advance 30 days
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", deposit).await;

    // withdraw half of the shares
    let shares_to_withdraw = deposit / 2;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that the user received more than half of the deposited amount as we have yield
    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    assert!(balances_after_first_withdraw.tokens["USDC"] > deposit / 2);
    assert_eq!(balances_after_first_withdraw.shares, deposit / 2 - 1);

    let vault_state = vault.state(&mut ctx).await;
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit + INITIAL_DEPOSIT_SIZE * 3 / 2,
        2
    );
    assert_eq!(
        vault_state.shares_issued,
        deposit / 2 - 1 + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state.pending_fees_sf, 0);

    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    // advance 60 days then withdraw the rest of the shares and check that the user received the rest of the yield
    ctx.fast_forward_seconds(u64::from(YEAR) / 6).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    let balances_after_final_withdraw = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert!(balances_after_final_withdraw.tokens["USDC"] > usdc(100.0));
    assert_eq!(balances_after_final_withdraw.shares, 0);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        2 * INITIAL_DEPOSIT_SIZE,
        4
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);

    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));
}

#[tokio::test]
async fn test_with_yield_and_performance_fee() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(1000),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    // advance 30 days
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", deposit).await;

    // withdraw half of the shares
    let shares_to_withdraw = deposit / 2;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that the user received more than half of the deposited amount as we have yield
    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    assert!(balances_after_first_withdraw.tokens["USDC"] > usdc(50.0));
    assert_eq!(balances_after_first_withdraw.shares, deposit / 2 - 1);

    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.pending_fees_sf > 0);

    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(
        vault_state.cumulative_perf_fees_sf,
        vault_state.pending_fees_sf,
    );

    // advance 60 days then withdraw the rest of the shares and check that the user received the rest of the yield
    ctx.fast_forward_seconds(u64::from(YEAR) / 6).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    let balances_after_final_withdraw = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert!(balances_after_final_withdraw.tokens["USDC"] > usdc(100.0));
    assert_eq!(balances_after_final_withdraw.shares, 0);

    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(
        vault_state.cumulative_perf_fees_sf,
        vault_state.pending_fees_sf,
    );
}

#[tokio::test]
async fn test_with_yield_and_mgmt_perf_fee() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(10),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(20),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, to_sf(0));
    assert_eq!(vault_state.cumulative_perf_fees_sf, to_sf(0));

    // advance half a year
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", deposit).await;

    // withdraw half of the shares
    let shares_to_withdraw = deposit / 2;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that the user received more than half of the deposited amount as we have yield
    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    assert!(balances_after_first_withdraw.tokens["USDC"] > deposit / 2);

    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.pending_fees_sf > 0);

    assert_eq!(
        vault_state.cumulative_perf_fees_sf + vault_state.cumulative_mgmt_fees_sf,
        vault_state.pending_fees_sf,
    );

    // advance half a year then withdraw the rest of the shares and check that the user user diff is the total net yield
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    let balances_after_final_withdraw = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_eq!(balances_after_final_withdraw.shares, 0);
    assert!(balances_after_final_withdraw.tokens["USDC"] > topup);

    // check that the cumulative mgmt and performance fee add up total pending fees
    assert_eq!(
        vault_state.cumulative_mgmt_fees_sf + vault_state.cumulative_perf_fees_sf,
        vault_state.pending_fees_sf,
    );
}

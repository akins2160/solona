//! BPF integration tests for the rolling deposit cap (tumbling-window USD rate-limit).

use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{program_test::common::math::usdc_decimal_to_u64, utils::to_sf};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

const HOUR: u64 = 3600;

/// Disabled cap (`interval_seconds == 0`) is a no-op even with `max == 0`.
#[tokio::test]
async fn test_disabled_default_allows_any_deposit() {
    let (mut ctx, vault, _owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let state = vault.state(&mut ctx).await;
    assert!(state.rolling_deposit_cap.is_disabled());

    let topup = usdc(10_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
}

/// Exhausting the cap within a window blocks subsequent deposits.
#[tokio::test]
async fn test_cap_exhausted_blocks_further_deposits() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(1000u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    let topup = usdc(2000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(600.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(400.0)).await;
    // Window now at $1000 / $1000. The next deposit (even tiny) must fail.
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RollingDepositCapExceeded, 1)
    );
}

/// Advancing the clock past the interval tumbles the window and re-opens capacity.
#[tokio::test]
async fn test_clock_warp_past_interval_resets_capacity() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(1000u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    let topup = usdc(3000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    // Saturate the cap.
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1000.0)).await;

    // Without a clock advance, even $1 fails.
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert!(res.is_err());

    // Advance just past the interval — the next deposit tumbles the window and succeeds.
    ctx.fast_forward_seconds(HOUR + 1).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(500.0)).await;
}

/// Klend-style reconfig preservation — admin updating the cap mid-window must NOT clear the
/// in-flight accumulator. The accumulator is only zeroed by a natural tumble.
#[tokio::test]
async fn test_reconfig_preserves_accumulator() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(1000u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    let topup = usdc(3000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1000.0)).await;

    // Tighten the cap mid-window. The accumulator was just at $1000 worth — it must remain.
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(500u64),
            interval_seconds: 2 * HOUR,
        },
    )
    .await;

    // Anchor stays where it was, so the original interval keeps running until the new anchor
    // is set on the next natural tumble. Immediately try to deposit anything → must fail.
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RollingDepositCapExceeded, 1)
    );

    // Advance past the new interval to reach the tumble — capacity returns.
    ctx.fast_forward_seconds(2 * HOUR + 1).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(500.0)).await;
}

/// Many small deposits aggregate up to the cap; the one that crosses the boundary fails.
#[tokio::test]
async fn test_small_deposits_aggregate_to_cap() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf: to_sf(100u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    let topup = usdc(200.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    // 9 × $10 = $90 — all succeed.
    for _ in 0..9 {
        client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(10.0)).await;
    }
    // 10th $10 push reaches $100 — boundary still passes (strict `>` rule).
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(10.0)).await;

    // Any further (even $0.01) fails.
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(0.01), 0).await;
    assert!(res.is_err());
}

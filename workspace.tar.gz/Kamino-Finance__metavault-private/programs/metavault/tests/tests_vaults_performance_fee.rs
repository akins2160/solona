use ::metavault::program_test::VaultDepositorAccounts;
use anchor_lang::Discriminator;
use anchor_spl::associated_token::get_associated_token_address;
use kamino_lending::{
    assert_almost_eq_fraction, assert_fuzzy_eq,
    fraction::Fraction,
    program_test::common::{
        consts::SCOPE_PROGRAM_ID, math::usdc_decimal_to_u64, token_operations::create_ata,
        types::TestContext,
    },
    utils::{scope::ScopePrices, to_sf, FULL_BPS},
    ScopeConfiguration,
};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup, ScopePrice, VaultAccounts,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, PERF_FEE_COOLDOWN_SECONDS, YEAR},
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::{account::Account, signer::Signer};
use usdc_decimal_to_u64 as usdc;

async fn set_scope_px_and_twap_at_indices(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    token_name: &str,
    price_index: usize,
    twap_index: usize,
    px: f64,
    twap_px: f64,
) {
    let (mut scope_price_acc, scope_info) = setup::get_scope_prices(ctx, vault, token_name).await;
    scope_price_acc.prices[price_index] = scope_price_acc.prices[scope_info.price_index];
    scope_price_acc.prices[twap_index] = scope_price_acc.prices[scope_info.twap_index];

    let clock = ctx.get_clock().await;
    for (index, price) in [(price_index, px), (twap_index, twap_px)] {
        let dated_price = &mut scope_price_acc.prices[index];
        dated_price.last_updated_slot = clock.slot;
        dated_price.unix_timestamp = clock.unix_timestamp as u64;
        dated_price.price.value = (price * 10_f64.powi(dated_price.price.exp as i32)) as u64;
    }

    let mut account = Account::new(
        u32::MAX as u64,
        8 + std::mem::size_of::<ScopePrices>(),
        &SCOPE_PROGRAM_ID,
    );
    account.data[..8].copy_from_slice(&ScopePrices::discriminator());
    account.data[8..].copy_from_slice(bytemuck::bytes_of(&scope_price_acc));
    ctx.set_account(&scope_info.scope_feed, account);
}

#[tokio::test]
async fn test_vault_performance_fee_is_set_correctly() {
    let (mut ctx, vault, owner, _, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(4000),
    )
    .await;

    // check the perf fee is set correctly
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 4000);
    assert_eq!(vault_state.management_fee_bps, 0);

    // update the management fee
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(50),
    )
    .await;

    // check the management fee is set correctly
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 4000);
    assert_eq!(vault_state.management_fee_bps, 50);

    // update both fees and check they were set correctly
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(30),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(20),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 30);
    assert_eq!(vault_state.management_fee_bps, 20);
}

#[tokio::test]
async fn test_set_invalid_perf_fee_fails() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    // update the management fee to a value bigger than the full bps
    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(10_100),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::PerformanceFeeGreaterThanMaxAllowed, 1)
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 0);
    assert_eq!(vault_state.management_fee_bps, 0);
}

#[tokio::test]
async fn test_perf_fee_no_impact_on_no_yield() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(1000),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // advance half a year
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws everything and check he received the same amount as he deposited
    client::withdraw(&mut ctx, &vault, &depositor, deposit - 1, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    assert_eq!(balances_after.tokens["USDC"], topup - 1);
    assert_eq!(balances_after.shares, 0);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
    assert!(vault_state.pending_fees_sf < to_sf(1));
    // The depositor's share mint rounds down, leaving 1 lamport of the deposit with the vault;
    // by the price-checkpoint design, any per-share price rise (including rounding dust) is
    // chargeable performance.
    assert!(vault_state.cumulative_perf_fees_sf < to_sf(1));
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, 0);
}

#[tokio::test]
async fn test_scope_basis_change_with_rebaseline_charges_no_phantom_perf_fee() {
    let (mut ctx, mut vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves(1).await;
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(1000),
    )
    .await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    let state_before_scope_update = vault.state(&mut ctx).await;
    let shares_before_scope_update = state_before_scope_update.shares_issued;
    let pending_fees_before_scope_update = state_before_scope_update.pending_fees_sf;
    let prev_aum_before_scope_update = state_before_scope_update.prev_aum_sf;

    let old_scope = vault.scope_prices[&usdc_mint].clone();
    let (new_price_index, new_twap_index) =
        vault.get_first_scope_idx_for_feed(old_scope.scope_feed);
    set_scope_px_and_twap_at_indices(
        &mut ctx,
        &vault,
        "USDC",
        new_price_index as usize,
        new_twap_index as usize,
        2.0,
        2.0,
    )
    .await;

    let new_scope_configuration = ScopeConfiguration {
        price_feed: old_scope.scope_feed,
        price_chain: [new_price_index, u16::MAX, u16::MAX, u16::MAX],
        twap_chain: [new_twap_index, u16::MAX, u16::MAX, u16::MAX],
    };
    vault.scope_prices.insert(
        usdc_mint,
        ScopePrice {
            scope_feed: old_scope.scope_feed,
            price_index: new_price_index as usize,
            twap_index: new_twap_index as usize,
        },
    );

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenScope(usdc_mint, new_scope_configuration),
    )
    .await;

    let state_after_scope_update = vault.state(&mut ctx).await;
    assert_eq!(
        state_after_scope_update.vault_tokens[0].scope_configuration,
        new_scope_configuration
    );
    assert_eq!(
        state_after_scope_update.shares_issued,
        shares_before_scope_update
    );
    assert_eq!(
        state_after_scope_update.pending_fees_sf,
        pending_fees_before_scope_update
    );
    assert_eq!(
        state_after_scope_update.prev_aum_sf,
        prev_aum_before_scope_update * 2
    );

    ctx.fast_forward_seconds(u64::from(PERF_FEE_COOLDOWN_SECONDS) + 1)
        .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 2.0, 2.0).await;
    client::refresh_vault(&mut ctx, &vault, &owner).await;

    let state_after_refresh = vault.state(&mut ctx).await;
    assert_eq!(
        state_after_refresh.shares_issued,
        shares_before_scope_update
    );
    // The rebaselined checkpoint stores a floored share price (2^-60 quanta), so reconstructing
    // its dollar value loses up to ~shares_issued quanta against the Ceil'd AUM: each cooldown
    // refresh may charge perf fees on that rounding dust, but never on the 2x valuation rebase
    // itself (which would be ~10% of half the AUM in shares).
    assert!(state_after_refresh.pending_fees_sf - pending_fees_before_scope_update < to_sf(1));
    assert!(state_after_refresh.cumulative_perf_fees_sf < to_sf(1));
    assert_eq!(state_after_refresh.cumulative_mgmt_fees_sf, 0);
}

#[tokio::test]
async fn test_simple_yield_perf_fee_collected_single_reserve() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let perf_fee_bps = 1500;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(perf_fee_bps),
    )
    .await;

    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    let vault_state_after_deposit = vault.state(&mut ctx).await;

    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
    assert_eq!(balances_after_deposit.shares, deposit - 1);

    assert_eq!(
        vault_state_after_deposit.vault_tokens[0].token_available,
        deposit + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(
        vault_state_after_deposit.shares_issued,
        deposit - 1 + INITIAL_DEPOSIT_SIZE
    );

    // advance an year
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", deposit + INITIAL_DEPOSIT_SIZE).await; // double all tokens

    // user withdraws everything and check 15% of the yield was taken as performance fee
    client::withdraw(&mut ctx, &vault, &depositor, deposit - 1, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let vault_state_after_withdraw = vault.state(&mut ctx).await;
    let perf_fee_accumulated = Fraction::from_bits(vault_state_after_withdraw.pending_fees_sf); // we don't have mgmt fees so the pending fees are the perf fees

    let expected_user_perf_fee = topup * perf_fee_bps / FULL_BPS as u64; // performance fee only on yield
    let expected_initial_deposit_perf_fee = INITIAL_DEPOSIT_SIZE * perf_fee_bps / FULL_BPS as u64; // performance fee only on yield
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        2 * topup - expected_user_perf_fee + 1
    );
    assert!(perf_fee_accumulated > 0);

    // verify that out of the total yield we took the correct ratio of the perf fee
    let expected_perf_fee = ((deposit + INITIAL_DEPOSIT_SIZE) as f64 * 0.075 / 0.925) as u64; // 1.5% applied on yield (half of total tokens)
    assert_eq!(
        Fraction::from_bits(vault_state_after_withdraw.pending_fees_sf).to_num::<u64>(),
        expected_perf_fee
    );
    assert_eq!(vault_state_after_withdraw.cumulative_mgmt_fees_sf, 0);
    assert_eq!(
        vault_state_after_withdraw.cumulative_perf_fees_sf,
        vault_state_after_withdraw.pending_fees_sf
    );

    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: [(
            "USDC".to_string(),
            get_associated_token_address(&owner.pubkey(), &vault.vault_tokens["USDC"].token_mint),
        )]
        .iter()
        .cloned()
        .collect(),
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;

    assert_almost_eq_fraction!(
        Fraction::from_num(owner_balances.tokens["USDC"]),
        Fraction::from_num(owner_initial_token_balance)
            + Fraction::from_num(expected_user_perf_fee),
    );

    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.pending_fees_sf < to_sf(1));
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        2 * INITIAL_DEPOSIT_SIZE - expected_initial_deposit_perf_fee,
        1
    );
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, 0);
    assert_fuzzy_eq!(
        vault_state.cumulative_perf_fees_sf,
        vault_state_after_withdraw.pending_fees_sf,
        1
    );
}

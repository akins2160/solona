use kamino_lending::program_test::common::types::{
    KaminoMarkets, MSpec, MarketsSpec, MintSpec, RSpec, ReserveAccounts, TestContext,
};
use maplit::hashmap;
use metavault::program_test::{
    client::{self, get_ordered_scope_and_obligation_accounts},
    fixtures::setup_markets_with_weights,
    instructions, VaultAccounts, VaultDepositorAccounts,
};
use solana_program_test::tokio;
use solana_sdk::{pubkey::Pubkey, signer::Signer, transaction::Transaction};

// --- Two-token, single-obligation baselines. ---

#[tokio::test]
async fn tx_size_deposit_obligation_collateral_fits() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec_2_tokens(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 5_000_000_000,
            "USDC".to_string() => 1_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        scope_and_obligation_accounts,
        vec![],
        vec![],
    )
    .await;

    assert_tx_fits("deposit_obligation_collateral", &tx);
}

#[tokio::test]
async fn tx_size_borrow_obligation_liquidity_fits() {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec_2_tokens(), vec![5u64, 5u64]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 5_000_000_000,
            "USDC".to_string() => 1_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 5_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;
    client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        1_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        10_000,
        scope_and_obligation_accounts,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_tx_fits("borrow_obligation_liquidity", &tx);
}

// --- 6-token, 3-obligation matrix: worst case for tx-size budget. ---
//
// MAX_OBLIGATIONS_PER_VAULT = 3 and up to 6 vault tokens. Each handler loads
// `tokens_count + obligations_count` scope/obligation accounts; borrow additionally forwards
// deposit reserves into klend's LTV CPI.
//
// Caveat: the prelude builder only refreshes the *target* obligation. With `ALL_CHECKS` on every
// obligation's staleness gate, a real production tx must `refresh_obligation` for each other
// registered obligation too — ~96 extra bytes apiece, not reflected here.

#[tokio::test]
async fn tx_size_deposit_obligation_collateral_3x6_fits() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, _) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        100_000_000,
        scope_and_obligation_accounts,
        vec![],
        vec![],
    )
    .await;

    assert_tx_fits("deposit_obligation_collateral_3x6", &tx);
}

#[tokio::test]
async fn tx_size_withdraw_obligation_collateral_3x6_fits() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, _) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    // The tx is only built (not sent), so the empty collateral entry doesn't matter — account
    // metas (and thus wire size) are identical whether the call would succeed or not.

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::withdraw_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        50_000_000,
        scope_and_obligation_accounts,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_tx_fits("withdraw_obligation_collateral_3x6", &tx);
}

#[tokio::test]
async fn tx_size_borrow_obligation_liquidity_3x6_fits() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, usdc_reserve) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        10_000,
        scope_and_obligation_accounts,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_tx_fits("borrow_obligation_liquidity_3x6", &tx);
}

// Borrow under an elevation group: klend iterates ALL active deposits of the obligation and
// requires each one in `remaining_accounts`. Each extra deposit reserve adds ~147 bytes (the
// metavault meta + the prelude's `refresh_reserve` with its oracle/farm accounts). At the 3×6
// config the breakeven is N=2; beyond that, callers need an AddressLookupTable.
#[tokio::test]
async fn tx_size_borrow_obligation_liquidity_3x6_fits_with_max_2_collaterals() {
    let (mut ctx, markets, vault, obligation_pk, _, usdc_reserve) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    let all_reserves = all_6_reserves(&markets);
    let sizes = measure_borrow_sizes_per_n(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        &all_reserves,
    )
    .await;
    for (n, size) in sizes.iter().enumerate() {
        println!(
            "tx_size borrow_obligation_liquidity_3x6 N={}: {} bytes",
            n + 1,
            size
        );
    }
    // Borrow fits up to N=2; breaks at N=3.
    kamino_lending::assert_lte!(sizes[0], MAX_TX_BYTES);
    kamino_lending::assert_lte!(sizes[1], MAX_TX_BYTES);
    kamino_lending::assert_gt!(sizes[2], MAX_TX_BYTES);
}

// Repay has slightly fewer fixed accounts than borrow (no `borrow_reserve_liquidity_fee_receiver`),
// so the breakeven is one higher: N=3.
#[tokio::test]
async fn tx_size_repay_obligation_liquidity_3x6_fits_with_max_3_collaterals() {
    let (mut ctx, markets, vault, obligation_pk, _, usdc_reserve) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    let all_reserves = all_6_reserves(&markets);
    let sizes = measure_repay_sizes_per_n(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        &all_reserves,
    )
    .await;
    for (n, size) in sizes.iter().enumerate() {
        println!(
            "tx_size repay_obligation_liquidity_3x6 N={}: {} bytes",
            n + 1,
            size
        );
    }
    // Repay fits up to N=3; breaks at N=4.
    kamino_lending::assert_lte!(sizes[0], MAX_TX_BYTES);
    kamino_lending::assert_lte!(sizes[1], MAX_TX_BYTES);
    kamino_lending::assert_lte!(sizes[2], MAX_TX_BYTES);
    kamino_lending::assert_gt!(sizes[3], MAX_TX_BYTES);
}

// `request_elevation_group` has a much leaner fixed-account set than borrow/repay (no token_vault
// / liquidity_mint / fee_receiver) AND skips the scope+obligation prelude.
#[tokio::test]
async fn tx_size_request_elevation_group_3x6_fits() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, _) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();

    let tx = instructions::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        &market,
        obligation_pk,
        1,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    assert_tx_fits("request_elevation_group_3x6", &tx);
}

#[tokio::test]
async fn tx_size_repay_obligation_liquidity_3x6_fits() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, usdc_reserve) =
        setup_3x6_with_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        1_000,
        scope_and_obligation_accounts,
        vec![&sol_reserve],
        vec![&usdc_reserve],
    )
    .await;

    assert_tx_fits("repay_obligation_liquidity_3x6", &tx);
}

// --- 3-token, single obligation with 2 deposit legs + 1 borrow leg: heavier leg-reserve segment. ---
//
// The leg-reserve segment scales with *active legs on registered obligations*, not with vault
// token count or registered-obligation count — so a small vault can still carry a heavy segment if
// one obligation is highly levered. Theoretical max: MAX_OBLIGATIONS_PER_VAULT (3) x klend's
// per-obligation leg cap (13 deposits + borrows) = 39 leg-reserve accounts. That worst case is far
// beyond what fits in a single transaction; production flows driving a near-max obligation must
// use an Address Lookup Table. These tests only confirm a moderate, realistic case (3 real legs on
// one obligation) still fits without one.

// Measured at ~1189/1232 bytes — a ~43-byte margin. A 4th leg on this obligation, or a second
// registered obligation needing its own refresh, would likely exceed the limit.
#[tokio::test]
async fn tx_size_borrow_obligation_liquidity_3_legs_fits() {
    let (
        mut ctx,
        markets,
        vault,
        _depositor,
        obligation_pk,
        sol_reserve,
        eth_reserve,
        usdc_reserve,
    ) = setup_3_token_obligation_with_2_deposit_and_1_borrow_leg().await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        10_000,
        scope_and_obligation_accounts,
        vec![&sol_reserve, &eth_reserve],
        vec![],
    )
    .await;

    assert_tx_fits("borrow_obligation_liquidity_3_legs", &tx);
}

#[tokio::test]
async fn tx_size_withdraw_3_legs_fits() {
    let (
        mut ctx,
        _markets,
        vault,
        depositor,
        _obligation_pk,
        _sol_reserve,
        _eth_reserve,
        _usdc_reserve,
    ) = setup_3_token_obligation_with_2_deposit_and_1_borrow_leg().await;
    let vault_token = vault.vault_tokens.get("SOL").unwrap();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        vault_token,
        "SOL",
        scope_and_obligation_accounts,
        1_000,
        0,
    )
    .await;

    assert_tx_fits("withdraw_3_legs", &tx);
}

// The user-facing withdraw shape: klend's same-slot freshness rule forces the refresh prelude
// into the withdraw transaction itself, so this measures the packet users actually send —
// unlike `tx_size_withdraw_3_legs_fits`, which measures the op instruction alone.
#[tokio::test]
async fn tx_size_withdraw_3_legs_with_refresh_prelude_fits() {
    let (mut ctx, markets, vault, depositor, obligation_pk, sol_reserve, eth_reserve, usdc_reserve) =
        setup_3_token_obligation_with_2_deposit_and_1_borrow_leg().await;
    let market = markets.markets[0].primary_market.clone();
    let vault_token = vault.vault_tokens.get("SOL").unwrap();

    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let tx = instructions::withdraw_with_refresh_prelude(
        &mut ctx,
        &vault,
        &depositor,
        vault_token,
        "SOL",
        scope_and_obligation_accounts,
        1_000,
        0,
        &market,
        &sol_reserve,
        obligation_pk,
        vec![&sol_reserve, &eth_reserve],
        vec![&usdc_reserve],
    )
    .await;

    assert_tx_fits("withdraw_3_legs_with_refresh_prelude", &tx);
}

fn make_spec_3_tokens() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "ETH".to_string() => MintSpec::spl(8, 2000.0),
        },
        // USDC reserve seeded with 10,000 USDC so we can borrow against SOL + ETH collateral.
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("ETH", 0),
        ])],
    }
}

// Vault with 3 tokens (USDC/SOL/ETH) and a single obligation actually carrying 2 deposit legs
// (SOL, ETH) + 1 borrow leg (USDC) — unlike `setup_3x6_with_obligation`, the collateral/borrow ops
// below are sent for real, so `get_ordered_scope_and_obligation_accounts` reads a non-empty
// leg-reserve segment off the obligation's genuine on-chain state.
async fn setup_3_token_obligation_with_2_deposit_and_1_borrow_leg() -> (
    TestContext,
    KaminoMarkets,
    VaultAccounts,
    VaultDepositorAccounts,
    Pubkey,
    ReserveAccounts,
    ReserveAccounts,
    ReserveAccounts,
) {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec_3_tokens(), vec![1, 1, 1]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let eth_reserve = markets.markets[0].reserves["ETH"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 2_000_000_000,
            "SOL".to_string() => 10_000_000_000,
            "ETH".to_string() => 500_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "ETH", 500_000_000).await;

    client::init_obligation(&mut ctx, &admin, &vault, &market, 0).await;
    let obligation_pk =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    // Deposit leg 1: SOL.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    // Deposit leg 2: ETH.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &eth_reserve,
        obligation_pk,
        "ETH",
        250_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    // Borrow leg: USDC, against both deposit legs.
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve, &eth_reserve],
        vec![],
    )
    .await
    .unwrap();

    (
        ctx,
        markets,
        vault,
        depositor,
        obligation_pk,
        sol_reserve,
        eth_reserve,
        usdc_reserve,
    )
}

// Solana tx packet size ceiling.
const MAX_TX_BYTES: usize = 1232;

fn make_spec_2_tokens() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

fn make_spec_6_tokens() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "ETH".to_string() => MintSpec::spl(8, 2000.0),
            "BTC".to_string() => MintSpec::spl(8, 50_000.0),
            "JTO".to_string() => MintSpec::spl(9, 3.0),
            "BONK".to_string() => MintSpec::spl(5, 0.00001),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("ETH", 0),
            RSpec::new("BTC", 0),
            RSpec::new("JTO", 0),
            RSpec::new("BONK", 0),
        ])],
    }
}

// Vault with 6 vault tokens + 3 registered obligations. Returns the first obligation's pubkey
// plus SOL and USDC reserves for the caller to drive ops with.
async fn setup_3x6_with_obligation() -> (
    TestContext,
    KaminoMarkets,
    VaultAccounts,
    Pubkey,
    ReserveAccounts,
    ReserveAccounts,
) {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_spec_6_tokens(), vec![1, 1, 1, 1, 1, 1]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 1_000_000_000,
            "SOL".to_string() => 5_000_000_000,
            "ETH".to_string() => 100_000_000,
            "BTC".to_string() => 100_000_000,
            "JTO".to_string() => 100_000_000_000,
            "BONK".to_string() => 100_000_000,
        },
    )
    .await;
    for token in ["USDC", "SOL", "ETH", "BTC", "JTO", "BONK"] {
        client::deposit(&mut ctx, &vault, &depositor, token, 100_000).await;
    }
    for id in 0..3 {
        client::init_obligation(&mut ctx, &admin, &vault, &market, id).await;
    }
    let obligation_pk =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    (
        ctx,
        markets,
        vault,
        obligation_pk,
        sol_reserve,
        usdc_reserve,
    )
}

// All 6 reserves in a stable order, for the max-deposits tx-size tests.
fn all_6_reserves(markets: &KaminoMarkets) -> Vec<ReserveAccounts> {
    ["USDC", "SOL", "ETH", "BTC", "JTO", "BONK"]
        .into_iter()
        .map(|n| markets.markets[0].reserves[n].clone())
        .collect()
}

#[allow(clippy::too_many_arguments)]
async fn measure_borrow_sizes_per_n(
    ctx: &mut TestContext,
    admin: &std::sync::Arc<solana_sdk::signature::Keypair>,
    vault: &VaultAccounts,
    market: &kamino_lending::program_test::common::types::LendingMarketAccounts,
    borrow_reserve: &ReserveAccounts,
    obligation_pk: Pubkey,
    all_reserves: &[ReserveAccounts],
) -> Vec<usize> {
    let mut sizes = Vec::with_capacity(all_reserves.len());
    for n in 1..=all_reserves.len() {
        let reserves: Vec<&ReserveAccounts> = all_reserves.iter().take(n).collect();
        let scope_and_obligation_accounts =
            get_ordered_scope_and_obligation_accounts(ctx, vault).await;
        let tx = instructions::borrow_obligation_liquidity(
            ctx,
            admin,
            vault,
            market,
            borrow_reserve,
            obligation_pk,
            "USDC",
            10_000,
            scope_and_obligation_accounts,
            reserves,
            vec![],
        )
        .await;
        sizes.push(wire_size(&tx));
    }
    sizes
}

#[allow(clippy::too_many_arguments)]
async fn measure_repay_sizes_per_n(
    ctx: &mut TestContext,
    admin: &std::sync::Arc<solana_sdk::signature::Keypair>,
    vault: &VaultAccounts,
    market: &kamino_lending::program_test::common::types::LendingMarketAccounts,
    repay_reserve: &ReserveAccounts,
    obligation_pk: Pubkey,
    all_reserves: &[ReserveAccounts],
) -> Vec<usize> {
    let mut sizes = Vec::with_capacity(all_reserves.len());
    for n in 1..=all_reserves.len() {
        let reserves: Vec<&ReserveAccounts> = all_reserves.iter().take(n).collect();
        let scope_and_obligation_accounts =
            get_ordered_scope_and_obligation_accounts(ctx, vault).await;
        let tx = instructions::repay_obligation_liquidity(
            ctx,
            admin,
            vault,
            market,
            repay_reserve,
            obligation_pk,
            "USDC",
            1_000,
            scope_and_obligation_accounts,
            reserves,
            vec![repay_reserve],
        )
        .await;
        sizes.push(wire_size(&tx));
    }
    sizes
}

fn wire_size(tx: &Transaction) -> usize {
    // serialized message + 1-byte compact-u16 prefix + 64 bytes per signature
    tx.message().serialize().len() + tx.signatures.len() * 64 + 1
}

fn assert_tx_fits(name: &str, tx: &Transaction) {
    let size = wire_size(tx);
    println!("tx_size {}: {} bytes", name, size);
    kamino_lending::assert_lte!(size, MAX_TX_BYTES);
}

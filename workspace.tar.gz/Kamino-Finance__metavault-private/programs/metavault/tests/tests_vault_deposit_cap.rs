//! BPF integration tests for the vault AUM hard cap (feature: `DepositCapUsd`).

use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{program_test::common::math::usdc_decimal_to_u64, utils::to_sf};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

/// Default-disabled (`deposit_cap_usd_sf == 0`) lets any reasonable deposit through.
#[tokio::test]
async fn test_disabled_default_allows_arbitrary_deposit() {
    let (mut ctx, vault, _owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    // Vault state right after fixture init: cap must be zero (disabled).
    let initial_state = vault.state(&mut ctx).await;
    assert_eq!(initial_state.deposit_cap_usd_sf, 0);
    assert!(!initial_state.is_deposit_cap_enabled());

    let topup = usdc(10_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
}

/// Below the cap, deposits pass. (The strict-`>` equality boundary is unit-tested at the
/// primitive level — here we only need to confirm the integration path admits sub-cap deposits.)
#[tokio::test]
async fn test_below_cap_passes() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(to_sf(1100u64)),
    )
    .await;

    let topup = usdc(1000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
}

/// One-above-boundary fails with `DepositAumCapExceeded`.
#[tokio::test]
async fn test_one_above_cap_fails() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(to_sf(1000u64)),
    )
    .await;

    // Deposit a fraction over: the existing seeded AUM puts us above $1000 total.
    let topup = usdc(1000.0) + usdc(0.1);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", topup, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAumCapExceeded, 1)
    );
}

/// Admin tightening the cap below current AUM blocks new deposits without unwinding state.
#[tokio::test]
async fn test_tighten_cap_below_current_aum_blocks_new_deposits() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    // First, deposit $500 with no cap.
    let topup = usdc(2000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(500.0)).await;

    // Admin tightens cap to $100 (well below the ~$500 already in the vault).
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(to_sf(100u64)),
    )
    .await;

    // Any new deposit should fail — existing positions remain untouched.
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAumCapExceeded, 1)
    );

    // State invariants: cap is the new value, shares were not retroactively burned.
    let state = vault.state(&mut ctx).await;
    assert_eq!(state.deposit_cap_usd_sf, to_sf(100u64));
    assert!(state.shares_issued > 0);
}

/// Round-trip the cap value through `UpdateVaultConfigParams::DepositCapUsd`.
#[tokio::test]
async fn test_admin_update_round_trips() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let cap_bits = to_sf(5_000_000u64); // $5M
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(cap_bits),
    )
    .await;

    let state = vault.state(&mut ctx).await;
    assert_eq!(state.deposit_cap_usd_sf, cap_bits);
    assert!(state.is_deposit_cap_enabled());

    // Setting back to 0 disables.
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::DepositCapUsd(0),
    )
    .await;
    let state = vault.state(&mut ctx).await;
    assert_eq!(state.deposit_cap_usd_sf, 0);
    assert!(!state.is_deposit_cap_enabled());
}

use borsh::BorshSerialize;
use kamino_lending::program_test::common::{
    math::sol_decimal_to_u64,
    runner::test,
    setup::{create_program_data_account, funded_kp},
};
use metavault::{
    metavault_error,
    program_test::{client, fixtures, get_global_config_state},
    utils::{global_config::UpdateGlobalConfigMode, pda},
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::{pubkey::Pubkey, signer::Signer};

#[tokio::test]
async fn test_init_global_config() {
    let mut program = fixtures::program();
    let owner = funded_kp(&mut program, sol_decimal_to_u64(10000.0));
    let global_config = pda::global_config();
    create_program_data_account(&mut program, metavault::ID, owner.pubkey());

    let mut ctx = test::start(program, &owner).await;

    client::init_global_config(&mut ctx, &owner, &global_config)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_update_global_config() {
    let mut program = fixtures::program();
    let owner = funded_kp(&mut program, sol_decimal_to_u64(10000.0));
    let global_config = pda::global_config();
    create_program_data_account(&mut program, metavault::ID, owner.pubkey());

    let mut ctx = test::start(program, &owner).await;

    client::init_global_config(&mut ctx, &owner, &global_config)
        .await
        .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;

    assert_eq!(global_config_state.global_admin, owner.pubkey());
    assert_eq!(global_config_state.pending_admin, Pubkey::default());
    assert_eq!(global_config_state.withdrawal_fee_lamports, 0);
    assert_eq!(global_config_state.withdrawal_fee_bps, 0);

    // check updating the penalties above max allowed fails
    let res = client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::MinWithdrawalFeeLamports,
        10_001u64.try_to_vec().unwrap(),
        &owner,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::LamportsFeeGreaterThanMaxAllowed, 0)
    );
    let res = client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::MinWithdrawalFeeBPS,
        1001u64.try_to_vec().unwrap(),
        &owner,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSFeeGreaterThanMaxAllowed, 0)
    );

    // update an u64 field
    let new_min_withdrawal_fee_lamports = 20u64;
    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::MinWithdrawalFeeLamports,
        new_min_withdrawal_fee_lamports.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;

    assert_eq!(
        global_config_state.withdrawal_fee_lamports,
        new_min_withdrawal_fee_lamports
    );
    assert_eq!(global_config_state.withdrawal_fee_bps, 0);
    assert_eq!(global_config_state.pending_admin, Pubkey::default());
    assert_eq!(global_config_state.global_admin, owner.pubkey());

    let new_min_withdrawal_fee_bps = 1000u64;
    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::MinWithdrawalFeeBPS,
        new_min_withdrawal_fee_bps.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;

    assert_eq!(
        global_config_state.withdrawal_fee_bps,
        new_min_withdrawal_fee_bps
    );
    assert_eq!(
        global_config_state.withdrawal_fee_lamports,
        new_min_withdrawal_fee_lamports
    );
    assert_eq!(global_config_state.pending_admin, Pubkey::default());
    assert_eq!(global_config_state.global_admin, owner.pubkey());

    let new_pending_admin = Pubkey::new_unique();
    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::PendingAdmin,
        new_pending_admin.to_bytes().to_vec(),
        &owner,
    )
    .await
    .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;

    assert_eq!(global_config_state.pending_admin, new_pending_admin);
    assert_eq!(global_config_state.global_admin, owner.pubkey());
    assert_eq!(
        global_config_state.withdrawal_fee_lamports,
        new_min_withdrawal_fee_lamports
    );
    assert_eq!(
        global_config_state.withdrawal_fee_bps,
        new_min_withdrawal_fee_bps
    );

    // Ensure all UpdateGlobalConfigMode variants are tested
    // This will fail to compile if new variants are added
    let tested_modes = [
        UpdateGlobalConfigMode::PendingAdmin,
        UpdateGlobalConfigMode::MinWithdrawalFeeLamports,
        UpdateGlobalConfigMode::MinWithdrawalFeeBPS,
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        UpdateGlobalConfigMode::KrfqSwapAuthority,
    ];

    // Verify we've covered all variants by checking that we have exactly 6 variants
    // If new variants are added, this test will need to be updated
    assert_eq!(
        tested_modes.len(),
        6,
        "All UpdateGlobalConfigMode variants must be tested. Current count: {}, expected: 6",
        tested_modes.len()
    );

    // Additional compile-time safety: ensure all variants are handled
    // This match will fail to compile if new variants are added
    for mode in &tested_modes {
        match mode {
            UpdateGlobalConfigMode::PendingAdmin => {}
            UpdateGlobalConfigMode::MinWithdrawalFeeLamports => {}
            UpdateGlobalConfigMode::MinWithdrawalFeeBPS => {}
            UpdateGlobalConfigMode::MinDepositFeeLamports => {}
            UpdateGlobalConfigMode::MinDepositFeeBPS => {}
            UpdateGlobalConfigMode::KrfqSwapAuthority => {}
        }
    }
}

#[tokio::test]
async fn test_update_global_config_admin() {
    let mut program = fixtures::program();
    let owner = funded_kp(&mut program, sol_decimal_to_u64(10000.0));
    let new_admin: std::sync::Arc<solana_sdk::signature::Keypair> =
        funded_kp(&mut program, sol_decimal_to_u64(10000.0));

    let global_config = pda::global_config();
    create_program_data_account(&mut program, metavault::ID, owner.pubkey());

    let mut ctx = test::start(program, &owner).await;

    client::init_global_config(&mut ctx, &owner, &global_config)
        .await
        .unwrap();

    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::PendingAdmin,
        new_admin.pubkey().to_bytes().to_vec(),
        &owner,
    )
    .await
    .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;

    assert_eq!(global_config_state.global_admin, owner.pubkey());
    assert_eq!(global_config_state.pending_admin, new_admin.pubkey());

    client::update_global_config_admin(&mut ctx, &global_config, &new_admin)
        .await
        .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;

    assert_eq!(global_config_state.global_admin, new_admin.pubkey());
}

#[tokio::test]
async fn test_update_global_config_krfq_swap_authority() {
    let mut program = fixtures::program();
    let owner = funded_kp(&mut program, sol_decimal_to_u64(10000.0));
    let global_config = pda::global_config();
    create_program_data_account(&mut program, metavault::ID, owner.pubkey());

    let mut ctx = test::start(program, &owner).await;

    client::init_global_config(&mut ctx, &owner, &global_config)
        .await
        .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;
    assert_eq!(global_config_state.krfq_swap_authority, Pubkey::default());

    let krfq_server = Pubkey::new_unique();
    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::KrfqSwapAuthority,
        krfq_server.to_bytes().to_vec(),
        &owner,
    )
    .await
    .unwrap();

    let global_config_state = get_global_config_state(&mut ctx, &global_config).await;
    assert_eq!(global_config_state.krfq_swap_authority, krfq_server);
}

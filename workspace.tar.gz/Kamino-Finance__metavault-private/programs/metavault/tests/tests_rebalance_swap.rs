use kamino_lending::{
    assert_fuzzy_eq,
    program_test::common::types::{MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    utils::{to_sf, FULL_BPS},
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    operations::rebalance_basket::RebalanceBasket,
    program_test::{
        client::{
            deposit, rebalance_swap, rebalance_target, refresh_vault, start_rebalance,
            try_rebalance_swap, update_vault_config, withdraw, RequestedOut,
            UpdateVaultConfigParams,
        },
        fixtures::setup_markets_with_weights,
        setup, VaultAccounts, VaultDepositorAccounts,
    },
    types::TokenAmount,
    utils::consts::{INITIAL_DEPOSIT_SIZE, REBALANCE_SETTLED_TOLERANCE_LAMPORTS},
    KaminoVaultError,
};
use solana_program_test::tokio;

fn expected_usdc_out_for_sol_swap(
    sol_in_lamports: u64,
    sol_buy_start_bps: u64,
    sol_buy_end_bps: u64,
    usdc_sell_start_bps: u64,
    usdc_sell_end_bps: u64,
    elapsed_seconds: u64,
    duration_seconds: u64,
) -> u64 {
    let elapsed = elapsed_seconds.min(duration_seconds);
    let remaining = duration_seconds - elapsed;

    let sol_buy_rate = u128::from(sol_buy_start_bps) * u128::from(remaining)
        + u128::from(sol_buy_end_bps) * u128::from(elapsed);
    let usdc_sell_rate = u128::from(usdc_sell_start_bps) * u128::from(remaining)
        + u128::from(usdc_sell_end_bps) * u128::from(elapsed);

    let amount_out = u128::from(sol_in_lamports) * 100 * 1_000_000 * sol_buy_rate
        / (1_000_000_000 * usdc_sell_rate);

    amount_out as u64
}

async fn setup_usdc_excess_rebalance_with_auction(
    max_slippage_bps: Option<u64>,
    usdc_sell_start_bps: u64,
    usdc_sell_end_bps: u64,
    sol_buy_start_bps: u64,
    sol_buy_end_bps: u64,
) -> (TestContext, VaultAccounts, VaultDepositorAccounts) {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint,
            usdc_sell_start_bps,
            usdc_sell_end_bps,
            10000,
            10000,
        ),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            sol_mint,
            10000,
            10000,
            sol_buy_start_bps,
            sol_buy_end_bps,
        ),
    )
    .await;
    if let Some(max_slippage_bps) = max_slippage_bps {
        update_vault_config(
            &mut ctx,
            &admin,
            &vault,
            UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(max_slippage_bps),
        )
        .await;
    }
    // What the whole rebalance may lose is not under test here (the default is no loss at all).
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceLossBps(u64::from(FULL_BPS)),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, 7200).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 1_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    (ctx, vault, swapper)
}

#[tokio::test]
async fn test_rebalance_swap_basic() {
    // Set initial weights to create rebalance scenario: 50% USDC, 50% SOL
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create a depositor and deposit only USDC to create imbalance
    // This will make the vault have too much USDC and need SOL for balance
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC in total
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Create a swapper with 10 SOL tokens
    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        5_000_000_000, // 5 SOL
        RequestedOut::AtCurve,
    )
    .await;

    // Assert that we have around 5 SOL and 500 USDC in vault, meaning that rebalance is done
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 500_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 5_000_000_000);
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Assert that swapper received 500 USDC for their 5 SOL
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_eq!(swapper_balances.tokens["USDC"], 500_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 5_000_000_000);
}

/// Test slippage protection in rebalance swaps
#[tokio::test]
async fn test_rebalance_swap_slippage_protection() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        5_000_000_000,
        RequestedOut::Exact(600_000_000), // Asking more than the curve quotes
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );
}

/// Test that swaps in wrong direction are rejected
#[tokio::test]
async fn test_rebalance_swap_invalid_direction() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 0,
            "USDC".to_string() => 1_000_000_000
        },
    )
    .await;

    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "USDC", // Wrong direction - vault has too much USDC already
        "SOL",
        100_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );
}

/// Test that swap amounts exceeding the deficit are clamped to it
#[tokio::test]
async fn test_rebalance_swap_amount_clamped_to_deficit() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // Small imbalance
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;
    // Set USDC price to 2 such that the swap will give out too much USDC to swapper
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 0.5, 0.5).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        5_000_000_000, // Much larger than needed to restore balance
        RequestedOut::AtCurve,
    )
    .await;
    result.unwrap();

    // Only the SOL deficit (2.5 SOL at $500 AUM, 50% weight) leaves the
    // swapper; the excess of the requested 5 SOL stays untouched.
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_fuzzy_eq!(swapper_balances.tokens["SOL"], 7_500_000_000u64, 2);
    assert_fuzzy_eq!(swapper_balances.tokens["USDC"], 500_000_000, 2);

    let vault_balances = vault.balances(&mut ctx).await;
    assert_fuzzy_eq!(vault_balances.token_vaults["SOL"], 2_500_000_000u64, 2);
    assert_fuzzy_eq!(vault_balances.token_vaults["USDC"], 500_000_000, 2);
}

/// Test that swaps fail when tokens are already settled
#[tokio::test]
async fn test_rebalance_swap_tokens_already_settled() {
    // Setup vault with 3 tokens: 30% USDC, 30% SOL, 40% USDT
    let initial_weights = vec![3u64, 3u64, 4u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Deposit only USDC to create imbalance
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC in total
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0,
            "USDT".to_string() => 10_000_000_000,
        },
    )
    .await;

    // First swap: SOL for USDC - this will settle SOL completely
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        3_000_000_000, // 3 SOL to reach 30% target
        RequestedOut::AtCurve,
    )
    .await;

    // Second swap attempt with already-settled SOL token should fail
    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL", // SOL is already settled
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );

    // Second swap attempt with already-settled SOL token as output should fail
    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "USDC",
        "SOL", // SOL is already settled
        1_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );

    // Settle USDT
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "USDT",
        "USDC",
        400_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Assert that we have around 3 SOL, 400 USDT and 300 USDC in vault, meaning that rebalance is done
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 300_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 3_000_000_000);
    assert_eq!(vault_balances.token_vaults["USDT"], 400_000_000);
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Assert that swapper received 500 USDC for their 5 SOL
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_eq!(swapper_balances.tokens["USDC"], 700_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 7_000_000_000);
    assert_eq!(swapper_balances.tokens["USDT"], 9_600_000_000);
}

/// Test that swaps only work during active rebalancing
#[tokio::test]
async fn test_rebalance_swap_not_during_rebalance() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        5_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceNotInProgress, 1)
    );
}

/// Test partial settlement with multiple swaps
#[tokio::test]
async fn test_rebalance_swap_partial_settlement() {
    // Setup vault with 3 tokens: 30% USDC, 30% SOL, 40% USDT
    let initial_weights = vec![3u64, 3u64, 4u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create imbalance: deposit only USDC
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC in total
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Create swapper with SOL and USDT
    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDT".to_string() => 1_000_000_000,
            "USDC".to_string() => 0,
        },
    )
    .await;

    // First partial swap: 1 SOL for USDC
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Check intermediate state
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["SOL"], 1_000_000_000);

    // Second partial swap: 1 more SOL for USDC
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Third partial swap: 1 more SOL to reach target
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Fourth swap: USDT for USDC
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "USDT",
        "USDC",
        400_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify final vault balances match targets (30% USDC, 30% SOL, 40% USDT of 1000 total)
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 300_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 3_000_000_000);
    assert_eq!(vault_balances.token_vaults["USDT"], 400_000_000);

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify swapper balances
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_eq!(swapper_balances.tokens["USDC"], 700_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 7_000_000_000);
    assert_eq!(swapper_balances.tokens["USDT"], 600_000_000);
}

/// Test multiple swappers participating in rebalance
#[tokio::test]
async fn test_rebalance_swap_multiple_swappers() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create imbalance: deposit excess USDC
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC total, need 500 USDC and 5 SOL
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Create 3 different swappers with SOL
    let swapper1 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 3_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swapper2 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 2_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swapper3 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 1_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // Swapper 1 provides 2 SOL
    rebalance_swap(
        &mut ctx,
        &swapper1.owner,
        &vault,
        "SOL",
        "USDC",
        2_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Swapper 2 provides 2 SOL
    rebalance_swap(
        &mut ctx,
        &swapper2.owner,
        &vault,
        "SOL",
        "USDC",
        2_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Swapper 3 provides 1 SOL to complete rebalance
    rebalance_swap(
        &mut ctx,
        &swapper3.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify vault reaches balance
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 500_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 5_000_000_000);

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify each swapper received correct USDC
    let swapper1_balances = swapper1.balances(&mut ctx).await;
    assert_eq!(swapper1_balances.tokens["USDC"], 200_000_000);
    assert_eq!(swapper1_balances.tokens["SOL"], 1_000_000_000);

    let swapper2_balances = swapper2.balances(&mut ctx).await;
    assert_eq!(swapper2_balances.tokens["USDC"], 200_000_000);
    assert_eq!(swapper2_balances.tokens["SOL"], 0);

    let swapper3_balances = swapper3.balances(&mut ctx).await;
    assert_eq!(swapper3_balances.tokens["USDC"], 100_000_000);
    assert_eq!(swapper3_balances.tokens["SOL"], 0);
}

/// Test partial swap then time elapsed
#[tokio::test]
async fn test_rebalance_swap_partial_then_time_elapsed() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create imbalance
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    // Start rebalance with 1000 second duration
    start_rebalance(&mut ctx, &admin, &vault, 1000).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // First partial swap
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        2_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Fast forward beyond rebalance duration
    ctx.fast_forward_seconds(1001).await;

    // Update prices to be current after time elapsed
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // Second swap should fail - rebalance expired
    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        3_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // An elapsed window and a vault that never started one are one refusal now: the quote asks
    // `rebalance_progress`, which is `None` in both cases.
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceNotInProgress, 1)
    );

    // Any instruction that touches the vault ends an expired rebalance; a refresh is the
    // neutral one.
    refresh_vault(&mut ctx, &vault, &admin).await;

    // Verify final state
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify balances (partial swap completed, not fully balanced)
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["SOL"], 2_000_000_000);
    assert_eq!(vault_balances.token_vaults["USDC"], 800_000_000);

    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_eq!(swapper_balances.tokens["USDC"], 200_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 8_000_000_000);
}

/// Test two tokens in excess, one in deficit
#[tokio::test]
async fn test_rebalance_swap_two_excess_one_deficit() {
    let initial_weights = vec![25u64, 25u64, 50u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create imbalance: deposit excess USDC and SOL, no USDT
    // Target should be 250 USDC, 2.5 SOL, 500 USDT
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 1_000_000_000,
            "SOL".to_string() => 10_000_000_000,
        },
    )
    .await;

    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        500_000_000 - INITIAL_DEPOSIT_SIZE, // 500 USDC (excess 250)
    )
    .await;

    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        5_000_000_000, // 5 SOL (excess 2.5)
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDT".to_string() => 1_000_000_000,
            "USDC".to_string() => 0,
            "SOL".to_string() => 0,
        },
    )
    .await;

    // Swap USDT for USDC
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "USDT",
        "USDC",
        250_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Swap USDT for SOL
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "USDT",
        "SOL",
        250_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify balances
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 250_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 2_500_000_000);
    assert_eq!(vault_balances.token_vaults["USDT"], 500_000_000);

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify swapper balances
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_eq!(swapper_balances.tokens["USDC"], 250_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 2_500_000_000);
    assert_eq!(swapper_balances.tokens["USDT"], 500_000_000);
}

/// Test two tokens in excess, two in deficit with 4 swappers
#[tokio::test]
async fn test_rebalance_swap_two_excess_two_deficit() {
    let initial_weights = vec![25u64, 25u64, 25u64, 25u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
                "WSOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
                RSpec::new("WSOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create imbalance: deposit only USDC and SOL
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 1_000_000_000,
            "SOL".to_string() => 10_000_000_000,
        },
    )
    .await;

    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC total
    )
    .await;

    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        10_000_000_000, // 10 SOL total
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Create 4 swappers with all necessary token accounts
    let swapper1 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDT".to_string() => 500_000_000,
            "USDC".to_string() => 0,  // Initialize USDC account for receiving
        },
    )
    .await;

    let swapper2 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "WSOL".to_string() => 5_000_000_000,
            "SOL".to_string() => 0,  // Initialize SOL account for receiving
        },
    )
    .await;

    let swapper3 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDT".to_string() => 500_000_000,
            "SOL".to_string() => 0,  // Initialize SOL account for receiving
        },
    )
    .await;

    let swapper4 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "WSOL".to_string() => 5_000_000_000,
            "USDC".to_string() => 0,  // Initialize USDC account for receiving
        },
    )
    .await;

    // First swapper: USDT for USDC
    rebalance_swap(
        &mut ctx,
        &swapper1.owner,
        &vault,
        "USDT",
        "USDC",
        250_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Second swapper: WSOL for SOL
    rebalance_swap(
        &mut ctx,
        &swapper2.owner,
        &vault,
        "WSOL",
        "SOL",
        2_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Third swapper: USDT for SOL
    rebalance_swap(
        &mut ctx,
        &swapper3.owner,
        &vault,
        "USDT",
        "SOL",
        250_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Fourth swapper: WSOL for USDC
    rebalance_swap(
        &mut ctx,
        &swapper4.owner,
        &vault,
        "WSOL",
        "USDC",
        2_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify final balances (each token should be 25% of total)
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 500_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 5_000_000_000);
    assert_eq!(vault_balances.token_vaults["USDT"], 500_000_000);
    assert_eq!(vault_balances.token_vaults["WSOL"], 5_000_000_000);

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify swapper balances
    let swapper1_balances = swapper1.balances(&mut ctx).await;
    assert_eq!(swapper1_balances.tokens["USDC"], 250_000_000);
    assert_eq!(swapper1_balances.tokens["USDT"], 250_000_000);

    let swapper2_balances = swapper2.balances(&mut ctx).await;
    assert_eq!(swapper2_balances.tokens["SOL"], 2_500_000_000);
    assert_eq!(swapper2_balances.tokens["WSOL"], 2_500_000_000);

    let swapper3_balances = swapper3.balances(&mut ctx).await;
    assert_eq!(swapper3_balances.tokens["SOL"], 2_500_000_000);
    assert_eq!(swapper3_balances.tokens["USDT"], 250_000_000);

    let swapper4_balances = swapper4.balances(&mut ctx).await;
    assert_eq!(swapper4_balances.tokens["USDC"], 250_000_000);
    assert_eq!(swapper4_balances.tokens["WSOL"], 2_500_000_000);
}

#[tokio::test]
async fn test_rebalance_swap_price_changes_complex() {
    let initial_weights = vec![25u64, 25u64, 25u64, 25u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
                "WSOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
                RSpec::new("WSOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create imbalance: deposit only USDC and SOL.
    // The vault is seeded with INITIAL_DEPOSIT_SIZE of the first token (USDC) on init,
    // so deposit the remainder to end up with 1000 USDC total and 10 SOL total.
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 1_000_000_000,
            "SOL".to_string() => 10_000_000_000,
        },
    )
    .await;

    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC
    )
    .await;

    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        10_000_000_000, // 10 SOL total
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Create swappers
    let swapper1 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDT".to_string() => 500_000_000,
            "USDC".to_string() => 0,
        },
    )
    .await;

    let swapper2 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "WSOL".to_string() => 5_000_000_000,
            "SOL".to_string() => 0,
        },
    )
    .await;

    let swapper3 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDT".to_string() => 2_500_000_000,
            "SOL".to_string() => 0,
        },
    )
    .await;

    let swapper4 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 2_000_000_000,
            "WSOL".to_string() => 250_000_000,
            "SOL".to_string() => 0,
        },
    )
    .await;

    // First swap with initial prices
    rebalance_swap(
        &mut ctx,
        &swapper1.owner,
        &vault,
        "USDT",
        "USDC",
        250_000_000, // settle half of the USDT deficit at the initial price
        RequestedOut::AtCurve,
    )
    .await;

    // Second swap with initial prices
    rebalance_swap(
        &mut ctx,
        &swapper2.owner,
        &vault,
        "WSOL",
        "SOL",
        2_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Update oracle prices - SOL price increases from 100 to 1000.
    // Targets are recalculated from fresh prices on every swap: AUM becomes
    // 750 USDC + 250 USDT + 7.5 SOL * $1000 + 2.5 WSOL * $1000 = $11,000, so each 25% target
    // becomes $2,750. USDC flips from surplus to deficit and SOL holds the only surplus, so the
    // remaining swaps all drain SOL.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 1000.0, 1000.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "WSOL", 1000.0, 1000.0).await;

    // Third swap with new prices - USDT for SOL (now more valuable)
    rebalance_swap(
        &mut ctx,
        &swapper3.owner,
        &vault,
        "USDT",
        "SOL",
        2_500_000_000, // this will settle USDT at 2,750 USDT for 2.5 SOL
        RequestedOut::AtCurve,
    )
    .await;

    // Fourth and fifth swaps with new prices for the remaining tokens
    rebalance_swap(
        &mut ctx,
        &swapper4.owner,
        &vault,
        "USDC",
        "SOL",
        2_000_000_000, // this should settle USDC at 2,750 USDC for 2 SOL
        RequestedOut::AtCurve,
    )
    .await;
    rebalance_swap(
        &mut ctx,
        &swapper4.owner,
        &vault,
        "WSOL",
        "SOL",
        250_000_000, // this should settle WSOL at 2.75 WSOL and SOL at 2.75 SOL
        RequestedOut::AtCurve,
    )
    .await;

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify swapper balances reflect price changes
    let swapper1_balances = swapper1.balances(&mut ctx).await;
    assert_eq!(swapper1_balances.tokens["USDC"], 250_000_000);
    assert_eq!(swapper1_balances.tokens["USDT"], 250_000_000);

    let swapper2_balances = swapper2.balances(&mut ctx).await;
    assert_eq!(swapper2_balances.tokens["SOL"], 2_500_000_000);
    assert_eq!(swapper2_balances.tokens["WSOL"], 2_500_000_000);

    let swapper3_balances = swapper3.balances(&mut ctx).await;
    assert_eq!(swapper3_balances.tokens["SOL"], 2_500_000_000);
    assert_eq!(swapper3_balances.tokens["USDT"], 0);

    let swapper4_balances = swapper4.balances(&mut ctx).await;
    assert_eq!(swapper4_balances.tokens["USDC"], 0);
    assert_eq!(swapper4_balances.tokens["SOL"], 2_250_000_000);
    assert_eq!(swapper4_balances.tokens["WSOL"], 0);
}

/// Test that Dutch auction prices change over time during rebalancing
#[tokio::test]
async fn test_rebalance_swap_dutch_auction_price_progression() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Set Dutch auction bounds for the tokens
    // USDC: vault has excess, so we're selling it - set selling bounds
    // SOL: vault needs more, so we're buying it - set buying bounds
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Set bounds for selling USDC: starts at 1.1x, ends at 0.95x oracle
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 11000, // start_scale_bps_when_selling: 1.1x oracle
            9500,  // end_scale_bps_when_selling: 0.95x oracle
            10000, // start_scale_bps_when_buying: not used (1.0x)
            10000, // end_scale_bps_when_buying: not used (1.0x)
        ),
    )
    .await;

    // Set bounds for buying SOL: starts at 0.95x, ends at 1.1x oracle
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            sol_mint, 10000, // start_scale_bps_when_selling: not used (1.0x)
            10000, // end_scale_bps_when_selling: not used (1.0x)
            9500,  // start_scale_bps_when_buying: 0.95x oracle
            11000, // end_scale_bps_when_buying: 1.1x oracle
        ),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(2_000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceLossBps(u64::from(FULL_BPS)),
    )
    .await;

    // Create imbalance: deposit only USDC
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC total
    )
    .await;

    // Start rebalance with 1 hour duration
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Create three swappers with SOL
    let swapper1 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 2_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swapper2 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 2_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swapper3 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 2_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // First swap at auction start (t=0)
    rebalance_swap(
        &mut ctx,
        &swapper1.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000, // 1 SOL
        RequestedOut::AtCurve,
    )
    .await;

    let swapper1_balance_t0 = swapper1.balances(&mut ctx).await;
    let usdc_received_t0 = swapper1_balance_t0.tokens["USDC"];

    // Fast forward to middle of auction (t=1800s, 50% through)
    ctx.fast_forward_seconds(1800).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // Second swap at middle of auction
    rebalance_swap(
        &mut ctx,
        &swapper2.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000, // 1 SOL
        RequestedOut::AtCurve,
    )
    .await;

    let swapper2_balance_t50 = swapper2.balances(&mut ctx).await;
    let usdc_received_t50 = swapper2_balance_t50.tokens["USDC"];

    // Fast forward to near end of auction (t=3500s, ~97% through)
    ctx.fast_forward_seconds(1700).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // Third swap near end of auction
    rebalance_swap(
        &mut ctx,
        &swapper3.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000, // 1 SOL
        RequestedOut::AtCurve,
    )
    .await;

    let swapper3_balance_t97 = swapper3.balances(&mut ctx).await;
    let usdc_received_t97 = swapper3_balance_t97.tokens["USDC"];
    let expected_t0 =
        expected_usdc_out_for_sol_swap(1_000_000_000, 9500, 11000, 11000, 9500, 0, 3600);
    let expected_t50 =
        expected_usdc_out_for_sol_swap(1_000_000_000, 9500, 11000, 11000, 9500, 1800, 3600);
    let expected_t97 =
        expected_usdc_out_for_sol_swap(1_000_000_000, 9500, 11000, 11000, 9500, 3500, 3600);

    // At t=0: Worst price for swapper (best for vault)
    // SOL buy scale = 0.95x, USDC sell scale = 1.1x
    // Net effect is computed with exact integer auction math.
    assert_fuzzy_eq!(usdc_received_t0, expected_t0, 1);

    // At t=50%: Middle of auction, prices improving for swapper
    // Midpoint quote should match the exact integer interpolation.
    assert_fuzzy_eq!(usdc_received_t50, expected_t50, 1);

    // At t=97.2% (3500/3600): Near end of auction, best price for swapper
    // Near-end quote should also match the exact integer interpolation.
    assert_fuzzy_eq!(usdc_received_t97, expected_t97, 1);

    // Prices should get progressively better for the swapper (worse for vault)
    assert!(
        usdc_received_t97 >= usdc_received_t0,
        "Price at t97 ({} USDC) should be better than t0 ({} USDC)",
        usdc_received_t97 / 1_000_000,
        usdc_received_t0 / 1_000_000
    );
    assert!(
        usdc_received_t50 >= usdc_received_t0,
        "Price at t50 ({} USDC) should be better than t0 ({} USDC)",
        usdc_received_t50 / 1_000_000,
        usdc_received_t0 / 1_000_000
    );
}

#[tokio::test]
async fn test_rebalance_swap_default_zero_slippage_rejects_net_aum_loss_from_dutch_auction() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Make the auction quote value-losing for the vault: SOL input is over-valued, USDC output is
    // under-priced, so the swapper would receive more oracle value than they provide.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(usdc_mint, 9000, 9000, 10000, 10000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(sol_mint, 10000, 10000, 11000, 11000),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, 7200).await;

    let state_before = vault.state(&mut ctx).await;
    let balances_before = vault.balances(&mut ctx).await;
    assert_eq!(state_before.prev_aum_sf, to_sf(1000u64));

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 1_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceSwapExceedsMaxLoss, 1)
    );

    let state_after = vault.state(&mut ctx).await;
    let balances_after = vault.balances(&mut ctx).await;
    let swapper_balances = swapper.balances(&mut ctx).await;

    assert_eq!(state_after.prev_aum_sf, state_before.prev_aum_sf);
    assert_eq!(
        state_after.vault_tokens[0].token_available,
        state_before.vault_tokens[0].token_available
    );
    assert_eq!(
        state_after.vault_tokens[1].token_available,
        state_before.vault_tokens[1].token_available
    );
    assert_eq!(balances_after.token_vaults, balances_before.token_vaults);
    assert_eq!(swapper_balances.tokens["SOL"], 1_000_000_000);
    assert_eq!(swapper_balances.tokens["USDC"], 0);
}

#[tokio::test]
async fn test_rebalance_swap_allows_non_decreasing_net_aum() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, 7200).await;

    let state_before = vault.state(&mut ctx).await;
    assert_eq!(state_before.prev_aum_sf, to_sf(1000u64));

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 1_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    let state_after = vault.state(&mut ctx).await;
    let vault_balances = vault.balances(&mut ctx).await;
    let swapper_balances = swapper.balances(&mut ctx).await;

    assert_eq!(state_after.prev_aum_sf, state_before.prev_aum_sf);
    assert_eq!(state_after.prev_aum_sf, to_sf(1000u64));
    assert_eq!(vault_balances.token_vaults["USDC"], 900_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 1_000_000_000);
    assert_eq!(swapper_balances.tokens["USDC"], 100_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 0);
}

#[tokio::test]
async fn test_rebalance_swap_configured_slippage_allows_small_net_aum_loss() {
    let (mut ctx, vault, swapper) =
        setup_usdc_excess_rebalance_with_auction(Some(100), 10000, 10000, 10100, 10100).await;

    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    let state_after = vault.state(&mut ctx).await;
    let vault_balances = vault.balances(&mut ctx).await;
    let swapper_balances = swapper.balances(&mut ctx).await;

    assert_eq!(state_after.rebalance_limits.max_fill_slippage_bps, 100);
    assert_eq!(vault_balances.token_vaults["USDC"], 899_000_000);
    assert_eq!(vault_balances.token_vaults["SOL"], 1_000_000_000);
    assert_eq!(swapper_balances.tokens["USDC"], 101_000_000);
    assert_eq!(swapper_balances.tokens["SOL"], 0);
}

#[tokio::test]
async fn test_rebalance_swap_configured_slippage_rejects_loss_above_budget() {
    let (mut ctx, vault, swapper) =
        setup_usdc_excess_rebalance_with_auction(Some(100), 10000, 10000, 10101, 10101).await;

    let state_before = vault.state(&mut ctx).await;
    let balances_before = vault.balances(&mut ctx).await;

    let result = try_rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceSwapExceedsMaxLoss, 1)
    );

    let state_after = vault.state(&mut ctx).await;
    let balances_after = vault.balances(&mut ctx).await;
    let swapper_balances = swapper.balances(&mut ctx).await;

    assert_eq!(
        state_after.vault_tokens[0].token_available,
        state_before.vault_tokens[0].token_available
    );
    assert_eq!(
        state_after.vault_tokens[1].token_available,
        state_before.vault_tokens[1].token_available
    );
    assert_eq!(balances_after.token_vaults, balances_before.token_vaults);
    assert_eq!(swapper_balances.tokens["SOL"], 1_000_000_000);
    assert_eq!(swapper_balances.tokens["USDC"], 0);
}

/// Test that swappers get worse prices at auction start vs end (vault gets better prices at start)
#[tokio::test]
async fn test_rebalance_swap_dutch_auction_worse_price_at_start() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Set Dutch auction bounds
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // USDC selling bounds: starts at 1.15x, ends at 1.0x oracle
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 11500, // start_scale_bps_when_selling: 1.15x oracle
            10000, // end_scale_bps_when_selling: 1.0x oracle
            10000, // start_scale_bps_when_buying: not used (1.0x)
            10000, // end_scale_bps_when_buying: not used (1.0x)
        ),
    )
    .await;

    // SOL buying bounds: starts at 1.0x, ends at 1.15x oracle
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            sol_mint, 10000, // start_scale_bps_when_selling: not used (1.0x)
            10000, // end_scale_bps_when_selling: not used (1.0x)
            10000, // start_scale_bps_when_buying: 1.0x oracle
            11500, // end_scale_bps_when_buying: 1.15x oracle
        ),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(2_000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceLossBps(u64::from(FULL_BPS)),
    )
    .await;

    // Create imbalance: deposit only USDC (vault has excess USDC, needs SOL)
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC total
    )
    .await;

    // Start rebalance with 2 hour duration to see more pronounced price changes
    start_rebalance(&mut ctx, &admin, &vault, 7200).await;

    // Create two swappers with SOL
    let swapper_early = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 2_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swapper_late = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 2_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // Early swap at auction start (should get better price for selling SOL)
    rebalance_swap(
        &mut ctx,
        &swapper_early.owner,
        &vault,
        "SOL",
        "USDC",
        1_500_000_000, // 1.5 SOL
        RequestedOut::AtCurve,
    )
    .await;

    let early_balance = swapper_early.balances(&mut ctx).await;
    let usdc_received_early = early_balance.tokens["USDC"];

    // Fast forward to end of auction
    ctx.fast_forward_seconds(7100).await; // Near end but not past duration
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // Late swap near auction end
    rebalance_swap(
        &mut ctx,
        &swapper_late.owner,
        &vault,
        "SOL",
        "USDC",
        1_500_000_000, // 1.5 SOL (same amount as early swapper)
        RequestedOut::AtCurve,
    )
    .await;

    let late_balance = swapper_late.balances(&mut ctx).await;
    let usdc_received_late = late_balance.tokens["USDC"];
    let expected_early =
        expected_usdc_out_for_sol_swap(1_500_000_000, 10000, 11500, 11500, 10000, 0, 7200);
    let expected_late =
        expected_usdc_out_for_sol_swap(1_500_000_000, 10000, 11500, 11500, 10000, 7100, 7200);

    // At t=0: Worst price for swapper (best for vault)
    // SOL buy scale = 1.0x, USDC sell scale = 1.15x
    // Net effect is computed with exact integer auction math.
    assert_fuzzy_eq!(usdc_received_early, expected_early, 1);

    // At t=98.6% (7100/7200): Best price for swapper (worst for vault)
    // Net effect is computed with exact integer auction math.
    assert_fuzzy_eq!(usdc_received_late, expected_late, 1);

    // Late swapper should get better price than early swapper (vault gets worse price)
    assert!(
        usdc_received_late > usdc_received_early,
        "Late swapper ({} USDC) should get better price than early swapper ({} USDC)",
        usdc_received_late / 1_000_000,
        usdc_received_early / 1_000_000
    );

    // The difference should be noticeable (at least 2 USDC for 1.5 SOL swap)
    assert!(
        usdc_received_late - usdc_received_early >= 2_000_000,
        "Price difference ({} USDC) should be at least 2 USDC",
        (usdc_received_late - usdc_received_early) / 1_000_000
    );
}

/// Test that swaps at the end of auction duration use final auction prices
#[tokio::test]
async fn test_rebalance_swap_dutch_auction_at_duration_end() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Set Dutch auction bounds
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // USDC selling bounds: starts at 1.12x, ends at 0.97x oracle
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 11200, // start_scale_bps_when_selling: 1.12x oracle
            9700,  // end_scale_bps_when_selling: 0.97x oracle
            10000, // start_scale_bps_when_buying: not used (1.0x)
            10000, // end_scale_bps_when_buying: not used (1.0x)
        ),
    )
    .await;

    // SOL buying bounds: starts at 0.97x, ends at 1.12x oracle
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            sol_mint, 10000, // start_scale_bps_when_selling: not used (1.0x)
            10000, // end_scale_bps_when_selling: not used (1.0x)
            9700,  // start_scale_bps_when_buying: 0.97x oracle
            11200, // end_scale_bps_when_buying: 1.12x oracle
        ),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(2_000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceLossBps(u64::from(FULL_BPS)),
    )
    .await;

    // Create imbalance: deposit only USDC
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC total
    )
    .await;

    // Start rebalance with short duration (10 minutes)
    start_rebalance(&mut ctx, &admin, &vault, 600).await;

    // Create two swappers with SOL
    let swapper1 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 3_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swapper2 = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 3_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // Fast forward to near the end of the window (595 of 600 seconds)
    ctx.fast_forward_seconds(595).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // First swap near the end of the window (small swap so it does not finish the rebalance)
    rebalance_swap(
        &mut ctx,
        &swapper1.owner,
        &vault,
        "SOL",
        "USDC",
        500_000_000, // 0.5 SOL (10% of the deficit)
        RequestedOut::AtCurve,
    )
    .await;

    let swapper1_balance = swapper1.balances(&mut ctx).await;
    let usdc_received_at_end = swapper1_balance.tokens["USDC"];

    // Fast forward to the last second still inside the window: it is half-open, `[start,
    // start + duration)`, so t=600 is already over and only t=599 can still be filled.
    ctx.fast_forward_seconds(4).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // Second swap on the window's last second (as close to the final auction price as a fill
    // can get: the curve reaches `(duration - 1) / duration`, never a full 1.0)
    rebalance_swap(
        &mut ctx,
        &swapper2.owner,
        &vault,
        "SOL",
        "USDC",
        500_000_000, // 0.5 SOL (same amount)
        RequestedOut::AtCurve,
    )
    .await;

    let swapper2_balance = swapper2.balances(&mut ctx).await;
    let usdc_received_past_end = swapper2_balance.tokens["USDC"];
    let expected_at_end =
        expected_usdc_out_for_sol_swap(500_000_000, 9700, 11200, 11200, 9700, 595, 600);
    let expected_past_end =
        expected_usdc_out_for_sol_swap(500_000_000, 9700, 11200, 11200, 9700, 599, 600);

    // At t=595s (99.17%): Near best price for swapper (near worst for vault)
    // Near-end quote should match the exact integer interpolation.
    assert_fuzzy_eq!(usdc_received_at_end, expected_at_end, 1);

    // At t=599s (99.83%): the best price a fill can get, i.e. the worst for the vault.
    assert_fuzzy_eq!(usdc_received_past_end, expected_past_end, 1);

    // Both swaps should receive very similar amounts: 595s vs 599s is 0.67% of the window, so
    // the prices should be almost identical.
    let diff = if usdc_received_at_end > usdc_received_past_end {
        usdc_received_at_end - usdc_received_past_end
    } else {
        usdc_received_past_end - usdc_received_at_end
    };

    assert!(
        diff <= 200_000, // Within 0.2 USDC
        "Prices at 595s ({} USDC) and 599s ({} USDC) should be very similar, diff: {} USDC",
        usdc_received_at_end / 1_000_000,
        usdc_received_past_end / 1_000_000,
        diff / 1_000_000
    );
}

/// Test that a solver cannot extract value by depositing during active rebalance
/// to trigger token reactivation and create additional swap opportunities.
///
/// Scenario: 3-token vault (USDC/SOL/USDT). Solver settles SOL via swap,
/// then deposits USDC to scale targets and reactivate SOL, then swaps again.
/// After withdrawing, the solver should have zero net profit.
#[tokio::test]
async fn test_rebalance_swap_deposit_reactivation_no_value_extraction() {
    // 50% USDC, 25% SOL, 25% USDT
    let initial_weights = vec![2u64, 1u64, 1u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Original depositor: 1000 USDC only → creates imbalance
    let original_depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &original_depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    let original_depositor_shares = original_depositor.balances(&mut ctx).await.shares;

    // AUM = $1000. Targets: USDC=$500, SOL=$250 (2.5 SOL), USDT=$250
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Solver with funds for swapping and depositing
    let solver = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 2_000_000_000,
            "SOL".to_string() => 20_000_000_000,
            "USDT".to_string() => 2_000_000_000,
        },
    )
    .await;

    let solver_usdc_before = solver.balances(&mut ctx).await.tokens["USDC"];
    let solver_sol_before = solver.balances(&mut ctx).await.tokens["SOL"];
    let solver_usdt_before = solver.balances(&mut ctx).await.tokens["USDT"];

    // Step 1: Solver fills SOL deficit (2.5 SOL → 250 USDC)
    // SOL settles at target, USDC excess reduced, USDT still deficit
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "SOL",
        "USDC",
        2_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify SOL is settled
    let vault_state = vault.state(&mut ctx).await;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;
    let sol_token = vault_state.tokens().by_mint(&sol_mint).unwrap();
    let sol_target = TokenAmount::from(rebalance_target(&mut ctx, &vault, "SOL").await);
    assert!(sol_token.is_settled(sol_target));

    // Step 2: Solver deposits 1000 USDC during active rebalance
    // This scales targets by 2x, reopening SOL (target doubles, balance stays)
    deposit(&mut ctx, &vault, &solver, "USDC", 1_000_000_000).await;

    // Verify SOL is in deficit again (target scaled from 2.5 to 5.0, available still 2.5)
    let vault_state = vault.state(&mut ctx).await;
    let sol_token = vault_state.tokens().by_mint(&sol_mint).unwrap();
    let sol_target = TokenAmount::from(rebalance_target(&mut ctx, &vault, "SOL").await);
    assert!(
        !sol_token.is_settled(sol_target),
        "SOL should be in deficit again after deposit scaled its target"
    );
    assert!(vault_state.rebalance.is_unfinished());

    // Step 3: Solver fills the new SOL deficit (2.5 more SOL)
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "SOL",
        "USDC",
        2_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Step 4: Solver fills USDT deficit (500 USDT → 500 USDC)
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "USDT",
        "USDC",
        500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Rebalance should be complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Step 5: Solver withdraws their deposit by burning all shares
    let solver_shares = solver.balances(&mut ctx).await.shares;
    withdraw(&mut ctx, &vault, &solver, solver_shares, "USDC").await;

    // Verify solver didn't profit — total value should be <= starting value
    let solver_usdc_after = solver.balances(&mut ctx).await.tokens["USDC"];
    let solver_sol_after = solver.balances(&mut ctx).await.tokens["SOL"];
    let solver_usdt_after = solver.balances(&mut ctx).await.tokens["USDT"];

    // Convert everything to USDC-equivalent value (SOL=$100, USDT=$1)
    let solver_value_before =
        solver_usdc_before + solver_sol_before / 1000 * 100 + solver_usdt_before;
    let solver_value_after = solver_usdc_after + solver_sol_after / 1000 * 100 + solver_usdt_after;

    // Solver should not have profited (rounding favors vault, so value_after <= value_before)
    assert!(
        solver_value_after <= solver_value_before,
        "Solver extracted value! before={} after={}",
        solver_value_before,
        solver_value_after,
    );

    // Verify original depositor's share value is preserved
    // Original depositor still has their shares, vault AUM should reflect their full value
    let original_depositor_shares_after = original_depositor.balances(&mut ctx).await.shares;
    assert_eq!(original_depositor_shares, original_depositor_shares_after);

    // Vault should have at least the original $1000 in value
    // (solver withdrew their deposit, so vault is back to original depositor's funds)
    let vault_balances = vault.balances(&mut ctx).await;
    let vault_usdc_value = vault_balances.token_vaults["USDC"];
    let vault_sol_value = vault_balances.token_vaults["SOL"] / 1000 * 100;
    let vault_usdt_value = vault_balances.token_vaults["USDT"];
    let total_vault_value = vault_usdc_value + vault_sol_value + vault_usdt_value;
    assert!(
        total_vault_value >= 1_000_000_000,
        "Vault lost value! total={}",
        total_vault_value,
    );
}

/// Demonstrates that a solver can amplify Dutch auction swap profit by depositing mid-rebalance
/// to scale up targets, creating new deficit to fill at the same favorable auction rate.
///
/// Strategy:
/// 1. Fill half the SOL deficit at solver-favorable auction price
/// 2. Deposit $1000 USDC (doubling AUM) → targets scale 2x, creating fresh SOL deficit
/// 3. Fill the original full deficit amount again from the newly created deficit
/// 4. Withdraw deposit → net effect: swapped 50% more SOL at premium than without deposit trick
///
/// The per-SOL premium is constant (same auction time), so 50% more SOL swapped = 50% more profit.
#[tokio::test]
async fn test_deposit_reactivation_with_dutch_auction_no_value_extraction() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Set Dutch auction bounds: moderate premium/discount
    // USDC selling: 1.05x → 0.97x
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(usdc_mint, 10500, 9700, 10000, 10000),
    )
    .await;

    // SOL buying: 0.97x → 1.05x
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(sol_mint, 10000, 10000, 9700, 10500),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(500),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceLossBps(u64::from(FULL_BPS)),
    )
    .await;

    // Original depositor: 1000 USDC → AUM = $1000
    let original_depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &original_depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Fast forward to 75% through auction (solver-favorable territory)
    ctx.fast_forward_seconds(2700).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // Solver with ample funds
    let solver = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 2_000_000_000,
            "SOL".to_string() => 20_000_000_000,
        },
    )
    .await;

    // Read original SOL deficit (~5B lamports at 50/50 weights, $1000 AUM)
    let vault_state = vault.state(&mut ctx).await;
    let sol_token = vault_state.get_vault_token_by_mint(&sol_mint).unwrap();
    let original_deficit = rebalance_target(&mut ctx, &vault, "SOL")
        .await
        .saturating_sub(sol_token.token_available);

    // --- Step 1: Fill half the SOL deficit ---
    let half_deficit = original_deficit / 2;
    let solver_usdc_before_swap1 = solver.balances(&mut ctx).await.tokens["USDC"];
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "SOL",
        "USDC",
        half_deficit,
        RequestedOut::AtCurve,
    )
    .await;
    let usdc_received_swap1 =
        solver.balances(&mut ctx).await.tokens["USDC"] - solver_usdc_before_swap1;

    // Compute per-SOL profit from first swap (premium over oracle rate)
    // Oracle value of half_deficit SOL in USDC: half_deficit * $100 / 10^9 * 10^6 = half_deficit / 10
    let oracle_value_swap1 = half_deficit / 10;
    let profit_swap1 = usdc_received_swap1 as i128 - oracle_value_swap1 as i128;
    // Baseline profit: extrapolate to full deficit (2x the half-deficit profit)
    let baseline_profit = profit_swap1 * 2;

    // --- Step 2: Deposit $1000 USDC (doubles AUM from ~$1000 to ~$2000) ---
    // This scales all targets by ~2x, creating a large new SOL deficit
    deposit(&mut ctx, &vault, &solver, "USDC", 1_000_000_000).await;

    // Verify SOL has fresh deficit from target scaling
    let vault_state = vault.state(&mut ctx).await;
    let sol_token = vault_state.tokens().by_mint(&sol_mint).unwrap();
    let sol_target = TokenAmount::from(rebalance_target(&mut ctx, &vault, "SOL").await);
    assert!(
        !sol_token.is_settled(sol_target),
        "SOL should have deficit after deposit scaled targets"
    );

    // --- Step 3: Fill the original full deficit worth of SOL from the new deficit ---
    // With doubled AUM, the USDC excess is large enough to accommodate this
    let solver_usdc_before_swap2 = solver.balances(&mut ctx).await.tokens["USDC"];
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "SOL",
        "USDC",
        original_deficit,
        RequestedOut::AtCurve,
    )
    .await;
    let usdc_received_swap2 =
        solver.balances(&mut ctx).await.tokens["USDC"] - solver_usdc_before_swap2;

    let oracle_value_swap2 = original_deficit / 10;
    let profit_swap2 = usdc_received_swap2 as i128 - oracle_value_swap2 as i128;

    // --- Step 4: Withdraw deposit ---
    let solver_shares = solver.balances(&mut ctx).await.shares;
    withdraw(&mut ctx, &vault, &solver, solver_shares, "USDC").await;

    // --- Verify: exploit profit is exactly 50% more than baseline ---
    // Total SOL swapped at premium: half_deficit + original_deficit = 1.5 * original_deficit
    let total_sol_swapped = half_deficit + original_deficit;
    assert_fuzzy_eq!(total_sol_swapped, original_deficit * 3 / 2, 1);

    // Total swap profit should be 1.5x baseline (proportional to SOL swapped at constant premium)
    let total_swap_profit = profit_swap1 + profit_swap2;
    assert_fuzzy_eq!(total_swap_profit as u64, baseline_profit as u64 * 3 / 2, 10);
}

/// The wedge that stored targets had: a deposit that lands the deficit token exactly on the
/// target it had a moment ago made the vault read as rebalanced against those stale targets, so
/// the recalculation was skipped and every later fill was refused. With
/// derived targets the deposit moves the targets along with the free AUM and the fill goes
/// through.
#[tokio::test]
async fn test_deposit_onto_the_stale_target_keeps_the_rebalance_fillable() {
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        vec![1u64, 1u64],
    )
    .await;
    let admin = ctx.initial_market_owner.clone();

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // SOL is 5 SOL short of its target; deposit exactly that.
    let sol_deficit = rebalance_target(&mut ctx, &vault, "SOL").await;
    let solver = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 5_000_000_000,
            "SOL".to_string() => 50_000_000_000,
        },
    )
    .await;
    deposit(&mut ctx, &vault, &solver, "SOL", sol_deficit).await;

    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.rebalance.is_unfinished());

    // A fill in the same direction still goes through: SOL's target rose with the free AUM.
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "SOL",
        "USDC",
        1_000_000_000,
        RequestedOut::AtCurve,
    )
    .await;
}

#[tokio::test]
async fn test_a_token_the_vault_targets_none_of_is_sold_down_to_nothing() {
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        vec![1, 1],
    )
    .await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => 2_000_000_000,
            "SOL".to_string() => 20_000_000_000,
        },
    )
    .await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;

    // Weight USDC to zero: its target becomes zero rather than merely small.
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let weights: Vec<u64> = vault
        .state(&mut ctx)
        .await
        .vault_tokens
        .iter()
        .filter(|token| token.is_token_set())
        .map(|token| u64::from(token.mint != usdc_mint))
        .collect();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights),
    )
    .await;
    assert_eq!(rebalance_target(&mut ctx, &vault, "USDC").await, 0);

    // Flat curves, so what a fill pays is the oracle price and the lamports below are exact.
    for mint in [usdc_mint, vault.vault_tokens["SOL"].token_mint] {
        update_vault_config(
            &mut ctx,
            &admin,
            &vault,
            UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
                mint, 10_000, 10_000, 10_000, 10_000,
            ),
        )
        .await;
    }

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 20_000_000_000,
            "USDC".to_string() => 0,
        },
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Buy nearly all of it, leaving a remainder below the tolerance that keeps a rebalance from
    // chasing dust towards a target it can never quite reach.
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        9_999_991_000,
        RequestedOut::AtCurve,
    )
    .await;
    let remainder = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert!(
        remainder > 0 && remainder < u64::from(REBALANCE_SETTLED_TOLERANCE_LAMPORTS),
        "{remainder}"
    );
    assert!(vault.state(&mut ctx).await.rebalance.is_unfinished());

    // A target of zero is reachable, so that remainder is still sellable: the fill is sized by
    // the vault's own remaining deficit, not by what the solver offers.
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        20_000,
        RequestedOut::AtCurve,
    )
    .await;
    // Which the old rule would have refused outright, calling a sub-tolerance excess settled.
    // What is left is bounded by the *other* side instead: a fill needs SOL meaningfully in
    // deficit, and a residue this small no longer moves SOL's target past its own tolerance.
    let left = vault.balances(&mut ctx).await.token_vaults["USDC"];
    assert!(left < remainder, "{remainder} -> {left}");
    assert!(!vault.state(&mut ctx).await.rebalance.is_unfinished());
}

//! Permissioned share tokens — design §11 scenarios. This file starts with scenario 1:
//! every vault now mints its shares as Token-2022 with the DefaultAccountState (open =
//! `Initialized`) and self-referential MetadataPointer extensions, the freeze authority
//! parked at `base_vault_authority`, no token-acl MintConfig, and deposits/withdraws
//! working with zero extra instructions.

use anchor_spl::token_2022::spl_token_2022;
use kamino_lending::{
    program_test::common::{
        math::usdc_decimal_to_u64, setup::funded_new_kp, token_operations::create_ata_if_not_exists,
    },
    send_transaction,
    utils::FULL_BPS,
};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures::{self, ProgramDependency},
        setup,
        token_acl::{self, mint_config_pda, thaw_permissionless_ix, MintConfig},
        VaultAccounts, VaultDepositorAccounts,
    },
    utils::consts::YEAR,
    KaminoVaultError,
};
use solana_program::{native_token::LAMPORTS_PER_SOL, program_pack::Pack};
use solana_program_test::tokio;
use solana_sdk::{
    instruction::InstructionError, pubkey::Pubkey, signature::Keypair, signer::Signer,
    system_instruction, transaction::TransactionError,
};
use spl_token_metadata_interface::state::TokenMetadata;

use spl_token_2022::{
    extension::{
        default_account_state::DefaultAccountState, immutable_owner::ImmutableOwner,
        metadata_pointer::MetadataPointer, BaseStateWithExtensions, StateWithExtensions,
    },
    instruction::{initialize_account3, set_authority, transfer_checked, AuthorityType},
    state::{Account as T22Account, AccountState, Mint},
};
use usdc_decimal_to_u64 as usdc;

async fn shares_account_state(
    ctx: &mut kamino_lending::program_test::common::types::TestContext,
    address: Pubkey,
) -> AccountState {
    let data = ctx.get_account(address).await.unwrap().unwrap().data;
    StateWithExtensions::<T22Account>::unpack(&data)
        .unwrap()
        .base
        .state
}

// A shares account of `owner`'s made by `InitializeAccount3`, which (unlike the ATA program) adds
// no `ImmutableOwner`, so its owner stays reassignable; thawed through the always-allow gate.
async fn thawed_mutable_owner_shares_account(
    ctx: &mut kamino_lending::program_test::common::types::TestContext,
    vault: &VaultAccounts,
    owner: &Keypair,
) -> Pubkey {
    let account = Keypair::new();
    let create = system_instruction::create_account(
        &owner.pubkey(),
        &account.pubkey(),
        ctx.rent.minimum_balance(T22Account::LEN),
        T22Account::LEN as u64,
        &spl_token_2022::ID,
    );
    let init = initialize_account3(
        &spl_token_2022::ID,
        &account.pubkey(),
        &vault.shares_mint,
        &owner.pubkey(),
    )
    .unwrap();
    let tx = ctx
        .create_transaction_with_payer_and_extra_signers([create, init], owner, [&account])
        .await;
    send_transaction!(ctx, tx).unwrap();
    let data = ctx
        .get_account(account.pubkey())
        .await
        .unwrap()
        .unwrap()
        .data;
    assert!(
        StateWithExtensions::<T22Account>::unpack(&data)
            .unwrap()
            .get_extension::<ImmutableOwner>()
            .is_err(),
        "must be the mutable-owner kind of account"
    );
    assert_eq!(
        shares_account_state(ctx, account.pubkey()).await,
        AccountState::Frozen
    );

    thaw_through_gate(ctx, vault, owner, account.pubkey()).await;
    account.pubkey()
}

// Thaws `account` of `owner`'s through the always-allow gate.
async fn thaw_through_gate(
    ctx: &mut kamino_lending::program_test::common::types::TestContext,
    vault: &VaultAccounts,
    owner: &Keypair,
    account: Pubkey,
) {
    let thaw = thaw_permissionless_ix(
        &owner.pubkey(),
        &vault.shares_mint,
        &account,
        &owner.pubkey(),
        &token_acl::ALWAYS_ALLOW_GATE_ID,
        vec![],
        false,
    );
    let tx = ctx.create_transaction_with_payer([thaw], owner).await;
    send_transaction!(ctx, tx).unwrap();
}

#[tokio::test]
async fn test_open_vault_shares_mint_is_t22_with_parked_freeze_authority() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let mint_account = ctx
        .get_account(vault.shares_mint)
        .await
        .unwrap()
        .expect("shares mint must exist after init_vault");
    assert_eq!(mint_account.owner, spl_token_2022::ID);

    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    assert_eq!(mint.base.decimals, 6);
    assert_eq!(
        mint.base.mint_authority.unwrap(),
        vault.base_vault_authority
    );
    // The freeze authority now exists on every share mint — parked at the program PDA,
    // unusable until a permissioned config exists (design §10.7).
    assert_eq!(
        mint.base.freeze_authority.unwrap(),
        vault.base_vault_authority
    );

    // Open vault: accounts are born thawed.
    let das = mint.get_extension::<DefaultAccountState>().unwrap();
    assert_eq!(das.state, u8::from(AccountState::Initialized));

    // Self-referential metadata pointer, authority = base_vault_authority.
    let pointer = mint.get_extension::<MetadataPointer>().unwrap();
    assert_eq!(
        Option::<solana_program::pubkey::Pubkey>::from(pointer.metadata_address).unwrap(),
        vault.shares_mint
    );
    assert_eq!(
        Option::<solana_program::pubkey::Pubkey>::from(pointer.authority).unwrap(),
        vault.base_vault_authority
    );

    // No token-acl MintConfig for an open vault.
    let (mint_config, _) = mint_config_pda(&vault.shares_mint);
    assert!(ctx.get_account(mint_config).await.unwrap().is_none());

    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.shares_permissioned());
}

// ── Scenario 2: permissioned init ───────────────────────────────────

#[tokio::test]
async fn test_permissioned_vault_init_hands_freeze_authority_to_mint_config() {
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;

    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.shares_permissioned());

    // DAS is Frozen and the freeze authority moved to the MintConfig PDA.
    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let das = mint.get_extension::<DefaultAccountState>().unwrap();
    assert_eq!(das.state, u8::from(AccountState::Frozen));
    assert_eq!(
        mint.base.freeze_authority.unwrap(),
        vault.shares_mint_config
    );

    let config_account = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .expect("MintConfig must exist for a permissioned vault");
    assert_eq!(config_account.owner, token_acl::TOKEN_ACL_ID);
    let config = MintConfig::unpack(&config_account.data).unwrap();
    assert_eq!(config.mint, vault.shares_mint);
    // The MintConfig field named `freeze_authority` holds the config ADMIN — which is the
    // program PDA, so every config-admin operation flows through vault instructions.
    assert_eq!(config.config_admin, vault.base_vault_authority);
    assert_eq!(config.gating_program, token_acl::ALWAYS_ALLOW_GATE_ID);
    // Policy: permissionless thaw on (gate-approved holders self-activate), freeze off.
    assert!(config.permissionless_thaw_enabled);
    assert!(!config.permissionless_freeze_enabled);
}

#[tokio::test]
async fn test_invalid_gate_can_be_rotated_to_recover_permissionless_thaw() {
    let invalid_gate = Pubkey::new_unique();
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            invalid_gate,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;

    // Init succeeds even though the configured gate account does not exist.
    let config_account = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap();
    let config = MintConfig::unpack(&config_account.data).unwrap();
    assert_eq!(config.gating_program, invalid_gate);

    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let thaw = thaw_permissionless_ix(
        &depositor.owner.pubkey(),
        &vault.shares_mint,
        &depositor.shares_ata,
        &depositor.owner.pubkey(),
        &invalid_gate,
        vec![],
        false,
    );
    let tx = ctx
        .create_transaction_with_payer([thaw], depositor.owner.as_ref())
        .await;
    let err = send_transaction!(ctx, tx).unwrap_err();
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(0, InstructionError::AccountNotExecutable)
    );

    client::set_shares_gating_program(&mut ctx, &owner, &vault, token_acl::ALWAYS_ALLOW_GATE_ID)
        .await
        .unwrap();

    let config_account = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap();
    let config = MintConfig::unpack(&config_account.data).unwrap();
    assert_eq!(config.gating_program, token_acl::ALWAYS_ALLOW_GATE_ID);

    thaw_through_gate(&mut ctx, &vault, &depositor.owner, depositor.shares_ata).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
}

// ── Scenario 3: gate-enforced deposits ──────────────────────────────

#[tokio::test]
async fn test_permissioned_deposit_requires_gate_thaw() {
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;

    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    // On a permissioned vault the fresh shares ATA is born frozen...
    let ata_account = ctx
        .get_account(depositor.shares_ata)
        .await
        .unwrap()
        .unwrap();
    let ata = StateWithExtensions::<T22Account>::unpack(&ata_account.data).unwrap();
    assert_eq!(ata.base.state, AccountState::Frozen);

    // ...so depositing fails with the actionable error, not a raw token error...
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", topup, 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountFrozen, 1)
    );
    // ...and so does withdrawing (the same account would be the burn's source).
    let res = client::try_withdraw(&mut ctx, &vault, &depositor, 1, "USDC", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountFrozen, 1)
    );

    // Whitelist enforcement costs the user one permissionless thaw through the gate.
    thaw_through_gate(&mut ctx, &vault, &depositor.owner, depositor.shares_ata).await;

    // Deposit + withdraw round-trip works exactly like an open vault afterwards.
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.shares, topup - 1);

    client::withdraw(&mut ctx, &vault, &depositor, topup - 1, "USDC").await;
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.shares, 0);
    assert_eq!(balances.tokens["USDC"], topup - 1);
}

/// The gate gates *accounts*, so an account whose owner can still be reassigned is a wrapper
/// around it: approved Alice thaws a hand-rolled account, fills it, and hands it to unapproved
/// Bob with `SetAuthority`. Token-2022 transfers never reach this program, so redemption is the
/// only leg that can refuse him.
#[tokio::test]
async fn test_permissioned_withdraw_rejects_a_mutable_owner_shares_account() {
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;

    let topup = usdc(10.0);
    let alice = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    thaw_through_gate(&mut ctx, &vault, &alice.owner, alice.shares_ata).await;

    client::deposit(&mut ctx, &vault, &alice, "USDC", topup).await;
    let shares = alice.balances(&mut ctx).await.shares;
    assert_eq!(shares, topup - 1);

    // The gate approves Alice, so her mutable-owner wrapper thaws...
    let wrapper = thawed_mutable_owner_shares_account(&mut ctx, &vault, &alice.owner).await;

    // ...takes every share, and then changes hands to someone the gate never saw. Neither
    // transfer nor handover touches the vault, and the account stays thawed throughout.
    let decimals = u8::try_from(vault.state(&mut ctx).await.shares_mint_decimals).unwrap();
    let fill = transfer_checked(
        &spl_token_2022::ID,
        &alice.shares_ata,
        &vault.shares_mint,
        &wrapper,
        &alice.owner.pubkey(),
        &[],
        shares,
        decimals,
    )
    .unwrap();
    let bob = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let handover = set_authority(
        &spl_token_2022::ID,
        &wrapper,
        Some(&bob.pubkey()),
        AuthorityType::AccountOwner,
        &alice.owner.pubkey(),
        &[],
    )
    .unwrap();
    let tx = ctx
        .create_transaction_with_payer([fill, handover], alice.owner.as_ref())
        .await;
    send_transaction!(ctx, tx).unwrap();
    assert_eq!(
        shares_account_state(&mut ctx, wrapper).await,
        AccountState::Initialized
    );

    // Bob now holds every share in a thawed account he owns, and withdrawals are not blocked:
    // the immutable-owner requirement is the only thing between him and the exit.
    let mut bob_accounts =
        VaultDepositorAccounts::new_with_owner(&mut ctx, bob, "USDC", &vault).await;
    bob_accounts.shares_ata = wrapper;
    let res = client::try_withdraw(&mut ctx, &vault, &bob_accounts, shares, "USDC", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountOwnerMutable, 1)
    );
    assert_eq!(ctx.get_balance(&wrapper).await, shares);
}

#[tokio::test]
async fn test_permissioned_settle_rejects_a_mutable_owner_shares_account() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;
    for switch in [
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderSettleEnabled(true),
    ] {
        client::update_vault_config(&mut ctx, &owner, &vault, switch).await;
    }
    let topup = usdc(10.0);
    let alice = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2 * topup).await;
    thaw_through_gate(&mut ctx, &vault, &alice.owner, alice.shares_ata).await;
    client::deposit(&mut ctx, &vault, &alice, "USDC", topup).await;
    let shares_before = alice.balances(&mut ctx).await.shares;

    // A single-token basket is at its weights already, so it settles right away...
    let order =
        client::open_deposit_order(&mut ctx, &vault, &alice, 0, &[("USDC", topup)], 3600).await;
    // ...but not into a thawed account whose owner could still hand the shares past the gate:
    let wrapper = thawed_mutable_owner_shares_account(&mut ctx, &vault, &alice.owner).await;
    let res =
        client::try_settle_deposit_order_into(&mut ctx, &alice.owner, &vault, order, wrapper).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountOwnerMutable, 1)
    );
    assert_eq!(ctx.get_balance(&wrapper).await, 0);

    client::settle_deposit_order(&mut ctx, &alice.owner, &vault, order).await;
    assert!(alice.balances(&mut ctx).await.shares > shares_before);
}

#[tokio::test]
async fn test_permissioned_withdraw_order_rejects_a_mutable_owner_shares_account() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(true),
    )
    .await;
    let topup = usdc(10.0);
    let alice = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    thaw_through_gate(&mut ctx, &vault, &alice.owner, alice.shares_ata).await;
    client::deposit(&mut ctx, &vault, &alice, "USDC", topup).await;
    let shares = alice.balances(&mut ctx).await.shares;

    // Her shares moved into a thawed account whose owner could still hand them past the gate:
    let wrapper = thawed_mutable_owner_shares_account(&mut ctx, &vault, &alice.owner).await;
    let decimals = u8::try_from(vault.state(&mut ctx).await.shares_mint_decimals).unwrap();
    let fill = transfer_checked(
        &spl_token_2022::ID,
        &alice.shares_ata,
        &vault.shares_mint,
        &wrapper,
        &alice.owner.pubkey(),
        &[],
        shares,
        decimals,
    )
    .unwrap();
    let tx = ctx
        .create_transaction_with_payer([fill], alice.owner.as_ref())
        .await;
    send_transaction!(ctx, tx).unwrap();

    let via_wrapper = VaultDepositorAccounts {
        shares_ata: wrapper,
        ..alice.clone()
    };
    let res = client::try_open_withdraw_order(
        &mut ctx,
        &vault,
        &via_wrapper,
        0,
        shares,
        &[("USDC", 1)],
        3600,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountOwnerMutable, 1)
    );
    assert_eq!(ctx.get_balance(&wrapper).await, shares);
}

#[tokio::test]
async fn test_open_vault_deposit_withdraw_round_trip_with_no_extra_instructions() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    // The depositor's shares ATA is a plain Token-2022 ATA, born thawed (open vault).
    let shares_ata = ctx
        .get_account(depositor.shares_ata)
        .await
        .unwrap()
        .expect("shares ATA must exist");
    assert_eq!(shares_ata.owner, spl_token_2022::ID);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.shares, topup - 1);
    assert_eq!(balances.tokens["USDC"], 0);

    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.shares_supply, topup - 1);

    client::withdraw(&mut ctx, &vault, &depositor, topup - 1, "USDC").await;
    let balances = depositor.balances(&mut ctx).await;
    assert_eq!(balances.shares, 0);
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.shares_supply, 0);
}

// ── Scenario 9: T22-native shares metadata ──────────────────────────

#[tokio::test]
async fn test_shares_metadata_open_vault_init_and_update() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::init_shares_metadata(
        &mut ctx,
        &owner,
        &vault,
        "Kamino Vault Shares".to_string(),
        "KVS".to_string(),
        "https://example.com/shares.json".to_string(),
    )
    .await
    .unwrap();

    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert_eq!(metadata.name, "Kamino Vault Shares");
    assert_eq!(metadata.symbol, "KVS");
    assert_eq!(metadata.uri, "https://example.com/shares.json");
    assert_eq!(metadata.mint, vault.shares_mint);
    assert_eq!(
        Option::<solana_program::pubkey::Pubkey>::from(metadata.update_authority).unwrap(),
        vault.base_vault_authority
    );
    // Open vault: no token_acl gate-discovery key.
    assert!(metadata.additional_metadata.is_empty());

    // Update with longer values — the variable-length rent top-up boundary.
    let long_uri = format!("https://example.com/{}.json", "x".repeat(200));
    client::update_shares_metadata(
        &mut ctx,
        &owner,
        &vault,
        "Kamino Vault Shares (renamed with a much longer name)".to_string(),
        "KVSX".to_string(),
        long_uri.clone(),
    )
    .await
    .unwrap();

    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert_eq!(
        metadata.name,
        "Kamino Vault Shares (renamed with a much longer name)"
    );
    assert_eq!(metadata.symbol, "KVSX");
    assert_eq!(metadata.uri, long_uri);
}

#[tokio::test]
async fn test_shares_metadata_permissioned_vault_records_gate_key() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;

    client::init_shares_metadata(
        &mut ctx,
        &owner,
        &vault,
        "Kamino Permissioned Shares".to_string(),
        "KPS".to_string(),
        "https://example.com/permissioned.json".to_string(),
    )
    .await
    .unwrap();

    // The gate is advertised under the ecosystem `token_acl` discovery key, read from
    // the MintConfig (its canonical source).
    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert_eq!(
        metadata.additional_metadata,
        vec![(
            "token_acl".to_string(),
            token_acl::ALWAYS_ALLOW_GATE_ID.to_string()
        )]
    );

    // Updating name/symbol/uri must leave the gate-discovery key intact.
    client::update_shares_metadata(
        &mut ctx,
        &owner,
        &vault,
        "Kamino Permissioned Shares v2".to_string(),
        "KPS2".to_string(),
        "https://example.com/permissioned-v2.json".to_string(),
    )
    .await
    .unwrap();

    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert_eq!(metadata.name, "Kamino Permissioned Shares v2");
    assert_eq!(metadata.symbol, "KPS2");
    assert_eq!(
        metadata.additional_metadata,
        vec![(
            "token_acl".to_string(),
            token_acl::ALWAYS_ALLOW_GATE_ID.to_string()
        )]
    );
}

#[tokio::test]
async fn test_always_block_gate_denies_thaw_without_mutating_vault_or_user_state() {
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_BLOCK_GATE_ID,
            vec![ProgramDependency::GateAlwaysBlock],
        )
        .await;
    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let user_before = depositor.balances(&mut ctx).await;
    let vault_before = vault.balances(&mut ctx).await;

    let thaw = thaw_permissionless_ix(
        &depositor.owner.pubkey(),
        &vault.shares_mint,
        &depositor.shares_ata,
        &depositor.owner.pubkey(),
        &token_acl::ALWAYS_BLOCK_GATE_ID,
        vec![],
        false,
    );
    let tx = ctx
        .create_transaction_with_payer([thaw], depositor.owner.as_ref())
        .await;
    let err = send_transaction!(ctx, tx).unwrap_err();
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(
            0,
            InstructionError::Custom(token_acl::error_code::GATE_UNSUPPORTED_INSTRUCTION),
        )
    );

    assert_eq!(
        shares_account_state(&mut ctx, depositor.shares_ata).await,
        AccountState::Frozen
    );
    let user_after_thaw = depositor.balances(&mut ctx).await;
    let vault_after_thaw = vault.balances(&mut ctx).await;
    assert_eq!(user_after_thaw, user_before);
    assert_eq!(vault_after_thaw.token_vaults, vault_before.token_vaults);
    assert_eq!(vault_after_thaw.shares_supply, vault_before.shares_supply);

    let err = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", topup, 0)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountFrozen, 1)
    );
    assert_eq!(depositor.balances(&mut ctx).await, user_before);
    let vault_after_deposit = vault.balances(&mut ctx).await;
    assert_eq!(vault_after_deposit.token_vaults, vault_before.token_vaults);
    assert_eq!(
        vault_after_deposit.shares_supply,
        vault_before.shares_supply
    );
    assert!(vault.state(&mut ctx).await.shares_permissioned());
}

#[tokio::test]
async fn test_nonexistent_gate_leaves_frozen_account_and_balances_unchanged() {
    let invalid_gate = Pubkey::new_unique();
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(invalid_gate, vec![]).await;
    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let user_before = depositor.balances(&mut ctx).await;
    let vault_before = vault.balances(&mut ctx).await;

    let thaw = thaw_permissionless_ix(
        &depositor.owner.pubkey(),
        &vault.shares_mint,
        &depositor.shares_ata,
        &depositor.owner.pubkey(),
        &invalid_gate,
        vec![],
        false,
    );
    let tx = ctx
        .create_transaction_with_payer([thaw], depositor.owner.as_ref())
        .await;
    let err = send_transaction!(ctx, tx).unwrap_err();
    assert_eq!(
        err.unwrap(),
        TransactionError::InstructionError(0, InstructionError::AccountNotExecutable)
    );

    let config_data = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap()
        .data;
    assert_eq!(
        MintConfig::unpack(&config_data).unwrap().gating_program,
        invalid_gate
    );
    assert!(vault.state(&mut ctx).await.shares_permissioned());
    assert_eq!(
        shares_account_state(&mut ctx, depositor.shares_ata).await,
        AccountState::Frozen
    );
    assert_eq!(depositor.balances(&mut ctx).await, user_before);
    let vault_after = vault.balances(&mut ctx).await;
    assert_eq!(vault_after.token_vaults, vault_before.token_vaults);
    assert_eq!(vault_after.shares_supply, vault_before.shares_supply);
}

// ── Scenario 4: blocked gate vs wrapper thaw ────────────────────────

#[tokio::test]
async fn test_wrapper_thaw_overrides_a_blocking_gate() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_BLOCK_GATE_ID,
            vec![ProgramDependency::GateAlwaysBlock],
        )
        .await;
    let (user, ata) = {
        let user = funded_new_kp(&mut ctx, 10 * LAMPORTS_PER_SOL);
        let mint = vault.shares_mint;
        let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;
        (user, ata)
    };

    // The always-block gate rejects the permissionless thaw...
    let thaw = thaw_permissionless_ix(
        &user.pubkey(),
        &vault.shares_mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_BLOCK_GATE_ID,
        vec![],
        false,
    );
    let tx = ctx
        .create_transaction_with_payer([thaw], user.as_ref())
        .await;
    let err = send_transaction!(ctx, tx).unwrap_err();
    match err.unwrap() {
        solana_sdk::transaction::TransactionError::InstructionError(
            _,
            solana_sdk::instruction::InstructionError::Custom(code),
        ) => assert_eq!(code, 999_999_999),
        other => panic!("unexpected error {other:?}"),
    }

    // ...but the unfreeze_authority thaws through the wrapper (which never consults the
    // gate), after the admin appoints it.
    let unfreezer = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::UnfreezeAuthority(unfreezer.pubkey()),
    )
    .await;
    client::thaw_shares_account(&mut ctx, &unfreezer, &vault, ata)
        .await
        .unwrap();

    let ata_data = ctx.get_account(ata).await.unwrap().unwrap().data;
    let state = StateWithExtensions::<T22Account>::unpack(&ata_data).unwrap();
    assert_eq!(state.base.state, AccountState::Initialized);
}

// ── Scenario 6: role matrix ─────────────────────────────────────────

#[tokio::test]
async fn test_wrapper_role_matrix() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;
    let user = funded_new_kp(&mut ctx, 10 * LAMPORTS_PER_SOL);
    let mint = vault.shares_mint;
    let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;

    let council = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let unfreezer = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let outsider = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::EmergencyCouncil(council.pubkey()),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::UnfreezeAuthority(unfreezer.pubkey()),
    )
    .await;

    // Thaw: unfreeze_authority and admin succeed; the council and outsiders do not.
    let err = client::thaw_shares_account(&mut ctx, &council, &vault, ata)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 0)
    );
    let err = client::thaw_shares_account(&mut ctx, &outsider, &vault, ata)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 0)
    );
    client::thaw_shares_account(&mut ctx, &unfreezer, &vault, ata)
        .await
        .unwrap();

    // Freeze: admin and council succeed; unfreeze_authority and outsiders do not.
    let err = client::freeze_shares_account(&mut ctx, &unfreezer, &vault, ata)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 0)
    );
    let err = client::freeze_shares_account(&mut ctx, &outsider, &vault, ata)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 0)
    );
    client::freeze_shares_account(&mut ctx, &council, &vault, ata)
        .await
        .unwrap();
    client::thaw_shares_account(&mut ctx, &owner, &vault, ata)
        .await
        .unwrap();
    client::freeze_shares_account(&mut ctx, &owner, &vault, ata)
        .await
        .unwrap();

    // Config wrappers are admin-only.
    let err = client::set_shares_gating_program(
        &mut ctx,
        &outsider,
        &vault,
        token_acl::ALWAYS_BLOCK_GATE_ID,
    )
    .await
    .unwrap_err();
    assert_eq!(
        err.unwrap(),
        kamino_lending::anchor_error!(anchor_lang::error::ErrorCode::ConstraintHasOne)
    );
    let err = client::toggle_shares_permissionless(&mut ctx, &outsider, &vault, false, false)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        kamino_lending::anchor_error!(anchor_lang::error::ErrorCode::ConstraintHasOne)
    );
    let err = client::delete_shares_config(&mut ctx, &outsider, &vault)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        kamino_lending::anchor_error!(anchor_lang::error::ErrorCode::ConstraintHasOne)
    );
}

#[tokio::test]
async fn test_wrappers_rejected_on_open_vaults() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let user = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let mint = vault.shares_mint;
    let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;

    // The parked freeze authority on open vaults is unusable: every wrapper requires
    // shares_permissioned == 1.
    let expected = metavault_error!(KaminoVaultError::SharesNotPermissioned, 0);
    let err = client::thaw_shares_account(&mut ctx, &owner, &vault, ata)
        .await
        .unwrap_err();
    assert_eq!(err.unwrap(), expected);
    let err = client::freeze_shares_account(&mut ctx, &owner, &vault, ata)
        .await
        .unwrap_err();
    assert_eq!(err.unwrap(), expected);
    let err = client::set_shares_gating_program(
        &mut ctx,
        &owner,
        &vault,
        token_acl::ALWAYS_ALLOW_GATE_ID,
    )
    .await
    .unwrap_err();
    assert_eq!(err.unwrap(), expected);
    let err = client::toggle_shares_permissionless(&mut ctx, &owner, &vault, false, true)
        .await
        .unwrap_err();
    assert_eq!(err.unwrap(), expected);
    let err = client::delete_shares_config(&mut ctx, &owner, &vault)
        .await
        .unwrap_err();
    assert_eq!(err.unwrap(), expected);
}

// ── Gate rotation keeps the discovery key in sync ───────────────────

#[tokio::test]
async fn test_set_gating_program_rotates_gate_and_syncs_metadata_key() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![
                ProgramDependency::GateAlwaysAllow,
                ProgramDependency::GateAlwaysBlock,
            ],
        )
        .await;
    client::init_shares_metadata(
        &mut ctx,
        &owner,
        &vault,
        "Kamino Permissioned Shares".to_string(),
        "KPS".to_string(),
        "https://example.com/permissioned.json".to_string(),
    )
    .await
    .unwrap();

    client::set_shares_gating_program(&mut ctx, &owner, &vault, token_acl::ALWAYS_BLOCK_GATE_ID)
        .await
        .unwrap();

    // MintConfig records the new gate...
    let config_data = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap()
        .data;
    let config = MintConfig::unpack(&config_data).unwrap();
    assert_eq!(config.gating_program, token_acl::ALWAYS_BLOCK_GATE_ID);

    // ...and the metadata discovery key follows it.
    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert_eq!(
        metadata.additional_metadata,
        vec![(
            "token_acl".to_string(),
            token_acl::ALWAYS_BLOCK_GATE_ID.to_string()
        )]
    );

    // Fresh accounts now go through the always-block gate.
    let user = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let mint = vault.shares_mint;
    let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;
    let thaw = thaw_permissionless_ix(
        &user.pubkey(),
        &vault.shares_mint,
        &ata,
        &user.pubkey(),
        &token_acl::ALWAYS_BLOCK_GATE_ID,
        vec![],
        false,
    );
    let tx = ctx
        .create_transaction_with_payer([thaw], user.as_ref())
        .await;
    send_transaction!(ctx, tx).unwrap_err();
}

// ── Scenario 7: delete re-opens the vault atomically ────────────────

#[tokio::test]
async fn test_delete_shares_config_reopens_the_vault() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;

    client::delete_shares_config(&mut ctx, &owner, &vault)
        .await
        .unwrap();

    // Config closed, DAS flipped to Initialized in the same instruction, freeze
    // authority parked back at base_vault_authority (migration-ready), flag cleared.
    assert!(ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .is_none());
    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    assert_eq!(
        mint.base.freeze_authority.unwrap(),
        vault.base_vault_authority
    );
    let das = mint.get_extension::<DefaultAccountState>().unwrap();
    assert_eq!(das.state, u8::from(AccountState::Initialized));
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.shares_permissioned());

    // New share accounts are born thawed and deposits need no extra instructions.
    let topup = usdc(5.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let ata_data = ctx
        .get_account(depositor.shares_ata)
        .await
        .unwrap()
        .unwrap()
        .data;
    let state = StateWithExtensions::<T22Account>::unpack(&ata_data).unwrap();
    assert_eq!(state.base.state, AccountState::Initialized);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    // The wrappers are inert again.
    let err = client::delete_shares_config(&mut ctx, &owner, &vault)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::SharesNotPermissioned, 0)
    );
}

#[tokio::test]
async fn test_delete_shares_config_removes_acl_discovery_metadata() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;
    client::init_shares_metadata(
        &mut ctx,
        &owner,
        &vault,
        "Kamino Permissioned Shares".to_string(),
        "KPS".to_string(),
        "https://example.com/permissioned.json".to_string(),
    )
    .await
    .unwrap();

    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert_eq!(
        metadata.additional_metadata,
        vec![(
            "token_acl".to_string(),
            token_acl::ALWAYS_ALLOW_GATE_ID.to_string()
        )]
    );

    client::delete_shares_config(&mut ctx, &owner, &vault)
        .await
        .unwrap();

    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    let metadata = mint.get_variable_len_extension::<TokenMetadata>().unwrap();
    assert!(metadata.additional_metadata.is_empty());
    assert!(!vault.state(&mut ctx).await.shares_permissioned());
}

#[tokio::test]
async fn test_delete_shares_config_strands_an_existing_frozen_holder() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;
    let topup = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    thaw_through_gate(&mut ctx, &vault, &depositor.owner, depositor.shares_ata).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    client::freeze_shares_account(&mut ctx, &owner, &vault, depositor.shares_ata)
        .await
        .unwrap();
    let ata_data = ctx
        .get_account(depositor.shares_ata)
        .await
        .unwrap()
        .unwrap()
        .data;
    assert_eq!(
        StateWithExtensions::<T22Account>::unpack(&ata_data)
            .unwrap()
            .base
            .state,
        AccountState::Frozen
    );
    let user_before_delete = depositor.balances(&mut ctx).await;
    let vault_before_delete = vault.balances(&mut ctx).await;

    client::delete_shares_config(&mut ctx, &owner, &vault)
        .await
        .unwrap();
    assert!(ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .is_none());
    assert!(!vault.state(&mut ctx).await.shares_permissioned());

    // Deletion changes only the mint's default for future accounts. The incumbent
    // account stays frozen, so its holder cannot burn shares to redeem underlying.
    let err = client::try_withdraw(
        &mut ctx,
        &vault,
        &depositor,
        user_before_delete.shares,
        "USDC",
        0,
    )
    .await
    .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountFrozen, 1)
    );

    // The former recovery wrapper is also disabled by clearing `shares_permissioned`.
    let err = client::thaw_shares_account(&mut ctx, &owner, &vault, depositor.shares_ata)
        .await
        .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::SharesNotPermissioned, 0)
    );

    assert_eq!(depositor.balances(&mut ctx).await, user_before_delete);
    let vault_after = vault.balances(&mut ctx).await;
    assert_eq!(vault_after.token_vaults, vault_before_delete.token_vaults);
    assert_eq!(vault_after.shares_supply, vault_before_delete.shares_supply);
}

// ── Scenario 8: withdraw_pending_fees needs a thawed admin ATA ──────

#[tokio::test]
async fn test_withdraw_pending_fees_requires_thawed_admin_ata() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![ProgramDependency::GateAlwaysAllow],
        )
        .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    // Accrue management fees over a year of deposits.
    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let user_thaw = thaw_permissionless_ix(
        &depositor.owner.pubkey(),
        &vault.shares_mint,
        &depositor.shares_ata,
        &depositor.owner.pubkey(),
        &token_acl::ALWAYS_ALLOW_GATE_ID,
        vec![],
        false,
    );
    let tx = ctx
        .create_transaction_with_payer([user_thaw], depositor.owner.as_ref())
        .await;
    send_transaction!(ctx, tx).unwrap();
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // The admin's shares ATA is born frozen on a permissioned vault, so collecting the
    // fee shares fails inside the Token-2022 mint CPI (the actionable pre-check ships
    // with the frozen-exit follow-up)...
    let owner_shares_ata = create_ata_if_not_exists(&mut ctx, &owner, &vault.shares_mint).await;
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: [(
            "USDC".to_string(),
            depositor.token_atas["USDC"], // unused by withdraw_pending_fees
        )]
        .into(),
        shares_ata: owner_shares_ata,
    };
    let err = client::try_withdraw_pending_fees(&mut ctx, &vault, &owner_accounts)
        .await
        .unwrap_err();
    match err.unwrap() {
        solana_sdk::transaction::TransactionError::InstructionError(
            _,
            solana_sdk::instruction::InstructionError::Custom(code),
        ) => assert_eq!(code, 17, "expected Token-2022 AccountFrozen"),
        other => panic!("unexpected error {other:?}"),
    }

    // ...nor into a thawed account whose owner could still be reassigned...
    let wrapper = thawed_mutable_owner_shares_account(&mut ctx, &vault, &owner).await;
    let wrapper_accounts = VaultDepositorAccounts {
        shares_ata: wrapper,
        ..owner_accounts.clone()
    };
    let res = client::try_withdraw_pending_fees(&mut ctx, &vault, &wrapper_accounts).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SharesAccountOwnerMutable, 0)
    );

    // ...and succeeds after the admin thaws their own ATA through the wrapper.
    client::thaw_shares_account(&mut ctx, &owner, &vault, owner_shares_ata)
        .await
        .unwrap();
    client::try_withdraw_pending_fees(&mut ctx, &vault, &owner_accounts)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_toggle_and_gate_rotation_without_metadata() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_permissioned(
            token_acl::ALWAYS_ALLOW_GATE_ID,
            vec![
                ProgramDependency::GateAlwaysAllow,
                ProgramDependency::GateAlwaysBlock,
            ],
        )
        .await;

    // Toggle success path: flip both flags and back, asserting the MintConfig follows.
    client::toggle_shares_permissionless(&mut ctx, &owner, &vault, true, false)
        .await
        .unwrap();
    let config_data = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap()
        .data;
    let config = MintConfig::unpack(&config_data).unwrap();
    assert!(config.permissionless_freeze_enabled);
    assert!(!config.permissionless_thaw_enabled);

    client::toggle_shares_permissionless(&mut ctx, &owner, &vault, false, true)
        .await
        .unwrap();
    let config_data = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap()
        .data;
    let config = MintConfig::unpack(&config_data).unwrap();
    assert!(!config.permissionless_freeze_enabled);
    assert!(config.permissionless_thaw_enabled);

    // The default pubkey is not a gate.
    let err = client::set_shares_gating_program(
        &mut ctx,
        &owner,
        &vault,
        solana_program::pubkey::Pubkey::default(),
    )
    .await
    .unwrap_err();
    assert_eq!(
        err.unwrap(),
        metavault_error!(KaminoVaultError::SharesGatingProgramInvalid, 0)
    );

    // Gate rotation on a vault whose metadata was never initialized: the discovery-key
    // sync is skipped and the rotation still succeeds.
    client::set_shares_gating_program(&mut ctx, &owner, &vault, token_acl::ALWAYS_BLOCK_GATE_ID)
        .await
        .unwrap();
    let config_data = ctx
        .get_account(vault.shares_mint_config)
        .await
        .unwrap()
        .unwrap()
        .data;
    let config = MintConfig::unpack(&config_data).unwrap();
    assert_eq!(config.gating_program, token_acl::ALWAYS_BLOCK_GATE_ID);
    let mint_account = ctx.get_account(vault.shares_mint).await.unwrap().unwrap();
    let mint = StateWithExtensions::<Mint>::unpack(&mint_account.data).unwrap();
    assert!(mint.get_variable_len_extension::<TokenMetadata>().is_err());
}

use kamino_lending::program_test::common::{
    math::usdc_decimal_to_u64,
    types::{MSpec, MarketsSpec, MintSpec, RSpec},
};
use maplit::hashmap;
use metavault::{
    program_test::{
        client::{self, start_rebalance, UpdateVaultConfigParams},
        fixtures::{setup_markets_and_reserves, setup_markets_with_weights},
        setup, VaultDepositorAccounts,
    },
    utils::consts::YEAR,
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_refresh_vault_charges_fees_without_spl_transfers() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;

    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    let state_before = vault.state(&mut ctx).await;
    let balances_before = vault.balances(&mut ctx).await;

    client::refresh_vault(&mut ctx, &vault, &depositor.owner).await;

    let state_after = vault.state(&mut ctx).await;
    let balances_after = vault.balances(&mut ctx).await;

    assert!(state_after.pending_fees_sf > state_before.pending_fees_sf);
    assert!(state_after.shares_issued > state_before.shares_issued);
    assert!(state_after.last_fee_charge_timestamp > state_before.last_fee_charge_timestamp);
    assert_eq!(
        state_after.last_fee_charge_timestamp,
        state_after.last_perf_fee_charge_timestamp
    );
    assert_eq!(state_after.prev_aum_sf, state_before.prev_aum_sf);

    assert_eq!(balances_after.shares_supply, balances_before.shares_supply);
    assert_eq!(balances_after.token_vaults, balances_before.token_vaults);
}

#[tokio::test]
async fn test_refresh_vault_finishes_elapsed_rebalance() {
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        vec![3, 4],
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0)).await;

    start_rebalance(&mut ctx, &admin, &vault, 600).await;
    ctx.fast_forward_seconds(601).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let state_before = vault.state(&mut ctx).await;
    assert!(state_before.rebalance.is_unfinished());

    client::refresh_vault(&mut ctx, &vault, &depositor.owner).await;

    let state_after = vault.state(&mut ctx).await;
    assert!(!state_after.rebalance.is_unfinished());
    assert_eq!(state_after.rebalance.end_timestamp, 0);
}

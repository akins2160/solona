use anchor_lang::Id;
use anchor_spl::token::Token;
use kamino_lending::{
    assert_fuzzy_eq,
    program_test::common::{
        setup::{funded_new_kp, kp},
        token_operations,
        types::{MSpec, MarketsSpec, MintSpec, RSpec},
    },
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    operations::rebalance_basket::RebalanceBasket,
    program_test::{
        client::{
            self, deposit, rebalance_swap, rebalance_targets, start_rebalance, stop_rebalance,
            try_start_rebalance, update_vault_config, withdraw, RequestedOut,
            UpdateVaultConfigParams,
        },
        fixtures::{setup_markets, setup_markets_with_weights},
        setup, VaultDepositorAccounts,
    },
    types::TokenAmount,
    utils::consts::INITIAL_DEPOSIT_SIZE,
    KaminoVaultError,
};
use solana_program::native_token::LAMPORTS_PER_SOL;
use solana_program_test::tokio;
use solana_sdk::signer::Signer;

#[tokio::test]
async fn test_start_rebalance_empty_vault() {
    // Set initial weights to 30%, 30%, 40% (3:3:4)
    let initial_weights = vec![3u64, 3u64, 4u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
                RSpec::new("USDT", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Verify initial weights
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].weight, 3);
    assert_eq!(vault_state.vault_tokens[1].weight, 3);
    assert_eq!(vault_state.vault_tokens[2].weight, 4);
    assert!(!vault_state.rebalance.is_unfinished());

    // Start rebalance with a duration of 1 hour (3600 seconds)
    let rebalance_duration = 3600u64;
    let result = try_start_rebalance(&mut ctx, &admin, &vault, rebalance_duration).await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultAlreadyRebalanced, 0)
    );

    // Rebalance doesnt start as all but 1 tokens are settled
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());
    assert_eq!(vault_state.rebalance.end_timestamp, 0);

    // Targets are derived from balances, weights (3:3:4) and prices whenever they are read.
    // With 1_000 lamports of USDC as the whole AUM (~$0.001): USDC ~300 and USDT ~400 lamports
    // are within the settle tolerance of their targets, so only SOL is unsettled, it has nothing
    // to swap against, and there is nothing to start.
    let targets = rebalance_targets(&mut ctx, &vault).await;
    let unsettled = vault_state
        .tokens()
        .into_iter()
        .zip(&targets)
        .filter(|(token, target)| !token.is_settled(TokenAmount::from(**target)))
        .count();
    assert_eq!(unsettled, 1);
}

#[tokio::test]
async fn test_start_rebalance_invalid_duration() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
        ])],
    })
    .await;

    let admin = ctx.initial_market_owner.clone();

    let invalid_duration = u64::from(metavault::utils::consts::MIN_REBALANCE_DURATION) - 1;
    let result = try_start_rebalance(&mut ctx, &admin, &vault, invalid_duration).await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidRebalanceDuration, 0)
    );

    let too_long_duration = u64::from(metavault::utils::consts::MAX_REBALANCE_DURATION) + 1;
    let result = try_start_rebalance(&mut ctx, &admin, &vault, too_long_duration).await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidRebalanceDuration, 0)
    );
}

#[tokio::test]
async fn test_start_rebalance_with_zero_weights() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
        ])],
    })
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Set all weights to zero first
    let zero_weights = vec![0u64, 0u64];
    let result = metavault::program_test::client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(zero_weights),
    )
    .await;

    // Setting zero weights should fail
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidWeightsSum, 1)
    );
}

#[tokio::test]
async fn test_start_rebalance_while_already_active() {
    // Set different weights to ensure rebalance is needed
    let weights = vec![2u64, 3u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("USDT", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;

    // Start first rebalance - with 3 tokens and different weights, it should be active
    let rebalance_duration = 3600u64;
    start_rebalance(&mut ctx, &admin, &vault, rebalance_duration).await;

    // Verify rebalance is active
    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.rebalance.is_unfinished());

    // Try to start another rebalance while first is active
    let result = try_start_rebalance(&mut ctx, &admin, &vault, rebalance_duration).await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 0)
    );
}

#[tokio::test]
async fn test_add_vault_token_during_active_rebalance_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, mut vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let before = vault.state(&mut ctx).await;
    assert!(before.rebalance.is_unfinished());
    let enabled_tokens_before = before
        .iter_enabled_tokens()
        .map(|token| (token.mint, token.weight, token.token_available))
        .collect::<Vec<_>>();
    let rebalance_start_before = before.rebalance.start_timestamp;
    let rebalance_end_before = before.rebalance.end_timestamp;

    let new_mint = kp();
    token_operations::create_mint(&mut ctx, &new_mint, 6, &admin.pubkey(), &Token::id(), None)
        .await;
    let scope_feed = vault.scope_prices[&vault.vault_tokens["USDC"].token_mint].scope_feed;

    let result = client::try_add_vault_token(
        &mut ctx,
        &admin,
        &mut vault,
        "NEW",
        new_mint.pubkey(),
        scope_feed,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 1)
    );
    assert!(!vault.vault_tokens.contains_key("NEW"));

    let after = vault.state(&mut ctx).await;
    assert_eq!(after.rebalance.start_timestamp, rebalance_start_before);
    assert_eq!(after.rebalance.end_timestamp, rebalance_end_before);
    assert!(after.get_vault_token_by_mint(&new_mint.pubkey()).is_err());
    assert_eq!(
        after
            .iter_enabled_tokens()
            .map(|token| { (token.mint, token.weight, token.token_available,) })
            .collect::<Vec<_>>(),
        enabled_tokens_before
    );
}

#[tokio::test]
async fn test_start_rebalance_with_deposits() {
    // Set initial weights to 20%, 30%, 50% (2:3:5)
    let initial_weights = vec![2u64, 3u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "SOL".to_string() => MintSpec::spl(9, 100.0),
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "USDT".to_string() => MintSpec::spl(6, 1.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("SOL", 0),
                RSpec::new("USDC", 0),
                RSpec::new("USDT", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Create depositors and make some deposits
    // Deposit 1,000,000 USDC lamports ($1 with 6 decimals)
    let usdc_depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 10_000_000).await;
    deposit(&mut ctx, &vault, &usdc_depositor, "USDC", 1_000_000).await;

    // Deposit 500,000 USDT lamports ($0.50 with 6 decimals)
    let usdt_depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDT", 10_000_000).await;
    deposit(&mut ctx, &vault, &usdt_depositor, "USDT", 500_000).await;

    // Deposit 10,000 SOL lamports (0.00001 SOL = $0.001 at $100/SOL with 9 decimals)
    let sol_depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", 100_000).await;
    deposit(&mut ctx, &vault, &sol_depositor, "SOL", 10_000).await;

    // Start rebalance with a duration of 2 hours (7200 seconds)
    let rebalance_duration = 7200u64;
    start_rebalance(&mut ctx, &admin, &vault, rebalance_duration).await;

    // Verify rebalance has started
    let vault_state = vault.state(&mut ctx).await;
    assert!(vault_state.rebalance.is_unfinished());
    assert_eq!(
        vault_state.rebalance.end_timestamp - vault_state.rebalance.start_timestamp,
        rebalance_duration
    );

    // Check that target lamounts are calculated for each token based on weights (2:3:5)
    // After deposits we have significant AUM, so targets should be meaningful
    // With alphabetical sorting BUT usdc always first: USDC[0], SOL[1], USDT[2]
    let targets = rebalance_targets(&mut ctx, &vault).await;
    let (usdc_target, sol_target, usdt_target) = (targets[0], targets[1], targets[2]);

    // Current balances after deposits:
    // SOL: 10,000 lamports = 0.00001 SOL = $0.001 (at $100/SOL)
    // USDC: 1,000,000 + 1,000 = 1,001,000 lamports = $1.001 (at $1/USDC)
    // USDT: 500,000 lamports = $0.50 (at $1/USDT)
    // Total AUM = $1.502

    // With weights: USDC = 20% (2), SOL = 30% (3), USDT = 50% (5)
    // Total weight = 10
    // Target AUM per token:
    // - SOL: $1.502 * 30% = $0.4506 → 0.004506 SOL → 4,506,000 lamports
    // - USDC: $1.502 * 20% = $0.3004 → 300,400 lamports
    // - USDT: $1.502 * 50% = $0.751 → 751,000 lamports

    // Verify actual rebalance targets match calculated values
    // Based on current balances: SOL: 1001000, USDC: 9991, USDT: 500000
    // And weights (2:3:5) with alphabetical ordering
    assert_fuzzy_eq!(usdc_target, 300_399, 3); // USDC needs to increase significantly
    assert_fuzzy_eq!(sol_target, 4_506_000, 3); // SOL needs to decrease significantly
    assert_fuzzy_eq!(usdt_target, 751_000, 3); // USDT needs to increase
}

/// Test deposit during rebalance updates targets based on new AUM
#[tokio::test]
async fn test_deposit_during_rebalance_updates_targets() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Initial deposit creates imbalance: 1000 USDC only
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Check initial targets: with $1000 total and equal weights, should be 500/500
    let targets_before = rebalance_targets(&mut ctx, &vault).await;
    // Initial targets should be 500 USDC and 5 SOL (at $100 each)
    assert_fuzzy_eq!(targets_before[0], 500_000_000, 10);
    assert_fuzzy_eq!(targets_before[1], 5_000_000_000u64, 10);

    // Another user deposits more USDC during rebalance
    let depositor2 = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 500_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor2,
        "USDC",
        500_000_000, // Add 500 USDC
    )
    .await;

    // Check updated targets after deposit
    // The deposit of 500 USDC increases AUM from 1000 to 1500
    // Targets are updated proportionally: 50% increase in AUM
    // USDC target: 500 * 1.5 = 750
    // SOL target: 5 * 1.5 = 7.5 SOL
    let vault_state_after = vault.state(&mut ctx).await;
    let targets_after = rebalance_targets(&mut ctx, &vault).await;
    assert_fuzzy_eq!(
        targets_after[0],
        750_000_000, // 500 * 1.5
        10
    );
    assert_fuzzy_eq!(
        targets_after[1],
        7_500_000_000u64, // 5 * 1.5
        10
    );

    // Rebalance should still be active
    assert!(vault_state_after.rebalance.is_unfinished());

    // Swapper provides SOL for the updated target
    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // Swap SOL for USDC to reach the new targets
    // We have 1500 USDC, target is 750, so excess of 750 USDC
    // We have 0 SOL, target is 7.5 SOL, so deficit of 7.5 SOL
    // Swap 7.5 SOL for 750 USDC
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        7_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify final balances match new targets
    let vault_balances = vault.balances(&mut ctx).await;
    assert_fuzzy_eq!(vault_balances.token_vaults["USDC"], 750_000_000, 10);
    assert_fuzzy_eq!(vault_balances.token_vaults["SOL"], 7_500_000_000u64, 10);

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify swapper balances
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_fuzzy_eq!(swapper_balances.tokens["USDC"], 750_000_000, 10); // Received 750 USDC
    assert_fuzzy_eq!(swapper_balances.tokens["SOL"], 2_500_000_000u64, 10); // 10 - 7.5 swapped = 2.5 SOL left
}

/// Test withdrawal during rebalance updates targets based on new AUM
#[tokio::test]
async fn test_withdraw_during_rebalance_updates_targets() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();

    // Initial deposit creates imbalance: 1000 USDC only
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Check initial targets: with $1000 total and equal weights, should be 500/500
    let targets_before = rebalance_targets(&mut ctx, &vault).await;
    // Initial targets should be 500 USDC and 5 SOL (at $100 each)
    assert_fuzzy_eq!(targets_before[0], 500_000_000, 10);
    assert_fuzzy_eq!(targets_before[1], 5_000_000_000u64, 10);

    // User withdraws some shares during rebalance
    withdraw(
        &mut ctx,
        &vault,
        &depositor,
        300_000_000, // Withdraw 300 shares (30% of 1000), leaving ~700 USDC
        "USDC",
    )
    .await;

    // Check updated targets after withdrawal
    // The withdrawal of ~300 shares (30% of 1000) reduces AUM by 30%
    // Targets are updated proportionally: 70% of original
    // USDC target: 500 * 0.7 = 350
    // SOL target: 5 * 0.7 = 3.5 SOL
    let vault_state_after = vault.state(&mut ctx).await;
    let targets_after = rebalance_targets(&mut ctx, &vault).await;
    assert_fuzzy_eq!(
        targets_after[0],
        350_000_000, // 500 * 0.7
        10
    );
    assert_fuzzy_eq!(
        targets_after[1],
        3_500_000_000u64, // 5 * 0.7
        10
    );

    // Rebalance should still be active
    assert!(vault_state_after.rebalance.is_unfinished());

    // Swapper provides SOL for the updated target
    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 5_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    // Swap SOL for USDC to reach the new targets
    // We have ~700 USDC, target is ~350, so excess of ~350 USDC
    // We have 0 SOL, target is 3.5 SOL, so deficit of 3.5 SOL
    rebalance_swap(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        3_500_000_000,
        RequestedOut::AtCurve,
    )
    .await;

    // Verify final balances
    let vault_balances = vault.balances(&mut ctx).await;
    assert_fuzzy_eq!(vault_balances.token_vaults["USDC"], 350_000_000, 10);
    assert_fuzzy_eq!(vault_balances.token_vaults["SOL"], 3_500_000_000u64, 10);

    // Verify rebalance is complete
    let vault_state = vault.state(&mut ctx).await;
    assert!(!vault_state.rebalance.is_unfinished());

    // Verify swapper balances
    let swapper_balances = swapper.balances(&mut ctx).await;
    assert_fuzzy_eq!(swapper_balances.tokens["USDC"], 350_000_000, 10); // Received ~350 USDC
    assert_fuzzy_eq!(swapper_balances.tokens["SOL"], 1_500_000_000, 10); // 5 - 3.5 swapped = 1.5 SOL left
}

#[tokio::test]
async fn test_dutch_auction_bounds_below_min_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    let result = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 4999, // below MIN_DUTCH_AUCTION_SCALE_BPS (5000)
            10000, 10000, 10000,
        ),
    )
    .await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidDutchAuctionBounds, 1)
    );
}

#[tokio::test]
async fn test_dutch_auction_bounds_above_max_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    let result = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 30001, // above MAX_DUTCH_AUCTION_SCALE_BPS (30000)
            10000, 10000, 10000,
        ),
    )
    .await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidDutchAuctionBounds, 1)
    );
}

#[tokio::test]
async fn test_dutch_auction_bounds_sell_scale_inverted_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    // Sell scale: start < end (should be start >= end)
    let result = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 9000, // start_sell < end_sell (wrong direction)
            11000, 10000, 10000,
        ),
    )
    .await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidDutchAuctionBounds, 1)
    );
}

#[tokio::test]
async fn test_dutch_auction_bounds_buy_scale_inverted_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    // Buy scale: end < start (should be end >= start)
    let result = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            usdc_mint, 10000, 10000, 11000, // start_buy > end_buy (wrong direction)
            9000,
        ),
    )
    .await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidDutchAuctionBounds, 1)
    );
}

#[tokio::test]
async fn test_dutch_auction_bounds_during_active_rebalance_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE, // 1000 USDC
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Attempting to update bounds during active rebalance should fail
    let result = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(usdc_mint, 11000, 9500, 9500, 11000),
    )
    .await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 1)
    );
}

#[tokio::test]
async fn test_dutch_auction_bounds_at_min_max_boundaries_accepted() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    // All at minimum boundary (5000): sell start >= end and buy end >= start both satisfied
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(usdc_mint, 5000, 5000, 5000, 5000),
    )
    .await;

    // Max sell start, min sell end, min buy start, max buy end
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(usdc_mint, 30000, 5000, 5000, 30000),
    )
    .await;
}

#[tokio::test]
async fn test_max_rebalance_swap_slippage_config_persists() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(125),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.rebalance_limits.max_fill_slippage_bps, 125);
}

#[tokio::test]
async fn test_max_rebalance_swap_slippage_above_full_bps_rejected() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let result = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(10_001),
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSValueTooBig, 1)
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.rebalance_limits.max_fill_slippage_bps, 0);
}

#[tokio::test]
async fn test_rebalance_limits_updated_mid_rebalance_apply_from_the_next_one() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    for config in [
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(100),
        UpdateVaultConfigParams::MaxRebalanceLossBps(200),
    ] {
        client::try_update_vault_config(&mut ctx, &admin, &vault, config)
            .await
            .unwrap();
    }

    // The running rebalance keeps the limits it started with.
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.rebalance_limits.max_fill_slippage_bps, 100);
    assert_eq!(vault_state.rebalance_limits.max_loss_bps, 200);
    assert!(vault_state.rebalance.is_unfinished());
    assert_eq!(vault_state.rebalance.limits.max_fill_slippage_bps, 0);
    assert_eq!(vault_state.rebalance.limits.max_loss_bps, 0);
}

/// P1-03: admin cannot change VaultTokenScope during an active rebalance.
#[tokio::test]
async fn test_update_vault_token_scope_blocked_during_rebalance() {
    use kamino_lending::ScopeConfiguration;

    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens.get("USDC").unwrap().token_mint;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let dummy_scope = ScopeConfiguration {
        price_feed: solana_sdk::pubkey::Pubkey::default(),
        price_chain: [0, u16::MAX, u16::MAX, u16::MAX],
        twap_chain: [u16::MAX; 4],
    };
    let res = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenScope(usdc_mint, dummy_scope),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 1)
    );
}

/// P1-03: admin cannot change VaultTokenMaxAgePriceSeconds during an active rebalance.
#[tokio::test]
async fn test_update_max_age_price_blocked_during_rebalance() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens.get("USDC").unwrap().token_mint;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let res = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxAgePriceSeconds(usdc_mint, 600),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 1)
    );
}

/// P1-03: admin cannot change VaultTokenMaxAgeTwapSeconds during an active rebalance.
#[tokio::test]
async fn test_update_max_age_twap_blocked_during_rebalance() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens.get("USDC").unwrap().token_mint;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let res = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxAgeTwapSeconds(usdc_mint, 600),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 1)
    );
}

/// P1-03: admin cannot change VaultTokenMaxTwapDivergenceBps during an active rebalance.
#[tokio::test]
async fn test_update_max_twap_divergence_blocked_during_rebalance() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens.get("USDC").unwrap().token_mint;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let res = client::try_update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxTwapDivergenceBps(usdc_mint, 200),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceInProgress, 1)
    );
}

/// Rebalance cooldown rate-limits the allocation admin's consecutive rebalance starts, including
/// stop-then-restart, while the vault admin bypasses it. The vault admin's bypassed start also
/// re-arms the cooldown anchor, so the allocation admin's next start is measured from it.
#[tokio::test]
async fn test_start_rebalance_cooldown_blocks_allocation_admin_vault_admin_bypasses() {
    let initial_weights = vec![3u64, 4u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights,
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let allocation_admin = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::RebalanceCooldownSeconds(3_600),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;

    // Allocation admin starts and stops a rebalance, arming the cooldown anchor.
    start_rebalance(&mut ctx, &allocation_admin, &vault, 3600).await;
    stop_rebalance(&mut ctx, &allocation_admin, &vault).await;

    // An immediate restart by the allocation admin is blocked by the cooldown.
    let res = try_start_rebalance(&mut ctx, &allocation_admin, &vault, 3600).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceCooldownNotElapsed, 0)
    );

    // The vault admin bypasses the cooldown and re-arms the anchor with its own start.
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;
    stop_rebalance(&mut ctx, &admin, &vault).await;

    // Warp past the cooldown, measured from the vault admin's bypassed start above.
    ctx.fast_forward_seconds(3_601).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // The allocation admin can start again now that the cooldown has elapsed.
    start_rebalance(&mut ctx, &allocation_admin, &vault, 3600).await;
}

# solana-program-test fixtures

By convention, solana-program-test will scan `tests/fixtures` when adding additional programs to the runtime.

`test_cpi_caller.so` is built from `test-cpi-caller-src`:

```sh
NO_DNA=1 cargo build-sbf --offline --manifest-path programs/metavault/tests/fixtures/test-cpi-caller-src/Cargo.toml --sbf-out-dir programs/metavault/tests/fixtures -- --locked
```

## Token ACL fixtures

`token_acl.so`, `always_allow.so`, `always_block.so` and `always_allow_with_deps.so` are
built from [token-acl](https://github.com/solana-foundation/token-acl) at commit
`9b24211` ("fix: updating test fixtures (#37)") with `cargo-build-sbf 4.0.0`
(platform-tools v1.53). They load and execute under this workspace's patched
solana-program-test 1.17.18 — verified by `tests/tests_token_acl_harness.rs`.

To rebuild byte-identical fixtures (`RUSTUP_TOOLCHAIN` supplies a lockfile-v4-capable
cargo for the metadata step; the SBF compile itself uses platform-tools):

```sh
cd <token-acl checkout at 9b24211>
export SBF=<agave 4.0.0 install>/bin/cargo-build-sbf
FIXTURES=<metavault>/programs/metavault/tests/fixtures
RUSTUP_TOOLCHAIN=1.89.0 $SBF --manifest-path program/Cargo.toml --sbf-out-dir /tmp/tacl
for ex in always-allow always-block always-allow-with-deps; do
    RUSTUP_TOOLCHAIN=1.89.0 $SBF --manifest-path examples/$ex/Cargo.toml --sbf-out-dir /tmp/tacl
done
cp /tmp/tacl/token_acl.so "$FIXTURES/token_acl.so"
cp /tmp/tacl/always_allow_gate_program.so "$FIXTURES/always_allow.so"
cp /tmp/tacl/always_block_gate_program.so "$FIXTURES/always_block.so"
cp /tmp/tacl/always_allow_with_deps_gate_program.so "$FIXTURES/always_allow_with_deps.so"
```

#[cfg(not(feature = "no-entrypoint"))]
use solana_program::entrypoint;
use solana_program::{
    account_info::AccountInfo,
    entrypoint::ProgramResult,
    instruction::{AccountMeta, Instruction},
    program::{get_return_data, invoke},
    program_error::ProgramError,
    pubkey::Pubkey,
};

#[cfg(not(feature = "no-entrypoint"))]
entrypoint!(process_instruction);

pub fn process_instruction(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    data: &[u8],
) -> ProgramResult {
    let (&tag, forwarded_data) = data
        .split_first()
        .ok_or(ProgramError::InvalidInstructionData)?;

    match tag {
        0 => forward_cpi(accounts, forwarded_data),
        1 => forward_cpi_and_capture_return_data(accounts, forwarded_data),
        _ => Err(ProgramError::InvalidInstructionData),
    }
}

fn forward_cpi(accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    let target_program = accounts
        .first()
        .ok_or(ProgramError::NotEnoughAccountKeys)?
        .key;

    let forwarded_metas = accounts
        .iter()
        .skip(1)
        .map(|account| AccountMeta {
            pubkey: *account.key,
            is_signer: account.is_signer,
            is_writable: account.is_writable,
        })
        .collect();

    invoke(
        &Instruction {
            program_id: *target_program,
            accounts: forwarded_metas,
            data: data.to_vec(),
        },
        accounts,
    )
}

fn forward_cpi_and_capture_return_data(accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    let target_program = accounts
        .first()
        .ok_or(ProgramError::NotEnoughAccountKeys)?
        .key;
    let return_data_account = accounts.get(1).ok_or(ProgramError::NotEnoughAccountKeys)?;
    if !return_data_account.is_writable {
        return Err(ProgramError::InvalidAccountData);
    }

    let cpi_accounts = accounts
        .get(2..)
        .ok_or(ProgramError::NotEnoughAccountKeys)?;
    let forwarded_metas = cpi_accounts
        .iter()
        .map(|account| AccountMeta {
            pubkey: *account.key,
            is_signer: account.is_signer,
            is_writable: account.is_writable,
        })
        .collect();

    invoke(
        &Instruction {
            program_id: *target_program,
            accounts: forwarded_metas,
            data: data.to_vec(),
        },
        accounts,
    )?;

    let (returned_program, return_data) =
        get_return_data().ok_or(ProgramError::InvalidAccountData)?;
    if returned_program != *target_program {
        return Err(ProgramError::IncorrectProgramId);
    }

    let mut output = return_data_account.try_borrow_mut_data()?;
    let required_len = 4usize
        .checked_add(return_data.len())
        .ok_or(ProgramError::InvalidAccountData)?;
    if output.len() < required_len {
        return Err(ProgramError::AccountDataTooSmall);
    }
    output[..4].copy_from_slice(&(return_data.len() as u32).to_le_bytes());
    output[4..required_len].copy_from_slice(&return_data);
    Ok(())
}

use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{assert_fuzzy_eq, program_test::common::math::usdc_decimal_to_u64};
use metavault::program_test::{client, fixtures, setup};
use rand::Rng;
use solana_program_test::tokio;
use test_case::test_case;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_vault_first_depositor_inflated_share_price_random() {
    let num_cases = 20;
    eprintln!("Running {} random test cases", num_cases);

    let mut rng = rand::thread_rng();
    for index in 0..num_cases {
        let number_of_deposits = rng.gen_range(1..40);
        let mut deposits = Vec::new();
        for _ in 0..number_of_deposits {
            deposits.push(rng.gen_range(1000..usdc(100_000.0)));
        }
        let first_user_initial_deposit = rng.gen_range(usdc(10.0)..usdc(900_000.0));
        let second_user_deposit = rng.gen_range(100..usdc(100.0));

        eprintln!(
            "{} {}/{} test case: {} deposits, second user deposit: {}",
            chrono::offset::Utc::now(),
            index + 1,
            num_cases,
            number_of_deposits,
            second_user_deposit
        );

        test_vault_first_depositor_inflated_share_price(
            first_user_initial_deposit,
            deposits,
            second_user_deposit,
        )
        .await;
    }
}

#[test_case(usdc(100.0), [5, 9, 15, 23, 35, 53, 80, 120, 180, 270, 405, 607, 910, 1365, 2047, 3070].into(), 4600)]
#[test_case(usdc(50_000.0), [5_000, 9_000, 15_000, 23_000, 35_000, 53_000, 80_000, 120_000, 180_000, 270_000, 405_000, 607_000, 910_000, 1_365_000, 2_047_000, 3_070_000].into(), 4600)]
#[test_case(usdc(20_000_000.), [5, 9, 15, 23, 35, 53, 80, 120, 180, 270, 405, 607, 910, 1365, 2047, 3070, 5_000, 9_000, 15_000, 23_000, 35_000, 53_000, 80_000, 120_000, 180_000, 270_000, 405_000, 607_000, 910_000, 1_365_000, 2_047_000, 3_070_000].into(), 4600)]
#[test_case(usdc(90_000_000.0), [5_000_000, 9_000_000, 15_000_000, 23_000_000, 35_000_000, 53_000_000, 80_000_000, 120_000_000, 180_000_000, 270_000_000, 405_000_000, 607_000_000, 910_000_000, 1_365_000_000, 2_047_000_000, 3_070_000_000].into(), 400)]
#[tokio::test]
async fn test_vault_first_depositor_inflated_share_price(
    initial_deposit_amount: u64,
    user_deposits: Vec<u64>,
    second_user_deposit: u64,
) {
    let (mut ctx, vault, _, _, _) = fixtures::setup_markets_and_reserves_with_yield(1).await;

    let initial_balance = usdc(100_000_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_balance).await;

    let deposit_amount = initial_deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    ctx.fast_forward_minutes(1).await;

    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    let balances = vault.balances(&mut ctx).await;
    let amount = balances.shares_supply - 1;
    client::withdraw(&mut ctx, &vault, &depositor, amount, "USDC").await;

    for (_, to_deposit) in user_deposits.iter().enumerate() {
        client::deposit(&mut ctx, &vault, &depositor, "USDC", *to_deposit).await;
        client::withdraw(&mut ctx, &vault, &depositor, 10, "USDC").await;
    }

    let balances = vault.balances(&mut ctx).await;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", balances.token_vaults["USDC"]).await;

    let second_depositor_initial_balance = second_user_deposit;
    let second_depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", second_depositor_initial_balance)
            .await;

    client::deposit(
        &mut ctx,
        &vault,
        &second_depositor,
        "USDC",
        second_depositor_initial_balance,
    )
    .await;

    let second_depositor_balances = second_depositor.balances(&mut ctx).await;
    assert!(second_depositor_balances.shares < second_depositor_initial_balance);

    // second user withdraws everything
    client::withdraw(
        &mut ctx,
        &vault,
        &second_depositor,
        second_depositor_balances.shares,
        "USDC",
    )
    .await;

    let second_depositor_balances = second_depositor.balances(&mut ctx).await;
    assert_eq!(second_depositor_balances.shares, 0);
    assert_fuzzy_eq!(
        second_depositor_balances.tokens["USDC"],
        second_depositor_initial_balance,
        2
    );
}

use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{program_test::common::math::usdc_decimal_to_u64, utils::FULL_BPS};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, YEAR},
    GlobalConfig, KaminoVaultError,
};

use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

fn gross_withdraw_amount(
    vault_token_available: u64,
    shares_issued: u64,
    shares_to_withdraw: u64,
) -> u64 {
    ((vault_token_available as u128 * shares_to_withdraw as u128) / shares_issued as u128) as u64
}

fn proportional_fee(amount: u64, bps_fee: u64) -> u64 {
    if bps_fee == 0 {
        0
    } else {
        ((amount as u128 * bps_fee as u128 + FULL_BPS as u128 - 1) / FULL_BPS as u128) as u64
    }
}

fn withdraw_fee(amount: u64, lamports_fee: u64, bps_fee: u64) -> u64 {
    lamports_fee.max(proportional_fee(amount, bps_fee))
}

#[tokio::test]
async fn test_set_withdraw_penalty_lamports_and_bps() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    // check updating the penalties above max allowed fails

    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            10_001,
        ),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::LamportsFeeGreaterThanMaxAllowed, 1)
    );

    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            1001,
        ),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSFeeGreaterThanMaxAllowed, 1)
    );

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            1000,
        ),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].withdraw_fee_lamports, 1000);
    assert_eq!(vault_state.vault_tokens[0].withdraw_fee_bps, 0);

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            123,
        ),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].withdraw_fee_lamports, 1000);
    assert_eq!(vault_state.vault_tokens[0].withdraw_fee_bps, 123);
}

#[tokio::test]
async fn test_lamports_fees_multiple_withdraws() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_withdraw_penalty = 20;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_withdraw_penalty,
        ),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].withdraw_fee_lamports,
        lamports_withdraw_penalty
    );
    assert_eq!(vault_state.vault_tokens[0].withdraw_fee_bps, 0);

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(10.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, lamports_withdraw_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        vault_state_before_withdraw.vault_tokens[0].token_available
            - (expected_gross - expected_fee)
    );

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(10.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, lamports_withdraw_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        vault_state_before_withdraw.vault_tokens[0].token_available
            - (expected_gross - expected_fee)
    );

    let balances_before_final = balances_after.clone();
    let vault_state_before_final = vault.state(&mut ctx).await;
    let withdraw_amount = balances_after.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_final.vault_tokens[0].token_available,
        vault_state_before_final.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, lamports_withdraw_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_final.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(balances_after.shares, 0);
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        vault_state_before_final.vault_tokens[0].token_available - (expected_gross - expected_fee)
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
}

#[tokio::test]
async fn test_bps_multiple_withdraws() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let bps_withdraw_penalty = 100;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_withdraw_penalty,
        ),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].withdraw_fee_lamports, 0);
    assert_eq!(
        vault_state.vault_tokens[0].withdraw_fee_bps,
        bps_withdraw_penalty
    );

    let initial_deposit = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_deposit).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], initial_deposit);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", initial_deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, initial_deposit - 1);

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(24.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, 0, bps_withdraw_penalty);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(400.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, 0, bps_withdraw_penalty);

    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    let balances_before_final = balances_after.clone();
    let shares_before_final = balances_before_final.shares;
    let vault_state_before_final = vault.state(&mut ctx).await;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_final.vault_tokens[0].token_available,
        vault_state_before_final.shares_issued,
        shares_before_final,
    );
    let expected_fee = withdraw_fee(expected_gross, 0, bps_withdraw_penalty);
    client::withdraw(&mut ctx, &vault, &depositor, initial_deposit, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_final.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(balances_after.shares, 0);
}

#[tokio::test]
async fn test_different_size_withdraws_fees() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_withdraw_penalty = 200;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_withdraw_penalty,
        ),
    )
    .await;

    let bps_withdraw_penalty = 10;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_withdraw_penalty,
        ),
    )
    .await;

    let initial_deposit = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_deposit).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], initial_deposit);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", initial_deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, initial_deposit - 1);

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(1.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(
        expected_gross,
        lamports_withdraw_penalty,
        bps_withdraw_penalty,
    );
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(0.001);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(
        expected_gross,
        lamports_withdraw_penalty,
        bps_withdraw_penalty,
    );
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(100.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(
        expected_gross,
        lamports_withdraw_penalty,
        bps_withdraw_penalty,
    );
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );
}

#[tokio::test]
async fn test_withdraw_less_than_withdraw_penalty_fails() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_withdraw_penalty = usdc(0.001);
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_withdraw_penalty,
        ),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;

    let withdraw_amount = usdc(0.00099);
    let result =
        client::try_withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC", 0).await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::WithdrawAmountLessThanWithdrawalFee, 1)
    );
}

#[tokio::test]
async fn test_different_size_and_fee_params_withdraws_fees() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    // start with lamports fee only
    let lamports_withdraw_penalty = 200;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_withdraw_penalty,
        ),
    )
    .await;

    let initial_deposit = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_deposit).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], initial_deposit);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", initial_deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, initial_deposit - 1);

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(100.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, lamports_withdraw_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    // set bps fee
    let bps_withdraw_penalty = 1;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_withdraw_penalty,
        ),
    )
    .await;

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(100.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(expected_gross, 0, bps_withdraw_penalty);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );

    // increase the fixed lamports fee
    let lamports_withdraw_penalty = 1000;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_withdraw_penalty,
        ),
    )
    .await;

    let balances_before_withdraw = balances_after.clone();
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let withdraw_amount = usdc(5.0);
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        withdraw_amount,
    );
    let expected_fee = withdraw_fee(
        expected_gross,
        lamports_withdraw_penalty,
        bps_withdraw_penalty,
    );
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
    assert_eq!(
        balances_after.shares,
        balances_before_withdraw.shares - withdraw_amount
    );
}

#[tokio::test]
async fn test_global_config_fees_lamports_is_used() {
    let mut global_config_state = GlobalConfig::default();

    // set global config 200 bps lamports fee
    let lamports_withdraw_penalty = 200;
    global_config_state.withdrawal_fee_lamports = lamports_withdraw_penalty;
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let expected_fee = withdraw_fee(expected_gross, lamports_withdraw_penalty, 0);
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_bps_is_used() {
    let mut global_config_state = GlobalConfig::default();

    // set global config 1000 bps fee
    let withdraw_fee_bps = 1000;
    global_config_state.withdrawal_fee_bps = withdraw_fee_bps;
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(expected_gross, 0, withdraw_fee_bps);
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_lamports_and_bps_non_zero_lamports_fee_is_used() {
    let mut global_config_state = GlobalConfig::default();

    // set global config 200 bps lamports fee
    let withdraw_fee_bps = 10;
    let withdraw_fee_lamports = 50_000;
    global_config_state.withdrawal_fee_bps = withdraw_fee_bps;
    global_config_state.withdrawal_fee_lamports = withdraw_fee_lamports;
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let deposit_amount = usdc(1.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(expected_gross, withdraw_fee_lamports, withdraw_fee_bps);
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_lamports_and_bps_non_zero_bps_fee_is_used() {
    let mut global_config_state = GlobalConfig::default();

    let withdraw_fee_bps = 100;
    let withdraw_fee_lamports = 300;
    global_config_state.withdrawal_fee_bps = withdraw_fee_bps;
    global_config_state.withdrawal_fee_lamports = withdraw_fee_lamports;
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let deposit_amount = usdc(5000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(expected_gross, withdraw_fee_lamports, withdraw_fee_bps);
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_vault_lamport_fee_used() {
    let mut global_config_state = GlobalConfig::default();

    let global_config_lamports_fee = 100;
    let global_config_bps_fee = 1;
    global_config_state.withdrawal_fee_lamports = global_config_lamports_fee;
    global_config_state.withdrawal_fee_bps = global_config_bps_fee;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let vault_lamports_fee = 5000;
    let vault_bps_fee = 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_fee,
        ),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_fee,
        ),
    )
    .await;

    let deposit_amount = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(expected_gross, vault_lamports_fee, vault_bps_fee);
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_global_lamport_fee_used() {
    let mut global_config_state = GlobalConfig::default();

    let global_config_lamports_fee = 1000;
    let global_config_bps_fee = 0;
    global_config_state.withdrawal_fee_lamports = global_config_lamports_fee;
    global_config_state.withdrawal_fee_bps = global_config_bps_fee;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let vault_lamports_fee = 500;
    let vault_bps_fee = 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_fee,
        ),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_fee,
        ),
    )
    .await;

    let deposit_amount = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(
        expected_gross,
        global_config_lamports_fee,
        global_config_bps_fee,
    );
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_vault_bps_fee_used() {
    let mut global_config_state = GlobalConfig::default();

    let global_config_lamports_fee = 100;
    let global_config_bps_fee = 1;
    global_config_state.withdrawal_fee_lamports = global_config_lamports_fee;
    global_config_state.withdrawal_fee_bps = global_config_bps_fee;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let vault_lamports_fee = 100;
    let vault_bps_fee = 1000;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_fee,
        ),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_fee,
        ),
    )
    .await;

    let deposit_amount = usdc(10_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(expected_gross, vault_lamports_fee, vault_bps_fee);
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_global_bps_fee_used() {
    let mut global_config_state = GlobalConfig::default();

    let global_config_lamports_penalty = 20;
    let global_config_bps_penalty = 100;
    global_config_state.withdrawal_fee_lamports = global_config_lamports_penalty;
    global_config_state.withdrawal_fee_bps = global_config_bps_penalty;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let vault_lamports_withdraw_penalty = 50;
    let vault_bps_withdraw_penalty = 99;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_withdraw_penalty,
        ),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_withdraw_penalty,
        ),
    )
    .await;

    let deposit_amount = usdc(500.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = balances_after_deposit.shares;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let withdraw_amount = deposit_amount;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw_amount, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    let expected_fee = withdraw_fee(
        expected_gross,
        global_config_lamports_penalty.max(vault_lamports_withdraw_penalty),
        global_config_bps_penalty.max(vault_bps_withdraw_penalty),
    );
    assert_eq!(balances_after_withdraw.shares, 0);
    assert_eq!(
        balances_after_withdraw.tokens["USDC"],
        expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_withdraw_with_fee_prev_aum_is_updated_correctly_1() {
    let mut global_config_state = GlobalConfig::default();

    let global_config_lamports_penalty = 5_000;
    global_config_state.withdrawal_fee_lamports = global_config_lamports_penalty;
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    let vault_state_before_deposit = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state_before_deposit.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let user_balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(user_balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(user_balances_after_deposit.tokens["USDC"], 0);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit_amount + INITIAL_DEPOSIT_SIZE
    );

    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let balances_before_withdraw = user_balances_after_deposit.clone();
    let net_amount_to_withdraw = 10;
    let amount_to_withdraw = global_config_lamports_penalty + net_amount_to_withdraw;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        amount_to_withdraw,
    );
    let expected_fee = withdraw_fee(expected_gross, global_config_lamports_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, amount_to_withdraw, "USDC").await;

    let user_balances_after_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(
        user_balances_after_withdraw.shares,
        balances_before_withdraw.shares - amount_to_withdraw
    );
    assert_eq!(
        user_balances_after_withdraw.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        vault_state_before_withdraw.vault_tokens[0].token_available
            - (expected_gross - expected_fee)
    );

    let shares_before_final = user_balances_after_withdraw.shares;
    let vault_state_before_final = vault.state(&mut ctx).await;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_final.vault_tokens[0].token_available,
        vault_state_before_final.shares_issued,
        shares_before_final,
    );
    let expected_fee = withdraw_fee(expected_gross, global_config_lamports_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, shares_before_final, "USDC").await;

    let user_balances_after_total_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(user_balances_after_total_withdraw.shares, 0);
    assert_eq!(
        user_balances_after_total_withdraw.tokens["USDC"],
        user_balances_after_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
}

#[tokio::test]
async fn test_withdraw_with_fee_prev_aum_is_updated_correctly_share_price_above_1() {
    let mut global_config_state = GlobalConfig::default();

    let global_config_lamports_penalty = 7_000;
    global_config_state.withdrawal_fee_lamports = global_config_lamports_penalty;
    let (mut ctx, vault, _owner, _, _) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(
            1,
            Some(global_config_state),
        )
        .await;

    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", deposit_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], deposit_amount);

    let vault_state_before_deposit = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state_before_deposit.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let user_balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(user_balances_after_deposit.shares, deposit_amount - 1);
    assert_eq!(user_balances_after_deposit.tokens["USDC"], 0);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit_amount + INITIAL_DEPOSIT_SIZE
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE + deposit_amount
    );
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(
        &mut ctx,
        &vault,
        "USDC",
        deposit_amount + INITIAL_DEPOSIT_SIZE,
    )
    .await;

    let balances_before_withdraw = depositor.balances(&mut ctx).await;
    let vault_state_before_withdraw = vault.state(&mut ctx).await;
    let shares_to_withdraw = 10_000;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_withdraw.vault_tokens[0].token_available,
        vault_state_before_withdraw.shares_issued,
        shares_to_withdraw,
    );
    let expected_fee = withdraw_fee(expected_gross, global_config_lamports_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    let user_balances_after_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(
        user_balances_after_withdraw.shares,
        balances_before_withdraw.shares - shares_to_withdraw
    );
    assert_eq!(
        user_balances_after_withdraw.tokens["USDC"],
        balances_before_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        vault_state_before_withdraw.vault_tokens[0].token_available
            - (expected_gross - expected_fee)
    );

    let shares_before_final = user_balances_after_withdraw.shares;
    let vault_state_before_final = vault.state(&mut ctx).await;
    let expected_gross = gross_withdraw_amount(
        vault_state_before_final.vault_tokens[0].token_available,
        vault_state_before_final.shares_issued,
        shares_before_final,
    );
    let expected_fee = withdraw_fee(expected_gross, global_config_lamports_penalty, 0);
    client::withdraw(&mut ctx, &vault, &depositor, shares_before_final, "USDC").await;

    let user_balances_after_total_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(user_balances_after_total_withdraw.shares, 0);
    assert_eq!(
        user_balances_after_total_withdraw.tokens["USDC"],
        user_balances_after_withdraw.tokens["USDC"] + expected_gross - expected_fee
    );
}

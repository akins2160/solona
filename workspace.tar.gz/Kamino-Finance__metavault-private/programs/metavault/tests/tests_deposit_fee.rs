use ::metavault::program_test::VaultDepositorAccounts;
use borsh::BorshSerialize;
use kamino_lending::{
    assert_fuzzy_eq, program_test::common::math::usdc_decimal_to_u64, utils::FULL_BPS,
};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    utils::{
        consts::{INITIAL_DEPOSIT_SIZE, YEAR},
        global_config::UpdateGlobalConfigMode,
        pda,
    },
    KaminoVaultError,
};

use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

/// Shares minted for a deposit of `net` (post-fee) token lamports into a vault holding `aum`
/// against `supply` shares, where the deposit also donates `fee` lamports: shares are priced
/// against post-fee AUM, so the donation is in the denominator.
fn shares_for_deposit(net: u64, supply: u64, aum: u64, fee: u64) -> u64 {
    u64::try_from(u128::from(net) * u128::from(supply) / (u128::from(aum) + u128::from(fee)))
        .unwrap()
}

#[tokio::test]
async fn test_set_deposit_penalty_lamports_and_bps() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    // check updating the penalties above max allowed fails

    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            10_001,
        ),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::LamportsFeeGreaterThanMaxAllowed, 1)
    );

    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            1001,
        ),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSFeeGreaterThanMaxAllowed, 1)
    );

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            1000,
        ),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].deposit_fee_lamports, 1000);
    assert_eq!(vault_state.vault_tokens[0].deposit_fee_bps, 0);

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            123,
        ),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].deposit_fee_lamports, 1000);
    assert_eq!(vault_state.vault_tokens[0].deposit_fee_bps, 123);
}

#[tokio::test]
async fn test_lamports_fees_multiple_deposits() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_deposit_penalty = 20;

    let initial_amount = usdc(100.0) + usdc(10.0) + usdc(10.0) + usdc(50.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let deposit = usdc(100.0);
    let mut total_deposited = deposit;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    // Track vault state to compute expected shares accounting for fee donation
    let mut vault_aum = INITIAL_DEPOSIT_SIZE + deposit;
    let mut vault_shares = INITIAL_DEPOSIT_SIZE + deposit - 1;
    let mut expected_user_shares = deposit - 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_deposit_penalty,
        ),
    )
    .await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].deposit_fee_lamports,
        lamports_deposit_penalty
    );
    assert_eq!(vault_state.vault_tokens[0].deposit_fee_bps, 0);

    let deposit_amount = usdc(10.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - lamports_deposit_penalty;
    let shares_minted = (vault_shares as u128 * net as u128
        / (vault_aum + lamports_deposit_penalty) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 1);

    let deposit_amount = usdc(10.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - lamports_deposit_penalty;
    let shares_minted = (vault_shares as u128 * net as u128
        / (vault_aum + lamports_deposit_penalty) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 2);

    // deposit more
    let deposit_amount = usdc(50.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - lamports_deposit_penalty;
    let shares_minted = (vault_shares as u128 * net as u128
        / (vault_aum + lamports_deposit_penalty) as u128) as u64;
    expected_user_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 3);
}

#[tokio::test]
async fn test_bps_multiple_deposits() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let bps_deposit_penalty = 100;

    let initial_amount = usdc(100_000.0) + usdc(24.0) + usdc(400.0) + usdc(600.0);
    let deposit_amount = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    let mut total_deposited = deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // Track vault state to compute expected shares accounting for fee donation
    let mut vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    let mut vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let mut expected_user_shares = deposit_amount - 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_deposit_penalty,
        ),
    )
    .await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_tokens[0].deposit_fee_lamports, 0);
    assert_eq!(
        vault_state.vault_tokens[0].deposit_fee_bps,
        bps_deposit_penalty
    );

    let deposit_amount = usdc(24.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 1);

    let deposit_amount = usdc(400.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 2);

    // deposit everything
    let deposit_amount = usdc(600.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 3);
}

#[tokio::test]
async fn test_different_size_deposits_fees() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_deposit_penalty = 200;
    let bps_deposit_penalty = 10;

    let initial_amount = usdc(100_000.0) + usdc(0.001) + usdc(1.0) + usdc(100.0);
    let deposit_amount = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    let mut total_deposited = deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // Track vault state to compute expected shares accounting for fee donation
    let mut vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    let mut vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let mut expected_user_shares = deposit_amount - 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_deposit_penalty,
        ),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_deposit_penalty,
        ),
    )
    .await;
    let deposit_amount = usdc(1.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // check that if the bps is higher than the lamports, the bps is used
    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 1);

    // check that if the bps is lower than the lamports, the lamports are used
    let deposit_amount = usdc(0.001);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = lamports_deposit_penalty;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 2);

    // bigger deposit, use bps fee
    let deposit_amount = usdc(100.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 3);
}

#[tokio::test]
async fn test_different_size_deposits_fees_admin_deposits_fees_after_every_action() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_deposit_penalty = 200;
    let bps_deposit_penalty = 10;

    let initial_amount = usdc(100_000.0) + usdc(0.001) + usdc(1.0) + usdc(100.0);
    let deposit_amount = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    let mut total_deposited = deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // Track vault state to compute expected shares accounting for fee donation
    let mut vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    let mut vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let mut expected_user_shares = deposit_amount - 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_deposit_penalty,
        ),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_deposit_penalty,
        ),
    )
    .await;
    let deposit_amount = usdc(1.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // check that if the bps is higher than the lamports, the bps is used
    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 1);

    // check that if the bps is lower than the lamports, the lamports are used
    let deposit_amount = usdc(0.001);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = lamports_deposit_penalty;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 2);

    // bigger deposit, use bps fee
    let deposit_amount = usdc(100.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let shares_minted = (vault_shares as u128 * net as u128 / (vault_aum + fee) as u128) as u64;
    expected_user_shares += shares_minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_user_shares, 3);
}

#[tokio::test]
async fn test_deposit_less_than_deposit_penalty_fails() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let lamports_deposit_penalty = usdc(0.001);
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_deposit_penalty,
        ),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;

    let deposit_amount = usdc(0.00099);
    let result = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount, 0).await;
    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAmountLessThanDepositFee, 1)
    );
}

#[tokio::test]
async fn test_different_size_and_fee_params_deposits_fees() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    // start with lamports fee only
    let lamports_deposit_penalty = 200;

    let initial_amount = usdc(100_000.0) + usdc(100.0) + usdc(100.0) + usdc(5.0);
    let deposit_amount = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;
    let mut total_deposited = deposit_amount;
    // Track the vault the way the program prices it: each fee-bearing deposit mints
    // `net * supply / (aum + fee)`, and the whole gross amount (fee included) stays in the
    // vault. Tracking the running supply is what keeps the donated fees accounted for.
    let mut vault_aum = deposit_amount;
    let mut vault_shares = deposit_amount;
    let mut expected_shares = deposit_amount - 1;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_deposit_penalty,
        ),
    )
    .await;
    let deposit_amount = usdc(100.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - lamports_deposit_penalty;
    let minted = shares_for_deposit(net, vault_shares, vault_aum, lamports_deposit_penalty);
    expected_shares += minted;
    vault_aum += deposit_amount;
    vault_shares += minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_shares, 1);

    // set bps fee
    let bps_deposit_penalty = 1;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            bps_deposit_penalty,
        ),
    )
    .await;

    let deposit_amount = usdc(100.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let fee = deposit_amount * bps_deposit_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let minted = shares_for_deposit(net, vault_shares, vault_aum, fee);
    expected_shares += minted;
    vault_aum += deposit_amount;
    vault_shares += minted;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_shares, 2);

    // increase the fixed lamports fee
    let lamports_deposit_penalty = 1000;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            lamports_deposit_penalty,
        ),
    )
    .await;

    let deposit_amount = usdc(5.0);
    total_deposited += deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - lamports_deposit_penalty;
    expected_shares += shares_for_deposit(net, vault_shares, vault_aum, lamports_deposit_penalty);

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        initial_amount - total_deposited
    );
    assert_fuzzy_eq!(balances_after.shares, expected_shares, 3);
}

#[tokio::test]
async fn test_global_config_fees_lamports_is_used() {
    let lamports_deposit_penalty = 200;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let initial_amount = 2 * usdc(100.0);
    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        lamports_deposit_penalty.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let net = deposit_amount - lamports_deposit_penalty;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        deposit_amount
            + shares_for_deposit(
                net,
                deposit_amount,
                deposit_amount,
                lamports_deposit_penalty
            ),
        3
    );
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
}

#[tokio::test]
async fn test_global_config_fees_bps_is_used() {
    // set global config 1000 bps lamports fee
    let deposit_fee_bps: u64 = 1000;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let initial_amount = 2 * usdc(100.0);
    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        deposit_fee_bps.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let fee = deposit_amount * deposit_fee_bps / FULL_BPS as u64;
    let net = deposit_amount - fee;
    // Price against the vault as it actually stands before this second deposit — seed included —
    // rather than against `deposit_amount` alone, which is short by the seed on both sides.
    let vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        (deposit_amount - 1) + shares_for_deposit(net, vault_shares, vault_aum, fee),
        1
    );
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
}

#[tokio::test]
async fn test_global_config_fees_lamports_and_bps_non_zero_lamports_fee_is_used() {
    let deposit_fee_bps: u64 = 1;
    let deposit_fee_lamports: u64 = 10_000;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let initial_amount = 2 * usdc(1.0);
    let deposit_amount = usdc(1.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        deposit_fee_bps.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        deposit_fee_lamports.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let net = deposit_amount - deposit_fee_lamports;
    let vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        (deposit_amount - 1)
            + shares_for_deposit(net, vault_shares, vault_aum, deposit_fee_lamports),
        1
    );
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
}

#[tokio::test]
async fn test_global_config_fees_lamports_and_bps_non_zero_bps_fee_is_used() {
    let deposit_fee_bps: u64 = 100;
    let deposit_fee_lamports: u64 = 300;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let initial_amount = 2 * usdc(5000.0);
    let deposit_amount = usdc(5000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        deposit_fee_bps.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        deposit_fee_lamports.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let fee = deposit_amount * deposit_fee_bps / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        (deposit_amount - 1) + shares_for_deposit(net, vault_shares, vault_aum, fee),
        1
    );
    assert_eq!(
        balances_after_deposit.tokens["USDC"],
        initial_amount - 2 * deposit_amount
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_vault_lamport_fee_used() {
    let global_config_lamports_fee: u64 = 100;
    let global_config_bps_fee: u64 = 1;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let vault_lamports_fee = 5000;
    let vault_bps_fee = 1;

    let initial_amount = 2 * usdc(10.0);
    let deposit_amount = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        global_config_bps_fee.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        global_config_lamports_fee.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_fee,
        ),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_fee,
        ),
    )
    .await;

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let net = deposit_amount - vault_lamports_fee;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        deposit_amount
            + shares_for_deposit(net, deposit_amount, deposit_amount, vault_lamports_fee),
        3
    );
    assert_eq!(
        balances_after_deposit.tokens["USDC"],
        initial_amount - 2 * deposit_amount
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_global_lamport_fee_used() {
    let global_config_lamports_fee: u64 = 1000;
    let global_config_bps_fee: u64 = 0;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let vault_lamports_fee = 500;
    let vault_bps_fee = 1;

    let initial_amount = 2 * usdc(10.0);
    let deposit_amount = usdc(10.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_fee,
        ),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_fee,
        ),
    )
    .await;
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        global_config_bps_fee.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        global_config_lamports_fee.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let net = deposit_amount - global_config_lamports_fee;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        deposit_amount
            + shares_for_deposit(
                net,
                deposit_amount,
                deposit_amount,
                global_config_lamports_fee
            ),
        3
    );
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_vault_bps_fee_used() {
    let global_config_lamports_fee: u64 = 100;
    let global_config_bps_fee: u64 = 1;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let vault_lamports_fee = 100;
    let vault_bps_fee = 1000;

    let initial_amount = 2 * usdc(10_000.0);
    let deposit_amount = usdc(10_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_fee,
        ),
    )
    .await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_fee,
        ),
    )
    .await;
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        global_config_bps_fee.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        global_config_lamports_fee.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well: the second deposit
    // mints `net * D / (D + fee)` rather than `net`.
    let fee = deposit_amount * vault_bps_fee / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        (deposit_amount - 1) + shares_for_deposit(net, vault_shares, vault_aum, fee),
        1
    );
    assert_eq!(
        balances_after_deposit.tokens["USDC"],
        initial_amount - 2 * deposit_amount
    );
}

#[tokio::test]
async fn test_global_config_fees_and_vault_config_fees_non_zero_global_bps_fee_used() {
    let global_config_lamports_penalty: u64 = 20;
    let global_config_bps_penalty: u64 = 100;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let vault_lamports_deposit_penalty = 50;
    let vault_bps_deposit_penalty = 99;

    let initial_amount = 2 * usdc(500.0);
    let deposit_amount = usdc(500.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        global_config_bps_penalty.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        global_config_lamports_penalty.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(
            vault.vault_tokens["USDC"].token_mint,
            vault_lamports_deposit_penalty,
        ),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            vault_bps_deposit_penalty,
        ),
    )
    .await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.shares, deposit_amount - 1);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    // Shares are priced against post-fee AUM (`m = net * supply / (aum + fee)`), so the
    // donated fee raises the price for the shares being minted as well.
    let fee = deposit_amount * global_config_bps_penalty / FULL_BPS as u64;
    let net = deposit_amount - fee;
    let vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    assert_fuzzy_eq!(
        balances_after_deposit.shares,
        (deposit_amount - 1) + shares_for_deposit(net, vault_shares, vault_aum, fee),
        1
    );
    assert_eq!(
        balances_after_deposit.tokens["USDC"],
        initial_amount - 2 * deposit_amount
    );
}

#[tokio::test]
async fn test_deposit_with_fee_prev_aum_is_updated_correctly_1() {
    let global_config_lamports_penalty: u64 = 5_000;
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let initial_amount = 2 * usdc(100.0);
    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // Track vault state to compute expected shares accounting for fee donation
    let mut vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    let mut vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let mut expected_user_shares = deposit_amount - 1;

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        global_config_lamports_penalty.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    let net_amount_to_deposit: u64 = 10;
    let amount_to_deposit = global_config_lamports_penalty + net_amount_to_deposit;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", amount_to_deposit).await;

    let shares_minted = vault_shares * net_amount_to_deposit / vault_aum;
    expected_user_shares += shares_minted;
    vault_aum += amount_to_deposit;
    vault_shares += shares_minted;

    let user_balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_fuzzy_eq!(user_balances_after_deposit.shares, expected_user_shares, 1);
    assert_eq!(
        user_balances_after_deposit.tokens["USDC"],
        initial_amount - deposit_amount - amount_to_deposit
    );

    // now deposit the remaining amount
    let deposit_amount = usdc(100.0) - amount_to_deposit;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - global_config_lamports_penalty;
    let shares_minted = (vault_shares as u128 * net as u128
        / (vault_aum + global_config_lamports_penalty) as u128) as u64;
    expected_user_shares += shares_minted;

    let user_balances_after_total_deposit = depositor.balances(&mut ctx).await;
    assert_fuzzy_eq!(
        user_balances_after_total_deposit.shares,
        expected_user_shares,
        2
    );
    assert_eq!(user_balances_after_total_deposit.tokens["USDC"], 0);
}

#[tokio::test]
async fn test_deposit_with_fee_prev_aum_is_updated_correctly_share_price_above_1() {
    let global_config_lamports_penalty: u64 = 7_000;
    let (mut ctx, vault, owner, _, _) =
        fixtures::setup_markets_and_reserves_with_yield_and_global_config(1, None).await;

    let initial_amount = 2 * usdc(100.0);
    let deposit_amount = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", initial_amount).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.tokens["USDC"], initial_amount);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // Track vault state to compute expected shares accounting for fee donation
    let mut vault_aum = INITIAL_DEPOSIT_SIZE + deposit_amount;
    let mut vault_shares = INITIAL_DEPOSIT_SIZE + deposit_amount - 1;
    let mut expected_user_shares = deposit_amount - 1;

    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    let inflation = deposit_amount + INITIAL_DEPOSIT_SIZE;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", inflation).await;
    vault_aum += inflation;

    client::update_global_config(
        &mut ctx,
        &pda::global_config(),
        UpdateGlobalConfigMode::MinDepositFeeLamports,
        global_config_lamports_penalty.try_to_vec().unwrap(),
        &owner,
    )
    .await
    .unwrap();
    let deposit_amount: u64 = 10_000;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - global_config_lamports_penalty;
    let shares_minted = (vault_shares as u128 * net as u128
        / (vault_aum + global_config_lamports_penalty) as u128) as u64;
    expected_user_shares += shares_minted;
    vault_aum += deposit_amount;
    vault_shares += shares_minted;

    // now deposit the remaining amount
    let deposit_amount = usdc(100.0) - deposit_amount;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    let net = deposit_amount - global_config_lamports_penalty;
    let shares_minted = (vault_shares as u128 * net as u128
        / (vault_aum + global_config_lamports_penalty) as u128) as u64;
    expected_user_shares += shares_minted;

    let user_balances_after_total_deposit = depositor.balances(&mut ctx).await;
    assert_fuzzy_eq!(
        user_balances_after_total_deposit.shares,
        expected_user_shares,
        2
    );
    assert_fuzzy_eq!(user_balances_after_total_deposit.tokens["USDC"], 0, 2);
}

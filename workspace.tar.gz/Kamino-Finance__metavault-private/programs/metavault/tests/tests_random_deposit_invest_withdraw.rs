#![allow(clippy::items_after_test_module)]

use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::{assert_fuzzy_eq, program_test::common::math::usdc_decimal_to_u64};
use metavault::{
    program_test::{client, fixtures, setup},
    utils::consts::INITIAL_DEPOSIT_SIZE,
};
use rand::Rng;
use solana_program_test::tokio;
use test_case::test_case;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_no_fees_mint_corectly_for_deposit_randomized_for_precision_loss() {
    let num_cases = 20;
    eprintln!("num tests: {num_cases}");
    for index in 0..num_cases {
        let mut rng = rand::thread_rng();

        let total = rng.gen_range(1..usdc(100_000_000.0));
        let first = rng.gen_range(1..total);
        let second = rng.gen_range(1..(total - first));
        eprintln!(
            "{} {}/{} test case: {},{},{},",
            chrono::offset::Utc::now(),
            index + 1,
            num_cases,
            total,
            first,
            second
        );

        test_no_interest_no_fees_mint_correctly_for_deposit_for_precision_loss(
            total, first, second,
        )
        .await;
    }
}

#[test_case(100, 33, 57)]
#[test_case(21437398, 9756764, 4473519)]
#[tokio::test]
async fn test_no_interest_no_fees_mint_correctly_for_deposit_for_precision_loss(
    total: u64,
    first: u64,
    second: u64,
) {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", total).await;
    let depositor_before = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_eq!(depositor_before.shares, 0);
    assert_eq!(depositor_before.tokens["USDC"], total);
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);

    // First deposit
    client::deposit(&mut ctx, &vault, &depositor, "USDC", first).await;

    let depositor_after = depositor.balances(&mut ctx).await;
    let vault_state_after = vault.state(&mut ctx).await;

    assert_eq!(depositor_after.tokens["USDC"], total - first);
    assert_fuzzy_eq!(depositor_after.shares, first, 1);
    assert_eq!(
        vault_state_after.vault_tokens[0].token_available,
        first + INITIAL_DEPOSIT_SIZE
    );
    assert_fuzzy_eq!(
        vault_state_after.shares_issued,
        first + INITIAL_DEPOSIT_SIZE,
        1
    );

    // Second deposit
    client::deposit(&mut ctx, &vault, &depositor, "USDC", second).await;

    let depositor_after = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(depositor_after.tokens["USDC"], total - first - second, 500);
    assert_fuzzy_eq!(depositor_after.shares, first + second, 500);
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        first + second + INITIAL_DEPOSIT_SIZE,
        500
    );

    // User withdraws the shares from the first deposit
    client::withdraw(&mut ctx, &vault, &depositor, first, "USDC").await;

    let depositor_state = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        second + INITIAL_DEPOSIT_SIZE,
        3
    );
    assert_fuzzy_eq!(
        depositor_state.tokens["USDC"],
        depositor_before.tokens["USDC"] - second,
        500
    );
    assert_fuzzy_eq!(depositor_state.shares, second, 500);
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        second + INITIAL_DEPOSIT_SIZE,
        500
    );

    // Withdraw all
    client::withdraw(&mut ctx, &vault, &depositor, second, "USDC").await;

    let depositor_state = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(depositor_state.tokens["USDC"], total, 4);
    assert_fuzzy_eq!(depositor_state.shares, 0, 4);

    assert_fuzzy_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE, 4);
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE,
        4
    );
}

#[test_case(100.0, 33.0, 10)]
#[test_case(8_000_000.0, 3_300_000.0, 10)]
#[test_case(50_000_000.0, 30_000.0, 20)]
#[test_case(1000.0, 40_000_000.0, 10)]
#[test_case(100.0, 33_000.0, 10)]
#[tokio::test]
async fn test_no_fees_mint_correctly_for_deposit_repeated_for_precision_loss(
    first_user_total: f64,
    second_user_total: f64,
    no_of_deposit_withdraw_loops: u64,
) {
    let first_user_total = usdc(first_user_total);
    let second_user_total = usdc(second_user_total);
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let first_depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", first_user_total).await;
    let second_depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", second_user_total).await;
    let first_depositor_before = first_depositor.balances(&mut ctx).await;
    let second_depositor_before = second_depositor.balances(&mut ctx).await;
    let vault_state_before = vault.state(&mut ctx).await;

    assert_eq!(first_depositor_before.shares, 0);
    assert_eq!(first_depositor_before.tokens["USDC"], first_user_total);
    assert_eq!(second_depositor_before.shares, 0);
    assert_eq!(second_depositor_before.tokens["USDC"], second_user_total);
    assert_eq!(
        vault_state_before.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state_before.shares_issued, INITIAL_DEPOSIT_SIZE);

    // First depositor deposits the whole amount
    client::deposit(&mut ctx, &vault, &first_depositor, "USDC", first_user_total).await;

    let first_depositor_after = first_depositor.balances(&mut ctx).await;
    let vault_state_after = vault.state(&mut ctx).await;

    assert_eq!(first_depositor_after.tokens["USDC"], 0);
    assert_fuzzy_eq!(first_depositor_after.shares, first_user_total, 1);
    assert_eq!(
        vault_state_after.vault_tokens[0].token_available,
        first_user_total + INITIAL_DEPOSIT_SIZE
    );
    assert_fuzzy_eq!(
        vault_state_after.shares_issued,
        first_user_total + INITIAL_DEPOSIT_SIZE,
        1
    );

    let mut current_second_user_total = second_user_total;
    let mut running_reward_sum = 0;
    // Second user does multiple deposits and withdraws of his whole amount as the time pass
    for _i in 0..no_of_deposit_withdraw_loops {
        // pass some time so there is some interest
        let mut rng = rand::thread_rng();
        let mins_to_pass = rng.gen_range(60..10 * 24 * 60);
        ctx.fast_forward_minutes(mins_to_pass).await;
        setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
        setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", current_second_user_total / 10)
            .await;
        running_reward_sum += current_second_user_total / 10;

        // assert that the user didn't lose too much from the initial amounts over the loops
        assert!(second_user_total - current_second_user_total < 20);
        let second_depositor_before_deposit = second_depositor.balances(&mut ctx).await;

        // Second depositor deposits the whole amount
        client::deposit(
            &mut ctx,
            &vault,
            &second_depositor,
            "USDC",
            current_second_user_total,
        )
        .await;

        let second_depositor_after_deposit = second_depositor.balances(&mut ctx).await;
        let vault_after = vault.balances(&mut ctx).await;

        let user_actual_deposit = second_depositor_before_deposit.tokens["USDC"]
            - second_depositor_after_deposit.tokens["USDC"];
        let actual_deposit =
            user_actual_deposit + first_user_total + running_reward_sum + INITIAL_DEPOSIT_SIZE;
        assert_fuzzy_eq!(vault_after.token_vaults["USDC"], actual_deposit, 20);
        assert!(vault_after.token_vaults["USDC"] >= actual_deposit); // the vault should have at least how many tokens were deposited by the user
        assert!(second_depositor_after_deposit.shares > 0);
        // asssert we get less shares than tokens (i.e. share price > 1)
        assert!(second_depositor_after_deposit.shares < current_second_user_total);

        // User withdraws the shares from the first deposit
        client::withdraw(
            &mut ctx,
            &vault,
            &second_depositor,
            second_depositor_after_deposit.shares,
            "USDC",
        )
        .await;

        let second_depositor_after_withdraw = second_depositor.balances(&mut ctx).await;
        let vault_after = vault.balances(&mut ctx).await;

        assert_fuzzy_eq!(
            second_depositor_after_withdraw.tokens["USDC"],
            second_user_total,
            20
        );
        assert!(second_depositor_after_withdraw.tokens["USDC"] <= second_user_total);
        assert_fuzzy_eq!(second_depositor_after_withdraw.shares, 0, 20);
        assert_fuzzy_eq!(
            vault_after.token_vaults["USDC"],
            first_user_total + running_reward_sum + INITIAL_DEPOSIT_SIZE,
            20
        );
        assert_fuzzy_eq!(vault_after.shares_supply, first_user_total, 20);

        current_second_user_total = second_depositor_after_withdraw.tokens["USDC"];
    }

    // First user withdraws all his shares and receives more tokens than he deposited
    client::withdraw(
        &mut ctx,
        &vault,
        &first_depositor,
        first_depositor_after.shares,
        "USDC",
    )
    .await;

    let first_depositor_after_withdraw = first_depositor.balances(&mut ctx).await;
    let vault_state_after = vault.state(&mut ctx).await;
    let vault_after = vault.balances(&mut ctx).await;

    // check that everything is withdrawn excepting bootstrap deposit and that vault has some yield on the initial deposit
    assert_eq!(vault_state_after.shares_issued, INITIAL_DEPOSIT_SIZE);
    assert!(vault_after.token_vaults["USDC"] > INITIAL_DEPOSIT_SIZE);

    // check that the user has no shares left and has more tokens than initially
    assert_fuzzy_eq!(first_depositor_after_withdraw.shares, 0, 2);
    assert!(first_depositor_after_withdraw.tokens["USDC"] > first_user_total);
}

#[test_case(100)]
#[test_case(200)]
#[test_case(300)]
#[tokio::test]
async fn test_realocation_no_interest_on_caps(total_amount: u64) {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", total_amount).await;

    let depositor_before = depositor.balances(&mut ctx).await;
    let vault_state_before = vault.state(&mut ctx).await;

    assert_eq!(depositor_before.shares, 0);
    assert_eq!(depositor_before.tokens["USDC"], total_amount);
    assert_eq!(
        vault_state_before.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state_before.shares_issued, INITIAL_DEPOSIT_SIZE);

    // First depositor deposits the whole amount
    client::deposit(&mut ctx, &vault, &depositor, "USDC", total_amount).await;

    let depositor_after = depositor.balances(&mut ctx).await;
    let vault_state_after = vault.state(&mut ctx).await;

    assert_eq!(depositor_after.tokens["USDC"], 0);
    assert_fuzzy_eq!(depositor_after.shares, total_amount, 1);
    assert_eq!(
        vault_state_after.vault_tokens[0].token_available,
        total_amount + INITIAL_DEPOSIT_SIZE
    );
    assert_fuzzy_eq!(
        vault_state_after.shares_issued,
        total_amount + INITIAL_DEPOSIT_SIZE,
        1
    );

    // the total tokens the user withdraw is equal to the total tokens deposited
    let depositor_balances_before_withdraw = depositor.balances(&mut ctx).await;

    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        depositor_balances_before_withdraw.shares,
        "USDC",
    )
    .await;

    let depositor_balances_after_withdraw = depositor.balances(&mut ctx).await;

    assert_eq!(
        depositor_balances_after_withdraw.tokens["USDC"],
        total_amount - 1
    );
    assert_fuzzy_eq!(depositor_balances_after_withdraw.shares, 1, 1);
}

#[tokio::test]
async fn test_random_realocation_no_interest_no_caps() {
    let num_cases = 20;
    eprintln!("num tests: {num_cases}");

    for index in 0..num_cases {
        let mut rng = rand::thread_rng();

        let total = rng.gen_range(1..usdc(100_000.0));
        eprintln!(
            "{} {}/{} test case: {}",
            chrono::offset::Utc::now(),
            index + 1,
            num_cases,
            total,
        );

        test_realocation_no_interest_on_caps(total).await;
    }
}

use ::metavault::program_test::VaultDepositorAccounts;
use anchor_lang::Id;
use anchor_spl::token::Token;
use kamino_lending::{
    assert_fuzzy_eq,
    fraction::Fraction,
    program_test::common::{
        math::{sol_decimal_to_u64, usdc_decimal_to_u64},
        setup::kp,
        token_operations,
        types::{MSpec, MarketsSpec, MintSpec, RSpec},
    },
    LendingError,
};
use metavault::program_test::fixtures::setup_markets;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, klend_error, setup,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, MAX_TOKENS_PER_VAULT, YEAR},
    KaminoVaultError,
};
use solana_program::pubkey::Pubkey;
use solana_program_test::tokio;
use solana_sdk::signer::Signer;
use usdc_decimal_to_u64 as usdc;

fn padded_vault_name(value: &str) -> [u8; 40] {
    let mut name = [0; 40];
    let bytes = value.as_bytes();
    let len = bytes.len().min(name.len());
    name[..len].copy_from_slice(&bytes[..len]);
    name
}

// Tests without fees:
// - [x] mint correctly for deposit
// - [x] mint correctly for deposit, repeatedly
// - [x] mint correctly for deposit, repeatedly with precision error, assert no loss
// - [x] mint correctly for deposit, repeatedly with precision error, assert loss is on user
// - [x] mint correctly for deposit, withdraw, randomized, loss is on user always
// - [x] burn correctly for withdraw
// - [x] burn correctly for deposit + withdraw repeatedly, assert pool no loss (user no gain)
// - [x] mint burn correctly deposit, withdraw (no interest)
// - [x] mint burn correctly deposit, withdraw with interest
// - mint burn  with socialized loss
// - [x] test with different decimals between token and shares see where precision loss is
// - [x] test that if we don't refresh reserve an user depositing gets more shares than he should

// Tests with mgmt fees:
// - [x] mint correctly for deposit
// - [x] burn correctly for withdraw
// - burn correctly for deposit + withdraw repeatedly, assert pool no loss (user no gain)
// - [x] mint burn correctly deposit, withdraw (no interest)
// - [x]  mint burn correctly deposit, withdraw with interest
// - mint burn  with socialized loss

// Tests with perf fees:
// - mint correctly for deposit
// - burn correctly for withdraw
// - burn correctly for deposit + withdraw repeatedly, assert pool no loss (user no gain)
// - mint burn correctly deposit, withdraw (no interest)
// - mint burn correctly deposit, withdraw with interest
// - mint burn  with socialized loss

// Tests with mgmt + perf fees:
// - [x] mint correctly for deposit
// - burn correctly for withdraw
// - burn correctly for deposit + withdraw repeatedly, assert pool no loss (user no gain)
// - mint burn correctly deposit, withdraw (no interest)
// - mint burn correctly deposit, withdraw with interest
// - mint burn  with socialized loss

// Tests for minting with partially unallocated funds, no yield
// - [x] deposit

// Tests  and allocations
// - [x] correctly proportionately
// - [x] change with all - ensure no loss of funds and allocates correctly
// - [x] random permutations of  values and weights
// - [x] un if allocation set to 0 but not deleted
// - [x] don't allow to delete allocation if still ed

// Tests withdraw
// - last withdrawal takes everything and all shares are closed
// - [x] test decimal precision where `1 bps` is less than how much user should get and rounds up

// Tests security:
// - allocation changed by admin only
// - all the other fields

#[tokio::test]
async fn test_vault_end_to_end() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(50.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after.tokens["USDC"],
        balances_before.tokens["USDC"] - deposit
    );
    assert_eq!(balances_after.shares, deposit - 1); // as it has 6 decimals, minus 1 due to vault-favorable floor rounding

    let withdraw = balances_after.shares;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_final = depositor.balances(&mut ctx).await;
    assert_eq!(balances_final.shares, 0);
    assert_eq!(balances_final.tokens["USDC"], usdc(100.0) - 1);
}

#[tokio::test]
async fn test_withdraw_partially() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let deposit = usdc(50.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    // Then deposit again
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, topup - 2);
    assert_eq!(balances_before.tokens["USDC"], 0);

    let withdraw = usdc(70.0);
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.shares, topup - 2 - withdraw);
    assert_eq!(balances_after.tokens["USDC"], withdraw + 1);
}

#[tokio::test]
async fn test_withdraw_all() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, topup - 1);
    assert_eq!(balances_before.tokens["USDC"], 0);

    // Withdraw all shares and because of no yield expect to get the same amount of tokens
    let withdraw = balances_before.shares;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.shares, 0);
    assert_eq!(balances_after.tokens["USDC"], topup - 1);
}

#[tokio::test]
async fn test_no_fees_mint_correctly_for_deposit_once() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let depositor_before = depositor.balances(&mut ctx).await;
    let vault_state_before = vault.state(&mut ctx).await;
    let _vault_balances_before = vault.balances(&mut ctx).await;

    assert_eq!(depositor_before.shares, 0);
    assert_eq!(depositor_before.tokens["USDC"], usdc(100.0));
    assert_eq!(
        vault_state_before.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state_before.shares_issued, INITIAL_DEPOSIT_SIZE);

    let deposit = usdc(50.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let depositor_after = depositor.balances(&mut ctx).await;
    let _vault_balances_after = vault.balances(&mut ctx).await;
    let vault_state_after = vault.state(&mut ctx).await;

    assert_eq!(
        depositor_after.tokens["USDC"],
        depositor_before.tokens["USDC"] - deposit
    );
    assert_eq!(depositor_after.shares, deposit - 1);
    assert_eq!(
        vault_state_after.vault_tokens[0].token_available,
        deposit + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(
        vault_state_after.shares_issued,
        deposit - 1 + INITIAL_DEPOSIT_SIZE
    );
}

#[tokio::test]
async fn test_no_fees_mint_correctly_for_deposit_repeatedly_exactly() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let depositor_before = depositor.balances(&mut ctx).await;
    let _vault_balances_before = vault.balances(&mut ctx).await;
    let vault_state_before = vault.state(&mut ctx).await;

    assert_eq!(depositor_before.shares, 0);
    assert_eq!(depositor_before.tokens["USDC"], usdc(100.0));
    assert_eq!(
        vault_state_before.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state_before.shares_issued, INITIAL_DEPOSIT_SIZE);

    let deposit = usdc(10.0);

    for i in 1..5 {
        client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

        let depositor_after = depositor.balances(&mut ctx).await;
        let vault_after = vault.state(&mut ctx).await;
        let _vault_balances_after = vault.balances(&mut ctx).await;

        assert_eq!(
            depositor_after.tokens["USDC"],
            depositor_before.tokens["USDC"] - deposit * i
        );
        assert_eq!(depositor_after.shares, (deposit - 1) * i);
        assert_eq!(
            vault_after.vault_tokens[0].token_available,
            deposit * i + INITIAL_DEPOSIT_SIZE
        );
        assert_eq!(
            vault_after.shares_issued,
            (deposit - 1) * i + INITIAL_DEPOSIT_SIZE
        );
    }
}

#[tokio::test]
async fn test_no_fees_deposit_withdraw_repeatedly_and_withdraw_fully() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(1000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let depositor_before = depositor.balances(&mut ctx).await;
    let vault_before = vault.state(&mut ctx).await;
    let _vault_balances_before = vault.balances(&mut ctx).await;

    assert_eq!(depositor_before.shares, 0);
    assert_eq!(depositor_before.tokens["USDC"], topup);
    assert_eq!(
        vault_before.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_before.shares_issued, INITIAL_DEPOSIT_SIZE);

    // do a few deposits and withdraws
    let deposits = [usdc(100.0), usdc(200.0), usdc(300.0), usdc(400.0)];
    let withdraws = [usdc(25.0), usdc(132.0), usdc(17.5), usdc(55.5)];
    let mut currently_deposited = INITIAL_DEPOSIT_SIZE;
    for (i, (deposit, withdraw)) in deposits.iter().zip(withdraws.iter()).enumerate() {
        client::deposit(&mut ctx, &vault, &depositor, "USDC", *deposit).await;
        client::withdraw(&mut ctx, &vault, &depositor, *withdraw, "USDC").await;
        currently_deposited += deposit;
        currently_deposited -= withdraw;

        let depositor_after = depositor.balances(&mut ctx).await;
        let vault_balances_after = vault.balances(&mut ctx).await;
        let vault_state_after = vault.state(&mut ctx).await;
        let token_max_diff = 3 * (i + 1);
        assert_fuzzy_eq!(
            depositor_after.tokens["USDC"],
            topup - (currently_deposited - INITIAL_DEPOSIT_SIZE),
            token_max_diff
        );
        let max_diff = 6 * (i + 1);
        assert_fuzzy_eq!(
            depositor_after.shares,
            (currently_deposited - INITIAL_DEPOSIT_SIZE),
            max_diff
        );
        assert!(
            depositor_after.shares
                <= vault_balances_after.token_vaults["USDC"] - INITIAL_DEPOSIT_SIZE
        ); // assert that all the time the depositor gets maximum the accurate amount but if there is a rounding he gets less
        assert_fuzzy_eq!(
            vault_balances_after.token_vaults["USDC"],
            currently_deposited,
            token_max_diff
        );
        assert_fuzzy_eq!(
            vault_state_after.shares_issued,
            currently_deposited,
            max_diff
        );
    }

    // withdraw the whole position
    let depositor_after = depositor.balances(&mut ctx).await;

    client::withdraw(&mut ctx, &vault, &depositor, depositor_after.shares, "USDC").await;
    let depositor_after = depositor.balances(&mut ctx).await;
    let vault_after = vault.state(&mut ctx).await;
    let _vault_balances_after = vault.balances(&mut ctx).await;

    assert_fuzzy_eq!(depositor_after.tokens["USDC"], topup, 10);
    assert_eq!(depositor_after.shares, 0);
    assert_fuzzy_eq!(
        vault_after.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE,
        10
    );
    assert_eq!(vault_after.shares_issued, INITIAL_DEPOSIT_SIZE);
}

#[tokio::test]
async fn test_user_gets_correct_shares_multiple_deposits() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(10_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    let deposits = [
        usdc(15.0),
        usdc(45.5),
        usdc(543.3),
        usdc(323.54854),
        usdc(72.65146),
    ];

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
    let mut currently_deposited = INITIAL_DEPOSIT_SIZE;
    let mut deposit_count: u64 = 0;
    for deposit in deposits.iter() {
        client::deposit(&mut ctx, &vault, &depositor, "USDC", *deposit).await;
        currently_deposited += deposit;
        deposit_count += 1;

        let depositor_after = depositor.balances(&mut ctx).await;
        let vault_balances_after = vault.balances(&mut ctx).await;
        let vault_state_after = vault.state(&mut ctx).await;
        let max_diff = deposit_count * (currently_deposited / 10_000_000 + 1);
        assert_fuzzy_eq!(
            depositor_after.tokens["USDC"],
            topup + INITIAL_DEPOSIT_SIZE - currently_deposited,
            max_diff
        );
        assert_fuzzy_eq!(
            depositor_after.shares,
            currently_deposited - INITIAL_DEPOSIT_SIZE,
            max_diff
        );
        assert!(
            depositor_after.shares
                <= vault_balances_after.token_vaults["USDC"] - INITIAL_DEPOSIT_SIZE
        ); // assert that all the time the depositor gets maximum the accurate amount but if there is a rounding he gets less
        assert_fuzzy_eq!(
            vault_state_after.vault_tokens[0].token_available,
            currently_deposited,
            max_diff
        );
        assert_fuzzy_eq!(
            vault_state_after.shares_issued,
            currently_deposited,
            max_diff
        );
    }
}

#[tokio::test]
async fn test_token_vault_mint_different_decimals_than_shares_mint() {
    // Vault initialized with USDC (6 decimals) so shares_mint has 6 decimals.
    // Then add SOL (9 decimals) as a second VaultToken and deposit/withdraw SOL.
    // Shares should differ from SOL deposit amount due to decimal mismatch.
    let (mut ctx, mut vault, owner, _investor, mkts) =
        fixtures::setup_markets_and_reserves(1).await;

    // Add SOL as a second vault token
    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["SOL"], sol_decimal_to_u64(100.0));

    let deposit = sol_decimal_to_u64(50.0);
    client::deposit(&mut ctx, &vault, &depositor, "SOL", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_fuzzy_eq!(
        balances_after.tokens["SOL"],
        balances_before.tokens["SOL"] - deposit,
        10
    );

    let withdraw = balances_after.shares;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "SOL").await;

    let balances_final = depositor.balances(&mut ctx).await;
    assert_eq!(balances_final.shares, 0);
    assert_fuzzy_eq!(balances_final.tokens["SOL"], sol_decimal_to_u64(100.0), 10);
}

#[tokio::test]
async fn test_user_can_withdraw_less_than_1_bps() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let deposit = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        topup + INITIAL_DEPOSIT_SIZE
    );

    // get user's balances and check everything is deposited
    let depositor_balances = depositor.balances(&mut ctx).await;
    assert_eq!(depositor_balances.shares, deposit - 1);
    assert_eq!(depositor_balances.tokens["USDC"], 0);

    // withdraw 0.5 BPS of the total shares so user has to receive 0.5 BPS of the total vault holding
    let shares_to_withdraw = deposit / 20_000;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that user has received 0.5 BPS of the total vault holding
    let depositor_balances = depositor.balances(&mut ctx).await;
    let remaining_shares = depositor_balances.shares;
    assert_fuzzy_eq!(
        depositor_balances.shares,
        deposit - 1 - shares_to_withdraw,
        2
    );
    assert_fuzzy_eq!(depositor_balances.tokens["USDC"], shares_to_withdraw, 2);

    // withdraw the rest and check that the user has received the rest of the shares
    client::withdraw(&mut ctx, &vault, &depositor, remaining_shares, "USDC").await;

    let depositor_balances = depositor.balances(&mut ctx).await;
    assert_eq!(depositor_balances.shares, 0);
    assert_fuzzy_eq!(depositor_balances.tokens["USDC"], deposit, 2);
}

#[tokio::test]
async fn test_give_up_fee() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // forward such as time * mgmt_fee_per_year > MAX_FEE (50%)
    ctx.fast_forward_seconds(u64::from(YEAR) * 12).await;

    // user try to withdraw but 50% is taken by admin
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    client::withdraw(&mut ctx, &vault, &depositor, deposit / 2, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    // User receives only half of what they were entitled at the time of deposit
    assert_fuzzy_eq!(balances_after.tokens["USDC"], deposit / 4, 2);
    assert_fuzzy_eq!(balances_after.shares, deposit / 2, 2);

    // the funds are still available in the vault but they belong to the vault owner
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit * 3 / 4 + INITIAL_DEPOSIT_SIZE,
        2
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        2 * (deposit + INITIAL_DEPOSIT_SIZE) - deposit / 2,
        2
    );
    // everything is pending fee but it is currently 0 in the state as they weren't updated since the time passed
    assert_eq!(
        Fraction::from_bits(vault_state.pending_fees_sf),
        Fraction::from_num(deposit - 1 + INITIAL_DEPOSIT_SIZE)
    );

    // owner gives up half of the pending fees
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::BlockDeposits(true),
    )
    .await;
    client::give_up_pending_fees(
        &mut ctx,
        &vault,
        &owner,
        (deposit - 1 + INITIAL_DEPOSIT_SIZE) / 2,
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        Fraction::from_bits(vault_state.pending_fees_sf),
        Fraction::from_num((deposit + INITIAL_DEPOSIT_SIZE) / 2)
    );
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit * 3 / 4 + INITIAL_DEPOSIT_SIZE,
        2
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        deposit + INITIAL_DEPOSIT_SIZE + INITIAL_DEPOSIT_SIZE / 2,
        2
    );

    // User can now withdraw the rest of the funds
    client::withdraw(&mut ctx, &vault, &depositor, deposit / 2, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    // User gets ~5/8 of deposit total (25 USDC from first withdrawal + ~37.5 USDC here)
    // because admin gave up half their fee shares, increasing user's proportional claim
    assert_fuzzy_eq!(balances_after.tokens["USDC"], 62_499_936, 100);
    assert_eq!(balances_after.shares, 0);

    assert_eq!(
        Fraction::from_bits(vault_state.pending_fees_sf),
        Fraction::from_num(deposit / 2 + INITIAL_DEPOSIT_SIZE / 2)
    );
    assert_fuzzy_eq!(vault_state.vault_tokens[0].token_available, 37_501_064, 100);
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        deposit / 2 + INITIAL_DEPOSIT_SIZE + INITIAL_DEPOSIT_SIZE / 2,
        2
    );
}

#[tokio::test]
async fn test_p2_04_vault_insert_same_mint_twice_bpf() {
    let (mut ctx, mut vault, owner, _investor, mkts) =
        fixtures::setup_markets_and_reserves(2).await;

    let vault_state = vault.state(&mut ctx).await;
    let allocations = vault_state.vault_tokens;
    assert_eq!(
        allocations[0].mint,
        mkts[0].usdc_reserve.liquidity_mint.pubkey()
    );

    let res = client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "USDC",
        mkts[0].usdc_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    // The token_vault PDA already exists and is owned by the SPL token program; klend's
    // `create_pda_account` helper (which metavault reuses) rejects with `InvalidAccountOwner`
    // because it requires the would-be-allocated account to still be system-owned.
    // If we move to init_if_needed we would expect `VaultTokenAlreadyExists` instead.
    assert_eq!(
        res.unwrap_err().unwrap(),
        klend_error(LendingError::InvalidAccountOwner, 1),
    );

    let vault_state_after = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state_after.get_tokens_count(),
        vault_state.get_tokens_count()
    );
    assert_eq!(vault_state_after.vault_tokens[0].mint, allocations[0].mint);
    assert_eq!(
        vault_state_after.vault_tokens[0].vault,
        allocations[0].vault
    );
    assert_eq!(
        vault_state_after.vault_tokens[0].decimals,
        allocations[0].decimals
    );
}

#[tokio::test]
async fn test_p2_04_add_vault_token_full_capacity_returns_space_exhausted_bpf() {
    let (mut ctx, mut vault, owner, _investor, mkts) =
        fixtures::setup_markets_and_reserves(1).await;
    let scope_feed = mkts[0].oracles.scope_prices;

    for token_index in 1..MAX_TOKENS_PER_VAULT {
        let mint = kp();
        token_operations::create_mint(&mut ctx, &mint, 6, &owner.pubkey(), &Token::id(), None)
            .await;
        client::add_vault_token(
            &mut ctx,
            &owner,
            &mut vault,
            &format!("TOKEN{token_index}"),
            mint.pubkey(),
            scope_feed,
        )
        .await;
    }

    let full_state = vault.state(&mut ctx).await;
    assert_eq!(full_state.get_tokens_count(), MAX_TOKENS_PER_VAULT);

    let overflow_mint = kp();
    token_operations::create_mint(
        &mut ctx,
        &overflow_mint,
        6,
        &owner.pubkey(),
        &Token::id(),
        None,
    )
    .await;

    let result = client::try_add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "OVERFLOW",
        overflow_mint.pubkey(),
        scope_feed,
    )
    .await;

    assert_eq!(
        result.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultTokensSpaceExhausted, 1)
    );
    assert!(!vault.vault_tokens.contains_key("OVERFLOW"));

    let after = vault.state(&mut ctx).await;
    assert_eq!(after.get_tokens_count(), MAX_TOKENS_PER_VAULT);
    assert!(after
        .get_vault_token_by_mint(&overflow_mint.pubkey())
        .is_err());
}

#[tokio::test]
async fn test_withdraw_0_shares_fails() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: [
            ("USDC".to_string(), MintSpec::spl(6, 1.0)),
            ("BTC".to_string(), MintSpec::spl(8, 50_000.0)),
        ]
        .into_iter()
        .collect(),
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("BTC", 0),
        ])],
    })
    .await;

    setup::update_scope_px_and_twap(&mut ctx, &vault, "BTC", 50_000.0, 50_000.0).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        [("USDC".to_string(), topup), ("BTC".to_string(), 0)]
            .into_iter()
            .collect(),
    )
    .await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // With BTC priced at $50k and 8 decimals, 1 BTC lamport is worth $0.0005.
    // A 1-share withdrawal from a ~$100 vault is worth much less than that, so it rounds to 0 lamports.

    let withdraw = 1;
    let res = client::try_withdraw(&mut ctx, &vault, &depositor, withdraw, "BTC", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::CannotWithdrawZeroLamports, 1)
    );
}

#[tokio::test]
async fn test_p2_04_update_vault_config_name_farm_lut_bpf() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    // check both default LUT and and farm pubkeys are default
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.name, padded_vault_name(""));
    assert_eq!(vault_state.vault_farm, Pubkey::default());
    assert_eq!(vault_state.vault_lookup_table, Pubkey::default());

    let name = "p2-04 regression vault";
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultName(name.to_string()),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.name, padded_vault_name(name));
    assert_eq!(vault_state.vault_lookup_table, Pubkey::default());
    assert_eq!(vault_state.vault_farm, Pubkey::default());

    let long_name = "0123456789012345678901234567890123456789extra";
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultName(long_name.to_string()),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.name, padded_vault_name(long_name));
    assert_eq!(vault_state.vault_lookup_table, Pubkey::default());
    assert_eq!(vault_state.vault_farm, Pubkey::default());

    let new_lut = Pubkey::new_unique();

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultLookupTable(new_lut),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_lookup_table, new_lut);
    assert_eq!(vault_state.vault_farm, Pubkey::default());

    let new_farm = Pubkey::new_unique();
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultFarm(new_farm),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.vault_lookup_table, new_lut);
    assert_eq!(vault_state.vault_farm, new_farm);
}

#[tokio::test]
async fn test_first_depositor_share_price_inflation() {
    let (mut ctx, vault, _owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_custom_yield(1, 20_000).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", topup).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // fast forward 3 years to get some significant yield
    ctx.fast_forward_seconds(6 * u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // withdraw everything but 1 lamport
    let withdraw = deposit - 2;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_withdraw.shares, 1);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE + 1);

    let second_deposit_topup = 59;
    let second_depositor =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", second_deposit_topup).await;

    client::deposit(
        &mut ctx,
        &vault,
        &second_depositor,
        "USDC",
        second_deposit_topup,
    )
    .await;
    let second_depositor_balances = second_depositor.balances(&mut ctx).await;
    assert_eq!(second_depositor_balances.tokens["USDC"], 0);

    // second user withdraws everything
    client::withdraw(
        &mut ctx,
        &vault,
        &second_depositor,
        second_deposit_topup,
        "USDC",
    )
    .await;

    let second_depositor_balances = second_depositor.balances(&mut ctx).await;
    assert_eq!(second_depositor_balances.shares, 0);
    assert_fuzzy_eq!(
        second_depositor_balances.tokens["USDC"],
        second_deposit_topup,
        2
    );
}

#[tokio::test]
async fn test_deposit_slippage_protection() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    let deposit = usdc(50.0);

    // Deposit with min_shares_out = 0 should succeed
    client::try_deposit(&mut ctx, &vault, &depositor, "USDC", deposit, 0)
        .await
        .unwrap();

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.shares, deposit - 1);

    // Deposit with min_shares_out set unreasonably high should fail
    let res = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", deposit, deposit + 1).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );

    // Deposit with min_shares_out equal to expected shares should succeed
    // At 1:1 price with same decimals, deposit amount ≈ shares (minus 1 from rounding)
    client::try_deposit(&mut ctx, &vault, &depositor, "USDC", deposit, deposit - 1)
        .await
        .unwrap();
}

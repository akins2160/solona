use kamino_lending::program_test::common::setup::kp;
use metavault::program_test::{client, client::UpdateVaultConfigParams, fixtures};
use metavault::{metavault_error, KaminoVaultError};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;

// Test cases:
// - [x] Wrong admin authority
// - [x] Wrong klend program
// - [x] Working case
// - [x] Allocation admin can update token weights
// - [x] Allocation admin cannot update any other field

#[tokio::test]
async fn test_security_update_vault_config() {
    let (mut ctx, vault, vault_manager, investor, _mkts) =
        fixtures::setup_markets_and_reserves(1).await;

    // Test cases:
    // - [] Wrong admin authority
    {
        let res = client::try_update_vault_config(
            &mut ctx,
            &investor.owner,
            &vault,
            UpdateVaultConfigParams::PendingVaultAdmin(kp().pubkey()),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
        );
    }

    // - [] Working case
    {
        client::try_update_vault_config(
            &mut ctx,
            &vault_manager,
            &vault,
            UpdateVaultConfigParams::PendingVaultAdmin(kp().pubkey()),
        )
        .await
        .unwrap();
    }
}

#[tokio::test]
async fn test_security_update_vault_config_allocation_admin() {
    let (mut ctx, vault, vault_manager, _investor, _mkts) =
        fixtures::setup_markets_and_reserves(1).await;

    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;

    // - [] Allocation admin has no access while unset
    {
        let res = client::try_update_vault_config(
            &mut ctx,
            &allocation_admin,
            &vault,
            UpdateVaultConfigParams::VaultTokenWeights(vec![7]),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
        );
    }

    client::update_vault_config(
        &mut ctx,
        &vault_manager,
        &vault,
        UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    // - [] Allocation admin can update token weights
    {
        client::try_update_vault_config(
            &mut ctx,
            &allocation_admin,
            &vault,
            UpdateVaultConfigParams::VaultTokenWeights(vec![7]),
        )
        .await
        .unwrap();
        assert_eq!(vault.state(&mut ctx).await.vault_tokens[0].weight, 7);
    }

    // - [] Allocation admin cannot update any other field (incl. its own authority)
    {
        let res = client::try_update_vault_config(
            &mut ctx,
            &allocation_admin,
            &vault,
            UpdateVaultConfigParams::AllocationAdminAuthority(kp().pubkey()),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
        );

        let res = client::try_update_vault_config(
            &mut ctx,
            &allocation_admin,
            &vault,
            UpdateVaultConfigParams::PendingVaultAdmin(kp().pubkey()),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
        );
    }
}

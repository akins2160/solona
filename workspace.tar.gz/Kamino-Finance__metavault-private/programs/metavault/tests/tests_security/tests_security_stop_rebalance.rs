use kamino_lending::program_test::common::{
    setup::funded_new_kp,
    types::{MSpec, MarketsSpec, MintSpec, RSpec},
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{
            deposit, start_rebalance, stop_rebalance, try_start_rebalance, try_stop_rebalance,
            try_update_vault_config, update_vault_config, UpdateVaultConfigParams,
        },
        fixtures::setup_markets_with_weights,
        VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program::{native_token::LAMPORTS_PER_SOL, pubkey::Pubkey};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;

// Test cases:
// - [x] Wrong admin authority

#[tokio::test]
async fn test_security_stop_rebalance() {
    let initial_weights = vec![3u64, 4u64];
    let (mut ctx, _, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 1_000_000).await;
    deposit(&mut ctx, &vault, &depositor, "USDC", 1_000_000).await;
    let investor = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);

    // Start rebalance as admin
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    // Test cases:
    // - Wrong admin authority - investor cannot stop
    {
        let res = try_stop_rebalance(&mut ctx, &investor, &vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect, 0)
        );
    }

    stop_rebalance(&mut ctx, &admin, &vault).await;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::AllocationAdminAuthority(investor.pubkey()),
    )
    .await;
    assert_eq!(
        vault.state(&mut ctx).await.allocation_admin_authority,
        investor.pubkey()
    );

    // The allocation admin cannot change vault configuration, including its own role.
    let res = try_update_vault_config(
        &mut ctx,
        &investor,
        &vault,
        UpdateVaultConfigParams::AllocationAdminAuthority(Pubkey::default()),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AdminAuthorityIncorrect, 1)
    );

    // Both authorities remain valid while the allocation role is set.
    start_rebalance(&mut ctx, &investor, &vault, 3600).await;
    stop_rebalance(&mut ctx, &admin, &vault).await;
    start_rebalance(&mut ctx, &admin, &vault, 3600).await;
    stop_rebalance(&mut ctx, &investor, &vault).await;

    // Clearing the role fails closed.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::AllocationAdminAuthority(Pubkey::default()),
    )
    .await;
    let res = try_start_rebalance(&mut ctx, &investor, &vault, 3600).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect)
    );
}

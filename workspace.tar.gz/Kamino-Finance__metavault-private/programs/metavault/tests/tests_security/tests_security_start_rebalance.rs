use metavault::{
    metavault_error,
    program_test::{client::try_start_rebalance, fixtures},
    KaminoVaultError,
};
use solana_program_test::tokio;

// Test cases:
// - [x] Wrong admin authority

#[tokio::test]
async fn test_security_start_rebalance() {
    let (mut ctx, vault, _, investor, _) = fixtures::setup_markets_and_reserves(1).await;

    // Test cases:
    // - [x] Wrong admin authority
    {
        let res = try_start_rebalance(&mut ctx, &investor.owner, &vault, 100).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect, 0)
        );
    }
}

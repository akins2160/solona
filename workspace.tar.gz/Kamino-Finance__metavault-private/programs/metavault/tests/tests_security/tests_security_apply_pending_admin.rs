use anchor_lang::error::ErrorCode;
use kamino_lending::{anchor_error, program_test::common::math::usdc_decimal_to_u64 as usdc};
use metavault::program_test::{
    client::{self, UpdateVaultConfigParams},
    fixtures, VaultDepositorAccounts,
};
use solana_program_test::tokio;
use solana_sdk::{pubkey::Pubkey, signer::Signer};

// Test cases:
// - [x] Wrong new admin
// - [x] Working case

#[tokio::test]
async fn test_security_apply_pending_admin() {
    let (mut ctx, vault, owner, investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    // - [x] Wrong new admin
    {
        client::try_update_vault_config(
            &mut ctx,
            &owner,
            &vault,
            UpdateVaultConfigParams::PendingVaultAdmin(investor.owner.pubkey()),
        )
        .await
        .unwrap();

        let res = client::try_apply_pending_admin(
            &mut ctx,
            &vault.vault_state.pubkey(),
            &depositor.owner,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne)
        );
    }

    // - [x] Working case
    {
        client::try_update_vault_config(
            &mut ctx,
            &owner,
            &vault,
            UpdateVaultConfigParams::AllocationAdminAuthority(depositor.owner.pubkey()),
        )
        .await
        .unwrap();
        client::try_update_vault_config(
            &mut ctx,
            &owner,
            &vault,
            UpdateVaultConfigParams::PendingVaultAdmin(investor.owner.pubkey()),
        )
        .await
        .unwrap();

        client::try_apply_pending_admin(&mut ctx, &vault.vault_state.pubkey(), &investor.owner)
            .await
            .unwrap();

        let state = vault.state(&mut ctx).await;
        assert_eq!(state.vault_admin_authority, investor.owner.pubkey());
        assert_eq!(state.allocation_admin_authority, Pubkey::default());
    }
}

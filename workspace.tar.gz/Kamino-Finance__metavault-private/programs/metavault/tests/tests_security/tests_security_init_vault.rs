use anchor_lang::error::ErrorCode;
use anchor_lang::Id;
use anchor_spl::token::Token;
use kamino_lending::anchor_error;
use metavault::{
    metavault_error,
    program_test::{client, fixtures, token_acl, VaultAccounts},
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::pubkey::Pubkey;

// Test cases:
// - [x] Wrong token vault
// - [x] Wrong base vault authority
// - [x] Wrong shares mint
// - [x] Working case

#[tokio::test]
async fn test_security_init_vault() {
    // - [ ] Working case
    {
        let (_ctx, _vault, _owner, _investor, _) = fixtures::setup_markets_and_reserves(1).await;
    }

    // - [] Wrong token vault
    {
        let (mut ctx, vault, _owner, _investor, mkt) =
            fixtures::setup_markets_and_reserves(1).await;
        let vault = VaultAccounts::new(
            &vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &Token::id(),
            mkt[0].oracles.scope_prices,
        );

        let wrong_token_vault = Pubkey::new_unique();
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_vault = wrong_token_vault;

        let res = client::init_vault(&mut ctx, &wrong_vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [] Wrong base vault authority
    {
        let (mut ctx, vault, _owner, _investor, mkt) =
            fixtures::setup_markets_and_reserves(1).await;
        let vault = VaultAccounts::new(
            &vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &Token::id(),
            mkt[0].oracles.scope_prices,
        );

        let wrong_base_vault_authority = Pubkey::new_unique();
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_base_vault_authority;

        let res = client::init_vault(&mut ctx, &wrong_vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [] Wrong shares mint
    {
        let (mut ctx, vault, _owner, _investor, mkt) =
            fixtures::setup_markets_and_reserves(1).await;
        let vault = VaultAccounts::new(
            &vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &Token::id(),
            mkt[0].oracles.scope_prices,
        );

        let wrong_shares_mint = Pubkey::new_unique();
        let mut wrong_vault = vault.clone();
        wrong_vault.shares_mint = wrong_shares_mint;

        let res = client::init_vault(&mut ctx, &wrong_vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }
}

// Permissioned-path setup invariants: every check fires in the handler before any
// token-acl CPI, so no gate fixtures are needed.
#[tokio::test]
async fn test_security_init_vault_permissioned() {
    // - [] Forged mint config account (not the PDA of the shares mint)
    {
        let (mut ctx, vault, _owner, _investor, mkt) =
            fixtures::setup_markets_and_reserves(1).await;
        let mut wrong_vault = VaultAccounts::new(
            &vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &vault.vault_tokens["USDC"].token_program,
            mkt[0].oracles.scope_prices,
        )
        .permissioned(token_acl::ALWAYS_ALLOW_GATE_ID);
        wrong_vault.shares_mint_config = Pubkey::new_unique();

        let res = client::init_vault(&mut ctx, &wrong_vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 1)
        );
    }

    // - [] Default gating program
    {
        let (mut ctx, vault, _owner, _investor, mkt) =
            fixtures::setup_markets_and_reserves(1).await;
        let wrong_vault = VaultAccounts::new(
            &vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &vault.vault_tokens["USDC"].token_program,
            mkt[0].oracles.scope_prices,
        )
        .permissioned(Pubkey::default());

        let res = client::init_vault(&mut ctx, &wrong_vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::SharesGatingProgramInvalid, 1)
        );
    }

    // - [] Wrong token ACL program account
    {
        let (mut ctx, vault, _owner, _investor, mkt) =
            fixtures::setup_markets_and_reserves(1).await;
        let mut wrong_vault = VaultAccounts::new(
            &vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &vault.vault_tokens["USDC"].token_program,
            mkt[0].oracles.scope_prices,
        )
        .permissioned(token_acl::ALWAYS_ALLOW_GATE_ID);
        wrong_vault.token_acl_program = Pubkey::new_unique();

        let res = client::init_vault(&mut ctx, &wrong_vault).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::TokenAclProgramIncorrect, 1)
        );
    }
}

#[tokio::test]
async fn test_permissioned_init_rejects_each_missing_optional_acl_account() {
    for (case, include_mint_config, include_token_acl_program) in [
        ("mint config", false, true),
        ("token ACL program", true, false),
        ("both ACL accounts", false, false),
    ] {
        let (mut ctx, existing_vault, _owner, _investor, markets) =
            fixtures::setup_markets_and_reserves(1).await;
        let vault = VaultAccounts::new(
            &existing_vault.vault_tokens["USDC"].token_mint,
            "USDC",
            &existing_vault.vault_tokens["USDC"].token_program,
            markets[0].oracles.scope_prices,
        )
        .permissioned(token_acl::ALWAYS_ALLOW_GATE_ID);

        let result = client::init_vault_with_acl_accounts(
            &mut ctx,
            &vault,
            include_mint_config.then_some(vault.shares_mint_config),
            include_token_acl_program.then_some(vault.token_acl_program),
        )
        .await;
        assert_eq!(
            result.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::SharesGatingProgramInvalid, 1),
            "omitting {case} must fail cleanly"
        );
    }
}

use kamino_lending::send_transaction;
use metavault::program_test::{
    client::get_ordered_scope_and_obligation_accounts,
    fixtures::{setup_markets_and_reserves_with_dependencies, ProgramDependency},
    instructions,
    test_cpi_caller::TEST_CPI_CALLER_ID,
};
use solana_program_test::tokio;
use solana_sdk::instruction::{AccountMeta, Instruction};

fn forward_cpi_ix(inner_ix: Instruction) -> Instruction {
    let mut accounts = Vec::with_capacity(inner_ix.accounts.len() + 1);
    accounts.push(AccountMeta::new_readonly(metavault::ID, false));
    accounts.extend(inner_ix.accounts);

    let mut data = Vec::with_capacity(inner_ix.data.len() + 1);
    data.push(0);
    data.extend(inner_ix.data);

    Instruction {
        program_id: TEST_CPI_CALLER_ID,
        accounts,
        data,
    }
}

#[tokio::test]
async fn test_security_readonly_instructions_are_cpi_callable() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves_with_dependencies(
        1,
        Some(vec![ProgramDependency::TestCpiCaller]),
        None,
    )
    .await;

    let accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let aum_ix = instructions::aum_ix(metavault::ID, &vault, accounts);
    let tx = ctx
        .create_transaction_with_payer([forward_cpi_ix(aum_ix)], &owner)
        .await;
    send_transaction!(ctx, tx).unwrap();

    let accounts = get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let exchange_rate_ix = instructions::exchange_rate_ix(
        metavault::ID,
        &vault,
        vault.vault_tokens["USDC"].token_mint,
        accounts,
    );
    let tx = ctx
        .create_transaction_with_payer([forward_cpi_ix(exchange_rate_ix)], &owner)
        .await;
    send_transaction!(ctx, tx).unwrap();
}

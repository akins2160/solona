use anchor_lang::error::ErrorCode;
use kamino_lending::{anchor_error, program_test::common::setup::funded_new_kp};
use metavault::{
    metavault_error,
    program_test::{client, fixtures, fixtures::ProgramDependency, token_acl},
    KaminoVaultError,
};
use solana_program::native_token::LAMPORTS_PER_SOL;
use solana_program_test::tokio;
use solana_sdk::{account::AccountSharedData, pubkey::Pubkey};

#[tokio::test]
async fn test_security_shares_metadata() {
    // - [] Wrong admin signer (initialize + update)
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves(1).await;
        let outsider = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);

        let res = client::init_shares_metadata(
            &mut ctx,
            &outsider,
            &vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne)
        );

        client::init_shares_metadata(
            &mut ctx,
            &owner,
            &vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await
        .unwrap();

        let res = client::update_shares_metadata(
            &mut ctx,
            &outsider,
            &vault,
            "n2".to_string(),
            "s2".to_string(),
            "u2".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne)
        );
    }

    // - [] Permissioned vault without its mint config account
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.gating_program = None; // builder omits the optional mint config

        let res = client::init_shares_metadata(
            &mut ctx,
            &owner,
            &wrong_vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::SharesGatingProgramInvalid, 0)
        );
    }

    // - [] Permissioned vault with a forged mint config account
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.shares_mint_config = Pubkey::new_unique();

        let res = client::init_shares_metadata(
            &mut ctx,
            &owner,
            &wrong_vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 0)
        );
    }

    // - [] Account at the correct MintConfig PDA but owned by a foreign program
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let forged = AccountSharedData::new(
            LAMPORTS_PER_SOL,
            token_acl::MintConfig::LEN,
            &Pubkey::new_unique(),
        );
        ctx.set_account(&vault.shares_mint_config, forged);

        let res = client::init_shares_metadata(
            &mut ctx,
            &owner,
            &vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 0)
        );
    }

    // - [] Malformed MintConfig data (right PDA and owner, zeroed discriminator)
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let malformed = AccountSharedData::new(
            LAMPORTS_PER_SOL,
            token_acl::MintConfig::LEN,
            &token_acl::TOKEN_ACL_ID,
        );
        ctx.set_account(&vault.shares_mint_config, malformed);

        let res = client::init_shares_metadata(
            &mut ctx,
            &owner,
            &vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 0)
        );
    }

    // - [] Open vault must not accept a mint config account
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves(1).await;
        let mut wrong_vault = vault.clone();
        // Makes the builder attach the (nonexistent) mint config to an open vault.
        wrong_vault.gating_program = Some(token_acl::ALWAYS_ALLOW_GATE_ID);

        let res = client::init_shares_metadata(
            &mut ctx,
            &owner,
            &wrong_vault,
            "n".to_string(),
            "s".to_string(),
            "u".to_string(),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 0)
        );
    }
}

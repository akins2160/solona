use anchor_lang::error::ErrorCode;
use borsh::BorshSerialize;
use kamino_lending::{anchor_error, program_test::common::setup::funded_new_kp};
use metavault::program_test::{client, fixtures};
use metavault::utils::{global_config::UpdateGlobalConfigMode, pda};
use solana_program_test::tokio;
use solana_sdk::{native_token::LAMPORTS_PER_SOL, signer::Signer};

// Test cases:
// - [x] Wrong pending admin (ConstraintHasOne)
// - [x] Working case (matching pending admin)

#[tokio::test]
async fn test_security_update_global_config_admin_wrong_pending() {
    let (mut ctx, _vault, owner, investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let global_config = pda::global_config();

    // Set pending to investor
    let mut pubkey_bytes = Vec::new();
    investor
        .owner
        .pubkey()
        .serialize(&mut pubkey_bytes)
        .unwrap();
    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::PendingAdmin,
        pubkey_bytes,
        &owner,
    )
    .await
    .unwrap();

    // Attempt apply with wrong signer
    let not_pending = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let res = client::update_global_config_admin(&mut ctx, &global_config, &not_pending).await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        anchor_error!(ErrorCode::ConstraintHasOne)
    );
}

#[tokio::test]
async fn test_security_update_global_config_admin_correct_pending() {
    let (mut ctx, _vault, owner, investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let global_config = pda::global_config();

    // Set pending to investor
    let mut pubkey_bytes = Vec::new();
    investor
        .owner
        .pubkey()
        .serialize(&mut pubkey_bytes)
        .unwrap();
    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::PendingAdmin,
        pubkey_bytes,
        &owner,
    )
    .await
    .unwrap();

    // Apply with matching pending admin
    client::update_global_config_admin(&mut ctx, &global_config, &investor.owner)
        .await
        .unwrap();
}

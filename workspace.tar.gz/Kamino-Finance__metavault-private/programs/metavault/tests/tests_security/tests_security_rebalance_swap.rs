use anchor_lang::{error::ErrorCode, Id};
use anchor_spl::token_2022::Token2022;
use kamino_lending::{
    anchor_error,
    program_test::common::{
        setup::kp,
        types::{MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    },
    send_transaction,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{
            deposit, get_ordered_scope_accounts, open_deposit_order, open_withdraw_order,
            start_rebalance, token_holder, try_rebalance_swap, try_rebalance_swap_with_krfq,
            try_rebalance_swap_with_krfq_marker, update_vault_config, usdc_holder, KrfqMarker,
            RequestedOut, UpdateVaultConfigParams,
        },
        fixtures::{self, set_global_config, setup_markets_with_weights},
        instructions, VaultAccounts, VaultDepositorAccounts,
    },
    utils::{consts::INITIAL_DEPOSIT_SIZE, pda},
    GlobalConfig, KaminoVaultError, VaultConfigField,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{pubkey::Pubkey, signer::Signer};

const USDC: u64 = 1_000_000;
const SOL: u64 = 1_000_000_000;
const SHARE: u64 = 1_000_000;
const HOUR: u64 = 3600;

// Test cases:
// - [x] Wrong base vault authority
// - [x] Wrong token in vault
// - [x] Wrong token out vault
// - [x] Wrong user token in ata (mint)
// - [x] Wrong user token in ata (owner)
// - [x] Wrong user token out ata (mint)
// - [x] Wrong user token out ata (owner)
// - [x] Wrong token in program
// - [x] Wrong token out program
// - [x] Wrong scope feed
// - [x] Working case (permissionless)
// - [x] Configured swap authority
// Order accounts:
// - [x] Deposit order of another vault
// - [x] Withdraw order of another vault
// - [x] Withdraw order in the deposit order slot
// - [x] Deposit order in the withdraw order slot
// - [x] Non-order account in an order slot
// - [x] Working case (deposit order fill)

#[tokio::test]
async fn test_security_rebalance_swap() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let second_swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swap_amount = 1_000_000_000u64;

    // Wrong base vault authority
    {
        let wrong_base_vault_authority = ctx.new_keypair(u32::MAX.into()).await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_base_vault_authority.pubkey();
        let res = try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &wrong_vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // Wrong token in vault
    {
        let wrong_token_vault = Pubkey::new_unique();
        ctx.clone_account(vault.vault_tokens["SOL"].token_vault, &wrong_token_vault)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.vault_tokens.get_mut("SOL").unwrap().token_vault = wrong_token_vault;
        let res = try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &wrong_vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // Wrong token out vault
    {
        let wrong_token_vault = Pubkey::new_unique();
        ctx.clone_account(vault.vault_tokens["USDC"].token_vault, &wrong_token_vault)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_vault = wrong_token_vault;
        let res = try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &wrong_vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // Wrong user token in ata (mint)
    {
        let token_in = &vault.vault_tokens["SOL"];
        let token_out = &vault.vault_tokens["USDC"];
        let scope_accounts: Vec<_> = vault.scope_prices.values().map(|s| s.scope_feed).collect();

        let tx = instructions::rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &vault,
            &swapper.token_atas["USDC"], // Wrong: USDC ata instead of SOL ata
            &swapper.token_atas["USDC"],
            token_in,
            token_out,
            swap_amount,
            0,
            scope_accounts,
            None,
            pda::global_config(),
            None,
            None,
            None,
        )
        .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 1)
        );
    }

    // Wrong user token in ata (owner)
    {
        let token_in = &vault.vault_tokens["SOL"];
        let token_out = &vault.vault_tokens["USDC"];
        let scope_accounts: Vec<_> = vault.scope_prices.values().map(|s| s.scope_feed).collect();

        let tx = instructions::rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &vault,
            &second_swapper.token_atas["SOL"], // Wrong: second_swapper's SOL ata
            &swapper.token_atas["USDC"],
            token_in,
            token_out,
            swap_amount,
            0,
            scope_accounts,
            None,
            pda::global_config(),
            None,
            None,
            None,
        )
        .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
        );
    }

    // Wrong user token out ata (mint)
    {
        let token_in = &vault.vault_tokens["SOL"];
        let token_out = &vault.vault_tokens["USDC"];
        let scope_accounts: Vec<_> = vault.scope_prices.values().map(|s| s.scope_feed).collect();

        let tx = instructions::rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &vault,
            &swapper.token_atas["SOL"],
            &swapper.token_atas["SOL"], // Wrong: SOL ata instead of USDC ata
            token_in,
            token_out,
            swap_amount,
            0,
            scope_accounts,
            None,
            pda::global_config(),
            None,
            None,
            None,
        )
        .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 1)
        );
    }

    // Wrong user token out ata (owner)
    {
        let token_in = &vault.vault_tokens["SOL"];
        let token_out = &vault.vault_tokens["USDC"];
        let scope_accounts: Vec<_> = vault.scope_prices.values().map(|s| s.scope_feed).collect();

        let tx = instructions::rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &vault,
            &swapper.token_atas["SOL"],
            &second_swapper.token_atas["USDC"], // Wrong: second_swapper's USDC ata
            token_in,
            token_out,
            swap_amount,
            0,
            scope_accounts,
            None,
            pda::global_config(),
            None,
            None,
            None,
        )
        .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
        );
    }

    // Wrong token in program
    {
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("SOL")
            .unwrap()
            .token_program = Token2022::id();
        let res = try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &wrong_vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintMintTokenProgram, 1)
        );
    }

    // Wrong token out program
    {
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_program = Token2022::id();
        let res = try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &wrong_vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintMintTokenProgram, 1)
        );
    }

    // Wrong scope feed
    {
        let mut wrong_vault = vault.clone();
        wrong_vault
            .scope_prices
            .get_mut(&vault.vault_tokens["SOL"].token_mint)
            .unwrap()
            .scope_feed = kp().pubkey();
        let res = try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &wrong_vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidScopePriceAccount, 1)
        );
    }

    // Working case - permissionless (anyone can call)
    {
        try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await
        .unwrap();
    }

    // Configured swap authority: only the configured signer can swap.
    {
        update_vault_config(
            &mut ctx,
            &admin,
            &vault,
            UpdateVaultConfigParams::SwapAuthority(swapper.owner.pubkey()),
        )
        .await;
        let vault_state = vault.state(&mut ctx).await;
        assert_eq!(vault_state.swap_authority, swapper.owner.pubkey());

        let res = try_rebalance_swap(
            &mut ctx,
            &second_swapper.owner,
            &vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::SwapAuthorityIncorrect, 1)
        );

        try_rebalance_swap(
            &mut ctx,
            &swapper.owner,
            &vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await
        .unwrap();
    }

    // Clearing the authority restores permissionless swaps.
    {
        update_vault_config(
            &mut ctx,
            &admin,
            &vault,
            UpdateVaultConfigParams::SwapAuthority(Pubkey::default()),
        )
        .await;
        let vault_state = vault.state(&mut ctx).await;
        assert_eq!(vault_state.swap_authority, Pubkey::default());

        try_rebalance_swap(
            &mut ctx,
            &second_swapper.owner,
            &vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
        )
        .await
        .unwrap();
    }
}

#[tokio::test]
async fn test_security_rebalance_swap_krfq_gate() {
    let initial_weights = vec![5u64, 5u64];
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        initial_weights.clone(),
    )
    .await;

    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 2_000_000_000).await;
    deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        1_000_000_000 - INITIAL_DEPOSIT_SIZE,
    )
    .await;

    start_rebalance(&mut ctx, &admin, &vault, 3600).await;

    let swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;
    let second_swapper = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 0
        },
    )
    .await;

    let swap_amount = 1_000_000_000; // 1 SOL
    let krfq_server = kp();
    let global_config = pda::global_config();

    // Enable the gate on the vault.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::KrfqEnabled(true),
    )
    .await;
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.krfq_enabled, 1);

    // Gate on, global krfq key unset: fails closed even with a would-be server co-signing.
    let res = try_rebalance_swap_with_krfq(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&krfq_server),
        global_config,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqSwapAuthorityNotSet, 1)
    );

    // Set the global krfq swap authority (directly: this fixture leaves global_admin
    // unset, see the note above; the update instruction is covered in tests_global_config).
    set_global_config(
        &mut ctx,
        &GlobalConfig {
            krfq_swap_authority: krfq_server.pubkey(),
            ..Default::default()
        },
    );

    // Global config present but no krfq signer: rejected.
    let res = try_rebalance_swap_with_krfq(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        None,
        global_config,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqAuthorityMissing, 1)
    );

    // Wrong co-signer: rejected.
    let wrong_server = kp();
    let res = try_rebalance_swap_with_krfq(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&wrong_server),
        global_config,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqAuthorityIncorrect, 1)
    );

    // Correct co-signer: the swap goes through.
    try_rebalance_swap_with_krfq(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&krfq_server),
        global_config,
    )
    .await
    .unwrap();

    // Omitting the marker: a co-signature with nothing binding it to a fill is refused.
    let res = try_rebalance_swap_with_krfq_marker(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&krfq_server),
        global_config,
        KrfqMarker::Omitted,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqFillMarkerMissing, 1)
    );

    // A marker for another fill: this is the attack the derivation exists to stop.
    // krfq compares the marker against the opportunity it ranked, so a maker carrying
    // the marker of an authorized fill while naming different accounts here would get a
    // co-signature for a fill krfq never authorized. Deriving from the accounts actually
    // used is what refuses it.
    for wrong in [
        // Right mint pair, wrong vault.
        pda::krfq_fill_marker(
            &Pubkey::new_unique(),
            &vault.vault_tokens["SOL"].token_mint,
            &vault.vault_tokens["USDC"].token_mint,
        ),
        // Right vault, mint pair reversed — the opposite direction is a different fill.
        pda::krfq_fill_marker(
            &vault.vault_state.pubkey(),
            &vault.vault_tokens["USDC"].token_mint,
            &vault.vault_tokens["SOL"].token_mint,
        ),
        // Not a marker at all.
        Pubkey::new_unique(),
    ] {
        let res = try_rebalance_swap_with_krfq_marker(
            &mut ctx,
            &swapper.owner,
            &vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
            Some(&krfq_server),
            global_config,
            KrfqMarker::Wrong(wrong),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::KrfqFillMarkerIncorrect, 1),
            "marker {wrong} must not authorize this fill"
        );
    }

    // Composes with swap_authority: the user check still runs first.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::SwapAuthority(swapper.owner.pubkey()),
    )
    .await;
    let res = try_rebalance_swap_with_krfq(
        &mut ctx,
        &second_swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&krfq_server),
        global_config,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SwapAuthorityIncorrect, 1)
    );
    try_rebalance_swap_with_krfq(
        &mut ctx,
        &swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&krfq_server),
        global_config,
    )
    .await
    .unwrap();

    // Gate off again: stray gate accounts are ignored and permissionless swaps return.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::KrfqEnabled(false),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::SwapAuthority(Pubkey::default()),
    )
    .await;
    try_rebalance_swap_with_krfq(
        &mut ctx,
        &second_swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        Some(&wrong_server),
        global_config,
    )
    .await
    .unwrap();
    try_rebalance_swap(
        &mut ctx,
        &second_swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
    )
    .await
    .unwrap();

    // Gate off, marker for another fill: still refused. The derivation is not
    // part of the gate flag. krfq binds its record of *which* fill it co-signed
    // to this address, so an ungated fill carrying a gated vault's marker would
    // let krfq settle that vault's auction — retiring its keeper's request — on
    // a fill that never touched it. Enforcing only for gated vaults left the
    // forgery open one step to the side.
    for wrong in [
        pda::krfq_fill_marker(
            &Pubkey::new_unique(),
            &vault.vault_tokens["SOL"].token_mint,
            &vault.vault_tokens["USDC"].token_mint,
        ),
        Pubkey::new_unique(),
    ] {
        let res = try_rebalance_swap_with_krfq_marker(
            &mut ctx,
            &second_swapper.owner,
            &vault,
            "SOL",
            "USDC",
            swap_amount,
            RequestedOut::AtCurve,
            None,
            global_config,
            KrfqMarker::Wrong(wrong),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::KrfqFillMarkerIncorrect, 1),
            "an ungated fill must not carry another fill's marker ({wrong})"
        );
    }

    // Gate off with this fill's own marker still passes: the check is on the
    // derivation, never on the marker's presence.
    try_rebalance_swap_with_krfq_marker(
        &mut ctx,
        &second_swapper.owner,
        &vault,
        "SOL",
        "USDC",
        swap_amount,
        RequestedOut::AtCurve,
        None,
        global_config,
        KrfqMarker::Derived,
    )
    .await
    .unwrap();

    // The flag only accepts 0 or 1.
    let tx = instructions::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        VaultConfigField::KrfqEnabled,
        vec![2],
        vec![],
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidFlagValue, 1)
    );
}

#[tokio::test]
async fn test_security_rebalance_swap_order_accounts() {
    let (mut ctx, vault, lp) = fixtures::setup_balanced_vault(vec![
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderFillEnabled(true),
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(true),
        UpdateVaultConfigParams::WithdrawOrderFillEnabled(true),
    ])
    .await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let deposit_order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 100 * USDC)],
        HOUR,
    )
    .await;
    let withdraw_order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 100 * SHARE, &[("USDC", 1)], HOUR).await;
    let solver = token_holder(&mut ctx, &vault, 0, 10 * SOL).await;

    // - [x] Deposit order of another vault
    {
        let foreign = claiming_another_vault(&mut ctx, deposit_order).await;
        let res = try_fill_order(&mut ctx, &solver, &vault, Some(foreign), None).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Withdraw order of another vault
    {
        let foreign = claiming_another_vault(&mut ctx, withdraw_order).await;
        let res = try_fill_order(&mut ctx, &solver, &vault, None, Some(foreign)).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Withdraw order in the deposit order slot
    {
        let res = try_fill_order(&mut ctx, &solver, &vault, Some(withdraw_order), None).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::AccountDiscriminatorMismatch, 1)
        );
    }

    // - [x] Deposit order in the withdraw order slot
    {
        let res = try_fill_order(&mut ctx, &solver, &vault, None, Some(deposit_order)).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::AccountDiscriminatorMismatch, 1)
        );
    }

    // - [x] Non-order account in an order slot
    {
        let token_vault = vault.vault_tokens["USDC"].token_vault;
        let res = try_fill_order(&mut ctx, &solver, &vault, Some(token_vault), None).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::AccountOwnedByWrongProgram, 1)
        );
    }

    // - [x] Working case (deposit order fill)
    try_fill_order(&mut ctx, &solver, &vault, Some(deposit_order), None)
        .await
        .unwrap();
}

// A solver's SOL-for-USDC fill (a tenth of a SOL, asking a lamport) against the given order slots.
async fn try_fill_order(
    ctx: &mut TestContext,
    solver: &VaultDepositorAccounts,
    vault: &VaultAccounts,
    deposit_order: Option<Pubkey>,
    withdraw_order: Option<Pubkey>,
) -> Result<(), BanksClientError> {
    let scope_accounts = get_ordered_scope_accounts(ctx, vault).await;
    let tx = instructions::rebalance_swap(
        ctx,
        &solver.owner,
        vault,
        &solver.token_atas["SOL"],
        &solver.token_atas["USDC"],
        &vault.vault_tokens["SOL"],
        &vault.vault_tokens["USDC"],
        SOL / 10,
        1,
        scope_accounts,
        None,
        pda::global_config(),
        None,
        deposit_order,
        withdraw_order,
    )
    .await;
    send_transaction!(ctx, tx)
}

// A copy of the order at `order`, at a fresh address, naming another vault as its own.
async fn claiming_another_vault(ctx: &mut TestContext, order: Pubkey) -> Pubkey {
    let copy = Pubkey::new_unique();
    ctx.clone_account(order, &copy).await;
    let mut data = ctx.get_account(copy).await.unwrap().unwrap().data;
    data[8..40].copy_from_slice(Pubkey::new_unique().as_ref()); // `base.vault_state`, right after the discriminator
    ctx.set_account_data(&copy, &data).await;
    copy
}

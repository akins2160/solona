use anchor_lang::prelude::{ErrorCode, Id};
use anchor_spl::{token::Token, token_interface::Token2022};
use kamino_lending::{
    anchor_error,
    program_test::common::{setup::kp, token_operations},
    send_transaction, ScopeConfiguration,
};
use metavault::{
    metavault_error,
    program_test::{client, fixtures, instructions, token_vault_pda},
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;

// Test cases:
// - [x] Wrong admin authority
// - [x] Wrong token vault
// - [x] Wrong token mint
// - [x] Wrong token program
// - [x] The vault's own shares mint
// - [x] Working case

#[tokio::test]
async fn test_security_add_vault_token() {
    let (mut ctx, mut vault, vault_manager, investor, mkts) =
        fixtures::setup_markets_and_reserves(1).await;
    let sol_mint = kp();
    token_operations::create_mint(
        &mut ctx,
        &sol_mint,
        9,
        &vault_manager.pubkey(),
        &Token::id(),
        None,
    )
    .await;
    let sol_vault = token_vault_pda(sol_mint.pubkey(), vault.vault_state.pubkey());
    let scope_feed = mkts[0].oracles.scope_prices;

    // Test cases:
    // - [] Wrong admin authority
    {
        let res = client::try_add_vault_token(
            &mut ctx,
            &investor.owner,
            &mut vault,
            "SOL",
            sol_mint.pubkey(),
            scope_feed,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [] Wrong token vault
    {
        let usdc_vault = token_vault_pda(
            vault.vault_tokens["USDC"].token_mint,
            vault.vault_state.pubkey(),
        );
        let tx = instructions::add_vault_token(
            &mut ctx,
            &vault_manager,
            &vault,
            sol_mint.pubkey(),
            usdc_vault,
            Token::id(),
            ScopeConfiguration {
                price_feed: scope_feed,
                price_chain: [2, u16::MAX, u16::MAX, u16::MAX],
                twap_chain: [3, u16::MAX, u16::MAX, u16::MAX],
            },
        )
        .await;

        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [] Wrong token program
    {
        let tx = instructions::add_vault_token(
            &mut ctx,
            &vault_manager,
            &vault,
            sol_mint.pubkey(),
            sol_vault,
            Token2022::id(),
            ScopeConfiguration {
                price_feed: scope_feed,
                price_chain: [2, u16::MAX, u16::MAX, u16::MAX],
                twap_chain: [3, u16::MAX, u16::MAX, u16::MAX],
            },
        )
        .await;

        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintMintTokenProgram, 1)
        );
    }

    // - [] The vault's own shares mint
    {
        let tx = instructions::add_vault_token(
            &mut ctx,
            &vault_manager,
            &vault,
            vault.shares_mint,
            token_vault_pda(vault.shares_mint, vault.vault_state.pubkey()),
            Token2022::id(),
            ScopeConfiguration {
                price_feed: scope_feed,
                price_chain: [2, u16::MAX, u16::MAX, u16::MAX],
                twap_chain: [3, u16::MAX, u16::MAX, u16::MAX],
            },
        )
        .await;

        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::VaultTokenIsSharesMint, 1)
        );
    }

    // - [] Working case
    {
        client::try_add_vault_token(
            &mut ctx,
            &vault_manager,
            &mut vault,
            "SOL",
            sol_mint.pubkey(),
            scope_feed,
        )
        .await
        .unwrap();
    }
}

use anchor_lang::{error::ErrorCode, Id, InstructionData, ToAccountMetas};
use anchor_spl::token_2022::Token2022;
use kamino_lending::{
    anchor_error,
    program_test::common::{
        fixtures::setup_reserves_with_elevation_groups,
        runner::state,
        setup::{new_borrower_accounts_with_obligation, update_reserve},
        types::{
            LendingMarketAccounts, MSpec, MarketsSpec, MintSpec, RSpec, ReserveAccounts,
            TestContext,
        },
    },
    send_transaction,
    state::ElevationGroup,
    Reserve,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, get_ordered_scope_and_obligation_accounts, init_obligation},
        event_authority_pda,
        fixtures::setup_markets_with_weights,
        instructions::{
            build_klend_refresh_obligation_ix, build_klend_refresh_reserve_ix,
            vault_obligation_pda, FARMS_PROGRAM_ID, FARMS_USER_STATE_SEED,
        },
        VaultAccounts, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction,
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    signature::Keypair,
    signer::Signer,
    sysvar::instructions as sysvar_instructions,
};

// Test cases:
// - [x] Wrong vault_admin_authority
// - [x] Wrong base_vault_authority
// - [x] Wrong obligation (real klend obligation, owned by a non-vault borrower)
// - [x] Wrong obligation pubkey in AUM remaining_accounts
// - [x] Reserve scope_configuration diverges from vault token's
// - [x] Wrong token_vault
// - [x] Wrong reserve_liquidity_mint (via wrong reserve struct)
// - [x] Liquidity mint not the reserve's
// - [x] Reserve token accounts not the reserve's
// - [x] Lending market not the obligation's
// - [x] Wrong lending_market_authority
// - [x] Farm accounts not the reserve's farm and the obligation's user state in it
// - [x] Wrong farms_program
// - [x] Wrong lending_program
// - [x] Token program not the token_vault's
// - [x] Wrong deposit reserve under elevation group (separate test)
// - [x] Multi-collateral elevation-group borrow (separate test — forwarding order)
// - [x] Working case

#[tokio::test]
async fn test_security_borrow_obligation_liquidity() {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        client::UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    // - [ ] Wrong vault_admin_authority
    {
        let stranger = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let res = client::try_borrow_obligation_liquidity(
            &mut ctx,
            &stranger,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            50_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect, 3)
        );
    }

    // - [ ] Wrong base_vault_authority
    {
        let wrong_bva = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_bva.pubkey();
        let res = client::try_borrow_obligation_liquidity(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            50_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 3)
        );
    }

    // - [ ] Wrong obligation
    // klend-valid obligation owned by an unrelated borrower (not registered in this vault).
    {
        let stranger_borrower = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let res = client::try_borrow_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &usdc_reserve,
            stranger_borrower.obligation,
            "USDC",
            50_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ObligationSlotNotFound, 3)
        );
    }

    // - [ ] Wrong token_vault
    {
        let wrong_token_vault = Pubkey::new_unique();
        ctx.clone_account(vault.vault_tokens["USDC"].token_vault, &wrong_token_vault)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_vault = wrong_token_vault;
        let res = client::try_borrow_obligation_liquidity(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            50_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong reserve_liquidity_mint
    {
        let res = client::try_borrow_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve, // wrong reserve (SOL where USDC expected)
            obligation_pk,
            "USDC",
            50_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong obligation pubkey in AUM remaining_accounts
    {
        let stranger = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let mut scope_and_obligation =
            get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
        *scope_and_obligation.last_mut().unwrap() = stranger.obligation;
        let mut metas = base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
            .to_account_metas(None);
        for acc in scope_and_obligation {
            metas.push(AccountMeta::new_readonly(acc, false));
        }
        let main_ix = Instruction {
            program_id: metavault::ID,
            accounts: metas,
            data: metavault::instruction::BorrowObligationLiquidity {
                liquidity_amount: 50_000_000,
            }
            .data(),
        };
        let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
        let tx = ctx
            .create_transaction_with_payer(
                vec![
                    cu_ix,
                    build_klend_refresh_reserve_ix(&usdc_reserve),
                    build_klend_refresh_obligation_ix(
                        obligation_pk,
                        market.market.pubkey(),
                        &[],
                        &[],
                    ),
                    main_ix,
                ],
                &admin,
            )
            .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 3),
        );
    }

    // - [ ] Reserve scope_configuration diverges from vault token's
    {
        let mut reserve = state::get::<Reserve>(&mut ctx, usdc_reserve.address.pubkey()).await;
        let original_chain = reserve.config.token_info.scope_configuration.price_chain;
        reserve.config.token_info.scope_configuration.price_chain[0] = u16::MAX - 1;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
        let res = client::try_borrow_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            50_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveScopeMismatch, 3),
        );
        reserve.config.token_info.scope_configuration.price_chain = original_chain;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
    }

    // - [ ] Liquidity mint not the reserve's (the other token's mint and token vault, the other
    // token's scope config on the reserve)
    {
        // The reserve takes the other token's scope config, so only the mint pin can reject:
        let mut reserve = state::get::<Reserve>(&mut ctx, usdc_reserve.address.pubkey()).await;
        let other_reserve = state::get::<Reserve>(&mut ctx, sol_reserve.address.pubkey()).await;
        let original_scope = reserve.config.token_info.scope_configuration;
        reserve.config.token_info.scope_configuration =
            other_reserve.config.token_info.scope_configuration;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            borrow_reserve_liquidity_mint: sol_reserve.liquidity_mint.pubkey(),
            token_vault: vault.vault_tokens["SOL"].token_vault,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
        reserve.config.token_info.scope_configuration = original_scope;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
    }

    // - [ ] Lending market not the obligation's (a copy of it at another address)
    {
        let foreign_market = Pubkey::new_unique();
        ctx.clone_account(market.market.pubkey(), &foreign_market)
            .await;
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            lending_market: foreign_market,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::LendingMarketMismatch, 3)
        );
    }

    // - [ ] `reserve_source_liquidity` not the reserve's (the other reserve's)
    {
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            reserve_source_liquidity: sol_reserve.liquidity_supply,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
    }

    // - [ ] `borrow_reserve_liquidity_fee_receiver` not the reserve's (the other reserve's)
    {
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            borrow_reserve_liquidity_fee_receiver: sol_reserve.fee_receiver,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
    }

    // - [ ] Wrong lending_market_authority (not the market's PDA)
    {
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            lending_market_authority: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Farm accounts not the reserve's farm and the obligation's user state in it
    {
        let mut reserve = state::get::<Reserve>(&mut ctx, usdc_reserve.address.pubkey()).await;
        let farm = Pubkey::new_unique();
        reserve.farm_debt = farm;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
        let (user_state, _) = Pubkey::find_program_address(
            &[FARMS_USER_STATE_SEED, farm.as_ref(), obligation_pk.as_ref()],
            &FARMS_PROGRAM_ID,
        );
        for farm_accounts in [
            vec![user_state, Pubkey::new_unique()],
            vec![Pubkey::new_unique(), farm],
        ] {
            let res = borrow_obligation_liquidity_with_custom_accs(
                &mut ctx,
                base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC"),
                &admin,
                &usdc_reserve,
                obligation_pk,
                market,
                &vault,
                /* prelude_deposit_reserves */ vec![],
                /* prelude_borrow_reserves */ vec![],
                /* metavault_ix_deposit_reserves (then the farm accounts) */ farm_accounts,
                50_000_000,
            )
            .await;
            assert_eq!(
                res.unwrap_err().unwrap(),
                metavault_error!(KaminoVaultError::FarmAccountMismatch, 3)
            );
        }
        reserve.farm_debt = Pubkey::default();
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
    }

    // - [ ] Wrong farms_program
    {
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            farms_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Token program not the token_vault's
    {
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            token_program: Token2022::id(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenTokenProgram, 3)
        );
    }

    // - [ ] Wrong lending_program
    {
        let accounts = metavault::accounts::BorrowObligationLiquidity {
            lending_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = borrow_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            50_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Working case
    {
        client::try_deposit_obligation_collateral(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            5_000_000_000,
            vec![],
            vec![],
        )
        .await
        .unwrap();
        client::try_borrow_obligation_liquidity(
            &mut ctx,
            &allocation_admin,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            50_000_000,
            vec![&sol_reserve],
            vec![],
        )
        .await
        .unwrap();
    }
}

// Wrong deposit reserve forwarded in the metavault remaining_accounts (a clone of SOL at a fresh
// pubkey): metavault checks the forwarded reserves against the obligation's active deposits.
#[tokio::test]
async fn test_security_borrow_obligation_liquidity_wrong_deposit_reserve_in_elevation_group() {
    let (mut ctx, _markets, vault, obligation_pk, sol_reserve, usdc_reserve) =
        setup_elevation_group_obligation_with_collateral().await;
    let admin = ctx.initial_market_owner.clone();

    let wrong_reserve_pk = Pubkey::new_unique();
    ctx.clone_account(sol_reserve.address.pubkey(), &wrong_reserve_pk)
        .await;

    let market = &_markets.markets[0].primary_market;
    let accounts = base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC");
    let res = borrow_obligation_liquidity_with_custom_accs(
        &mut ctx,
        accounts,
        &admin,
        &usdc_reserve,
        obligation_pk,
        market,
        &vault,
        /* prelude_deposit_reserves (correct) */ vec![&sol_reserve],
        /* prelude_borrow_reserves */ vec![],
        /* metavault_ix_deposit_reserves (wrong: cloned-SOL at a fresh pubkey) */
        vec![wrong_reserve_pk],
        50_000_000,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 4)
    );
}

// Multi-collateral in an elevation group: same forwarding-order contract as repay — klend
// asserts pairwise equality between forwarded reserves and `obligation.active_deposits_mut()`.
#[tokio::test]
async fn test_security_borrow_obligation_liquidity_multi_collateral_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, _usdc_reserve, usdt_reserve) =
        setup_three_reserve_elevation_group_with_multi_collateral().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    // [SOL, USDT] is the obligation's deposit insertion order; klend's iterator demands this
    // exact order.
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve, &usdt_reserve],
        vec![],
    )
    .await
    .unwrap();
}

const TEST_ELEVATION_GROUP_ID: u8 = 1;

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

fn make_three_reserve_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("USDT", 0),
        ])],
    }
}

// Vault with one obligation in an elevation group, SOL collateral already deposited.
async fn setup_elevation_group_obligation_with_collateral() -> (
    TestContext,
    kamino_lending::program_test::common::types::KaminoMarkets,
    VaultAccounts,
    Pubkey,
    ReserveAccounts,
    ReserveAccounts,
) {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[ElevationGroup {
            id: TEST_ELEVATION_GROUP_ID,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 1,
            debt_reserve: usdc_reserve.address.pubkey(),
            ..Default::default()
        }],
    )
    .await;
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;

    (
        ctx,
        markets,
        vault,
        obligation_pk,
        sol_reserve,
        usdc_reserve,
    )
}

// 3-reserve market + vault, obligation with two collaterals (SOL + USDT) deposited before
// joining an elevation group with `max_reserves_as_collateral = 2`.
async fn setup_three_reserve_elevation_group_with_multi_collateral() -> (
    TestContext,
    kamino_lending::program_test::common::types::KaminoMarkets,
    VaultAccounts,
    Pubkey,
    ReserveAccounts,
    ReserveAccounts,
    ReserveAccounts,
) {
    let (mut ctx, markets, vault) =
        setup_markets_with_weights(&make_three_reserve_spec(), vec![5, 5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let usdt_reserve = markets.markets[0].reserves["USDT"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
            "USDT".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC", "USDT"],
        &[ElevationGroup {
            id: TEST_ELEVATION_GROUP_ID,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 2,
            debt_reserve: usdc_reserve.address.pubkey(),
            ..Default::default()
        }],
    )
    .await;

    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdt_reserve,
        obligation_pk,
        "USDT",
        500_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve, &usdt_reserve],
        vec![],
    )
    .await;

    (
        ctx,
        markets,
        vault,
        obligation_pk,
        sol_reserve,
        usdc_reserve,
        usdt_reserve,
    )
}

fn base_accounts(
    admin: &Keypair,
    vault: &VaultAccounts,
    market: &LendingMarketAccounts,
    borrow_reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
) -> metavault::accounts::BorrowObligationLiquidity {
    let vault_token = vault.vault_tokens.get(token_name).unwrap();
    metavault::accounts::BorrowObligationLiquidity {
        authority: admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        borrow_reserve: borrow_reserve.address.pubkey(),
        borrow_reserve_liquidity_mint: borrow_reserve.liquidity_mint.pubkey(),
        reserve_source_liquidity: borrow_reserve.liquidity_supply,
        borrow_reserve_liquidity_fee_receiver: borrow_reserve.fee_receiver,
        token_vault: vault_token.token_vault,
        token_program: borrow_reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::id(),
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
}

#[allow(clippy::too_many_arguments)]
async fn borrow_obligation_liquidity_with_custom_accs(
    ctx: &mut TestContext,
    accounts: impl ToAccountMetas,
    admin: &Keypair,
    borrow_reserve: &ReserveAccounts,
    obligation: Pubkey,
    market: &LendingMarketAccounts,
    vault: &VaultAccounts,
    prelude_deposit_reserves: Vec<&ReserveAccounts>,
    prelude_borrow_reserves: Vec<&ReserveAccounts>,
    metavault_ix_deposit_reserves: Vec<Pubkey>,
    liquidity_amount: u64,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let mut metas = accounts.to_account_metas(None);
    for acc in scope_and_obligation_accounts {
        metas.push(AccountMeta::new_readonly(acc, false));
    }
    for r in &metavault_ix_deposit_reserves {
        metas.push(AccountMeta::new(*r, false));
    }
    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts: metas,
        data: metavault::instruction::BorrowObligationLiquidity { liquidity_amount }.data(),
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    let mut all_ixs = vec![cu_ix];
    all_ixs.push(build_klend_refresh_reserve_ix(borrow_reserve));
    for r in &prelude_deposit_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    for r in &prelude_borrow_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    all_ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        market.market.pubkey(),
        &prelude_deposit_reserves,
        &prelude_borrow_reserves,
    ));
    all_ixs.push(main_ix);
    let tx = ctx.create_transaction_with_payer(all_ixs, admin).await;
    send_transaction!(ctx, tx)
}

use anchor_lang::error::ErrorCode;
use kamino_lending::{
    anchor_error,
    program_test::common::{setup::funded_new_kp, token_operations::create_ata_if_not_exists},
};
use metavault::{
    metavault_error,
    program_test::{client, fixtures, fixtures::ProgramDependency, token_acl},
    KaminoVaultError,
};
use solana_program::native_token::LAMPORTS_PER_SOL;
use solana_program_test::tokio;
use solana_sdk::pubkey::Pubkey;

#[tokio::test]
async fn test_security_shares_acl_wrappers() {
    // - [] Forged mint config account (thaw and delete as representatives of the
    //   readonly and mutating CPI shapes)
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let user = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
        let mint = vault.shares_mint;
        let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;

        let mut wrong_vault = vault.clone();
        wrong_vault.shares_mint_config = Pubkey::new_unique();

        let err = client::thaw_shares_account(&mut ctx, &owner, &wrong_vault, ata)
            .await
            .unwrap_err();
        assert_eq!(
            err.unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 0)
        );
        let err = client::delete_shares_config(&mut ctx, &owner, &wrong_vault)
            .await
            .unwrap_err();
        assert_eq!(
            err.unwrap(),
            metavault_error!(KaminoVaultError::MintConfigIncorrect, 0)
        );
    }

    // - [] Mismatched vault/mint pair: the shares mint of a DIFFERENT vault
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let user = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
        let mint = vault.shares_mint;
        let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;

        let mut wrong_vault = vault.clone();
        wrong_vault.shares_mint = Pubkey::new_unique();

        let err = client::thaw_shares_account(&mut ctx, &owner, &wrong_vault, ata)
            .await
            .unwrap_err();
        assert_eq!(err.unwrap(), anchor_error!(ErrorCode::ConstraintHasOne));
    }

    // - [] Wrong token ACL program account on the thaw CPI path
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        let user = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
        let mint = vault.shares_mint;
        let ata = create_ata_if_not_exists(&mut ctx, &user, &mint).await;

        let mut wrong_vault = vault.clone();
        wrong_vault.token_acl_program = Pubkey::new_unique();

        let err = client::thaw_shares_account(&mut ctx, &owner, &wrong_vault, ata)
            .await
            .unwrap_err();
        assert_eq!(
            err.unwrap(),
            metavault_error!(KaminoVaultError::TokenAclProgramIncorrect, 0)
        );
    }

    // - [] A shares account of a foreign mint cannot be thawed through the vault
    {
        let (mut ctx, vault, owner, _investor, _mkts) =
            fixtures::setup_markets_and_reserves_permissioned(
                token_acl::ALWAYS_ALLOW_GATE_ID,
                vec![ProgramDependency::GateAlwaysAllow],
            )
            .await;
        // A token account of the vault's UNDERLYING mint, not the shares mint.
        let user = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
        let underlying_mint = vault.vault_tokens["USDC"].token_mint;
        let foreign_account = create_ata_if_not_exists(&mut ctx, &user, &underlying_mint).await;

        let res = client::thaw_shares_account(&mut ctx, &owner, &vault, foreign_account).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 0)
        );
    }
}

use kamino_lending::{program_test::common::setup::kp, send_transaction};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures::setup_markets_and_reserves,
        instructions, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::{instruction::InstructionError, signer::Signer, transaction::TransactionError};

// Test cases:
// - [x] Anyone can call refresh_vault
// - [x] Wrong remaining scope account is rejected
// - [x] Missing remaining accounts are rejected
// - [x] Wrong scope account owner is rejected before decode

#[tokio::test]
async fn test_security_refresh_vault() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves(1).await;
    let stranger = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", 0).await;

    client::try_refresh_vault(&mut ctx, &vault, &stranger.owner)
        .await
        .unwrap();

    {
        let mut wrong_vault = vault.clone();
        wrong_vault
            .scope_prices
            .get_mut(&vault.vault_tokens["USDC"].token_mint)
            .unwrap()
            .scope_feed = kp().pubkey();

        let res = client::try_refresh_vault(&mut ctx, &wrong_vault, &stranger.owner).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidScopePriceAccount, 0)
        );
    }

    {
        // No remaining accounts at all: the scope-price segment comes first and runs dry first.
        let tx = instructions::refresh_vault(&mut ctx, &stranger.owner, &vault, vec![]).await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            TransactionError::InstructionError(0, InstructionError::NotEnoughAccountKeys)
        );
    }

    {
        let scope_feed = vault.scope_prices[&vault.vault_tokens["USDC"].token_mint].scope_feed;
        let mut scope_account = ctx.get_account(scope_feed).await.unwrap().unwrap();
        scope_account.owner = metavault::ID;
        scope_account.data.clear();
        ctx.set_account(&scope_feed, scope_account);

        let res = client::try_refresh_vault(&mut ctx, &vault, &stranger.owner).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidScopePriceAccount, 0)
        );
    }

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;

    let res = client::try_refresh_vault(&mut ctx, &vault, &stranger.owner).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultEmergencyMode)
    );
}

use anchor_lang::error::ErrorCode;
use kamino_lending::{
    anchor_error,
    program_test::common::{math::usdc_decimal_to_u64 as usdc, setup::kp, token_operations},
    send_transaction,
};
use metavault::{
    metavault_error,
    program_test::{client, fixtures, instructions, token_vault_pda, VaultDepositorAccounts},
    utils::pda,
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::{pubkey::Pubkey, signer::Signer};

// Test cases:
// - [] Wrong reserve ?
// - [x] Wrong global config
// - [x] Wrong token vault
// - [x] Wrong base vault authority
// - [x] Wrong token ata mint
// - [x] Wrong token ata authority
// - [x] Wrong token mint
// - [x] Wrong user shares ata mint
// - [x] Wrong user shares ata authority
// - [x] Wrong shares mint
// - [x] Wrong scope feed
// - [x] Working case

#[tokio::test]
async fn test_security_withdraw() {
    let (mut ctx, vault, _owner, _investor, mkts) = fixtures::setup_markets_and_reserves(2).await;

    let topup = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let second_depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let deposit_amount = topup;

    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // - [] Wrong global config
    {
        let wrong_global_config = Pubkey::new_unique();
        ctx.clone_account(pda::global_config(), &wrong_global_config)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.global_config = wrong_global_config;

        let res = client::try_withdraw(
            &mut ctx,
            &wrong_vault,
            &depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [] Wrong token vault
    {
        let wrong_token_vault = Pubkey::new_unique();
        ctx.clone_account(vault.vault_tokens["USDC"].token_vault, &wrong_token_vault)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_vault = wrong_token_vault;

        let res = client::try_withdraw(
            &mut ctx,
            &wrong_vault,
            &depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [] Wrong base vault authority
    {
        let wrong_base_vault = ctx.new_keypair(u32::MAX.into()).await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_base_vault.pubkey();

        let res = client::try_withdraw(
            &mut ctx,
            &wrong_vault,
            &depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [] Wrong token ata mint
    {
        let mut wrong_depositor = depositor.clone();
        wrong_depositor
            .token_atas
            .insert("USDC".to_string(), depositor.shares_ata);

        let res = client::try_withdraw(
            &mut ctx,
            &vault,
            &wrong_depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 1)
        );
    }

    // - [] Wrong token ata authority
    {
        let mut wrong_depositor = depositor.clone();
        wrong_depositor
            .token_atas
            .insert("USDC".to_string(), second_depositor.token_atas["USDC"]);

        let res = client::try_withdraw(
            &mut ctx,
            &vault,
            &wrong_depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
        );
    }

    // - [] Wrong token mint
    {
        let mut wrong_vault = vault.clone();
        let wrong_mint = mkts[1].reserve_accounts().collateral_mint;
        // Clone mint into the wrong one
        wrong_vault.vault_tokens.get_mut("USDC").unwrap().token_mint = wrong_mint;
        ctx.clone_account(vault.vault_tokens["USDC"].token_mint, &wrong_mint)
            .await;

        // Change vault and clone it
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_vault = token_vault_pda(wrong_mint, wrong_vault.vault_state.pubkey());
        ctx.clone_account(
            vault.vault_tokens["USDC"].token_vault,
            &wrong_vault.vault_tokens["USDC"].token_vault,
        )
        .await;

        // Also change user ata
        let mut wrong_depositor = depositor.clone();
        let wrong_ata =
            token_operations::create_ata(&mut ctx, &wrong_depositor.owner, &wrong_mint).await;
        wrong_depositor
            .token_atas
            .insert("USDC".to_string(), wrong_ata);
        let tx = instructions::withdraw(
            &mut ctx,
            &wrong_vault,
            &wrong_depositor,
            &wrong_vault.vault_tokens["USDC"],
            "USDC",
            vec![wrong_vault.scope_prices[&vault.vault_tokens["USDC"].token_mint].scope_feed],
            1,
            0,
        )
        .await;

        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::TokenNotEnabledInVault, 1)
        );
    }

    // - [] Wrong user shares ata mint
    {
        let mut wrong_depositor = depositor.clone();
        wrong_depositor.shares_ata = depositor.token_atas["USDC"];
        let res = client::try_withdraw(
            &mut ctx,
            &vault,
            &wrong_depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 1)
        );
    }

    // - [] Wrong user shares ata authority
    {
        let mut wrong_depositor = depositor.clone();
        wrong_depositor.shares_ata = second_depositor.shares_ata;
        let res = client::try_withdraw(
            &mut ctx,
            &vault,
            &wrong_depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
        );
    }

    // - [] Wrong shares mint
    {
        let wrong_shares_mint = Pubkey::new_unique();
        ctx.clone_account(vault.shares_mint, &wrong_shares_mint)
            .await;

        let mut wrong_vault = vault.clone();
        wrong_vault.shares_mint = wrong_shares_mint;

        let res = client::try_withdraw(
            &mut ctx,
            &wrong_vault,
            &depositor,
            deposit_amount,
            "USDC",
            0,
        )
        .await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // Wrong scope feed
    {
        let mut wrong_vault = vault.clone();
        wrong_vault
            .scope_prices
            .get_mut(&vault.vault_tokens["USDC"].token_mint)
            .unwrap()
            .scope_feed = kp().pubkey();
        let res = client::try_withdraw(&mut ctx, &wrong_vault, &depositor, 1, "USDC", 0).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidScopePriceAccount, 1)
        );
    }

    // - [] Working case
    {
        client::try_withdraw(&mut ctx, &vault, &depositor, deposit_amount, "USDC", 0)
            .await
            .unwrap();
    }
}

use anchor_lang::error::ErrorCode;
use borsh::BorshSerialize;
use kamino_lending::anchor_error;
use metavault::program_test::{client, fixtures};
use metavault::utils::{global_config::UpdateGlobalConfigMode, pda};
use solana_program_test::tokio;

// Test cases:
// - [x] Wrong admin authority (ConstraintHasOne)
// - [x] Working case (correct admin)

fn u64_bytes(value: u64) -> Vec<u8> {
    let mut buf = Vec::new();
    value.serialize(&mut buf).unwrap();
    buf
}

#[tokio::test]
async fn test_security_update_global_config_wrong_admin() {
    let (mut ctx, _vault, _owner, investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let global_config = pda::global_config();

    let res = client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        u64_bytes(100),
        &investor.owner,
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        anchor_error!(ErrorCode::ConstraintHasOne)
    );
}

#[tokio::test]
async fn test_security_update_global_config_correct_admin() {
    let (mut ctx, _vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    let global_config = pda::global_config();

    client::update_global_config(
        &mut ctx,
        &global_config,
        UpdateGlobalConfigMode::MinDepositFeeBPS,
        u64_bytes(100),
        &owner,
    )
    .await
    .unwrap();
}

use anchor_lang::{error::ErrorCode, Id};
use anchor_spl::token::Token;
use kamino_lending::{
    anchor_error,
    program_test::common::{math::usdc_decimal_to_u64 as usdc, token_operations},
};
use metavault::program_test::{client, fixtures, VaultDepositorAccounts};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;

// Test cases:
// - [x] Wrong admin authority (non-admin)
// - [x] Wrong base vault authority
// - [x] Wrong shares ata mint
// - [x] Wrong shares ata authority
// - [x] Wrong shares mint
// - [x] Working case

#[tokio::test]
async fn test_security_withdraw_pending_fees() {
    let (mut ctx, vault, owner, _investor, mkts) = fixtures::setup_markets_and_reserves(2).await;

    let topup = usdc(100_000.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let vault_admin = VaultDepositorAccounts::new_with_owner(&mut ctx, owner, "USDC", &vault).await;

    let deposit_amount = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit_amount).await;

    // - [] Wrong admin authority (non-admin tries to withdraw fees)
    {
        let res = client::try_withdraw_pending_fees(&mut ctx, &vault, &depositor).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne)
        );
    }

    // - [] Wrong base vault authority
    {
        let wrong_base_vault_authority = ctx.new_keypair(u32::MAX.into()).await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_base_vault_authority.pubkey();

        let res = client::try_withdraw_pending_fees(&mut ctx, &wrong_vault, &vault_admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne)
        );
    }

    // - [] Wrong shares mint
    {
        let mut wrong_vault = vault.clone();
        let wrong_mint = mkts[1].reserve_accounts().collateral_mint;
        // Clone mint into the wrong one
        wrong_vault.shares_mint = wrong_mint;
        ctx.clone_account(vault.shares_mint, &wrong_mint).await;

        // Also change user ata
        let mut wrong_depositor = vault_admin.clone();
        wrong_depositor.shares_ata =
            token_operations::create_ata(&mut ctx, &wrong_depositor.owner, &wrong_mint).await;

        let res = client::try_withdraw_pending_fees(&mut ctx, &wrong_vault, &wrong_depositor).await;

        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 0)
        );
    }

    // - [] Wrong shares ata mint
    {
        let mut wrong_admin_ata = vault_admin.clone();
        wrong_admin_ata.shares_ata = vault_admin.token_atas["USDC"];

        let res = client::try_withdraw_pending_fees(&mut ctx, &vault, &wrong_admin_ata).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint)
        );
    }

    // - [] Wrong shares ata authority
    {
        let mut wrong_admin_ata = vault_admin.clone();
        wrong_admin_ata.shares_ata = depositor.shares_ata;

        let res = client::try_withdraw_pending_fees(&mut ctx, &vault, &wrong_admin_ata).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner)
        );
    }

    // - [] Wrong shares program
    {
        let mut wrong_vault = vault.clone();
        wrong_vault.shares_token_program = Token::id();

        let res = client::try_withdraw_pending_fees(&mut ctx, &wrong_vault, &vault_admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::InvalidProgramId)
        );
    }

    // - [] Working case
    {
        client::try_withdraw_pending_fees(&mut ctx, &vault, &vault_admin)
            .await
            .unwrap();
    }
}

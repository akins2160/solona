use anchor_lang::{error::ErrorCode, Id, InstructionData, ToAccountMetas};
use anchor_spl::token_2022::Token2022;
use kamino_lending::{
    anchor_error,
    program_test::common::{
        fixtures::setup_reserves_with_elevation_groups,
        runner::state,
        setup::{new_borrower_accounts_with_obligation, update_reserve},
        types::{
            KaminoMarkets, LendingMarketAccounts, MSpec, MarketsSpec, MintSpec, RSpec,
            ReserveAccounts, TestContext,
        },
    },
    send_transaction,
    state::ElevationGroup,
    Reserve,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, get_ordered_scope_and_obligation_accounts, init_obligation},
        event_authority_pda,
        fixtures::setup_markets_with_weights,
        instructions::{
            build_klend_refresh_obligation_ix, build_klend_refresh_reserve_ix,
            vault_obligation_pda, FARMS_PROGRAM_ID,
        },
        VaultAccounts, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction,
    instruction::{AccountMeta, Instruction, InstructionError},
    pubkey::Pubkey,
    signature::Keypair,
    signer::Signer,
    sysvar::instructions as sysvar_instructions,
    transaction::TransactionError,
};

// Test cases:
// - [x] Wrong vault_admin_authority
// - [x] Wrong base_vault_authority
// - [x] Wrong obligation (real klend obligation, owned by a non-vault borrower)
// - [x] Wrong obligation pubkey in AUM remaining_accounts
// - [x] Reserve scope_configuration diverges from vault token's
// - [x] Wrong token_vault
// - [x] Wrong reserve_liquidity_mint (via wrong reserve struct)
// - [x] Liquidity mint not the reserve's
// - [x] Reserve token accounts not the reserve's
// - [x] Lending market not the obligation's
// - [x] Wrong lending_market_authority
// - [x] Wrong farms_program
// - [x] Wrong lending_program
// - [x] Token program not the token_vault's
// - [x] Working case
// - [x] Missing deposit reserves under elevation group (separate test)
// - [x] Wrong (non-matching) deposit reserve under elevation group (separate test)

#[tokio::test]
async fn test_security_repay_obligation_liquidity() {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        client::UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    // - [ ] Wrong vault_admin_authority
    {
        let stranger = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let res = client::try_repay_obligation_liquidity(
            &mut ctx,
            &stranger,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            10_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect, 3)
        );
    }

    // - [ ] Wrong base_vault_authority
    {
        let wrong_bva = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_bva.pubkey();
        let res = client::try_repay_obligation_liquidity(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            10_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 3)
        );
    }

    // - [ ] Wrong obligation
    // klend-valid obligation owned by an unrelated borrower (not registered in this vault).
    {
        let stranger_borrower = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let res = client::try_repay_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &usdc_reserve,
            stranger_borrower.obligation,
            "USDC",
            10_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ObligationSlotNotFound, 3)
        );
    }

    // - [ ] Wrong token_vault
    {
        let wrong_token_vault = Pubkey::new_unique();
        ctx.clone_account(vault.vault_tokens["USDC"].token_vault, &wrong_token_vault)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault
            .vault_tokens
            .get_mut("USDC")
            .unwrap()
            .token_vault = wrong_token_vault;
        let res = client::try_repay_obligation_liquidity(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            10_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong reserve_liquidity_mint
    {
        let res = client::try_repay_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve, // wrong reserve (SOL where USDC expected)
            obligation_pk,
            "USDC",
            10_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong obligation pubkey in AUM remaining_accounts
    {
        let stranger = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let mut scope_and_obligation =
            get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
        *scope_and_obligation.last_mut().unwrap() = stranger.obligation;
        let mut metas = base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
            .to_account_metas(None);
        for acc in scope_and_obligation {
            metas.push(AccountMeta::new_readonly(acc, false));
        }
        let main_ix = Instruction {
            program_id: metavault::ID,
            accounts: metas,
            data: metavault::instruction::RepayObligationLiquidity {
                liquidity_amount: 10_000_000,
            }
            .data(),
        };
        let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
        let tx = ctx
            .create_transaction_with_payer(
                vec![
                    cu_ix,
                    build_klend_refresh_reserve_ix(&usdc_reserve),
                    build_klend_refresh_obligation_ix(
                        obligation_pk,
                        market.market.pubkey(),
                        &[],
                        &[],
                    ),
                    main_ix,
                ],
                &admin,
            )
            .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 3),
        );
    }

    // - [ ] Reserve scope_configuration diverges from vault token's
    {
        let mut reserve = state::get::<Reserve>(&mut ctx, usdc_reserve.address.pubkey()).await;
        let original_chain = reserve.config.token_info.scope_configuration.price_chain;
        reserve.config.token_info.scope_configuration.price_chain[0] = u16::MAX - 1;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
        let res = client::try_repay_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            10_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveScopeMismatch, 3),
        );
        reserve.config.token_info.scope_configuration.price_chain = original_chain;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
    }

    // - [ ] Liquidity mint not the reserve's (the other token's mint and token vault, the other
    // token's scope config on the reserve)
    {
        // The reserve takes the other token's scope config, so only the mint pin can reject:
        let mut reserve = state::get::<Reserve>(&mut ctx, usdc_reserve.address.pubkey()).await;
        let other_reserve = state::get::<Reserve>(&mut ctx, sol_reserve.address.pubkey()).await;
        let original_scope = reserve.config.token_info.scope_configuration;
        reserve.config.token_info.scope_configuration =
            other_reserve.config.token_info.scope_configuration;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
        let accounts = metavault::accounts::RepayObligationLiquidity {
            reserve_liquidity_mint: sol_reserve.liquidity_mint.pubkey(),
            token_vault: vault.vault_tokens["SOL"].token_vault,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
        reserve.config.token_info.scope_configuration = original_scope;
        update_reserve(&mut ctx, &reserve, &usdc_reserve.address.pubkey()).await;
    }

    // - [ ] Lending market not the obligation's (a copy of it at another address)
    {
        let foreign_market = Pubkey::new_unique();
        ctx.clone_account(market.market.pubkey(), &foreign_market)
            .await;
        let accounts = metavault::accounts::RepayObligationLiquidity {
            lending_market: foreign_market,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::LendingMarketMismatch, 3)
        );
    }

    // - [ ] `reserve_destination_liquidity` not the reserve's (the other reserve's)
    {
        let accounts = metavault::accounts::RepayObligationLiquidity {
            reserve_destination_liquidity: sol_reserve.liquidity_supply,
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
    }

    // - [ ] Wrong lending_market_authority (not the market's PDA)
    {
        let accounts = metavault::accounts::RepayObligationLiquidity {
            lending_market_authority: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong farms_program
    {
        let accounts = metavault::accounts::RepayObligationLiquidity {
            farms_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Token program not the token_vault's
    {
        let accounts = metavault::accounts::RepayObligationLiquidity {
            token_program: Token2022::id(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenTokenProgram, 3)
        );
    }

    // - [ ] Wrong lending_program
    {
        let accounts = metavault::accounts::RepayObligationLiquidity {
            lending_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC")
        };
        let res = repay_obligation_liquidity_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &usdc_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            /* metavault_ix_deposit_reserves */ vec![],
            10_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Working case
    // Deposit + borrow first so there's a debt to repay against.
    {
        client::try_deposit_obligation_collateral(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            5_000_000_000,
            vec![],
            vec![],
        )
        .await
        .unwrap();
        client::try_borrow_obligation_liquidity(
            &mut ctx,
            &admin,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            100_000_000,
            vec![&sol_reserve],
            vec![],
        )
        .await
        .unwrap();
        client::try_repay_obligation_liquidity(
            &mut ctx,
            &allocation_admin,
            &vault,
            market,
            &usdc_reserve,
            obligation_pk,
            "USDC",
            10_000_000,
            vec![&sol_reserve],
            vec![&usdc_reserve],
        )
        .await
        .unwrap();
    }
}

// Under elevation group, klend requires one matching deposit reserve per active deposit in
// remaining_accounts. Empty → `InvalidAccountInput` (klend custom code 6006).
#[tokio::test]
async fn test_security_repay_obligation_liquidity_missing_deposit_reserve_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk, _sol_reserve, usdc_reserve) =
        setup_elevation_group_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    // Refresh prelude gets the SOL deposit reserve, but the repay CPI does not.
    let res = client::try_repay_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        50_000_000,
        /* obligation_deposit_reserves (also forwarded into the repay ix) */ vec![],
        /* obligation_borrow_reserves */ vec![&usdc_reserve],
    )
    .await;
    // klend `InvalidAccountInput` = error code 6006 = 0x1776
    match res.unwrap_err() {
        BanksClientError::TransactionError(TransactionError::InstructionError(
            _,
            InstructionError::Custom(6006),
        )) => {}
        other => panic!("expected klend InvalidAccountInput (6006), got {:?}", other),
    }
}

// Forward a WRONG reserve (clone of SOL at a fresh pubkey) where the real SOL reserve is
// expected: metavault checks the forwarded reserves against the obligation's active deposits.
#[tokio::test]
async fn test_security_repay_obligation_liquidity_wrong_deposit_reserve_in_elevation_group() {
    let (mut ctx, markets, vault, obligation_pk, sol_reserve, usdc_reserve) =
        setup_elevation_group_obligation().await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;

    let wrong_reserve_pk = Pubkey::new_unique();
    ctx.clone_account(sol_reserve.address.pubkey(), &wrong_reserve_pk)
        .await;

    let accounts = base_accounts(&admin, &vault, market, &usdc_reserve, obligation_pk, "USDC");
    let res = repay_obligation_liquidity_with_custom_accs(
        &mut ctx,
        accounts,
        &admin,
        &usdc_reserve,
        obligation_pk,
        market,
        &vault,
        /* prelude_deposit_reserves (correct) */ vec![&sol_reserve],
        /* prelude_borrow_reserves */ vec![&usdc_reserve],
        /* metavault_ix_deposit_reserves (wrong: cloned-SOL at a fresh pubkey) */
        vec![wrong_reserve_pk],
        50_000_000,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 4)
    );
}

const TEST_ELEVATION_GROUP_ID: u8 = 1;

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

fn base_accounts(
    admin: &Keypair,
    vault: &VaultAccounts,
    market: &LendingMarketAccounts,
    repay_reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
) -> metavault::accounts::RepayObligationLiquidity {
    let vault_token = vault.vault_tokens.get(token_name).unwrap();
    metavault::accounts::RepayObligationLiquidity {
        authority: admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        repay_reserve: repay_reserve.address.pubkey(),
        reserve_liquidity_mint: repay_reserve.liquidity_mint.pubkey(),
        reserve_destination_liquidity: repay_reserve.liquidity_supply,
        token_vault: vault_token.token_vault,
        token_program: repay_reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::id(),
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
}

#[allow(clippy::too_many_arguments)]
async fn repay_obligation_liquidity_with_custom_accs(
    ctx: &mut TestContext,
    accounts: impl ToAccountMetas,
    admin: &Keypair,
    repay_reserve: &ReserveAccounts,
    obligation: Pubkey,
    market: &LendingMarketAccounts,
    vault: &VaultAccounts,
    prelude_deposit_reserves: Vec<&ReserveAccounts>,
    prelude_borrow_reserves: Vec<&ReserveAccounts>,
    metavault_ix_deposit_reserves: Vec<Pubkey>,
    liquidity_amount: u64,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let mut metas = accounts.to_account_metas(None);
    for acc in scope_and_obligation_accounts {
        metas.push(AccountMeta::new_readonly(acc, false));
    }
    for r in &metavault_ix_deposit_reserves {
        metas.push(AccountMeta::new(*r, false));
    }
    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts: metas,
        data: metavault::instruction::RepayObligationLiquidity { liquidity_amount }.data(),
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    let mut all_ixs = vec![cu_ix];
    all_ixs.push(build_klend_refresh_reserve_ix(repay_reserve));
    for r in &prelude_deposit_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    for r in &prelude_borrow_reserves {
        if r.address.pubkey() != repay_reserve.address.pubkey() {
            all_ixs.push(build_klend_refresh_reserve_ix(r));
        }
    }
    all_ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        market.market.pubkey(),
        &prelude_deposit_reserves,
        &prelude_borrow_reserves,
    ));
    all_ixs.push(main_ix);
    let tx = ctx.create_transaction_with_payer(all_ixs, admin).await;
    send_transaction!(ctx, tx)
}

// Sets up a vault + obligation in an elevation group with SOL collateral and a USDC borrow. Used
// by both the missing- and wrong-deposit-reserve elevation-group repay tests.
async fn setup_elevation_group_obligation() -> (
    TestContext,
    KaminoMarkets,
    VaultAccounts,
    Pubkey,
    ReserveAccounts,
    ReserveAccounts,
) {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let usdc_reserve_pk = usdc_reserve.address.pubkey();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);

    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[ElevationGroup {
            id: TEST_ELEVATION_GROUP_ID,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 1,
            debt_reserve: usdc_reserve_pk,
            ..Default::default()
        }],
    )
    .await;
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    client::request_elevation_group(
        &mut ctx,
        &admin,
        &vault,
        market,
        obligation_pk,
        TEST_ELEVATION_GROUP_ID,
        vec![&sol_reserve],
        vec![],
    )
    .await;
    client::try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        market,
        &usdc_reserve,
        obligation_pk,
        "USDC",
        100_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();

    (
        ctx,
        markets,
        vault,
        obligation_pk,
        sol_reserve,
        usdc_reserve,
    )
}

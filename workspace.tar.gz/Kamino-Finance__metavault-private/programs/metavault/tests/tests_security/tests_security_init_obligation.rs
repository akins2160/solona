use anchor_lang::{error::ErrorCode, system_program::System, Id, InstructionData, ToAccountMetas};
use kamino_lending::{
    anchor_error,
    program_test::common::types::{
        LendingMarketAccounts, MSpec, MarketsSpec, MintSpec, RSpec, TestContext,
    },
    send_transaction,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, try_init_obligation},
        event_authority_pda,
        fixtures::setup_markets_with_weights,
        instructions::vault_obligation_pda,
        VaultAccounts,
    },
    utils::pda::vault_user_metadata,
    KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction, instruction::Instruction, pubkey::Pubkey, rent::Rent,
    signature::Keypair, signer::Signer, sysvar::SysvarId,
};

// Test cases:
// - [x] Wrong vault_admin_authority (caller-signer)
// - [x] Allocation admin is not allowed (admin-only instruction)
// - [x] Wrong base_vault_authority (breaks the has_one)
// - [x] Wrong lending_program (anchor address constraint)
// - [x] Non-lending-market account in the lending_market slot
// - [x] Obligation not the vault's PDA for the market and slot
// - [x] Non-default seed accounts
// - [x] Wrong owner_user_metadata
// - [x] Working case

#[tokio::test]
async fn test_security_init_obligation() {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        client::UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    // - [ ] Wrong vault_admin_authority
    {
        let stranger = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let res = try_init_obligation(&mut ctx, &stranger, &vault, market, 0).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [ ] Allocation admin is not allowed (admin-only instruction)
    {
        let res = try_init_obligation(&mut ctx, &allocation_admin, &vault, market, 0).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [ ] Wrong base_vault_authority
    {
        let wrong_bva = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_bva.pubkey();
        let res = try_init_obligation(&mut ctx, &admin, &wrong_vault, market, 0).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [ ] Wrong lending_program
    {
        let accounts = metavault::accounts::InitObligation {
            lending_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, 0)
        };
        let res = init_obligation_with_custom_accs(&mut ctx, accounts, &admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 1)
        );
    }

    // - [ ] Non-lending-market account in the lending_market slot
    {
        let accounts = metavault::accounts::InitObligation {
            lending_market: vault.vault_state.pubkey(),
            ..base_accounts(&admin, &vault, market, 0)
        };
        let res = init_obligation_with_custom_accs(&mut ctx, accounts, &admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::AccountOwnedByWrongProgram, 1)
        );
    }

    // - [ ] Obligation not the vault's PDA for the market and slot (the next slot's)
    {
        let accounts = metavault::accounts::InitObligation {
            obligation: vault_obligation_pda(
                &market.market.pubkey(),
                &vault.base_vault_authority,
                1,
            ),
            ..base_accounts(&admin, &vault, market, 0)
        };
        let res = init_obligation_with_custom_accs(&mut ctx, accounts, &admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ObligationAddressMismatch, 1)
        );
    }

    // - [ ] Non-default seed accounts
    for (seed1_account, seed2_account) in [
        (market.market.pubkey(), Pubkey::default()),
        (Pubkey::default(), market.market.pubkey()),
    ] {
        let accounts = metavault::accounts::InitObligation {
            seed1_account,
            seed2_account,
            ..base_accounts(&admin, &vault, market, 0)
        };
        let res = init_obligation_with_custom_accs(&mut ctx, accounts, &admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 1)
        );
    }

    // - [ ] Wrong owner_user_metadata
    {
        let accounts = metavault::accounts::InitObligation {
            owner_user_metadata: vault_user_metadata(&admin.pubkey()),
            ..base_accounts(&admin, &vault, market, 0)
        };
        let res = init_obligation_with_custom_accs(&mut ctx, accounts, &admin).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [ ] Working case
    {
        let lamports_before = ctx
            .get_account(admin.pubkey())
            .await
            .unwrap()
            .unwrap()
            .lamports;
        client::init_obligation(&mut ctx, &admin, &vault, market, 0).await;
        let lamports_after = ctx
            .get_account(admin.pubkey())
            .await
            .unwrap()
            .unwrap()
            .lamports;
        assert!(lamports_after < lamports_before);
    }
}

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

fn base_accounts(
    admin: &Keypair,
    vault: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation_id: u8,
) -> metavault::accounts::InitObligation {
    let obligation = vault_obligation_pda(
        &market.market.pubkey(),
        &vault.base_vault_authority,
        obligation_id,
    );
    let user_metadata = vault_user_metadata(&vault.base_vault_authority);
    metavault::accounts::InitObligation {
        vault_admin_authority: admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        seed1_account: Pubkey::default(),
        seed2_account: Pubkey::default(),
        owner_user_metadata: user_metadata,
        lending_program: kamino_lending::ID,
        rent: Rent::id(),
        system_program: System::id(),
        instruction_sysvar_account: solana_sdk::sysvar::instructions::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
}

async fn init_obligation_with_custom_accs(
    ctx: &mut TestContext,
    accounts: impl ToAccountMetas,
    admin: &Keypair,
) -> Result<(), BanksClientError> {
    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts: accounts.to_account_metas(None),
        data: metavault::instruction::InitObligation {}.data(),
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    let tx = ctx
        .create_transaction_with_payer([cu_ix, main_ix], admin)
        .await;
    send_transaction!(ctx, tx)
}

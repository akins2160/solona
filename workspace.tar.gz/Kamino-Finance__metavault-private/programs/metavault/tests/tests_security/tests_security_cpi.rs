use anchor_lang::{InstructionData, ToAccountMetas};
use kamino_lending::send_transaction;
use metavault::{
    metavault_error,
    program_test::{
        client,
        fixtures::{setup_markets_and_reserves_with_dependencies, ProgramDependency},
        test_cpi_caller::TEST_CPI_CALLER_ID,
    },
    KaminoVaultError, VaultConfigField,
};
use solana_program_test::tokio;
use solana_sdk::{
    instruction::{AccountMeta, Instruction},
    signer::Signer,
};

#[tokio::test]
async fn test_security_blocks_cpi_calls() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves_with_dependencies(
        1,
        Some(vec![ProgramDependency::TestCpiCaller]),
        None,
    )
    .await;

    client::try_refresh_vault(&mut ctx, &vault, &owner)
        .await
        .unwrap();

    let scope_and_obligation_accounts =
        client::get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
    let mut inner_accounts = metavault::accounts::RefreshVault {
        vault_state: vault.vault_state.pubkey(),
        instruction_sysvar_account: solana_sdk::sysvar::instructions::ID,
        event_authority: metavault::program_test::event_authority_pda(),
        program: metavault::ID,
    }
    .to_account_metas(None);
    inner_accounts.extend(
        scope_and_obligation_accounts
            .into_iter()
            .map(|account| AccountMeta::new_readonly(account, false)),
    );

    let inner_ix = Instruction {
        program_id: metavault::ID,
        accounts: inner_accounts,
        data: metavault::instruction::RefreshVault {}.data(),
    };

    let mut cpi_accounts = Vec::with_capacity(inner_ix.accounts.len() + 1);
    cpi_accounts.push(AccountMeta::new_readonly(metavault::ID, false));
    cpi_accounts.extend(inner_ix.accounts);

    let mut cpi_data = Vec::with_capacity(inner_ix.data.len() + 1);
    cpi_data.push(0);
    cpi_data.extend(inner_ix.data);

    let cpi_ix = Instruction {
        program_id: TEST_CPI_CALLER_ID,
        accounts: cpi_accounts,
        data: cpi_data,
    };

    let tx = ctx.create_transaction_with_payer([cpi_ix], &owner).await;
    let res = send_transaction!(ctx, tx);

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::CpiDisabled)
    );
}

/// The CPI restriction covers the instructions anyone can call. Administration must stay
/// reachable through CPI, because that is how an on-chain multisig (Squads and similar) executes
/// an approved instruction — from a vault PDA, one stack frame down.
#[tokio::test]
async fn test_security_allows_cpi_calls_to_administrative_instructions() {
    let (mut ctx, vault, owner, _investor, _mkts) = setup_markets_and_reserves_with_dependencies(
        1,
        Some(vec![ProgramDependency::TestCpiCaller]),
        None,
    )
    .await;

    let new_slippage_bps = 42u64;
    let inner_ix = Instruction {
        program_id: metavault::ID,
        accounts: metavault::accounts::UpdateVaultConfig {
            vault_admin_authority: owner.pubkey(),
            vault_state: vault.vault_state.pubkey(),
            instruction_sysvar_account: solana_sdk::sysvar::instructions::ID,
        }
        .to_account_metas(None),
        data: metavault::instruction::UpdateVaultConfig {
            entry: VaultConfigField::MaxRebalanceSwapSlippageBps,
            data: new_slippage_bps.to_le_bytes().to_vec(),
        }
        .data(),
    };

    let mut cpi_accounts = Vec::with_capacity(inner_ix.accounts.len() + 1);
    cpi_accounts.push(AccountMeta::new_readonly(metavault::ID, false));
    cpi_accounts.extend(inner_ix.accounts);

    let mut cpi_data = Vec::with_capacity(inner_ix.data.len() + 1);
    cpi_data.push(0);
    cpi_data.extend(inner_ix.data);

    let cpi_ix = Instruction {
        program_id: TEST_CPI_CALLER_ID,
        accounts: cpi_accounts,
        data: cpi_data,
    };

    let tx = ctx.create_transaction_with_payer([cpi_ix], &owner).await;
    send_transaction!(ctx, tx).unwrap();

    assert_eq!(
        vault
            .state(&mut ctx)
            .await
            .rebalance_limits
            .max_fill_slippage_bps,
        new_slippage_bps
    );
}

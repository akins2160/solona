use anchor_lang::{error::ErrorCode, system_program::System, Id};
use anchor_spl::token::Token;
use kamino_lending::{anchor_error, program_test::common::types::TestContext, utils::FULL_BPS};
use metavault::{
    metavault_error,
    order::DepositOrder,
    program_test::{
        client::{
            deposit_order_pda, deposit_order_state, get_ordered_scope_accounts,
            get_ordered_scope_and_obligation_accounts, order_payout_accounts,
            order_token_accounts_and_amounts, skip, try_send_ix, usdc_holder,
            UpdateVaultConfigParams,
        },
        fixtures, instructions, VaultAccounts, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::{
    instruction::Instruction, pubkey::Pubkey, signer::Signer, sysvar::instructions as sysvar,
};

const USDC: u64 = 1_000_000;
const HOUR: u64 = 3600;

// Test cases:
// open_deposit_order:
// - [x] Wrong deposit order (another id's PDA)
// - [x] Wrong system program
// - [x] Wrong instruction sysvar
// - [x] Working case
// settle_deposit_order:
// - [x] Wrong global config
// - [x] Wrong base vault authority
// - [x] Wrong shares mint
// - [x] Wrong vault state (not the order's)
// - [x] Wrong owner (not the order's)
// - [x] Wrong owner shares ata mint
// - [x] Wrong owner shares ata authority
// - [x] Wrong shares token program
// - [x] Working case (permissionless)
// cancel_deposit_order:
// - [x] Wrong base vault authority
// - [x] Wrong vault state (not the order's)
// - [x] Wrong owner (a signer other than the order's owner)
// - [x] Working case

#[tokio::test]
async fn test_security_open_deposit_order() {
    let (mut ctx, vault, _lp) = setup().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    let ix = open_ix(&mut ctx, &vault, &depositor, order).await;

    // - [x] Wrong deposit order (another id's PDA)
    {
        let wrong_order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 1);
        let res = try_send_ix(
            &mut ctx,
            &depositor.owner,
            replaced(&ix, order, wrong_order),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [x] Wrong system program
    {
        let wrong_ix = replaced(&ix, System::id(), Token::id());
        let res = try_send_ix(&mut ctx, &depositor.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::InvalidProgramId, 1)
        );
    }

    // - [x] Wrong instruction sysvar
    {
        let wrong_ix = replaced(&ix, sysvar::ID, Pubkey::new_unique());
        let res = try_send_ix(&mut ctx, &depositor.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 1)
        );
    }

    // - [x] Working case
    try_send_ix(&mut ctx, &depositor.owner, ix).await.unwrap();
    assert_eq!(
        deposit_order_state(&mut ctx, order).await.base.owner,
        depositor.owner.pubkey()
    );
}

#[tokio::test]
async fn test_security_settle_deposit_order() {
    let (mut ctx, vault, lp) = setup().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    let open = open_ix(&mut ctx, &vault, &depositor, order).await;
    try_send_ix(&mut ctx, &depositor.owner, open).await.unwrap();
    skip(&mut ctx, &vault, HOUR + 1).await;
    let cranker = usdc_holder(&mut ctx, &vault, 0).await;
    let ix = settle_ix(&mut ctx, &cranker, &vault, order, depositor.shares_ata).await;

    // - [x] Wrong global config
    {
        let wrong_global_config = Pubkey::new_unique();
        ctx.clone_account(vault.global_config, &wrong_global_config)
            .await;
        let wrong_ix = replaced(&ix, vault.global_config, wrong_global_config);
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [x] Wrong base vault authority
    {
        let wrong_ix = replaced(&ix, vault.base_vault_authority, Pubkey::new_unique());
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [x] Wrong shares mint
    {
        let wrong_shares_mint = Pubkey::new_unique();
        ctx.clone_account(vault.shares_mint, &wrong_shares_mint)
            .await;
        let wrong_ix = replaced(&ix, vault.shares_mint, wrong_shares_mint);
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [x] Wrong vault state (not the order's)
    {
        let wrong_vault_state = cloned(&mut ctx, vault.vault_state.pubkey()).await;
        let wrong_ix = replaced(&ix, vault.vault_state.pubkey(), wrong_vault_state);
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Wrong owner (not the order's)
    {
        let wrong_ix = replaced(&ix, depositor.owner.pubkey(), lp.owner.pubkey());
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Wrong owner shares ata mint
    {
        let wrong_ix = replaced(&ix, depositor.shares_ata, depositor.token_atas["USDC"]);
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 1)
        );
    }

    // - [x] Wrong owner shares ata authority
    {
        let wrong_ix = replaced(&ix, depositor.shares_ata, lp.shares_ata);
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
        );
    }

    // - [x] Wrong shares token program
    {
        let wrong_ix = replaced(&ix, vault.shares_token_program, Token::id());
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::InvalidProgramId, 1)
        );
    }

    // - [x] Working case (permissionless)
    try_send_ix(&mut ctx, &cranker.owner, ix).await.unwrap();
    assert!(ctx.get_account(order).await.unwrap().is_none());
}

#[tokio::test]
async fn test_security_cancel_deposit_order() {
    let (mut ctx, vault, lp) = setup().await;
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let order = deposit_order_pda(&vault, &depositor.owner.pubkey(), 0);
    let open = open_ix(&mut ctx, &vault, &depositor, order).await;
    try_send_ix(&mut ctx, &depositor.owner, open).await.unwrap();
    let ix = cancel_ix(&mut ctx, &depositor, &vault, order).await;

    // - [x] Wrong base vault authority
    {
        let wrong_ix = replaced(&ix, vault.base_vault_authority, Pubkey::new_unique());
        let res = try_send_ix(&mut ctx, &depositor.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [x] Wrong vault state (not the order's)
    {
        let wrong_vault_state = cloned(&mut ctx, vault.vault_state.pubkey()).await;
        let wrong_ix = replaced(&ix, vault.vault_state.pubkey(), wrong_vault_state);
        let res = try_send_ix(&mut ctx, &depositor.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Wrong owner (a signer other than the order's owner)
    {
        let wrong_ix = replaced(&ix, depositor.owner.pubkey(), lp.owner.pubkey());
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Working case
    try_send_ix(&mut ctx, &depositor.owner, ix).await.unwrap();
    assert!(ctx.get_account(order).await.unwrap().is_none());
}

async fn setup() -> (TestContext, VaultAccounts, VaultDepositorAccounts) {
    fixtures::setup_balanced_vault(vec![
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderFillEnabled(true),
        UpdateVaultConfigParams::DepositOrderSettleEnabled(true),
    ])
    .await
}

// A 100 USDC order at `order` (the owner's PDA for id 0), with every account in place.
async fn open_ix(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    order: Pubkey,
) -> Instruction {
    let (amounts, per_token) =
        order_token_accounts_and_amounts(ctx, vault, depositor, &[("USDC", 100 * USDC)]).await;
    let scope_accounts = get_ordered_scope_accounts(ctx, vault).await;
    instructions::open_deposit_order_ix(
        vault,
        depositor,
        order,
        0,
        &per_token,
        amounts,
        HOUR,
        0,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
        scope_accounts,
    )
}

async fn settle_ix(
    ctx: &mut TestContext,
    signer: &VaultDepositorAccounts,
    vault: &VaultAccounts,
    order: Pubkey,
    owner_shares_ata: Pubkey,
) -> Instruction {
    let state: DepositOrder = deposit_order_state(ctx, order).await;
    let per_token = order_payout_accounts(ctx, vault, &state).await;
    let aum_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    instructions::settle_deposit_order_ix(
        &signer.owner,
        vault,
        order,
        state.base.owner,
        owner_shares_ata,
        aum_accounts,
        &per_token,
    )
}

async fn cancel_ix(
    ctx: &mut TestContext,
    owner: &VaultDepositorAccounts,
    vault: &VaultAccounts,
    order: Pubkey,
) -> Instruction {
    let state = deposit_order_state(ctx, order).await;
    let per_token = order_payout_accounts(ctx, vault, &state).await;
    instructions::cancel_deposit_order_ix(&owner.owner, vault, order, &per_token)
}

// A copy of the account at `address`, at a fresh one.
async fn cloned(ctx: &mut TestContext, address: Pubkey) -> Pubkey {
    let copy = Pubkey::new_unique();
    ctx.clone_account(address, &copy).await;
    copy
}

// `ix` with its first account at `from` moved to `to`.
fn replaced(ix: &Instruction, from: Pubkey, to: Pubkey) -> Instruction {
    let mut ix = ix.clone();
    let meta = ix
        .accounts
        .iter_mut()
        .find(|meta| meta.pubkey == from)
        .expect("the instruction names the account to replace");
    meta.pubkey = to;
    ix
}

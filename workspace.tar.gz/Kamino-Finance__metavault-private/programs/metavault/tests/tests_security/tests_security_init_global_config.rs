use anchor_lang::error::ErrorCode;
use anchor_lang::system_program::System;
use anchor_lang::Id;
use anchor_lang::InstructionData;
use anchor_lang::ToAccountMetas;
use kamino_lending::anchor_error;
use kamino_lending::program_test::common::math::sol_decimal_to_u64;
use kamino_lending::program_test::common::runner::test;
use kamino_lending::program_test::common::setup;
use kamino_lending::program_test::common::setup::funded_kp;
use kamino_lending::program_test::common::types::TestContext;
use kamino_lending::send_transaction;
use metavault::program_test::fixtures;
use metavault::utils::pda;
use solana_program_test::tokio;
use solana_program_test::BanksClientError;
use solana_sdk::instruction::{Instruction, InstructionError};
use solana_sdk::pubkey::Pubkey;
use solana_sdk::rent::Rent;
use solana_sdk::signature::Keypair;
use solana_sdk::signer::Signer;
use solana_sdk::sysvar::SysvarId;
use solana_sdk::transaction::TransactionError;

// - [x] Wrong program data account
// - [x] Global config already initialized
// - [x] Wrong global config pubkey
// - [x] Working case

async fn init_global_config_with_custom_accs(
    ctx: &mut TestContext,
    accounts: impl ToAccountMetas,
    payer: &Keypair,
) -> Result<(), BanksClientError> {
    let ix_data = metavault::instruction::InitGlobalConfig {}.data();

    let instruction = Instruction {
        program_id: metavault::id(),
        accounts: accounts.to_account_metas(None),
        data: ix_data,
    };

    let tx = ctx
        .create_transaction_with_payer([instruction], payer)
        .await;

    send_transaction!(ctx, tx)
}

fn base_accounts(payer: Pubkey) -> metavault::accounts::InitGlobalConfig {
    metavault::accounts::InitGlobalConfig {
        payer,
        global_config: pda::global_config(),
        program_data: pda::program_data(),
        system_program: System::id(),
        rent: Rent::id(),
        instruction_sysvar_account: solana_sdk::sysvar::instructions::ID,
    }
}

#[tokio::test]
async fn test_security_init_global_config() {
    let mut program = fixtures::program();

    let initial_market_owner = funded_kp(&mut program, sol_decimal_to_u64(10000.0));

    setup::create_program_data_account(&mut program, metavault::ID, initial_market_owner.pubkey());

    let mut ctx = test::start(program, &initial_market_owner).await;

    // - [x] Wrong program data account
    {
        let wrong_program_data = Pubkey::new_unique();
        ctx.clone_account(pda::program_data(), &wrong_program_data)
            .await;
        let accounts = metavault::accounts::InitGlobalConfig {
            program_data: wrong_program_data,
            ..base_accounts(initial_market_owner.pubkey())
        };
        let res =
            init_global_config_with_custom_accs(&mut ctx, accounts, &initial_market_owner).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress)
        );
    }

    // - [x] Wrong global config pubkey
    {
        let wrong_global_config = Pubkey::new_unique();
        let accounts = metavault::accounts::InitGlobalConfig {
            global_config: wrong_global_config,
            ..base_accounts(initial_market_owner.pubkey())
        };
        let res =
            init_global_config_with_custom_accs(&mut ctx, accounts, &initial_market_owner).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds)
        );
    }

    // - [x] Working case
    {
        init_global_config_with_custom_accs(
            &mut ctx,
            base_accounts(initial_market_owner.pubkey()),
            &initial_market_owner,
        )
        .await
        .unwrap();
    }

    // - [x] Global config already initialized
    {
        let res = init_global_config_with_custom_accs(
            &mut ctx,
            base_accounts(initial_market_owner.pubkey()),
            &initial_market_owner,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            TransactionError::InstructionError(0, InstructionError::Custom(0)), // sadly, this is how "account already-in-use" is surfaced
        );
    }
}

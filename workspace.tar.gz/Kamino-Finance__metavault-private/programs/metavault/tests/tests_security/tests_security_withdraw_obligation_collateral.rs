use anchor_lang::{error::ErrorCode, Id, InstructionData, ToAccountMetas};
use anchor_spl::{token::Token, token_2022::Token2022};
use kamino_lending::{
    anchor_error,
    program_test::common::{
        runner::state,
        setup::{new_borrower_accounts_with_obligation, update_reserve},
        types::{
            LendingMarketAccounts, MSpec, MarketsSpec, MintSpec, RSpec, ReserveAccounts,
            TestContext,
        },
    },
    send_transaction, Reserve,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, get_ordered_scope_and_obligation_accounts, init_obligation},
        event_authority_pda,
        fixtures::setup_markets_with_weights,
        instructions::{
            build_klend_refresh_obligation_ix, build_klend_refresh_reserve_ix,
            vault_obligation_pda, FARMS_PROGRAM_ID,
        },
        VaultAccounts, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction,
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    signature::Keypair,
    signer::Signer,
    sysvar::instructions as sysvar_instructions,
};

// Test cases:
// - [x] Wrong vault_admin_authority
// - [x] Wrong base_vault_authority
// - [x] Wrong obligation (real klend obligation, owned by a non-vault borrower)
// - [x] Wrong obligation pubkey in AUM remaining_accounts
// - [x] Reserve scope_configuration diverges from vault token's
// - [x] Wrong token_vault
// - [x] Wrong reserve_liquidity_mint (via wrong reserve struct)
// - [x] Liquidity mint not the reserve's
// - [x] Reserve token accounts not the reserve's
// - [x] Lending market not the obligation's
// - [x] Wrong lending_market_authority
// - [x] Wrong farms_program
// - [x] Wrong lending_program
// - [x] Token program not the token_vault's
// - [x] Working case

#[tokio::test]
async fn test_security_withdraw_obligation_collateral() {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        client::UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    // - [ ] Wrong vault_admin_authority
    {
        let stranger = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let res = client::try_withdraw_obligation_collateral(
            &mut ctx,
            &stranger,
            &vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            500_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect, 3)
        );
    }

    // - [ ] Wrong base_vault_authority
    {
        let wrong_bva = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_bva.pubkey();
        let res = client::try_withdraw_obligation_collateral(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            500_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 3)
        );
    }

    // - [ ] Wrong obligation
    // klend-valid obligation owned by an unrelated borrower (not registered in this vault).
    {
        let stranger_borrower = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let res = client::try_withdraw_obligation_collateral(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve,
            stranger_borrower.obligation,
            "SOL",
            500_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ObligationSlotNotFound, 3)
        );
    }

    // - [ ] Reserve scope_configuration diverges from vault token's
    {
        let mut reserve = state::get::<Reserve>(&mut ctx, sol_reserve.address.pubkey()).await;
        let original_chain = reserve.config.token_info.scope_configuration.price_chain;
        reserve.config.token_info.scope_configuration.price_chain[0] = u16::MAX - 1;
        update_reserve(&mut ctx, &reserve, &sol_reserve.address.pubkey()).await;
        let res = client::try_withdraw_obligation_collateral(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            500_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveScopeMismatch, 3),
        );
        reserve.config.token_info.scope_configuration.price_chain = original_chain;
        update_reserve(&mut ctx, &reserve, &sol_reserve.address.pubkey()).await;
    }

    // - [ ] Wrong token_vault
    {
        let wrong_token_vault = Pubkey::new_unique();
        ctx.clone_account(vault.vault_tokens["SOL"].token_vault, &wrong_token_vault)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.vault_tokens.get_mut("SOL").unwrap().token_vault = wrong_token_vault;
        let res = client::try_withdraw_obligation_collateral(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            500_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong reserve_liquidity_mint
    {
        let res = client::try_withdraw_obligation_collateral(
            &mut ctx,
            &admin,
            &vault,
            market,
            &usdc_reserve, // wrong reserve (USDC where SOL expected)
            obligation_pk,
            "SOL",
            500_000_000,
            vec![],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong obligation pubkey in AUM remaining_accounts
    {
        let stranger = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let mut scope_and_obligation =
            get_ordered_scope_and_obligation_accounts(&mut ctx, &vault).await;
        *scope_and_obligation.last_mut().unwrap() = stranger.obligation;
        let mut metas = base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
            .to_account_metas(None);
        for acc in scope_and_obligation {
            metas.push(AccountMeta::new_readonly(acc, false));
        }
        let main_ix = Instruction {
            program_id: metavault::ID,
            accounts: metas,
            data: metavault::instruction::WithdrawObligationCollateral {
                collateral_amount: 500_000_000,
            }
            .data(),
        };
        let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
        let tx = ctx
            .create_transaction_with_payer(
                vec![
                    cu_ix,
                    build_klend_refresh_reserve_ix(&sol_reserve),
                    build_klend_refresh_obligation_ix(
                        obligation_pk,
                        market.market.pubkey(),
                        &[],
                        &[],
                    ),
                    main_ix,
                ],
                &admin,
            )
            .await;
        let res = send_transaction!(ctx, tx);
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::RemainingAccountKeyMismatch, 3),
        );
    }

    // - [ ] Liquidity mint not the reserve's (the other token's mint and token vault, the other
    // token's scope config on the reserve)
    {
        // The reserve takes the other token's scope config, so only the mint pin can reject:
        let mut reserve = state::get::<Reserve>(&mut ctx, sol_reserve.address.pubkey()).await;
        let other_reserve = state::get::<Reserve>(&mut ctx, usdc_reserve.address.pubkey()).await;
        let original_scope = reserve.config.token_info.scope_configuration;
        reserve.config.token_info.scope_configuration =
            other_reserve.config.token_info.scope_configuration;
        update_reserve(&mut ctx, &reserve, &sol_reserve.address.pubkey()).await;
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            reserve_liquidity_mint: usdc_reserve.liquidity_mint.pubkey(),
            token_vault: vault.vault_tokens["USDC"].token_vault,
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
        reserve.config.token_info.scope_configuration = original_scope;
        update_reserve(&mut ctx, &reserve, &sol_reserve.address.pubkey()).await;
    }

    // - [ ] Lending market not the obligation's (a copy of it at another address)
    {
        let foreign_market = Pubkey::new_unique();
        ctx.clone_account(market.market.pubkey(), &foreign_market)
            .await;
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            lending_market: foreign_market,
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::LendingMarketMismatch, 3)
        );
    }

    // - [ ] `reserve_source_collateral` not the reserve's (the other reserve's)
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            reserve_source_collateral: usdc_reserve.collateral_supply,
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
    }

    // - [ ] `reserve_collateral_mint` not the reserve's (the other reserve's)
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            reserve_collateral_mint: usdc_reserve.collateral_mint,
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
    }

    // - [ ] `reserve_liquidity_supply` not the reserve's (the other reserve's)
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            reserve_liquidity_supply: usdc_reserve.liquidity_supply,
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ReserveAccountMismatch, 3)
        );
    }

    // - [ ] Wrong lending_market_authority (not the market's PDA)
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            lending_market_authority: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 3)
        );
    }

    // - [ ] Wrong farms_program
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            farms_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Token program not the token_vault's
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            liquidity_token_program: Token2022::id(),
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenTokenProgram, 3)
        );
    }

    // - [ ] Wrong lending_program
    {
        let accounts = metavault::accounts::WithdrawObligationCollateral {
            lending_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, &sol_reserve, obligation_pk, "SOL")
        };
        let res = withdraw_obligation_collateral_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            &sol_reserve,
            obligation_pk,
            market,
            &vault,
            /* prelude_deposit_reserves */ vec![],
            /* prelude_borrow_reserves */ vec![],
            500_000_000,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Working case
    // Deposit collateral first so there's something to withdraw.
    {
        client::try_deposit_obligation_collateral(
            &mut ctx,
            &admin,
            &vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            5_000_000_000,
            vec![],
            vec![],
        )
        .await
        .unwrap();
        client::try_withdraw_obligation_collateral(
            &mut ctx,
            &allocation_admin,
            &vault,
            market,
            &sol_reserve,
            obligation_pk,
            "SOL",
            500_000_000,
            vec![&sol_reserve],
            vec![],
        )
        .await
        .unwrap();
    }
}

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

fn base_accounts(
    admin: &Keypair,
    vault: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
) -> metavault::accounts::WithdrawObligationCollateral {
    let vault_token = vault.vault_tokens.get(token_name).unwrap();
    metavault::accounts::WithdrawObligationCollateral {
        authority: admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        withdraw_reserve: reserve.address.pubkey(),
        reserve_liquidity_mint: reserve.liquidity_mint.pubkey(),
        reserve_source_collateral: reserve.collateral_supply,
        reserve_collateral_mint: reserve.collateral_mint,
        reserve_liquidity_supply: reserve.liquidity_supply,
        token_vault: vault_token.token_vault,
        collateral_token_program: Token::id(),
        liquidity_token_program: reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::id(),
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
}

#[allow(clippy::too_many_arguments)]
async fn withdraw_obligation_collateral_with_custom_accs(
    ctx: &mut TestContext,
    accounts: impl ToAccountMetas,
    admin: &Keypair,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    market: &LendingMarketAccounts,
    vault: &VaultAccounts,
    prelude_deposit_reserves: Vec<&ReserveAccounts>,
    prelude_borrow_reserves: Vec<&ReserveAccounts>,
    collateral_amount: u64,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    let mut metas = accounts.to_account_metas(None);
    for acc in scope_and_obligation_accounts {
        metas.push(AccountMeta::new_readonly(acc, false));
    }
    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts: metas,
        data: metavault::instruction::WithdrawObligationCollateral { collateral_amount }.data(),
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    let mut all_ixs = vec![cu_ix];
    all_ixs.push(build_klend_refresh_reserve_ix(reserve));
    for r in &prelude_deposit_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    for r in &prelude_borrow_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    all_ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        market.market.pubkey(),
        &prelude_deposit_reserves,
        &prelude_borrow_reserves,
    ));
    all_ixs.push(main_ix);
    let tx = ctx.create_transaction_with_payer(all_ixs, admin).await;
    send_transaction!(ctx, tx)
}

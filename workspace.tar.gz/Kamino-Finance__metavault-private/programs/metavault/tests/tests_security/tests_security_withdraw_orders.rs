use anchor_lang::{error::ErrorCode, system_program::System, Id};
use anchor_spl::token::Token;
use kamino_lending::{anchor_error, program_test::common::types::TestContext, utils::FULL_BPS};
use metavault::{
    metavault_error,
    program_test::{
        client::{
            dense_by_token_name, get_ordered_scope_accounts,
            get_ordered_scope_and_obligation_accounts, order_payout_accounts, skip, try_send_ix,
            usdc_holder, withdraw_order_pda, withdraw_order_state, UpdateVaultConfigParams,
        },
        fixtures, instructions, VaultAccounts, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::{instruction::Instruction, pubkey::Pubkey, signer::Signer};

const SHARE: u64 = 1_000_000;
const HOUR: u64 = 3600;

// Test cases:
// open_withdraw_order:
// - [x] Wrong global config
// - [x] Wrong withdraw order (another id's PDA)
// - [x] Wrong shares mint
// - [x] Wrong owner shares ata mint
// - [x] Wrong owner shares ata authority
// - [x] Wrong shares token program
// - [x] Wrong system program
// - [x] Working case
// settle_withdraw_order:
// - [x] Wrong base vault authority
// - [x] Wrong vault state (not the order's)
// - [x] Wrong owner (not the order's)
// - [x] Working case (permissionless)

#[tokio::test]
async fn test_security_open_withdraw_order() {
    let (mut ctx, vault, lp) = setup().await;
    let other = usdc_holder(&mut ctx, &vault, 0).await;
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);
    let ix = open_ix(&mut ctx, &vault, &lp, order).await;

    // - [x] Wrong global config
    {
        let wrong_global_config = cloned(&mut ctx, vault.global_config).await;
        let wrong_ix = replaced(&ix, vault.global_config, wrong_global_config);
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [x] Wrong withdraw order (another id's PDA)
    {
        let wrong_order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 1);
        let res = try_send_ix(&mut ctx, &lp.owner, replaced(&ix, order, wrong_order)).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintSeeds, 1)
        );
    }

    // - [x] Wrong shares mint
    {
        let wrong_shares_mint = cloned(&mut ctx, vault.shares_mint).await;
        let wrong_ix = replaced(&ix, vault.shares_mint, wrong_shares_mint);
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [x] Wrong owner shares ata mint
    {
        let wrong_ix = replaced(&ix, lp.shares_ata, lp.token_atas["USDC"]);
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenMint, 1)
        );
    }

    // - [x] Wrong owner shares ata authority
    {
        let wrong_ix = replaced(&ix, lp.shares_ata, other.shares_ata);
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
        );
    }

    // - [x] Wrong shares token program
    {
        let wrong_ix = replaced(&ix, vault.shares_token_program, Token::id());
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::InvalidProgramId, 1)
        );
    }

    // - [x] Wrong system program
    {
        let wrong_ix = replaced(&ix, System::id(), Token::id());
        let res = try_send_ix(&mut ctx, &lp.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::InvalidProgramId, 1)
        );
    }

    // - [x] Working case
    try_send_ix(&mut ctx, &lp.owner, ix).await.unwrap();
    assert_eq!(
        withdraw_order_state(&mut ctx, order).await.base.owner,
        lp.owner.pubkey()
    );
}

#[tokio::test]
async fn test_security_settle_withdraw_order() {
    let (mut ctx, vault, lp) = setup().await;
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);
    let open = open_ix(&mut ctx, &vault, &lp, order).await;
    try_send_ix(&mut ctx, &lp.owner, open).await.unwrap();
    skip(&mut ctx, &vault, HOUR + 1).await;
    let cranker = usdc_holder(&mut ctx, &vault, 0).await;
    let ix = settle_ix(&mut ctx, &cranker, &vault, order).await;

    // - [x] Wrong base vault authority
    {
        let wrong_ix = replaced(&ix, vault.base_vault_authority, Pubkey::new_unique());
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 1)
        );
    }

    // - [x] Wrong vault state (not the order's)
    {
        let wrong_vault_state = cloned(&mut ctx, vault.vault_state.pubkey()).await;
        let wrong_ix = replaced(&ix, vault.vault_state.pubkey(), wrong_vault_state);
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Wrong owner (not the order's)
    {
        let wrong_ix = replaced(&ix, lp.owner.pubkey(), cranker.owner.pubkey());
        let res = try_send_ix(&mut ctx, &cranker.owner, wrong_ix).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
        );
    }

    // - [x] Working case (permissionless)
    try_send_ix(&mut ctx, &cranker.owner, ix).await.unwrap();
    assert!(ctx.get_account(order).await.unwrap().is_none());
}

async fn setup() -> (TestContext, VaultAccounts, VaultDepositorAccounts) {
    fixtures::setup_balanced_vault(vec![
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(true),
        UpdateVaultConfigParams::WithdrawOrderFillEnabled(true),
    ])
    .await
}

// A 100-share order at `order` (the holder's PDA for id 0) into USDC, with every account in place.
async fn open_ix(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    order: Pubkey,
) -> Instruction {
    let weights = dense_by_token_name(ctx, vault, &[("USDC", 1)]).await;
    let no_minimums = vec![0; weights.len()];
    let aum_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault).await;
    instructions::open_withdraw_order_ix(
        vault,
        holder,
        order,
        0,
        100 * SHARE,
        weights,
        HOUR,
        no_minimums,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
        aum_accounts,
    )
}

// A settle by `signer` (not the owner, so with the prices).
async fn settle_ix(
    ctx: &mut TestContext,
    signer: &VaultDepositorAccounts,
    vault: &VaultAccounts,
    order: Pubkey,
) -> Instruction {
    let state = withdraw_order_state(ctx, order).await;
    let per_token = order_payout_accounts(ctx, vault, &state).await;
    let scope_accounts = get_ordered_scope_accounts(ctx, vault).await;
    instructions::settle_withdraw_order_ix(
        &signer.owner,
        vault,
        order,
        state.base.owner,
        scope_accounts,
        &per_token,
    )
}

// A copy of the account at `address`, at a fresh one.
async fn cloned(ctx: &mut TestContext, address: Pubkey) -> Pubkey {
    let copy = Pubkey::new_unique();
    ctx.clone_account(address, &copy).await;
    copy
}

// `ix` with its first account at `from` moved to `to`.
fn replaced(ix: &Instruction, from: Pubkey, to: Pubkey) -> Instruction {
    let mut ix = ix.clone();
    let meta = ix
        .accounts
        .iter_mut()
        .find(|meta| meta.pubkey == from)
        .expect("the instruction names the account to replace");
    meta.pubkey = to;
    ix
}

use anchor_lang::prelude::ErrorCode;
use kamino_lending::anchor_error;
use metavault::program_test::{
    client::{self, UpdateVaultConfigParams},
    fixtures,
};
use solana_program_test::tokio;

// Test cases:
// - [x] Wrong admin authority
// - [x] Working case

#[tokio::test]
async fn tests_security_give_up_pending_fees() {
    let (mut ctx, vault, vault_manager, investor, _mkts) =
        fixtures::setup_markets_and_reserves(1).await;

    // Test cases:
    // - [] Wrong admin authority
    {
        let res = client::try_give_up_pending_fees(&mut ctx, &vault, &investor.owner, 1).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne)
        );
    }

    // - [] Working case
    {
        client::update_vault_config(
            &mut ctx,
            &vault_manager,
            &vault,
            UpdateVaultConfigParams::BlockDeposits(true),
        )
        .await;
        client::try_give_up_pending_fees(&mut ctx, &vault, &vault_manager, 1)
            .await
            .unwrap();
    }
}

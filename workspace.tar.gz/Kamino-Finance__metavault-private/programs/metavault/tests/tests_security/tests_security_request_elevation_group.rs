use anchor_lang::{error::ErrorCode, InstructionData, ToAccountMetas};
use kamino_lending::{
    anchor_error,
    program_test::common::{
        fixtures::setup_reserves_with_elevation_groups,
        setup::new_borrower_accounts_with_obligation,
        types::{
            LendingMarketAccounts, MSpec, MarketsSpec, MintSpec, RSpec, ReserveAccounts,
            TestContext,
        },
    },
    send_transaction,
    state::ElevationGroup,
    Obligation,
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, init_obligation},
        event_authority_pda,
        fixtures::setup_markets_with_weights,
        instructions::{
            build_klend_refresh_obligation_ix, build_klend_refresh_reserve_ix, vault_obligation_pda,
        },
        VaultAccounts, VaultDepositorAccounts,
    },
    KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction, instruction::Instruction, pubkey::Pubkey,
    signature::Keypair, signer::Signer,
};

// Test cases:
// - [x] Wrong vault_admin_authority
// - [x] Wrong base_vault_authority
// - [x] Wrong obligation (real klend obligation, owned by a non-vault borrower)
// - [x] Lending market not the obligation's
// - [x] Wrong lending_program
// - [x] Forwarded reserves not the obligation's positions
// - [x] Working case

const TEST_ELEVATION_GROUP_ID: u8 = 1;

#[tokio::test]
async fn test_security_request_elevation_group() {
    let (mut ctx, markets, vault) = setup_markets_with_weights(&make_spec(), vec![5, 5]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = &markets.markets[0].primary_market;
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "SOL".to_string() => 10_000_000_000,
            "USDC".to_string() => 2_000_000_000,
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", 10_000_000_000).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", 2_000_000_000).await;
    init_obligation(&mut ctx, &admin, &vault, market, 0).await;
    let obligation_pk =
        vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    let allocation_admin = ctx
        .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
        .await;
    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        client::UpdateVaultConfigParams::AllocationAdminAuthority(allocation_admin.pubkey()),
    )
    .await;

    // Klend's entry guards require an obligation with deposits and a registered group on the
    // reserves.
    client::try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        market,
        &sol_reserve,
        obligation_pk,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    setup_reserves_with_elevation_groups(
        &mut ctx,
        &markets.markets[0],
        &["SOL", "USDC"],
        &[ElevationGroup {
            id: TEST_ELEVATION_GROUP_ID,
            max_liquidation_bonus_bps: 500,
            ltv_pct: 90,
            liquidation_threshold_pct: 95,
            allow_new_loans: 1,
            max_reserves_as_collateral: 1,
            debt_reserve: usdc_reserve.address.pubkey(),
            ..Default::default()
        }],
    )
    .await;

    // - [ ] Wrong vault_admin_authority
    {
        let stranger = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let res = client::try_request_elevation_group(
            &mut ctx,
            &stranger,
            &vault,
            market,
            obligation_pk,
            TEST_ELEVATION_GROUP_ID,
            vec![&sol_reserve],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::AllocationAuthorityIncorrect, 3)
        );
    }

    // - [ ] Wrong base_vault_authority
    {
        let wrong_bva = ctx
            .new_keypair(solana_sdk::native_token::LAMPORTS_PER_SOL)
            .await;
        let mut wrong_vault = vault.clone();
        wrong_vault.base_vault_authority = wrong_bva.pubkey();
        let res = client::try_request_elevation_group(
            &mut ctx,
            &admin,
            &wrong_vault,
            market,
            obligation_pk,
            TEST_ELEVATION_GROUP_ID,
            vec![&sol_reserve],
            vec![],
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintHasOne, 3)
        );
    }

    // - [ ] Wrong obligation
    // A klend-valid obligation owned by an unrelated borrower (NOT registered in this vault).
    // Skip the refresh prelude so the metavault handler is the first thing to touch it.
    {
        let stranger_borrower = new_borrower_accounts_with_obligation(
            &mut ctx,
            market,
            &sol_reserve,
            &usdc_reserve,
            &Pubkey::default(),
            0,
            0,
        )
        .await;
        let accounts = metavault::accounts::RequestElevationGroup {
            obligation: stranger_borrower.obligation,
            ..base_accounts(&admin, &vault, market, stranger_borrower.obligation)
        };
        let res = request_elevation_group_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            stranger_borrower.obligation,
            market,
            /* deposit_reserves */ vec![],
            /* borrow_reserves */ vec![],
            /* forwarded_reserves */ None,
            TEST_ELEVATION_GROUP_ID,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::ObligationSlotNotFound, 2)
        );
    }

    // - [ ] Lending market not the obligation's (a copy of it at another address)
    {
        let foreign_market = Pubkey::new_unique();
        ctx.clone_account(market.market.pubkey(), &foreign_market)
            .await;
        let accounts = metavault::accounts::RequestElevationGroup {
            lending_market: foreign_market,
            ..base_accounts(&admin, &vault, market, obligation_pk)
        };
        let res = request_elevation_group_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            obligation_pk,
            market,
            vec![&sol_reserve],
            vec![],
            /* forwarded_reserves */ None,
            TEST_ELEVATION_GROUP_ID,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::LendingMarketMismatch, 3)
        );
    }

    // - [ ] Wrong lending_program
    {
        let accounts = metavault::accounts::RequestElevationGroup {
            lending_program: Pubkey::new_unique(),
            ..base_accounts(&admin, &vault, market, obligation_pk)
        };
        let res = request_elevation_group_with_custom_accs(
            &mut ctx,
            accounts,
            &admin,
            obligation_pk,
            market,
            vec![&sol_reserve],
            vec![],
            /* forwarded_reserves */ None,
            TEST_ELEVATION_GROUP_ID,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            anchor_error!(ErrorCode::ConstraintAddress, 3)
        );
    }

    // - [ ] Forwarded reserves not the obligation's positions (another reserve, a missing one,
    // an extra one)
    for (forwarded_reserves, expected_error) in [
        (
            vec![usdc_reserve.address.pubkey()],
            KaminoVaultError::RemainingAccountKeyMismatch,
        ),
        (vec![], KaminoVaultError::ObligationAccountMissing),
        (
            vec![sol_reserve.address.pubkey(), usdc_reserve.address.pubkey()],
            KaminoVaultError::UnexpectedRemainingAccounts,
        ),
    ] {
        let res = request_elevation_group_with_custom_accs(
            &mut ctx,
            base_accounts(&allocation_admin, &vault, market, obligation_pk),
            &allocation_admin,
            obligation_pk,
            market,
            vec![&sol_reserve],
            vec![],
            Some(forwarded_reserves),
            TEST_ELEVATION_GROUP_ID,
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(expected_error, 3)
        );
    }

    // - [ ] Working case
    {
        client::request_elevation_group(
            &mut ctx,
            &allocation_admin,
            &vault,
            market,
            obligation_pk,
            TEST_ELEVATION_GROUP_ID,
            vec![&sol_reserve],
            vec![],
        )
        .await;
        let acct = ctx.get_account(obligation_pk).await.unwrap().unwrap();
        let obligation: &Obligation = bytemuck::from_bytes(&acct.data[8..]);
        assert_eq!(obligation.elevation_group, TEST_ELEVATION_GROUP_ID);
    }
}

fn make_spec() -> MarketsSpec {
    MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
        ])],
    }
}

fn base_accounts(
    admin: &Keypair,
    vault: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation: Pubkey,
) -> metavault::accounts::RequestElevationGroup {
    metavault::accounts::RequestElevationGroup {
        authority: admin.pubkey(),
        vault_state: vault.vault_state.pubkey(),
        base_vault_authority: vault.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_program: kamino_lending::ID,
        instruction_sysvar_account: solana_sdk::sysvar::instructions::ID,
        event_authority: event_authority_pda(),
        program: metavault::ID,
    }
}

#[allow(clippy::too_many_arguments)]
async fn request_elevation_group_with_custom_accs(
    ctx: &mut TestContext,
    accounts: impl ToAccountMetas,
    admin: &Keypair,
    obligation: Pubkey,
    market: &LendingMarketAccounts,
    deposit_reserves: Vec<&ReserveAccounts>,
    borrow_reserves: Vec<&ReserveAccounts>,
    forwarded_reserves: Option<Vec<Pubkey>>,
    new_elevation_group: u8,
) -> Result<(), BanksClientError> {
    use kamino_lending::writable;
    let mut metas = accounts.to_account_metas(None);
    let forwarded_reserves = forwarded_reserves.unwrap_or_else(|| {
        deposit_reserves
            .iter()
            .chain(&borrow_reserves)
            .map(|r| r.address.pubkey())
            .collect()
    });
    for r in forwarded_reserves {
        metas.push(writable!(r));
    }
    let main_ix = Instruction {
        program_id: metavault::ID,
        accounts: metas,
        data: metavault::instruction::RequestElevationGroup {
            new_elevation_group,
        }
        .data(),
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    let mut all_ixs = vec![cu_ix];
    if let Some(target) = deposit_reserves.first() {
        all_ixs.push(build_klend_refresh_reserve_ix(target));
    }
    for r in deposit_reserves.iter().skip(1) {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    for r in &borrow_reserves {
        all_ixs.push(build_klend_refresh_reserve_ix(r));
    }
    all_ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        market.market.pubkey(),
        &deposit_reserves,
        &borrow_reserves,
    ));
    all_ixs.push(main_ix);
    let tx = ctx.create_transaction_with_payer(all_ixs, admin).await;
    send_transaction!(ctx, tx)
}

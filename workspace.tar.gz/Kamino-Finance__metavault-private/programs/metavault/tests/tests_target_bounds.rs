use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::program_test::common::{
    math::{sol_decimal_to_u64, usdc_decimal_to_u64},
    types::{MSpec, MarketsSpec, MintSpec, RSpec},
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, try_update_vault_config, update_vault_config, UpdateVaultConfigParams},
        fixtures::{setup_markets, setup_markets_and_reserves, setup_markets_with_weights},
        setup,
    },
    KaminoVaultError,
};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;
use usdc_decimal_to_u64 as usdc;

/// Admin can read back `max_deviation_bps` after setting it per-token.
#[tokio::test]
async fn test_set_and_read_max_deviation_bps() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
        ])],
    })
    .await;

    let owner = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 750),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    let usdc_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == usdc_mint)
        .unwrap();
    assert_eq!(usdc_token.max_deviation_bps, 750);
}

/// Setting `max_deviation_bps` above 10_000 must be rejected.
#[tokio::test]
async fn test_update_max_deviation_bps_rejects_above_cap() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! { "USDC".to_string() => MintSpec::spl(6, 1.0) },
        markets: vec![MSpec::new(vec![RSpec::new("USDC", 0)])],
    })
    .await;
    let owner = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    let res = try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 10_001),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSValueTooBig, 1)
    );
}

/// The 10_000 bps cap is inclusive.
#[tokio::test]
async fn test_update_max_deviation_bps_accepts_exact_cap() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! { "USDC".to_string() => MintSpec::spl(6, 1.0) },
        markets: vec![MSpec::new(vec![RSpec::new("USDC", 0)])],
    })
    .await;
    let owner = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 10_000),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    let usdc_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == usdc_mint)
        .unwrap();
    assert_eq!(usdc_token.max_deviation_bps, 10_000);
}

/// End-to-end: after skewing the vault so USDC is above its upper bound, depositing more USDC
/// fails with the new `TargetBoundExceeded` error.
#[tokio::test]
async fn test_deposit_errors_when_above_target_bound() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // 1) Seed the vault with heavy USDC + tiny SOL BEFORE any bound is set so the skew is
    //    established without being blocked by the clamp we're about to introduce.
    let depositor_usdc =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(500_000.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(1.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(0.01),
    )
    .await;

    // 2) Now set equal target weights and a tight 1% bound → upper = 0.51.
    //    USDC's actual weight sits at ~99.999% → well above the bound.
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 100),
    )
    .await;

    // 3) Further USDC deposits must fail.
    let res = client::try_deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(10.0), 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TargetBoundExceeded, 1),
    );
}

/// Being outside the upper bound only blocks deposits into that overweight token; depositing the
/// underweight token is the intended way to move the vault back toward target.
#[tokio::test]
async fn test_deposit_underweight_token_succeeds_when_sibling_above_upper() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    let depositor_usdc =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(500_000.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(2.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(0.01),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 100),
    )
    .await;

    let before = depositor_sol.balances(&mut ctx).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(0.01),
    )
    .await;
    let after = depositor_sol.balances(&mut ctx).await;

    let deducted = before.tokens["SOL"] - after.tokens["SOL"];
    // Requested 0.01 SOL = 10_000_000 lamports. SOL is the underweight token here so the clamp
    // does not fire; the 9-lamport shortfall is the vault-favorable Fraction quantization loss
    // that accumulates through the scope-price AUM round-trip.
    assert_eq!(deducted, 9_999_991);
}

/// End-to-end: after skewing the vault so USDC is below its lower bound, withdrawing USDC fails
/// with the new error.
#[tokio::test]
async fn test_withdraw_errors_when_below_target_bound() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Skew first, THEN set tight bounds — otherwise the bound would block the setup deposits.
    let depositor_usdc = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(1.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(1_000.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(500.0),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 100),
    )
    .await;

    // USDC is below lower bound; a withdraw attempt must fail.
    let res = client::try_withdraw(&mut ctx, &vault, &depositor_usdc, 1_000, "USDC", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TargetBoundExceeded, 1),
    );
}

/// Being above the upper bound does not block a withdraw from that token, because the withdraw
/// moves the token weight back toward target and is governed by the lower bound.
#[tokio::test]
async fn test_withdraw_overweight_token_succeeds_when_above_upper() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    let depositor_usdc =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(500_000.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(1.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(0.01),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 100),
    )
    .await;

    let before = depositor_usdc.balances(&mut ctx).await;
    client::withdraw(&mut ctx, &vault, &depositor_usdc, usdc(10.0), "USDC").await;
    let after = depositor_usdc.balances(&mut ctx).await;

    assert_eq!(after.tokens["USDC"] - before.tokens["USDC"], usdc(10.0));
    assert_eq!(before.shares - after.shares, usdc(10.0));
}

/// When the bound is disabled (0), deposit behaves as before — no clamping, no new errors.
#[tokio::test]
async fn test_deposit_succeeds_when_bound_disabled() {
    let (mut ctx, vault, _owner, _investor, _mkts) = setup_markets_and_reserves(1).await;
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(50.0)).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], usdc(50.0));
    // Standard 1-lamport vault-favorable rounding loss.
    assert_eq!(balances_after.shares, usdc(50.0) - 1);
}

/// A request 10x above the bound succeeds but is silently clamped — the depositor's ATA is
/// debited only by the bound amount. End-to-end sanity for the silent-clamp path.
#[tokio::test]
async fn test_deposit_silently_clamps_to_bound() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Seed 50/50 in USD terms: $100 of USDC and $100 of SOL (at $100/SOL).
    let depositor_usdc = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(100.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(10.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(1.0),
    )
    .await;

    // Weights 1:1; 10% deviation on both tokens → upper_usdc = 0.6.
    // bound_max = (0.6 * 200 - 100) / (1 - 0.6) = $50 ⇒ 50 USDC.
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    let balances_before = depositor_usdc.balances(&mut ctx).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(500.0)).await;
    let balances_after = depositor_usdc.balances(&mut ctx).await;

    // Vault init pre-seeds INITIAL_DEPOSIT_SIZE=1000 USDC lamports on the first token, so the
    // pre-clamp total AUM is $200.001 (not $200) and the exact bound resolves to $49.999 =
    // 49_998_999 USDC lamports.
    let deducted = balances_before.tokens["USDC"] - balances_after.tokens["USDC"];
    assert_eq!(deducted, 49_998_999);
}

/// The silent deposit clamp must still respect `min_shares_out`; callers can reject a clipped
/// deposit by setting slippage against the amount they expected to deposit.
#[tokio::test]
async fn test_deposit_clamp_respects_min_shares_out() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;
    let depositor_usdc = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(100.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(10.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(1.0),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    let res = client::try_deposit(
        &mut ctx,
        &vault,
        &depositor_usdc,
        "USDC",
        usdc(500.0),
        usdc(100.0),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );
}

/// A withdraw request above the lower-bound allowance succeeds but sends only the bounded amount.
#[tokio::test]
async fn test_withdraw_silently_clamps_to_bound() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "SOL".to_string() => sol_decimal_to_u64(10.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", sol_decimal_to_u64(1.0)).await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    let balances_before = depositor.balances(&mut ctx).await;
    client::withdraw(&mut ctx, &vault, &depositor, balances_before.shares, "USDC").await;
    let balances_after = depositor.balances(&mut ctx).await;

    let received = balances_after.tokens["USDC"] - balances_before.tokens["USDC"];
    // Weights 1:1, dev 10%, post-seed total AUM ≈ $200.001 (USDC $100.001 + SOL $100 at $100/SOL).
    // USDC lower bound = 0.4 → max_withdraw_aum = (100.001 - 0.4*200.001)/0.6 ≈ $33.3343...,
    // floor to 33_334_333 USDC lamports. Remaining shares = total_shares - burned ≈ 166_665_665.
    assert_eq!(received, 33_334_333);
    assert_eq!(balances_after.shares, 166_665_665);
}

/// The silent withdraw clamp must still respect `min_tokens_out`.
#[tokio::test]
async fn test_withdraw_clamp_respects_min_tokens_out() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "SOL".to_string() => sol_decimal_to_u64(10.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", sol_decimal_to_u64(1.0)).await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    let balances_before = depositor.balances(&mut ctx).await;
    let res = client::try_withdraw(
        &mut ctx,
        &vault,
        &depositor,
        balances_before.shares,
        "USDC",
        usdc(90.0),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );
}

/// With a non-zero deposit fee AND an active target-weight bound, the bound remains strict:
/// because fees are donated into the vault, both numerator and denominator of the weight
/// ratio grow by the full gross amount, so the resulting USDC weight stays at or below the
/// upper bound. Cross-multiplied integer check — no f64 tolerance.
#[tokio::test]
async fn test_deposit_bound_with_deposit_fee() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    let depositor_usdc = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(100.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(10.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(1.0),
    )
    .await;

    // 1% USDC deposit fee + 10% target-weight bound + weights 1:1.
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(500.0)).await;

    // USDC is 6 dec at $1, SOL is 9 dec at $100 — scale both to pico-USD (10^-12 USD) so the
    // integer inequality is exact:
    //   usdc_pico = usdc_lamports * 10^6     (1 lamport = $10^-6 = 10^6 pico-USD)
    //   sol_pico  = sol_lamports  * 10^5     (1 lamport = $100 / 10^9 = 10^5 pico-USD)
    //   assert 10 * usdc_pico <= 6 * total_pico      ⇔   weight_USDC <= 0.6
    let vault_state = vault.state(&mut ctx).await;
    let usdc_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == usdc_mint)
        .unwrap();
    let sol_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == sol_mint)
        .unwrap();
    let usdc_pico = u128::from(usdc_token.token_available) * 1_000_000;
    let sol_pico = u128::from(sol_token.token_available) * 100_000;
    let total_pico = usdc_pico + sol_pico;
    assert!(
        10 * usdc_pico <= 6 * total_pico,
        "post-deposit USDC weight {usdc_pico}/{total_pico} exceeds 0.6 upper bound",
    );
}

/// With a non-zero withdrawal fee, the lower-bound clamp remains strict. Fees stay in the vault,
/// so the post-withdraw token weight is higher than the gross-bound calculation assumes.
#[tokio::test]
async fn test_withdraw_bound_with_withdrawal_fee() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "SOL".to_string() => sol_decimal_to_u64(10.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", sol_decimal_to_u64(1.0)).await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    let balances_before = depositor.balances(&mut ctx).await;
    client::withdraw(&mut ctx, &vault, &depositor, balances_before.shares, "USDC").await;
    let balances_after = depositor.balances(&mut ctx).await;

    let received = balances_after.tokens["USDC"] - balances_before.tokens["USDC"];
    // Pre-fee bound clamp produces the same 33_334_333 lamports as the no-fee case; the 1% USDC
    // withdraw fee then reduces the payout: floor(33_334_333 * 0.99) = 33_000_989. Burned-shares
    // count is identical to the no-fee case because fees are donated back to the vault rather
    // than reducing the share-amount redeemed.
    assert_eq!(received, 33_000_989);
    assert_eq!(balances_after.shares, 166_665_665);

    let vault_state = vault.state(&mut ctx).await;
    let usdc_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == usdc_mint)
        .unwrap();
    let sol_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == sol_mint)
        .unwrap();
    let usdc_pico = u128::from(usdc_token.token_available) * 1_000_000;
    let sol_pico = u128::from(sol_token.token_available) * 100_000;
    let total_pico = usdc_pico + sol_pico;
    assert!(
        10 * usdc_pico >= 4 * total_pico,
        "post-withdraw USDC weight {usdc_pico}/{total_pico} fell below 0.4 lower bound",
    );
}

/// Admin can relax the bound at runtime: a deposit blocked while `max_deviation_bps` is tight
/// must succeed after the admin resets it to zero, without any other state change.
#[tokio::test]
async fn test_deposit_unblocked_after_disabling_bound() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Skew the vault so USDC sits above any non-trivial upper bound.
    let depositor_usdc =
        VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(500_000.0)).await;
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(1.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(0.01),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 100),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 100),
    )
    .await;

    let blocked =
        client::try_deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(10.0), 0).await;
    assert_eq!(
        blocked.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TargetBoundExceeded, 1),
    );

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 0),
    )
    .await;

    // Same request succeeds with the bound disabled — not clamped, not errored.
    let before = depositor_usdc.balances(&mut ctx).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(10.0)).await;
    let after = depositor_usdc.balances(&mut ctx).await;
    assert_eq!(before.tokens["USDC"] - after.tokens["USDC"], usdc(10.0));
}

/// 3-token vault with asymmetric weights and per-token deviations: each token's clamp is governed
/// by its own target/deviation, not the symmetric 2-token case covered elsewhere.
#[tokio::test]
async fn test_three_token_asymmetric_weights_and_deviations() {
    let (mut ctx, _markets, vault) = setup_markets(&MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "USDT".to_string() => MintSpec::spl(6, 1.0),
            "DAI".to_string() => MintSpec::spl(6, 1.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 0),
            RSpec::new("USDT", 0),
            RSpec::new("DAI", 0),
        ])],
    })
    .await;
    let owner = ctx.initial_market_owner.clone();
    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let usdt_mint = vault.vault_tokens["USDT"].token_mint;
    let dai_mint = vault.vault_tokens["DAI"].token_mint;

    // Seed balances so vault_state has all three tokens funded. We deposit into USDC to establish
    // shares, then into USDT and DAI so all three tokens carry non-zero AUM.
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "USDT".to_string() => usdc(1_000.0),
            "DAI".to_string() => usdc(1_000.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", usdc(300.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "DAI", usdc(400.0)).await;

    // Target weights [1, 4, 3] — USDC target = 1/8. USDC starts at ≈100/800 = 1/8 (at target).
    // Tight dev_bps on USDC so a further USDC deposit is clamped.
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 4, 3]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 3750),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdt_mint, 1250),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(dai_mint, 2500),
    )
    .await;

    // Requesting a large USDT deposit must cap at the USDT bound: upper_USDT = 3/8 + 1/8 = 1/2.
    //   max_usdt_aum = (0.5 * 800.001 - 300)/(1 - 0.5) = 200.001 → 200_001_000 lamports, minus a
    //   single lamport of Fraction precision loss. `usdc(500.0) > 200_001_000` so the clamp fires.
    let before = depositor.balances(&mut ctx).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDT", usdc(500.0)).await;
    let after = depositor.balances(&mut ctx).await;
    let deducted = before.tokens["USDT"] - after.tokens["USDT"];
    assert_eq!(deducted, 200_000_999);

    // Post-op cross-multiplied check: USDT ≤ 1/2 of total (pico-USD, all $1 tokens with 6 dec).
    let vault_state = vault.state(&mut ctx).await;
    let get = |mint: &solana_sdk::pubkey::Pubkey| {
        vault_state
            .vault_tokens
            .iter()
            .find(|t| t.mint == *mint)
            .unwrap()
            .token_available as u128
    };
    let total = get(&usdc_mint) + get(&usdt_mint) + get(&dai_mint);
    assert!(2 * get(&usdt_mint) <= total, "USDT weight above 1/2 upper");
}

/// A scope price move can push an already-compliant vault out of the upper bound; subsequent
/// deposits on the over-weight token must fail with `TargetBoundExceeded`.
#[tokio::test]
async fn test_price_move_pushes_vault_out_of_upper_bound() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Seed 50/50 in USD terms at the initial SOL price of $100.
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "SOL".to_string() => sol_decimal_to_u64(10.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", sol_decimal_to_u64(1.0)).await;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 500),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 500),
    )
    .await;

    // Quote SOL at 10x its old price: SOL USD value now dominates → SOL weight ≫ upper.
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 1_000.0, 1_000.0).await;

    let res = client::try_deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        sol_decimal_to_u64(0.01),
        0,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TargetBoundExceeded, 1),
    );
}

/// Management & performance fees accrue as pending shares (not tokens), so `token_available`
/// stays unchanged and the target-bound math still holds after fees are charged.
#[tokio::test]
async fn test_bound_invariant_after_mgmt_perf_fees_accrue() {
    use metavault::utils::consts::YEAR;

    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "SOL".to_string() => sol_decimal_to_u64(10.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", sol_decimal_to_u64(1.0)).await;

    // 10% mgmt + 50% perf; then advance a year so fees accrue into pending shares.
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(5000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 1000),
    )
    .await;

    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    // The bound still strictly governs a further USDC deposit despite the accrued fee shares.
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(500.0)).await;

    let vault_state = vault.state(&mut ctx).await;
    let usdc_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == usdc_mint)
        .unwrap();
    let sol_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == sol_mint)
        .unwrap();
    let usdc_pico = u128::from(usdc_token.token_available) * 1_000_000;
    let sol_pico = u128::from(sol_token.token_available) * 100_000;
    let total_pico = usdc_pico + sol_pico;
    assert!(
        10 * usdc_pico <= 6 * total_pico,
        "post-deposit USDC weight {usdc_pico}/{total_pico} exceeds 0.6 upper bound",
    );
}

/// If admin changes `VaultTokenWeights` so the current balances now violate the new target, the
/// offending direction is blocked until an inverse op rebalances. Documents the "recovery" path.
#[tokio::test]
async fn test_admin_weight_change_blocks_deposit_until_rebalanced() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;

    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;

    let usdc_mint = vault.vault_tokens["USDC"].token_mint;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    // Seed balances so the vault is at target with weights [1, 1] — $100 of each in USD.
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(1_000.0),
            "SOL".to_string() => sol_decimal_to_u64(10.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "SOL", sol_decimal_to_u64(1.0)).await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(usdc_mint, 500),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 500),
    )
    .await;

    // Flip the target: weights [1, 9] → USDC target is now 10% instead of 50%. USDC at ≈50% is
    // well above upper = 15%, so further USDC deposits must fail.
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 9]),
    )
    .await;

    let blocked = client::try_deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1.0), 0).await;
    assert_eq!(
        blocked.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TargetBoundExceeded, 1),
    );

    // Depositing the under-weight token (SOL) is still allowed — it moves the vault toward the
    // new target.
    client::deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        sol_decimal_to_u64(0.01),
    )
    .await;
}

/// A newly-added token with a weight > 0, non-zero deviation, and zero balance must see its
/// first deposit bounded by `upper * total / (1 - upper)` — not unlimited.
#[tokio::test]
async fn test_newly_added_token_first_deposit_is_bounded() {
    let (mut ctx, mut vault, owner, _investor, mkts) = setup_markets_and_reserves(1).await;
    // Seed the vault with USDC first so shares/total_aum exist before we add SOL.
    let depositor_usdc = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(1_000.0)).await;
    client::deposit(&mut ctx, &vault, &depositor_usdc, "USDC", usdc(100.0)).await;

    // Add SOL with a weight and a deviation — initial SOL balance is 0.
    client::add_vault_token(
        &mut ctx,
        &owner,
        &mut vault,
        "SOL",
        mkts[0].sol_reserve.liquidity_mint.pubkey(),
        mkts[0].oracles.scope_prices,
    )
    .await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "SOL", 100.0, 100.0).await;
    let sol_mint = vault.vault_tokens["SOL"].token_mint;

    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 1]),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(sol_mint, 2500),
    )
    .await;

    // target_SOL = 1/2, dev = 1/4 ⇒ upper = 3/4. total_aum ≈ $100 (USDC only), sol_aum = 0.
    //   max_sol_aum = (0.75 * 100 - 0) / 0.25 = $300.
    // A request of 100 SOL ($10 000) must clamp to ≤ ~3 SOL ($300) worth.
    let depositor_sol =
        VaultDepositorAccounts::new(&mut ctx, &vault, "SOL", sol_decimal_to_u64(100.0)).await;
    let before = depositor_sol.balances(&mut ctx).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor_sol,
        "SOL",
        sol_decimal_to_u64(100.0),
    )
    .await;
    let after = depositor_sol.balances(&mut ctx).await;

    let deducted = before.tokens["SOL"] - after.tokens["SOL"];
    assert!(
        deducted < sol_decimal_to_u64(10.0),
        "newly-added token deposit was not bounded: deducted {deducted}",
    );
    // Verify the clamp pinned USDC weight below the USDC upper bound (post-deposit USDC weight
    // <= 0.75 ⇔ 4 * usdc_pico <= 3 * total_pico).
    let vault_state = vault.state(&mut ctx).await;
    let usdc_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint != sol_mint && t.is_token_set())
        .unwrap();
    let sol_token = vault_state
        .vault_tokens
        .iter()
        .find(|t| t.mint == sol_mint)
        .unwrap();
    let usdc_pico = u128::from(usdc_token.token_available) * 1_000_000;
    let sol_pico = u128::from(sol_token.token_available) * 100_000;
    let total_pico = usdc_pico + sol_pico;
    assert!(
        4 * sol_pico <= 3 * total_pico,
        "post-deposit SOL weight {sol_pico}/{total_pico} exceeds 0.75 upper bound",
    );
}

#[tokio::test]
async fn test_a_token_the_vault_targets_none_of_takes_no_deposits_but_still_pays_out() {
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: hashmap! {
                "USDC".to_string() => MintSpec::spl(6, 1.0),
                "SOL".to_string() => MintSpec::spl(9, 100.0),
            },
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        vec![1, 1],
    )
    .await;
    let admin = ctx.initial_market_owner.clone();
    let depositor = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        hashmap! {
            "USDC".to_string() => usdc(2_000.0),
            "SOL".to_string() => sol_decimal_to_u64(20.0),
        },
    )
    .await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(1_000.0)).await;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        sol_decimal_to_u64(10.0),
    )
    .await;

    // Weight SOL to zero: the vault wants none of it from here on. Weights are positional, so
    // read the vault's own token order rather than assume one.
    let sol_mint = vault.vault_tokens["SOL"].token_mint;
    let weights: Vec<u64> = vault
        .state(&mut ctx)
        .await
        .vault_tokens
        .iter()
        .filter(|token| token.is_token_set())
        .map(|token| u64::from(token.mint != sol_mint))
        .collect();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights),
    )
    .await;

    let refused = client::try_deposit(
        &mut ctx,
        &vault,
        &depositor,
        "SOL",
        sol_decimal_to_u64(1.0),
        0,
    )
    .await;
    assert_eq!(
        refused.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::TokenWeightZeroed, 1),
    );

    // The token it does still target is unaffected.
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(10.0)).await;

    // And a zero-weighted token is not held in: its holders can still take it out.
    let sol_before = depositor.balances(&mut ctx).await.tokens["SOL"];
    let shares = depositor.balances(&mut ctx).await.shares;
    client::withdraw(&mut ctx, &vault, &depositor, shares / 10, "SOL").await;
    assert!(depositor.balances(&mut ctx).await.tokens["SOL"] > sol_before);
}

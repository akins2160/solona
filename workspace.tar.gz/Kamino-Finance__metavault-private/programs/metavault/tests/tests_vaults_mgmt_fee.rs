use ::metavault::program_test::VaultDepositorAccounts;
use anchor_spl::associated_token::get_associated_token_address;
use kamino_lending::{
    assert_almost_eq_fraction, assert_fuzzy_eq,
    fraction::Fraction,
    program_test::common::{math::usdc_decimal_to_u64, token_operations::create_ata},
    utils::{to_sf, FractionExtra},
};
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, YEAR},
    KaminoVaultError,
};

use solana_program_test::tokio;
use solana_sdk::signer::Signer;
use usdc_decimal_to_u64 as usdc;

#[tokio::test]
async fn test_vault_performance_fee_and_mgmt_fee_are_set_correctly() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(1000),
    )
    .await;

    // check the perf fee is set correctly
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 1000);
    assert_eq!(vault_state.management_fee_bps, 0);

    // update the management fee
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(50),
    )
    .await;

    // check the management fee is set correctly
    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 1000);
    assert_eq!(vault_state.management_fee_bps, 50);

    // update both fees and check they were set correctly
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::PerformanceFeeBps(30),
    )
    .await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(20),
    )
    .await;

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 30);
    assert_eq!(vault_state.management_fee_bps, 20);
}

#[tokio::test]
async fn test_set_invalid_mgmt_fee_fails() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    // update the management fee to a value bigger than the full bps
    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(11_000),
    )
    .await;

    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ManagementFeeGreaterThanMaxAllowed, 1)
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 0);
    assert_eq!(vault_state.management_fee_bps, 0);

    // check that the management fee bigger than 10% doesn't work
    let res = client::try_update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1_001),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::ManagementFeeGreaterThanMaxAllowed, 1)
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.performance_fee_bps, 0);
    assert_eq!(vault_state.management_fee_bps, 0);
}

#[tokio::test]
async fn test_mgmt_fee_charged_no_more_than_total_vault() {
    let (mut ctx, vault, owner, _, _mkts) = fixtures::setup_markets_and_reserves(1).await;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // forward such as time * mgmt_fee_per_year > MAX_CHARGED_RATE_FOR_VAULT_FEE
    ctx.fast_forward_seconds(u64::from(YEAR) * 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws but will receive only half
    client::withdraw(&mut ctx, &vault, &depositor, deposit, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    assert_eq!(balances_after.tokens["USDC"], deposit / 2 - 1);
    assert_eq!(balances_after.shares, 1);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit / 2 + INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        deposit + 2 * INITIAL_DEPOSIT_SIZE,
        1
    );

    // check cumulative mgmt and perf fees are correct
    assert_eq!(
        vault_state.pending_fees_sf,
        to_sf(deposit - 1 + INITIAL_DEPOSIT_SIZE)
    );
    assert_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        vault_state.pending_fees_sf,
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);

    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: {
            let mut map = std::collections::HashMap::new();
            map.insert(
                "USDC".to_string(),
                get_associated_token_address(
                    &owner.pubkey(),
                    &vault.vault_tokens["USDC"].token_mint,
                ),
            );
            map
        },
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_eq!(
        to_sf(owner_balances.tokens["USDC"]),
        to_sf(owner_initial_token_balance + deposit / 2 + INITIAL_DEPOSIT_SIZE / 2)
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE / 2,
        1
    );
    assert!(vault_state.cumulative_mgmt_fees_sf >= to_sf(deposit));
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);
}

#[tokio::test]
async fn test_mgmt_fee_charged_no_yield() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // advance a year
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws everything and check the management fee was applied
    client::withdraw(&mut ctx, &vault, &depositor, deposit, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;
    let pending_fees = Fraction::from_bits(vault_state.pending_fees_sf);
    let expected_mgmt_fee_from_initial_deposit = (INITIAL_DEPOSIT_SIZE as f64 * 0.01 / 0.99) as u64;
    let expected_mgmt_fee_from_deposit = (deposit as f64 * 0.01 / 0.99) as u64;

    assert_eq!(balances_after.tokens["USDC"], usdc(99.0));
    assert_eq!(balances_after.shares, 0);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit / 100 + INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_eq!(
        vault_state.shares_issued,
        expected_mgmt_fee_from_deposit
            + INITIAL_DEPOSIT_SIZE
            + expected_mgmt_fee_from_initial_deposit
    );
    assert_fuzzy_eq!(
        vault_state.pending_fees_sf,
        to_sf(expected_mgmt_fee_from_deposit + expected_mgmt_fee_from_initial_deposit),
        to_sf(1)
    );

    let user_paid_fees = pending_fees.to_floor::<u64>() - expected_mgmt_fee_from_initial_deposit;
    assert_fuzzy_eq!(user_paid_fees, expected_mgmt_fee_from_deposit, 1);

    // check cumulative mgmt and perf fees are correct
    assert_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        vault_state.pending_fees_sf,
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);

    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: {
            let mut map = std::collections::HashMap::new();
            map.insert(
                "USDC".to_string(),
                get_associated_token_address(
                    &owner.pubkey(),
                    &vault.vault_tokens["USDC"].token_mint,
                ),
            );
            map
        },
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];
    let pending_fees = vault_state.pending_fees_sf;

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        to_sf(owner_balances.tokens["USDC"]),
        to_sf(owner_initial_token_balance + deposit / 100 + INITIAL_DEPOSIT_SIZE / 100),
        to_sf(1)
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE * 99 / 100,
        1
    );
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, pending_fees);
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);
}

#[tokio::test]
async fn test_deposit_with_mgmt_fee_charged_no_yield() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let mgmt_fee_bps = 1000;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(mgmt_fee_bps),
    )
    .await;

    let topup = usdc(200.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after_initial_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_initial_deposit.tokens["USDC"], deposit);
    assert_eq!(balances_after_initial_deposit.shares, deposit - 1);

    // advance 5 years
    ctx.fast_forward_seconds(u64::from(YEAR) * 5).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // as there are some management fees deposit the same amount again and expect more shares as now the initial deposited - fees represent the initial amount of shares, so the share price decreased
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    let shares_gained_after_second_deposit =
        balances_after.shares - balances_after_initial_deposit.shares;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_fuzzy_eq!(shares_gained_after_second_deposit, 2 * deposit, 3); // this is not exactly accurate as we round the seconds passed
    assert!(shares_gained_after_second_deposit > balances_after_initial_deposit.shares);

    // withdraw everything and expect to get back the whole second deposit and 50% of the first deposit
    client::withdraw(&mut ctx, &vault, &depositor, balances_after.shares, "USDC").await;

    let expected_mgmt_fee = balances_after_initial_deposit.shares; // 50% fee -> same number of shares received for first deposit

    let balances_after = depositor.balances(&mut ctx).await;
    assert_fuzzy_eq!(balances_after.tokens["USDC"], deposit + deposit / 2, 1);
    assert_fuzzy_eq!(balances_after.shares, 0, 1); // there is a mgmt fee and no yield so 1 share < 1 token and there is 1 share dust that worth less than 1 lamport so it reamins in user's wallet

    let vault_state = vault.state(&mut ctx).await;
    let pending_fees = Fraction::from_bits(vault_state.pending_fees_sf);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit / 2 + INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        2 * INITIAL_DEPOSIT_SIZE + deposit,
        1
    ); // initial depposit + 1 share leftover in user's wallet
    assert_almost_eq_fraction!(pending_fees, Fraction::from(expected_mgmt_fee));

    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: {
            let mut map = std::collections::HashMap::new();
            map.insert(
                "USDC".to_string(),
                get_associated_token_address(
                    &owner.pubkey(),
                    &vault.vault_tokens["USDC"].token_mint,
                ),
            );
            map
        },
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        owner_balances.tokens["USDC"],
        owner_initial_token_balance + deposit / 2 + INITIAL_DEPOSIT_SIZE / 2,
        30
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE / 2,
        30
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);
}

#[tokio::test]
async fn test_mgmt_fee_charged_on_withdraw_with_invest_no_yield() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // advance 30 days in seconds
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // withdraw half of the shares
    let shares_to_withdraw = deposit / 2;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that the user received exactly half of the deposited amount
    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    let vault_state_after_first_withdraw = vault.state(&mut ctx).await;
    assert_eq!(balances_after_first_withdraw.tokens["USDC"], usdc(50.0));
    assert_eq!(balances_after_first_withdraw.shares, deposit / 2 - 1);

    assert_eq!(vault_state_after_first_withdraw.pending_fees_sf, 0);
    assert_fuzzy_eq!(
        vault_state_after_first_withdraw.vault_tokens[0].token_available,
        deposit / 2 + INITIAL_DEPOSIT_SIZE,
        1
    );

    // set the management fee and advance half a year
    let mgmt_fee_bps = 500;
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(mgmt_fee_bps),
    )
    .await;

    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    let vault_state = vault.state(&mut ctx).await;
    let shares_issued = vault_state.shares_issued;

    // user withdraws everything and check the management fee was applied
    client::withdraw(&mut ctx, &vault, &depositor, balances_after.shares, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after_final_withdraw = depositor.balances(&mut ctx).await;

    let mgmt_fee = Fraction::from_bps(mgmt_fee_bps / 2); // mgmt fee for half a year
    let expected_management_fee: u64 =
        (Fraction::from(shares_issued) * mgmt_fee / (Fraction::ONE - mgmt_fee)).to_floor();
    assert_fuzzy_eq!(
        vault_state.pending_fees_sf,
        to_sf(expected_management_fee),
        to_sf(1)
    );
    assert_fuzzy_eq!(
        balances_after_final_withdraw.tokens["USDC"],
        topup / 2 + topup / 2 * (10_000 - mgmt_fee_bps / 2) / 10_000,
        1
    );
    assert_fuzzy_eq!(balances_after_final_withdraw.shares, 0, 1);

    let pending_fees = vault_state.pending_fees_sf;
    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: {
            let mut map = std::collections::HashMap::new();
            map.insert(
                "USDC".to_string(),
                get_associated_token_address(
                    &owner.pubkey(),
                    &vault.vault_tokens["USDC"].token_mint,
                ),
            );
            map
        },
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        owner_balances.tokens["USDC"],
        owner_initial_token_balance + topup / 2 * mgmt_fee_bps / 2 / 10_000,
        30
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE,
        30
    );
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, pending_fees);
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);
}

#[tokio::test]
async fn test_mgmt_fee_charged_on_deposit_and_withdraw_no_invest_no_yield() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // advance 30 days
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // withdraw half of the shares
    let shares_to_withdraw = deposit / 2;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that the user received exactly half of the deposited amount
    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], usdc(50.0));
    assert_eq!(balances_after.shares, deposit / 2 - 1);

    // set the management fee and advance half a year
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws everything and check the management fee was applied
    client::withdraw(&mut ctx, &vault, &depositor, balances_after.shares, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    // the management fee is 10% per year so for half of year it is 5% from the remaining balance (50.0 USDC)
    let expected_mgmt_fee_from_user = (usdc(50.0) as f64 * 0.05 / 0.95) as u64;
    let expected_mgmt_fee_from_bootstrap_deposit =
        (INITIAL_DEPOSIT_SIZE as f64 * 0.05 / 0.95) as u64;
    let expected_mgmt_fee_from_deposit = (usdc(50.0) as f64 * 0.05).ceil() as u64;
    let expected_mgmt_fee = expected_mgmt_fee_from_user + expected_mgmt_fee_from_bootstrap_deposit;
    assert_eq!(
        balances_after.tokens["USDC"],
        topup - expected_mgmt_fee_from_deposit
    );
    assert_eq!(balances_after.shares, 0);

    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        expected_mgmt_fee_from_deposit + INITIAL_DEPOSIT_SIZE
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        expected_mgmt_fee + INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_fuzzy_eq!(
        vault_state.pending_fees_sf,
        to_sf(expected_mgmt_fee),
        to_sf(2)
    );
    assert_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        vault_state.pending_fees_sf
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);

    let total_available_after_full_withdraw = balances_after.tokens["USDC"];
    let amount_to_deposit = usdc(10.0);

    client::deposit(&mut ctx, &vault, &depositor, "USDC", amount_to_deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;
    let shares_balance_after_deposit = balances_after.shares;
    let aum_from_initial_deposit = INITIAL_DEPOSIT_SIZE - expected_mgmt_fee_from_bootstrap_deposit;

    assert!(
        balances_after.tokens["USDC"] == total_available_after_full_withdraw - amount_to_deposit
    );
    assert!(balances_after.shares > amount_to_deposit);

    let actual_deposited = total_available_after_full_withdraw - balances_after.tokens["USDC"];
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        actual_deposited + expected_mgmt_fee_from_deposit + INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        balances_after.shares + expected_mgmt_fee + INITIAL_DEPOSIT_SIZE,
        1
    );

    // advance a full year so 10% of the total deposited amount is taken as management fee
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // make another deposit of 9$ and verify that the shares received are the same as on the first deposit when we deposited ~10$ and the management fee was 10% of the deposited amount
    let second_expected_mgmt_fee_from_deposit = actual_deposited / 10;
    let second_expected_mgmt_fee_from_user =
        ((balances_after.shares + expected_mgmt_fee) as f64 * 0.1 / 0.9).ceil() as u64;
    let second_expected_mgmt_fee_from_bootstrap =
        (aum_from_initial_deposit as f64 * 0.1 / 0.9).ceil() as u64;
    let second_expected_mgmt_fee =
        second_expected_mgmt_fee_from_user + second_expected_mgmt_fee_from_bootstrap;
    let second_amount_to_deposit = actual_deposited - second_expected_mgmt_fee_from_deposit;
    client::deposit(
        &mut ctx,
        &vault,
        &depositor,
        "USDC",
        second_amount_to_deposit,
    )
    .await;

    let balances_after_second_deposit = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    let actual_second_deposit =
        balances_after.tokens["USDC"] - balances_after_second_deposit.tokens["USDC"];
    // assert we get the same amount of shares as on the first deposit, with rounding in favour of the protocol
    assert_fuzzy_eq!(
        balances_after_second_deposit.shares,
        shares_balance_after_deposit * 2,
        2
    );
    assert!(balances_after_second_deposit.shares <= shares_balance_after_deposit * 2);
    assert_fuzzy_eq!(
        balances_after_second_deposit.tokens["USDC"],
        total_available_after_full_withdraw - actual_deposited - second_amount_to_deposit,
        1
    );

    assert!(
        balances_after_second_deposit.tokens["USDC"]
            == total_available_after_full_withdraw - actual_deposited - second_amount_to_deposit
    ); // we have some dust as the price is not exactly 1 and we take just enough for the minted shares

    assert_fuzzy_eq!(
        vault_state.shares_issued,
        shares_balance_after_deposit * 2
            + INITIAL_DEPOSIT_SIZE
            + second_expected_mgmt_fee
            + expected_mgmt_fee,
        6
    );
    assert_fuzzy_eq!(
        vault_state.pending_fees_sf,
        to_sf(expected_mgmt_fee + second_expected_mgmt_fee),
        to_sf(7)
    );
    assert_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        vault_state.pending_fees_sf
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);

    // check that what is available is the sum of the two deposits + the initial deposit + the fees that were already in the vault from the user
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        actual_deposited
            + actual_second_deposit
            + INITIAL_DEPOSIT_SIZE
            + expected_mgmt_fee_from_deposit,
    );

    // user withdraws everything and check he has the initial balance - the management fees
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        balances_after_second_deposit.shares,
        "USDC",
    )
    .await;

    let balances_after = depositor.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    let expected_user_balance =
        topup - expected_mgmt_fee_from_deposit - second_expected_mgmt_fee_from_deposit;
    assert_fuzzy_eq!(balances_after.tokens["USDC"], expected_user_balance, 1);
    assert!(expected_user_balance >= balances_after.tokens["USDC"]);
    assert_fuzzy_eq!(balances_after.shares, 0, 1);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE
            + expected_mgmt_fee_from_deposit
            + second_expected_mgmt_fee_from_deposit,
        1
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        INITIAL_DEPOSIT_SIZE + expected_mgmt_fee + second_expected_mgmt_fee,
        6
    );
    assert_fuzzy_eq!(
        vault_state.pending_fees_sf,
        to_sf(expected_mgmt_fee + second_expected_mgmt_fee),
        to_sf(7)
    );
    assert_eq!(
        vault_state.cumulative_mgmt_fees_sf,
        vault_state.pending_fees_sf
    );
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);

    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: {
            let mut map = std::collections::HashMap::new();
            map.insert(
                "USDC".to_string(),
                get_associated_token_address(
                    &owner.pubkey(),
                    &vault.vault_tokens["USDC"].token_mint,
                ),
            );
            map
        },
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];
    let pending_fees = vault_state.pending_fees_sf;

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        owner_balances.tokens["USDC"],
        owner_initial_token_balance
            + expected_mgmt_fee_from_deposit
            + second_expected_mgmt_fee_from_deposit
            + 140, // 140 diff meaning that actual received to admin is more than expected
        5
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));
    // Remaining amount in vault is only the remaining from the bootstrap deposit minus the mgmt fees on that initial deposit
    let expected_available_amount = INITIAL_DEPOSIT_SIZE
        - (INITIAL_DEPOSIT_SIZE as f64 * 0.05) as u64
        - (INITIAL_DEPOSIT_SIZE as f64 * 0.95 * 0.1) as u64;
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        expected_available_amount,
        2
    );
    assert!(vault_state.vault_tokens[0].token_available > expected_available_amount);
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, pending_fees);
    assert_eq!(vault_state.cumulative_perf_fees_sf, 0);
}

#[tokio::test]
async fn test_mgmt_fee_charged_on_deposit_and_withdraw_with_invest_with_yield() {
    let (mut ctx, vault, owner, _investor, _mkts) =
        fixtures::setup_markets_and_reserves_with_yield(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], topup);

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;
    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // advance 30 days
    ctx.fast_forward_seconds(u64::from(YEAR) / 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(&mut ctx, &vault, "USDC", deposit + INITIAL_DEPOSIT_SIZE).await; // double all tokens

    // withdraw half of the shares
    let shares_to_withdraw = deposit / 2;
    client::withdraw(&mut ctx, &vault, &depositor, shares_to_withdraw, "USDC").await;

    // check that the user received more than half of the deposited amount as we have yield
    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    assert!(balances_after_first_withdraw.tokens["USDC"] > usdc(50.0));
    assert_eq!(balances_after_first_withdraw.shares, deposit / 2 - 1);

    let vault_state = vault.state(&mut ctx).await;
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit + 2 * INITIAL_DEPOSIT_SIZE,
        2
    );
    assert_eq!(
        vault_state.shares_issued,
        deposit / 2 - 1 + INITIAL_DEPOSIT_SIZE
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));

    // set the management fee and advance half a year
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws everything and check the management fee was applied on the principal amount + yield
    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        balances_after_first_withdraw.shares,
        "USDC",
    )
    .await;

    let vault_state_after_withdraw_all = vault.state(&mut ctx).await;
    let user_balances_after_withdraw_all = depositor.balances(&mut ctx).await;

    // the management fee on user amount is 10% per year so for half of year it is 5% from the remaining balance (50.0 USDC)
    // 2.5 * 2 USDC is the expected fee for half a year on the principal + yield
    let expected_mgmt_fee_from_deposit = (deposit as f64 * 0.05) as u64;
    let expected_mgmt_fee_as_shares =
        ((deposit as f64 / 2.0 + INITIAL_DEPOSIT_SIZE as f64) * 0.05 / 0.95) as u64;
    assert!(
        Fraction::from_bits(vault_state_after_withdraw_all.pending_fees_sf)
            >= Fraction::from_num(expected_mgmt_fee_as_shares)
    );
    assert_eq!(
        vault_state_after_withdraw_all.shares_issued,
        INITIAL_DEPOSIT_SIZE + expected_mgmt_fee_as_shares
    );
    assert_fuzzy_eq!(
        vault_state_after_withdraw_all.vault_tokens[0].token_available,
        2 * INITIAL_DEPOSIT_SIZE + expected_mgmt_fee_from_deposit,
        2
    );
    assert!(
        vault_state_after_withdraw_all.cumulative_mgmt_fees_sf
            >= to_sf(expected_mgmt_fee_as_shares)
    );
    assert_eq!(
        vault_state_after_withdraw_all.cumulative_perf_fees_sf
            + vault_state_after_withdraw_all.cumulative_mgmt_fees_sf,
        vault_state_after_withdraw_all.pending_fees_sf
    );

    // pass some more time to check that the invested fees are generating yield;
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;
    setup::inflate_tokens_in_vault(
        &mut ctx,
        &vault,
        "USDC",
        expected_mgmt_fee_from_deposit + 2 * INITIAL_DEPOSIT_SIZE,
    )
    .await; // double all tokens again

    let vault_state_before_new_deposit = vault.state(&mut ctx).await;

    assert!(
        vault_state_before_new_deposit.vault_tokens[0].token_available
            > vault_state_after_withdraw_all.vault_tokens[0].token_available
    );
    // now as the user has all the tokens - the management fee and the vault is empty he should get shares = deposited amount
    let total_available_after_full_withdraw = user_balances_after_withdraw_all.tokens["USDC"];
    let amount_to_deposit = usdc(10.0);
    let mgmt_fee_before_new_deposit =
        (vault_state_before_new_deposit.shares_issued as f64 * 0.05 / 0.95) as u64;

    client::deposit(&mut ctx, &vault, &depositor, "USDC", amount_to_deposit).await;
    let balances_after = depositor.balances(&mut ctx).await;
    let deposited = total_available_after_full_withdraw - balances_after.tokens["USDC"];
    let vault_state = vault.state(&mut ctx).await;
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        4 * INITIAL_DEPOSIT_SIZE + 2 * expected_mgmt_fee_from_deposit + deposited,
        5
    );
    assert_fuzzy_eq!(
        vault_state.shares_issued,
        vault_state_before_new_deposit.shares_issued
            + mgmt_fee_before_new_deposit
            + balances_after.shares,
        1
    );

    assert_eq!(
        balances_after.tokens["USDC"],
        total_available_after_full_withdraw - deposited
    );
    // check that share price > 1
    assert!(balances_after.shares < deposited);
    assert_eq!(
        vault_state_after_withdraw_all.cumulative_perf_fees_sf
            + vault_state_after_withdraw_all.cumulative_mgmt_fees_sf,
        vault_state_after_withdraw_all.pending_fees_sf
    );

    // advance a full year so 10% of the total deposited amount is taken as management fee and there is a 10% yield
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws everything and check he has the initial balance - the management fees
    client::withdraw(&mut ctx, &vault, &depositor, balances_after.shares, "USDC").await;
    let mgmt_fee_after_second_withdraw = ((vault_state_before_new_deposit.shares_issued
        + mgmt_fee_before_new_deposit
        + balances_after.shares) as f64
        * 0.1
        / 0.9) as u64;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    let expected_fee_from_second_deposit = (deposited as f64 * 0.1) as u64;

    assert_fuzzy_eq!(
        vault_state.shares_issued,
        vault_state_before_new_deposit.shares_issued
            + mgmt_fee_before_new_deposit
            + mgmt_fee_after_second_withdraw,
        2
    );
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        4 * INITIAL_DEPOSIT_SIZE
            + 2 * expected_mgmt_fee_from_deposit
            + expected_fee_from_second_deposit,
        5
    );

    assert_fuzzy_eq!(
        balances_after.tokens["USDC"],
        total_available_after_full_withdraw - expected_fee_from_second_deposit,
        3
    );
    assert_eq!(balances_after.shares, 0);

    let pending_fees = vault_state.pending_fees_sf;

    // withdraw pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: {
            let mut map = std::collections::HashMap::new();
            map.insert(
                "USDC".to_string(),
                get_associated_token_address(
                    &owner.pubkey(),
                    &vault.vault_tokens["USDC"].token_mint,
                ),
            );
            map
        },
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        owner_balances.tokens["USDC"],
        owner_initial_token_balance
            + 2 * expected_mgmt_fee_from_deposit
            + expected_fee_from_second_deposit
            + INITIAL_DEPOSIT_SIZE * 3 / 4,
        3
    );
    assert!(vault_state.pending_fees_sf < to_sf(1));
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        3 * INITIAL_DEPOSIT_SIZE + INITIAL_DEPOSIT_SIZE / 4,
        1
    );
    assert_eq!(vault_state.cumulative_mgmt_fees_sf, pending_fees);
    assert_eq!(
        vault_state.cumulative_perf_fees_sf + vault_state.cumulative_mgmt_fees_sf,
        pending_fees
    );
}

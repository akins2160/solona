use anchor_lang::Id;
use anchor_spl::associated_token::get_associated_token_address;
use anchor_spl::token_2022::Token2022;
use kamino_lending::{
    assert_almost_eq_fraction, assert_fuzzy_eq,
    fraction::Fraction,
    program_test::common::{math::usdc_decimal_to_u64, token_operations::create_ata},
    send_transaction,
    utils::FractionExtra,
};
use metavault::{
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup, VaultDepositorAccounts,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, YEAR},
};
use solana_program::instruction::{AccountMeta, Instruction};
use solana_program_test::tokio;
use solana_sdk::signer::Signer;
use usdc_decimal_to_u64 as usdc;

/// Build a raw Token-2022 Burn instruction (index 8, same encoding as legacy SPL).
fn spl_burn_ix(
    source: &solana_program::pubkey::Pubkey,
    mint: &solana_program::pubkey::Pubkey,
    authority: &solana_program::pubkey::Pubkey,
    amount: u64,
) -> Instruction {
    let mut data = vec![8u8]; // Burn instruction index
    data.extend_from_slice(&amount.to_le_bytes());
    Instruction {
        program_id: Token2022::id(),
        accounts: vec![
            AccountMeta::new(*source, false),
            AccountMeta::new(*mint, false),
            AccountMeta::new_readonly(*authority, true),
        ],
        data,
    }
}

#[tokio::test]
async fn test_mgmt_fee_charged_is_entire_vault() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: [(
            "USDC".to_string(),
            get_associated_token_address(&owner.pubkey(), &vault.vault_tokens["USDC"].token_mint),
        )]
        .iter()
        .cloned()
        .collect(),
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
    assert_eq!(balances_after_deposit.shares, deposit - 1);

    // forward such as time * mgmt_fee_per_year == MAX_CHARGED_RATE_FOR_VAULT_FEE
    ctx.fast_forward_seconds(u64::from(YEAR) * 12).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user tries to withdraw but gets only 50%
    client::withdraw(&mut ctx, &vault, &depositor, deposit - 1, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;

    assert_eq!(balances_after.tokens["USDC"], deposit / 2 - 1);
    assert_eq!(balances_after.shares, 1);

    // the funds are still available in the vault but they belong to the vault owner
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit / 2 + INITIAL_DEPOSIT_SIZE + 1
    );
    assert_eq!(
        vault_state.shares_issued,
        deposit + 2 * INITIAL_DEPOSIT_SIZE
    );

    let owner_balance_before_withdraw_fees = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    // owner withdraws the pending fees
    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    // Check that the owner has withdrawn the full amount from the vault
    let owner_balances: metavault::program_test::VaultDepositorBalances =
        owner_accounts.balances(&mut ctx).await;
    assert_eq!(
        owner_balances.tokens["USDC"],
        deposit / 2 + owner_balance_before_withdraw_fees + INITIAL_DEPOSIT_SIZE / 2
    );

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.pending_fees_sf, 0);
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE / 2,
        1
    );
    assert_fuzzy_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE, 1);
}

#[tokio::test]
async fn test_mgmt_fee_charged_no_yield_after_invest() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(100),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = usdc(100.0);
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after_deposit = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_deposit.tokens["USDC"], 0);
    assert_eq!(balances_after_deposit.shares, deposit - 1);

    // advance a year
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // user withdraws everything and check the management fee was applied
    client::withdraw(&mut ctx, &vault, &depositor, deposit - 1, "USDC").await;

    let vault_state = vault.state(&mut ctx).await;
    let balances_after = depositor.balances(&mut ctx).await;
    let pending_fees = Fraction::from_bits(vault_state.pending_fees_sf);

    let expected_shares_minted_as_fee =
        ((usdc(100.0) + INITIAL_DEPOSIT_SIZE) as f64 * 0.01 / 0.99) as u64;
    let expected_mgmt_fee = (usdc(100.0) as f64 * 0.01) as u64;
    let expected_initial_deposit_mgmt_fee = (INITIAL_DEPOSIT_SIZE as f64 * 0.01) as u64;
    let expected_total_mgmt_fee = expected_mgmt_fee + expected_initial_deposit_mgmt_fee;
    assert_eq!(balances_after.tokens["USDC"], deposit - expected_mgmt_fee);
    assert_eq!(balances_after.shares, 0);

    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        expected_mgmt_fee + INITIAL_DEPOSIT_SIZE,
        1
    );
    assert_eq!(
        vault_state.shares_issued,
        expected_shares_minted_as_fee + INITIAL_DEPOSIT_SIZE
    );
    assert_almost_eq_fraction!(
        pending_fees,
        Fraction::from_num(expected_shares_minted_as_fee)
    );

    assert_eq!(
        balances_after.tokens["USDC"] + expected_mgmt_fee,
        usdc(100.0)
    );

    // owner withdraws the pending fees
    let owner_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: [(
            "USDC".to_string(),
            get_associated_token_address(&owner.pubkey(), &vault.vault_tokens["USDC"].token_mint),
        )]
        .iter()
        .cloned()
        .collect(),
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };
    let owner_initial_token_balance = owner_accounts.balances(&mut ctx).await.tokens["USDC"];

    client::withdraw_pending_fees_and_redeem(&mut ctx, &vault, &owner_accounts, "USDC").await;

    let owner_balances = owner_accounts.balances(&mut ctx).await;
    let vault_state = vault.state(&mut ctx).await;

    assert_fuzzy_eq!(
        owner_balances.tokens["USDC"],
        owner_initial_token_balance + expected_total_mgmt_fee,
        1
    );
    assert_almost_eq_fraction!(
        Fraction::from_bits(vault_state.pending_fees_sf),
        Fraction::from_num(0.101010101010101),
        0.001
    );
    assert_fuzzy_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE - expected_initial_deposit_mgmt_fee,
        1
    );
    assert_fuzzy_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE, 1);
}

/// After the fix (== → >=), withdraw_pending_fees tolerates external
/// SPL burns because shares_issued > expected is harmless — no one
/// can externally mint shares (the vault PDA is the mint authority).
#[tokio::test]
async fn test_withdraw_pending_fees_succeeds_after_external_spl_burn() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(1000),
    )
    .await;

    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", usdc(100.0)).await;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", usdc(100.0)).await;

    // Fast-forward 1 year so management fees accrue
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    // User burns 1 share lamport directly via SPL token program
    let burn_ix = spl_burn_ix(
        &depositor.shares_ata,
        &vault.shares_mint,
        &depositor.owner.pubkey(),
        1,
    );
    let tx = ctx
        .create_transaction_with_payer([burn_ix], &depositor.owner)
        .await;
    send_transaction!(ctx, tx).unwrap();

    // shares_issued > spl_supply + floor(pending_fees) + INITIAL_DEPOSIT
    let vault_state = vault.state(&mut ctx).await;
    let balances = vault.balances(&mut ctx).await;
    let pending_fees_floor: u64 = Fraction::from(vault_state.pending_fees()).to_floor();
    let expected = balances.shares_supply + pending_fees_floor + 1000;
    assert!(
        vault_state.shares_issued > expected,
        "shares_issued ({}) should exceed expected ({}) by the externally burned amount",
        vault_state.shares_issued,
        expected,
    );

    // Admin withdraws pending fees — succeeds with the >= fix
    let admin_accounts = VaultDepositorAccounts {
        owner: owner.clone(),
        token_atas: [(
            "USDC".to_string(),
            anchor_spl::associated_token::get_associated_token_address(
                &owner.pubkey(),
                &vault.vault_tokens["USDC"].token_mint,
            ),
        )]
        .iter()
        .cloned()
        .collect(),
        shares_ata: create_ata(&mut ctx, &owner, &vault.shares_mint).await,
    };

    client::try_withdraw_pending_fees(&mut ctx, &vault, &admin_accounts)
        .await
        .unwrap();
}

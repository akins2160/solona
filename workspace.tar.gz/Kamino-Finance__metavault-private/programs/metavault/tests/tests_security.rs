mod tests_security {
    mod tests_security_add_vault_token;
    mod tests_security_apply_pending_admin;
    mod tests_security_cpi;
    mod tests_security_deposit;
    mod tests_security_deposit_orders;
    mod tests_security_give_up_pending_fees;
    mod tests_security_init_vault;
    mod tests_security_update_global_config;
    mod tests_security_update_global_config_admin;
    mod tests_security_update_vault_config;
    mod tests_security_withdraw;
    mod tests_security_withdraw_orders;

    mod tests_security_withdraw_pending_fees;

    mod tests_security_borrow_obligation_liquidity;
    mod tests_security_deposit_obligation_collateral;
    mod tests_security_init_global_config;
    mod tests_security_init_obligation;
    mod tests_security_readonly;
    mod tests_security_rebalance_swap;
    mod tests_security_refresh_vault;
    mod tests_security_repay_obligation_liquidity;
    mod tests_security_request_elevation_group;
    mod tests_security_shares_acl;
    mod tests_security_shares_metadata;
    mod tests_security_start_rebalance;
    mod tests_security_stop_rebalance;
    mod tests_security_withdraw_obligation_collateral;
}

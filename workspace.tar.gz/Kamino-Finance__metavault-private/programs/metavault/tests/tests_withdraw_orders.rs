use anchor_lang::error::ErrorCode;
use kamino_lending::{
    anchor_error, assert_fuzzy_eq,
    fraction::{Fraction, FractionExtra},
    program_test::common::{
        setup::{funded_new_kp, kp, KP},
        token_operations,
        types::{MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    },
    send_transaction,
    utils::{to_sf, FULL_BPS},
};
use maplit::hashmap;
use metavault::{
    metavault_error,
    order::WithdrawOrder,
    program_test::{
        client::{
            add_priced_spl_token, assert_vault_covers_locked, available_of, deposit,
            deposit_order_pda, fill_withdraw_order, get_ordered_scope_accounts,
            init_obligation as instructions_init_obligation, lamports_of, locked_amount_of,
            locked_total, open_deposit_order, open_withdraw_order, rebalance_swap,
            settle_withdraw_order, skip, start_rebalance, token_holder,
            try_borrow_obligation_liquidity, try_deposit_obligation_collateral,
            try_fill_withdraw_order, try_fill_withdraw_order_with_krfq_marker,
            try_open_deposit_order, try_open_withdraw_order, try_open_withdraw_order_raw,
            try_open_withdraw_order_with_min_tokens_out, try_settle_withdraw_order,
            try_settle_withdraw_order_raw, try_withdraw, try_withdraw_order_state,
            update_vault_config, usdc_holder, withdraw_order_pda, withdraw_order_rebalance_target,
            withdraw_order_state, KrfqMarker, RequestedOut, UpdateVaultConfigParams,
        },
        fixtures::{self, set_global_config},
        instructions::{self, OrderTokenAccounts},
        VaultAccounts, VaultDepositorAccounts,
    },
    utils::{consts::YEAR, pda},
    GlobalConfig, KaminoVaultError,
};
use solana_program_test::{tokio, BanksClientError};
use solana_sdk::{
    instruction::InstructionError, native_token::LAMPORTS_PER_SOL, pubkey::Pubkey, signer::Signer,
    system_instruction::SystemError, transaction::TransactionError,
};

const USDC: u64 = 1_000_000;
const SOL: u64 = 1_000_000_000;
const SHARE: u64 = 1_000_000;
const HOUR: u64 = 3600;

#[tokio::test]
async fn test_open_at_the_vaults_composition_is_a_proportional_withdraw() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let lp_before = lp.balances(&mut ctx).await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let usdc_leg = slice(1000 * USDC, 1000 * SHARE, shares_issued);
    let sol_leg = slice(10 * SOL, 1000 * SHARE, shares_issued);

    // Weights at the vault's own 50/50 leave nothing to auction: anyone may settle at once.
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let order = open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1), ("SOL", 1)],
        HOUR,
    )
    .await;
    assert_eq!(
        withdraw_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    settle_withdraw_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());

    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(lp_after.shares, lp_before.shares - 1000 * SHARE);
    assert_eq!(lp_after.tokens["USDC"], lp_before.tokens["USDC"] + usdc_leg);
    assert_eq!(lp_after.tokens["SOL"], lp_before.tokens["SOL"] + sol_leg);
    assert_eq!(
        available_of(&mut ctx, &vault, "USDC").await,
        1000 * USDC - usdc_leg
    );
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL - sol_leg
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_open_fill_settle_lifecycle() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let lp_before = lp.balances(&mut ctx).await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let usdc_leg = slice(1000 * USDC, 1000 * SHARE, shares_issued);
    let sol_leg = slice(10 * SOL, 1000 * SHARE, shares_issued);

    // 1000 shares release a hair over half of each token into the order (the supply is a couple of
    // lamports short of round) and burn, while nothing leaves the vault's token accounts.
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    let state = withdraw_order_state(&mut ctx, order).await;
    let now = ctx.get_clock().await.unix_timestamp as u64;
    assert_eq!(state.base.owner, lp.owner.pubkey());
    assert_eq!(state.base.id, 0);
    assert_eq!(state.base.rebalance.start_timestamp, now);
    assert_eq!(state.base.rebalance.end_timestamp, now + HOUR);
    assert_eq!(
        state.base.rebalance.limits.max_fill_slippage_bps,
        u64::from(FULL_BPS)
    );
    assert_eq!(usdc_leg, 500 * USDC);
    assert_eq!(sol_leg, 5 * SOL + 5);
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, usdc_leg);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_leg);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, usdc_leg);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, sol_leg);
    assert_eq!(
        available_of(&mut ctx, &vault, "USDC").await,
        1000 * USDC - usdc_leg
    );
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL - sol_leg
    );
    let lp_after_open = lp.balances(&mut ctx).await;
    assert_eq!(lp_after_open.shares, lp_before.shares - 1000 * SHARE);
    assert_eq!(lp_after_open.tokens["USDC"], lp_before.tokens["USDC"]);
    assert_eq!(lp_after_open.tokens["SOL"], lp_before.tokens["SOL"]);
    assert_eq!(issued(&mut ctx, &vault).await, shares_issued - 1000 * SHARE);
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 1000 * USDC);
    assert_eq!(vault_balances.token_vaults["SOL"], 10 * SOL);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // The order wants only USDC: its whole value in it, and none of the SOL.
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        0
    );

    // A solver buys 5 of the order's SOL for its 500 USDC, at oracle (the vault's own stays put):
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        500 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    let solver_balances = solver.balances(&mut ctx).await;
    assert_eq!(solver_balances.tokens["USDC"], 500 * USDC);
    assert_eq!(solver_balances.tokens["SOL"], 15 * SOL);
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        sol_leg - 5 * SOL
    );
    assert_eq!(
        available_of(&mut ctx, &vault, "USDC").await,
        1000 * USDC - usdc_leg
    );
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL - sol_leg
    );
    // No deficit left: the auction is over before its window ends (SOL dust stays in the basket).
    let state = withdraw_order_state(&mut ctx, order).await;
    assert_eq!(state.base.rebalance.end_timestamp, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // Settle: the owner receives the basket as it stands, plus the rent, and the order is gone.
    let rent_before = lamports_of(&mut ctx, lp.owner.pubkey()).await;
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    assert!(lamports_of(&mut ctx, lp.owner.pubkey()).await > rent_before);
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(
        lp_after.tokens["USDC"],
        lp_before.tokens["USDC"] + 1000 * USDC
    );
    assert_eq!(
        lp_after.tokens["SOL"],
        lp_before.tokens["SOL"] + sol_leg - 5 * SOL
    );
    assert_eq!(lp_after.shares, lp_before.shares - 1000 * SHARE);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    let vault_balances = vault.balances(&mut ctx).await;
    assert_eq!(vault_balances.token_vaults["USDC"], 1000 * USDC - usdc_leg);
    assert_eq!(vault_balances.token_vaults["SOL"], 10 * SOL - sol_leg);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_release_is_pro_rata_to_the_liquid_holdings() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;

    // Tilt the vault off its weights: 1500 USDC against 10 SOL, i.e. 60/40 by value.
    deposit(&mut ctx, &vault, &lp, "USDC", 500 * USDC).await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let supply_before = vault.balances(&mut ctx).await.shares_supply;

    // A fifth of the shares takes a fifth of each token, whatever the weights (the tilt stays):
    let order = open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        shares_issued / 5,
        &[("USDC", 1), ("SOL", 1)],
        HOUR,
    )
    .await;
    let usdc_leg = slice(1500 * USDC, shares_issued / 5, shares_issued);
    let sol_leg = slice(10 * SOL, shares_issued / 5, shares_issued);
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, usdc_leg);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_leg);
    assert_eq!(
        available_of(&mut ctx, &vault, "USDC").await,
        1500 * USDC - usdc_leg
    );
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL - sol_leg
    );
    assert_eq!(
        vault.balances(&mut ctx).await.shares_supply,
        supply_before - shares_issued / 5
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_fill_in_parts() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let sol_leg = slice(10 * SOL, 1000 * SHARE, issued(&mut ctx, &vault).await);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;

    for _ in 0..2 {
        fill_withdraw_order(
            &mut ctx,
            &solver.owner,
            &vault,
            order,
            "USDC",
            "SOL",
            200 * USDC,
            RequestedOut::AtCurve,
        )
        .await;
    }
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 900 * USDC);
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        sol_leg - 4 * SOL
    );
    assert_ne!(
        withdraw_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );

    // An input beyond the remaining deficit is clamped to it.
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        1000 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        1000 * USDC
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        sol_leg - 5 * SOL
    );
    assert_eq!(solver.balances(&mut ctx).await.tokens["USDC"], 500 * USDC);
    assert_eq!(
        withdraw_order_state(&mut ctx, order)
            .await
            .base
            .rebalance
            .end_timestamp,
        0
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_fill_rejections() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;

    // Under the minimum size, whatever the direction.
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        999,
        RequestedOut::Exact(0),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceSwapAmountBelowMinimum, 1)
    );

    // The order sheds SOL; selling it more SOL is the wrong direction.
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );

    // Asking for more than the curve pays.
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::Exact(SOL + SOL / 100),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );

    // Dust input.
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        0,
        RequestedOut::Exact(0),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::DepositAmountsZero, 1)
    );

    // Past the window.
    skip(&mut ctx, &vault, HOUR + 1).await;
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceNotInProgress, 1)
    );
}

#[tokio::test]
async fn test_order_auction_curve_and_loss_cap() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;

    // The vault sells SOL 5% under oracle throughout (the curve of a fill taking SOL for USDC):
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            vault.vault_tokens["SOL"].token_mint,
            9_500,
            9_500,
            10_000,
            10_000,
        ),
    )
    .await;

    // An order capping its loss per fill at 1% will not pay that curve.
    try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1)],
        HOUR,
        100,
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceSwapExceedsMaxLoss, 1)
    );

    // The same curve under a 10% cap.
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1)],
        HOUR,
        1000,
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);

    // The curve gives 5.26 SOL for 500 USDC, but the order only has 5 to shed.
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        500 * USDC,
        RequestedOut::Exact(5 * SOL + SOL / 10),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RequestedOutExceedsExcess, 1)
    );

    // The solver gets 100 / 95 SOL per 100 USDC.
    let sol_before = solver.balances(&mut ctx).await.tokens["SOL"];
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    let sol_after = solver.balances(&mut ctx).await.tokens["SOL"];
    assert_eq!(sol_after - sol_before, SOL * 10_000 / 9_500);
}

#[tokio::test]
async fn test_a_withdraw_order_is_capped_by_its_loss_ceiling() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    // The vault sells SOL 4% under oracle, throughout.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            vault.vault_tokens["SOL"].token_mint,
            9_600,
            9_600,
            10_000,
            10_000,
        ),
    )
    .await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 0).await;
    // A $1000 slice (500 USDC + 5 SOL) sold into USDC, 10% allowed per fill, 0.5% ($5) overall:
    try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1)],
        HOUR,
        1000,
        50,
    )
    .await
    .unwrap();
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);

    // Each 50 USDC buys ~0.52 SOL: ~$2.08 lost, twice.
    for _ in 0..2 {
        fill_withdraw_order(
            &mut ctx,
            &solver.owner,
            &vault,
            order,
            "USDC",
            "SOL",
            50 * USDC,
            RequestedOut::AtCurve,
        )
        .await;
    }
    // A third would pass the per-fill limit, but not the auction's loss ceiling.
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        50 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RebalanceLossCeilingExceeded, 1)
    );
    // What is left of it still buys a smaller fill (~$0.42).
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        10 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    let rebalance = withdraw_order_state(&mut ctx, order).await.base.rebalance;
    assert_eq!(rebalance.limits.max_loss_bps, 50);
    assert_fuzzy_eq!(
        Fraction::from_bits(rebalance.ceiling_at_start_usd_sf).to_floor::<u64>(),
        5,
        1
    );
    assert_eq!(
        Fraction::from_bits(rebalance.lost_usd_sf).to_floor::<u64>(),
        4
    );
}

#[tokio::test]
async fn test_open_validation() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    async fn open(
        ctx: &mut TestContext,
        vault: &VaultAccounts,
        lp: &VaultDepositorAccounts,
        id: u8,
        shares: u64,
        weights: &[(&str, u64)],
        duration: u64,
    ) -> Result<(), BanksClientError> {
        let no_limit = u64::from(FULL_BPS);
        try_open_withdraw_order(
            ctx, vault, lp, id, shares, weights, duration, no_limit, no_limit,
        )
        .await
    }
    let usdc_only = &[("USDC", 1)];

    let res = open(&mut ctx, &vault, &lp, 10, 1000 * SHARE, usdc_only, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidOrderId, 1)
    );
    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        usdc_only,
        HOUR,
        u64::from(FULL_BPS) + 1,
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSValueTooBig, 1)
    );
    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        usdc_only,
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS) + 1,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::BPSValueTooBig, 1)
    );
    for duration in [0, 299, 86_401] {
        let res = open(&mut ctx, &vault, &lp, 0, 1000 * SHARE, usdc_only, duration).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidOrderAuctionDuration, 1)
        );
    }
    for weights in [vec![0, 0], vec![u64::MAX, 1]] {
        let res = try_open_withdraw_order_raw(
            &mut ctx,
            &vault,
            &lp,
            0,
            1000 * SHARE,
            weights,
            HOUR,
            vec![0; 2],
            u64::from(FULL_BPS),
            u64::from(FULL_BPS),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::InvalidWeightsSum, 1)
        );
    }
    for weights in [vec![1], vec![1, 1, 1]] {
        let res = try_open_withdraw_order_raw(
            &mut ctx,
            &vault,
            &lp,
            0,
            1000 * SHARE,
            weights,
            HOUR,
            vec![0; 2],
            u64::from(FULL_BPS),
            u64::from(FULL_BPS),
        )
        .await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::TokenArrayLengthMismatch, 1)
        );
    }
    let res = open(&mut ctx, &vault, &lp, 0, 0, usdc_only, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::CannotWithdrawZeroShares, 1)
    );

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::OrderMinOpenUsd(to_sf(1001u64)),
    )
    .await;
    let res = open(&mut ctx, &vault, &lp, 0, 1000 * SHARE, usdc_only, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderBelowMinValue, 1)
    );
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::OrderMinOpenUsd(0),
    )
    .await;

    // Blocking withdrawals blocks the open too: it is the step that burns the shares.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(true),
    )
    .await;
    let res = open(&mut ctx, &vault, &lp, 0, 1000 * SHARE, usdc_only, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::VaultWithdrawsBlocked, 1)
    );
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::BlockWithdraws(false),
    )
    .await;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(false),
    )
    .await;
    let res = open(&mut ctx, &vault, &lp, 0, 1000 * SHARE, usdc_only, HOUR).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::WithdrawOrderCreationDisabled, 1)
    );
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(true),
    )
    .await;

    // Nothing above left an order behind, nor burned a share.
    assert!(
        try_withdraw_order_state(&mut ctx, withdraw_order_pda(&vault, &lp.owner.pubkey(), 0))
            .await
            .is_none()
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 1000 * USDC);
    assert_vault_covers_locked(&mut ctx, &vault).await;
    open(&mut ctx, &vault, &lp, 0, 1000 * SHARE, usdc_only, HOUR)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_shares_beyond_the_balance_burn_everything_owned() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let lp_shares = lp.balances(&mut ctx).await.shares;
    let shares_issued = issued(&mut ctx, &vault).await;
    let supply_before = vault.balances(&mut ctx).await.shares_supply;

    // Every share the owner has, for everything the vault holds but the founder's slice.
    let order = open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        u64::MAX,
        &[("USDC", 1), ("SOL", 1)],
        HOUR,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        slice(1000 * USDC, lp_shares, shares_issued)
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        slice(10 * SOL, lp_shares, shares_issued)
    );
    // The legs' flooring costs the last lamport of a share here, as with the plain withdraw.
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(lp_after.shares, 1);
    assert_eq!(
        vault.balances(&mut ctx).await.shares_supply,
        supply_before - lp_shares + lp_after.shares
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_withdrawal_fee_stays_in_the_vault() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            100,
        ),
    )
    .await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let usdc_gross = slice(1000 * USDC, 1000 * SHARE, shares_issued);
    let sol_leg = slice(10 * SOL, 1000 * SHARE, shares_issued);

    // 1% of the USDC leg stays in the vault for the holders (SOL has none): the shares burn gross.
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    let fee = usdc_gross.div_ceil(100);
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        usdc_gross - fee
    );
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_leg);
    assert_eq!(
        available_of(&mut ctx, &vault, "USDC").await,
        1000 * USDC - usdc_gross + fee
    );
    assert_eq!(issued(&mut ctx, &vault).await, shares_issued - 1000 * SHARE);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_rolling_withdraw_cap_counts_the_gross_release() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(
            vault.vault_tokens["USDC"].token_mint,
            1000,
        ),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::RollingWithdrawCap {
            max_usd_sf: to_sf(600u64),
            interval_seconds: HOUR,
        },
    )
    .await;

    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RollingWithdrawCapExceeded, 1)
    );
    // $590 fits and counts whole (fee included) against the plain withdraw's window: $30 won't.
    open_withdraw_order(&mut ctx, &vault, &lp, 0, 590 * SHARE, &[("USDC", 1)], HOUR).await;
    let res = try_withdraw(&mut ctx, &vault, &lp, 30 * SHARE, "SOL", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::RollingWithdrawCapExceeded, 1)
    );
    try_withdraw(&mut ctx, &vault, &lp, 9 * SHARE, "SOL", 0)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_expired_order_is_settled_by_anyone() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let lp_before = lp.balances(&mut ctx).await;
    let sol_leg = slice(10 * SOL, 1000 * SHARE, issued(&mut ctx, &vault).await);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        200 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    skip(&mut ctx, &vault, HOUR + 1).await;

    // A stranger's payout goes to the owner's associated accounts only (no other of theirs).
    let side_account = kp();
    token_operations::create_token_account(
        &mut ctx,
        cranker.clone(),
        &side_account,
        &vault.vault_tokens["USDC"].token_mint,
        &lp.owner.pubkey(),
    )
    .await
    .unwrap();
    let scope_accounts = get_ordered_scope_accounts(&mut ctx, &vault).await;
    let res = try_settle_withdraw_order_raw(
        &mut ctx,
        &cranker,
        &vault,
        order,
        lp.owner.pubkey(),
        scope_accounts,
        &[
            OrderTokenAccounts {
                token: vault.vault_tokens["USDC"].clone(),
                owner_ata: side_account.pubkey(),
            },
            OrderTokenAccounts {
                token: vault.vault_tokens["SOL"].clone(),
                owner_ata: lp.token_atas["SOL"],
            },
        ],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::PayoutNotToAssociatedAccount, 1)
    );

    // The basket as the auction left it, paid out by a stranger to the owner, rent included.
    let owner_lamports_before = lamports_of(&mut ctx, lp.owner.pubkey()).await;
    let rent = lamports_of(&mut ctx, order).await;
    settle_withdraw_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    assert_eq!(
        lamports_of(&mut ctx, lp.owner.pubkey()).await,
        owner_lamports_before + rent
    );
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(
        lp_after.tokens["USDC"],
        lp_before.tokens["USDC"] + 700 * USDC
    );
    assert_eq!(
        lp_after.tokens["SOL"],
        lp_before.tokens["SOL"] + sol_leg - 2 * SOL
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_only_the_owner_may_settle_a_live_auction() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let stranger = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let lp_before = lp.balances(&mut ctx).await;
    let sol_leg = slice(10 * SOL, 1000 * SHARE, issued(&mut ctx, &vault).await);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        200 * USDC,
        RequestedOut::AtCurve,
    )
    .await;

    // Mid-auction a stranger cannot end it.
    let res = try_settle_withdraw_order(&mut ctx, &stranger, &vault, order).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAuctionStillRunning, 1)
    );

    // The owner can, taking the basket as it stands.
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(
        lp_after.tokens["USDC"],
        lp_before.tokens["USDC"] + 700 * USDC
    );
    assert_eq!(
        lp_after.tokens["SOL"],
        lp_before.tokens["SOL"] + sol_leg - 2 * SOL
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_completed_auction_is_settled_by_anyone_before_its_window_ends() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let cranker = funded_new_kp(&mut ctx, LAMPORTS_PER_SOL);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        500 * USDC,
        RequestedOut::AtCurve,
    )
    .await;

    // The fill that completes the basket ends the auction, and with it the owner's exclusivity.
    settle_withdraw_order(&mut ctx, &cranker, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_needs_every_held_token_and_only_those() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    let owner = lp.owner.pubkey();
    let usdc = OrderTokenAccounts {
        token: vault.vault_tokens["USDC"].clone(),
        owner_ata: lp.token_atas["USDC"],
    };
    let sol = OrderTokenAccounts {
        token: vault.vault_tokens["SOL"].clone(),
        owner_ata: lp.token_atas["SOL"],
    };
    async fn settle(
        ctx: &mut TestContext,
        vault: &VaultAccounts,
        lp: &VaultDepositorAccounts,
        order: Pubkey,
        owner: Pubkey,
        per_token: &[OrderTokenAccounts],
    ) -> Result<(), BanksClientError> {
        try_settle_withdraw_order_raw(ctx, &lp.owner, vault, order, owner, vec![], per_token).await
    }

    // Both tokens are held, so both sets are needed, and nothing beyond them.
    for per_token in [vec![], vec![usdc.clone()]] {
        let res = settle(&mut ctx, &vault, &lp, order, owner, &per_token).await;
        assert_eq!(
            res.unwrap_err().unwrap(),
            metavault_error!(KaminoVaultError::OrderTokensNotCovered, 1)
        );
    }
    let res = settle(
        &mut ctx,
        &vault,
        &lp,
        order,
        owner,
        &[usdc.clone(), sol.clone(), usdc.clone()],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::UnexpectedRemainingAccounts, 1)
    );

    // Someone else's token account is not where the payout goes, nor is someone else the owner.
    let other = usdc_holder(&mut ctx, &vault, 0).await;
    let res = settle(
        &mut ctx,
        &vault,
        &lp,
        order,
        owner,
        &[
            OrderTokenAccounts {
                token: vault.vault_tokens["USDC"].clone(),
                owner_ata: other.token_atas["USDC"],
            },
            sol.clone(),
        ],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );
    let res = settle(
        &mut ctx,
        &vault,
        &lp,
        order,
        other.owner.pubkey(),
        &[usdc.clone(), sol.clone()],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );

    // The owner's account of another token is not where the payout goes either.
    let res = settle(
        &mut ctx,
        &vault,
        &lp,
        order,
        owner,
        &[
            OrderTokenAccounts {
                token: vault.vault_tokens["USDC"].clone(),
                owner_ata: lp.token_atas["SOL"],
            },
            sol.clone(),
        ],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::OrderAccountMismatch, 1)
    );

    // Nothing moved through any attempt. The owner's own settle may name any account of theirs.
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, 500 * USDC);
    let side_account = kp();
    token_operations::create_token_account(
        &mut ctx,
        lp.owner.clone(),
        &side_account,
        &usdc.token.token_mint,
        &owner,
    )
    .await
    .unwrap();
    let usdc_to_side_account = OrderTokenAccounts {
        owner_ata: side_account.pubkey(),
        ..usdc
    };
    settle(
        &mut ctx,
        &vault,
        &lp,
        order,
        owner,
        &[usdc_to_side_account, sol],
    )
    .await
    .unwrap();
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    assert_eq!(
        token_operations::balance(&mut ctx, &side_account.pubkey()).await,
        500 * USDC
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_locked_amounts_are_not_the_vaults_to_pay_out() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let shares_issued = issued(&mut ctx, &vault).await;
    let usdc_leg = slice(1000 * USDC, 1000 * SHARE, shares_issued);
    let sol_leg = slice(10 * SOL, 1000 * SHARE, shares_issued);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(
            vault.vault_tokens["USDC"].token_mint,
            0,
        ),
    )
    .await;

    // The LP's remaining $1000 claim withdraws only the vault's own 500 USDC (the order's stay put).
    let lp_before = lp.balances(&mut ctx).await;
    try_withdraw(&mut ctx, &vault, &lp, lp_before.shares, "USDC", 0)
        .await
        .unwrap();
    assert_eq!(
        lp.balances(&mut ctx).await.tokens["USDC"],
        lp_before.tokens["USDC"] + 1000 * USDC - usdc_leg
    );
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, usdc_leg);
    assert_eq!(
        vault.balances(&mut ctx).await.token_vaults["USDC"],
        usdc_leg
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;

    let lp_before = lp.balances(&mut ctx).await;
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(lp_after.tokens["USDC"], lp_before.tokens["USDC"] + usdc_leg);
    assert_eq!(lp_after.tokens["SOL"], lp_before.tokens["SOL"] + sol_leg);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_two_orders_of_one_owner() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let first =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 400 * SHARE, &[("USDC", 1)], HOUR).await;
    let first_usdc = slice(1000 * USDC, 400 * SHARE, shares_issued);
    // The second takes its share of what the first left.
    let second =
        open_withdraw_order(&mut ctx, &vault, &lp, 1, 320 * SHARE, &[("SOL", 1)], HOUR).await;
    let second_usdc = slice(
        1000 * USDC - first_usdc,
        320 * SHARE,
        shares_issued - 400 * SHARE,
    );
    assert_ne!(first, second);
    // An id in use cannot be opened again: the account exists.
    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        0,
        10 * SHARE,
        &[("USDC", 1)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        TransactionError::InstructionError(
            1,
            InstructionError::Custom(SystemError::AccountAlreadyInUse as u32) // Anchor's `init`
        )
    );
    assert_eq!(locked_of(&mut ctx, &vault, first, "USDC").await, first_usdc);
    assert_eq!(
        locked_of(&mut ctx, &vault, second, "USDC").await,
        second_usdc
    );
    assert_eq!(
        locked_total(&mut ctx, &vault, "USDC").await,
        first_usdc + second_usdc
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;

    settle_withdraw_order(&mut ctx, &lp.owner, &vault, second).await;
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, first_usdc);
    assert_eq!(locked_of(&mut ctx, &vault, first, "USDC").await, first_usdc);
    assert_vault_covers_locked(&mut ctx, &vault).await;

    // A closed id can be used again, for a fresh order.
    let shares_issued = issued(&mut ctx, &vault).await;
    let available_usdc = available_of(&mut ctx, &vault, "USDC").await;
    let again =
        open_withdraw_order(&mut ctx, &vault, &lp, 1, 100 * SHARE, &[("SOL", 1)], HOUR).await;
    assert_eq!(again, second);
    assert_eq!(
        locked_of(&mut ctx, &vault, again, "USDC").await,
        slice(available_usdc, 100 * SHARE, shares_issued)
    );
    let now = ctx.get_clock().await.unix_timestamp as u64;
    assert_eq!(
        withdraw_order_state(&mut ctx, again)
            .await
            .base
            .rebalance
            .end_timestamp,
        now + HOUR
    );
}

#[tokio::test]
async fn test_four_orders_per_owner_per_kind() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    for switch in [
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderFillEnabled(true),
    ] {
        update_vault_config(&mut ctx, &admin, &vault, switch).await;
    }
    let depositor = usdc_holder(&mut ctx, &vault, 500 * USDC).await;
    for id in 0..4 {
        open_withdraw_order(&mut ctx, &vault, &lp, id, 10 * SHARE, &[("USDC", 1)], HOUR).await;
        open_deposit_order(
            &mut ctx,
            &vault,
            &depositor,
            id,
            &[("USDC", 10 * USDC)],
            HOUR,
        )
        .await;
    }
    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        4,
        10 * SHARE,
        &[("USDC", 1)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidOrderId, 1)
    );
    let res = try_open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        4,
        &[("USDC", 10 * USDC)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidOrderId, 1)
    );
    // The two kinds have their own address spaces.
    assert_ne!(
        withdraw_order_pda(&vault, &lp.owner.pubkey(), 0),
        deposit_order_pda(&vault, &lp.owner.pubkey(), 0)
    );
}

#[tokio::test]
async fn test_two_owners_share_an_id() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let other = usdc_holder(&mut ctx, &vault, 200 * USDC).await;
    deposit(&mut ctx, &vault, &other, "USDC", 200 * USDC).await;
    let other_before = other.balances(&mut ctx).await;
    let lp_before = lp.balances(&mut ctx).await;

    let first =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 100 * SHARE, &[("USDC", 1)], HOUR).await;
    let second = open_withdraw_order(
        &mut ctx,
        &vault,
        &other,
        0,
        100 * SHARE,
        &[("USDC", 1)],
        HOUR,
    )
    .await;
    assert_ne!(first, second);
    let first_usdc = locked_of(&mut ctx, &vault, first, "USDC").await;
    let second_usdc = locked_of(&mut ctx, &vault, second, "USDC").await;

    // Each owner gets their own basket back, whatever the order of the settles.
    settle_withdraw_order(&mut ctx, &other.owner, &vault, second).await;
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, first).await;
    assert_eq!(
        other.balances(&mut ctx).await.tokens["USDC"],
        other_before.tokens["USDC"] + second_usdc
    );
    assert_eq!(
        lp.balances(&mut ctx).await.tokens["USDC"],
        lp_before.tokens["USDC"] + first_usdc
    );
    assert_eq!(locked_total(&mut ctx, &vault, "USDC").await, 0);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_unwanted_tokens_are_sold_down_to_dust_which_is_paid_out_too() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let lp_before = lp.balances(&mut ctx).await;
    let sol_leg = slice(10 * SOL, 1000 * SHARE, issued(&mut ctx, &vault).await);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;

    // 500 lamports short of the USDC deficit is within tolerance, so the auction is over with the
    // 5000 lamports of SOL they would have bought still in the basket (excess is no progress).
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        500 * USDC - 500,
        RequestedOut::AtCurve,
    )
    .await;
    let state = withdraw_order_state(&mut ctx, order).await;
    assert_eq!(state.base.rebalance.end_timestamp, 0);
    let sol_bought = solver.balances(&mut ctx).await.tokens["SOL"] - 10 * SOL;
    assert_eq!(sol_bought, 5 * SOL - 5_000 - 1); // the curve floors the lamport it pays
    let sol_dust = sol_leg - sol_bought;
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_dust);

    // The payout carries the dust along: the owner needs an account for every token held.
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(
        lp_after.tokens["USDC"],
        lp_before.tokens["USDC"] + 1000 * USDC - 500
    );
    assert_eq!(lp_after.tokens["SOL"], lp_before.tokens["SOL"] + sol_dust);
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, 0);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_emergency_mode_blocks_every_order_instruction() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 500 * SHARE, &[("USDC", 1)], HOUR).await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::EmergencyMode(true),
    )
    .await;

    let expected = metavault_error!(KaminoVaultError::VaultEmergencyMode, 1);
    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &lp,
        1,
        500 * SHARE,
        &[("USDC", 1)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
    let res = try_settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    assert_eq!(res.unwrap_err().unwrap(), expected);
}

#[tokio::test]
async fn test_fill_switch_stops_order_fills_but_not_the_vaults_own() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let sol_leg = slice(10 * SOL, 1000 * SHARE, issued(&mut ctx, &vault).await);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;

    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::WithdrawOrderFillEnabled(false),
    )
    .await;
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::WithdrawOrderFillDisabled, 1)
    );

    // The vault's own rebalance fills are a different arm and answer to none of the order switches.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, HOUR).await;
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "USDC",
        "SOL",
        500 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    let sol_bought = solver.balances(&mut ctx).await.tokens["SOL"] - 10 * SOL;
    assert_ne!(sol_bought, 0);
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL - sol_leg - sol_bought
    );
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_leg);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_settle_answers_to_none_of_the_switches() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let lp_before = lp.balances(&mut ctx).await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    for switch in [
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(false),
        UpdateVaultConfigParams::WithdrawOrderFillEnabled(false),
        UpdateVaultConfigParams::BlockWithdraws(true),
    ] {
        update_vault_config(&mut ctx, &admin, &vault, switch).await;
    }

    // The owner always gets their basket back.
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    let lp_after = lp.balances(&mut ctx).await;
    assert_eq!(
        lp_after.tokens["USDC"],
        lp_before.tokens["USDC"] + slice(1000 * USDC, 1000 * SHARE, shares_issued)
    );
    assert_eq!(
        lp_after.tokens["SOL"],
        lp_before.tokens["SOL"] + slice(10 * SOL, 1000 * SHARE, shares_issued)
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_krfq_gate_keys_the_fill_on_the_order() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    let krfq_server = kp();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::KrfqEnabled(true),
    )
    .await;
    set_global_config(
        &mut ctx,
        &GlobalConfig {
            krfq_swap_authority: krfq_server.pubkey(),
            ..Default::default()
        },
    );

    async fn fill(
        ctx: &mut TestContext,
        vault: &VaultAccounts,
        solver: &VaultDepositorAccounts,
        order: Pubkey,
        krfq_authority: Option<&KP>,
        marker: KrfqMarker,
    ) -> Result<(), BanksClientError> {
        try_fill_withdraw_order_with_krfq_marker(
            ctx,
            &solver.owner,
            vault,
            order,
            "USDC",
            "SOL",
            100 * USDC,
            RequestedOut::AtCurve,
            krfq_authority,
            pda::global_config(),
            marker,
        )
        .await
    }
    let res = fill(&mut ctx, &vault, &solver, order, None, KrfqMarker::Derived).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqAuthorityMissing, 1)
    );
    let res = fill(
        &mut ctx,
        &vault,
        &solver,
        order,
        Some(&krfq_server),
        KrfqMarker::Omitted,
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqFillMarkerMissing, 1)
    );
    // The vault's own marker for the same pair authorizes a different fill.
    let vault_marker = pda::krfq_fill_marker(
        &vault.vault_state.pubkey(),
        &vault.vault_tokens["USDC"].token_mint,
        &vault.vault_tokens["SOL"].token_mint,
    );
    let res = fill(
        &mut ctx,
        &vault,
        &solver,
        order,
        Some(&krfq_server),
        KrfqMarker::Wrong(vault_marker),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::KrfqFillMarkerIncorrect, 1)
    );
    fill(
        &mut ctx,
        &vault,
        &solver,
        order,
        Some(&krfq_server),
        KrfqMarker::Derived,
    )
    .await
    .unwrap();
}

#[tokio::test]
async fn test_a_fill_names_at_most_one_order() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    for switch in [
        UpdateVaultConfigParams::DepositOrderCreationEnabled(true),
        UpdateVaultConfigParams::DepositOrderFillEnabled(true),
    ] {
        update_vault_config(&mut ctx, &admin, &vault, switch).await;
    }
    let depositor = usdc_holder(&mut ctx, &vault, 1000 * USDC).await;
    let deposit_order = open_deposit_order(
        &mut ctx,
        &vault,
        &depositor,
        0,
        &[("USDC", 1000 * USDC)],
        HOUR,
    )
    .await;
    let withdraw_order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 500 * SHARE, &[("USDC", 1)], HOUR).await;
    let withdraw_usdc = locked_of(&mut ctx, &vault, withdraw_order, "USDC").await;

    // The malformed shape, naming both, is refused before either is touched.
    let scope_accounts = get_ordered_scope_accounts(&mut ctx, &vault).await;
    let tx = instructions::rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        &solver.token_atas["USDC"],
        &solver.token_atas["SOL"],
        &vault.vault_tokens["USDC"],
        &vault.vault_tokens["SOL"],
        100 * USDC,
        SOL,
        scope_accounts,
        None,
        pda::global_config(),
        None,
        Some(deposit_order),
        Some(withdraw_order),
    )
    .await;
    let res = send_transaction!(ctx, tx);
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InconsistentOrderAccounts, 1)
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, withdraw_order, "USDC").await,
        withdraw_usdc
    );
    assert_eq!(
        locked_total(&mut ctx, &vault, "USDC").await,
        withdraw_usdc + 1000 * USDC
    );

    // Named alone, the same fill goes through.
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        withdraw_order,
        "USDC",
        "SOL",
        100 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(
        locked_of(&mut ctx, &vault, withdraw_order, "USDC").await,
        withdraw_usdc + 100 * USDC
    );
}

#[tokio::test]
async fn test_vault_rebalance_and_orders_do_not_interfere() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let usdc_leg = slice(1000 * USDC, 1000 * SHARE, shares_issued);
    let sol_leg = slice(10 * SOL, 1000 * SHARE, shares_issued);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("SOL", 1)], HOUR).await;

    // The vault goes all USDC, the order wants all SOL: each fill leaves the other's tokens alone.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, HOUR).await;
    assert!(vault.state(&mut ctx).await.rebalance.is_unfinished());
    rebalance_swap(
        &mut ctx,
        &solver.owner,
        &vault,
        "USDC",
        "SOL",
        500 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    let solver_balances = solver.balances(&mut ctx).await;
    let (usdc_sold, sol_bought) = (
        1000 * USDC - solver_balances.tokens["USDC"],
        solver_balances.tokens["SOL"] - 10 * SOL,
    );
    assert_ne!(sol_bought, 0);
    let (vault_usdc, vault_sol) = (
        1000 * USDC - usdc_leg + usdc_sold,
        10 * SOL - sol_leg - sol_bought,
    );
    assert_eq!(locked_of(&mut ctx, &vault, order, "USDC").await, usdc_leg);
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_leg);
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, vault_usdc);
    assert_eq!(available_of(&mut ctx, &vault, "SOL").await, vault_sol);
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "SOL",
        "USDC",
        SOL,
        RequestedOut::AtCurve,
    )
    .await;
    assert_eq!(available_of(&mut ctx, &vault, "USDC").await, vault_usdc);
    assert_eq!(available_of(&mut ctx, &vault, "SOL").await, vault_sol);
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        usdc_leg - 100 * USDC
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        sol_leg + SOL
    );
    assert_eq!(
        locked_total(&mut ctx, &vault, "USDC").await,
        usdc_leg - 100 * USDC
    );
    assert_eq!(locked_total(&mut ctx, &vault, "SOL").await, sol_leg + SOL);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_open_during_the_vaults_rebalance_scales_its_deficit_down() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1, 0]),
    )
    .await;
    start_rebalance(&mut ctx, &admin, &vault, HOUR).await;
    let shares_issued = issued(&mut ctx, &vault).await;

    // The vault wants its 10 SOL in USDC: releasing half of everything halves the job (5 SOL left).
    open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    let state = vault.state(&mut ctx).await;
    assert!(state.rebalance.is_unfinished());
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        10 * SOL - slice(10 * SOL, 1000 * SHARE, shares_issued)
    );

    // Releasing (nearly) all of the rest leaves nothing worth selling: the rebalance is over.
    let lp_shares = lp.balances(&mut ctx).await.shares;
    let issued_now = issued(&mut ctx, &vault).await;
    let sol_available = available_of(&mut ctx, &vault, "SOL").await;
    open_withdraw_order(&mut ctx, &vault, &lp, 1, u64::MAX, &[("USDC", 1)], HOUR).await;
    assert!(!vault.state(&mut ctx).await.rebalance.is_unfinished());
    assert_eq!(
        available_of(&mut ctx, &vault, "SOL").await,
        sol_available - slice(sol_available, lp_shares, issued_now)
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_vault_weight_change_leaves_a_live_orders_targets_alone() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    let usdc_target = withdraw_order_rebalance_target(&mut ctx, &vault, order, "USDC").await;
    assert_eq!(usdc_target, 1000 * USDC);

    // The order targets its owner's weights, not the vault's.
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![0, 1]),
    )
    .await;
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, order, "USDC").await,
        usdc_target
    );
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, order, "SOL").await,
        0
    );
}

#[tokio::test]
async fn test_a_token_added_to_the_vault_joins_live_orders_unwanted() {
    let (mut ctx, mut vault, lp) = setup_balanced_vault().await;
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;
    add_priced_spl_token(&mut ctx, &mut vault, "ETH", 8, 2000.0).await;

    // The new token holds nothing in the order and has no weight there: not a side of any fill.
    assert_eq!(locked_of(&mut ctx, &vault, order, "ETH").await, 0);
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, order, "ETH").await,
        0
    );
    let res = try_fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "ETH",
        "SOL",
        1_000_000,
        RequestedOut::Exact(0),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::InvalidSwapPair, 1)
    );
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        500 * USDC,
        RequestedOut::AtCurve,
    )
    .await;
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());

    // A new order may want the new token (the vault holds none to release: all of it is a deficit).
    let wants_eth =
        open_withdraw_order(&mut ctx, &vault, &lp, 1, 500 * SHARE, &[("ETH", 1)], HOUR).await;
    assert_eq!(locked_of(&mut ctx, &vault, wants_eth, "ETH").await, 0);
    // A hair over $500 (500 of the 999,999,998 shares left): a quarter ETH at $2000, hair floored.
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, wants_eth, "ETH").await,
        25_000_000
    );
    assert_eq!(
        withdraw_order_rebalance_target(&mut ctx, &vault, wants_eth, "USDC").await,
        0
    );
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_open_mints_the_pending_fee_shares_first() {
    // 2% a year, a year since the last charge: the fee shares mint before the claim is priced.
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(200),
    )
    .await;
    skip(&mut ctx, &vault, u64::from(YEAR)).await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let fee_shares = shares_issued / 49;
    let diluted = shares_issued + fee_shares;
    let lp_before = lp.balances(&mut ctx).await;

    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;

    assert_eq!(
        locked_of(&mut ctx, &vault, order, "USDC").await,
        slice(1000 * USDC, 1000 * SHARE, diluted)
    );
    assert_eq!(
        locked_of(&mut ctx, &vault, order, "SOL").await,
        slice(10 * SOL, 1000 * SHARE, diluted)
    );
    assert_eq!(
        lp.balances(&mut ctx).await.shares,
        lp_before.shares - 1000 * SHARE
    );
    assert_eq!(issued(&mut ctx, &vault).await, diluted - 1000 * SHARE);
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_a_floor_on_any_token_out_refuses_an_open_releasing_less_of_it() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);
    let sol_leg = slice(10 * SOL, 1000 * SHARE, issued(&mut ctx, &vault).await);

    // 1000 shares take 500 USDC and a hair over 5 SOL: a lamport more SOL refuses, exactly passes.
    let res = try_open_withdraw_order_with_min_tokens_out(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1)],
        HOUR,
        &[("USDC", 500 * USDC), ("SOL", sol_leg + 1)],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    try_open_withdraw_order_with_min_tokens_out(
        &mut ctx,
        &vault,
        &lp,
        0,
        1000 * SHARE,
        &[("USDC", 1)],
        HOUR,
        &[("USDC", 500 * USDC), ("SOL", sol_leg)],
    )
    .await
    .unwrap();
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, sol_leg);
}

#[tokio::test]
async fn test_open_rejects_another_holders_shares_account() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let other = usdc_holder(&mut ctx, &vault, 0).await;
    let imposter = VaultDepositorAccounts {
        shares_ata: other.shares_ata,
        ..lp.clone()
    };

    // Anchor's token authority constraint on `owner_shares_ata`.
    let res = try_open_withdraw_order(
        &mut ctx,
        &vault,
        &imposter,
        0,
        10 * SHARE,
        &[("USDC", 1)],
        HOUR,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        anchor_error!(ErrorCode::ConstraintTokenOwner, 1)
    );
    let order = withdraw_order_pda(&vault, &lp.owner.pubkey(), 0);
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
}

#[tokio::test]
async fn test_a_leg_sold_out_needs_no_accounts_at_settle() {
    let (mut ctx, vault, lp) = setup_balanced_vault().await;
    let admin = ctx.initial_market_owner.clone();
    let solver = token_holder(&mut ctx, &vault, 1000 * USDC, 10 * SOL).await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(1000),
    )
    .await;
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            vault.vault_tokens["SOL"].token_mint,
            9_500,
            9_500,
            10_000,
            10_000,
        ),
    )
    .await;
    let shares_issued = issued(&mut ctx, &vault).await;
    let sol_leg = slice(10 * SOL, 1000 * SHARE, shares_issued);
    let order =
        open_withdraw_order(&mut ctx, &vault, &lp, 0, 1000 * SHARE, &[("USDC", 1)], HOUR).await;

    // At 5% under oracle, 476 USDC buys the whole SOL leg (worth a hair over $500).
    fill_withdraw_order(
        &mut ctx,
        &solver.owner,
        &vault,
        order,
        "USDC",
        "SOL",
        476 * USDC,
        RequestedOut::Exact(sol_leg),
    )
    .await;
    assert_eq!(locked_of(&mut ctx, &vault, order, "SOL").await, 0);

    // The empty slot takes no accounts, and the rest is paid out without them.
    let owner = lp.owner.pubkey();
    let usdc = OrderTokenAccounts {
        token: vault.vault_tokens["USDC"].clone(),
        owner_ata: lp.token_atas["USDC"],
    };
    let sol = OrderTokenAccounts {
        token: vault.vault_tokens["SOL"].clone(),
        owner_ata: lp.token_atas["SOL"],
    };
    let res = try_settle_withdraw_order_raw(
        &mut ctx,
        &lp.owner,
        &vault,
        order,
        owner,
        vec![],
        &[usdc.clone(), sol],
    )
    .await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::UnexpectedRemainingAccounts, 1)
    );
    let lp_before = lp.balances(&mut ctx).await;
    try_settle_withdraw_order_raw(&mut ctx, &lp.owner, &vault, order, owner, vec![], &[usdc])
        .await
        .unwrap();
    assert_eq!(
        lp.balances(&mut ctx).await.tokens["USDC"],
        lp_before.tokens["USDC"] + 500 * USDC + 476 * USDC
    );
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

#[tokio::test]
async fn test_open_and_settle_on_a_full_vault_with_obligations() {
    // A full vault (MAX_TOKENS_PER_VAULT tokens, an obligation of 2 collateral legs and a borrow),
    // so the open reads a full AUM layout (`test-sbf` logs each instruction's compute units).
    let spec = MarketsSpec {
        mints: hashmap! {
            "USDC".to_string() => MintSpec::spl(6, 1.0),
            "SOL".to_string() => MintSpec::spl(9, 100.0),
            "ETH".to_string() => MintSpec::spl(8, 2000.0),
        },
        markets: vec![MSpec::new(vec![
            RSpec::new("USDC", 10_000_000_000),
            RSpec::new("SOL", 0),
            RSpec::new("ETH", 0),
        ])],
    };
    let (mut ctx, markets, mut vault) =
        fixtures::setup_markets_with_weights(&spec, vec![1, 1, 1]).await;
    let admin = ctx.initial_market_owner.clone();
    let market = markets.markets[0].primary_market.clone();
    let sol_reserve = markets.markets[0].reserves["SOL"].clone();
    let eth_reserve = markets.markets[0].reserves["ETH"].clone();
    let usdc_reserve = markets.markets[0].reserves["USDC"].clone();
    let extra = ["BTC", "JTO", "BONK", "WIF", "PYTH", "RAY", "JUP"];
    for name in extra {
        add_priced_spl_token(&mut ctx, &mut vault, name, 6, 2.0).await;
    }
    let names: Vec<&str> = ["USDC", "SOL", "ETH"].into_iter().chain(extra).collect();
    let lp = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        names
            .iter()
            .map(|name| (name.to_string(), 20_000_000_000))
            .collect(),
    )
    .await;
    for name in &names {
        deposit(&mut ctx, &vault, &lp, name, 10_000_000_000).await;
    }
    instructions_init_obligation(&mut ctx, &admin, &vault, &market, 0).await;
    let obligation =
        instructions::vault_obligation_pda(&market.market.pubkey(), &vault.base_vault_authority, 0);
    try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &sol_reserve,
        obligation,
        "SOL",
        5_000_000_000,
        vec![],
        vec![],
    )
    .await
    .unwrap();
    try_deposit_obligation_collateral(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &eth_reserve,
        obligation,
        "ETH",
        250_000_000,
        vec![&sol_reserve],
        vec![],
    )
    .await
    .unwrap();
    try_borrow_obligation_liquidity(
        &mut ctx,
        &admin,
        &vault,
        &market,
        &usdc_reserve,
        obligation,
        "USDC",
        100_000_000,
        vec![&sol_reserve, &eth_reserve],
        vec![],
    )
    .await
    .unwrap();
    update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(true),
    )
    .await;

    let shares = lp.balances(&mut ctx).await.shares / 2;
    let weights: Vec<(&str, u64)> = names.iter().map(|name| (*name, 1)).collect();
    // The open reads the obligation, which klend must have refreshed in the same slot:
    instructions::submit_obligation_refresh(
        &mut ctx,
        &admin,
        &market,
        &sol_reserve,
        obligation,
        vec![&sol_reserve, &eth_reserve],
        vec![&usdc_reserve],
    )
    .await;
    let order = open_withdraw_order(&mut ctx, &vault, &lp, 0, shares, &weights, HOUR).await;
    for name in &names {
        assert!(locked_of(&mut ctx, &vault, order, name).await > 0);
    }
    // The owner settles at once (allowed at any time), paying all ten legs out:
    settle_withdraw_order(&mut ctx, &lp.owner, &vault, order).await;
    assert!(try_withdraw_order_state(&mut ctx, order).await.is_none());
    assert_vault_covers_locked(&mut ctx, &vault).await;
}

// ── Helpers ──────────────────────────────────────────────────────────

async fn setup_balanced_vault() -> (TestContext, VaultAccounts, VaultDepositorAccounts) {
    fixtures::setup_balanced_vault(vec![
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(true),
        UpdateVaultConfigParams::WithdrawOrderFillEnabled(true),
    ])
    .await
}

async fn issued(ctx: &mut TestContext, vault: &VaultAccounts) -> u64 {
    vault.state(ctx).await.shares_issued
}

// The pro-rata slice of `available` that `shares` of `issued` take, floored as the program does
// (equal to their claim on the net AUM while the vault has no obligations).
fn slice(available: u64, shares: u64, issued: u64) -> u64 {
    (u128::from(available) * u128::from(shares) / u128::from(issued)) as u64
}

async fn locked_of(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    order: Pubkey,
    token: &str,
) -> u64 {
    locked_amount_of::<WithdrawOrder>(ctx, vault, order, token).await
}

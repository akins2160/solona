use ::metavault::program_test::VaultDepositorAccounts;
use kamino_lending::program_test::common::math::usdc_decimal_to_u64;
use metavault::{
    metavault_error,
    program_test::{
        client::{self, UpdateVaultConfigParams},
        fixtures, setup,
    },
    utils::consts::{INITIAL_DEPOSIT_SIZE, YEAR},
    KaminoVaultError,
};
use solana_program_test::tokio;
use usdc_decimal_to_u64 as usdc;

// - [x] partial withdraw + total withdraw (no mgmt fees)
// - [ ] partial withdraw + total withdraw (with mgmt fees)
// - [x] withdraw less than 1 lamport fails

#[tokio::test]
async fn test_partial_and_total_withdraw_no_fees() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(0).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    let withdraw = deposit / 3;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_withdraw.tokens["USDC"], withdraw);
    assert_eq!(balances_after_withdraw.shares, deposit - 1 - withdraw);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.shares_issued,
        deposit - 1 - withdraw + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit - 1 - withdraw + INITIAL_DEPOSIT_SIZE + 1
    );

    client::withdraw(&mut ctx, &vault, &depositor, deposit - 1 - withdraw, "USDC").await;

    let balances_after_total_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_total_withdraw.tokens["USDC"], deposit - 1);
    assert_eq!(balances_after_total_withdraw.shares, 0);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE + 1
    );
}

#[tokio::test]
async fn test_partial_and_total_withdraw_from_available_with_mgmt_fees() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(0).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // set mgmt fees to 2% per year and advance half a year
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(200),
    )
    .await;

    // advance half a year
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    let withdraw = deposit / 2;
    let expected_user_loss_on_withdrawal = withdraw * 2 / 100 / 2; // 2% per year, half a year, on the withdrawn amount
    let vault_state = vault.state(&mut ctx).await;
    let expected_shares_minted_as_mgmt_fee =
        (vault_state.shares_issued as f64 * 0.01 / 0.99) as u64;

    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after_first_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after_first_withdraw.tokens["USDC"],
        withdraw - expected_user_loss_on_withdrawal
    );
    assert_eq!(balances_after_first_withdraw.shares, deposit - 1 - withdraw);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.shares_issued,
        deposit - 1 - withdraw + expected_shares_minted_as_mgmt_fee + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit - withdraw + expected_user_loss_on_withdrawal + INITIAL_DEPOSIT_SIZE
    );

    // pass half a year more and withdraw everything
    ctx.fast_forward_seconds(u64::from(YEAR) / 2).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    let vault_state = vault.state(&mut ctx).await;
    let expected_shares_minted_as_mgmt_fee_second_period =
        (vault_state.shares_issued as f64 * 0.01 / 0.99) as u64;
    let user_fee_from_first_period = deposit * 2 / 100 / 2; // 2% per year, half a year for the first period
    let user_net_aum_in_vault = deposit / 2 - expected_user_loss_on_withdrawal; // as user withdrew half of the deposit what is in position (aum -  fees) is exactly how much he received
    let user_fee_from_second_period = user_net_aum_in_vault * 2 / 100 / 2; // 2% per year, half a year for the second period
    let total_user_fee = user_fee_from_first_period + user_fee_from_second_period;

    client::withdraw(
        &mut ctx,
        &vault,
        &depositor,
        balances_after_first_withdraw.shares,
        "USDC",
    )
    .await;

    let balances_after_total_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(
        balances_after_total_withdraw.tokens["USDC"],
        deposit - total_user_fee
    );
    assert_eq!(balances_after_total_withdraw.shares, 0);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.shares_issued,
        INITIAL_DEPOSIT_SIZE
            + expected_shares_minted_as_mgmt_fee
            + expected_shares_minted_as_mgmt_fee_second_period
    );
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        total_user_fee + INITIAL_DEPOSIT_SIZE
    );
}

#[tokio::test]
async fn test_withdraw_from_available_works_after_allocation() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(1).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    let withdraw = deposit / 3;
    client::withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC").await;

    let balances_after_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_withdraw.tokens["USDC"], withdraw);
    assert_eq!(balances_after_withdraw.shares, deposit - 1 - withdraw);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(
        vault_state.shares_issued,
        deposit - 1 - withdraw + INITIAL_DEPOSIT_SIZE
    );
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        deposit - 1 - withdraw + INITIAL_DEPOSIT_SIZE + 1
    );

    // withdraw the rest
    client::withdraw(&mut ctx, &vault, &depositor, deposit - 1 - withdraw, "USDC").await;

    let balances_after_total_withdraw = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after_total_withdraw.tokens["USDC"], deposit - 1);
    assert_eq!(balances_after_total_withdraw.shares, 0);

    let vault_state = vault.state(&mut ctx).await;
    assert_eq!(vault_state.shares_issued, INITIAL_DEPOSIT_SIZE);
    assert_eq!(
        vault_state.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE + 1
    );
}

#[tokio::test]
async fn test_withdraw_less_than_1_lamport_fails() {
    let (mut ctx, vault, owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(0).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;
    let balances_before = depositor.balances(&mut ctx).await;
    assert_eq!(balances_before.shares, 0);
    assert_eq!(balances_before.tokens["USDC"], usdc(100.0));

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.tokens["USDC"], 0);
    assert_eq!(balances_after.shares, deposit - 1);

    // set mgmt fees to 2% per year and advance a year
    client::update_vault_config(
        &mut ctx,
        &owner,
        &vault,
        UpdateVaultConfigParams::ManagementFeeBps(200),
    )
    .await;

    // advance half a year
    ctx.fast_forward_seconds(u64::from(YEAR)).await;
    setup::update_scope_px_and_twap(&mut ctx, &vault, "USDC", 1.0, 1.0).await;

    let withdraw = 1;
    let res = client::try_withdraw(&mut ctx, &vault, &depositor, withdraw, "USDC", 0).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::CannotWithdrawZeroLamports, 1)
    );
}

#[tokio::test]
async fn test_withdraw_slippage_exceeded() {
    let (mut ctx, vault, _owner, _investor, _mkts) = fixtures::setup_markets_and_reserves(0).await;

    let topup = usdc(100.0);
    let depositor = VaultDepositorAccounts::new(&mut ctx, &vault, "USDC", topup).await;

    let deposit = topup;
    client::deposit(&mut ctx, &vault, &depositor, "USDC", deposit).await;

    let balances_after = depositor.balances(&mut ctx).await;
    assert_eq!(balances_after.shares, deposit - 1);

    // Withdrawing all shares yields deposit - 1 tokens (floor rounding),
    // so requesting min_tokens_out = deposit should fail
    let res =
        client::try_withdraw(&mut ctx, &vault, &depositor, deposit - 1, "USDC", deposit).await;
    assert_eq!(
        res.unwrap_err().unwrap(),
        metavault_error!(KaminoVaultError::SlippageExceeded, 1)
    );

    // Requesting min_tokens_out = deposit - 1 (the actual received amount) should succeed
    client::try_withdraw(
        &mut ctx,
        &vault,
        &depositor,
        deposit - 1,
        "USDC",
        deposit - 1,
    )
    .await
    .unwrap();

    let balances_final = depositor.balances(&mut ctx).await;
    assert_eq!(balances_final.shares, 0);
    assert_eq!(balances_final.tokens["USDC"], deposit - 1);
}

use anchor_lang::prelude::*;

use crate::{
    types::{RebalanceState, SharePrice, TokenAmount, VaultTokenId, Weight},
    utils::consts::{DEPOSIT_ORDER_SIZE, MAX_TOKENS_PER_VAULT, WITHDRAW_ORDER_SIZE},
};

/// What a deposit order and a withdraw order have in common: a basket of the vault's tokens owned
/// by one user (physically stored in the vault's TAs), auctioned by solvers for a bounded time.
#[zero_copy]
#[derive(Debug, Default, PartialEq, Eq)]
pub struct OrderBase {
    /// The vault the basket is locked in.
    pub vault_state: Pubkey,

    /// Who owns the basket: the only one to end its auction early, and who receives whatever the
    /// order ends with (and the rent).
    pub owner: Pubkey,

    /// The owner's order number within this vault, a seed below `MAX_ORDERS_PER_OWNER`.
    pub id: u8,

    pub alignment_padding: [u8; 15], // (so that the u128-holding fields below start 16-aligned)

    /// The order's auction (with the loss limits the owner accepts).
    pub rebalance: RebalanceState,

    /// What amounts of vault's tokens this order owns (physically stored in the vault's TAs).
    pub locked_amounts: [u64; MAX_TOKENS_PER_VAULT],
}

impl OrderBase {
    /// An empty, not-started-yet order.
    pub fn new(vault_state: Pubkey, owner: Pubkey, id: u8) -> Self {
        Self {
            vault_state,
            owner,
            id,
            ..Self::default()
        }
    }

    /// How much of the token `id` this order owns (the basket's `available`).
    pub fn locked_amount(&self, id: VaultTokenId) -> TokenAmount {
        TokenAmount::from(self.locked_amounts[id.storage_index])
    }

    /// Adds `amount` of the token `id` to what this order owns.
    pub fn lock(&mut self, id: VaultTokenId, amount: TokenAmount) {
        self.locked_amounts[id.storage_index] += u64::from(amount);
    }

    /// Takes `amount` of the token `id` off what this order owns.
    pub fn unlock(&mut self, id: VaultTokenId, amount: TokenAmount) {
        self.locked_amounts[id.storage_index] -= u64::from(amount);
    }
}

/// A depositor's basket of tokens, held in the vault's token accounts and auctioned into the
/// vault's target weights by solvers, then absorbed into the vault in exchange for shares.
#[account(zero_copy)]
#[derive(Debug, Default, PartialEq, Eq)]
pub struct DepositOrder {
    pub base: OrderBase,

    /// The highest share price the owner accepts on each settle, or `0` for no limit.
    pub max_share_price_sf: u128,

    pub trailing_padding: [u128; 15], // (as large as the fields above, left free for future ones)
}

static_assertions::const_assert_eq!(DEPOSIT_ORDER_SIZE, std::mem::size_of::<DepositOrder>());

impl DepositOrder {
    /// Creates an empty, not-started-yet order.
    pub fn new(vault_state: Pubkey, owner: Pubkey, id: u8) -> Self {
        Self {
            base: OrderBase::new(vault_state, owner, id),
            ..Self::default()
        }
    }

    /// Sets the highest share price the order accepts ([None] for no limit).
    pub fn set_max_share_price(&mut self, max_share_price: Option<SharePrice>) {
        self.max_share_price_sf = max_share_price.unwrap_or_default().to_bits();
    }

    /// The highest share price the owner accepts, or [None] for no limit.
    pub fn max_share_price(&self) -> Option<SharePrice> {
        (self.max_share_price_sf != 0).then(|| SharePrice::from_bits(self.max_share_price_sf))
    }
}

/// A withdrawer's pro-rata slice of the vault's liquid tokens, released for their burned shares
/// (kept in the vault's token accounts), auctioned into the owner's chosen weights by solvers.
#[account(zero_copy)]
#[derive(Debug, Default, PartialEq, Eq)]
pub struct WithdrawOrder {
    pub base: OrderBase,

    /// The weights the owner wants the basket auctioned into (in the vault's storage index order).
    pub weights: [u64; MAX_TOKENS_PER_VAULT],

    pub trailing_padding: [u128; 19], // (as large as the fields above, left free for future ones)
}

static_assertions::const_assert_eq!(WITHDRAW_ORDER_SIZE, std::mem::size_of::<WithdrawOrder>());

impl WithdrawOrder {
    /// Creates an empty, not-started-yet order.
    pub fn new(vault_state: Pubkey, owner: Pubkey, id: u8) -> Self {
        Self {
            base: OrderBase::new(vault_state, owner, id),
            ..Self::default()
        }
    }

    /// The weight the owner wants the token `id` auctioned into.
    pub fn weight(&self, id: VaultTokenId) -> Weight {
        Weight::from(self.weights[id.storage_index])
    }

    /// Sets the weight the owner wants the token `id` auctioned into.
    pub fn set_weight(&mut self, id: VaultTokenId, weight: Weight) {
        self.weights[id.storage_index] = u64::from(weight);
    }
}

use anchor_lang::prelude::*;
use borsh::BorshDeserialize;
use kamino_lending::fraction::Fraction;
use kamino_lending::ScopeConfiguration;

use crate::VaultConfigField;
use crate::{
    operations::rolling_cap,
    operations::vault_operations::{string_utils::slice_to_array_padded, update_token_weights},
    types::{
        DollarValue, Duration, DutchAuctionBounds, DutchAuctionScales, FractionalShares,
        MinFeeSpec, NetAum, Ratio, RebalanceLimits, RebalanceState, RoundingMethod, ShareAmount,
        SharePrice, Timestamp, TokenAmount, TokenPrice, VaultObligationId, VaultTokenId, Weight,
    },
    utils::{
        config_items,
        consts::{
            DEFAULT_MAX_AGE_PRICE_SECONDS, DEFAULT_MAX_AGE_TWAP_SECONDS,
            DEFAULT_MAX_TWAP_DIVERGENCE_BPS, GLOBAL_CONFIG_SIZE, MAX_FEE_LAMPORTS, MAX_FEE_RATE,
            MAX_MAX_AGE_SECONDS, MAX_MGMT_FEE, MAX_MIN_DEPOSIT_AMOUNT, MAX_MIN_WITHDRAW_AMOUNT,
            MAX_OBLIGATIONS_PER_VAULT, MAX_PERF_FEE, MAX_REBALANCE_COOLDOWN,
            MAX_ROLLING_CAP_INTERVAL_SECONDS, MAX_TOKENS_PER_VAULT, MIN_MAX_AGE_SECONDS,
            VAULT_OBLIGATION_STATE_SIZE, VAULT_STATE_SIZE, VAULT_TOKEN_STATE_SIZE,
        },
        global_config::UpdateGlobalConfigMode,
        scope::VaultScopePrices,
    },
    KaminoVaultError,
};
use bytemuck::Zeroable;
use itertools::izip;
use kamino_lending::utils::accounts::default_array;
use kamino_lending::utils::FULL_BPS;

pub fn quote_swap(
    amount_in: TokenAmount,
    token_in_price: &TokenPrice,
    token_out_price: &TokenPrice,
) -> Result<TokenAmount> {
    let amount_in_aum = amount_in.to_aum(token_in_price, RoundingMethod::Floor);
    // Saturating: this quote is only ever an upper bound on what a solver may request (the
    // fill transfers `requested_out_amount`, itself capped by the token's actual excess), so
    // a quote past `u64::MAX` correctly reads as "the curve permits any amount the vault can
    // pay". The per-swap and per-rebalance loss bounds are computed from the real amounts and
    // still apply. Converting unsaturated would abort the fill instead.
    let amount_out = amount_in_aum.to_tokens_clamp_saturating(token_out_price);
    require!(
        amount_in.is_zero() || !amount_out.is_zero(),
        KaminoVaultError::SwapQuoteRoundsToZero
    );
    Ok(amount_out)
}

pub fn quote_swap_with_dutch_auction(
    progress: Ratio<Duration>,
    amount_in: TokenAmount,
    token_in_price: &TokenPrice,
    token_out_price: &TokenPrice,
    bounds: &DutchAuctionBounds,
) -> Result<TokenAmount> {
    // Basket-favorable rounding: Floor for buy-side (under-credits the solver's input),
    // Ceil for sell-side (over-prices the basket's output so fewer tokens go out).
    let adjusted_in_price =
        bounds
            .buying
            .adjust_price_after(token_in_price, progress, RoundingMethod::Floor);
    let adjusted_out_price =
        bounds
            .selling
            .adjust_price_after(token_out_price, progress, RoundingMethod::Ceil);
    quote_swap(amount_in, &adjusted_in_price, &adjusted_out_price)
}

/// Tumbling-window USD rate limiter, used independently for deposit and withdraw flows.
///
/// Disabled when `interval_seconds == 0` (matches klend's `WithdrawalCaps` convention). When
/// active, `accumulated_usd_sf` collects cumulative flow within the current window; the window
/// resets to `now` whenever `now - last_interval_start_timestamp >= interval_seconds` (drifting
/// anchor — the next window begins on the first operation past expiry, not on a fixed cadence).
///
/// All zero ⇒ disabled, which is the default for pre-feature vault state.
#[zero_copy]
#[derive(AnchorDeserialize, Debug, PartialEq, Eq)]
pub struct RollingCap {
    pub max_usd_sf: u128,
    pub accumulated_usd_sf: u128,
    pub interval_seconds: u64,
    pub last_interval_start_timestamp: u64,
}

impl Default for RollingCap {
    fn default() -> Self {
        Self::zeroed()
    }
}

impl RollingCap {
    pub fn max_usd(&self) -> DollarValue {
        DollarValue::from_bits(self.max_usd_sf)
    }

    pub fn accumulated_usd(&self) -> DollarValue {
        DollarValue::from_bits(self.accumulated_usd_sf)
    }

    pub fn set_accumulated_usd(&mut self, value: DollarValue) {
        self.accumulated_usd_sf = value.to_bits();
    }

    pub fn interval(&self) -> Duration {
        Duration::from(self.interval_seconds)
    }

    pub fn last_interval_start(&self) -> Timestamp {
        Timestamp::from(self.last_interval_start_timestamp)
    }

    pub fn set_last_interval_start(&mut self, ts: Timestamp) {
        self.last_interval_start_timestamp = u64::from(ts);
    }

    pub fn is_disabled(&self) -> bool {
        self.interval_seconds == 0
    }

    /// Overwrites `max_usd_sf` and `interval_seconds` from a 24-byte LE payload
    /// (`u128 max_usd_sf ++ u64 interval_seconds`), validating `interval_seconds` against
    /// [`MAX_ROLLING_CAP_INTERVAL_SECONDS`].
    ///
    /// The in-flight window is settled under the *old* interval first (windows tumble lazily, on
    /// the next flow), so a longer new interval cannot resurrect a window that had already
    /// expired and blocked flow until the extended deadline. Whatever survives that settlement —
    /// `accumulated_usd_sf` and `last_interval_start_timestamp` — is then deliberately left
    /// untouched: an admin tightening a cap mid-window does not retroactively forgive in-flight
    /// flow.
    pub fn apply_config_bytes(&mut self, value: &[u8], tag: &str, now: Timestamp) -> Result<()> {
        let max_sf: u128 =
            BorshDeserialize::try_from_slice(config_items::value_bytes(value, ..16)?)?;
        let interval: u64 =
            BorshDeserialize::try_from_slice(config_items::value_bytes(value, 16..24)?)?;
        require_gte!(
            u64::from(MAX_ROLLING_CAP_INTERVAL_SECONDS),
            interval,
            KaminoVaultError::RollingCapIntervalTooLong
        );
        rolling_cap::tumble_window_if_needed(self, now)?;
        msg!(
            "Prv rolling_{}_cap max_sf={} interval={}",
            tag,
            self.max_usd_sf,
            self.interval_seconds
        );
        self.max_usd_sf = max_sf;
        self.interval_seconds = interval;
        msg!(
            "New rolling_{}_cap max_sf={} interval={}",
            tag,
            max_sf,
            interval
        );
        Ok(())
    }
}

static_assertions::const_assert_eq!(GLOBAL_CONFIG_SIZE, std::mem::size_of::<GlobalConfig>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<GlobalConfig>() % 16);

#[account(zero_copy)]
#[derive(AnchorDeserialize, PartialEq, Eq)]
#[repr(C)]
pub struct GlobalConfig {
    pub global_admin: Pubkey,
    pub pending_admin: Pubkey,

    pub deposit_fee_lamports: u64,
    pub deposit_fee_bps: u64,
    pub withdrawal_fee_lamports: u64,
    pub withdrawal_fee_bps: u64,

    /// The krfq auction server key that must co-sign `rebalance_swap` on vaults with
    /// `krfq_enabled` set. Stored globally (not per vault) so a krfq server-key rotation
    /// needs one update here instead of one per vault. [`Pubkey::default`] means unset:
    /// krfq-gated vaults reject all fills until it is configured (fail closed).
    pub krfq_swap_authority: Pubkey,

    pub trailing_padding: [u128; 56],
}

impl Default for GlobalConfig {
    fn default() -> Self {
        Self::zeroed()
    }
}

impl GlobalConfig {
    pub fn init(&mut self, initial_admin: Pubkey) {
        self.global_admin = initial_admin;
    }

    pub fn update_value(&mut self, mode: UpdateGlobalConfigMode, value: &[u8]) -> Result<()> {
        match mode {
            UpdateGlobalConfigMode::PendingAdmin => {
                config_items::for_named_field!(&mut self.pending_admin).set(value)?;
            }
            UpdateGlobalConfigMode::MinWithdrawalFeeLamports => {
                config_items::for_named_field!(&mut self.withdrawal_fee_lamports)
                    .validating(at_most(
                        MAX_FEE_LAMPORTS,
                        TokenAmount::from,
                        KaminoVaultError::LamportsFeeGreaterThanMaxAllowed,
                    ))
                    .set(value)?;
            }
            UpdateGlobalConfigMode::MinWithdrawalFeeBPS => {
                config_items::for_named_field!(&mut self.withdrawal_fee_bps)
                    .validating(at_most(
                        MAX_FEE_RATE,
                        Ratio::from_bps,
                        KaminoVaultError::BPSFeeGreaterThanMaxAllowed,
                    ))
                    .set(value)?;
            }
            UpdateGlobalConfigMode::MinDepositFeeLamports => {
                config_items::for_named_field!(&mut self.deposit_fee_lamports)
                    .validating(at_most(
                        MAX_FEE_LAMPORTS,
                        TokenAmount::from,
                        KaminoVaultError::LamportsFeeGreaterThanMaxAllowed,
                    ))
                    .set(value)?;
            }
            UpdateGlobalConfigMode::MinDepositFeeBPS => {
                config_items::for_named_field!(&mut self.deposit_fee_bps)
                    .validating(at_most(
                        MAX_FEE_RATE,
                        Ratio::from_bps,
                        KaminoVaultError::BPSFeeGreaterThanMaxAllowed,
                    ))
                    .set(value)?;
            }
            UpdateGlobalConfigMode::KrfqSwapAuthority => {
                config_items::for_named_field!(&mut self.krfq_swap_authority).set(value)?;
            }
        }
        Ok(())
    }

    #[inline(always)]
    pub fn apply_pending_admin(&mut self) -> Result<()> {
        self.global_admin = self.pending_admin;
        self.pending_admin = Pubkey::default();
        Ok(())
    }

    // ── Typed accessors ──────────────────────────────────────────────

    pub fn deposit_fee_spec(&self) -> MinFeeSpec {
        MinFeeSpec::new(
            Ratio::from_bps(self.deposit_fee_bps),
            TokenAmount::from(self.deposit_fee_lamports),
        )
    }

    pub fn withdrawal_fee_spec(&self) -> MinFeeSpec {
        MinFeeSpec::new(
            Ratio::from_bps(self.withdrawal_fee_bps),
            TokenAmount::from(self.withdrawal_fee_lamports),
        )
    }
}

static_assertions::const_assert_eq!(VAULT_STATE_SIZE, std::mem::size_of::<MetavaultState>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<MetavaultState>() % 16);
#[account(zero_copy)]
#[derive(AnchorDeserialize, PartialEq, Eq)]
pub struct MetavaultState {
    // Admin
    pub vault_admin_authority: Pubkey,

    pub base_vault_authority: Pubkey,
    pub base_vault_authority_bump: u8,
    pub alignment_padding_1: [u8; 15],

    // shares
    pub shares_mint: Pubkey,
    pub shares_mint_decimals: u64,
    pub alignment_padding_2: [u8; 8],

    pub vault_tokens: [VaultToken; MAX_TOKENS_PER_VAULT],
    pub obligations: [VaultObligation; MAX_OBLIGATIONS_PER_VAULT],
    // accounting
    pub shares_issued: u64,
    pub alignment_padding_3: [u8; 8],

    pub prev_aum_sf: u128,

    // Fees taken in vault shares (stored as Fraction bits)
    pub pending_fees_sf: u128,

    pub last_fee_charge_timestamp: u64,
    pub alignment_padding_4: [u8; 8],

    /// Retired slot, kept so the account layout is unchanged; live vaults still carry whatever
    /// the counter it replaced last held.
    ///
    /// It summed `new_aum - prev_aum` across fee charges under the name "cumulative earned
    /// interest", but it measured neither: the subtraction saturated at zero so drawdowns were
    /// dropped, `new_aum` is a Scope valuation so token price moves counted as interest, and
    /// every value-moving operation rebased `prev_aum` to its own post-operation AUM, hiding
    /// whatever that operation created or destroyed. Nothing on-chain read it.
    pub retired_padding_1: u128,
    pub cumulative_mgmt_fees_sf: u128,
    pub cumulative_perf_fees_sf: u128,

    pub last_perf_fee_charge_timestamp: u64,
    pub alignment_padding_5: [u8; 8],

    /// The vault's own rebalance (the current or last one).
    pub rebalance: RebalanceState,

    // General config
    pub pending_admin: Pubkey,

    pub name: [u8; 40],
    pub alignment_padding_6: [u8; 8],

    /// For clients only: the program never reads it, and does not check what the admin sets.
    pub vault_lookup_table: Pubkey,

    /// For clients only: the program never reads it, and does not check what the admin sets.
    pub vault_farm: Pubkey,

    pub creation_timestamp: u64,
    pub performance_fee_bps: u64,
    pub management_fee_bps: u64,

    /// Rebalance cooldown: minimum period between consecutive rebalance *starts*, rate-limiting
    /// weight churn by the allocation delegate. Binds the allocation key only — the vault admin
    /// bypasses it. `0` disables.
    pub rebalance_cooldown_seconds: u64,

    // --- Vault-level limits (cap configuration) ---
    /// Hard ceiling on the vault's net AUM, in USD (`DollarValue::to_bits`). `0` disables the cap.
    pub deposit_cap_usd_sf: u128,
    /// Tumbling-window cap on cumulative deposit USD per interval. `interval_seconds == 0` disables.
    pub rolling_deposit_cap: RollingCap,
    /// Tumbling-window cap on cumulative withdraw USD per interval. `interval_seconds == 0` disables.
    pub rolling_withdraw_cap: RollingCap,

    // Emergency controls.
    pub emergency_council: Pubkey,
    pub emergency_mode: u8,
    pub block_deposits: u8,
    pub block_withdraws: u8,
    pub alignment_padding_8: [u8; 13],
    pub unfreeze_authority: Pubkey,
    pub swap_authority: Pubkey,

    /// 1 = share accounts are gated through the Token ACL program (permissioned vault),
    /// 0 = open. Set once at init; the gating program itself is never mirrored here — its
    /// canonical source is the token-acl `MintConfig`.
    pub shares_permissioned: u8,
    /// 1 = every `rebalance_swap` fill must be co-signed by the krfq auction server key
    /// held in `GlobalConfig::krfq_swap_authority`, 0 = no auction gate. Composes with
    /// `swap_authority`: when both are set, both checks must pass.
    pub krfq_enabled: u8,
    pub alignment_padding_9: [u8; 14],

    /// Optional delegate for rebalance and obligation allocation operations.
    /// [`Pubkey::default`] means delegation is disabled.
    pub allocation_admin_authority: Pubkey,

    /// [`SharePrice`] bits at the last eligible performance-fee charge. Zero means
    /// not yet seeded. Unlike `prev_aum_sf` this moves only at cooldown boundaries: capital
    /// flows trade at the current share price, so they cannot move it by construction.
    pub last_perf_fee_price_sf: u128,

    /// The limits the vault's next rebalance starts with (a running one keeps its own; orders set
    /// their own).
    pub rebalance_limits: RebalanceLimits,

    /// The lowest value a basket may have to open an order (of either kind), or `0` for no minimum
    /// (dust orders are then possible; each costs its owner the account's rent, and an owner has
    /// at most `MAX_ORDERS_PER_OWNER` of each kind open).
    pub order_min_open_usd_sf: u128,

    /// Allows `open_deposit_order` (which `block_deposits` leaves alone: nothing enters the vault
    /// before the settle; `cancel_deposit_order` has no switch at all).
    pub deposit_order_creation_enabled: u8,

    /// Allows fills against deposit orders (never gates the vault's own rebalance fills).
    pub deposit_order_fill_enabled: u8,

    /// Allows `settle_deposit_order` (which `block_deposits` also stops, as it mints the shares).
    pub deposit_order_settle_enabled: u8,

    /// Allows `open_withdraw_order` (which `block_withdraws` also stops, as it burns the shares;
    /// the settle answers to no switch, so the owner can always take what the order holds).
    pub withdraw_order_creation_enabled: u8,

    /// Allows fills against withdraw orders (never gates the vault's own rebalance fills).
    pub withdraw_order_fill_enabled: u8,

    pub alignment_padding_11: [u8; 11],

    pub trailing_padding: [u128; 459],
}

impl Default for MetavaultState {
    fn default() -> Self {
        Self::zeroed()
    }
}

impl MetavaultState {
    pub fn pending_fees(&self) -> FractionalShares {
        FractionalShares::from_bits(self.pending_fees_sf)
    }

    pub fn set_pending_fees(&mut self, pending_fees: FractionalShares) {
        self.pending_fees_sf = pending_fees.to_bits()
    }

    pub fn shares_issued_amount(&self) -> ShareAmount {
        ShareAmount::from(self.shares_issued)
    }

    /// Lamports in one whole share (`10^shares_mint_decimals`). Saturates to [`ShareAmount::MAX`] if
    /// the configured decimals are out of range (clamped against the issued supply by callers).
    pub fn one_whole_share(&self) -> ShareAmount {
        u32::try_from(self.shares_mint_decimals)
            .ok()
            .and_then(|decimals| 10u64.checked_pow(decimals))
            .map_or(ShareAmount::MAX, ShareAmount::new)
    }

    pub fn mint_shares(&mut self, amt: ShareAmount) {
        self.shares_issued += u64::from(amt);
    }

    pub fn burn_shares(&mut self, amt: ShareAmount) {
        self.shares_issued -= u64::from(amt);
    }

    pub fn prev_aum(&self) -> DollarValue {
        DollarValue::from_bits(self.prev_aum_sf)
    }

    pub fn set_prev_aum(&mut self, current_aum: DollarValue) {
        self.prev_aum_sf = current_aum.to_bits();
    }

    pub fn last_perf_fee_price(&self) -> SharePrice {
        SharePrice::from_bits(self.last_perf_fee_price_sf)
    }

    pub fn set_last_perf_fee_price(&mut self, price: SharePrice) {
        self.last_perf_fee_price_sf = price.to_bits();
    }

    pub fn cumulative_mgmt_fees(&self) -> FractionalShares {
        FractionalShares::from_bits(self.cumulative_mgmt_fees_sf)
    }

    pub fn set_cumulative_mgmt_fees(&mut self, cumulative_mgmt_fees: FractionalShares) {
        self.cumulative_mgmt_fees_sf = cumulative_mgmt_fees.to_bits();
    }

    pub fn cumulative_perf_fees(&self) -> FractionalShares {
        FractionalShares::from_bits(self.cumulative_perf_fees_sf)
    }

    pub fn set_cumulative_perf_fees(&mut self, cumulative_perf_fees: FractionalShares) {
        self.cumulative_perf_fees_sf = cumulative_perf_fees.to_bits();
    }

    pub fn last_fee_charge(&self) -> Timestamp {
        Timestamp::from(self.last_fee_charge_timestamp)
    }

    pub fn set_last_fee_charge(&mut self, ts: Timestamp) {
        self.last_fee_charge_timestamp = u64::from(ts);
    }

    pub fn last_perf_fee_charge(&self) -> Timestamp {
        Timestamp::from(self.last_perf_fee_charge_timestamp)
    }

    pub fn set_last_perf_fee_charge(&mut self, ts: Timestamp) {
        self.last_perf_fee_charge_timestamp = u64::from(ts);
    }

    pub fn management_fee_rate(&self) -> Ratio<u64> {
        Ratio::from_bps(self.management_fee_bps)
    }

    pub fn performance_fee_rate(&self) -> Ratio<u64> {
        Ratio::from_bps(self.performance_fee_bps)
    }

    pub fn rebalance_cooldown(&self) -> Duration {
        Duration::from(self.rebalance_cooldown_seconds)
    }

    // "Free" AUM: market value of tokens sitting in this vault's token vaults (i.e. uninvested
    // liquidity that rebalance can move between tokens). Does NOT include value locked in
    // obligations.
    // Every enabled token is expected to have a corresponding valid scope price.
    pub fn compute_free_aum(
        &self,
        vault_scope_prices: &VaultScopePrices,
        rounding: RoundingMethod,
    ) -> DollarValue {
        izip!(self.iter_enabled_tokens(), &vault_scope_prices.prices)
            .map(|(token, price)| token.compute_aum(price, rounding))
            .sum()
    }

    /// Returns "net AUM", i.e. all [VaultToken]s' AUM + all obligations' AUM (potentially negative).
    pub fn compute_net_aum(
        &self,
        vault_scope_prices: &VaultScopePrices,
        obligations_aum: NetAum,
        rounding: RoundingMethod,
    ) -> NetAum {
        self.compute_free_aum(vault_scope_prices, rounding) + obligations_aum
    }

    /// The enabled tokens with their ids.
    pub fn enumerate_enabled_tokens(&self) -> impl Iterator<Item = (VaultTokenId, &VaultToken)> {
        self.vault_tokens
            .iter()
            .enumerate()
            .filter(|(_, token)| token.is_token_set())
            .enumerate()
            .map(|(input_account_index, (storage_index, token))| {
                let id = VaultTokenId {
                    storage_index,
                    input_account_index,
                };
                (id, token)
            })
    }

    pub fn iter_enabled_tokens(&self) -> impl Iterator<Item = &VaultToken> {
        self.enumerate_enabled_tokens().map(|(_, token)| token)
    }

    pub fn iter_mut_enabled_tokens(&mut self) -> impl Iterator<Item = &mut VaultToken> {
        self.vault_tokens.iter_mut().filter(|r| r.is_token_set())
    }

    pub fn iter_enabled_obligations(&self) -> impl Iterator<Item = &VaultObligation> {
        self.obligations.iter().filter(|o| o.is_set())
    }

    pub fn get_obligations_count(&self) -> usize {
        self.iter_enabled_obligations().count()
    }

    pub fn get_tokens_count(&self) -> usize {
        self.iter_enabled_tokens().count()
    }

    pub fn deposit_cap(&self) -> DollarValue {
        DollarValue::from_bits(self.deposit_cap_usd_sf)
    }

    pub fn deposit_order_creation_enabled(&self) -> bool {
        self.deposit_order_creation_enabled == 1
    }

    pub fn deposit_order_fill_enabled(&self) -> bool {
        self.deposit_order_fill_enabled == 1
    }

    pub fn deposit_order_settle_enabled(&self) -> bool {
        self.deposit_order_settle_enabled == 1
    }

    pub fn withdraw_order_creation_enabled(&self) -> bool {
        self.withdraw_order_creation_enabled == 1
    }

    pub fn withdraw_order_fill_enabled(&self) -> bool {
        self.withdraw_order_fill_enabled == 1
    }

    /// The lowest value a basket may have to open an order, or [None] for no minimum.
    pub fn order_min_open(&self) -> Option<DollarValue> {
        (self.order_min_open_usd_sf != 0)
            .then(|| DollarValue::from_bits(self.order_min_open_usd_sf))
    }

    pub fn is_deposit_cap_enabled(&self) -> bool {
        self.deposit_cap_usd_sf != 0
    }

    pub fn validate_swap_authority(&self, signer: Pubkey) -> Result<()> {
        require!(
            self.swap_authority == Pubkey::default() || signer == self.swap_authority,
            KaminoVaultError::SwapAuthorityIncorrect
        );
        Ok(())
    }

    pub fn shares_permissioned(&self) -> bool {
        self.shares_permissioned == 1
    }

    pub fn is_krfq_enabled(&self) -> bool {
        self.krfq_enabled != 0
    }

    pub fn is_allocation_authority(&self, signer: Pubkey) -> bool {
        signer == self.vault_admin_authority
            || (self.allocation_admin_authority != Pubkey::default()
                && signer == self.allocation_admin_authority)
    }

    /// Thawing a shares account is the `unfreeze_authority`'s job, with the vault admin
    /// as fallback (and as the only holder of the role while it is unset).
    pub fn validate_shares_thaw_authority(&self, signer: Pubkey) -> Result<()> {
        require!(
            signer == self.vault_admin_authority
                || (self.unfreeze_authority != Pubkey::default()
                    && signer == self.unfreeze_authority),
            KaminoVaultError::AdminAuthorityIncorrect
        );
        Ok(())
    }

    /// Freezing a shares account is a defensive action: the vault admin or the emergency
    /// council may do it (the council cannot thaw).
    pub fn validate_shares_freeze_authority(&self, signer: Pubkey) -> Result<()> {
        require!(
            signer == self.vault_admin_authority
                || (self.emergency_council != Pubkey::default()
                    && signer == self.emergency_council),
            KaminoVaultError::AdminAuthorityIncorrect
        );
        Ok(())
    }

    pub fn validate(&self) -> Result<()> {
        if self.vault_admin_authority == Pubkey::default() {
            return err!(KaminoVaultError::AdminAuthorityIncorrect);
        }

        if self.base_vault_authority == Pubkey::default() {
            return err!(KaminoVaultError::BaseVaultAuthorityIncorrect);
        }

        if self.shares_mint == Pubkey::default() {
            return err!(KaminoVaultError::SharesMintIncorrect);
        }

        if self.shares_mint_decimals == 0 {
            return err!(KaminoVaultError::SharesMintDecimalsIncorrect);
        }

        if self.shares_issued != 0
            || self.performance_fee_bps != 0
            || self.management_fee_bps != 0
            || self.prev_aum_sf != 0
            || self.last_perf_fee_price_sf != 0
        {
            return err!(KaminoVaultError::InitialAccountingIncorrect);
        }

        Ok(())
    }

    pub fn update_config(
        &mut self,
        field: VaultConfigField,
        value: &[u8],
        current_timestamp: Timestamp,
    ) -> Result<()> {
        match field {
            // Fee changes (here and on the vault tokens) apply at once, with no timelock: the
            // `MAX_*` caps are what bounds the admin.
            VaultConfigField::PerformanceFeeBps => {
                config_items::for_named_field!(&mut self.performance_fee_bps)
                    .validating(at_most(
                        MAX_PERF_FEE,
                        Ratio::from_bps,
                        KaminoVaultError::PerformanceFeeGreaterThanMaxAllowed,
                    ))
                    .set(value)?;
            }
            VaultConfigField::ManagementFeeBps => {
                config_items::for_named_field!(&mut self.management_fee_bps)
                    .validating(at_most(
                        MAX_MGMT_FEE,
                        Ratio::from_bps,
                        KaminoVaultError::ManagementFeeGreaterThanMaxAllowed,
                    ))
                    .set(value)?;
            }
            // Not refused mid-rebalance: a running rebalance keeps the limits it started with.
            VaultConfigField::MaxRebalanceSwapSlippageBps => {
                config_items::for_named_field!(&mut self.rebalance_limits.max_fill_slippage_bps)
                    .validating(valid_bps)
                    .set(value)?;
            }
            VaultConfigField::MaxRebalanceLossBps => {
                config_items::for_named_field!(&mut self.rebalance_limits.max_loss_bps)
                    .validating(valid_bps)
                    .set(value)?;
            }
            VaultConfigField::PendingVaultAdmin => {
                config_items::for_named_field!(&mut self.pending_admin).set(value)?;
            }
            VaultConfigField::Name => {
                let name = slice_to_array_padded(value);
                msg!("Prv value: name = {:?}", self.name);
                msg!("New value: name = {:?}", name);
                self.name = name;
            }
            VaultConfigField::LookupTable => {
                config_items::for_named_field!(&mut self.vault_lookup_table).set(value)?;
            }
            VaultConfigField::Farm => {
                // Shares are Token-2022 mints: kfarms only accepts legacy SPL on the
                // stake side and rejects DefaultAccountState on rewards, so a configured
                // farm cannot stake these shares until kfarms is extended.
                config_items::for_named_field!(&mut self.vault_farm).set(value)?;
            }
            VaultConfigField::VaultTokenScope
            | VaultConfigField::VaultTokenMinDepositAmount
            | VaultConfigField::VaultTokenMinWithdrawAmount
            | VaultConfigField::VaultTokenMaxAgeTwapSeconds
            | VaultConfigField::VaultTokenMaxAgePriceSeconds
            | VaultConfigField::VaultTokenMaxTwapDivergenceBps
            | VaultConfigField::VaultTokenDepositFeeBps
            | VaultConfigField::VaultTokenDepositFeeLamports
            | VaultConfigField::VaultTokenWithdrawFeeBps
            | VaultConfigField::VaultTokenWithdrawFeeLamports
            | VaultConfigField::VaultTokenDutchAuctionBounds
            | VaultConfigField::VaultTokenMaxDeviationBps
            | VaultConfigField::VaultTokenMaxPriceDivergenceBps => {
                if matches!(
                    field,
                    VaultConfigField::VaultTokenDutchAuctionBounds
                        | VaultConfigField::VaultTokenScope
                        | VaultConfigField::VaultTokenMaxAgePriceSeconds
                        | VaultConfigField::VaultTokenMaxAgeTwapSeconds
                        | VaultConfigField::VaultTokenMaxTwapDivergenceBps
                        | VaultConfigField::VaultTokenMaxPriceDivergenceBps
                ) {
                    require!(
                        !self.rebalance.is_within(current_timestamp),
                        KaminoVaultError::RebalanceInProgress
                    );
                }
                let id_offset_bytes = 32;
                let mint =
                    Pubkey::try_from_slice(config_items::value_bytes(value, ..id_offset_bytes)?)?;
                let vault_token_value = config_items::value_bytes(value, id_offset_bytes..)?;
                let vault_token = self.get_vault_token_mut_by_mint(&mint)?;
                match field {
                    VaultConfigField::VaultTokenScope => {
                        // Trusted as the token's own price: only its shape is checked (on use,
                        // by `validate_token_price_config`), so a chain naming another price
                        // misprices the token, and one naming a missing price fails every
                        // instruction that loads the vault's prices until it is fixed.
                        config_items::for_named_field!(&mut vault_token.scope_configuration)
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenMaxAgePriceSeconds => {
                        config_items::for_named_field!(&mut vault_token.max_age_price_seconds)
                            .validating(valid_max_age)
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenMaxAgeTwapSeconds => {
                        config_items::for_named_field!(&mut vault_token.max_age_twap_seconds)
                            .validating(valid_max_age)
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenMaxTwapDivergenceBps => {
                        config_items::for_named_field!(&mut vault_token.max_twap_divergence_bps)
                            .validating(valid_bps)
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenMaxPriceDivergenceBps => {
                        config_items::for_named_field!(&mut vault_token.max_price_divergence_bps)
                            .validating(valid_bps)
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenMinDepositAmount => {
                        config_items::for_named_field!(&mut vault_token.min_deposit_amount)
                            .validating(at_most(
                                MAX_MIN_DEPOSIT_AMOUNT,
                                TokenAmount::from,
                                KaminoVaultError::MinDepositAmountTooBig,
                            ))
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenMinWithdrawAmount => {
                        config_items::for_named_field!(&mut vault_token.min_withdraw_amount)
                            .validating(at_most(
                                MAX_MIN_WITHDRAW_AMOUNT,
                                TokenAmount::from,
                                KaminoVaultError::MinWithdrawAmountTooBig,
                            ))
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenDepositFeeBps => {
                        config_items::for_named_field!(&mut vault_token.deposit_fee_bps)
                            .validating(at_most(
                                MAX_FEE_RATE,
                                Ratio::from_bps,
                                KaminoVaultError::BPSFeeGreaterThanMaxAllowed,
                            ))
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenDepositFeeLamports => {
                        config_items::for_named_field!(&mut vault_token.deposit_fee_lamports)
                            .validating(at_most(
                                MAX_FEE_LAMPORTS,
                                TokenAmount::from,
                                KaminoVaultError::LamportsFeeGreaterThanMaxAllowed,
                            ))
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenWithdrawFeeBps => {
                        config_items::for_named_field!(&mut vault_token.withdraw_fee_bps)
                            .validating(at_most(
                                MAX_FEE_RATE,
                                Ratio::from_bps,
                                KaminoVaultError::BPSFeeGreaterThanMaxAllowed,
                            ))
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenWithdrawFeeLamports => {
                        config_items::for_named_field!(&mut vault_token.withdraw_fee_lamports)
                            .validating(at_most(
                                MAX_FEE_LAMPORTS,
                                TokenAmount::from,
                                KaminoVaultError::LamportsFeeGreaterThanMaxAllowed,
                            ))
                            .set(vault_token_value)?;
                    }
                    VaultConfigField::VaultTokenDutchAuctionBounds => {
                        // The wire value is the four scales in storage order, so it deserializes
                        // straight into the struct.
                        let scales: DutchAuctionScales = BorshDeserialize::try_from_slice(
                            config_items::value_bytes(vault_token_value, ..32)?,
                        )?;
                        scales.validate()?;
                        vault_token.dutch_auction_scales = scales;
                    }
                    VaultConfigField::VaultTokenMaxDeviationBps => {
                        config_items::for_named_field!(&mut vault_token.max_deviation_bps)
                            .validating(valid_bps)
                            .set(vault_token_value)?;
                    }
                    _ => unreachable!("Already checked for entry type in outer check"),
                }
            }
            VaultConfigField::TokenWeights => {
                let tokens_count = self.get_tokens_count();
                if value.len() != tokens_count * 8 {
                    return err!(KaminoVaultError::TokenArrayLengthMismatch);
                }

                let mut weights = Vec::with_capacity(tokens_count);
                for i in 0..tokens_count {
                    let start = i * 8;
                    let weight: u64 = BorshDeserialize::try_from_slice(&value[start..start + 8])?;
                    weights.push(weight.into());
                }

                update_token_weights(self, weights, current_timestamp)?;
            }
            VaultConfigField::DepositCapUsd => {
                config_items::for_named_field!(&mut self.deposit_cap_usd_sf).set(value)?;
            }
            VaultConfigField::DepositOrderCreationEnabled => {
                config_items::for_named_field!(&mut self.deposit_order_creation_enabled)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::DepositOrderFillEnabled => {
                config_items::for_named_field!(&mut self.deposit_order_fill_enabled)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::DepositOrderSettleEnabled => {
                config_items::for_named_field!(&mut self.deposit_order_settle_enabled)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::OrderMinOpenUsd => {
                config_items::for_named_field!(&mut self.order_min_open_usd_sf).set(value)?;
            }
            VaultConfigField::WithdrawOrderCreationEnabled => {
                config_items::for_named_field!(&mut self.withdraw_order_creation_enabled)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::WithdrawOrderFillEnabled => {
                config_items::for_named_field!(&mut self.withdraw_order_fill_enabled)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::RollingDepositCap => {
                self.rolling_deposit_cap
                    .apply_config_bytes(value, "deposit", current_timestamp)?;
            }
            VaultConfigField::RollingWithdrawCap => {
                self.rolling_withdraw_cap.apply_config_bytes(
                    value,
                    "withdraw",
                    current_timestamp,
                )?;
            }
            VaultConfigField::EmergencyCouncil => {
                config_items::for_named_field!(&mut self.emergency_council).set(value)?;
            }
            VaultConfigField::UnfreezeAuthority => {
                config_items::for_named_field!(&mut self.unfreeze_authority).set(value)?;
            }
            VaultConfigField::SwapAuthority => {
                config_items::for_named_field!(&mut self.swap_authority).set(value)?;
            }
            VaultConfigField::AllocationAdminAuthority => {
                config_items::for_named_field!(&mut self.allocation_admin_authority).set(value)?;
            }
            VaultConfigField::RebalanceCooldownSeconds => {
                config_items::for_named_field!(&mut self.rebalance_cooldown_seconds)
                    .validating(at_most(
                        MAX_REBALANCE_COOLDOWN,
                        Duration::from,
                        KaminoVaultError::RebalanceCooldownTooLong,
                    ))
                    .set(value)?;
            }
            VaultConfigField::EmergencyMode => {
                config_items::for_named_field!(&mut self.emergency_mode)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::BlockDeposits => {
                config_items::for_named_field!(&mut self.block_deposits)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::BlockWithdraws => {
                config_items::for_named_field!(&mut self.block_withdraws)
                    .validating(valid_bool)
                    .set(value)?;
            }
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps => {
                let id_offset_bytes = 32;
                let obligation =
                    Pubkey::try_from_slice(config_items::value_bytes(value, ..id_offset_bytes)?)?;
                let id = self.get_obligation_id_by_address(&obligation)?;
                let bps: u64 = BorshDeserialize::try_from_slice(config_items::value_bytes(
                    value,
                    id_offset_bytes..,
                )?)?;
                let vault_obligation = &mut self.obligations[id.storage_index];
                msg!(
                    "Prv value: obligations[{}].max_unhealthy_ltv_fraction_bps = {}",
                    id.storage_index,
                    vault_obligation.max_unhealthy_ltv_fraction_bps
                );
                vault_obligation.set_max_unhealthy_ltv_fraction_bps(bps)?;
                msg!(
                    "New value: obligations[{}].max_unhealthy_ltv_fraction_bps = {}",
                    id.storage_index,
                    bps
                );
            }
            VaultConfigField::KrfqEnabled => {
                config_items::for_named_field!(&mut self.krfq_enabled)
                    .validating(valid_bool)
                    .set(value)?;
            }
        }
        Ok(())
    }

    pub fn get_vault_token_by_mint(&self, mint: &Pubkey) -> Result<&VaultToken> {
        self.vault_tokens
            .iter()
            .find(|r| r.mint.eq(mint))
            .ok_or(KaminoVaultError::TokenNotEnabledInVault.into())
    }

    pub fn get_vault_token_mut_by_mint(&mut self, mint: &Pubkey) -> Result<&mut VaultToken> {
        self.vault_tokens
            .iter_mut()
            .find(|r| r.mint.eq(mint))
            .ok_or(KaminoVaultError::TokenNotEnabledInVault.into())
    }

    pub fn get_vault_token_id_by_mint(&self, mint: &Pubkey) -> Result<VaultTokenId> {
        self.enumerate_enabled_tokens()
            .find(|(_, token)| token.mint == *mint)
            .map(|(id, _)| id)
            .ok_or_else(|| error!(KaminoVaultError::TokenNotEnabledInVault))
    }

    pub fn get_vault_token_by_id(&self, id: VaultTokenId) -> &VaultToken {
        &self.vault_tokens[id.storage_index]
    }

    pub fn get_vault_token_mut_by_id(&mut self, id: VaultTokenId) -> &mut VaultToken {
        &mut self.vault_tokens[id.storage_index]
    }

    #[allow(clippy::too_many_arguments)]
    pub fn add_vault_token_if_not_present(
        &mut self,
        mint: Pubkey,
        vault: Pubkey,
        token_program: Pubkey,
        decimals: u8,
        scope_configuration: ScopeConfiguration,
        current_timestamp: Timestamp,
    ) -> Result<()> {
        require!(
            !self.rebalance.is_within(current_timestamp),
            KaminoVaultError::RebalanceInProgress
        );

        match self.get_vault_token_id_by_mint(&mint) {
            Ok(_) => return Err(error!(KaminoVaultError::VaultTokenAlreadyExists)),
            Err(_) => {
                // Doesn't exist yet
                let idx = self
                    .vault_tokens
                    .iter()
                    .position(|r| {
                        // Find an empty allocation
                        !r.is_token_set()
                    })
                    .ok_or(error!(KaminoVaultError::VaultTokensSpaceExhausted))?;

                self.vault_tokens[idx] = VaultToken {
                    mint,
                    token_program,
                    vault,
                    decimals,
                    scope_configuration,
                    max_age_price_seconds: DEFAULT_MAX_AGE_PRICE_SECONDS.into(),
                    max_age_twap_seconds: DEFAULT_MAX_AGE_TWAP_SECONDS.into(),
                    max_twap_divergence_bps: DEFAULT_MAX_TWAP_DIVERGENCE_BPS,
                    dutch_auction_scales: DutchAuctionScales::default(),
                    ..Default::default()
                };
            }
        }

        Ok(())
    }

    pub fn get_obligation_id_by_address(&self, address: &Pubkey) -> Result<VaultObligationId> {
        for (storage_index, obligation) in self.obligations.iter().enumerate() {
            if obligation.is_set() && obligation.obligation.eq(address) {
                return Ok(VaultObligationId { storage_index });
            }
        }
        Err(error!(KaminoVaultError::ObligationSlotNotFound))
    }

    pub fn add_obligation_if_not_present(
        &mut self,
        obligation: Pubkey,
    ) -> Result<VaultObligationId> {
        if self.get_obligation_id_by_address(&obligation).is_ok() {
            return Err(error!(KaminoVaultError::ObligationAlreadyExists));
        }
        let storage_index = self
            .obligations
            .iter()
            .position(|obligation| !obligation.is_set())
            .ok_or(error!(KaminoVaultError::ObligationsSpaceExhausted))?;
        self.obligations[storage_index] = VaultObligation::new(obligation);
        Ok(VaultObligationId { storage_index })
    }

    pub fn remove_obligation(&mut self, id: VaultObligationId) -> Result<()> {
        let slot = self
            .obligations
            .get_mut(id.storage_index)
            .filter(|obligation| obligation.is_set())
            .ok_or(error!(KaminoVaultError::ObligationSlotNotFound))?;
        *slot = VaultObligation::default();
        Ok(())
    }
}

/// [config_items] validator asserting that a flag value is `0` or `1`.
fn valid_bool(value: &u8) -> Result<()> {
    require_gte!(1, *value, KaminoVaultError::InvalidFlagValue);
    Ok(())
}

/// [config_items] validator asserting that a bps value does not exceed [FULL_BPS].
fn valid_bps(bps: &u64) -> Result<()> {
    require_gte!(u64::from(FULL_BPS), *bps, KaminoVaultError::BPSValueTooBig);
    Ok(())
}

/// [config_items] validator asserting that a max price age lies within [MIN_MAX_AGE_SECONDS] and
/// [MAX_MAX_AGE_SECONDS].
fn valid_max_age(seconds: &u64) -> Result<()> {
    require!(
        (u64::from(MIN_MAX_AGE_SECONDS)..=u64::from(MAX_MAX_AGE_SECONDS)).contains(seconds),
        KaminoVaultError::MaxPriceAgeOutOfRange
    );
    Ok(())
}

/// Builds a [config_items] validator asserting `convert(value) <= max`, failing with `error`.
fn at_most<T: Copy, C: PartialOrd + ToString + Copy>(
    max: C,
    convert: impl Fn(T) -> C,
    error: KaminoVaultError,
) -> impl Fn(&T) -> Result<()> {
    move |&value| {
        let value = convert(value);
        require_gte!(max, value, error);
        Ok(())
    }
}

static_assertions::const_assert_eq!(VAULT_TOKEN_STATE_SIZE, std::mem::size_of::<VaultToken>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<VaultToken>() % 16);
#[zero_copy]
#[derive(AnchorDeserialize, Debug, PartialEq, Eq)]
pub struct VaultToken {
    // Token state
    pub mint: Pubkey,
    pub vault: Pubkey,
    pub token_program: Pubkey,

    // Available (uninvested) token balance held by this vault token
    pub token_available: u64,

    pub decimals: u8,
    pub alignment_padding_1: [u8; 7],

    // Token config
    // Prices
    pub scope_configuration: ScopeConfiguration,

    pub max_twap_divergence_bps: u64,

    pub max_age_price_seconds: u64,
    pub max_age_twap_seconds: u64,

    // Min amounts
    pub min_deposit_amount: u64,
    pub min_withdraw_amount: u64,

    // Fees
    pub deposit_fee_bps: u64,
    pub deposit_fee_lamports: u64,
    pub withdraw_fee_bps: u64,
    pub withdraw_fee_lamports: u64,

    // Rebalance fields
    // Target weight (ratio = weight / sum_of_weights)
    pub weight: u64,
    pub alignment_padding_2: [u8; 16],

    /// The dutch-auction scales this token is sold and bought at.
    pub dutch_auction_scales: DutchAuctionScales,

    /// Maximum deviation (in bps) of the resulting token weight from `target` after a deposit
    /// or withdraw. Deposits must keep resulting weight <= target + deviation; withdraws must
    /// keep resulting weight >= target - deviation. A value of 0 disables the bound for this
    /// token (backward-compatible default for existing vaults).
    pub max_deviation_bps: u64,

    /// Maximum divergence (in bps of the scope price) tolerated between klend's cached reserve
    /// price and this token's scope price in the price-basis gate. 0 requires a bit-exact
    /// match — the gate fails closed until an explicit tolerance is set. Deliberately opposite
    /// to `max_deviation_bps`, where 0 disables the bound.
    pub max_price_divergence_bps: u64,

    /// What the live orders (of either kind) lock of this token: in its TA, but never part of
    /// `token_available` (the TA balance always covers `token_available + locked_total`; a withdraw
    /// order holds a slice of every liquid token, wanted by its weights or not).
    pub locked_total: u64,

    pub alignment_padding_3: [u8; 8],

    pub trailing_padding: [u128; 124],
}

impl VaultToken {
    // NOTE: this might be expensive but it's a simple way to have a symbol for each token instead of letting the manager set them individually
    pub fn symbol(&self) -> String {
        self.mint.to_string()
    }

    pub fn is_token_set(&self) -> bool {
        self.mint != Pubkey::default()
    }

    pub fn compute_aum(&self, token_price: &TokenPrice, rounding: RoundingMethod) -> DollarValue {
        self.available().to_aum(token_price, rounding)
    }

    pub fn weight(&self) -> Weight {
        Weight::from(self.weight)
    }

    /// How far this token's weight may stray from its target, or [None] when the vault imposes
    /// no such rule and any amount of it is welcome.
    ///
    /// An *absolute* deviation, added directly to a target weight ratio (not scaled), so a
    /// weight-typed ratio is the right shape.
    pub fn max_deviation(&self) -> Option<Ratio<Weight>> {
        if self.max_deviation_bps == 0 {
            return None;
        }
        Some(Ratio::from_bps(self.max_deviation_bps))
    }

    /// Returns [Self::max_price_divergence_bps] as a price-space ratio: the price-basis gate
    /// compares it against a divergence of `Fraction` prices, so the sides are fraction-typed.
    pub fn max_price_divergence(&self) -> Ratio<Fraction> {
        Ratio::from_bps(self.max_price_divergence_bps)
    }

    pub fn available(&self) -> TokenAmount {
        TokenAmount::from(self.token_available)
    }

    pub fn locked_total(&self) -> TokenAmount {
        TokenAmount::from(self.locked_total)
    }

    pub fn min_deposit(&self) -> TokenAmount {
        TokenAmount::from(self.min_deposit_amount)
    }

    pub fn min_withdraw(&self) -> TokenAmount {
        TokenAmount::from(self.min_withdraw_amount)
    }

    pub fn deposit_fee_spec(&self) -> MinFeeSpec {
        MinFeeSpec::new(
            Ratio::from_bps(self.deposit_fee_bps),
            TokenAmount::from(self.deposit_fee_lamports),
        )
    }

    pub fn withdrawal_fee_spec(&self) -> MinFeeSpec {
        MinFeeSpec::new(
            Ratio::from_bps(self.withdraw_fee_bps),
            TokenAmount::from(self.withdraw_fee_lamports),
        )
    }

    pub fn deposit_tokens(&mut self, amount: TokenAmount) {
        self.token_available += u64::from(amount);
    }

    pub fn withdraw_tokens(&mut self, amount: TokenAmount) {
        self.token_available -= u64::from(amount);
    }

    /// Adds `amount` to what the orders lock of this token (out of the vault's own AUM).
    pub fn lock(&mut self, amount: TokenAmount) {
        self.locked_total += u64::from(amount);
    }

    /// Takes `amount` off what the orders lock of this token.
    pub fn unlock(&mut self, amount: TokenAmount) {
        self.locked_total -= u64::from(amount);
    }

    #[inline]
    pub fn is_valid(&self) -> bool {
        self.scope_configuration.is_valid() && self.scope_configuration.is_enabled()
    }

    /// Tell if the twap is enabled
    #[inline]
    pub fn is_twap_enabled(&self) -> bool {
        self.max_twap_divergence_bps > 0
    }

    /// Check if the twap configuration is valid
    /// If twap is enabled:
    /// - all enabled prices need a twap
    /// - twap max age must be greater than 0
    #[inline]
    pub fn is_twap_config_valid(&self) -> bool {
        if !self.is_twap_enabled() {
            return true;
        }

        if self.max_age_twap_seconds == 0 {
            return false;
        }

        if self.scope_configuration.is_enabled() && !self.scope_configuration.has_twap() {
            return false;
        }

        true
    }

    pub fn validate_token_price_config(&self, scope_account_key: Pubkey) -> Result<()> {
        require!(self.is_valid(), KaminoVaultError::InvalidOracleConfig);
        require!(
            self.is_twap_config_valid(),
            KaminoVaultError::InvalidTwapConfig
        );
        require_keys_eq!(
            scope_account_key,
            self.scope_configuration.price_feed,
            KaminoVaultError::InvalidScopePriceAccount
        );

        Ok(())
    }
}

impl Default for VaultToken {
    fn default() -> Self {
        Self::zeroed()
    }
}

static_assertions::const_assert_eq!(
    VAULT_OBLIGATION_STATE_SIZE,
    std::mem::size_of::<VaultObligation>()
);
static_assertions::const_assert_eq!(0, std::mem::size_of::<VaultObligation>() % 16);
#[zero_copy]
#[derive(AnchorDeserialize, Debug, PartialEq, Eq)]
pub struct VaultObligation {
    pub obligation: Pubkey,
    /// Obligation LTV ceiling: predicted post-op borrow-factor-adjusted debt may
    /// not exceed this fraction (bps) of the obligation's unhealthy borrow value. `0` disables.
    pub max_unhealthy_ltv_fraction_bps: u64,
    pub alignment_padding_1: [u8; 8],
    pub trailing_padding: [u128; 5],
}

impl VaultObligation {
    pub fn new(obligation: Pubkey) -> Self {
        Self {
            obligation,
            max_unhealthy_ltv_fraction_bps: 0,
            alignment_padding_1: [0; 8],
            trailing_padding: default_array(),
        }
    }

    pub fn is_set(&self) -> bool {
        self.obligation != Pubkey::default()
    }

    pub fn max_unhealthy_ltv_fraction(&self) -> Ratio<DollarValue> {
        Ratio::from_bps(self.max_unhealthy_ltv_fraction_bps)
    }

    /// Validates and sets the obligation LTV ceiling. `0` disables.
    pub fn set_max_unhealthy_ltv_fraction_bps(&mut self, bps: u64) -> Result<()> {
        valid_bps(&bps)?;
        self.max_unhealthy_ltv_fraction_bps = bps;
        Ok(())
    }
}

impl Default for VaultObligation {
    fn default() -> Self {
        Self::zeroed()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allocation_authority_fails_closed_and_preserves_state_size() {
        assert_eq!(std::mem::size_of::<MetavaultState>(), VAULT_STATE_SIZE);

        let vault_admin = Pubkey::new_unique();
        let allocation_admin = Pubkey::new_unique();
        let stranger = Pubkey::new_unique();
        let mut vault = MetavaultState {
            vault_admin_authority: vault_admin,
            ..Default::default()
        };

        assert!(vault.is_allocation_authority(vault_admin));
        assert!(!vault.is_allocation_authority(stranger));
        assert!(!vault.is_allocation_authority(Pubkey::default()));

        vault.allocation_admin_authority = allocation_admin;
        assert!(vault.is_allocation_authority(vault_admin));
        assert!(vault.is_allocation_authority(allocation_admin));
        assert!(!vault.is_allocation_authority(stranger));
    }
}

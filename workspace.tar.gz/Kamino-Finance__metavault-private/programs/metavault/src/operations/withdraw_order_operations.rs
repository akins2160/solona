use anchor_lang::prelude::*;

use crate::{
    operations::{
        effects::{OpenWithdrawOrderEffects, OrderPayoutEffects},
        order_basket::OrderBasket,
        rebalance_basket::RebalanceBasket,
        rolling_cap,
        vault_operations::{
            charge_fees, common::calculate_shares_to_burn, finish_rebalance_and_rebaseline_aum,
        },
    },
    order::WithdrawOrder,
    state::MetavaultState,
    types::{
        DollarValue, Duration, MinFeeSpec, NetAum, Ratio, RebalanceLimits, RoundingMethod,
        ShareAmount, Timestamp, TokenAmount, Weight,
    },
    utils::{consts::MAX_TOKENS_PER_VAULT, scope::VaultScopePrices},
    GlobalConfig, KaminoVaultError,
};

/// Opens a freshly constructed order ([WithdrawOrder::new]): validates and records `weights`,
/// releases the pro-rata slice `shares` are worth into it (at least `min_tokens_out` of each
/// token) and starts its auction under `limits` (both per token: one per enabled token, dense).
#[allow(clippy::too_many_arguments)]
pub fn open_withdraw_order(
    order: &mut WithdrawOrder,
    vault: &mut MetavaultState,
    prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    shares: ShareAmount,
    weights: &[Weight],
    duration: Duration,
    limits: RebalanceLimits,
    min_tokens_out: &[TokenAmount],
    now: Timestamp,
) -> Result<OpenWithdrawOrderEffects> {
    require!(
        vault.withdraw_order_creation_enabled(),
        KaminoVaultError::WithdrawOrderCreationDisabled
    );
    require!(
        vault.block_withdraws == 0,
        KaminoVaultError::VaultWithdrawsBlocked
    );
    require_eq!(
        weights.len(),
        vault.get_tokens_count(),
        KaminoVaultError::TokenArrayLengthMismatch
    );
    require_eq!(
        min_tokens_out.len(),
        vault.get_tokens_count(),
        KaminoVaultError::TokenArrayLengthMismatch
    );
    let total_weight = weights
        .iter()
        .try_fold(Weight::ZERO, |sum, weight| sum.checked_add(*weight))
        .ok_or(KaminoVaultError::InvalidWeightsSum)?;
    require!(!total_weight.is_zero(), KaminoVaultError::InvalidWeightsSum);
    require!(
        !shares.is_zero(),
        KaminoVaultError::CannotWithdrawZeroShares
    );

    // Record the owner's weights (in the vault's storage index order, as the order keeps it all):
    let mut basket = OrderBasket { order, vault };
    for token in &basket.tokens() {
        basket
            .order
            .set_weight(token.id, weights[token.id.input_account_index]);
    }

    // Release the shares' slice into the order (burning them):
    let effects = release_pro_rata(
        &mut basket,
        prices,
        obligations_aum,
        global_config,
        shares,
        min_tokens_out,
        now,
    )?;

    // Start the auction toward the owner's requested weights (a basket already at them ends it at once):
    basket.start_auction(duration, prices, now, limits)?;

    Ok(effects)
}

/// How a withdraw order is settled: by its owner at any time, or by anyone once the auction is over
/// (which takes the prices to show, so only that mode carries them).
pub enum SettleMode {
    ByOwner,
    Permissionless(VaultScopePrices),
}

/// Ends the order by paying out everything it holds.
pub fn settle_withdraw_order(
    order: &mut WithdrawOrder,
    vault: &mut MetavaultState,
    mode: &SettleMode,
    now: Timestamp,
) -> Result<OrderPayoutEffects> {
    let mut basket = OrderBasket { order, vault };
    let mid_auction = match mode {
        SettleMode::ByOwner => basket.order.base.rebalance.is_within(now), // owner may settle even if not yet balanced
        SettleMode::Permissionless(prices) => {
            require!(
                basket.is_auction_over(prices, now),
                KaminoVaultError::OrderAuctionStillRunning
            );
            false // others never cut the auction short (see the check above)
        }
    };
    Ok(OrderPayoutEffects {
        payouts: basket.release_everything(),
        mid_auction,
    })
}

/// The core of an open: burns `shares` for a pro-rata slice of every liquid token, released into
/// the order (which leaves the vault's composition as it was, up to the fees it keeps).
#[allow(clippy::too_many_arguments)]
fn release_pro_rata(
    basket: &mut OrderBasket<WithdrawOrder>,
    prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    shares: ShareAmount,
    min_tokens_out: &[TokenAmount],
    now: Timestamp,
) -> Result<OpenWithdrawOrderEffects> {
    basket.vault.finish_rebalance_if_over(prices, now);
    let fee_shares_to_mint = charge_fees(basket.vault, prices, obligations_aum, now)?;

    // Halt withdrawals when the vault AUM is <= 0:
    let net_aum = basket
        .vault
        .compute_net_aum(prices, obligations_aum, RoundingMethod::Floor)
        .check_positive()?;
    let shares_issued = basket.vault.shares_issued_amount();
    require!(!shares_issued.is_zero(), KaminoVaultError::VaultSharesZero);
    require_gte!(
        shares_issued,
        shares,
        KaminoVaultError::WithdrawSharesExceedIssued
    );

    // The shares' claim on the vault, served from its liquid holdings only (the obligations stay)
    // and, as for the plain withdraw, clamped to them: the shares are burned for what is released.
    let claim_aum = net_aum.apply_ratio(Ratio::of(shares, shares_issued), RoundingMethod::Floor);
    require!(
        !claim_aum.is_zero(),
        KaminoVaultError::CannotWithdrawZeroLamports
    );
    let free_aum = basket.vault.compute_free_aum(prices, RoundingMethod::Floor);
    let fraction = if claim_aum >= free_aum {
        Ratio::one() // everything liquid goes (also keeps a zero `free_aum` out of a denominator)
    } else {
        Ratio::of(claim_aum, free_aum)
    };
    let release = plan_release(basket.vault, prices, global_config, fraction);
    // The owner's floor on each token, as for the plain withdraw:
    for token in &basket.tokens() {
        require_gte!(
            release.amounts[token.id.storage_index],
            min_tokens_out[token.id.input_account_index],
            KaminoVaultError::SlippageExceeded
        );
    }
    require!(
        !release.net_aum.is_zero(),
        KaminoVaultError::WithdrawAmountLessThanWithdrawalFee
    );
    if let Some(min_value) = basket.vault.order_min_open() {
        require_gte!(
            release.net_aum,
            min_value,
            KaminoVaultError::OrderBelowMinValue
        );
    }
    // Burn the shares the gross release is worth (its fees stay in the vault), at most those asked:
    let shares_to_burn =
        calculate_shares_to_burn(Ratio::of(release.gross_aum, net_aum), shares_issued).min(shares);
    // The withdraw cap takes the gross value too:
    rolling_cap::accumulate_withdraw(
        &mut basket.vault.rolling_withdraw_cap,
        release.gross_aum,
        now,
    )?;

    // Actually move the tokens from the vault into the order's basket:
    for token in &basket.tokens() {
        let amount = release.amounts[token.id.storage_index];
        if amount.is_zero() {
            continue;
        }
        basket
            .vault
            .get_vault_token_mut_by_id(token.id)
            .withdraw_tokens(amount);
        basket.credit(token.id, amount);
    }
    basket.vault.burn_shares(shares_to_burn);

    finish_rebalance_and_rebaseline_aum(basket.vault, prices, obligations_aum, now);

    Ok(OpenWithdrawOrderEffects {
        shares_to_burn,
        fee_shares_to_mint,
        released: release.amounts,
    })
}

/// What a pro-rata release takes from the vault, planned before anything moves.
struct Release {
    /// What the order receives, each leg net of its withdrawal fee (in storage order).
    amounts: [TokenAmount; MAX_TOKENS_PER_VAULT],

    /// The value the shares pay for: the legs gross of their fees (which stay in the vault).
    gross_aum: DollarValue,

    /// The value the order receives.
    net_aum: DollarValue,
}

/// Plans releasing `fraction` of every liquid token, each less its withdrawal fee (which stays in
/// the vault).
fn plan_release(
    vault: &MetavaultState,
    prices: &VaultScopePrices,
    global_config: &GlobalConfig,
    fraction: Ratio<DollarValue>,
) -> Release {
    let mut release = Release {
        amounts: [TokenAmount::ZERO; MAX_TOKENS_PER_VAULT],
        gross_aum: DollarValue::ZERO,
        net_aum: DollarValue::ZERO,
    };
    for (id, vault_token) in vault.enumerate_enabled_tokens() {
        let gross = vault_token
            .available()
            .apply_ratio(fraction, RoundingMethod::Floor);
        if gross.is_zero() {
            continue; // the pro-rata share is under a lamport
        }
        let fee = MinFeeSpec::combine_max(
            global_config.withdrawal_fee_spec(),
            vault_token.withdrawal_fee_spec(),
        )
        .calculate_fee_from(gross)
        .min(gross); // a leg not worth its fee is all fee (the plain withdraw would refuse it)
        let net = gross - fee;
        let price = prices.by_id(id);
        release.gross_aum = release
            .gross_aum
            .saturating_add(gross.to_aum(price, RoundingMethod::Ceil));
        release.net_aum = release
            .net_aum
            .saturating_add(net.to_aum(price, RoundingMethod::Floor));
        release.amounts[id.storage_index] = net;
    }
    release
}

use anchor_lang::prelude::*;

use crate::types::NetAum;
use crate::{
    kmsg_sized,
    operations::{
        effects::RebalanceFillEffects,
        rebalance_basket::RebalanceBasket,
        vault_operations::{charge_fees, rebaseline_aum},
    },
    state::{quote_swap_with_dutch_auction, MetavaultState},
    types::{
        BasketTokens, Duration, DutchAuctionBounds, RebalanceState, RoundingMethod,
        StartRebalanceAuthority, Timestamp, TokenAmount, VaultTokenId,
    },
    utils::{
        consts::{
            MAX_REBALANCE_DURATION, MIN_REBALANCE_DURATION, MIN_REBALANCE_SWAP_AMOUNT_LAMPORTS,
        },
        scope::VaultScopePrices,
    },
    KaminoVaultError,
};

pub fn start_rebalance(
    vault: &mut MetavaultState,
    rebalance_duration: Duration,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    current_timestamp: Timestamp,
    authority: StartRebalanceAuthority,
) -> Result<()> {
    charge_fees(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;

    // A rebalance that already ran its course is closed here like on every other path; one
    // that can still be filled blocks a new start.
    vault.finish_rebalance_if_over(vault_scope_prices, current_timestamp);
    require!(
        !vault.rebalance.is_unfinished(),
        KaminoVaultError::RebalanceInProgress
    );

    // Rebalance cooldown: rate-limits weight churn by the allocation key, including
    // stop-then-restart — only the exact vault admin key bypasses it.
    //
    // The anchor is deliberately the *start*, so the cooldown counts starts rather than
    // completions: a rebalance that ended early costs the delegate the same window as one that
    // ran its full course. That matters because ending one early is not the delegate's
    // privilege — any depositor or withdrawer can make the vault unfillable and every such
    // instruction closes a rebalance that is over. The delegate is then out of action until the
    // cooldown elapses or the vault admin (who bypasses it) starts one, so keep
    // `rebalance_cooldown_seconds` in the hours, not days, on vaults that delegate allocation.
    let cooldown_binds = authority == StartRebalanceAuthority::AllocationDelegate
        && !vault.rebalance_cooldown().is_zero();
    if cooldown_binds {
        // A vault that has never started a rebalance has nothing to measure from.
        if let Some(previous_start) = vault.rebalance.most_recent_start() {
            require_gte!(
                current_timestamp - previous_start,
                vault.rebalance_cooldown(),
                KaminoVaultError::RebalanceCooldownNotElapsed
            );
        }
    }

    require_gte!(
        rebalance_duration,
        MIN_REBALANCE_DURATION,
        KaminoVaultError::InvalidRebalanceDuration
    );
    require_gte!(
        MAX_REBALANCE_DURATION,
        rebalance_duration,
        KaminoVaultError::InvalidRebalanceDuration
    );

    let tokens = vault.tokens();
    require!(
        !tokens.total_weight().is_zero(),
        KaminoVaultError::InvalidWeightsSum
    );

    // If nothing can be filled at these prices, there is nothing to start.
    require!(
        tokens.is_progress_possible(vault_scope_prices),
        KaminoVaultError::VaultAlreadyRebalanced
    );

    // (A restart resets what was lost: the cooldown above rate-limits that, for the delegate.)
    let limits = vault.rebalance_limits;
    vault.start_rebalance(
        rebalance_duration,
        vault_scope_prices,
        current_timestamp,
        limits,
    );

    kmsg_sized!(100, "Rebalance started: duration={}", rebalance_duration);

    Ok(())
}

/// Ends the rebalance whatever its state, so stopping never fails on a race with the clock: an
/// expired one that nobody has closed yet is ended here too (and reported as stopped).
pub fn stop_rebalance(vault: &mut MetavaultState) -> Result<()> {
    require!(
        vault.rebalance.is_unfinished(),
        KaminoVaultError::RebalanceNotInProgress
    );

    vault.rebalance.finish();

    kmsg_sized!(100, "Rebalance stopped");

    Ok(())
}

/// A priced fill request: the input the vault will actually take, and the two independent
/// ceilings a solver's `requested_out_amount` has to fit under. Neither ceiling is the amount
/// that moves — that is the solver's own `requested_out_amount`, which may be lower than both.
#[derive(Debug, Clone, Copy)]
pub struct RebalanceSwapQuote {
    pub token_in_id: VaultTokenId,
    pub token_out_id: VaultTokenId,
    /// `amount_in` as accepted, clamped to the `token_in` deficit.
    pub amount_in: TokenAmount,
    /// What the dutch-auction curve prices `amount_in` at, at this point in the window.
    pub max_out_from_curve: TokenAmount,
    /// What the vault can part with: its excess of `token_out` over that token's target.
    pub max_out_from_inventory: TokenAmount,
}

/// Validates a fill request against a basket's `tokens` and `rebalance` and prices it on the curve
/// (read-only: nothing is moved or charged).
pub fn quote_rebalance_swap(
    tokens: &BasketTokens,
    rebalance: &RebalanceState,
    prices: &VaultScopePrices,
    token_in_mint: &Pubkey,
    token_out_mint: &Pubkey,
    amount_in: TokenAmount,
    current_timestamp: Timestamp,
) -> Result<RebalanceSwapQuote> {
    // Reject dust amounts early so griefers can't dust attack.
    require_gte!(
        amount_in,
        MIN_REBALANCE_SWAP_AMOUNT_LAMPORTS,
        KaminoVaultError::RebalanceSwapAmountBelowMinimum
    );

    let Some(auction_progress) = rebalance.progress(current_timestamp) else {
        return err!(KaminoVaultError::RebalanceNotInProgress);
    };

    // Resolve the in/out tokens and make sure we really need them swapped:
    let targets = tokens.targets(prices);
    let token_in = tokens.by_mint(token_in_mint)?;
    let token_out = tokens.by_mint(token_out_mint)?;
    common::validate_swap_pair(token_in, token_out, &targets)?;

    // An oversized input is clamped to the deficit:
    let amount_in = amount_in.min(token_in.deficit(targets.of(token_in.id)));

    // Find out how much of the out token we can get for this amount:
    let max_out_from_curve = quote_swap_with_dutch_auction(
        auction_progress,
        amount_in,
        prices.by_id(token_in.id),
        prices.by_id(token_out.id),
        &DutchAuctionBounds::of_fill(&token_in, &token_out),
    )?;
    let max_out_from_inventory = token_out.excess(targets.of(token_out.id));

    Ok(RebalanceSwapQuote {
        token_in_id: token_in.id,
        token_out_id: token_out.id,
        amount_in,
        max_out_from_curve,
        max_out_from_inventory,
    })
}

/// A solver's fill request: `amount_in` of one token for exactly `requested_out_amount` of another.
#[derive(Clone, Copy, Debug)]
pub struct FillRequest {
    pub token_in_mint: Pubkey,
    pub token_out_mint: Pubkey,
    pub amount_in: TokenAmount,
    pub requested_out_amount: TokenAmount,
    pub now: Timestamp,
}

/// A solver's fill against a basket: quotes the ask, refuses one above either ceiling, moves the
/// balances, records the fill against the rebalance's limits and ends the auction once nothing is
/// left to fill.
pub fn fill_rebalance_swap<B: RebalanceBasket>(
    basket: &mut B,
    prices: &VaultScopePrices,
    request: FillRequest,
) -> Result<RebalanceFillEffects> {
    let FillRequest {
        token_in_mint,
        token_out_mint,
        amount_in,
        requested_out_amount,
        now,
    } = request;
    let tokens = basket.tokens();
    let value_before = tokens.value(prices, RoundingMethod::Ceil); // the vault's free AUM: a fill moves no obligation
    let quote = quote_rebalance_swap(
        &tokens,
        basket.rebalance(),
        prices,
        &token_in_mint,
        &token_out_mint,
        amount_in,
        now,
    )?;

    // The solver is paid exactly what it asks for, provided the ask clears both ceilings.
    require_gte!(
        quote.max_out_from_curve,
        requested_out_amount,
        KaminoVaultError::SlippageExceeded
    );
    require_gte!(
        quote.max_out_from_inventory,
        requested_out_amount,
        KaminoVaultError::RequestedOutExceedsExcess
    );

    kmsg_sized!(
        400,
        "Filling {} token {} -> {} token {} (curve quoted {})",
        quote.amount_in,
        token_in_mint,
        requested_out_amount,
        token_out_mint,
        quote.max_out_from_curve
    );

    // Actually move the tokens in the accounting:
    basket.credit(quote.token_in_id, quote.amount_in);
    basket.debit(quote.token_out_id, requested_out_amount);

    // Record the fill against the rebalance's limits:
    let value_after = basket.tokens().value(prices, RoundingMethod::Ceil);
    let value_in = quote
        .amount_in
        .to_aum(prices.by_id(quote.token_in_id), RoundingMethod::Floor);
    basket
        .rebalance()
        .record_fill(value_in, value_before, value_after)?;

    // Targets shift with the balances just moved:
    basket.finish_rebalance_if_over(prices, now);
    Ok(RebalanceFillEffects {
        amount_in: quote.amount_in,
        rebalance_ended: !basket.rebalance().is_unfinished(), // a fill only happens inside the window
    })
}

/// The vault's fill: fee accrual first, so that the fill's loss is measured on its own, and the
/// AUM re-baselined after.
pub fn calculate_rebalance_swap(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    request: FillRequest,
) -> Result<RebalanceFillEffects> {
    charge_fees(vault, vault_scope_prices, obligations_aum, request.now)?;
    let effects = fill_rebalance_swap(vault, vault_scope_prices, request)?;
    rebaseline_aum(vault, vault_scope_prices, obligations_aum);
    Ok(effects)
}

pub mod common {
    use anchor_lang::*;

    use crate::{
        types::{BasketToken, RebalanceTargets},
        KaminoVaultError,
    };

    /// Returns an error if the basket is not interested in swapping the given pair (from its
    /// balance perspective).
    pub fn validate_swap_pair(
        token_in: BasketToken,
        token_out: BasketToken,
        targets: &RebalanceTargets,
    ) -> Result<()> {
        require!(
            token_in.id != token_out.id,
            KaminoVaultError::InvalidSwapPair
        );

        // We only swap when we have too little of the in token and too much of the out token:
        require!(
            token_in.is_in_deficit(targets.of(token_in.id)),
            KaminoVaultError::InvalidSwapPair
        );
        require!(
            token_out.is_in_excess(targets.of(token_out.id)),
            KaminoVaultError::InvalidSwapPair
        );

        Ok(())
    }
}

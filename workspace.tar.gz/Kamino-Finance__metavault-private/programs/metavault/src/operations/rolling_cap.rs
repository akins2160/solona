//! Tumbling-window USD rate limiter for vault deposit and withdraw flows.
//!
//! The primitive is direction-agnostic — call [`accumulate_deposit`] or [`accumulate_withdraw`]
//! to get a direction-specific cap-exceeded error mapping. Both wrappers call into the same
//! [`accumulate`] core. The window is drifting: on the first operation past expiry, the new
//! window starts at `now` (not on a fixed cadence).
//!
//! Disabled state is `interval_seconds == 0` — every public function is a no-op when the cap
//! is disabled, so callers can invoke unconditionally.

use anchor_lang::{error, prelude::Result};

use crate::types::{DollarValue, Timestamp};
use crate::{KaminoVaultError, RollingCap};

/// Tumbles the window forward if at least `interval_seconds` have elapsed since the last anchor.
///
/// On tumble: resets `accumulated_usd_sf` to 0 and updates `last_interval_start_timestamp` to
/// `now`. A future anchor (clock rolled backwards) yields `elapsed == 0` via
/// `Timestamp - Timestamp` saturating, so the window simply doesn't tumble.
pub fn tumble_window_if_needed(cap: &mut RollingCap, now: Timestamp) -> Result<()> {
    if cap.is_disabled() {
        return Ok(());
    }
    let last_start = cap.last_interval_start();
    let elapsed = now - last_start;
    if elapsed >= cap.interval() {
        cap.set_accumulated_usd(DollarValue::ZERO);
        cap.set_last_interval_start(now);
    }
    Ok(())
}

/// Adds `flow_usd` to the deposit-direction cap; maps cap-exceeded to
/// [`KaminoVaultError::RollingDepositCapExceeded`].
pub fn accumulate_deposit(
    cap: &mut RollingCap,
    flow_usd: DollarValue,
    now: Timestamp,
) -> Result<()> {
    accumulate(cap, flow_usd, now, || {
        error!(KaminoVaultError::RollingDepositCapExceeded)
    })
}

/// Adds `flow_usd` to the withdraw-direction cap; maps cap-exceeded to
/// [`KaminoVaultError::RollingWithdrawCapExceeded`].
pub fn accumulate_withdraw(
    cap: &mut RollingCap,
    flow_usd: DollarValue,
    now: Timestamp,
) -> Result<()> {
    accumulate(cap, flow_usd, now, || {
        error!(KaminoVaultError::RollingWithdrawCapExceeded)
    })
}

/// Common cap-accumulate path. Tumbles the window first, then `accumulated += flow_usd`.
/// Boundary is strict `>`: equality with `max_usd` passes (so an exhaust-the-cap deposit is
/// allowed).
///
/// On rejection, the accumulator is left untouched.
fn accumulate(
    cap: &mut RollingCap,
    flow_usd: DollarValue,
    now: Timestamp,
    on_exceeded: impl FnOnce() -> anchor_lang::error::Error,
) -> Result<()> {
    if cap.is_disabled() {
        return Ok(());
    }
    tumble_window_if_needed(cap, now)?;
    let new_accumulated = cap.accumulated_usd() + flow_usd;
    if new_accumulated > cap.max_usd() {
        return Err(on_exceeded());
    }
    cap.set_accumulated_usd(new_accumulated);
    Ok(())
}

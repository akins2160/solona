use anchor_lang::prelude::*;
use itertools::izip;
use kamino_lending::{
    fraction::Fraction,
    lending_market::lending_operations::utils::{
        get_elevation_group, get_max_ltv_and_liquidation_threshold,
    },
    utils::{FatAccountLoader, FractionExtra, ELEVATION_GROUP_NONE},
    LendingMarket, Obligation, Reserve,
};
use solana_program::pubkey::Pubkey;

use crate::{
    operations::effects::{
        BorrowObligationLiquidityEffects, DepositObligationCollateralEffects,
        RepayObligationLiquidityEffects, WithdrawObligationCollateralEffects,
    },
    require_msg,
    state::{VaultObligation, VaultToken},
    types::{
        DollarValue, FractionalTokenAmount, Ratio, RoundingMethod, ShareAmount, TokenAmount,
        TokenPrice,
    },
    utils::scope::VaultScopePrices,
    KaminoVaultError, MetavaultState,
};

/// Returns whether the vault token of the given mint uses the same scope config as the given klend
/// reserve.
///
/// Note: this is an extracted helper for more concise Anchor constraints.
pub fn has_matching_scope_config(
    vault: &MetavaultState,
    mint: &Pubkey,
    reserve: &Reserve,
) -> Result<bool> {
    Ok(vault.get_vault_token_by_mint(mint)?.scope_configuration
        == reserve.config.token_info.scope_configuration)
}

pub struct VaultOperationBalances {
    pub user_shares_balance_before: ShareAmount,
    pub user_shares_balance_after: ShareAmount,
    pub user_token_balances_before: Vec<TokenAmount>,
    pub user_token_balances_after: Vec<TokenAmount>,
    pub vault_shares_issued_before: ShareAmount,
    pub vault_shares_issued_after: ShareAmount,
    pub vault_token_balances_before: Vec<TokenAmount>,
    pub vault_token_balances_after: Vec<TokenAmount>,
}

pub fn post_transfer_deposit_checks(
    balances: &VaultOperationBalances,
    user_requested_amounts: &[TokenAmount],
    tokens_to_deposit: &[TokenAmount],
    fee_shares_to_mint: ShareAmount,
) -> Result<()> {
    let user_shares_gained =
        balances.user_shares_balance_after - balances.user_shares_balance_before;

    // Check shares issued correctly
    let expected_shares_issued =
        balances.vault_shares_issued_before + user_shares_gained + fee_shares_to_mint;
    require_msg!(
        expected_shares_issued == balances.vault_shares_issued_after,
        KaminoVaultError::SharesIssuedAmountDoesNotMatch,
        &format!(
            "Shares issued mismatch: expected {} got {}",
            expected_shares_issued, balances.vault_shares_issued_after
        )
    );

    // Check max amounts
    for (i, (&deposited_amount, &max_amount)) in
        izip!(tokens_to_deposit, user_requested_amounts).enumerate()
    {
        require_msg!(
            deposited_amount <= max_amount,
            KaminoVaultError::DepositAmountGreaterThanRequestedAmount,
            &format!(
                "Token {} deposit amount {} exceeds max amount {}",
                i, deposited_amount, max_amount
            )
        );
    }

    // Check balance changes for each token
    for (
        i,
        (
            &user_balance_before,
            &user_balance_after,
            &vault_balance_before,
            &vault_balance_after,
            &deposited_amount,
        ),
    ) in izip!(
        &balances.user_token_balances_before,
        &balances.user_token_balances_after,
        &balances.vault_token_balances_before,
        &balances.vault_token_balances_after,
        tokens_to_deposit
    )
    .enumerate()
    {
        let expected_user_balance = user_balance_before - deposited_amount;
        require_msg!(
            user_balance_after == expected_user_balance,
            KaminoVaultError::TokensDepositedAmountDoesNotMatch,
            &format!(
                "Token {} user balance mismatch: expected {} got {}",
                i, expected_user_balance, user_balance_after
            )
        );

        let expected_vault_balance = vault_balance_before + deposited_amount;
        require_msg!(
            vault_balance_after == expected_vault_balance,
            KaminoVaultError::VaultBalanceDoesNotMatch,
            &format!(
                "Token {} vault balance mismatch: expected {} got {}",
                i, expected_vault_balance, vault_balance_after
            )
        );
    }

    Ok(())
}

pub fn post_withdraw_pending_fees_check(
    vault_state: &MetavaultState,
    spl_supply: ShareAmount,
) -> Result<()> {
    let remaining_pending_fees = vault_state.pending_fees().floor_shares();
    // Expected should also include the initial deposit amount, but because the vault can have a deposit fee
    // before the initial deposit this actually becomes between
    // [spl_supply + remaining_pending_fees, spl_supply + remaining_pending_fees + INITIAL_DEPOSIT_SIZE]
    // ( assuming no burns )
    let expected = spl_supply + remaining_pending_fees; // + INITIAL_DEPOSIT_SIZE
    let shares_issued = vault_state.shares_issued_amount();
    // Use >= because users can externally burn SPL share tokens (bypassing
    // the vault), which reduces spl_supply without touching shares_issued.
    // External mints are impossible since the mint authority is the vault PDA.
    // shares_issued < expected would indicate a real accounting bug.
    require_msg!(
        shares_issued >= expected,
        KaminoVaultError::SharesSupplyInconsistent,
        &format!("Shares issued {} and expected {}", shares_issued, expected)
    );
    Ok(())
}

pub fn post_transfer_withdraw_checks(
    balances: &VaultOperationBalances,
    shares_to_burn: ShareAmount,
    tokens_to_withdraw: &[TokenAmount],
    fee_shares_to_mint: ShareAmount,
) -> Result<()> {
    check_shares_burned(
        balances.user_shares_balance_before,
        balances.user_shares_balance_after,
        balances.vault_shares_issued_before,
        balances.vault_shares_issued_after,
        shares_to_burn,
        fee_shares_to_mint,
    )?;

    // Check balance changes for each token
    for (
        i,
        (
            &user_balance_before,
            &user_balance_after,
            &vault_balance_before,
            &vault_balance_after,
            &withdrawn_amount,
        ),
    ) in izip!(
        &balances.user_token_balances_before,
        &balances.user_token_balances_after,
        &balances.vault_token_balances_before,
        &balances.vault_token_balances_after,
        tokens_to_withdraw
    )
    .enumerate()
    {
        // Check user received correct amount
        let user_ata_increase = user_balance_after.token_diff(user_balance_before);
        let expected_increase = i128::from(withdrawn_amount);

        require_msg!(
            user_ata_increase == expected_increase,
            KaminoVaultError::UserReceivedAmountDoesNotMatch,
            &format!(
                "Token {} user received mismatch: increase {} != withdrawn {}",
                i, user_ata_increase, expected_increase
            )
        );

        // Check vault balance changed correctly
        let expected_vault_balance = vault_balance_before - withdrawn_amount;
        require_msg!(
            vault_balance_after == expected_vault_balance,
            KaminoVaultError::VaultBalanceDoesNotMatch,
            &format!(
                "Token {} vault balance mismatch: expected {} got {}",
                i, expected_vault_balance, vault_balance_after
            )
        );
    }

    Ok(())
}

/// The share side of a withdrawal: the user lost exactly `shares_to_burn`, and the vault's issued
/// count followed it (less the burn, plus the fee shares minted).
pub fn check_shares_burned(
    user_shares_before: ShareAmount,
    user_shares_after: ShareAmount,
    vault_shares_issued_before: ShareAmount,
    vault_shares_issued_after: ShareAmount,
    shares_to_burn: ShareAmount,
    fee_shares_to_mint: ShareAmount,
) -> Result<()> {
    let user_shares_burned = user_shares_before - user_shares_after;

    // Check shares issued correctly
    let expected_shares_issued =
        vault_shares_issued_before - user_shares_burned + fee_shares_to_mint;
    require_msg!(
        expected_shares_issued == vault_shares_issued_after,
        KaminoVaultError::SharesIssuedAmountDoesNotMatch,
        &format!(
            "Vault shares issued mismatch: expected {} got {}",
            expected_shares_issued, vault_shares_issued_after
        )
    );

    // Check shares burned
    require_msg!(
        user_shares_burned == shares_to_burn,
        KaminoVaultError::SharesBurnedAmountDoesNotMatch,
        &format!(
            "Shares burned mismatch: actual {} != expected {}",
            user_shares_burned, shares_to_burn
        )
    );
    Ok(())
}

/// The four token balances a rebalance swap moves (one snapshot, taken before and after it).
pub struct SwapBalances {
    pub user_token_in: TokenAmount,

    pub user_token_out: TokenAmount,

    pub vault_token_in: TokenAmount,

    pub vault_token_out: TokenAmount,
}

pub struct DepositObligationCollateralBalances {
    pub vault_token_balance: TokenAmount,
    pub reserve_liquidity_supply: TokenAmount,
    pub reserve_destination_deposit_collateral: TokenAmount,
}

pub fn post_deposit_obligation_collateral_checks(
    pre: &DepositObligationCollateralBalances,
    post: &DepositObligationCollateralBalances,
    effects: &DepositObligationCollateralEffects,
) -> Result<()> {
    let vault_out = pre.vault_token_balance - post.vault_token_balance;
    require_msg!(
        vault_out == effects.liquidity_to_deposit,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "vault sent {} liquidity, expected {}",
            vault_out, effects.liquidity_to_deposit
        )
    );
    let reserve_in = post.reserve_liquidity_supply - pre.reserve_liquidity_supply;
    require_msg!(
        reserve_in == effects.liquidity_to_deposit,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "reserve received {} liquidity, expected {}",
            reserve_in, effects.liquidity_to_deposit
        )
    );
    let collateral_minted =
        post.reserve_destination_deposit_collateral - pre.reserve_destination_deposit_collateral;
    require_msg!(
        collateral_minted == effects.ctokens_to_receive,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "obligation collateral escrow gained {}, expected {}",
            collateral_minted, effects.ctokens_to_receive
        )
    );
    Ok(())
}

pub struct WithdrawObligationCollateralBalances {
    pub vault_token_balance: TokenAmount,
    pub reserve_liquidity_supply: TokenAmount,
    pub reserve_source_collateral: TokenAmount,
}

pub fn post_withdraw_obligation_collateral_checks(
    pre: &WithdrawObligationCollateralBalances,
    post: &WithdrawObligationCollateralBalances,
    effects: &WithdrawObligationCollateralEffects,
) -> Result<()> {
    let vault_in = post.vault_token_balance - pre.vault_token_balance;
    let reserve_out = pre.reserve_liquidity_supply - post.reserve_liquidity_supply;
    require_msg!(
        reserve_out == vault_in,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "reserve released {} liquidity, vault received {}",
            reserve_out, vault_in
        )
    );

    let collateral_burned = pre.reserve_source_collateral - post.reserve_source_collateral;
    require_msg!(
        collateral_burned == effects.ctokens_to_redeem,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "obligation collateral escrow released {}, expected {}",
            collateral_burned, effects.ctokens_to_redeem
        )
    );

    require_msg!(
        vault_in == effects.liquidity_to_receive,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "vault received {} liquidity, expected {} for {} redeemed ctokens",
            vault_in, effects.liquidity_to_receive, collateral_burned
        )
    );

    Ok(())
}

pub struct BorrowObligationLiquidityBalances {
    pub vault_token_balance: TokenAmount,
    pub reserve_source_liquidity: TokenAmount,
    pub reserve_liquidity_fee_receiver: TokenAmount,
}

pub fn post_borrow_obligation_liquidity_checks(
    pre: &BorrowObligationLiquidityBalances,
    post: &BorrowObligationLiquidityBalances,
    effects: &BorrowObligationLiquidityEffects,
) -> Result<()> {
    let vault_in = post.vault_token_balance - pre.vault_token_balance;
    require_msg!(
        vault_in == effects.liquidity_to_receive,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "vault received {} liquidity, expected {}",
            vault_in, effects.liquidity_to_receive
        )
    );
    let reserve_out = pre.reserve_source_liquidity - post.reserve_source_liquidity;
    let expected_reserve_out = effects.liquidity_to_receive + effects.origination_fee;
    require_msg!(
        reserve_out == expected_reserve_out,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "reserve released {} liquidity, expected {} (receive {} + fee {})",
            reserve_out,
            expected_reserve_out,
            effects.liquidity_to_receive,
            effects.origination_fee
        )
    );
    let fee_in = post.reserve_liquidity_fee_receiver - pre.reserve_liquidity_fee_receiver;
    require_msg!(
        fee_in == effects.origination_fee,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "fee receiver gained {}, expected {}",
            fee_in, effects.origination_fee
        )
    );
    Ok(())
}

pub struct RepayObligationLiquidityBalances {
    pub vault_token_balance: TokenAmount,
    pub reserve_destination_liquidity: TokenAmount,
}

pub fn post_repay_obligation_liquidity_checks(
    pre: &RepayObligationLiquidityBalances,
    post: &RepayObligationLiquidityBalances,
    effects: &RepayObligationLiquidityEffects,
) -> Result<()> {
    let vault_out = pre.vault_token_balance - post.vault_token_balance;
    require_msg!(
        vault_out == effects.liquidity_to_repay,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "vault sent {} liquidity, expected {}",
            vault_out, effects.liquidity_to_repay
        )
    );
    let reserve_in = post.reserve_destination_liquidity - pre.reserve_destination_liquidity;
    require_msg!(
        reserve_in == effects.liquidity_to_repay,
        KaminoVaultError::BalanceAfterObligationCpiMismatch,
        &format!(
            "reserve received {} liquidity, expected {}",
            reserve_in, effects.liquidity_to_repay
        )
    );
    Ok(())
}

/// Enforces the obligation LTV ceiling: the predicted
/// post-op borrow-factor-adjusted debt must not exceed the configured fraction of the predicted
/// unhealthy borrow value. A zero ceiling disables the check. The allowance rounds down
/// (vault-favorable: stricter).
///
/// Callers provide post-op-predicted values — see [check_borrow_ltv_ceiling],
/// [check_withdraw_ltv_ceiling], and [check_elevation_group_ltv_ceiling].
pub(crate) fn check_obligation_ltv_ceiling(
    max_unhealthy_ltv_fraction: Ratio<DollarValue>,
    bf_adjusted_debt_value: DollarValue,
    unhealthy_borrow_value: DollarValue,
) -> Result<()> {
    if max_unhealthy_ltv_fraction.is_zero() {
        return Ok(());
    }
    let allowed_bf_debt_value =
        unhealthy_borrow_value.apply_ratio(max_unhealthy_ltv_fraction, RoundingMethod::Floor);
    require_gte!(
        allowed_bf_debt_value,
        bf_adjusted_debt_value,
        KaminoVaultError::ObligationLtvCeilingExceeded
    );
    Ok(())
}

/// Post-CPI borrow check, mirroring klend's `post_borrow_obligation_invariants`: the new debt's
/// market value (reserve price basis, same as the refreshed aggregates) is borrow-factor adjusted
/// and added to the refreshed debt aggregate; the unhealthy value is unchanged by a borrow.
///
/// Called after the handler reloads the obligation post-CPI: klend's borrow mutates only
/// per-position amounts (`ObligationLiquidity::borrow`) and marks the obligation stale — it never
/// recomputes `borrow_factor_adjusted_debt_value_sf` / `unhealthy_borrow_value_sf` itself (only
/// `refresh_obligation` does). So the aggregates read here still carry the same-slot pre-op
/// refresh, which is exactly the anchor this delta needs.
pub fn check_borrow_ltv_ceiling(
    vault_obligation: &VaultObligation,
    reserve: &Reserve,
    obligation: &Obligation,
    new_debt: FractionalTokenAmount,
) -> Result<()> {
    let max_unhealthy_ltv_fraction = vault_obligation.max_unhealthy_ltv_fraction();
    if max_unhealthy_ltv_fraction.is_zero() {
        return Ok(());
    }
    let new_debt_mv = reserve
        .liquidity
        .liquidity_amount_to_market_value(new_debt.into());
    let borrow_factor = reserve.borrow_factor_f(obligation.elevation_group != ELEVATION_GROUP_NONE);
    let bf_adjusted_debt_value =
        DollarValue::from_bits(obligation.borrow_factor_adjusted_debt_value_sf)
            + DollarValue::from(new_debt_mv * borrow_factor);
    check_obligation_ltv_ceiling(
        max_unhealthy_ltv_fraction,
        bf_adjusted_debt_value,
        DollarValue::from_bits(obligation.unhealthy_borrow_value_sf),
    )
}

/// Post-CPI withdraw check, mirroring klend's `post_withdraw_obligation_invariants`: the withdrawn
/// collateral's market value, scaled by the reserve's (elevation-group-aware) liquidation
/// threshold, is subtracted from the refreshed unhealthy borrow value; the debt aggregate is
/// unchanged by a withdrawal. Saturating ops match klend (worst case a zero allowance, which fails
/// closed).
///
/// `withdrawn_liquidity` must be the full-precision ctoken→liquidity conversion of the redeemed
/// collateral — the same fractional arithmetic klend's next `refresh_obligation` values deposit
/// legs with — NOT the floor'd integer amount klend actually transfers: the truncated amount
/// would under-subtract by up to one lamport's value, leaving this ceiling looser than klend's
/// own post-state.
///
/// The threshold scaling is NOT bit-for-bit klend: klend computes `Fraction::from_percent(pct)` (a
/// truncating pct/100 division) and then multiplies it in (a second truncation), whereas this uses
/// an exact `Ratio::from_bps(pct * 100)` multiplied via a single full-precision floor
/// ([`DollarValue::apply_ratio`]). Each of klend's two truncations can only lose value, so the
/// value subtracted here is always >= klend's — i.e. this check is at most a few ULPs (on the
/// order of 1e-16 dollars) stricter than klend, never looser. That is far below the whole-dollar
/// margins the boundary tests pin, so it does not change any test outcome — vault-favorable.
///
/// Called after the handler reloads the obligation post-CPI: klend's withdraw mutates only
/// per-position amounts (`ObligationCollateral::withdraw`) and marks the obligation stale — it
/// never recomputes `borrow_factor_adjusted_debt_value_sf` / `unhealthy_borrow_value_sf` itself
/// (only `refresh_obligation` does). So the aggregates read here still carry the same-slot pre-op
/// refresh, which is exactly the anchor this delta needs.
pub fn check_withdraw_ltv_ceiling(
    vault_obligation: &VaultObligation,
    reserve: &Reserve,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    withdrawn_liquidity: FractionalTokenAmount,
) -> Result<()> {
    let max_unhealthy_ltv_fraction = vault_obligation.max_unhealthy_ltv_fraction();
    if max_unhealthy_ltv_fraction.is_zero() {
        return Ok(());
    }
    let withdrawn_mv = DollarValue::from(
        reserve
            .liquidity
            .liquidity_amount_to_market_value(withdrawn_liquidity.into()),
    );
    let (_max_ltv_pct, liquidation_threshold_pct) = get_max_ltv_and_liquidation_threshold(
        reserve,
        get_elevation_group(obligation.elevation_group, lending_market)?,
    );
    let liquidation_threshold =
        Ratio::<DollarValue>::from_bps(u64::from(liquidation_threshold_pct) * 100);
    let withdrawn_threshold_value =
        withdrawn_mv.apply_ratio(liquidation_threshold, RoundingMethod::Floor);
    let predicted_unhealthy_borrow_value =
        DollarValue::from_bits(obligation.unhealthy_borrow_value_sf)
            .saturating_sub(withdrawn_threshold_value);
    check_obligation_ltv_ceiling(
        max_unhealthy_ltv_fraction,
        DollarValue::from_bits(obligation.borrow_factor_adjusted_debt_value_sf),
        predicted_unhealthy_borrow_value,
    )
}

/// Post-CPI elevation-group check: an elevation-group switch changes both sides of the ceiling
/// ratio (borrow factors and liquidation thresholds) without moving tokens, and klend only
/// enforces the destination group's own max-LTV allowance — which can be looser than the vault's
/// configured fraction of unhealthy LTV.
///
/// Unlike borrow/withdraw, klend's `request_elevation_group` recomputes the destination-group
/// aggregates only into locals for its own health check — the obligation-level
/// `borrow_factor_adjusted_debt_value_sf` / `unhealthy_borrow_value_sf` still carry the same-slot
/// pre-CPI refresh under the *source* group. What the CPI does persist is per-position: each
/// borrow's `borrow_factor_adjusted_market_value_sf` is rewritten under the destination group's
/// borrow factor, and each deposit's `market_value_sf` at current prices. So this rebuilds the
/// destination aggregates from those: the debt side sums the stored per-borrow values, and the
/// unhealthy side mirrors klend's `refresh_obligation_deposits` arithmetic
/// (`market_value × Fraction::from_percent(threshold)`) with the destination group's thresholds —
/// bit-identical to what the next `refresh_obligation` will write.
///
/// `deposit_reserves` are the leading remaining accounts forwarded to the CPI; klend already
/// validated them pairwise against the active deposits (same order), and the keys are re-checked
/// here.
pub fn check_elevation_group_ltv_ceiling(
    vault_obligation: &VaultObligation,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    deposit_reserves: &[AccountInfo],
) -> Result<()> {
    let max_unhealthy_ltv_fraction = vault_obligation.max_unhealthy_ltv_fraction();
    if max_unhealthy_ltv_fraction.is_zero() {
        return Ok(());
    }
    let elevation_group = get_elevation_group(obligation.elevation_group, lending_market)?;

    let mut bf_adjusted_debt_value = Fraction::ZERO;
    for borrow in obligation.active_borrows() {
        bf_adjusted_debt_value +=
            Fraction::from_bits(borrow.borrow_factor_adjusted_market_value_sf);
    }

    let mut unhealthy_borrow_value = Fraction::ZERO;
    let mut deposit_reserves_iter = deposit_reserves.iter();
    for deposit in obligation.active_deposits() {
        let reserve_info = deposit_reserves_iter
            .next()
            .ok_or_else(|| error!(KaminoVaultError::ObligationAccountMissing))?;
        require_keys_eq!(
            reserve_info.key(),
            deposit.deposit_reserve,
            KaminoVaultError::ObligationAccountMissing
        );
        let reserve_loader = FatAccountLoader::<Reserve>::try_from(reserve_info)?;
        let reserve = reserve_loader.load()?;
        let (_max_ltv_pct, liquidation_threshold_pct) =
            get_max_ltv_and_liquidation_threshold(&reserve, elevation_group);
        unhealthy_borrow_value += Fraction::from_bits(deposit.market_value_sf)
            * Fraction::from_percent(liquidation_threshold_pct);
    }

    check_obligation_ltv_ceiling(
        max_unhealthy_ltv_fraction,
        DollarValue::from(bf_adjusted_debt_value),
        DollarValue::from(unhealthy_borrow_value),
    )
}

pub fn post_transfer_swap_checks(
    pre: &SwapBalances,
    post: &SwapBalances,
    amount_in: TokenAmount,
    amount_out: TokenAmount,
) -> Result<()> {
    // Verify vault received token_in
    let vault_in_increase = post.vault_token_in.token_diff(pre.vault_token_in);
    let expected_in = i128::from(amount_in);
    require_msg!(
        vault_in_increase == expected_in,
        KaminoVaultError::VaultBalanceDoesNotMatch,
        &format!(
            "Vault token_in balance mismatch: increase {} != expected {}",
            vault_in_increase, expected_in
        )
    );

    // Verify vault sent token_out
    let vault_out_decrease = pre.vault_token_out.token_diff(post.vault_token_out);
    let expected_out = i128::from(amount_out);
    require_msg!(
        vault_out_decrease == expected_out,
        KaminoVaultError::VaultBalanceDoesNotMatch,
        &format!(
            "Vault token_out balance mismatch: decrease {} != expected {}",
            vault_out_decrease, expected_out
        )
    );

    // Verify user sent token_in
    let user_in_decrease = pre.user_token_in.token_diff(post.user_token_in);
    require_msg!(
        user_in_decrease == expected_in,
        KaminoVaultError::TokensDepositedAmountDoesNotMatch,
        &format!(
            "User token_in balance mismatch: decrease {} != expected {}",
            user_in_decrease, expected_in
        )
    );

    // Verify user received token_out
    let user_out_increase = post.user_token_out.token_diff(pre.user_token_out);
    require_msg!(
        user_out_increase == expected_out,
        KaminoVaultError::UserReceivedAmountDoesNotMatch,
        &format!(
            "User token_out balance mismatch: increase {} != expected {}",
            user_out_increase, expected_out
        )
    );

    Ok(())
}

/// The token's TA balance must cover the vault's own available plus what the orders lock there
/// (checked wherever tokens leave a TA, or an order locks them).
pub fn check_vault_balance_covers_locked(
    vault_balance: TokenAmount,
    vault_token: &VaultToken,
) -> Result<()> {
    require_gte!(
        vault_balance,
        vault_token.available() + vault_token.locked_total(),
        KaminoVaultError::TokenVaultBalanceBelowLocked
    );
    Ok(())
}

/// Finds the enabled vault token and its scope price for a mint. The zip pairing is the
/// invariant layout of [VaultScopePrices] (one price per enabled token, in order).
pub fn find_enabled_token_and_price<'a>(
    vault: &'a MetavaultState,
    vault_scope_prices: &'a VaultScopePrices,
    mint: &Pubkey,
) -> Result<(&'a VaultToken, &'a TokenPrice)> {
    vault
        .iter_enabled_tokens()
        .zip(&vault_scope_prices.prices)
        .find(|(token, _)| token.mint == *mint)
        .ok_or_else(|| KaminoVaultError::TokenNotEnabledInVault.into())
}

/// Requires klend's cached reserve price to stay within the token's configured divergence bound
/// of the vault's scope price — the price-basis gate: obligation AUM is valued at scope prices,
/// so a reserve whose own oracle basis has drifted away from scope must not be transacted
/// against.
/// [Ratio] comparison cross-multiplies at full precision, so this is exactly klend's
/// `is_within_tolerance` formula but with `<=` instead of `<`: zero tolerance accepts bit-equal
/// prices and nothing else (fail closed until a tolerance is configured).
/// Retryable by re-refreshing the reserve in the same transaction as the operation.
pub fn check_reserve_price_basis(
    vault_token: &VaultToken,
    token_price: &TokenPrice,
    reserve: &Reserve,
) -> Result<()> {
    // The scope price is non-zero by scope-load validation, so the relative difference is
    // well-formed.
    let divergence = Ratio::rel_diff(reserve.liquidity.get_market_price(), token_price.price());
    require_gte!(
        vault_token.max_price_divergence(),
        divergence,
        KaminoVaultError::ReservePriceMismatch
    );
    Ok(())
}

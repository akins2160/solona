use crate::{
    types::{FractionalTokenAmount, ShareAmount, TokenAmount},
    utils::consts::MAX_TOKENS_PER_VAULT,
};

#[derive(Debug, PartialEq)]
pub struct DepositEffects {
    pub shares_to_mint: ShareAmount,
    pub token_to_deposit: TokenAmount,
    pub fee_shares_to_mint: ShareAmount,
}

#[derive(Debug, Default, PartialEq)]
pub struct WithdrawEffects {
    pub shares_to_burn: ShareAmount,
    pub available_to_send_to_user: TokenAmount,
    pub fee_shares_to_mint: ShareAmount,
}

#[derive(Debug, Default)]
pub struct WithdrawPendingFeesEffects {
    pub available_to_send_to_user: ShareAmount,
}

#[derive(Debug, Default, PartialEq)]
pub struct RefreshVaultEffects {
    pub fee_shares_to_mint: ShareAmount,
}

#[derive(Debug, PartialEq)]
pub struct DepositObligationCollateralEffects {
    /// Liquidity tokens the vault sends to klend - may be less than the requested amount (due to
    /// klend's ctoken exchange rate misalignment).
    pub liquidity_to_deposit: TokenAmount,
    /// Ctokens klend mints in exchange.
    pub ctokens_to_receive: TokenAmount,
}

#[derive(Debug, PartialEq)]
pub struct WithdrawObligationCollateralEffects {
    /// Ctoken klend burns from the obligation.
    pub ctokens_to_redeem: TokenAmount,
    /// Liquidity tokens received in exchange.
    pub liquidity_to_receive: TokenAmount,
}

#[derive(Debug, PartialEq)]
pub struct BorrowObligationLiquidityEffects {
    /// Liquidity tokens the vault receives from klend's reserve.
    pub liquidity_to_receive: TokenAmount,
    /// Origination fee klend transfers from the reserve to its fee receiver account.
    pub origination_fee: TokenAmount,
    /// Increase in the obligation's debt, as klend will record it: exactly
    /// `liquidity_to_receive + origination_fee` for an exact-amount borrow, but fractional for
    /// all-available sizing.
    pub debt_increase: FractionalTokenAmount,
}

#[derive(Debug, PartialEq)]
pub struct RepayObligationLiquidityEffects {
    /// Liquidity tokens the vault sends to klend's reserve; the ceiling of `debt_decrease`.
    pub liquidity_to_repay: TokenAmount,
    /// Decrease in the obligation's debt, as klend will settle it — fractional when a full
    /// repay clears interest-bearing debt.
    pub debt_decrease: FractionalTokenAmount,
}

/// What settling a deposit order did: the vault absorbed what it admits and refunds the rest.
#[derive(Debug, PartialEq, Eq)]
pub struct SettleDepositOrderEffects {
    /// What the absorb minted for the owner.
    pub shares_minted: ShareAmount,

    /// What goes back to the owner (in the vault's storage index order).
    pub refunds: [TokenAmount; MAX_TOKENS_PER_VAULT],
}

/// What ending an order by paying it out did (a deposit order's cancel, a withdraw order's settle):
/// everything it held goes to the owner.
#[derive(Debug, PartialEq, Eq)]
pub struct OrderPayoutEffects {
    /// What goes to the owner (in the vault's storage index order).
    pub payouts: [TokenAmount; MAX_TOKENS_PER_VAULT],

    /// Whether the owner cut the auction short (settled or cancelled inside its window).
    pub mid_auction: bool,
}

/// What opening a withdraw order did: shares burned for the value released into the order.
#[derive(Debug, PartialEq, Eq)]
pub struct OpenWithdrawOrderEffects {
    /// What was burned - possibly less than requested (if liquidity is locked up in obligations).
    pub shares_to_burn: ShareAmount,

    /// The fee shares this open charged before pricing the claim (booked into `shares_issued` and
    /// the vault's pending fees, which the admin withdraws later; no share token is minted here).
    pub fee_shares_to_mint: ShareAmount,

    /// What the order received after fees (in the vault's storage index order).
    pub released: [TokenAmount; MAX_TOKENS_PER_VAULT],
}

/// What a solver's fill did, against the vault's own rebalance or an order's auction (of either
/// kind).
#[derive(Debug, PartialEq, Eq)]
pub struct RebalanceFillEffects {
    /// The input taken: the request clamped to the basket's `token_in` deficit (the output is
    /// always the caller's own `requested_out_amount`).
    pub amount_in: TokenAmount,

    /// Whether this fill left the rebalance (or the auction) with nothing more to do.
    pub rebalance_ended: bool,
}

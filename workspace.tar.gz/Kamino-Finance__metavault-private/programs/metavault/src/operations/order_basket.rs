use anchor_lang::prelude::*;

use crate::{
    operations::{
        effects::RebalanceFillEffects,
        rebalance_basket::RebalanceBasket,
        rebalance_operations::{fill_rebalance_swap, FillRequest},
    },
    order::{DepositOrder, OrderBase, WithdrawOrder},
    state::{MetavaultState, VaultToken},
    types::{
        BasketToken, BasketTokens, Duration, RebalanceLimits, RebalanceState, Timestamp,
        TokenAmount, VaultTokenId, Weight,
    },
    utils::{
        consts::{MAX_ORDER_AUCTION_DURATION, MAX_TOKENS_PER_VAULT, MIN_ORDER_AUCTION_DURATION},
        scope::VaultScopePrices,
    },
    KaminoVaultError,
};

/// Either kind of order as the shared code sees it: an [OrderBase], plus what the kind decides for
/// itself (the vault's switch for its fills, and the weights its basket is auctioned into).
pub trait Order {
    fn base(&self) -> &OrderBase;

    fn base_mut(&mut self) -> &mut OrderBase;

    /// Refuses a fill while the vault's switch for this kind of order is off.
    fn check_fill_enabled(vault: &MetavaultState) -> Result<()>;

    /// The target weight this order gives to the vault token `id`.
    fn target_weight(&self, id: VaultTokenId, vault_token: &VaultToken) -> Weight;
}

impl Order for DepositOrder {
    fn base(&self) -> &OrderBase {
        &self.base
    }

    fn base_mut(&mut self) -> &mut OrderBase {
        &mut self.base
    }

    fn check_fill_enabled(vault: &MetavaultState) -> Result<()> {
        require!(
            vault.deposit_order_fill_enabled(),
            KaminoVaultError::DepositOrderFillDisabled
        );
        Ok(())
    }

    /// A deposit order is auctioned into the vault's own weights, read live: an admin weight change
    /// steers the running auctions too (within each order's own loss limits and share price limit).
    fn target_weight(&self, _id: VaultTokenId, vault_token: &VaultToken) -> Weight {
        vault_token.weight()
    }
}

impl Order for WithdrawOrder {
    fn base(&self) -> &OrderBase {
        &self.base
    }

    fn base_mut(&mut self) -> &mut OrderBase {
        &mut self.base
    }

    fn check_fill_enabled(vault: &MetavaultState) -> Result<()> {
        require!(
            vault.withdraw_order_fill_enabled(),
            KaminoVaultError::WithdrawOrderFillDisabled
        );
        Ok(())
    }

    /// A withdraw order is auctioned into its owner's weights, whatever the vault targets.
    fn target_weight(&self, id: VaultTokenId, _vault_token: &VaultToken) -> Weight {
        self.weight(id)
    }
}

/// An order viewed as a [RebalanceBasket]: its locked amounts, the vault's scales, the weights it
/// targets. Balance moves update both the order's amounts and the vault's `locked_total`s.
pub struct OrderBasket<'a, O: Order> {
    pub order: &'a mut O,
    pub vault: &'a mut MetavaultState,
}

impl<O: Order> RebalanceBasket for OrderBasket<'_, O> {
    /// All the vault's enabled tokens, with the amounts this order owns of each.
    fn tokens(&self) -> BasketTokens {
        self.vault
            .enumerate_enabled_tokens()
            .map(|(id, vault_token)| BasketToken {
                id,
                mint: vault_token.mint,
                available: self.order.base().locked_amount(id),
                weight: self.order.target_weight(id, vault_token),
                scales: vault_token.dutch_auction_scales,
            })
            .collect()
    }

    /// Locks more of the token in the order (out of the vault's own amount's way).
    fn credit(&mut self, id: VaultTokenId, amount: TokenAmount) {
        self.order.base_mut().lock(id, amount);
        self.vault.get_vault_token_mut_by_id(id).lock(amount);
    }

    /// Unlocks some of the token from the order.
    fn debit(&mut self, id: VaultTokenId, amount: TokenAmount) {
        self.order.base_mut().unlock(id, amount);
        self.vault.get_vault_token_mut_by_id(id).unlock(amount);
    }

    fn rebalance(&mut self) -> &mut RebalanceState {
        &mut self.order.base_mut().rebalance
    }
}

impl<O: Order> OrderBasket<'_, O> {
    /// Starts the order's auction for `duration` (within the orders' range) under `limits`, ending
    /// it at once if the basket is already at its weights (then anyone may settle it right away).
    // (Not `start_rebalance`: an inherent method would silently shadow the trait's.)
    pub(crate) fn start_auction(
        &mut self,
        duration: Duration,
        prices: &VaultScopePrices,
        now: Timestamp,
        limits: RebalanceLimits,
    ) -> Result<()> {
        require!(
            (MIN_ORDER_AUCTION_DURATION..=MAX_ORDER_AUCTION_DURATION).contains(&duration),
            KaminoVaultError::InvalidOrderAuctionDuration
        );
        self.start_rebalance(duration, prices, now, limits);
        self.finish_rebalance_if_over(prices, now);
        Ok(())
    }

    /// Whether nothing can be filled any more (see [RebalanceState::is_over]).
    pub(crate) fn is_auction_over(&self, prices: &VaultScopePrices, now: Timestamp) -> bool {
        self.order
            .base()
            .rebalance
            .is_over(&self.tokens(), prices, now)
    }

    /// Empties the order, returning every locked amount for paying out to the owner.
    pub(crate) fn release_everything(&mut self) -> [TokenAmount; MAX_TOKENS_PER_VAULT] {
        let mut payouts = [TokenAmount::ZERO; MAX_TOKENS_PER_VAULT];
        for token in &self.tokens() {
            payouts[token.id.storage_index] = token.available;
            self.debit(token.id, token.available);
        }
        payouts
    }
}

/// One solver fill against the order (a [fill_rebalance_swap] of its basket), allowed by the
/// vault's switch for the order's kind.
pub fn fill_order<O: Order>(
    order: &mut O,
    vault: &mut MetavaultState,
    prices: &VaultScopePrices,
    request: FillRequest,
) -> Result<RebalanceFillEffects> {
    O::check_fill_enabled(vault)?;
    fill_rebalance_swap(&mut OrderBasket { order, vault }, prices, request)
}

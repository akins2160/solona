use anchor_lang::{err, error, require, require_eq, require_gt, require_gte, Result};
use itertools::izip;
use solana_program::pubkey::Pubkey;
use std::cmp::min;

use super::effects::{
    DepositEffects, RefreshVaultEffects, WithdrawEffects, WithdrawPendingFeesEffects,
};
use super::rebalance_basket::RebalanceBasket;
use super::rolling_cap;
use crate::types::{DollarValue, NetAum, RoundingMethod, SharePrice};
use crate::utils::consts::INITIAL_DEPOSIT_SIZE;
use crate::{
    kmsg_sized,
    operations::vault_operations::common::{
        compute_user_total_received_on_withdraw, get_shares_to_mint,
    },
    types::{
        FractionalShares, MinFeeSpec, Ratio, ShareAmount, Timestamp, TokenAmount, VaultTokenId,
        Weight,
    },
    utils::{
        consts::{PERF_FEE_COOLDOWN_SECONDS, YEAR},
        scope::VaultScopePrices,
    },
    GlobalConfig, KaminoVaultError, MetavaultState,
};

#[derive(Clone, Copy, Debug)]
pub struct WithdrawExchangeRateQuote {
    /// Net tokens (lamports) received for redeeming `quoted_shares`, after the withdrawal fee.
    pub net_tokens_out: TokenAmount,
    /// The redeemed share count the quote was computed against (a canonical, non-caller-controlled
    /// unit; see [`quote_withdraw_exchange_rate`]). `rate` is `net_tokens_out / quoted_shares`.
    pub quoted_shares: ShareAmount,
    /// Net withdrawable token lamports per share lamport, after the withdrawal fee.
    pub rate: Ratio<TokenAmount, ShareAmount>,
    /// Decimals of the quoted token mint, so consumers can normalize `rate` to a whole-token rate.
    pub token_mint_decimals: u8,
}

#[derive(Clone, Copy, Debug)]
struct WithdrawSimulation {
    vault_token_id: VaultTokenId,
    token_mint_decimals: u8,
    available_to_send_to_user: TokenAmount,
    withdrawal_fee: TokenAmount,
    gross_withdraw_aum: DollarValue,
    actual_withdraw_aum: DollarValue,
    shares_to_burn: ShareAmount,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum WithdrawSimulationMode {
    OnlyQuote,
    QuoteAndEnforceWithdrawBounds,
}

pub fn initialize(
    vault: &mut MetavaultState,
    vault_admin_authority: Pubkey,
    base_vault_authority: Pubkey,
    shares_mint: Pubkey,
    base_vault_authority_bump: u8,
    shares_decimals: u8,
    current_timestamp: Timestamp,
) -> Result<()> {
    crate::kmsg_sized!(100, "Initializing with shares_decimals={}", shares_decimals);

    vault.vault_admin_authority = vault_admin_authority;
    vault.base_vault_authority = base_vault_authority;
    vault.shares_mint = shares_mint;
    vault.base_vault_authority_bump = base_vault_authority_bump;
    vault.shares_mint_decimals = shares_decimals as u64;
    vault.shares_issued = 0;
    vault.creation_timestamp = u64::from(current_timestamp);

    vault.validate()
}

/// Performs the initial deposit for vault initialization.
///
/// This assumes that the vault has just been created (contains 0 shares) and does a 1:1
/// lamport-to-share mint, with no fee computation.
pub fn perform_initial_deposit(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    mint: Pubkey,
    current_timestamp: Timestamp,
) -> Result<DepositEffects> {
    let vault_token_id = vault.get_vault_token_id_by_mint(&mint)?;
    let deposit_amount = TokenAmount::new(INITIAL_DEPOSIT_SIZE);
    let shares_to_mint = ShareAmount::new(INITIAL_DEPOSIT_SIZE);

    let vault_token = vault.get_vault_token_mut_by_id(vault_token_id);
    vault_token.deposit_tokens(deposit_amount);
    vault.mint_shares(shares_to_mint);

    let new_vault_aum = vault.compute_free_aum(vault_scope_prices, RoundingMethod::Ceil);
    vault.set_prev_aum(new_vault_aum);
    vault.set_last_perf_fee_price(SharePrice::of(
        new_vault_aum,
        vault.shares_issued_amount(),
        RoundingMethod::Floor,
    ));
    vault.set_last_fee_charge(current_timestamp);
    vault.set_last_perf_fee_charge(current_timestamp);

    Ok(DepositEffects {
        shares_to_mint,
        fee_shares_to_mint: ShareAmount::ZERO,
        token_to_deposit: deposit_amount,
    })
}

#[inline(never)]
pub fn deposit(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    mint: Pubkey,
    max_user_tokens_to_deposit: TokenAmount,
    current_timestamp: Timestamp,
) -> Result<DepositEffects> {
    vault.finish_rebalance_if_over(vault_scope_prices, current_timestamp);
    let fee_shares_to_mint = charge_fees(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;
    let total_shares_issued = vault.shares_issued_amount();
    require!(
        !total_shares_issued.is_zero(),
        KaminoVaultError::VaultSharesZero
    );

    // Halt deposits when net AUM is <= 0:
    let current_net_aum = vault
        .compute_net_aum(vault_scope_prices, obligations_aum, RoundingMethod::Ceil)
        .check_positive()?;
    let (vault_token_id, token_price) =
        common::get_vault_token_and_price(vault, vault_scope_prices, &mint)?;
    // Clamp to the per-token target-weight upper bound on the gross (pre-fee) amount. The
    // clamp is strict: deposit fees remain inside the vault on both sides of the ratio — they
    // grow `token_aum` and `total_aum` by the same amount — so the post-deposit weight is
    // guaranteed to satisfy `weight <= target + max_deviation_bps`.
    let bound_max = compute_max_deposit_by_target_bound(vault, vault_scope_prices, vault_token_id)?;
    // Past that the vault is known to carry weights, so a zero one is deliberate: a token it
    // holds to sell, not to take more of.
    let weight = vault.get_vault_token_by_id(vault_token_id).weight();
    require!(!weight.is_zero(), KaminoVaultError::TokenWeightZeroed);
    if bound_max.is_zero() {
        return err!(KaminoVaultError::TargetBoundExceeded);
    }
    let max_user_tokens_to_deposit = max_user_tokens_to_deposit.min(bound_max);

    let vault_token = vault.get_vault_token_by_id(vault_token_id);

    // Use as deposit fee the max between the deposit fee lamports and the deposit fee bps
    // based on both global config and the vault state
    let fee_spec = MinFeeSpec::combine_max(
        global_config.deposit_fee_spec(),
        vault_token.deposit_fee_spec(),
    );
    let deposit_fee = fee_spec.calculate_fee_from(max_user_tokens_to_deposit);
    require_gt!(
        max_user_tokens_to_deposit,
        deposit_fee,
        KaminoVaultError::DepositAmountLessThanDepositFee
    );
    let original_max_amount = max_user_tokens_to_deposit;
    let max_user_tokens_to_deposit = max_user_tokens_to_deposit - deposit_fee;

    // Price the new shares against the AUM the vault holds *after* the fee donation, not
    // before it. The fee stays in `token_available`, so pricing against pre-fee AUM hands the
    // depositor a pro-rata claim on their own fee the instant they receive their shares — the
    // realized rate collapses to `nominal x A/(A+N)` as the deposit grows relative to the
    // vault, gutting the fee as an economic barrier to atomic (flash-loaned) manipulation.
    // With `m = N x S/(A+f)` the entrant's post-deposit stake is worth exactly `N`, so the fee
    // lands entirely on the existing holders at the configured rate, whatever the size.
    // Ceil on the fee's dollar value keeps the denominator vault-favorable.
    let pricing_aum = current_net_aum + deposit_fee.to_aum(&token_price, RoundingMethod::Ceil);

    // Compute shares to mint based on deposit AUM
    let shares_to_mint = get_shares_to_mint(
        pricing_aum,
        max_user_tokens_to_deposit,
        total_shares_issued,
        &token_price,
    );

    // Then convert those shares back to the actual number of tokens to deposit + add fee back as it's not included in conversion.
    // Ceil rounding inside `compute_amount_to_deposit_from_shares_to_mint` can add 1 lamport; clamp
    // to the user-supplied `original_max_amount` so the post-CPI check never reverts with
    // `DepositAmountGreaterThanRequestedAmount`.
    let user_tokens_to_deposit = (common::compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(shares_to_mint, total_shares_issued),
        pricing_aum,
        &token_price,
    ) + deposit_fee)
        .min(original_max_amount);
    require_gte!(
        user_tokens_to_deposit,
        vault_token.min_deposit(),
        KaminoVaultError::DepositAmountBelowMinimum
    );
    // Compute deposit AUM based on the full deposit (fee is donated to vault)
    let deposit_token_aum = user_tokens_to_deposit.to_aum(&token_price, RoundingMethod::Floor);
    require!(
        !shares_to_mint.is_zero() && !deposit_token_aum.is_zero(),
        KaminoVaultError::DepositAmountsZero
    );

    crate::kmsg_sized!(
        200,
        "User tokens to deposit {} (fee {}) and shares to mint {}",
        user_tokens_to_deposit,
        deposit_fee,
        shares_to_mint
    );

    // Cap enforcement (rolling rate-limit then hard AUM ceiling).
    //
    // We re-compute the deposit USD value with Ceil rounding — the existing `deposit_token_aum`
    // (Floor) feeds the share-minting math and stays untouched. Ceil here is vault-favorable: it
    // over-estimates user flow, making the caps tighter rather than looser.
    let deposit_aum_for_caps = user_tokens_to_deposit.to_aum(&token_price, RoundingMethod::Ceil);
    // Rolling cap first — cheap to evaluate and surfaces transient (rate-limit) rejection
    // before structural (cap-full) rejection.
    rolling_cap::accumulate_deposit(
        &mut vault.rolling_deposit_cap,
        deposit_aum_for_caps,
        current_timestamp,
    )?;
    if vault.is_deposit_cap_enabled() {
        // saturating_add ensures the check is conservative even at the u128 extreme — a saturated
        // value compares strictly greater than any finite cap.
        let post_deposit_net_aum = current_net_aum.saturating_add(deposit_aum_for_caps);
        require_gte!(
            vault.deposit_cap(),
            post_deposit_net_aum,
            KaminoVaultError::DepositAumCapExceeded
        );
    }

    // EFFECTS: These are always the last things to update, their order matters for fee tracking
    //          Fee is donated to vault (stays in token_available)
    let vault_token = vault.get_vault_token_mut_by_id(vault_token_id);
    vault_token.deposit_tokens(user_tokens_to_deposit);
    vault.mint_shares(shares_to_mint);

    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    );

    Ok(DepositEffects {
        shares_to_mint,
        fee_shares_to_mint,
        token_to_deposit: user_tokens_to_deposit,
    })
}

fn simulate_withdraw(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    current_net_aum: DollarValue,
    global_config: &GlobalConfig,
    mint: Pubkey,
    number_of_shares: ShareAmount,
    mode: WithdrawSimulationMode,
) -> Result<WithdrawSimulation> {
    let total_shares_issued = vault.shares_issued_amount();
    require!(
        !number_of_shares.is_zero(),
        KaminoVaultError::CannotWithdrawZeroShares
    );
    require!(
        !total_shares_issued.is_zero(),
        KaminoVaultError::VaultSharesZero
    );

    let (vault_token_id, token_price) =
        common::get_vault_token_and_price(vault, vault_scope_prices, &mint)?;
    let vault_token = vault.get_vault_token_by_id(vault_token_id);

    let total_for_user = compute_user_total_received_on_withdraw(
        current_net_aum,
        Ratio::of(number_of_shares, total_shares_issued),
        &token_price,
    );

    let gross_tokens_to_redeem = match mode {
        WithdrawSimulationMode::OnlyQuote => total_for_user,
        WithdrawSimulationMode::QuoteAndEnforceWithdrawBounds => {
            require!(
                !total_for_user.is_zero(),
                KaminoVaultError::CannotWithdrawZeroLamports
            );

            let bound_max =
                compute_max_withdraw_by_target_bound(vault, vault_scope_prices, vault_token_id)?;
            if bound_max.is_zero() {
                return err!(KaminoVaultError::TargetBoundExceeded);
            }
            vault_token.available().min(total_for_user).min(bound_max)
        }
    };

    let fee_spec = MinFeeSpec::combine_max(
        global_config.withdrawal_fee_spec(),
        vault_token.withdrawal_fee_spec(),
    );
    let withdrawal_fee = fee_spec.calculate_fee_from(gross_tokens_to_redeem);
    require_gt!(
        gross_tokens_to_redeem,
        withdrawal_fee,
        KaminoVaultError::WithdrawAmountLessThanWithdrawalFee
    );
    let available_to_send_to_user = gross_tokens_to_redeem - withdrawal_fee;

    // Fee is donated to the vault (stays in token_available), so the user gives up claim on the
    // gross redeemed amount while only the net amount leaves the vault.
    let gross_withdraw_aum = gross_tokens_to_redeem.to_aum(&token_price, RoundingMethod::Ceil);
    let actual_withdraw_aum = available_to_send_to_user.to_aum(&token_price, RoundingMethod::Ceil);

    // Burn shares against the gross redeemed AUM so the withdrawing user does not retain
    // ownership of the fee that was donated to the remaining shareholders.
    let theoretical_shares_to_burn = common::calculate_shares_to_burn(
        Ratio::of(gross_withdraw_aum, current_net_aum),
        total_shares_issued,
    );
    let shares_to_burn = min(theoretical_shares_to_burn, number_of_shares);

    Ok(WithdrawSimulation {
        vault_token_id,
        token_mint_decimals: token_price.decimals(),
        available_to_send_to_user,
        withdrawal_fee,
        gross_withdraw_aum,
        actual_withdraw_aum,
        shares_to_burn,
    })
}

#[inline(never)]
pub fn withdraw(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    mint: Pubkey,
    current_timestamp: Timestamp,
    number_of_shares: ShareAmount,
) -> Result<WithdrawEffects> {
    vault.finish_rebalance_if_over(vault_scope_prices, current_timestamp);
    require!(
        !number_of_shares.is_zero(),
        KaminoVaultError::CannotWithdrawZeroShares
    );
    let fee_shares_to_mint = charge_fees(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;

    // Halt withdrawals when the vault AUM is <= 0:
    let current_net_aum = vault
        .compute_net_aum(vault_scope_prices, obligations_aum, RoundingMethod::Floor)
        .check_positive()?;

    let total_shares_issued = vault.shares_issued_amount();
    require!(
        !total_shares_issued.is_zero(),
        KaminoVaultError::VaultSharesZero
    );
    require_gte!(
        total_shares_issued,
        number_of_shares,
        KaminoVaultError::WithdrawSharesExceedIssued
    );

    let simulation = simulate_withdraw(
        vault,
        vault_scope_prices,
        current_net_aum,
        global_config,
        mint,
        number_of_shares,
        WithdrawSimulationMode::QuoteAndEnforceWithdrawBounds,
    )?;

    let vault_token = vault.get_vault_token_by_id(simulation.vault_token_id);

    require!(
        simulation.gross_withdraw_aum <= current_net_aum,
        KaminoVaultError::WithdrawAumExceedTotal
    );
    require!(
        !simulation.shares_to_burn.is_zero() && !simulation.actual_withdraw_aum.is_zero(),
        KaminoVaultError::WithdrawResultsInZeroShares
    );
    require!(
        simulation.available_to_send_to_user >= vault_token.min_withdraw(),
        KaminoVaultError::WithdrawAmountBelowMinimum
    );

    // Rolling withdraw cap: compute pre-fee gross USD with Ceil (vault-favorable) and accumulate
    // into the withdraw-direction limiter. Disabled when interval_seconds == 0. Placed after all
    // immutable uses of `vault_token` to avoid a borrow conflict with `&mut vault.rolling_*`.
    rolling_cap::accumulate_withdraw(
        &mut vault.rolling_withdraw_cap,
        simulation.gross_withdraw_aum,
        current_timestamp,
    )?;

    crate::kmsg_sized!(
        200,
        "Available to send to user {} (fee {}) and shares to burn {}",
        simulation.available_to_send_to_user,
        simulation.withdrawal_fee,
        simulation.shares_to_burn
    );

    let vault_token = vault.get_vault_token_mut_by_id(simulation.vault_token_id);
    vault_token.withdraw_tokens(simulation.available_to_send_to_user);
    vault.burn_shares(simulation.shares_to_burn);

    // EFFECTS: Fee stays in vault (donated), only withdraw the net amount user receives
    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    );

    Ok(WithdrawEffects {
        shares_to_burn: simulation.shares_to_burn,
        available_to_send_to_user: simulation.available_to_send_to_user,
        fee_shares_to_mint,
    })
}

/// Quote the net withdraw exchange rate for `mint` at the current Scope prices and obligation
/// values: net withdrawable token lamports per share lamport, after the withdrawal fee.
///
/// The rate is computed against a *canonical*, non-caller-controlled redemption of one whole share
/// (`10^shares_mint_decimals`), clamped to the issued supply. A fixed unit keeps the implied share
/// ratio `<= 1`, giving the token-amount conversion the same overflow profile as a full
/// [`withdraw`] — there is no caller-supplied amount that could force an out-of-range conversion.
///
/// The quote reflects vault state as of the last refresh: unlike [`withdraw`] it does NOT accrue
/// pending management/performance fees, and (being read-only) it ignores per-token target-weight
/// bounds and available liquidity. Treat the returned rate as an upper bound on what a real
/// `withdraw` would realize, not a settlement price.
#[inline(never)]
pub fn quote_withdraw_exchange_rate(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    mint: Pubkey,
) -> Result<WithdrawExchangeRateQuote> {
    let current_net_aum = vault
        .compute_net_aum(vault_scope_prices, obligations_aum, RoundingMethod::Floor)
        .check_positive()?;

    let total_shares_issued = vault.shares_issued_amount();
    let quoted_shares = total_shares_issued.min(vault.one_whole_share());

    let simulation = simulate_withdraw(
        vault,
        vault_scope_prices,
        current_net_aum,
        global_config,
        mint,
        quoted_shares,
        WithdrawSimulationMode::OnlyQuote,
    )?;

    Ok(WithdrawExchangeRateQuote {
        net_tokens_out: simulation.available_to_send_to_user,
        quoted_shares,
        rate: Ratio::of(simulation.available_to_send_to_user, quoted_shares),
        token_mint_decimals: simulation.token_mint_decimals,
    })
}

#[inline(never)]
pub fn withdraw_pending_fees(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    current_timestamp: Timestamp,
) -> Result<WithdrawPendingFeesEffects> {
    charge_fees(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;

    let pending = vault.pending_fees();
    let total_fees = pending.floor_shares();

    // Withdraw maximum possible from the available
    let available_to_send_to_user = vault.shares_issued_amount().min(total_fees);

    // Accounting
    vault.set_pending_fees(pending.sub_shares(available_to_send_to_user));

    Ok(WithdrawPendingFeesEffects {
        available_to_send_to_user,
    })
}

#[inline(never)]
pub fn give_up_pending_fee(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    current_timestamp: Timestamp,
    max_amount_to_give_up: ShareAmount,
) -> Result<()> {
    require!(
        !max_amount_to_give_up.is_zero(),
        KaminoVaultError::CannotGiveUpZeroFees
    );
    require!(
        vault.block_deposits != 0,
        KaminoVaultError::VaultDepositsNotBlocked
    );
    charge_fees(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;
    let pending = vault.pending_fees();
    let pending_floor = pending.floor_shares();
    let amount_to_give_up = max_amount_to_give_up.min(pending_floor);
    crate::kmsg_sized!(
        150,
        "Giving up {} of {} pending fees",
        amount_to_give_up,
        pending_floor
    );

    let shares_before_burn = vault.shares_issued_amount();
    vault.set_pending_fees(pending.sub_shares(amount_to_give_up));
    vault.burn_shares(amount_to_give_up);

    if !amount_to_give_up.is_zero() {
        // Burning fee shares raises the share price without adding capital. Scale the
        // checkpoint so its aggregate value `price x shares` is conserved across the burn:
        // the waiver is then not re-charged as performance at the next boundary, while any
        // genuine in-window gain keeps its exact fee base. Ceil both steps so the aggregate
        // never shrinks — the give-up itself can never create phantom performance, at the
        // cost of under-charging at most quantization dust later.
        let checkpoint_value = vault
            .last_perf_fee_price()
            .value_of(shares_before_burn, RoundingMethod::Ceil);
        let shares_after_burn = vault.shares_issued_amount();
        let scaled_price = if shares_after_burn.is_zero() {
            SharePrice::ZERO
        } else {
            SharePrice::of(checkpoint_value, shares_after_burn, RoundingMethod::Ceil)
        };
        vault.set_last_perf_fee_price(scaled_price);
    }

    Ok(())
}

#[inline(never)]
pub fn refresh_vault(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    current_timestamp: Timestamp,
) -> Result<RefreshVaultEffects> {
    let fee_shares_to_mint = charge_fees(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;

    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        obligations_aum,
        current_timestamp,
    );

    Ok(RefreshVaultEffects { fee_shares_to_mint })
}

pub fn charge_fees(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    timestamp: Timestamp,
) -> Result<ShareAmount> {
    if vault.last_fee_charge_timestamp == 0 {
        // First call never charges fees because we need an accurate timestamp
        vault.set_last_fee_charge(timestamp);
        vault.set_last_perf_fee_charge(timestamp);
        return Ok(ShareAmount::ZERO);
    }

    let new_net_aum =
        vault.compute_net_aum(vault_scope_prices, obligations_aum, RoundingMethod::Ceil);
    let Some(new_aum) = new_net_aum.try_non_negative() else {
        // Negative AUM: skip mgmt + perf accrual and preserve `prev_aum` and the price
        // checkpoint at their pre-loss values. Bumping both timestamps anchors the next
        // post-recovery charge to now; perf fee still yields zero on rebound until the share
        // price passes the preserved checkpoint.
        vault.last_fee_charge_timestamp = u64::from(timestamp);
        vault.last_perf_fee_charge_timestamp = u64::from(timestamp);
        return Ok(ShareAmount::ZERO);
    };

    let time_since_last_fee_charge = timestamp - vault.last_fee_charge();
    let prev_aum = vault.prev_aum();

    let total_shares_issued = vault.shares_issued_amount();
    // Seed the price checkpoint on the first touch of a vault predating it: the
    // first performance window starts here.
    if vault.last_perf_fee_price().is_zero() && !total_shares_issued.is_zero() && !new_aum.is_zero()
    {
        vault.set_last_perf_fee_price(SharePrice::of(
            new_aum,
            total_shares_issued,
            RoundingMethod::Floor,
        ));
    }
    // Floor is fee-favorable here, matching the Ceil on `new_aum`.
    let perf_checkpoint_value = vault
        .last_perf_fee_price()
        .value_of(total_shares_issued, RoundingMethod::Floor);
    let perf_earned_interest = new_aum.saturating_sub(perf_checkpoint_value);

    crate::kmsg_sized!(
        350,
        "prev_aum {} perf_ckpt_value {} new_aum {} shares issued {} time_since_last_fee_charge {}",
        prev_aum,
        perf_checkpoint_value,
        new_aum,
        vault.shares_issued,
        time_since_last_fee_charge
    );

    // Management fee is applied to the total AUM, no matter the profit/loss, based on an yearly fee
    // To charge from all of the tokens we mint more shares based on how much % we want to take
    let total_shares_issued_f = total_shares_issued.as_fractional();
    let mgmt_charge = common::get_shares_to_charge_for_vault_fee(
        vault.management_fee_rate(),
        Ratio::of(time_since_last_fee_charge, YEAR),
        total_shares_issued_f,
    );
    crate::kmsg_sized!(100, "mgmt_charge_f {}", mgmt_charge);

    // Performance fee is applied to the interest earned; if there was a loss we don't charge any performance fee
    // If there was a profit, charge a proportional amount of shares based on it relative to the new AUM
    // Performance fee has a cooldown - only charge if enough time has passed since last performance fee charge
    //
    // We also update shares issued to include the previous charge, example below why that is the case
    // prev_aum = 0
    // new_aum = 100
    // shares_issued = 100
    // f_m = 50% (management fee)
    // mint 100 shares as mgmt_charge
    //
    // f_p = 10% -> (no mgmt fee) charge 11..... shares -> admin has 111/211
    //           -> charge 22..... shares               -> admin has 122/222

    // f_p = 50% -> (no mgmt fee) charge 100 shares -> admin has 200/300
    //           -> charge 200 shares               -> admin has 300/400

    let time_since_last_perf_fee = timestamp - vault.last_perf_fee_charge();
    // Performance fee can be charged only after cooldown elapses so we don't charge on every up/down movement.
    // NOTE: a user could theoretically deposit/withdraw within the cooldown period so they don't get charged perf fee.
    let charge_perf_now = time_since_last_perf_fee >= PERF_FEE_COOLDOWN_SECONDS
        && !new_aum.is_zero()
        && !total_shares_issued.is_zero();
    let perf_charge = if charge_perf_now {
        let charge = common::get_shares_to_charge_for_vault_fee(
            vault.performance_fee_rate(),
            Ratio::of(perf_earned_interest, new_aum),
            total_shares_issued_f + mgmt_charge,
        );
        vault.set_last_perf_fee_charge(timestamp);
        charge
    } else {
        FractionalShares::ZERO
    };
    crate::kmsg_sized!(100, "perf_charge {}", perf_charge);

    // Accounting cumulative fees (use the Fraction values for accurate accumulation)
    vault.set_cumulative_mgmt_fees(vault.cumulative_mgmt_fees() + mgmt_charge);
    vault.set_cumulative_perf_fees(vault.cumulative_perf_fees() + perf_charge);

    // Accounting shares and AUM
    let pending = vault.pending_fees();
    let new_charge = mgmt_charge + perf_charge;
    let new_fees = (new_charge + pending.fractional_part()).floor_shares();
    // Everything taken as management/performance fees are actually more shares minted
    vault.mint_shares(new_fees);

    let shares_after_mint = vault.shares_issued_amount();
    if charge_perf_now && new_aum >= perf_checkpoint_value {
        // New high-water mark: the window closes at `new_aum`. Checkpoint the POST-mint price so
        // the fee dilution just charged is not counted as next window's loss.
        vault.set_last_perf_fee_price(SharePrice::of(
            new_aum,
            shares_after_mint,
            RoundingMethod::Floor,
        ));
    } else if shares_after_mint != total_shares_issued && !shares_after_mint.is_zero() {
        // Either a drawdown observed at a cooldown boundary, or a mid-window management-fee
        // mint. Both change the share count without changing the *value* the fee is measured
        // against, so carry the existing checkpoint value across the supply change rather than
        // letting the stored per-share price re-anchor against it:
        //  - the high-water mark survives the drawdown, so recovering back to it is not charged
        //    a second time on interest that already paid a performance fee;
        //  - fee shares, which were minted for free rather than purchased, do not get the old
        //    per-share basis and so cannot inflate the fee base.
        // Ceil so the carried value never shrinks: at worst this under-charges quantization dust.
        vault.set_last_perf_fee_price(SharePrice::of(
            perf_checkpoint_value,
            shares_after_mint,
            RoundingMethod::Ceil,
        ));
    }

    vault.set_pending_fees(pending + new_charge);
    vault.set_prev_aum(new_aum);
    vault.set_last_fee_charge(timestamp);

    Ok(new_fees)
}

/// Raises the performance-fee price checkpoint to the current share price, never lowering it.
/// Call right after [`charge_fees`] on a performance-fee-*rate* update, so the new rate sees
/// only post-change performance. In-window gain accrued under the old rate is forgiven: the
/// cooldown blocks charging it, and charging on demand instead would let a config toggle
/// bypass the cooldown.
///
/// Raise-only is what keeps the checkpoint a high-water mark: lowering it toward a depressed
/// price would re-arm the fee on a recovery that has already been charged once. A negative net
/// AUM has no share price at all, so the checkpoint is left untouched.
pub fn raise_perf_fee_checkpoint(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
) {
    let Some(price) = current_share_price(vault, vault_scope_prices, obligations_aum) else {
        return;
    };
    if price > vault.last_perf_fee_price() {
        vault.set_last_perf_fee_price(price);
    }
}

/// Re-anchors the performance-fee price checkpoint to the current share price, in either
/// direction. Call right after [`update_prev_aum_if_not_negative`] on a Scope feed change: that
/// is a change of *valuation basis*, not vault performance, so the checkpoint has to follow it
/// down as well as up — a checkpoint left above the new basis would never be reachable again.
///
/// A negative net AUM has no share price at all, so the checkpoint is left untouched (its
/// pre-loss value is what keeps the recovery from the loss unchargeable).
pub fn reanchor_perf_fee_checkpoint(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
) {
    let Some(price) = current_share_price(vault, vault_scope_prices, obligations_aum) else {
        return;
    };
    vault.set_last_perf_fee_price(price);
}

/// The current share price, or `None` when it is undefined — a negative net AUM or no supply.
fn current_share_price(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
) -> Option<SharePrice> {
    let shares_issued = vault.shares_issued_amount();
    if shares_issued.is_zero() {
        return None;
    }
    let net_aum = vault
        .compute_net_aum(vault_scope_prices, obligations_aum, RoundingMethod::Ceil)
        .try_non_negative()?;
    Some(SharePrice::of(
        net_aum,
        shares_issued,
        RoundingMethod::Floor,
    ))
}

/// Snapshots the current net AUM into [MetavaultState::prev_aum] for fee accounting, but only
/// when it is non-negative — preserving the last healthy value so a later recovery (e.g. via
/// klend's `socialize_loss`) is not mistaken for genuine vault yield.
pub fn update_prev_aum_if_not_negative(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
) {
    if let Some(new_aum) = vault
        .compute_net_aum(vault_scope_prices, obligations_aum, RoundingMethod::Ceil)
        .try_non_negative()
    {
        vault.set_prev_aum(new_aum);
    }
}

/// Ends a potential rebalance operation (if outside the window or already balanced) and updates the
/// `prev_aum`.
///
/// This is supposed to be called after every operation that affects vault balances.
pub fn finish_rebalance_and_rebaseline_aum(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    current_timestamp: Timestamp,
) {
    vault.finish_rebalance_if_over(vault_scope_prices, current_timestamp);
    rebaseline_aum(vault, vault_scope_prices, obligations_aum);
}

/// Sets the AUM the next fee accrual measures against, at the current balances and prices.
pub fn rebaseline_aum(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
) {
    let free_aum = vault.compute_free_aum(vault_scope_prices, RoundingMethod::Ceil);
    if let Some(new_aum) = (free_aum + obligations_aum).try_non_negative() {
        vault.set_prev_aum(new_aum);
    }
}

/// Computes the maximum token amount a user can deposit into `vault_token_id` without pushing the
/// resulting token weight above `target + max_deviation_bps`.
///
/// Returns [`TokenAmount::MAX`] when the bound is disabled — either because
/// `max_deviation_bps == 0` or `target + deviation >= 1`. Returns [`TokenAmount::ZERO`] when the
/// token weight is already at or above the upper bound, or when the vault weights some tokens but
/// none of this one; in either case the caller must surface
/// [`KaminoVaultError::TargetBoundExceeded`] if the user requested a non-zero deposit. A vault
/// carrying no weights at all has no targets to bound against and is refused outright.
///
/// The `1 / (1 - upper)` amplification means the dollar bound can convert to more raw lamports
/// than a `u64` holds — a cheap, high-decimal token in a large vault, or a token whose price
/// collapsed after listing. That bound is vacuous (no `u64` deposit can reach it), so it
/// saturates to [`TokenAmount::MAX`] rather than panicking and bricking every deposit of that
/// token regardless of size.
///
/// Rounding is deliberately conservative: [`RoundingMethod::Ceil`] on the per-token AUM and
/// [`RoundingMethod::Floor`] on the total AUM so the computed bound can never over-allow.
pub fn compute_max_deposit_by_target_bound(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    vault_token_id: VaultTokenId,
) -> Result<TokenAmount> {
    let vault_token = vault.get_vault_token_by_id(vault_token_id);
    let sum_weights = vault.tokens().total_weight();
    require!(!sum_weights.is_zero(), KaminoVaultError::InvalidWeightsSum);
    if vault_token.weight().is_zero() {
        return Ok(TokenAmount::ZERO); // zeroed weight means "this vault wants none of it"
    }
    let Some(deviation) = vault_token.max_deviation() else {
        return Ok(TokenAmount::MAX); // no deviation rule means no ceiling to clamp a deposit to
    };

    let target = Ratio::of(vault_token.weight(), sum_weights);
    let upper_ratio = target + deviation;
    if upper_ratio >= Ratio::one() {
        return Ok(TokenAmount::MAX);
    }

    let token_price = vault_scope_prices.by_id(vault_token_id);
    let token_aum = vault_token.compute_aum(token_price, RoundingMethod::Ceil);
    let total_aum = vault.compute_free_aum(vault_scope_prices, RoundingMethod::Floor);

    let upper_bound_aum = total_aum.apply_ratio(upper_ratio, RoundingMethod::Floor);
    let excess_aum = upper_bound_aum.saturating_sub(token_aum);
    let Some(reverse_upper_ratio) = upper_ratio.reverse() else {
        // Guarded above, but keep the fallback aligned with the documented semantics.
        return Ok(TokenAmount::MAX);
    };
    // max_aum_to_deposit = excess / (1 - upper) = excess * (1 + upper/(1-upper)) = excess + excess*reverse(upper).
    let max_aum_to_deposit =
        excess_aum + excess_aum.apply_ratio(reverse_upper_ratio, RoundingMethod::Floor);
    Ok(max_aum_to_deposit.to_tokens_clamp_saturating(token_price))
}

/// Computes the maximum token amount a user can withdraw from `vault_token_id` without pushing the
/// resulting token weight below `target - max_deviation_bps`.
///
/// Returns [`TokenAmount::MAX`] when the bound is disabled. Returns [`TokenAmount::ZERO`] when the
/// token weight is already at or below the lower bound. A vault carrying no weights at all has no
/// targets to bound against and is refused outright.
///
/// Rounding is conservative in the opposite direction: [`RoundingMethod::Floor`] on the per-token
/// AUM, [`RoundingMethod::Ceil`] on the total AUM, and [`RoundingMethod::Ceil`] on `lower_bound_aum`
/// so the bound strictly under-approximates allowed withdrawals.
pub fn compute_max_withdraw_by_target_bound(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    vault_token_id: VaultTokenId,
) -> Result<TokenAmount> {
    let vault_token = vault.get_vault_token_by_id(vault_token_id);
    let sum_weights = vault.tokens().total_weight();
    require!(!sum_weights.is_zero(), KaminoVaultError::InvalidWeightsSum);

    let Some(deviation) = vault_token.max_deviation() else {
        return Ok(TokenAmount::MAX); // no deviation rule means no floor to clamp a withdraw to
    };

    let target = Ratio::of(vault_token.weight(), sum_weights);
    if target <= deviation {
        return Ok(TokenAmount::MAX); // the lower bound is non-positive and imposes no constraint
    }
    let lower_ratio = target - deviation;

    let token_price = vault_scope_prices.by_id(vault_token_id);
    let token_aum = vault_token.compute_aum(token_price, RoundingMethod::Floor);
    let total_aum = vault.compute_free_aum(vault_scope_prices, RoundingMethod::Ceil);

    // Ceil so `lower_bound_aum` over-approximates the true value; combined with `token_aum`
    // Floor this makes `excess_aum` a strict under-approximation of the true numerator, so the
    // computed bound never over-allows a withdrawal past `target - max_deviation_bps`.
    let lower_bound_aum = total_aum.apply_ratio(lower_ratio, RoundingMethod::Ceil);
    let excess_aum = token_aum.saturating_sub(lower_bound_aum);
    let Some(reverse_lower_ratio) = lower_ratio.reverse() else {
        // `lower < 1` is guaranteed here (target <= 1 and deviation > 0), so reverse() is defined.
        return Ok(TokenAmount::MAX);
    };
    let max_aum_to_withdraw =
        excess_aum + excess_aum.apply_ratio(reverse_lower_ratio, RoundingMethod::Floor);
    // Unlike the deposit bound, this conversion cannot exceed `u64`: `total_aum >= token_aum`
    // (free AUM sums every enabled token), so `excess_aum <= (1 - lower) * token_aum` and the
    // `1 / (1 - lower)` amplification brings it back to at most `token_aum` — an amount the
    // token account already holds.
    Ok(max_aum_to_withdraw.to_tokens(token_price, RoundingMethod::Floor))
}

#[inline(never)]
pub fn update_token_weights(
    vault: &mut MetavaultState,
    weights: Vec<Weight>,
    current_timestamp: Timestamp,
) -> Result<()> {
    // Like every other configuration change, refused only while a rebalance can still be
    // filled. The guard is on the clock, so a rebalance whose window has elapsed does not block
    // a weight change even if nobody has closed it yet.
    require!(
        !vault.rebalance.is_within(current_timestamp),
        KaminoVaultError::CannotUpdateWeightsDuringRebalance
    );
    require_eq!(
        weights.len(),
        vault.get_tokens_count(),
        KaminoVaultError::TokenArrayLengthMismatch
    );

    let total_weight: Weight = weights.iter().copied().sum();
    require!(!total_weight.is_zero(), KaminoVaultError::InvalidWeightsSum);

    for (weight, vault_token) in izip!(weights, vault.iter_mut_enabled_tokens()) {
        vault_token.weight = u64::from(weight);

        kmsg_sized!(
            200,
            "Updated token {} weight to {} (ratio {})",
            vault_token.mint,
            vault_token.weight,
            Ratio::of(weight, total_weight)
        );
    }

    Ok(())
}

pub mod common {
    use super::*;
    use crate::types::ratio::RatioSide;
    use crate::{
        types::{
            DollarValue, Ratio, RoundingMethod, ShareAmount, TokenAmount, TokenPrice, VaultTokenId,
        },
        utils::consts::MAX_CHARGED_RATE_FOR_VAULT_FEE,
    };
    use anchor_lang::Result;

    pub fn get_vault_token_and_price(
        vault: &MetavaultState,
        vault_scope_prices: &VaultScopePrices,
        mint: &Pubkey,
    ) -> Result<(VaultTokenId, TokenPrice)> {
        let id = vault.get_vault_token_id_by_mint(mint)?;
        let token_price = vault_scope_prices.by_id(id).clone();
        Ok((id, token_price))
    }

    // Shares to mint are based on deposited AUM and total vault AUM
    //
    // Example:
    // deposited_AUM = 5$, total_AUM = 10$ and we have 100 shares
    // shares_to_mint = 50 -> user will own 1/3 of the 15$ AUM
    pub fn get_shares_to_mint(
        holdings_aum: DollarValue,
        max_user_tokens_to_deposit: TokenAmount,
        total_shares_issued: ShareAmount,
        token_price: &TokenPrice,
    ) -> ShareAmount {
        // Calculate AUM based on intended tokens to deposit
        let max_deposited_token_aum =
            max_user_tokens_to_deposit.to_aum(token_price, RoundingMethod::Floor); // Note: deliberately under-estimating the AUM (meaning: user gets less shares)
        get_shares_to_mint_from_aum(
            Ratio::of(max_deposited_token_aum, holdings_aum),
            total_shares_issued,
        )
    }

    // Calculates the number of shares to mint based on the deposit-to-holdings AUM ratio.
    //
    // The share calculation is proportional to the existing shares and vault AUM ratio.
    // Uses floor rounding so the protocol never over-issues shares.
    //
    // Example:
    // Vault has $1000 AUM, 100 shares issued, user deposits $200 AUM
    // Returns 20 shares (200/1000 * 100 = 20)
    pub fn get_shares_to_mint_from_aum(
        deposited_aum_ratio: Ratio<DollarValue>,
        total_shares_issued: ShareAmount,
    ) -> ShareAmount {
        total_shares_issued.apply_ratio(deposited_aum_ratio, RoundingMethod::Floor)
    }

    // When charging management/performance fee we issue more shares such that admin will own a bit of each token in vault
    // How much we issue depends on fee_bps, numerator and denominator - which represent percentage of fee_bps to apply,
    // and also total_shares_issued
    // Management fee uses time passed in a year as percentage of fee_bps
    // And performance fee uses accrued interest / total AUM
    //
    // Formula:
    // F = fee_bps * fee_ratio_numerator / fee_ratio_denominator
    // SI = shares_issued
    // NS = new_shares
    // NS = (SI * F) / (1 - F)
    //
    // Example:
    // SI = 10
    // F = 50%
    // ----------------
    // Need to issue 10 new shares such that admin represents 50% of vault
    // Total: 20 shares issued && NS = 10 fee

    // We again charge a fee from the above value
    // F = 50%
    // ------------------------------------------
    // Total: 40 shares issued && NS = 20 fee -> 30 fee in total (admin has 75% of vault)
    pub fn get_shares_to_charge_for_vault_fee<N: RatioSide>(
        fee_rate: Ratio<u64>,
        proportion: Ratio<N>,
        shares_issued: FractionalShares,
    ) -> FractionalShares {
        let proportional_fee_rate = proportion * fee_rate;
        let clamped_fee_rate = proportional_fee_rate.limit_at_most(MAX_CHARGED_RATE_FOR_VAULT_FEE);
        let Some(reverse_fee_rate) = clamped_fee_rate.reverse() else {
            panic!(
                "we just clamped {} to const {} that is supposed to be <1",
                proportional_fee_rate, MAX_CHARGED_RATE_FOR_VAULT_FEE
            );
        };
        shares_issued.apply_ratio(reverse_fee_rate, RoundingMethod::Ceil)
    }

    // Calculates the AUM that a user should receive when withdrawing shares.
    //
    // Applies the withdrawn shares ratio to the total vault AUM to get the user's
    // proportional share. Uses floor rounding so the protocol never over-pays.
    //
    // Example:
    // Vault has $1000 AUM total, user's ratio is 25/100
    // Returns DollarValue representing $250 AUM for user (25% of vault)
    pub fn compute_aum_total_received_on_withdraw(
        vault_total_holdings: DollarValue,
        withdrawn_shares_ratio: Ratio<ShareAmount>,
    ) -> DollarValue {
        let total_aum_for_user =
            vault_total_holdings.apply_ratio(withdrawn_shares_ratio, RoundingMethod::Floor);
        kmsg_sized!(
            150,
            "Total AUM for user {} Total AUM in vault {}",
            total_aum_for_user,
            vault_total_holdings
        );

        total_aum_for_user
    }

    pub fn compute_user_total_received_on_withdraw(
        vault_total_holdings: DollarValue,
        withdrawn_shares_ratio: Ratio<ShareAmount>,
        token_price: &TokenPrice,
    ) -> TokenAmount {
        let aum =
            compute_aum_total_received_on_withdraw(vault_total_holdings, withdrawn_shares_ratio);
        // Apply floor() such that users that withdraw too few shares don't receive any lamports.
        // Saturating: a claim worth more raw lamports than a `u64` holds is one no token account
        // could ever pay out, and the caller clamps to `vault_token.available()` immediately
        // after. Converting unsaturated would instead panic — bricking withdrawals of a cheap,
        // high-decimal token for exactly the holders with the largest claims.
        aum.to_tokens_clamp_saturating(token_price)
    }

    // Calculates the AUM value required to mint a specific number of shares.
    //
    // This function performs the inverse calculation of share minting - given a desired
    // number of shares to mint, it determines what AUM value those shares represent.
    // Uses ceiling rounding to ensure the user pays at least the full AUM value.
    //
    // Example:
    // Vault has $1000 AUM total, 100 shares, user wants to mint 10 shares
    // Returns ~DollarValue of $100 AUM required
    pub fn compute_aum_to_deposit_from_shares_to_mint(
        minted_shares_ratio: Ratio<ShareAmount>,
        vault_total_holdings: DollarValue,
    ) -> DollarValue {
        vault_total_holdings.apply_ratio(minted_shares_ratio, RoundingMethod::Ceil)
    }

    pub fn compute_amount_to_deposit_from_shares_to_mint(
        minted_shares_ratio: Ratio<ShareAmount>,
        vault_total_holdings: DollarValue,
        token_price: &TokenPrice,
    ) -> TokenAmount {
        let aum =
            compute_aum_to_deposit_from_shares_to_mint(minted_shares_ratio, vault_total_holdings);
        // Apply ceil() to make sure user pays at least 1 lamport more
        aum.to_tokens(token_price, RoundingMethod::Ceil)
    }

    // Calculates the number of shares to burn for a given AUM withdrawal amount.
    //
    // This function determines how many shares must be burned to withdraw a specific
    // AUM value from the vault. It uses ceiling rounding to ensure users pay for
    // the full cost of their withdrawal, preventing the vault from being drained.
    //
    // Example:
    // User withdraws $250 AUM worth, vault has $1000 total AUM, 100 shares total
    // Returns 25 shares (250/1000 * 100 = 25)
    pub fn calculate_shares_to_burn(
        withdrawn_aum_ratio: Ratio<DollarValue>,
        total_shares_supply: ShareAmount,
    ) -> ShareAmount {
        total_shares_supply.apply_ratio(withdrawn_aum_ratio, RoundingMethod::Ceil)
        // Note: deliberately over-estimating the burnt shares (meaning: user loses due to rounding, not the protocol)
    }
}

pub mod string_utils {
    pub fn slice_to_array_padded(slice: &[u8]) -> [u8; 40] {
        let mut array = [0u8; 40];
        let len = slice.len().min(40);
        array[..len].copy_from_slice(&slice[..len]);
        array
    }
}

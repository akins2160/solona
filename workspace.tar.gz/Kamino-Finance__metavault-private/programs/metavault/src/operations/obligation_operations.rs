use crate::{
    operations::{
        effects::{
            BorrowObligationLiquidityEffects, DepositObligationCollateralEffects,
            RepayObligationLiquidityEffects, WithdrawObligationCollateralEffects,
        },
        rebalance_basket::RebalanceBasket,
        vault_checks::find_enabled_token_and_price,
        vault_operations::{charge_fees, finish_rebalance_and_rebaseline_aum},
    },
    types::{
        amounts::AllAvailableOr, DollarValue, FractionalTokenAmount, NetAum, RoundingMethod,
        Timestamp, TokenAmount,
    },
    utils::scope::VaultScopePrices,
    KaminoVaultError, MetavaultState,
};
use anchor_lang::prelude::*;
use kamino_lending::{
    fraction::Fraction,
    lending_market::lending_operations::utils::{
        get_elevation_group, get_max_ltv_and_liquidation_threshold,
    },
    utils::{FractionExtra, ELEVATION_GROUP_NONE},
    BorrowSize, CalculateBorrowResult, CalculateRepayResult, LendingMarket, LtvMaxWithdrawalCheck,
    Obligation, ObligationCollateral, PriceStatusFlags, Reserve,
};
use solana_program::{clock::Slot, pubkey::Pubkey};
use std::cmp::min;

/// Inventory moves shift the free AUM and with it every rebalance target, so they wait for the
/// rebalance to end. One that is over at these prices is ended here first.
fn require_no_rebalance_in_progress(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    timestamp: Timestamp,
) -> Result<()> {
    vault.finish_rebalance_if_over(vault_scope_prices, timestamp);
    require!(
        !vault.rebalance.is_unfinished(),
        KaminoVaultError::ObligationOperationDuringRebalance
    );
    Ok(())
}

#[allow(clippy::too_many_arguments)]
#[inline(never)]
pub fn deposit_obligation_collateral(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    reserve: &Reserve,
    liquidity_mint: &Pubkey,
    liquidity_amount: TokenAmount,
    slot: Slot,
    timestamp: Timestamp,
) -> Result<DepositObligationCollateralEffects> {
    require_no_rebalance_in_progress(vault, vault_scope_prices, timestamp)?;

    require!(
        !reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?,
        KaminoVaultError::ReserveStale,
    );

    charge_fees(vault, vault_scope_prices, obligations_aum, timestamp)?;
    let effects = compute_deposit_obligation_collateral_effects(reserve, liquidity_amount)?;

    // EFFECTS: vault liquidity flows to the klend reserve; obligation gains a matching ctoken
    // deposit. Net AUM is conserved modulo klend's ctoken-rounding step: the leg is booked as
    // the ctokens actually minted (what the loader recomputes next), not the ceil'd liquidity
    // klend charges for them.
    let vault_token = vault.get_vault_token_mut_by_mint(liquidity_mint)?;
    vault_token.withdraw_tokens(effects.liquidity_to_deposit);

    let post_cpi_obligations_aum = obligations_aum
        + scope_ctoken_value(
            &*vault,
            vault_scope_prices,
            liquidity_mint,
            reserve,
            effects.ctokens_to_receive,
            RoundingMethod::Floor,
        )?;

    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        post_cpi_obligations_aum,
        timestamp,
    );

    Ok(effects)
}

#[allow(clippy::too_many_arguments)]
#[inline(never)]
pub fn withdraw_obligation_collateral(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    reserve: &Reserve,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    withdraw_reserve_pk: &Pubkey,
    liquidity_mint: &Pubkey,
    collateral_amount: AllAvailableOr<TokenAmount>,
    slot: Slot,
    timestamp: Timestamp,
) -> Result<WithdrawObligationCollateralEffects> {
    require_no_rebalance_in_progress(vault, vault_scope_prices, timestamp)?;

    require!(
        !reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?,
        KaminoVaultError::ReserveStale,
    );

    charge_fees(vault, vault_scope_prices, obligations_aum, timestamp)?;
    let effects = compute_withdraw_obligation_collateral_effects(
        reserve,
        lending_market,
        obligation,
        withdraw_reserve_pk,
        collateral_amount,
    )?;

    // EFFECTS: vault liquidity flows in from the klend reserve; obligation drops a matching
    // slice of ctokens.
    let vault_token = vault.get_vault_token_mut_by_mint(liquidity_mint)?;
    vault_token.deposit_tokens(effects.liquidity_to_receive);

    let post_cpi_obligations_aum = obligations_aum
        - scope_ctoken_value(
            &*vault,
            vault_scope_prices,
            liquidity_mint,
            reserve,
            effects.ctokens_to_redeem,
            RoundingMethod::Ceil,
        )?;

    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        post_cpi_obligations_aum,
        timestamp,
    );

    Ok(effects)
}

#[allow(clippy::too_many_arguments)]
#[inline(never)]
pub fn borrow_obligation_liquidity(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    reserve: &Reserve,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    liquidity_mint: &Pubkey,
    liquidity_amount: TokenAmount,
    slot: Slot,
    timestamp: Timestamp,
) -> Result<BorrowObligationLiquidityEffects> {
    require_no_rebalance_in_progress(vault, vault_scope_prices, timestamp)?;

    require!(
        !reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?,
        KaminoVaultError::ReserveStale,
    );

    charge_fees(vault, vault_scope_prices, obligations_aum, timestamp)?;
    let effects = compute_borrow_obligation_liquidity_effects(
        reserve,
        lending_market,
        obligation,
        liquidity_amount,
    )?;

    // EFFECTS: vault gains `liquidity_to_receive` (the origination fee is netted out by klend
    // before the SPL transfer); the obligation's debt grows by `debt_increase` — the fractional amount klend
    // actually records, which the loader revalues next time. For an exact-amount borrow this is
    // `liquidity_to_receive + origination_fee`, so net AUM drops by exactly the origination fee;
    // an all-available borrow additionally drops the sub-lamport part klend books but never
    // transfers.
    let vault_token = vault.get_vault_token_mut_by_mint(liquidity_mint)?;
    vault_token.deposit_tokens(effects.liquidity_to_receive);

    let post_cpi_obligations_aum = obligations_aum
        - scope_liquidity_value(
            &*vault,
            vault_scope_prices,
            liquidity_mint,
            effects.debt_increase,
            RoundingMethod::Ceil,
        )?;

    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        post_cpi_obligations_aum,
        timestamp,
    );

    Ok(effects)
}

#[allow(clippy::too_many_arguments)]
#[inline(never)]
pub fn repay_obligation_liquidity(
    vault: &mut MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    obligations_aum: NetAum,
    reserve: &Reserve,
    obligation: &Obligation,
    repay_reserve_pk: &Pubkey,
    liquidity_mint: &Pubkey,
    liquidity_amount: TokenAmount,
    slot: Slot,
    timestamp: Timestamp,
) -> Result<RepayObligationLiquidityEffects> {
    require_no_rebalance_in_progress(vault, vault_scope_prices, timestamp)?;

    require!(
        !reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?,
        KaminoVaultError::ReserveStale,
    );

    charge_fees(vault, vault_scope_prices, obligations_aum, timestamp)?;
    let effects = compute_repay_obligation_liquidity_effects(
        reserve,
        obligation,
        repay_reserve_pk,
        liquidity_amount,
    )?;

    // EFFECTS: vault liquidity flows to the klend reserve; obligation drops `debt_decrease` of
    // debt — the fractional amount klend actually settles, which the loader revalues next time.
    // The vault transfers its ceiling (`liquidity_to_repay`); on a full repay the sub-lamport
    // difference is donated to the reserve, not AUM.
    let vault_token = vault.get_vault_token_mut_by_mint(liquidity_mint)?;
    vault_token.withdraw_tokens(effects.liquidity_to_repay);

    let post_cpi_obligations_aum = obligations_aum
        + scope_liquidity_value(
            &*vault,
            vault_scope_prices,
            liquidity_mint,
            effects.debt_decrease,
            RoundingMethod::Floor,
        )?;

    finish_rebalance_and_rebaseline_aum(
        vault,
        vault_scope_prices,
        post_cpi_obligations_aum,
        timestamp,
    );

    Ok(effects)
}

pub fn compute_deposit_obligation_collateral_effects(
    reserve: &Reserve,
    liquidity_amount: TokenAmount,
) -> Result<DepositObligationCollateralEffects> {
    let deposit_result =
        reserve.compute_depositable_amount_and_minted_collateral(u64::from(liquidity_amount))?;
    Ok(DepositObligationCollateralEffects {
        liquidity_to_deposit: TokenAmount::from(deposit_result.liquidity_amount),
        ctokens_to_receive: TokenAmount::from(deposit_result.collateral_amount),
    })
}

pub fn compute_withdraw_obligation_collateral_effects(
    reserve: &Reserve,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    withdraw_reserve_address: &Pubkey,
    requested_ctoken_amount: AllAvailableOr<TokenAmount>,
) -> Result<WithdrawObligationCollateralEffects> {
    // Note: a reimplementation of klend's `withdraw_obligation_collateral_and_redeem_reserve_collateral`:
    let collateral = obligation.find_collateral_in_deposits(*withdraw_reserve_address)?;

    let ctokens_to_redeem = match requested_ctoken_amount {
        AllAvailableOr::AllAvailable => {
            compute_max_redeemable_ctoken_amount(reserve, lending_market, obligation, collateral)?
        }
        AllAvailableOr::Exactly(requested_ctoken_amount) => min(
            requested_ctoken_amount,
            TokenAmount::from(collateral.deposited_amount),
        ),
    };

    let liquidity_to_receive = reserve
        .collateral_exchange_rate()
        .collateral_to_liquidity(ctokens_to_redeem.into())
        .into();

    Ok(WithdrawObligationCollateralEffects {
        ctokens_to_redeem,
        liquidity_to_receive,
    })
}

pub fn compute_borrow_obligation_liquidity_effects(
    reserve: &Reserve,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    liquidity_amount: TokenAmount,
) -> Result<BorrowObligationLiquidityEffects> {
    // Note: a reimplementation of klend's `borrow_obligation_liquidity` calcs:
    let CalculateBorrowResult {
        borrow_amount_f,
        receive_amount,
        origination_fee,
        referrer_fee,
    } = reserve.calculate_borrow(
        BorrowSize::exact_or_all_available(u64::from(liquidity_amount)),
        obligation.remaining_borrow_value(),
        lending_market.referral_fee_bps,
        obligation.elevation_group != ELEVATION_GROUP_NONE,
        false, // metavault never sets a referrer on its obligations
    )?;
    require_eq!(referrer_fee, 0, KaminoVaultError::UnexpectedReferrerFee);
    Ok(BorrowObligationLiquidityEffects {
        liquidity_to_receive: TokenAmount::from(receive_amount),
        origination_fee: TokenAmount::from(origination_fee),
        debt_increase: FractionalTokenAmount::from(borrow_amount_f),
    })
}

pub fn compute_repay_obligation_liquidity_effects(
    reserve: &Reserve,
    obligation: &Obligation,
    repay_reserve_pk: &Pubkey,
    liquidity_amount: TokenAmount,
) -> Result<RepayObligationLiquidityEffects> {
    // Note: a reimplementation of klend's `repay_obligation_liquidity` calcs - but NOT including the newest "early repay penalty" yet!
    let (borrow, _index) = obligation.find_liquidity_in_borrows(*repay_reserve_pk)?;
    let CalculateRepayResult {
        repay_amount,
        settle_amount,
    } = reserve.calculate_repay(u64::from(liquidity_amount), borrow.borrowed_amount());
    Ok(RepayObligationLiquidityEffects {
        liquidity_to_repay: TokenAmount::from(repay_amount),
        debt_decrease: FractionalTokenAmount::from(settle_amount),
    })
}

fn compute_max_redeemable_ctoken_amount(
    reserve: &Reserve,
    lending_market: &LendingMarket,
    obligation: &Obligation,
    collateral: &ObligationCollateral,
) -> Result<TokenAmount> {
    let deposited_ctokens = TokenAmount::from(collateral.deposited_amount);
    require!(
        !deposited_ctokens.is_zero() && obligation.deposited_value_sf != 0,
        KaminoVaultError::ObligationDepositsZero
    );

    if obligation.is_active_borrows_empty() {
        return Ok(deposited_ctokens);
    }

    let (max_ltv_pct, liq_threshold_pct) = get_max_ltv_and_liquidation_threshold(
        reserve,
        get_elevation_group(obligation.elevation_group, lending_market)?,
    );
    let max_withdraw_value = DollarValue::from(obligation.max_withdraw_value(
        collateral,
        max_ltv_pct,
        liq_threshold_pct,
        LtvMaxWithdrawalCheck::MaxLtv,
    ));

    let collateral_value = DollarValue::from_bits(collateral.market_value_sf);
    require!(
        !max_withdraw_value.is_zero() && !collateral_value.is_zero(),
        KaminoVaultError::MaximumWithdrawValueZero
    );

    let withdraw_value = min(max_withdraw_value, collateral_value);
    // Bit-exact replica of klend's sizing: the ratio is truncated to `Fraction` precision
    // *before* multiplying by the deposited amount. A full-precision ratio application can
    // yield one more ctoken than klend will actually burn.
    let withdraw_ratio = Fraction::from(withdraw_value) / Fraction::from(collateral_value);
    let ratioed_amount: u64 =
        (withdraw_ratio * u128::from(u64::from(deposited_ctokens))).to_floor();
    Ok(min(deposited_ctokens, TokenAmount::from(ratioed_amount)))
}

/// Values a (fractional) liquidity amount on the vault's scope basis (not klend's reserve
/// price), so post-CPI AUM deltas stay coherent with the scope-priced aggregate the shared
/// loader recomputes.
fn scope_liquidity_value(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    liquidity_mint: &Pubkey,
    amount: FractionalTokenAmount,
    rounding: RoundingMethod,
) -> Result<DollarValue> {
    let (_, token_price) = find_enabled_token_and_price(vault, vault_scope_prices, liquidity_mint)?;
    Ok(amount.to_aum(token_price, rounding))
}

/// Values a ctoken amount on the vault's scope basis: converts to liquidity via the reserve's own
/// exchange rate (klend's collateral <-> liquidity relationship, unaffected by price basis), then
/// prices that liquidity at the vault's scope price rather than klend's reserve price.
fn scope_ctoken_value(
    vault: &MetavaultState,
    vault_scope_prices: &VaultScopePrices,
    liquidity_mint: &Pubkey,
    reserve: &Reserve,
    ctoken_amount: TokenAmount,
    rounding: RoundingMethod,
) -> Result<DollarValue> {
    let liquidity_f = FractionalTokenAmount::from(
        reserve
            .collateral_exchange_rate()
            .fraction_collateral_to_liquidity(ctoken_amount.as_fraction()),
    );
    let (_, token_price) = find_enabled_token_and_price(vault, vault_scope_prices, liquidity_mint)?;
    Ok(liquidity_f.to_aum(token_price, rounding))
}

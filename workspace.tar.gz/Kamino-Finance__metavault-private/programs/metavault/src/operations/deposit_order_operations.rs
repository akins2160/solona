use anchor_lang::prelude::*;

use crate::{
    operations::{
        effects::{OrderPayoutEffects, SettleDepositOrderEffects},
        order_basket::OrderBasket,
        rebalance_basket::RebalanceBasket,
        rolling_cap,
        vault_operations::{
            charge_fees, common::get_shares_to_mint_from_aum, finish_rebalance_and_rebaseline_aum,
        },
    },
    order::DepositOrder,
    state::{MetavaultState, VaultToken},
    types::{
        DollarValue, Duration, MinFeeSpec, NetAum, Ratio, RebalanceLimits, RoundingMethod,
        ShareAmount, SharePrice, Timestamp, TokenAmount, VaultTokenId, Weight,
    },
    utils::{consts::MAX_TOKENS_PER_VAULT, scope::VaultScopePrices},
    GlobalConfig, KaminoVaultError,
};

/// Opens a freshly constructed order ([DepositOrder::new]): locks the given `amounts` (one per
/// enabled vault token, dense order), sets its share price limit and starts its auction under
/// `limits`.
#[allow(clippy::too_many_arguments)]
pub fn open_deposit_order(
    order: &mut DepositOrder,
    vault: &mut MetavaultState,
    prices: &VaultScopePrices,
    amounts: &[TokenAmount],
    duration: Duration,
    limits: RebalanceLimits,
    min_shares_out: ShareAmount,
    now: Timestamp,
) -> Result<()> {
    require!(
        vault.deposit_order_creation_enabled(),
        KaminoVaultError::DepositOrderCreationDisabled
    );
    require_eq!(
        amounts.len(),
        vault.get_tokens_count(),
        KaminoVaultError::TokenArrayLengthMismatch
    );
    require!(
        amounts.iter().any(|amount| !amount.is_zero()),
        KaminoVaultError::DepositAmountsZero
    );

    // Lock the amounts and learn (and validate) the total order value:
    let locked_value = lock_deposit_order_inputs(order, vault, prices, amounts)?;

    // A worthless basket could only ever absorb nothing (and would turn its share price limit off):
    require!(
        !locked_value.is_zero(),
        KaminoVaultError::DepositAmountsZero
    );
    if let Some(min_value) = vault.order_min_open() {
        require_gte!(
            locked_value,
            min_value,
            KaminoVaultError::OrderBelowMinValue
        );
    }

    // Only now we can calculate and configure the share price limit:
    let max_share_price = SharePrice::try_of(locked_value, min_shares_out, RoundingMethod::Ceil);
    order.set_max_share_price(max_share_price);

    // Actually start the auction:
    let mut basket = OrderBasket { order, vault };
    basket.start_auction(duration, prices, now, limits)?;

    Ok(())
}

/// Ends the order once its auction is over (anyone may): absorbs what the vault's bounds admit,
/// mints shares for it, refunds the rest.
///
/// The settler picks the moment, so the prices and the bounds' headroom are those of the settle's
/// slot (the share price limit still holds): orders settle first-come against the vault's current
/// bounds, and one settled later may have to refund more.
pub fn settle_deposit_order(
    order: &mut DepositOrder,
    vault: &mut MetavaultState,
    prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    now: Timestamp,
) -> Result<SettleDepositOrderEffects> {
    let mut basket = OrderBasket { order, vault };
    require!(
        basket.vault.deposit_order_settle_enabled(),
        KaminoVaultError::DepositOrderSettleDisabled
    );
    require!(
        basket.vault.block_deposits == 0,
        KaminoVaultError::VaultDepositsBlocked
    );
    require!(
        basket.is_auction_over(prices, now),
        KaminoVaultError::OrderAuctionStillRunning // a fill could still improve it (an absorb now would leave an unfillable rest)
    );
    Ok(SettleDepositOrderEffects {
        shares_minted: absorb_admissible(&mut basket, prices, obligations_aum, global_config, now)?,
        refunds: basket.release_everything(),
    })
}

/// Ends the order by refunding everything it holds. Needs no prices; the auction state is left as
/// is (the handler deletes the account right after).
pub fn cancel_deposit_order(
    order: &mut DepositOrder,
    vault: &mut MetavaultState,
    now: Timestamp,
) -> OrderPayoutEffects {
    let mut basket = OrderBasket { order, vault };
    let mid_auction = basket.order.base.rebalance.is_within(now);
    OrderPayoutEffects {
        payouts: basket.release_everything(),
        mid_auction,
    }
}

/// One token's inputs to the bound solve: its ceiling and the two values it is compared against.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct TokenAbsorbBound {
    /// The highest share of the (post-absorb) vault this token may take; `>= 1` means no ceiling.
    max_weight: Ratio<Weight>,

    /// The value the vault already holds of this token.
    vault_token_aum: DollarValue,

    /// The value this order has locked of this token (the most it could add).
    locked_aum: DollarValue,
}

/// Validates and locks the user-provided amounts for the deposit order, returning its total value.
fn lock_deposit_order_inputs(
    order: &mut DepositOrder,
    vault: &mut MetavaultState,
    prices: &VaultScopePrices,
    amounts: &[TokenAmount],
) -> Result<DollarValue> {
    let mut basket = OrderBasket { order, vault };

    for token in &basket.tokens() {
        let amount = amounts[token.id.input_account_index];
        if amount.is_zero() {
            continue; // user did not provide this one at all
        }
        require!(!token.weight.is_zero(), KaminoVaultError::TokenWeightZeroed); // if the vault is selling that token off, it does not accept more of it
        basket.credit(token.id, amount);
    }

    Ok(basket.tokens().value(prices, RoundingMethod::Floor))
}

/// Calculates the highest value that the target-weight bounds let the order put into the vault
/// at once.
fn max_absorbable_aum(bounds: &[TokenAbsorbBound], free_aum: DollarValue) -> DollarValue {
    // Everything fits: done.
    let all_locked_aum = bounds.iter().map(|bound| bound.locked_aum).sum();
    if absorbable_aum_sum(bounds, free_aum, all_locked_aum) >= all_locked_aum {
        return all_locked_aum;
    }

    // The room only changes shape where a token hits its ceiling or runs out: collect those points.
    let mut breakpoints = vec![DollarValue::ZERO];
    for bound in bounds {
        let Some(reciprocal) = bound.max_weight.reciprocal() else {
            continue; // a zero ceiling admits nothing at any total, so nothing about it changes shape
        };
        for vault_token_aum_after in [
            bound.vault_token_aum,
            bound.vault_token_aum.saturating_add(bound.locked_aum),
        ] {
            // Absorbed total at which the grown vault's ceiling on this token equals this holding.
            let breakpoint = vault_token_aum_after
                .apply_ratio(reciprocal, RoundingMethod::Floor)
                .saturating_sub(free_aum);
            if breakpoint > DollarValue::ZERO && breakpoint < all_locked_aum {
                breakpoints.push(breakpoint);
            }
        }
    }

    // The last point the tokens still cover and the first they do not - the answer is in between.
    let last_fillable = breakpoints
        .iter()
        .copied()
        .filter(|&point| absorbable_aum_sum(bounds, free_aum, point) >= point)
        .max()
        .unwrap_or(DollarValue::ZERO);
    let next_breakpoint = breakpoints
        .iter()
        .copied()
        .filter(|&point| point > last_fillable)
        .min()
        .unwrap_or(all_locked_aum);

    // `>= 0`, since `last_fillable` passed the coverage filter.
    let overshoot =
        absorbable_aum_sum(bounds, free_aum, last_fillable).saturating_sub(last_fillable);
    // `> 0`, since every point past `last_fillable` failed that filter.
    let shortfall =
        next_breakpoint.saturating_sub(absorbable_aum_sum(bounds, free_aum, next_breakpoint));
    // Coverage is linear between breakpoints, so the crossing is a plain interpolation.
    let towards_next = Ratio::of(overshoot, overshoot.saturating_add(shortfall)); // in [0, 1)
    last_fillable.lerp(next_breakpoint, towards_next, RoundingMethod::Floor) // Floor only errs towards taking less
}

/// The value of one token the bounds admit, given the whole absorb is worth `absorbed_aum`.
fn absorbable_aum(
    bound: &TokenAbsorbBound,
    free_aum: DollarValue,
    absorbed_aum: DollarValue,
) -> DollarValue {
    if bound.max_weight >= Ratio::one() {
        return bound.locked_aum; // no ceiling (and the vault-favorable rounding below would miss it, hence explicit handling)
    }
    free_aum
        .saturating_add(absorbed_aum)
        .apply_ratio(bound.max_weight, RoundingMethod::Floor)
        .saturating_sub(bound.vault_token_aum)
        .min(bound.locked_aum)
}

/// The highest share of the vault this token may take, or `>= 1` for no ceiling.
fn max_weight(vault_token: &VaultToken, total_weight: Weight) -> Ratio<Weight> {
    if vault_token.weight().is_zero() {
        return Ratio::zero(); // the vault wants to strictly get rid of all of this token
    }
    let Some(max_deviation) = vault_token.max_deviation() else {
        return Ratio::one(); // the "max deviation" limit is not configured for this token (== no ceiling for depositing)
    };
    Ratio::of(vault_token.weight(), total_weight) + max_deviation
}

/// The core of a settle: absorbs the largest part of the order the vault's bounds admit and returns
/// the minted shares (`0` when not worth a whole share - then nothing moves). Whatever is not
/// absorbed stays locked, for the refund.
fn absorb_admissible(
    basket: &mut OrderBasket<DepositOrder>,
    prices: &VaultScopePrices,
    obligations_aum: NetAum,
    global_config: &GlobalConfig,
    now: Timestamp,
) -> Result<ShareAmount> {
    basket.vault.finish_rebalance_if_over(prices, now);
    charge_fees(basket.vault, prices, obligations_aum, now)?;
    let total_shares = basket.vault.shares_issued_amount();
    require!(!total_shares.is_zero(), KaminoVaultError::VaultSharesZero);
    let net_aum = basket
        .vault
        .compute_net_aum(prices, obligations_aum, RoundingMethod::Ceil)
        .check_positive()?;

    let tokens = admissible_tokens(basket, prices);

    // Back to tokens, gross and net of the deposit fee.
    let mut gross_value = DollarValue::ZERO;
    let mut net_value = DollarValue::ZERO;
    let mut fee_value = DollarValue::ZERO;
    let mut absorbed = [TokenAmount::ZERO; MAX_TOKENS_PER_VAULT];
    for token in &tokens {
        let vault_token = basket.vault.get_vault_token_by_id(token.id);
        let price = prices.by_id(token.id);
        let amount = if token.admitted_aum == token.bound.locked_aum {
            token.locked // untouched by the bounds: whole, not through a value round trip losing a lamport
        } else {
            token
                .admitted_aum
                .to_tokens(price, RoundingMethod::Floor)
                .min(token.locked)
        };
        if amount.is_zero() {
            continue;
        }
        // The fee stays in the vault (a leg worth less than its fee is all fee):
        let fee = MinFeeSpec::combine_max(
            global_config.deposit_fee_spec(),
            vault_token.deposit_fee_spec(),
        )
        .calculate_fee_from(amount)
        .min(amount);
        absorbed[token.id.storage_index] = amount;
        gross_value = gross_value.saturating_add(amount.to_aum(price, RoundingMethod::Ceil));
        net_value = net_value.saturating_add((amount - fee).to_aum(price, RoundingMethod::Floor));
        fee_value = fee_value.saturating_add(fee.to_aum(price, RoundingMethod::Ceil));
    }
    // Priced against the AUM with the fees in (like a plain deposit: no claim on one's own fee):
    let pricing_aum = net_aum.saturating_add(fee_value);
    let shares_minted =
        get_shares_to_mint_from_aum(Ratio::of(net_value, pricing_aum), total_shares);
    // Also covers the "nothing admitted" case (its value is zero).
    if shares_minted.is_zero() {
        return Ok(ShareAmount::ZERO); // not worth a whole share: better take nothing than take it for nothing
    }
    if let Some(max_share_price) = basket.order.max_share_price() {
        // The minted shares, priced at the owner's limit, must cover what the absorb takes.
        require_gte!(
            max_share_price.value_of(shares_minted, RoundingMethod::Floor),
            net_value,
            KaminoVaultError::SlippageExceeded
        );
    }

    // The deposit caps take the gross value (shares were minted for the net one):
    rolling_cap::accumulate_deposit(&mut basket.vault.rolling_deposit_cap, gross_value, now)?;
    if basket.vault.is_deposit_cap_enabled() {
        require_gte!(
            basket.vault.deposit_cap(),
            net_aum.saturating_add(gross_value),
            KaminoVaultError::DepositAumCapExceeded
        );
    }

    // Effects: locked amounts become the vault's available (fee included); shares go to the owner.
    for token in &tokens {
        let amount = absorbed[token.id.storage_index];
        if amount.is_zero() {
            continue;
        }
        basket.debit(token.id, amount);
        basket
            .vault
            .get_vault_token_mut_by_id(token.id)
            .deposit_tokens(amount);
    }
    basket.vault.mint_shares(shares_minted);
    finish_rebalance_and_rebaseline_aum(basket.vault, prices, obligations_aum, now);

    Ok(shares_minted)
}

/// One of the order's tokens as the bound solve sees it, and what it admits of it.
pub(crate) struct OrderToken {
    pub(crate) id: VaultTokenId,

    /// The amount this order owns of it.
    pub(crate) locked: TokenAmount,

    /// Its inputs to the bound solve.
    bound: TokenAbsorbBound,

    /// The value the bounds admit of it (never more than `bound.locked_aum`).
    pub(crate) admitted_aum: DollarValue,
}

/// The order's non-empty tokens with what the vault's target-weight bounds currently admit of each.
pub(crate) fn admissible_tokens(
    basket: &OrderBasket<DepositOrder>,
    prices: &VaultScopePrices,
) -> Vec<OrderToken> {
    let free_aum = basket.vault.compute_free_aum(prices, RoundingMethod::Floor);
    let total_weight = basket.vault.tokens().total_weight();
    let mut tokens = basket
        .tokens()
        .into_iter()
        .filter(|token| !token.available.is_zero())
        .map(|token| {
            let price = prices.by_id(token.id);
            let vault_token = basket.vault.get_vault_token_by_id(token.id);
            OrderToken {
                id: token.id,
                locked: token.available,
                bound: TokenAbsorbBound {
                    max_weight: max_weight(vault_token, total_weight),
                    vault_token_aum: vault_token.compute_aum(price, RoundingMethod::Ceil),
                    locked_aum: token.available.to_aum(price, RoundingMethod::Floor),
                },
                admitted_aum: DollarValue::ZERO,
            }
        })
        .collect::<Vec<_>>();
    let bounds = tokens.iter().map(|token| token.bound).collect::<Vec<_>>();
    // The tokens couple only through the total absorbed, so that is the one unknown solved for.
    let absorbed_aum = max_absorbable_aum(&bounds, free_aum);
    // Each token's share is then a direct clamp at that total, all against the same vault size.
    for token in tokens.iter_mut() {
        token.admitted_aum = absorbable_aum(&token.bound, free_aum, absorbed_aum);
    }
    tokens
}

/// The sum of every token's admitted value at `absorbed_aum` (how much of that total they cover).
fn absorbable_aum_sum(
    bounds: &[TokenAbsorbBound],
    free_aum: DollarValue,
    absorbed_aum: DollarValue,
) -> DollarValue {
    bounds
        .iter()
        .map(|bound| absorbable_aum(bound, free_aum, absorbed_aum))
        .sum()
}

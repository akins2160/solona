use std::collections::HashMap;

use kamino_lending::fraction::Fraction;
use proptest::prelude::*;

use super::tests_utils::{fixtures::setup_vault_with_tokens_and_config, TokenConfig};
use crate::operations::vault_operations;
use crate::operations::vault_operations::common::{
    calculate_shares_to_burn, compute_amount_to_deposit_from_shares_to_mint, get_shares_to_mint,
};
use crate::types::{
    DollarValue, NetAum, Ratio, RoundingMethod, ShareAmount, Timestamp, TokenAmount, TokenPrice,
};

// ---------------------------------------------------------------------------
// 1. tokens_to_aum <-> aum_to_tokens roundtrip
// ---------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig::with_cases(1_000_000))]

    #[test]
    fn test_tokens_aum_roundtrip_floor(
        tokens in 1_u64..10_000_000_000,
        price_f in 0.001_f64..100_000.0,
        decimals in 2_u8..13,
    ) {
        let price = Fraction::from_num(price_f);
        let tp = TokenPrice::new(price, decimals);
        let aum = TokenAmount::from(tokens).to_aum(&tp, RoundingMethod::Floor);
        let back = aum.to_tokens(&tp, RoundingMethod::Floor);
        prop_assert!(
            back <= TokenAmount::from(tokens),
            "Floor roundtrip must not exceed original: back={} > tokens={}",
            back, tokens
        );
    }

    #[test]
    fn test_tokens_aum_roundtrip_ceil(
        tokens in 1_u64..10_000_000_000,
        price_f in 0.001_f64..100_000.0,
        decimals in 2_u8..13,
    ) {
        let price = Fraction::from_num(price_f);
        let tp = TokenPrice::new(price, decimals);
        let aum = TokenAmount::from(tokens).to_aum(&tp, RoundingMethod::Floor);
        let back = aum.to_tokens(&tp, RoundingMethod::Ceil);
        prop_assert!(
            back >= TokenAmount::from(tokens),
            "Ceil roundtrip must not be less than original: back={} < tokens={}",
            back, tokens
        );
    }
}

// ---------------------------------------------------------------------------
// 2. get_shares_to_mint <-> compute_amount_to_deposit_from_shares_to_mint
// ---------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn test_mint_then_recompute_covers_shares(
        vault_aum_f in 1.0_f64..1_000_000.0,
        // Keep the domain below the edge where rounding can drive the remint path
        // into values that no longer fit in the u64-based ShareAmount/TokenAmount types.
        max_tokens in 1_000_u64..1_000_000_000,
        shares_issued in 100_u64..1_000_000_000,
        price_f in 0.01_f64..10_000.0,
        decimals in 4_u8..10,
    ) {
        let vault_aum = DollarValue::from(Fraction::from_num(vault_aum_f));
        let token_price = TokenPrice::new(Fraction::from_num(price_f), decimals);

        let shares_to_mint = get_shares_to_mint(
            vault_aum, TokenAmount::from(max_tokens), ShareAmount::from(shares_issued), &token_price,
        );
        prop_assume!(!shares_to_mint.is_zero());

        let tokens_needed = compute_amount_to_deposit_from_shares_to_mint(
            Ratio::of(shares_to_mint, ShareAmount::from(shares_issued)), vault_aum, &token_price,
        );

        let reminted = get_shares_to_mint(
            vault_aum, tokens_needed, ShareAmount::from(shares_issued), &token_price,
        );

        prop_assert!(
            reminted >= shares_to_mint,
            "Recomputed tokens must cover original shares: reminted={} < shares_to_mint={}",
            reminted, shares_to_mint
        );
    }
}

// ---------------------------------------------------------------------------
// 3. get_shares_to_mint <-> calculate_shares_to_burn symmetry
// ---------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn test_mint_burn_vault_favorable(
        vault_aum_f in 1.0_f64..1_000_000.0,
        deposit_tokens in 1_000_u64..1_000_000_000,
        shares_issued in 1_000_u64..1_000_000_000,
        price_f in 0.01_f64..10_000.0,
        decimals in 4_u8..10,
    ) {
        let vault_aum = DollarValue::from(Fraction::from_num(vault_aum_f));
        let token_price = TokenPrice::new(Fraction::from_num(price_f), decimals);

        let shares_minted = get_shares_to_mint(
            vault_aum, TokenAmount::from(deposit_tokens), ShareAmount::from(shares_issued), &token_price,
        );
        prop_assume!(!shares_minted.is_zero());

        let deposit_aum = TokenAmount::from(deposit_tokens).to_aum(&token_price, RoundingMethod::Floor);
        prop_assume!(!deposit_aum.is_zero());

        let new_shares = shares_issued.checked_add(u64::from(shares_minted));
        prop_assume!(new_shares.is_some());
        let new_shares = ShareAmount::from(new_shares.unwrap());
        let new_aum = vault_aum + deposit_aum;

        let shares_burned = calculate_shares_to_burn(
            Ratio::of(deposit_aum, new_aum),
            new_shares,
        );

        prop_assert!(
            shares_burned >= shares_minted,
            "Shares burned ({}) must be >= shares minted ({}) for same AUM",
            shares_burned, shares_minted
        );
    }
}

// ---------------------------------------------------------------------------
// 4. Full deposit -> withdraw no-profit invariant
// ---------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn test_deposit_withdraw_no_profit(
        price_f in 0.1_f64..10_000.0,
        decimals in 4_u8..10,
        deposit_amount in 10_000_u64..1_000_000_000,
    ) {
        let tokens = HashMap::from_iter([
            ("TOKEN", TokenConfig::with_price_and_decimals(price_f, decimals)),
        ]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);
        let mint = tokens["TOKEN"].mint;

        let deposit_result = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, mint, TokenAmount::new(deposit_amount), Timestamp::ZERO,
        );
        prop_assume!(deposit_result.is_ok());
        let deposit_effects = deposit_result.unwrap();
        prop_assume!(!deposit_effects.shares_to_mint.is_zero());

        let withdraw_result = vault_operations::withdraw(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, mint, Timestamp::ZERO, deposit_effects.shares_to_mint,
        );
        prop_assume!(withdraw_result.is_ok());
        let withdraw_effects = withdraw_result.unwrap();

        prop_assert!(
            withdraw_effects.available_to_send_to_user <= deposit_effects.token_to_deposit,
            "User must not profit from deposit+withdraw: received={} > deposited={}",
            withdraw_effects.available_to_send_to_user,
            deposit_effects.token_to_deposit
        );
    }
}

// ---------------------------------------------------------------------------
// 5. compute_aum additive invariant (vault AUM == sum of individual token AUMs)
// ---------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig::with_cases(1_000_000))]

    #[test]
    fn test_vault_aum_equals_sum_of_token_aums(
        price_a_f in 0.1_f64..10_000.0,
        price_b_f in 0.1_f64..10_000.0,
        decimals_a in 4_u8..10,
        decimals_b in 4_u8..10,
        deposit_a in 10_000_u64..1_000_000_000,
        deposit_b in 10_000_u64..1_000_000_000,
    ) {
        let tokens = HashMap::from_iter([
            ("ALPHA", TokenConfig::with_price_and_decimals(price_a_f, decimals_a)),
            ("BETA", TokenConfig::with_price_and_decimals(price_b_f, decimals_b)),
        ]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);

        let _ = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, tokens["ALPHA"].mint, TokenAmount::new(deposit_a), Timestamp::ZERO,
        );
        let _ = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, tokens["BETA"].mint, TokenAmount::new(deposit_b), Timestamp::ZERO,
        );

        let vault_aum = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));

        let mut manual_sum = Fraction::ZERO;
        for (token, price) in vault.iter_enabled_tokens()
            .zip(&vault_scope_prices.prices)
        {
            manual_sum += Fraction::from(TokenAmount::from(token.token_available).to_aum(price, RoundingMethod::Floor));
        }

        prop_assert_eq!(
            vault_aum, manual_sum,
            "Vault AUM ({}) != sum of token AUMs ({})",
            vault_aum.to_num::<f64>(), manual_sum.to_num::<f64>()
        );
    }
}

// -------------------------------------------------------------------------------------------------------------
// 6. Multi-deposit/withdraw AUM monotonicity
// -------------------------------------------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn test_deposit_aum_monotonically_increases(
        price_f in 0.1_f64..10_000.0,
        decimals in 4_u8..10,
        deposits in prop::collection::vec(10_000_u64..100_000_000, 2..5),
    ) {
        let tokens = HashMap::from_iter([
            ("TOKEN", TokenConfig::with_price_and_decimals(price_f, decimals)),
        ]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);
        let mint = tokens["TOKEN"].mint;

        let first_result = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, mint, TokenAmount::new(deposits[0]), Timestamp::ZERO,
        );
        prop_assume!(first_result.is_ok());
        let mut prev_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);

        for &amount in deposits.iter().skip(1) {
            let result = vault_operations::deposit(
                &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, mint, TokenAmount::new(amount), Timestamp::ZERO,
            );
            if result.is_ok() {
                let current_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);
                prop_assert!(
                    current_aum >= prev_aum,
                    "AUM decreased after deposit: {:?} < {:?}",
                    current_aum, prev_aum
                );
                prev_aum = current_aum;
            }
        }
    }

    #[test]
    fn test_withdraw_aum_monotonically_decreases(
        price_f in 0.1_f64..10_000.0,
        decimals in 4_u8..10,
        initial_deposit in 100_000_000_u64..10_000_000_000,
        withdraw_pcts in prop::collection::vec(1_u64..20, 2..5),
    ) {
        let tokens = HashMap::from_iter([
            ("TOKEN", TokenConfig::with_price_and_decimals(price_f, decimals)),
        ]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);
        let mint = tokens["TOKEN"].mint;

        let deposit_result = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, mint, TokenAmount::new(initial_deposit), Timestamp::ZERO,
        );
        prop_assume!(deposit_result.is_ok());

        let mut prev_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);
        let initial_shares = vault.shares_issued;

        for &pct in &withdraw_pcts {
            let shares_to_withdraw =
                (initial_shares as u128 * pct as u128 / 100) as u64;
            let shares_to_withdraw = shares_to_withdraw.min(vault.shares_issued);
            if shares_to_withdraw == 0 {
                continue;
            }

            let result = vault_operations::withdraw(
                &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config, mint, Timestamp::ZERO, ShareAmount::new(shares_to_withdraw),
            );
            if result.is_ok() {
                let current_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);
                prop_assert!(
                    current_aum <= prev_aum,
                    "AUM increased after withdraw: {:?} > {:?}",
                    current_aum, prev_aum
                );
                prev_aum = current_aum;
            }
        }
    }
}

use kamino_lending::fraction::Fraction;

use crate::{
    operations::vault_operations::common::calculate_shares_to_burn,
    types::{DollarValue, Ratio, ShareAmount},
};

#[test]
fn test_calculate_shares_to_burn_with_fractional_part() {
    // We want: (amount * total_supply / total_sum) to have a fractional part

    let amount_to_send_to_user = DollarValue::from(Fraction::from(100u64));
    let total_supply = ShareAmount::from(3); // 3 total supply (small to create fractional result)
    let total_sum = DollarValue::from(Fraction::from(7u64));

    let shares_to_burn =
        calculate_shares_to_burn(Ratio::of(amount_to_send_to_user, total_sum), total_supply);

    // The mathematical calculation: 100 * 3 / 7 = 300/7 ≈ 42.857
    let expected_shares_to_burn = 43;

    assert_eq!(shares_to_burn, ShareAmount::from(expected_shares_to_burn));
}

#[test]
fn test_calculate_shares_to_burn_when_no_fractional_part() {
    let amount_to_send_to_user = DollarValue::from(Fraction::from(100u64));
    let total_supply = ShareAmount::from(4);
    let total_sum = DollarValue::from(Fraction::from(8u64));

    let shares_to_burn =
        calculate_shares_to_burn(Ratio::of(amount_to_send_to_user, total_sum), total_supply);

    // 100 * 4 / 8 = 400/8 = 50 (exact division)
    assert_eq!(shares_to_burn, ShareAmount::from(50));
}

#[test]
fn test_calculate_shares_to_burn_scenarios() {
    struct TestCase {
        aum_to_withdraw: u64,
        total_shares_supply: u64,
        total_vault_aum: u64,
        expected_shares: u64,
    }

    let test_cases = vec![
        // Standard proportional withdrawals
        TestCase {
            aum_to_withdraw: 250,
            total_shares_supply: 100,
            total_vault_aum: 1000,
            expected_shares: 25, // 25% of vault = 25% of shares
        },
        TestCase {
            aum_to_withdraw: 500,
            total_shares_supply: 200,
            total_vault_aum: 2000,
            expected_shares: 50, // 25% of vault = 25% of shares
        },
        // Full vault withdrawal
        TestCase {
            aum_to_withdraw: 1000,
            total_shares_supply: 100,
            total_vault_aum: 1000,
            expected_shares: 100,
        },
        // Ceiling rounding cases
        TestCase {
            aum_to_withdraw: 333,
            total_shares_supply: 100,
            total_vault_aum: 1000,
            expected_shares: 34, // 33.3 rounds up to 34
        },
        TestCase {
            aum_to_withdraw: 1,
            total_shares_supply: 100,
            total_vault_aum: 1000,
            expected_shares: 1, // 0.1 rounds up to 1
        },
        // Large numbers
        TestCase {
            aum_to_withdraw: 1_000_000_000,
            total_shares_supply: 1_000_000_000,
            total_vault_aum: 2_000_000_000,
            expected_shares: 500_000_000,
        },
        // Tiny withdrawals that round up
        TestCase {
            aum_to_withdraw: 1,
            total_shares_supply: 1_000_000,
            total_vault_aum: 1_000_000_000,
            expected_shares: 1, // 0.001 rounds up to 1
        },
    ];

    for test in test_cases {
        let result = calculate_shares_to_burn(
            Ratio::of(
                DollarValue::from(Fraction::from(test.aum_to_withdraw)),
                DollarValue::from(Fraction::from(test.total_vault_aum)),
            ),
            ShareAmount::from(test.total_shares_supply),
        );

        assert_eq!(result, ShareAmount::from(test.expected_shares));
    }
}

#[test]
fn test_calculate_shares_to_burn_edge_cases() {
    // Zero withdrawal
    let result = calculate_shares_to_burn(
        Ratio::of(
            DollarValue::from(Fraction::ZERO),
            DollarValue::from(Fraction::from_num(1000)),
        ),
        ShareAmount::from(100_000_000),
    );
    assert_eq!(result, ShareAmount::from(0));
}

#[test]
fn test_calculate_shares_to_burn_ceiling_precision() {
    #[derive(Debug, Clone)]
    struct TestCase {
        aum_to_withdraw: u64,
        total_shares_supply: u64,
        total_vault_aum: u64,
        expected_shares: u64,
    }

    let test_cases = vec![
        // Cases that create precise fractional results needing ceiling
        TestCase {
            aum_to_withdraw: 1,
            total_shares_supply: 3,
            total_vault_aum: 10,
            expected_shares: 1, // 0.3 -> 1
        },
        TestCase {
            aum_to_withdraw: 7,
            total_shares_supply: 3,
            total_vault_aum: 10,
            expected_shares: 3, // 2.1 -> 3
        },
        TestCase {
            aum_to_withdraw: 100,
            total_shares_supply: 3,
            total_vault_aum: 7,
            expected_shares: 43, // 42.857... -> 43
        },
        TestCase {
            aum_to_withdraw: 999_999,
            total_shares_supply: 1_000_000,
            total_vault_aum: 1_000_000,
            expected_shares: 999_999, // 999,999.0 exactly
        },
        TestCase {
            aum_to_withdraw: 999_999,
            total_shares_supply: 1_000_000,
            total_vault_aum: 1_000_001,
            expected_shares: 999_999, // 999,998.000002... -> 999,999.0
        },
    ];

    for test in test_cases {
        let result = calculate_shares_to_burn(
            Ratio::of(
                DollarValue::from(Fraction::from(test.aum_to_withdraw)),
                DollarValue::from(Fraction::from(test.total_vault_aum)),
            ),
            ShareAmount::from(test.total_shares_supply),
        );

        assert_eq!(result, ShareAmount::from(test.expected_shares));
    }
}

use kamino_lending::fraction::Fraction;

use crate::{
    operations::{
        tests::tests_utils::EPSILON_F,
        vault_operations::common::compute_aum_to_deposit_from_shares_to_mint,
    },
    types::{DollarValue, Ratio, ShareAmount},
};

#[test]
fn test_compute_aum_to_deposit_standard_scenarios() {
    struct TestCase {
        vault_total_shares: u64,
        vault_total_holdings: f64,
        shares_to_mint: u64,
        expected_aum: f64,
    }

    let test_cases = vec![
        TestCase {
            vault_total_shares: 100_000_000, // 100 shares
            vault_total_holdings: 1000.0,    // $1000 AUM
            shares_to_mint: 10_000_000,      // 10 shares to mint
            expected_aum: 100.0,             // $100 AUM required
        },
        TestCase {
            vault_total_shares: 200_000_000,
            vault_total_holdings: 2000.0,
            shares_to_mint: 50_000_000, // 50 shares
            expected_aum: 500.0,        // $500 AUM required
        },
        TestCase {
            vault_total_shares: 1_000_000,
            vault_total_holdings: 500.0,
            shares_to_mint: 100_000, // 10% of shares
            expected_aum: 50.0,      // $50 AUM required
        },
        TestCase {
            vault_total_shares: 1_000_000_000_000, // Large vault
            vault_total_holdings: 1_000_000.0,     // $1M AUM
            shares_to_mint: 1_000_000_000,         // 0.1% of shares
            expected_aum: 1000.0,                  // $1000 AUM required
        },
        TestCase {
            vault_total_shares: 333,
            vault_total_holdings: 999.0,
            shares_to_mint: 1, // Single share
            expected_aum: 3.0, // Exactly 3 AUM
        },
    ];

    for test in test_cases {
        let result = compute_aum_to_deposit_from_shares_to_mint(
            Ratio::of(
                ShareAmount::from(test.shares_to_mint),
                ShareAmount::from(test.vault_total_shares),
            ),
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert_eq!(Fraction::from(result), expected);
    }
}

#[test]
fn test_compute_aum_to_deposit_ceiling_rounding() {
    struct TestCase {
        vault_total_shares: u64,
        vault_total_holdings: f64,
        shares_to_mint: u64,
        expected_aum: f64,
    }

    let test_cases = vec![
        TestCase {
            vault_total_shares: 3,
            vault_total_holdings: 10.0,
            shares_to_mint: 1,               // 1/3 of shares
            expected_aum: 3.333333333333334, // Should ceil up
        },
        TestCase {
            vault_total_shares: 7,
            vault_total_holdings: 3.0,
            shares_to_mint: 1,                 // 1/7 of shares
            expected_aum: 0.42857142857142855, // Should ceil up
        },
        TestCase {
            vault_total_shares: 1000,
            vault_total_holdings: 333.0,
            shares_to_mint: 1,   // 0.1% of shares
            expected_aum: 0.333, // Should ceil up
        },
        TestCase {
            vault_total_shares: 999,
            vault_total_holdings: 1000.0,
            shares_to_mint: 1,               // Single share
            expected_aum: 1.001001001001001, // Should ceil up
        },
    ];

    for test in test_cases {
        let result = compute_aum_to_deposit_from_shares_to_mint(
            Ratio::of(
                ShareAmount::from(test.shares_to_mint),
                ShareAmount::from(test.vault_total_shares),
            ),
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert!(Fraction::from(result).abs_diff(expected) < EPSILON_F);
    }
}

#[test]
fn test_compute_aum_to_deposit_edge_cases() {
    // Zero shares to mint
    let result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(ShareAmount::from(0), ShareAmount::from(100_000_000)),
        DollarValue::from(Fraction::from_num(1000.0)),
    );
    assert_eq!(Fraction::from(result), Fraction::ZERO);

    // Tiny vault with large share mint
    let result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(ShareAmount::from(1_000_000), ShareAmount::from(1)),
        DollarValue::from(Fraction::from_num(1.0)),
    );
    assert_eq!(Fraction::from(result), Fraction::from_num(1_000_000.0));

    // Very large vault
    let result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(1_000_000),
            ShareAmount::from(u64::MAX / 2),
        ),
        DollarValue::from(Fraction::from_num(1_000_000_000.0)),
    );
    assert!(Fraction::from(result) > Fraction::ZERO);
    assert!(Fraction::from(result) < Fraction::from_num(1000.0)); // Should be tiny fraction
}

#[test]
fn test_compute_aum_to_deposit_precision_scenarios() {
    struct TestCase {
        vault_total_shares: u64,
        vault_total_holdings: f64,
        shares_to_mint: u64,
        expected_aum: f64,
    }

    let test_cases = vec![
        TestCase {
            vault_total_shares: 999_999_999,
            vault_total_holdings: 1_000_000_000.0,
            shares_to_mint: 1, // Tiny fraction
            expected_aum: 1.000000001,
        },
        TestCase {
            vault_total_shares: 777_777_777,
            vault_total_holdings: 12345.6789,
            shares_to_mint: 123_456,
            expected_aum: 1.95961903174,
        },
        TestCase {
            vault_total_shares: 1_000_000_000_000, // 1 trillion shares
            vault_total_holdings: 999.999,
            shares_to_mint: 1_000_000, // 1 millionth
            expected_aum: 0.000999999,
        },
    ];

    for test in test_cases {
        let result = compute_aum_to_deposit_from_shares_to_mint(
            Ratio::of(
                ShareAmount::from(test.shares_to_mint),
                ShareAmount::from(test.vault_total_shares),
            ),
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert!(Fraction::from(result).abs_diff(expected) < EPSILON_F);
    }
}

#[test]
fn test_compute_aum_to_deposit_mathematical_properties() {
    // Test proportionality: 2x shares = 2x AUM
    let base_result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        DollarValue::from(Fraction::from_num(1000.0)),
    );
    let double_result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(20_000_000),
            ShareAmount::from(100_000_000),
        ),
        DollarValue::from(Fraction::from_num(1000.0)),
    );
    assert_eq!(
        Fraction::from(double_result),
        Fraction::from(base_result) * Fraction::from_num(2)
    );

    // Test vault scaling: 2x vault holdings = 2x AUM per share
    let base_vault_result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        DollarValue::from(Fraction::from_num(1000.0)),
    );
    let double_vault_result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        DollarValue::from(Fraction::from_num(2000.0)),
    );
    assert_eq!(
        Fraction::from(double_vault_result),
        Fraction::from(base_vault_result) * Fraction::from_num(2)
    );

    // Test share dilution: 2x total shares = 0.5x AUM per share
    let base_shares_result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        DollarValue::from(Fraction::from_num(1000.0)),
    );
    let double_shares_result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(200_000_000),
        ),
        DollarValue::from(Fraction::from_num(1000.0)),
    );
    assert_eq!(
        Fraction::from(double_shares_result) * Fraction::from_num(2),
        Fraction::from(base_shares_result)
    );

    // Test ceiling property: result should be >= exact calculation
    let vault_shares = ShareAmount::from(3);
    let vault_holdings = DollarValue::from(Fraction::from_num(10.0));
    let shares_to_mint = ShareAmount::from(1);

    let result = compute_aum_to_deposit_from_shares_to_mint(
        Ratio::of(shares_to_mint, vault_shares),
        vault_holdings,
    );

    let exact_calculation =
        Fraction::from_num(10.0) * Fraction::from_num(1u64) / Fraction::from_num(3u64);
    assert!(Fraction::from(result) >= exact_calculation);
}

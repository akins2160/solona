use std::collections::HashMap;

use anchor_lang::prelude::Pubkey;
use kamino_lending::{fraction::Fraction, utils::FULL_BPS};
use proptest::prelude::*;

use crate::{
    operations::{
        effects::OpenWithdrawOrderEffects,
        order_basket::OrderBasket,
        rebalance_basket::RebalanceBasket,
        tests::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig},
        vault_operations::common::calculate_shares_to_burn,
        withdraw_order_operations::{open_withdraw_order, settle_withdraw_order, SettleMode},
    },
    order::WithdrawOrder,
    state::{MetavaultState, VaultToken},
    types::{
        DollarValue, Duration, MinFeeSpec, NetAum, Ratio, RebalanceLimits, RoundingMethod,
        ShareAmount, Timestamp, TokenAmount, TokenPrice, VaultTokenId, Weight,
    },
    utils::{
        consts::{MAX_TOKENS_PER_VAULT, YEAR},
        scope::VaultScopePrices,
    },
    GlobalConfig, KaminoVaultError,
};

const USDC: u64 = 1_000_000;
const SOL: u64 = 1_000_000_000;
const SHARE: u64 = 1_000_000;
const HOUR: u64 = 3600;

#[test]
fn test_half_the_shares_take_half_of_every_token() {
    // 1000 USDC + 10 SOL = $2000 behind 2000 shares: a thousand shares take 500 USDC + 5 SOL.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);

    let (order, effects) = fixture.open(1000 * SHARE, &[("USDC", 1)], NetAum::ZERO);

    assert_eq!(fixture.released(&order, "USDC"), 500 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 5 * SOL);
    assert_eq!(effects.released, order.base.locked_amounts.map(Into::into));
    assert_eq!(effects.shares_to_burn, ShareAmount::from(1000 * SHARE));
    assert_eq!(fixture.available("USDC"), 500 * USDC);
    assert_eq!(fixture.available("SOL"), 5 * SOL);
    assert_eq!(fixture.locked_total("USDC"), 500 * USDC);
    assert_eq!(fixture.locked_total("SOL"), 5 * SOL);
    assert_eq!(fixture.vault.shares_issued, 1000 * SHARE);
    assert_eq!(fixture.vault.rolling_withdraw_cap.accumulated_usd_sf, 0);
}

#[test]
fn test_the_slice_follows_the_holdings_not_the_weights() {
    // 1500 USDC against 10 SOL is 60/40 by value while the weights say 50/50: a fifth of the
    // shares takes a fifth of each token, leaving the vault exactly as tilted as it was.
    let mut fixture = vault(&[("USDC", 1500 * USDC), ("SOL", 10 * SOL)], 2500 * SHARE);

    let (order, _) = fixture.open(500 * SHARE, &[("USDC", 1), ("SOL", 1)], NetAum::ZERO);

    assert_eq!(fixture.released(&order, "USDC"), 300 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 2 * SOL);
    assert_eq!(fixture.available("USDC"), 1200 * USDC);
    assert_eq!(fixture.available("SOL"), 8 * SOL);
}

#[test]
fn test_obligations_value_is_served_from_the_liquid_holdings() {
    // $2000 liquid and $2000 in obligations behind 4000 shares: a quarter of the shares claims
    // $1000, which is half of everything liquid.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 4000 * SHARE);

    let (order, effects) = fixture.open(1000 * SHARE, &[("USDC", 1)], NetAum::from(dollars(2000)));

    assert_eq!(fixture.released(&order, "USDC"), 500 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 5 * SOL);
    assert_eq!(effects.shares_to_burn, ShareAmount::from(1000 * SHARE));
}

#[test]
fn test_a_claim_beyond_the_liquid_holdings_takes_them_all_and_burns_only_their_worth() {
    // $2000 liquid and $6000 in obligations behind 8000 shares: a quarter of the shares claims
    // exactly the liquid $2000; a share more takes the same, and only the 2000 shares that is
    // worth are burned (as with the plain withdraw, clamped to what is available).
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 8000 * SHARE);
    let obligations = NetAum::from(dollars(6000));

    let (order, effects) = fixture.open(2000 * SHARE + 1, &[("USDC", 1)], obligations);

    assert_eq!(fixture.released(&order, "USDC"), 1000 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 10 * SOL);
    assert_eq!(fixture.available("USDC"), 0);
    assert_eq!(fixture.available("SOL"), 0);
    assert_eq!(effects.shares_to_burn, ShareAmount::from(2000 * SHARE));
    assert_eq!(fixture.vault.shares_issued, 6000 * SHARE);
}

#[test]
fn test_withdrawal_fees_stay_in_the_vault_and_the_shares_pay_for_them() {
    // A 1% fee on USDC (the vault's) and 2% on everything (the global config's): the larger one
    // applies per leg, and the shares are burned for the gross slice, fees included - which is
    // also what the rolling withdraw cap counts.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    fixture.token_mut("USDC").withdraw_fee_bps = 100;
    fixture.config.withdrawal_fee_bps = 200;
    fixture.vault.rolling_withdraw_cap.max_usd_sf = dollars(5000).to_bits();
    fixture.vault.rolling_withdraw_cap.interval_seconds = HOUR;

    let (order, effects) = fixture.open(1000 * SHARE, &[("USDC", 1)], NetAum::ZERO);

    assert_eq!(fixture.released(&order, "USDC"), 490 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 49 * SOL / 10);
    assert_eq!(fixture.available("USDC"), 510 * USDC);
    assert_eq!(fixture.available("SOL"), 51 * SOL / 10);
    assert_eq!(effects.shares_to_burn, ShareAmount::from(1000 * SHARE));
    assert_eq!(
        fixture.vault.rolling_withdraw_cap.accumulated_usd_sf,
        dollars(1000).to_bits()
    );
}

#[test]
fn test_a_leg_not_worth_its_minimum_fee_is_all_fee() {
    // A tenth of a percent of the shares would take 0.01 SOL, under the 0.02 SOL minimum fee: that
    // leg is all fee, staying with the vault, and the shares pay for it as for the USDC leg.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    fixture.token_mut("SOL").withdraw_fee_lamports = 2 * SOL / 100;

    let (order, effects) = fixture.open(2 * SHARE, &[("USDC", 1)], NetAum::ZERO);

    assert_eq!(fixture.released(&order, "USDC"), USDC);
    assert_eq!(fixture.released(&order, "SOL"), 0);
    assert_eq!(fixture.available("SOL"), 10 * SOL);
    assert_eq!(effects.shares_to_burn, ShareAmount::from(2 * SHARE));
    assert_eq!(fixture.vault.shares_issued, 1998 * SHARE);
}

#[test]
fn test_weights_and_released_amounts_are_keyed_by_storage_index() {
    // The tokens sit in storage sorted by name (BTC, SOL, USDC); with the middle one disabled, the
    // dense inputs (one per enabled token) land on storage slots 0 and 2.
    let mut fixture = vault(
        &[("USDC", 1000 * USDC), ("SOL", 10 * SOL), ("BTC", 2_000_000)],
        4000 * SHARE,
    );
    fixture.disable("SOL");

    let (mut order, effects) = fixture.open(1000 * SHARE, &[("BTC", 3), ("USDC", 7)], NetAum::ZERO);

    // A quarter of the $2000 the two enabled tokens are worth: 0.005 BTC and 250 USDC.
    assert_eq!(order.weights, padded_to_storage([3, 0, 7]));
    assert_eq!(effects.released[0], TokenAmount::from(500_000));
    assert_eq!(effects.released[1], TokenAmount::ZERO);
    assert_eq!(effects.released[2], TokenAmount::from(250 * USDC));
    // The $500 basket auctioned 3:7: $150 of BTC and $350 of USDC.
    let targets = OrderBasket {
        order: &mut order,
        vault: &mut fixture.vault,
    }
    .tokens()
    .targets(&fixture.prices);
    assert_eq!(targets.of(fixture.id("BTC")), TokenAmount::from(300_000));
    assert_eq!(
        targets.of(fixture.id("USDC")),
        TokenAmount::from(350 * USDC)
    );
}

#[test]
fn test_open_accrues_the_management_fee_before_pricing_the_claim() {
    // 1% a year, a year since the last charge: the fee shares dilute the supply before the claim
    // is priced, so a thousand shares take a hair under half of every token.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    fixture.vault.management_fee_bps = 100;
    fixture.vault.last_fee_charge_timestamp = 1000;
    let now = Timestamp::from(1000 + u64::from(YEAR));

    let (order, effects) = fixture.open_at(1000 * SHARE, &[("USDC", 1)], NetAum::ZERO, now);

    let fee_shares = 2000 * SHARE / 99;
    assert_eq!(effects.fee_shares_to_mint, ShareAmount::from(fee_shares));
    assert_eq!(fixture.released(&order, "USDC"), 495 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 495 * SOL / 100);
    assert_eq!(effects.shares_to_burn, ShareAmount::from(1000 * SHARE));
    assert_eq!(fixture.vault.shares_issued, 1000 * SHARE + fee_shares);
    assert_eq!(fixture.vault.last_fee_charge_timestamp, u64::from(now));
    // The fee baseline follows the release, so the next charge sees no phantom loss.
    assert_eq!(
        fixture.vault.prev_aum(),
        fixture
            .vault
            .compute_free_aum(&fixture.prices, RoundingMethod::Floor)
    );
}

#[test]
fn test_a_floor_on_any_token_out_refuses_an_open_releasing_less_of_it() {
    // A thousand of 2000 shares take 500 USDC + 5 SOL: a lamport more of USDC asked refuses the
    // open (nothing moves), exactly the legs asked are met.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);

    let res = fixture.try_open_with_min_tokens_out(1000 * SHARE, &[("USDC", 500 * USDC + 1)]);
    assert_eq!(res.unwrap_err(), KaminoVaultError::SlippageExceeded.into());
    assert_eq!(fixture.available("USDC"), 1000 * USDC);
    assert_eq!(fixture.vault.shares_issued, 2000 * SHARE);

    let (order, effects) = fixture
        .try_open_with_min_tokens_out(1000 * SHARE, &[("USDC", 500 * USDC), ("SOL", 5 * SOL)])
        .unwrap();
    assert_eq!(fixture.released(&order, "USDC"), 500 * USDC);
    assert_eq!(fixture.released(&order, "SOL"), 5 * SOL);
    assert_eq!(effects.shares_to_burn, ShareAmount::from(1000 * SHARE));
}

#[test]
fn test_the_floor_on_tokens_out_takes_one_entry_per_enabled_token() {
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    let mut order = WithdrawOrder::new(Pubkey::new_unique(), Pubkey::new_unique(), 0);

    let res = open_withdraw_order(
        &mut order,
        &mut fixture.vault,
        &fixture.prices,
        NetAum::ZERO,
        &fixture.config,
        ShareAmount::from(1000 * SHARE),
        &[Weight::from(1), Weight::from(1)],
        Duration::from_secs(HOUR),
        no_limits(),
        &[TokenAmount::ZERO],
        Timestamp::ZERO,
    );

    assert_eq!(
        res.unwrap_err(),
        KaminoVaultError::TokenArrayLengthMismatch.into()
    );
    assert_eq!(fixture.vault.shares_issued, 2000 * SHARE);
}

#[test]
fn test_open_closes_the_vaults_own_rebalance_once_its_window_is_over() {
    // A vault off its weights, mid-rebalance: an open within the window leaves it running, one
    // past the window closes it (the entry point every AUM-touching instruction shares).
    let mut fixture = vault(&[("USDC", 1500 * USDC), ("SOL", 10 * SOL)], 2500 * SHARE);
    fixture.vault.rebalance.start_timestamp = 0;
    fixture.vault.rebalance.end_timestamp = 100;

    fixture.open_at(
        100 * SHARE,
        &[("USDC", 1)],
        NetAum::ZERO,
        Timestamp::from(50),
    );
    assert_eq!(fixture.vault.rebalance.end_timestamp, 100);

    fixture.open_at(
        100 * SHARE,
        &[("USDC", 1)],
        NetAum::ZERO,
        Timestamp::from(100),
    );
    assert_eq!(fixture.vault.rebalance.end_timestamp, 0);
}

#[test]
fn test_open_refuses_what_it_cannot_serve() {
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    let usdc_only: &[(&str, u64)] = &[("USDC", 1)];
    let errors = |fixture: &mut Fixture, shares, weights, obligations, duration| {
        fixture
            .try_open(shares, weights, obligations, duration)
            .unwrap_err()
    };

    assert_eq!(
        errors(&mut fixture, 1000 * SHARE, &[], NetAum::ZERO, HOUR),
        KaminoVaultError::InvalidWeightsSum.into()
    );
    assert_eq!(
        errors(
            &mut fixture,
            1000 * SHARE,
            &[("USDC", u64::MAX), ("SOL", 1)],
            NetAum::ZERO,
            HOUR
        ),
        KaminoVaultError::InvalidWeightsSum.into()
    );
    for duration in [299, 86_401] {
        // A fresh vault each (the release runs first, and only a transaction's revert undoes it):
        let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
        assert_eq!(
            errors(
                &mut fixture,
                1000 * SHARE,
                usdc_only,
                NetAum::ZERO,
                duration
            ),
            KaminoVaultError::InvalidOrderAuctionDuration.into()
        );
    }
    assert_eq!(
        errors(&mut fixture, 0, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::CannotWithdrawZeroShares.into()
    );
    assert_eq!(
        errors(&mut fixture, 2001 * SHARE, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::WithdrawSharesExceedIssued.into()
    );
    assert_eq!(
        errors(
            &mut fixture,
            1000 * SHARE,
            usdc_only,
            NetAum::ZERO - NetAum::from(dollars(3000)),
            HOUR
        ),
        KaminoVaultError::VaultAUMZero.into()
    );
    fixture.vault.order_min_open_usd_sf = dollars(1001).to_bits();
    assert_eq!(
        errors(&mut fixture, 1000 * SHARE, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::OrderBelowMinValue.into()
    );
    fixture.vault.order_min_open_usd_sf = 0;
    fixture.vault.block_withdraws = 1;
    assert_eq!(
        errors(&mut fixture, 1000 * SHARE, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::VaultWithdrawsBlocked.into()
    );
    fixture.vault.block_withdraws = 0;
    fixture.vault.withdraw_order_creation_enabled = 0;
    assert_eq!(
        errors(&mut fixture, 1000 * SHARE, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::WithdrawOrderCreationDisabled.into()
    );

    // A share of a vault holding a lamport is not worth a lamport of anything.
    let mut fixture = vault(&[("USDC", 1)], 1_000_000_000_000_000);
    assert_eq!(
        errors(&mut fixture, 1, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::CannotWithdrawZeroLamports.into()
    );
    // Legs that are all fee leave nothing to open with.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    fixture.config.withdrawal_fee_lamports = SOL;
    assert_eq!(
        errors(&mut fixture, 2 * SHARE, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::WithdrawAmountLessThanWithdrawalFee.into()
    );
    let mut fixture = vault(&[("USDC", 1000 * USDC)], 0);
    assert_eq!(
        errors(&mut fixture, 1, usdc_only, NetAum::ZERO, HOUR),
        KaminoVaultError::VaultSharesZero.into()
    );
}

#[test]
fn test_settle_is_the_owners_alone_while_the_auction_runs() {
    // The order sells its SOL leg for USDC; mid-window it can still be filled, so a stranger may
    // not end it; its owner may.
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    let (mut order, _) = fixture.open(1000 * SHARE, &[("USDC", 1)], NetAum::ZERO);
    let mid_auction = Timestamp::from(1800);

    let res = settle_withdraw_order(
        &mut order,
        &mut fixture.vault,
        &SettleMode::Permissionless(fixture.prices.clone()),
        mid_auction,
    );
    assert_eq!(
        res.unwrap_err(),
        KaminoVaultError::OrderAuctionStillRunning.into()
    );
    assert_eq!(fixture.released(&order, "USDC"), 500 * USDC);

    let effects = settle_withdraw_order(
        &mut order,
        &mut fixture.vault,
        &SettleMode::ByOwner,
        mid_auction,
    )
    .unwrap();
    assert!(effects.mid_auction);
    assert_eq!(
        effects.payouts[fixture.storage_index("USDC")],
        (500 * USDC).into()
    );
    assert_eq!(
        effects.payouts[fixture.storage_index("SOL")],
        (5 * SOL).into()
    );
    assert_eq!(fixture.released(&order, "USDC"), 0);
    assert_eq!(fixture.locked_total("USDC"), 0);
    assert_eq!(fixture.locked_total("SOL"), 0);
}

#[test]
fn test_settle_is_anyones_once_the_auction_is_over() {
    let mut fixture = vault(&[("USDC", 1000 * USDC), ("SOL", 10 * SOL)], 2000 * SHARE);
    let (mut expired, _) = fixture.open(500 * SHARE, &[("USDC", 1)], NetAum::ZERO);
    let (mut stranded, _) = fixture.open(500 * SHARE, &[("USDC", 1)], NetAum::ZERO);
    let mid_auction = Timestamp::from(1800);

    // Past the window (its end excluded), the clock alone says so, whatever the prices show.
    let effects = settle_withdraw_order(
        &mut expired,
        &mut fixture.vault,
        &SettleMode::Permissionless(fixture.prices.clone()),
        Timestamp::from(HOUR),
    )
    .unwrap();
    assert!(!effects.mid_auction);
    assert_eq!(
        effects.payouts[fixture.storage_index("USDC")],
        (250 * USDC).into()
    );

    // Inside it, the prices must show that no fill could improve the basket any more: here SOL falls
    // to worthless, so the USDC the basket lacks goes under the settled tolerance.
    let res = settle_withdraw_order(
        &mut stranded,
        &mut fixture.vault,
        &SettleMode::Permissionless(fixture.prices.clone()),
        mid_auction,
    );
    assert_eq!(
        res.unwrap_err(),
        KaminoVaultError::OrderAuctionStillRunning.into()
    );
    let sol = fixture.id("SOL").input_account_index;
    fixture.prices.prices[sol] = TokenPrice::new(Fraction::from_num(0.000_001), 9);
    let sol_leg = fixture.released(&stranded, "SOL");
    let effects = settle_withdraw_order(
        &mut stranded,
        &mut fixture.vault,
        &SettleMode::Permissionless(fixture.prices.clone()),
        mid_auction,
    )
    .unwrap();
    assert!(!effects.mid_auction);
    assert_eq!(
        effects.payouts[fixture.storage_index("SOL")],
        sol_leg.into()
    );
    assert_eq!(fixture.locked_total("USDC"), 0);
    assert_eq!(fixture.locked_total("SOL"), 0);
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(2_000))]

    #[test]
    fn test_every_release_is_pro_rata_and_paid_for(
        // Lamports available of USDC (6 decimals, $1), SOL (9 decimals, $100) and BTC (8, $50k).
        available in (1_u64..10_u64.pow(12), 1_u64..10_u64.pow(12), 1_u64..10_u64.pow(9)),
        shares_issued in 1_u64..10_u64.pow(12),
        shares_asked in 1_u64..10_u64.pow(12),
        obligations_dollars in 0_u64..1_000_000,
        global_fee_bps in 0_u64..500,
        token_fee_bps in 0_u64..500,
    ) {
        let (usdc, sol, btc) = available;
        let holdings = [("USDC", usdc), ("SOL", sol), ("BTC", btc)];
        let mut fixture = vault(&holdings, shares_issued);
        fixture.config.withdrawal_fee_bps = global_fee_bps;
        fixture.token_mut("SOL").withdraw_fee_bps = token_fee_bps;
        let shares = shares_asked.min(shares_issued);
        let obligations = NetAum::from(dollars(obligations_dollars));
        let free_aum = fixture.vault.compute_free_aum(&fixture.prices, RoundingMethod::Floor);
        let net_aum = fixture
            .vault
            .compute_net_aum(&fixture.prices, obligations, RoundingMethod::Floor)
            .check_positive()
            .unwrap();
        let claim = net_aum.apply_ratio(
            Ratio::of(ShareAmount::from(shares), ShareAmount::from(shares_issued)),
            RoundingMethod::Floor,
        );

        let (order, effects) = match fixture.try_open(shares, &[("USDC", 1)], obligations, HOUR) {
            Ok(opened) => opened,
            Err(err) => {
                // Refused for exactly one of two reasons: the shares claim nothing, or nothing is
                // worth a lamport (of any token, or after the fees).
                let expected = if claim.is_zero() {
                    KaminoVaultError::CannotWithdrawZeroLamports
                } else {
                    KaminoVaultError::WithdrawAmountLessThanWithdrawalFee
                };
                prop_assert_eq!(err, expected.into());
                return Ok(());
            }
        };

        // Pro-rata: every net leg is `before * fraction * (1 - fee)`, up to two lamports of
        // rounding (the gross floor, the fee ceiling), so any two legs with the same fee are in
        // the ratio of the holdings up to that.
        let fee_bps = |name: &str| {
            if name == "SOL" {
                token_fee_bps.max(global_fee_bps)
            } else {
                global_fee_bps
            }
        };
        let legs: Vec<(u64, u64, u64)> = holdings
            .iter()
            .map(|(name, before)| (*before, fixture.released(&order, name), fee_bps(name)))
            .collect();
        for (i, &(before_i, net_i, fee_i)) in legs.iter().enumerate() {
            for &(before_j, net_j, fee_j) in &legs[i + 1..] {
                if fee_i != fee_j || net_i == 0 || net_j == 0 {
                    continue; // skipped legs and differently-fee'd legs are not proportional
                }
                let lhs = u128::from(net_i) * u128::from(before_j);
                let rhs = u128::from(net_j) * u128::from(before_i);
                let slack = 2 * (u128::from(before_i) + u128::from(before_j));
                prop_assert!(
                    lhs.abs_diff(rhs) <= slack,
                    "legs {net_i}/{before_i} and {net_j}/{before_j} are not pro-rata"
                );
            }
        }

        // Paid for: never more shares than asked, and never fewer than the value the order got is
        // worth (the difference being the fees, and the rounding, which favour the vault).
        prop_assert!(effects.shares_to_burn <= ShareAmount::from(shares));
        let mut net_value = DollarValue::ZERO;
        for (name, _) in &holdings {
            net_value = net_value.saturating_add(fixture.value_of(name, &order));
        }
        let fair_burn = calculate_shares_to_burn(
            Ratio::of(net_value, net_aum),
            ShareAmount::from(shares_issued),
        );
        prop_assert!(effects.shares_to_burn >= fair_burn);

        // Accounted: what left the vault's available is exactly what the order holds.
        for (name, before) in &holdings {
            prop_assert_eq!(fixture.locked_total(name), fixture.released(&order, name));
            prop_assert_eq!(fixture.available(name) + fixture.released(&order, name), *before);
        }

        // Clamped: a claim beyond the liquid holdings takes every leg whole, less its fee (which
        // may be all of it).
        if claim >= free_aum {
            for (name, before) in &holdings {
                let before = TokenAmount::from(*before);
                let fee = MinFeeSpec::combine_max(
                    fixture.config.withdrawal_fee_spec(),
                    fixture.vault.vault_tokens[fixture.storage_index(name)].withdrawal_fee_spec(),
                )
                .calculate_fee_from(before)
                .min(before);
                prop_assert_eq!(fixture.available(name), u64::from(fee));
            }
        }
    }
}

// A vault of USDC ($1, 6 decimals), SOL ($100, 9) and BTC ($50k, 8), or a subset, with the given
// lamports available at equal weights, `shares_issued` shares out, withdraw orders enabled.
struct Fixture {
    vault: MetavaultState,
    prices: VaultScopePrices,
    config: GlobalConfig,
    mints: HashMap<String, Pubkey>,
}

impl Fixture {
    fn open(
        &mut self,
        shares: u64,
        weights: &[(&str, u64)],
        obligations_aum: NetAum,
    ) -> (WithdrawOrder, OpenWithdrawOrderEffects) {
        self.open_at(shares, weights, obligations_aum, Timestamp::ZERO)
    }

    fn open_at(
        &mut self,
        shares: u64,
        weights: &[(&str, u64)],
        obligations_aum: NetAum,
        now: Timestamp,
    ) -> (WithdrawOrder, OpenWithdrawOrderEffects) {
        self.try_open_at(shares, weights, obligations_aum, HOUR, now, &[])
            .unwrap()
    }

    fn try_open(
        &mut self,
        shares: u64,
        weights: &[(&str, u64)],
        obligations_aum: NetAum,
        duration_seconds: u64,
    ) -> anchor_lang::Result<(WithdrawOrder, OpenWithdrawOrderEffects)> {
        self.try_open_at(
            shares,
            weights,
            obligations_aum,
            duration_seconds,
            Timestamp::ZERO,
            &[],
        )
    }

    fn try_open_with_min_tokens_out(
        &mut self,
        shares: u64,
        min_tokens_out: &[(&str, u64)],
    ) -> anchor_lang::Result<(WithdrawOrder, OpenWithdrawOrderEffects)> {
        let weights = [("USDC", 1)];
        self.try_open_at(
            shares,
            &weights,
            NetAum::ZERO,
            HOUR,
            Timestamp::ZERO,
            min_tokens_out,
        )
    }

    fn try_open_at(
        &mut self,
        shares: u64,
        weights: &[(&str, u64)],
        obligations_aum: NetAum,
        duration_seconds: u64,
        now: Timestamp,
        min_tokens_out: &[(&str, u64)],
    ) -> anchor_lang::Result<(WithdrawOrder, OpenWithdrawOrderEffects)> {
        let dense: Vec<Weight> = self
            .vault
            .iter_enabled_tokens()
            .map(|token| {
                weights
                    .iter()
                    .find(|(name, _)| self.mints[*name] == token.mint)
                    .map_or(0, |(_, weight)| *weight)
                    .into()
            })
            .collect();
        let dense_min_tokens_out: Vec<TokenAmount> = self
            .vault
            .iter_enabled_tokens()
            .map(|token| {
                min_tokens_out
                    .iter()
                    .find(|(name, _)| self.mints[*name] == token.mint)
                    .map_or(0, |(_, amount)| *amount)
                    .into()
            })
            .collect();
        let mut order = WithdrawOrder::new(Pubkey::new_unique(), Pubkey::new_unique(), 0);
        let effects = open_withdraw_order(
            &mut order,
            &mut self.vault,
            &self.prices,
            obligations_aum,
            &self.config,
            ShareAmount::from(shares),
            &dense,
            Duration::from_secs(duration_seconds),
            no_limits(),
            &dense_min_tokens_out,
            now,
        )?;
        Ok((order, effects))
    }

    fn storage_index(&self, name: &str) -> usize {
        self.vault
            .vault_tokens
            .iter()
            .position(|token| token.mint == self.mints[name])
            .unwrap()
    }

    fn id(&self, name: &str) -> VaultTokenId {
        self.vault
            .get_vault_token_id_by_mint(&self.mints[name])
            .unwrap()
    }

    fn token_mut(&mut self, name: &str) -> &mut VaultToken {
        let index = self.storage_index(name);
        &mut self.vault.vault_tokens[index]
    }

    // Disables the token, as its removal does: its slot is dead and its price is no longer passed.
    fn disable(&mut self, name: &str) {
        let input_index = self.id(name).input_account_index;
        self.token_mut(name).mint = Pubkey::default();
        self.prices.prices.remove(input_index);
    }

    fn released(&self, order: &WithdrawOrder, name: &str) -> u64 {
        order.base.locked_amounts[self.storage_index(name)]
    }

    fn value_of(&self, name: &str, order: &WithdrawOrder) -> DollarValue {
        TokenAmount::from(order.base.locked_amounts[self.storage_index(name)])
            .to_aum(self.prices.by_id(self.id(name)), RoundingMethod::Floor)
    }

    fn available(&self, name: &str) -> u64 {
        self.vault.vault_tokens[self.storage_index(name)]
            .available()
            .into()
    }

    fn locked_total(&self, name: &str) -> u64 {
        self.vault.vault_tokens[self.storage_index(name)].locked_total
    }
}

fn vault(available: &[(&str, u64)], shares_issued: u64) -> Fixture {
    let specs: HashMap<&str, (f64, u8)> = HashMap::from([
        ("USDC", (1.0, 6)),
        ("SOL", (100.0, 9)),
        ("BTC", (50_000.0, 8)),
    ]);
    let configs: HashMap<&str, TokenConfig> = available
        .iter()
        .map(|(name, _)| {
            let (price, decimals) = specs[*name];
            (*name, TokenConfig::with_price_and_decimals(price, decimals))
        })
        .collect();
    let (mut vault, prices) = setup_vault_with_tokens(&configs);
    for (name, lamports) in available {
        let mint = configs[*name].mint;
        let token = vault
            .vault_tokens
            .iter_mut()
            .find(|token| token.mint == mint)
            .unwrap();
        token.token_available = *lamports;
        token.weight = 1;
    }
    vault.shares_issued = shares_issued;
    vault.withdraw_order_creation_enabled = 1;
    Fixture {
        vault,
        prices,
        config: GlobalConfig::default(),
        mints: configs
            .iter()
            .map(|(name, config)| (name.to_string(), config.mint))
            .collect(),
    }
}

fn padded_to_storage(weights: [u64; 3]) -> [u64; MAX_TOKENS_PER_VAULT] {
    let mut by_storage = [0; MAX_TOKENS_PER_VAULT];
    by_storage[..3].copy_from_slice(&weights);
    by_storage
}

fn dollars(value: u64) -> DollarValue {
    DollarValue::from(Fraction::from_num(value))
}

fn no_limits() -> RebalanceLimits {
    RebalanceLimits {
        max_fill_slippage_bps: u64::from(FULL_BPS),
        max_loss_bps: u64::from(FULL_BPS),
    }
}

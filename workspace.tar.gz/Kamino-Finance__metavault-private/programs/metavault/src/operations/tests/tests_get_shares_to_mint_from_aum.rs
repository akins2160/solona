use kamino_lending::{fraction::Fraction, utils::FractionExtra};
use proptest::prelude::*;

use crate::operations::vault_operations::common::get_shares_to_mint_from_aum;
use crate::types::{DollarValue, Ratio, ShareAmount};
use kamino_lending::assert_fuzzy_eq;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1_000_000))]
    #[test]
    fn test_get_shares_to_mint_from_aum_fuzzing(
        holdings_aum in 10.0_f64..100_000_000.0,
        deposit_aum in 1.0_f64..1_000_000.0,
        shares_issued in 100_u64..100_000_000_000) {

        let holdings_aum_frac = Fraction::from_num(holdings_aum);
        let deposit_aum_frac = Fraction::from_num(deposit_aum);

        let shares_to_mint = get_shares_to_mint_from_aum(
            Ratio::of(
                DollarValue::from(deposit_aum_frac),
                DollarValue::from(holdings_aum_frac),
            ),
            ShareAmount::from(shares_issued),
        );

        let expected_shares_to_mint = test_compute_shares_to_mint_from_aum(
            holdings_aum_frac,
            deposit_aum_frac,
            shares_issued,
        );

        // Allow 1 lamport diff due to rounding precision
        assert_fuzzy_eq!(u64::from(shares_to_mint), expected_shares_to_mint, 1);
    }
}

#[test]
fn test_standard_proportional_minting() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(100.0)),
            DollarValue::from(Fraction::from_num(1000.0)),
        ),
        ShareAmount::from(100_000_000),
    );

    // $100 deposit into $1000 vault should mint 10% of existing shares
    // (100 shares * $100 deposit) / $1000 vault = 10 shares
    assert_eq!(result, ShareAmount::from(10_000_000)); // 10 shares
}

#[test]
fn test_zero_deposit_aum() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::ZERO),
            DollarValue::from(Fraction::from_num(1000.0)),
        ),
        ShareAmount::from(100_000_000),
    );

    // Zero deposit should mint zero shares
    assert_eq!(result, ShareAmount::from(0));
}

#[test]
fn test_equal_deposit_and_holdings() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(500.0)),
            DollarValue::from(Fraction::from_num(500.0)),
        ),
        ShareAmount::from(75_000_000),
    );

    // Doubling vault AUM should mint equal shares to existing
    // (75 shares * $500 deposit) / $500 vault = 75 shares
    assert_eq!(result, ShareAmount::from(75_000_000)); // 75 shares
}

#[test]
fn test_massive_deposit() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(10000.0)),
            DollarValue::from(Fraction::from_num(100.0)),
        ),
        ShareAmount::from(20_000_000),
    );

    // 100x deposit should mint 100x shares
    // (20 shares * $10,000 deposit) / $100 vault = 2000 shares
    assert_eq!(result, ShareAmount::from(2_000_000_000)); // 2000 shares
}

#[test]
fn test_tiny_deposit() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(0.001)),
            DollarValue::from(Fraction::from_num(1_000_000.0)),
        ),
        ShareAmount::from(1_000_000_000_000),
    );

    // Tiny deposit into massive vault should still mint some shares
    // (1T shares * $0.001) / $1M = 1_000 shares
    assert_eq!(result, ShareAmount::from(1_000));
}

#[test]
fn test_precision_edge_cases() {
    struct TestCase {
        holdings_aum: f64,
        deposit_aum: f64,
        shares_issued: u64,
        expected_shares: u64,
        description: &'static str,
    }

    let test_cases = vec![
        TestCase {
            holdings_aum: 3.0,
            deposit_aum: 1.0,
            shares_issued: 7,
            expected_shares: 2, // floor(7 * 1 / 3) = floor(2.333) = 2
            description: "Fractional result gets floored",
        },
        TestCase {
            holdings_aum: 1.0,
            deposit_aum: 1.0,
            shares_issued: 1,
            expected_shares: 1, // 1 * 1 / 1 = 1
            description: "Exact proportional match",
        },
        TestCase {
            holdings_aum: 1000.0,
            deposit_aum: 0.999,
            shares_issued: 1000,
            expected_shares: 0, // floor(1000 * 0.999 / 1000) = 0 due to precision
            description: "Just under 1:1 ratio",
        },
        TestCase {
            holdings_aum: 1000.0,
            deposit_aum: 1.001,
            shares_issued: 1000,
            expected_shares: 1, // floor(1000 * 1.001 / 1000) = 1
            description: "Just over 1:1 ratio gets floored",
        },
    ];

    for test in test_cases {
        let result = get_shares_to_mint_from_aum(
            Ratio::of(
                DollarValue::from(Fraction::from_num(test.deposit_aum)),
                DollarValue::from(Fraction::from_num(test.holdings_aum)),
            ),
            ShareAmount::from(test.shares_issued),
        );

        assert_eq!(
            result,
            ShareAmount::from(test.expected_shares),
            "{}",
            test.description
        );
    }
}

#[test]
fn test_rounding_behavior_consistency() {
    // Test that we consistently use floor rounding
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(2.0)),
            DollarValue::from(Fraction::from_num(7.0)),
        ),
        ShareAmount::from(10),
    );

    // (10 shares * $2 deposit) / $7 vault = 2.857... shares
    // Floor rounding should give us 2 shares
    assert_eq!(result, ShareAmount::from(2));
}

#[test]
fn test_various_scale_scenarios() {
    struct TestCase {
        vault_scale: u64,
        deposit_scale: u64,
        shares_scale: u64,
        expected_ratio: f64,
    }

    let test_cases = vec![
        TestCase {
            vault_scale: 1,
            deposit_scale: 1,
            shares_scale: 1,
            expected_ratio: 1.0, // 1:1:1 ratio
        },
        TestCase {
            vault_scale: 100,
            deposit_scale: 10,
            shares_scale: 50,
            expected_ratio: 0.1, // 10/100 = 0.1, expect 5 shares (50 * 0.1)
        },
        TestCase {
            vault_scale: 1000,
            deposit_scale: 500,
            shares_scale: 200,
            expected_ratio: 0.5, // 500/1000 = 0.5, expect 100 shares (200 * 0.5)
        },
    ];

    for test in test_cases {
        let result = get_shares_to_mint_from_aum(
            Ratio::of(
                DollarValue::from(Fraction::from_num(test.deposit_scale)),
                DollarValue::from(Fraction::from_num(test.vault_scale)),
            ),
            ShareAmount::from(test.shares_scale),
        );

        let expected = (test.shares_scale as f64 * test.expected_ratio) as u64;
        assert_eq!(result, ShareAmount::from(expected));
    }
}

#[test]
fn test_large_number_scenarios() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(1_000_000_000.0)),
            DollarValue::from(Fraction::from_num(1_000_000_000_000.0)),
        ),
        ShareAmount::from(u64::MAX),
    );

    // Should handle large numbers without overflow
    // $1B / $1T = 0.001, expect 0.001 * u64::MAX, but with precision loss
    let expected = ((u64::MAX as f64) * 0.001) as u64;
    // Allow for precision differences due to fixed-point arithmetic
    assert_fuzzy_eq!(u64::from(result), expected, 1);
}

#[test]
fn test_minimum_vault_scenarios() {
    struct TestCase {
        holdings_aum: f64,
        deposit_aum: f64,
        shares_issued: u64,
        expected_minimum: u64,
    }

    let test_cases = vec![
        TestCase {
            holdings_aum: 0.000001, // Tiny vault
            deposit_aum: 0.000001,  // Matching deposit
            shares_issued: 1,
            expected_minimum: 1,
        },
        TestCase {
            holdings_aum: 0.000001, // Tiny vault
            deposit_aum: 0.000002,  // Double the vault
            shares_issued: 1,
            expected_minimum: 2,
        },
    ];

    for test in test_cases {
        let result = get_shares_to_mint_from_aum(
            Ratio::of(
                DollarValue::from(Fraction::from_num(test.deposit_aum)),
                DollarValue::from(Fraction::from_num(test.holdings_aum)),
            ),
            ShareAmount::from(test.shares_issued),
        );

        assert_eq!(result, ShareAmount::from(test.expected_minimum));
    }
}

#[test]
fn test_economic_invariants() {
    // Test that proportional deposits maintain economic invariants
    let base_deposit = DollarValue::from(Fraction::from_num(100.0));
    let base_vault = DollarValue::from(Fraction::from_num(1000.0));
    let base_shares = ShareAmount::from(100_000_000);

    let base_result = get_shares_to_mint_from_aum(Ratio::of(base_deposit, base_vault), base_shares);

    // Doubling everything should maintain the same proportion
    let double_result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from(base_deposit) * Fraction::from_num(2.0)),
            DollarValue::from(Fraction::from(base_vault) * Fraction::from_num(2.0)),
        ),
        ShareAmount::from(u64::from(base_shares) * 2),
    );

    // Should mint proportionally more shares
    assert_eq!(double_result, ShareAmount::from(u64::from(base_result) * 2));
}

#[test]
fn test_deposit_larger_than_vault() {
    let result = get_shares_to_mint_from_aum(
        Ratio::of(
            DollarValue::from(Fraction::from_num(1000.0)),
            DollarValue::from(Fraction::from_num(100.0)),
        ),
        ShareAmount::from(50_000_000),
    );

    // Depositing 10x vault value should mint 10x existing shares
    assert_eq!(result, ShareAmount::from(500_000_000)); // 500 shares
}

fn test_compute_shares_to_mint_from_aum(
    holdings_aum: Fraction,
    deposit_aum: Fraction,
    shares_issued: u64,
) -> u64 {
    if shares_issued == 0 {
        return deposit_aum.to_floor();
    }

    let shares_to_mint_f = (Fraction::from(shares_issued) * deposit_aum) / holdings_aum;
    shares_to_mint_f.to_floor()
}

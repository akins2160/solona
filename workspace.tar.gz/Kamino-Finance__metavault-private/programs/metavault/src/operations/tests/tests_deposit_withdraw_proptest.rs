use crate::types::RoundingMethod;
use std::collections::HashMap;

use proptest::prelude::*;

use super::tests_utils::{fixtures::setup_vault_with_tokens_and_config, TokenConfig};
use crate::operations::tests::tests_utils::EPSILON_F;
use crate::operations::vault_operations;
use crate::types::{DollarValue, NetAum, ShareAmount, Timestamp, TokenAmount};
use crate::KaminoVaultError;
use anchor_lang::err;
use kamino_lending::assert_fuzzy_eq_f;
use kamino_lending::fraction::Fraction;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1_000_000))]

    #[test]
    fn test_deposit_prev_aum_invariant(
        price_usdc in 0.1_f64..1000.0,
        price_sol in 0.1_f64..1000.0,
        price_btc in 1.0_f64..10000.0,
        decimals_usdc in 4_u8..9,
        decimals_sol in 4_u8..9,
        decimals_btc in 4_u8..9,
        deposit_amounts in prop::collection::vec(10000_u64..1_000_000_000, 3),
        deposit_fee_lamports in 0_u64..100_000,
        deposit_fee_bps in 0_u64..500,
    ) {
        let tokens = HashMap::from_iter([
            ("BTC", TokenConfig::with_price_and_decimals(price_btc, decimals_btc)),
            ("SOL", TokenConfig::with_price_and_decimals(price_sol, decimals_sol)),
            ("USDC", TokenConfig::with_price_and_decimals(price_usdc, decimals_usdc)),
        ]);
        let (mut vault, mut global_config, vault_scope_prices) = setup_vault_with_tokens_and_config(
            &tokens, 0, 0,
        );

        global_config.deposit_fee_lamports = deposit_fee_lamports;
        global_config.deposit_fee_bps = deposit_fee_bps;

        // Set small fixed fees: 0.5% management fee and 10% performance fee
        vault.management_fee_bps = 50; // 0.5%
        vault.performance_fee_bps = 1000; // 10%

        let token_names = ["BTC", "SOL", "USDC"];
        let token_configs: Vec<_> = token_names.iter().map(|&name| &tokens[name]).collect();

        let mut timestamp = 0_u64;
        for (i, &deposit_amount) in deposit_amounts.iter().enumerate() {
            timestamp += 3600; // Advance by 1 hour for each deposit
            let token_mint = token_configs[i].mint;
            let result = vault_operations::deposit(
                &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config,
                token_mint, TokenAmount::new(deposit_amount), Timestamp::from(timestamp),
            );

            if result.is_ok() {
                let computed_aum_after = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
                let prev_aum = Fraction::from(vault.prev_aum());
                assert_fuzzy_eq_f!(prev_aum, computed_aum_after, EPSILON_F);
            }
        }
    }

    #[test]
    fn test_withdraw_prev_aum_invariant(
        price_usdc in 0.1_f64..1000.0,
        price_sol in 0.1_f64..1000.0,
        price_btc in 1.0_f64..10000.0,
        decimals_usdc in 4_u8..9,
        decimals_sol in 4_u8..9,
        decimals_btc in 4_u8..9,
        initial_deposits in prop::collection::vec(10000_u64..10_000_000_000, 3),
        withdraw_shares_pct in prop::collection::vec(1_u64..20, 1..5),
        withdrawal_fee_lamports in 0_u64..100_000,
        withdrawal_fee_bps in 0_u64..500,
    ) {
        let tokens = HashMap::from_iter([
            ("BTC", TokenConfig::with_price_and_decimals(price_btc, decimals_btc)),
            ("SOL", TokenConfig::with_price_and_decimals(price_sol, decimals_sol)),
            ("USDC", TokenConfig::with_price_and_decimals(price_usdc, decimals_usdc)),
        ]);
        let (mut vault, global_config, vault_scope_prices) = setup_vault_with_tokens_and_config(
            &tokens, withdrawal_fee_lamports, withdrawal_fee_bps,
        );

        // Set small fixed fees: 0.5% management fee and 10% performance fee
        vault.management_fee_bps = 50; // 0.5%
        vault.performance_fee_bps = 1000; // 10%

        let token_names = ["BTC", "SOL", "USDC"];
        let token_configs: Vec<_> = token_names.iter().map(|&name| &tokens[name]).collect();

        let mut timestamp = 0_u64;
        let mut total_shares = 0_u64;
        let deposit_config = crate::GlobalConfig::default();
        for (i, &deposit_amount) in initial_deposits.iter().enumerate() {
            timestamp += 3600;
            let token_mint = token_configs[i].mint;
            let result = vault_operations::deposit(
                &mut vault, &vault_scope_prices, NetAum::ZERO, &deposit_config,
                token_mint, TokenAmount::new(deposit_amount), Timestamp::from(timestamp),
            );
            if let Ok(effects) = result {
                total_shares += u64::from(effects.shares_to_mint);
            }
        }

        if total_shares == 0 {
            return Ok(());
        }

        for (i, &withdraw_pct) in withdraw_shares_pct.iter().enumerate() {
            timestamp += 3600;
            let token_mint = token_configs[i % 3].mint;
            let shares_to_withdraw = (total_shares as u128 * withdraw_pct as u128 / 100) as u64;
            if shares_to_withdraw == 0 {
                continue;
            }

            let shares_to_withdraw = shares_to_withdraw.min(vault.shares_issued);
            let result = vault_operations::withdraw(
                &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config,
                token_mint, Timestamp::from(timestamp), ShareAmount::new(shares_to_withdraw),
            );

            if result.is_ok() {
                let computed_aum_after = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
                let prev_aum = Fraction::from(vault.prev_aum());
                assert_fuzzy_eq_f!(prev_aum, computed_aum_after, EPSILON_F);
            }
        }
    }
}

proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn test_multi_user_fairness_deposit_withdraw(
        price_f in 0.1_f64..10_000.0,
        decimals in 4_u8..10,
        deposit_amount in 10_000_u64..100_000_000,
    ) {
        let tokens = HashMap::from_iter([
            ("TOKEN", TokenConfig::with_price_and_decimals(price_f, decimals)),
        ]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);
        let mint = tokens["TOKEN"].mint;

        // User A deposits
        let deposit_a = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config,
            mint, TokenAmount::new(deposit_amount), Timestamp::ZERO,
        );
        prop_assume!(deposit_a.is_ok());
        let deposit_a = deposit_a.unwrap();
        prop_assume!(!deposit_a.shares_to_mint.is_zero());
        let shares_a = deposit_a.shares_to_mint;

        // User B deposits same amount
        let deposit_b = vault_operations::deposit(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config,
            mint, TokenAmount::new(deposit_amount), Timestamp::ZERO,
        );
        prop_assume!(deposit_b.is_ok());
        let deposit_b = deposit_b.unwrap();
        prop_assume!(!deposit_b.shares_to_mint.is_zero());
        let shares_b = deposit_b.shares_to_mint;

        // User A withdraws all shares
        let withdraw_a = vault_operations::withdraw(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config,
            mint, Timestamp::ZERO, shares_a,
        );
        prop_assume!(withdraw_a.is_ok());
        let received_a = withdraw_a.unwrap().available_to_send_to_user;

        // User B withdraws all shares
        let withdraw_b = vault_operations::withdraw(
            &mut vault, &vault_scope_prices, NetAum::ZERO, &global_config,
            mint, Timestamp::ZERO, shares_b,
        );
        prop_assume!(withdraw_b.is_ok());
        let received_b = withdraw_b.unwrap().available_to_send_to_user;

        // Neither user should profit
        prop_assert!(
            received_a <= deposit_a.token_to_deposit,
            "User A profited: received {} > deposited {}",
            received_a, deposit_a.token_to_deposit
        );
        prop_assert!(
            received_b <= deposit_b.token_to_deposit,
            "User B profited: received {} > deposited {}",
            received_b, deposit_b.token_to_deposit
        );

        // Fairness: both users deposited the same amount,
        // received amounts should be within 2 lamports of each other
        let diff = if received_a > received_b {
            received_a - received_b
        } else {
            received_b - received_a
        };
        prop_assert!(
            diff <= TokenAmount::new(2),
            "Unfair distribution: User A received {}, User B received {}, diff {}",
            received_a, received_b, diff
        );
    }
}

// Same prev_aum invariant as above, but with random *non-zero* obligations contribution.
// Exercises the wiring of `compute_net_aum + obligations_aum` through `update_prev_aum_if_not_negative`.
proptest! {
    #![proptest_config(ProptestConfig::with_cases(50_000))]

    #[test]
    fn test_deposit_prev_aum_invariant_with_positive_obligations(
        price_usdc in 0.1_f64..1000.0,
        decimals_usdc in 4_u8..9,
        deposit_amounts in prop::collection::vec(10000_u64..1_000_000_000, 3),
        obligation_dollar_value_f in 0.0_f64..1_000_000.0,
    ) {
        let tokens = HashMap::from_iter([
            ("USDC", TokenConfig::with_price_and_decimals(price_usdc, decimals_usdc)),
        ]);
        let (mut vault, global_config, vault_scope_prices) = setup_vault_with_tokens_and_config(
            &tokens, 0, 0,
        );
        vault.management_fee_bps = 50;
        vault.performance_fee_bps = 1000;

        let obligations_aum = NetAum::from(DollarValue::from(Fraction::from_num(obligation_dollar_value_f)));
        let token_mint = tokens["USDC"].mint;

        let mut timestamp = 0_u64;
        for &deposit_amount in &deposit_amounts {
            timestamp += 3600;
            let result = vault_operations::deposit(
                &mut vault,
                &vault_scope_prices,
                obligations_aum,
                &global_config,
                token_mint,
                TokenAmount::new(deposit_amount),
                Timestamp::from(timestamp),
            );

            if result.is_ok() {
                // After a successful deposit, `prev_aum` should equal the current `net_aum` (i.e.
                // `compute_free_aum + obligations_aum.abs_value` for the positive-obligation case).
                let computed_free_aum = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
                let expected_net_aum = computed_free_aum + Fraction::from(obligations_aum.abs_value);
                let prev_aum = Fraction::from(vault.prev_aum());
                assert_fuzzy_eq_f!(prev_aum, expected_net_aum, EPSILON_F);
            }
        }
    }
}

// Random sequence of *interleaved* deposits and withdraws, while the (constant for the seed)
// `obligations_aum` is non-zero. Invariant: `prev_aum` always tracks the current net AUM after a
// successful op. Per-op direction is randomised: each step either deposits a fresh slice or burns
// a slice of issued shares.
proptest! {
    #![proptest_config(ProptestConfig::with_cases(20_000))]

    #[test]
    fn test_interleaved_deposit_withdraw_with_positive_obligations_preserves_prev_aum(
        price_usdc in 0.5_f64..50.0,
        decimals_usdc in 6_u8..9,
        ops in prop::collection::vec((any::<bool>(), 1_000_u64..100_000_000), 6),
        obligation_dollar_value_f in 0.0_f64..1_000.0,
    ) {
        let tokens = HashMap::from_iter([
            ("USDC", TokenConfig::with_price_and_decimals(price_usdc, decimals_usdc)),
        ]);
        let (mut vault, global_config, vault_scope_prices) = setup_vault_with_tokens_and_config(
            &tokens, 0, 0,
        );
        vault.management_fee_bps = 50;
        vault.performance_fee_bps = 1000;

        let obligations_aum = NetAum::from(DollarValue::from(Fraction::from_num(obligation_dollar_value_f)));
        let token_mint = tokens["USDC"].mint;

        let mut timestamp = 0_u64;
        for (is_deposit, amount) in ops {
            timestamp += 3600;
            let op_result = if is_deposit {
                vault_operations::deposit(
                    &mut vault,
                    &vault_scope_prices,
                    obligations_aum,
                    &global_config,
                    token_mint,
                    TokenAmount::new(amount),
                    Timestamp::from(timestamp),
                )
                .map(|_| ())
            } else {
                // Withdraw a slice of *currently-issued* shares, capped at `amount` so the value
                // domain stays comparable to the deposit branch.
                let shares = ShareAmount::new(amount.min(vault.shares_issued));
                if shares.is_zero() {
                    continue;
                }
                vault_operations::withdraw(
                    &mut vault,
                    &vault_scope_prices,
                    obligations_aum,
                    &global_config,
                    token_mint,
                    Timestamp::from(timestamp),
                    shares,
                )
                .map(|_| ())
            };

            if op_result.is_ok() {
                let computed_free_aum = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
                let expected_net_aum = computed_free_aum + Fraction::from(obligations_aum.abs_value);
                let prev_aum = Fraction::from(vault.prev_aum());
                assert_fuzzy_eq_f!(prev_aum, expected_net_aum, EPSILON_F);
            }
        }
    }
}

// Negative-obligation fuzz: when the obligation's debt exceeds free AUM, `compute_net_aum` is
// negative and `vault_operations::deposit/withdraw` must return `VaultAUMZero` — `charge_fees`
// must bump timestamps without accrual, and `prev_aum` must be preserved at its prior healthy
// value (never overwritten with the bogus negative aum). The proptest exercises this across many
// price/decimals/amount combos.
proptest! {
    #![proptest_config(ProptestConfig::with_cases(20_000))]

    #[test]
    fn test_ops_halt_under_negative_aum_and_prev_aum_is_preserved(
        price_usdc in 0.5_f64..50.0,
        decimals_usdc in 6_u8..9,
        deposit_amount in 10_000_u64..1_000_000_000,
        // Debt must strictly exceed the seeded deposit's dollar value across the entire
        // parameter domain: worst case is 1_000_000_000 lamports of USDC at $50 = $50B. Use a
        // domain that comfortably dominates.
        obligation_debt_dollars_f in 100_000_000_000.0_f64..10_000_000_000_000.0,
    ) {
        let tokens = HashMap::from_iter([
            ("USDC", TokenConfig::with_price_and_decimals(price_usdc, decimals_usdc)),
        ]);
        let (mut vault, global_config, vault_scope_prices) = setup_vault_with_tokens_and_config(
            &tokens, 0, 0,
        );
        vault.management_fee_bps = 50;
        vault.performance_fee_bps = 1000;
        let token_mint = tokens["USDC"].mint;

        // Seed a healthy deposit with NetAum=ZERO first so `prev_aum` lands at a known positive
        // value we can later assert is preserved.
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            token_mint,
            TokenAmount::new(deposit_amount),
            Timestamp::from(1_000_u64),
        )
        .unwrap();
        let prev_aum_before = vault.prev_aum();

        // Now turn negative: stuff a huge obligation debt.
        let obligations_aum = NetAum {
            abs_value: DollarValue::from(Fraction::from_num(obligation_debt_dollars_f)),
            negative: true,
        };
        let timestamp = Timestamp::from(1_000_u64 + 3_600);

        let deposit_res = vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            obligations_aum,
            &global_config,
            token_mint,
            TokenAmount::new(deposit_amount),
            timestamp,
        );
        prop_assert_eq!(deposit_res, err!(KaminoVaultError::VaultAUMZero));

        let withdraw_res = vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            obligations_aum,
            &global_config,
            token_mint,
            timestamp,
            ShareAmount::new(1),
        );
        prop_assert_eq!(withdraw_res, err!(KaminoVaultError::VaultAUMZero));

        // `prev_aum` must NOT have moved: `update_prev_aum_if_not_negative` skipped both times.
        prop_assert_eq!(vault.prev_aum(), prev_aum_before);
    }
}

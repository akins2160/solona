use std::collections::HashMap;

use kamino_lending::{
    fraction::Fraction,
    program_test::common::math::usdc_decimal_to_u64 as usdc,
    utils::{FractionExtra, FULL_BPS},
};

use super::tests_utils::fixtures::setup_vault_with_tokens_and_config;
use crate::{
    operations::{
        effects::WithdrawPendingFeesEffects,
        tests::tests_utils::{
            fixtures::setup_vault_with_tokens, TokenConfig, UserState, EPSILON_F,
        },
        vault_operations::{self},
    },
    types::{
        DollarValue, Duration, FractionalShares, NetAum, Ratio, RoundingMethod, ShareAmount,
        SharePrice, Timestamp, TokenAmount,
    },
    utils::consts::{
        INITIAL_DEPOSIT_SIZE, MAX_CHARGED_RATE_FOR_VAULT_FEE, PERF_FEE_COOLDOWN_SECONDS, YEAR,
    },
    GlobalConfig,
};
use kamino_lending::{assert_fuzzy_eq, assert_fuzzy_eq_f, assert_gt};
use proptest::prelude::*;

/// Deposit/withdraw rounding dust is donated to the vault and, being a genuine share-price rise,
/// is charged as performance. Analytic expectations that measure gain from post-flow
/// AUM snapshots are blind to that dust, so their fee assertions tolerate one share.
const FLOW_DUST_EPSILON_F: Fraction = Fraction::ONE;

#[test]
fn test_charge_mgmt_fees() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mgmt_fee_bps = 100;
    vault.management_fee_bps = mgmt_fee_bps;

    let deposit = usdc(43.0);
    let current_timestamp = 0;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(deposit),
        Timestamp::from(current_timestamp),
    )
    .unwrap();

    // set a timestamp as the last time when fees were charged
    let prev_timestamp = 1000;
    vault.last_fee_charge_timestamp = prev_timestamp;
    let current_timestamp = prev_timestamp + 485;
    let shares_issued_before = vault.shares_issued;

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(current_timestamp),
    )
    .unwrap();

    let shares_issued_after = vault.shares_issued;

    let mgmt_fee = (Fraction::from(mgmt_fee_bps * (current_timestamp - prev_timestamp))
        / Fraction::from(u64::from(YEAR) * u64::from(FULL_BPS)))
    .min(Fraction::from_bps(5_000));
    let expected_mgmt_fee =
        Fraction::from(shares_issued_before) * mgmt_fee / (Fraction::ONE - mgmt_fee);
    let expected_shares_minted = expected_mgmt_fee.to_floor::<u64>();
    assert_eq!(vault.last_fee_charge_timestamp, current_timestamp);
    assert_eq!(
        shares_issued_after - shares_issued_before,
        expected_shares_minted
    );
    assert_fuzzy_eq_f!(
        Fraction::from(vault.pending_fees()),
        expected_mgmt_fee,
        EPSILON_F
    );

    // charge fees again
    let prev_timestamp = current_timestamp;
    let current_timestamp = prev_timestamp + 48545;
    let shares_issued_before_2 = vault.shares_issued;

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(current_timestamp),
    )
    .unwrap();

    let shares_issued_after_2 = vault.shares_issued;

    let mgmt_fee = (Fraction::from(mgmt_fee_bps * (current_timestamp - prev_timestamp))
        / Fraction::from(u64::from(YEAR) * u64::from(FULL_BPS)))
    .min(Fraction::from_bps(5_000));
    let updated_expected_mgmt_fee =
        Fraction::from(shares_issued_before_2) * mgmt_fee / (Fraction::ONE - mgmt_fee);
    let expected_shares_minted_2 =
        (updated_expected_mgmt_fee + expected_mgmt_fee).to_floor::<u64>() - expected_shares_minted;
    assert_eq!(vault.last_fee_charge_timestamp, current_timestamp);
    assert_eq!(
        shares_issued_after_2 - shares_issued_before_2,
        expected_shares_minted_2
    );
    assert_fuzzy_eq_f!(
        Fraction::from(vault.pending_fees()),
        updated_expected_mgmt_fee + expected_mgmt_fee,
        EPSILON_F
    );
}

#[test]
fn test_charge_fees() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mgmt_fee_bps = 1430;
    let perf_fee_bps = 679;
    vault.management_fee_bps = mgmt_fee_bps;
    vault.performance_fee_bps = perf_fee_bps;

    let deposit = usdc(548.0);
    let current_timestamp = 0;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(deposit),
        Timestamp::from(current_timestamp),
    )
    .unwrap();

    // set a slot as the last time when fees were charged
    let prev_timestamp = 144300;
    vault.last_fee_charge_timestamp = prev_timestamp;
    let current_timestamp = prev_timestamp + 58485;
    let prev_aum = Fraction::from(vault.prev_aum());
    let shares_issued_before = vault.shares_issued;
    let shares_issued = Fraction::from(shares_issued_before);

    vault.vault_tokens[0].token_available += deposit;
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(current_timestamp),
    )
    .unwrap();

    let shares_issued_after = vault.shares_issued;

    let new_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    let time_elapsed = Duration::from(current_timestamp - prev_timestamp);
    let mgmt_rate = (Ratio::of(time_elapsed, YEAR) * Ratio::<u64>::from_bps(mgmt_fee_bps))
        .limit_at_most(MAX_CHARGED_RATE_FOR_VAULT_FEE);
    let mgmt_reverse = mgmt_rate.reverse().unwrap();
    let expected_mgmt_fee = mgmt_reverse.full_mul(shares_issued, RoundingMethod::Ceil);

    let earned_interest_dv = DollarValue::from(new_aum - prev_aum);
    let new_aum_dv = DollarValue::from(new_aum);
    let perf_fee_rate = (Ratio::of(earned_interest_dv, new_aum_dv)
        * Ratio::<u64>::from_bps(perf_fee_bps))
    .limit_at_most(MAX_CHARGED_RATE_FOR_VAULT_FEE);
    let perf_reverse = perf_fee_rate.reverse().unwrap();
    let expected_perf_fee =
        perf_reverse.full_mul(shares_issued + expected_mgmt_fee, RoundingMethod::Ceil);
    let expected_total_fee = expected_mgmt_fee + expected_perf_fee;
    let expected_shares_minted = expected_total_fee.to_floor::<u64>();
    assert_eq!(vault.last_fee_charge_timestamp, current_timestamp);
    assert_eq!(
        shares_issued_after - shares_issued_before,
        expected_shares_minted
    );
    assert_fuzzy_eq_f!(
        Fraction::from(vault.pending_fees()),
        expected_total_fee,
        FLOW_DUST_EPSILON_F
    );

    // charge fees again
    let prev_timestamp = current_timestamp;
    let current_timestamp = prev_timestamp + 48545;
    let shares_issued_before_2 = vault.shares_issued;
    let shares_issued = Fraction::from(shares_issued_before_2);

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(current_timestamp),
    )
    .unwrap();

    let shares_issued_after_2 = vault.shares_issued;

    let mgmt_fee = (Fraction::from(mgmt_fee_bps * (current_timestamp - prev_timestamp))
        / Fraction::from(u64::from(YEAR) * u64::from(FULL_BPS)))
    .min(Fraction::from_bps(5_000));
    let expected_mgmt_fee = Fraction::from(shares_issued) * mgmt_fee / (Fraction::ONE - mgmt_fee);
    let new_expected_total_fee = expected_mgmt_fee + expected_total_fee;
    let expected_shares_minted_2 =
        new_expected_total_fee.to_floor::<u64>() - expected_shares_minted;

    assert_eq!(vault.last_fee_charge_timestamp, current_timestamp);
    assert_eq!(
        shares_issued_after_2 - shares_issued_before_2,
        expected_shares_minted_2
    );
    assert_fuzzy_eq_f!(
        Fraction::from(vault.pending_fees()),
        new_expected_total_fee,
        FLOW_DUST_EPSILON_F
    );
}

#[test]
fn test_management_fee_distribution_fairness() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set 1% annual management fee
    vault.management_fee_bps = 100; // 1%

    // Alice deposits first
    let mut alice = UserState::new("USDC", 1_010_000_000); // $10
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(2000u64),
        )
        .unwrap(),
    );

    // Bob deposits later with same amount
    let mut bob = UserState::new("USDC", 1_010_000_000); // $10
    bob.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(2000u64),
        )
        .unwrap(),
    );

    // Both users should have equal shares since they deposited same amount
    assert_eq!(alice.shares, bob.shares);
    let initial_total_shares = vault.shares_issued;

    // Fast forward 1 year and charge management fees
    vault.last_fee_charge_timestamp = 2000;
    let one_year_later = 2000 + u64::from(YEAR);
    let shares_issued_before = vault.shares_issued;

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(one_year_later),
    )
    .unwrap();

    let shares_issued_after = vault.shares_issued;

    // Calculate expected management fee (1% of shares)
    let expected_mgmt_fee_shares =
        Fraction::from(initial_total_shares) * Fraction::from_num(0.01) / Fraction::from_num(0.99);
    let actual_pending_fees = Fraction::from(vault.pending_fees());

    // Verify management fee was charged correctly
    assert!(actual_pending_fees > Fraction::ZERO);
    let expected_shares_minted = expected_mgmt_fee_shares.to_floor::<u64>();
    assert_eq!(
        shares_issued_after - shares_issued_before,
        expected_shares_minted
    );
    assert_fuzzy_eq_f!(actual_pending_fees, expected_mgmt_fee_shares, EPSILON_F);

    // When users withdraw, they should get proportionally less due to management fee dilution
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year_later),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year_later),
            ShareAmount::from(bob.shares),
        )
        .unwrap(),
    );

    // Both users should get back slightly less than they deposited due to management fees
    let alice_received = alice.tokens["USDC"] - 1_000_000_000;
    let bob_received = bob.tokens["USDC"] - 1_000_000_000;

    // Users should receive approximately 99% of their deposit (1% management fee)
    assert_eq!(alice_received, 10_000_000 * 99 / 100);
    assert_eq!(bob_received, 10_000_000 * 99 / 100);
}

#[test]
fn test_performance_fee_only() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set 20% performance fee only
    vault.performance_fee_bps = 2000; // 20%
    vault.management_fee_bps = 0; // No management fee

    // Alice deposits
    let mut alice = UserState::new("USDC", 1_010_000_000); // $10
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    // Bob deposits same amount
    let mut bob = UserState::new("USDC", 1_010_000_000); // $10
    bob.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    let initial_total_shares = vault.shares_issued;
    let initial_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));

    // Simulate profit by adding tokens to vault (representing yield/investment gains)
    vault.vault_tokens[0].token_available += 5_000_000; // $5 profit = 25% gain
    let new_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    let profit = new_aum - initial_aum;

    // Charge performance fees
    vault.last_fee_charge_timestamp = 1000;
    let shares_issued_before = vault.shares_issued;

    let new_timestamp = 1000 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(new_timestamp),
    )
    .unwrap();

    let shares_issued_after = vault.shares_issued;

    // Calculate expected performance fee: 20% of profit
    let perf_fee_fraction = Fraction::from_bps(2000) * profit / new_aum; // 20% * (profit/new_aum)
    let expected_perf_fee_shares = Fraction::from(initial_total_shares) * perf_fee_fraction
        / (Fraction::ONE - perf_fee_fraction);

    let expected_shares_minted = expected_perf_fee_shares.to_floor::<u64>();
    assert_eq!(
        shares_issued_after - shares_issued_before,
        expected_shares_minted
    );
    assert_fuzzy_eq_f!(
        Fraction::from(vault.pending_fees()),
        expected_perf_fee_shares,
        FLOW_DUST_EPSILON_F
    );

    // Users withdraw - should get back their deposit plus 80% of profit (20% goes to fees)
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(new_timestamp),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(new_timestamp),
            ShareAmount::from(bob.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - 1_000_000_000;
    let bob_received = bob.tokens["USDC"] - 1_000_000_000;

    let expected_received = 11_999_900;
    assert_eq!(alice_received, expected_received);
    assert_eq!(bob_received, expected_received);
}

#[test]
fn test_combined_management_and_performance_fees() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set both fees: 2% management + 15% performance
    vault.management_fee_bps = 200; // 2%
    vault.performance_fee_bps = 1500; // 15%

    // Alice deposits
    let mut alice = UserState::new("USDC", 1_010_000_000); // $10
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    let initial_total_shares = vault.shares_issued;
    let initial_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));

    // Fast forward 6 months and add profit
    let six_months_later = 1000 + (u64::from(YEAR) / 2);
    vault.vault_tokens[0].token_available += 2_000_000; // $2 profit = 20% gain
    vault.last_fee_charge_timestamp = 1000;

    // Charge both management and performance fees
    let shares_issued_before = vault.shares_issued;

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(six_months_later),
    )
    .unwrap();

    let shares_issued_after = vault.shares_issued;

    let mgmt_rate = (Ratio::of(Duration::from(u64::from(YEAR) / 2), YEAR)
        * Ratio::<u64>::from_bps(200))
    .limit_at_most(MAX_CHARGED_RATE_FOR_VAULT_FEE);
    let mgmt_reverse = mgmt_rate.reverse().unwrap();
    let expected_mgmt_fee_shares =
        mgmt_reverse.full_mul(Fraction::from(initial_total_shares), RoundingMethod::Ceil);

    let new_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    let profit = new_aum - initial_aum;
    let shares_after_mgmt_fee = Fraction::from(initial_total_shares) + expected_mgmt_fee_shares;
    let perf_rate = (Ratio::of(DollarValue::from(profit), DollarValue::from(new_aum))
        * Ratio::<u64>::from_bps(1500))
    .limit_at_most(MAX_CHARGED_RATE_FOR_VAULT_FEE);
    let perf_reverse = perf_rate.reverse().unwrap();
    let expected_perf_fee_shares =
        perf_reverse.full_mul(shares_after_mgmt_fee, RoundingMethod::Ceil);

    let expected_total_fee_shares = expected_mgmt_fee_shares + expected_perf_fee_shares;
    let expected_shares_minted = expected_total_fee_shares.to_floor::<u64>();
    assert_eq!(
        shares_issued_after - shares_issued_before,
        expected_shares_minted
    );
    assert_fuzzy_eq_f!(
        Fraction::from(vault.pending_fees()),
        expected_total_fee_shares,
        FLOW_DUST_EPSILON_F
    );

    let total_shares_before = vault.shares_issued;
    let total_tokens_before = vault.vault_tokens[0].token_available;
    let alice_shares_before = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months_later),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - 1_000_000_000;

    let expected_alice = (Fraction::from(alice_shares_before)
        * Fraction::from(total_tokens_before)
        / Fraction::from(total_shares_before))
    .to_floor::<u64>();
    assert_fuzzy_eq!(alice_received, expected_alice, 1);
}

#[test]
fn test_different_deposit_timing_fee_differences() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set 1% management fee
    vault.management_fee_bps = 100; // 1%

    // Alice deposits at time 1000
    let mut alice = UserState::new("USDC", 1_010_000_000); // $10
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    // Fast forward 6 months and charge fees (Alice pays 6 months of management fees)
    let six_months_later = 1000 + (u64::from(YEAR) / 2);
    vault.last_fee_charge_timestamp = 1000;
    let shares_issued_before_1 = vault.shares_issued;

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(six_months_later),
    )
    .unwrap();

    let shares_issued_after_1 = vault.shares_issued;

    let fees_from_alice_period = vault.pending_fees();
    let shares_minted_1 = shares_issued_after_1 - shares_issued_before_1;
    assert_eq!(
        shares_minted_1,
        u64::from(fees_from_alice_period.floor_shares())
    );

    // Bob deposits 6 months later (after Alice has already paid management fees)
    let mut bob = UserState::new("USDC", 1_010_000_000); // $10
    bob.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(six_months_later),
        )
        .unwrap(),
    );

    // Fast forward another 6 months and charge fees (both users pay for this period)
    let one_year_total = six_months_later + (u64::from(YEAR) / 2);
    let shares_issued_before_2 = vault.shares_issued;

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(one_year_total),
    )
    .unwrap();

    let shares_issued_after_2 = vault.shares_issued;

    // Alice should have paid management fees for full year
    // Bob should have paid management fees for only 6 months
    let total_fees = vault.pending_fees();
    let shares_minted_2 = shares_issued_after_2 - shares_issued_before_2;
    assert_eq!(
        shares_minted_2,
        (u64::from(total_fees.floor_shares()) - shares_minted_1)
    );
    assert!(total_fees > fees_from_alice_period); // More fees accumulated

    let total_shares_before_alice_wth = vault.shares_issued;
    let total_tokens_before_alice_wth = vault.vault_tokens[0].token_available;
    let alice_shares_before_wth = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year_total),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let total_shares_before_bob_wth = vault.shares_issued;
    let total_tokens_before_bob_wth = vault.vault_tokens[0].token_available;
    let bob_shares_before_wth = bob.shares;

    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year_total),
            ShareAmount::from(bob.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - 1_000_000_000;
    let bob_received = bob.tokens["USDC"] - 1_000_000_000;

    let expected_alice = (Fraction::from(alice_shares_before_wth)
        * Fraction::from(total_tokens_before_alice_wth)
        / Fraction::from(total_shares_before_alice_wth))
    .to_floor::<u64>();
    let expected_bob = (Fraction::from(bob_shares_before_wth)
        * Fraction::from(total_tokens_before_bob_wth)
        / Fraction::from(total_shares_before_bob_wth))
    .to_floor::<u64>();
    assert_fuzzy_eq!(alice_received, expected_alice, 1);
    assert_fuzzy_eq!(bob_received, expected_bob, 1);

    let total_deposited = 10_000_000u64 + 10_000_000u64 + INITIAL_DEPOSIT_SIZE;
    let remaining = vault.vault_tokens[0].token_available;
    assert!(alice_received + bob_received + remaining <= total_deposited);
}

#[test]
fn test_one_user_different_deposit_times_mgmt_and_perf() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set both management and performance fees
    vault.management_fee_bps = 100; // 1%
    vault.performance_fee_bps = 1000; // 10%

    let mut alice = UserState::new("USDC", 1_010_000_000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(10_000_000u64),
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    // Fast forward 6 months, charge fees, then Bob deposits
    let mut admin = UserState::new("USDC", 0);
    let six_months = 1000 + u64::from(YEAR) / 2;
    // Make admin withdraw fees and redeem for USDC
    let shares_issued_before_1 = vault.shares_issued;
    let pending_fees_before_1 = vault.pending_fees();
    let shares_minted_1 = u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(six_months),
        )
        .unwrap(),
    );
    admin.consume_charge_fees(shares_minted_1);
    let shares_issued_after_1 = vault.shares_issued;
    let pending_fees_after_1 = vault.pending_fees();
    assert_eq!(
        shares_issued_after_1 - shares_issued_before_1,
        shares_minted_1
    );
    assert_eq!(
        shares_minted_1,
        (u64::from(pending_fees_after_1.floor_shares())
            - u64::from(pending_fees_before_1.floor_shares()))
    );
    let total_shares_before_admin1 = vault.shares_issued;
    let total_tokens_before_admin1 = vault.vault_tokens[0].token_available;
    let admin_shares_before1 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin1 = (Fraction::from(admin_shares_before1)
        * Fraction::from(total_tokens_before_admin1)
        / Fraction::from(total_shares_before_admin1))
    .to_floor::<u64>();

    // Add profit and fast forward another 6 months
    let one_year = 1000 + u64::from(YEAR);
    vault.vault_tokens[0].token_available += 5_000_000; // $5 profit on $25 vault = 20% gain
    let shares_issued_before_2 = vault.shares_issued;
    let shares_minted_2 = u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(one_year),
        )
        .unwrap(),
    );
    admin.consume_charge_fees(shares_minted_2);
    let shares_issued_after_2 = vault.shares_issued;
    assert_eq!(
        shares_issued_after_2 - shares_issued_before_2,
        shares_minted_2
    );
    let total_shares_before_admin2 = vault.shares_issued;
    let total_tokens_before_admin2 = vault.vault_tokens[0].token_available;
    let admin_shares_before2 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin2 = (Fraction::from(admin_shares_before2)
        * Fraction::from(total_tokens_before_admin2)
        / Fraction::from(total_shares_before_admin2))
    .to_floor::<u64>();

    let total_shares_before_alice = vault.shares_issued;
    let total_tokens_before_alice = vault.vault_tokens[0].token_available;
    let alice_shares_before_wth = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - 1_000_000_000;
    let admin_received = admin.tokens["USDC"];

    let expected_alice = (Fraction::from(alice_shares_before_wth)
        * Fraction::from(total_tokens_before_alice)
        / Fraction::from(total_shares_before_alice))
    .to_floor::<u64>();

    assert_fuzzy_eq!(alice_received, expected_alice, 1);
    assert_fuzzy_eq!(admin_received, expected_admin1 + expected_admin2, 1);

    let total_input = 10_000_000u64 + 5_000_000u64 + INITIAL_DEPOSIT_SIZE;
    let remaining = vault.vault_tokens[0].token_available;
    assert!(alice_received + admin_received + remaining <= total_input);
}

#[test]
fn test_one_user_different_deposit_times_small_values_only_mgmt() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set both management and performance fees
    vault.management_fee_bps = 1000; // 10%
    let mut alice = UserState::new("USDC", 1000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(1000u64),
            Timestamp::from(1000u64), // timestamp
        )
        .unwrap(),
    );

    // Fast forward 6 years to charge max fee
    let six_months = 1000 + u64::from(YEAR) * 6;
    let shares_issued_before_1 = vault.shares_issued;
    let shares_minted_1 = u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(six_months),
        )
        .unwrap(),
    );
    let shares_issued_after_1 = vault.shares_issued;
    assert_eq!(
        shares_issued_after_1 - shares_issued_before_1,
        shares_minted_1
    );

    // Add profit and fast forward another 6 months
    let one_year = 1000 + u64::from(YEAR) * 12;
    let shares_issued_before_2 = vault.shares_issued;
    let shares_minted_2 = u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(one_year),
        )
        .unwrap(),
    );
    let shares_issued_after_2 = vault.shares_issued;
    assert_eq!(
        shares_issued_after_2 - shares_issued_before_2,
        shares_minted_2
    );

    // Both users withdraw at same time
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"];
    assert_eq!(alice_received, 249);
}

#[test]
fn test_one_user_different_deposit_times_small_values_only_mgmt_but_has_yield() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set both management and performance fees
    vault.management_fee_bps = 1000; // 10%
    let mut alice = UserState::new("USDC", 1000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(1000u64),
            Timestamp::from(1000u64), // timestamp
        )
        .unwrap(),
    );

    // Fast forward 6 years to charge max fee
    let mut admin = UserState::new("USDC", 0);
    let six_months = 1000 + u64::from(YEAR) * 6;
    let shares_issued_before_1 = vault.shares_issued;
    let shares_minted_1 = u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(six_months),
        )
        .unwrap(),
    );
    admin.consume_charge_fees(shares_minted_1);
    let shares_issued_after_1 = vault.shares_issued;
    assert_eq!(
        shares_issued_after_1 - shares_issued_before_1,
        shares_minted_1
    );
    let total_shares_before_admin1 = vault.shares_issued;
    let total_tokens_before_admin1 = vault.vault_tokens[0].token_available;
    let admin_shares_before1 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin1 = (Fraction::from(admin_shares_before1)
        * Fraction::from(total_tokens_before_admin1)
        / Fraction::from(total_shares_before_admin1))
    .to_floor::<u64>();

    // Add profit and fast forward another 6 months
    let one_year = 1000 + u64::from(YEAR) * 12;
    vault.vault_tokens[0].token_available += 1000; // 100% gain
    let shares_issued_before_2 = vault.shares_issued;
    let shares_minted_2 = u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(one_year),
        )
        .unwrap(),
    );
    admin.consume_charge_fees(shares_minted_2);
    let shares_issued_after_2 = vault.shares_issued;
    assert_eq!(
        shares_issued_after_2 - shares_issued_before_2,
        shares_minted_2
    );
    let total_shares_before_admin2 = vault.shares_issued;
    let total_tokens_before_admin2 = vault.vault_tokens[0].token_available;
    let admin_shares_before2 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin2 = (Fraction::from(admin_shares_before2)
        * Fraction::from(total_tokens_before_admin2)
        / Fraction::from(total_shares_before_admin2))
    .to_floor::<u64>();

    let total_shares_before_alice = vault.shares_issued;
    let total_tokens_before_alice = vault.vault_tokens[0].token_available;
    let alice_shares_before_wth = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"];
    let admin_received = admin.tokens["USDC"];

    let expected_alice = (Fraction::from(alice_shares_before_wth)
        * Fraction::from(total_tokens_before_alice)
        / Fraction::from(total_shares_before_alice))
    .to_floor::<u64>();

    assert_fuzzy_eq!(alice_received, expected_alice, 1);
    assert_fuzzy_eq!(admin_received, expected_admin1 + expected_admin2, 1);

    let total_input = 1000u64 + 1000u64 + INITIAL_DEPOSIT_SIZE;
    let remaining = vault.vault_tokens[0].token_available;
    assert!(alice_received + admin_received + remaining <= total_input);
}

#[test]
fn test_two_users_different_deposit_and_withdraw_times() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set both management and performance fees
    vault.management_fee_bps = 200; // 2%
    vault.performance_fee_bps = 500; // 5%

    // Alice deposits at time 1000
    let mut alice = UserState::new("USDC", 1_020_000_000);
    let alice_deposit = 20_000_000.0;
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(alice_deposit as u64), // $20
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    // Fast forward 3 months and Bob deposits
    let mut admin = UserState::new("USDC", 0);
    let three_months = 1000 + (u64::from(YEAR) / 4);
    vault.last_fee_charge_timestamp = 1000;
    // Make admin withdraw fees and redeem for USDC
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(three_months),
        )
        .unwrap(),
    ));
    let ts_before_admin1 = vault.shares_issued;
    let tt_before_admin1 = vault.vault_tokens[0].token_available;
    let as_before_admin1 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(three_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin1 = (Fraction::from(as_before_admin1) * Fraction::from(tt_before_admin1)
        / Fraction::from(ts_before_admin1))
    .to_floor::<u64>();

    let mut bob = UserState::new("USDC", 1_010_000_000);
    let bob_deposit = 10_000_000.0;
    bob.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(bob_deposit as u64), // $10
            Timestamp::from(three_months),
        )
        .unwrap(),
    );

    // Fast forward 3 more months, Alice withdraws
    let six_months = three_months + (u64::from(YEAR) / 4);
    let total_yield = 6_000_000.0;
    vault.vault_tokens[0].token_available += total_yield as u64; // $6 profit on $30 vault = 20% gain
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(six_months),
        )
        .unwrap(),
    ));
    let ts_before_admin2 = vault.shares_issued;
    let tt_before_admin2 = vault.vault_tokens[0].token_available;
    let as_before_admin2 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin2 = (Fraction::from(as_before_admin2) * Fraction::from(tt_before_admin2)
        / Fraction::from(ts_before_admin2))
    .to_floor::<u64>();

    let ts_before_alice = vault.shares_issued;
    let tt_before_alice = vault.vault_tokens[0].token_available;
    let alice_shares_before_wth = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let expected_alice = (Fraction::from(alice_shares_before_wth)
        * Fraction::from(tt_before_alice)
        / Fraction::from(ts_before_alice))
    .to_floor::<u64>();

    // Fast forward 6 more months, Bob withdraws
    let one_year = six_months + (u64::from(YEAR) / 2);
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(one_year),
        )
        .unwrap(),
    ));
    let ts_before_admin3 = vault.shares_issued;
    let tt_before_admin3 = vault.vault_tokens[0].token_available;
    let as_before_admin3 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_admin3 = (Fraction::from(as_before_admin3) * Fraction::from(tt_before_admin3)
        / Fraction::from(ts_before_admin3))
    .to_floor::<u64>();

    let ts_before_bob = vault.shares_issued;
    let tt_before_bob = vault.vault_tokens[0].token_available;
    let bob_shares_before_wth = bob.shares;

    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(bob.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - 1_000_000_000;
    let bob_received = bob.tokens["USDC"] - 1_000_000_000;
    let admin_received = admin.tokens["USDC"];

    let expected_bob = (Fraction::from(bob_shares_before_wth) * Fraction::from(tt_before_bob)
        / Fraction::from(ts_before_bob))
    .to_floor::<u64>();

    assert_fuzzy_eq!(alice_received, expected_alice, 1);
    assert_fuzzy_eq!(bob_received, expected_bob, 1);
    assert_fuzzy_eq!(
        admin_received,
        expected_admin1 + expected_admin2 + expected_admin3,
        1
    );

    let total_input = 20_000_000u64 + 10_000_000u64 + 6_000_000u64 + INITIAL_DEPOSIT_SIZE;
    let remaining = vault.vault_tokens[0].token_available;
    assert!(alice_received + bob_received + admin_received + remaining <= total_input);
}

#[test]
fn test_user_deposit_withdraw_redeposit_cycle() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Set both management and performance fees
    vault.management_fee_bps = 150; // 1.5%
    vault.performance_fee_bps = 750; // 7.5%

    // Alice deposits first
    let mut alice = UserState::new("USDC", 1_015_000_000);
    let alice_deposit = 15_000_000.0;
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(alice_deposit as u64), // $15
            Timestamp::from(1000u64),
        )
        .unwrap(),
    );

    // Bob deposits 3 months later
    let three_months = 1000 + (u64::from(YEAR) / 4);
    let mut admin = UserState::new("USDC", 0);
    vault.last_fee_charge_timestamp = 1000;
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(three_months),
        )
        .unwrap(),
    ));
    let ts_before_adm1 = vault.shares_issued;
    let tt_before_adm1 = vault.vault_tokens[0].token_available;
    let as_before_adm1 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(three_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_adm1 = (Fraction::from(as_before_adm1) * Fraction::from(tt_before_adm1)
        / Fraction::from(ts_before_adm1))
    .to_floor::<u64>();

    let mut bob = UserState::new("USDC", 1_025_000_000);
    let bob_deposit = 25_000_000.0;
    bob.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(bob_deposit as u64), // $25
            Timestamp::from(three_months),
        )
        .unwrap(),
    );

    // 3 months later, add profit and Alice withdraws
    let six_months = three_months + (u64::from(YEAR) / 4);
    let total_yield = 8_000_000.0;
    vault.vault_tokens[0].token_available += total_yield as u64; // $8 profit on $40 vault = 20% gain
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(six_months),
        )
        .unwrap(),
    ));
    let ts_before_adm2 = vault.shares_issued;
    let tt_before_adm2 = vault.vault_tokens[0].token_available;
    let as_before_adm2 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_adm2 = (Fraction::from(as_before_adm2) * Fraction::from(tt_before_adm2)
        / Fraction::from(ts_before_adm2))
    .to_floor::<u64>();

    let ts_before_alice1 = vault.shares_issued;
    let tt_before_alice1 = vault.vault_tokens[0].token_available;
    let alice_shares_before_wth1 = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(six_months),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let expected_alice1 = (Fraction::from(alice_shares_before_wth1)
        * Fraction::from(tt_before_alice1)
        / Fraction::from(ts_before_alice1))
    .to_floor::<u64>();

    // 3 months later, Alice re-deposits
    let nine_months = six_months + (u64::from(YEAR) / 4);
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(nine_months),
        )
        .unwrap(),
    ));
    let ts_before_adm3 = vault.shares_issued;
    let tt_before_adm3 = vault.vault_tokens[0].token_available;
    let as_before_adm3 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(nine_months),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_adm3 = (Fraction::from(as_before_adm3) * Fraction::from(tt_before_adm3)
        / Fraction::from(ts_before_adm3))
    .to_floor::<u64>();

    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::from(alice_deposit as u64), // $15
            Timestamp::from(nine_months),
        )
        .unwrap(),
    );

    // Final withdrawal 3 months later
    let one_year = nine_months + (u64::from(YEAR) / 4);
    admin.consume_charge_fees(u64::from(
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(one_year),
        )
        .unwrap(),
    ));
    let ts_before_adm4 = vault.shares_issued;
    let tt_before_adm4 = vault.vault_tokens[0].token_available;
    let as_before_adm4 = admin.shares;

    admin.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(admin.shares),
        )
        .unwrap(),
    );

    let expected_adm4 = (Fraction::from(as_before_adm4) * Fraction::from(tt_before_adm4)
        / Fraction::from(ts_before_adm4))
    .to_floor::<u64>();

    let ts_before_alice2 = vault.shares_issued;
    let tt_before_alice2 = vault.vault_tokens[0].token_available;
    let alice_shares_before_wth2 = alice.shares;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(alice.shares),
        )
        .unwrap(),
    );

    let expected_alice2 = (Fraction::from(alice_shares_before_wth2)
        * Fraction::from(tt_before_alice2)
        / Fraction::from(ts_before_alice2))
    .to_floor::<u64>();

    let ts_before_bob = vault.shares_issued;
    let tt_before_bob = vault.vault_tokens[0].token_available;
    let bob_shares_before_wth = bob.shares;

    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::from(one_year),
            ShareAmount::from(bob.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - 1_000_000_000;
    let bob_received = bob.tokens["USDC"] - 1_000_000_000;
    let admin_received = admin.tokens["USDC"];

    let expected_bob = (Fraction::from(bob_shares_before_wth) * Fraction::from(tt_before_bob)
        / Fraction::from(ts_before_bob))
    .to_floor::<u64>();

    let expected_admin_total = expected_adm1 + expected_adm2 + expected_adm3 + expected_adm4;
    let expected_alice_net = expected_alice1 + expected_alice2 - alice_deposit as u64;
    assert_fuzzy_eq!(alice_received, expected_alice_net, 1);
    assert_fuzzy_eq!(bob_received, expected_bob, 1);
    assert_fuzzy_eq!(admin_received, expected_admin_total, 1);

    let total_input =
        15_000_000u64 + 25_000_000u64 + 15_000_000u64 + 8_000_000u64 + INITIAL_DEPOSIT_SIZE;
    let remaining = vault.vault_tokens[0].token_available;
    assert!(alice_received + bob_received + admin_received + remaining <= total_input);
}

#[test]
fn test_fractional_remainder_carryover() {
    let mut tokens = HashMap::new();
    tokens.insert("USDC", TokenConfig::with_price(1.0));

    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);

    // Use small fees to ensure fractional behavior
    vault.management_fee_bps = 1; // 0.01%

    let start_timestamp = 1000000;
    vault.last_fee_charge_timestamp = start_timestamp;
    vault.shares_issued = 1000;

    // Set up a small profit scenario
    vault.set_prev_aum(DollarValue::from(Fraction::from(100u64))); // $100
                                                                   // Manually set pending fees to a known fractional value to test carryover
    vault.set_pending_fees(FractionalShares::from(Fraction::from_num(0.9999))); // 0.9999 shares pending
    vault.last_fee_charge_timestamp = start_timestamp;

    // Second charge - the 0.9999 should carry over and combine with new fees
    let timestamp2 = start_timestamp + u64::from(YEAR); // Another year
    let shares_before_2 = vault.shares_issued;
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(timestamp2),
    )
    .unwrap();

    let shares_after_2 = vault.shares_issued;
    let shares_minted_2 = shares_after_2 - shares_before_2;

    // Mint 1 share because we combined it with the 0.9999
    assert_eq!(shares_minted_2, 1);

    // Simulate 9 more years
    // First 8 should yield 0 shares, but last one should mint 1 more
    for i in 0..9 {
        let timestamp_n = start_timestamp + u64::from(YEAR) * (i + 2); // Another year
        let shares_before_n = vault.shares_issued;
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(timestamp_n),
        )
        .unwrap();
        let shares_after_n = vault.shares_issued;
        let shares_minted_n = shares_after_n - shares_before_n;

        if i < 8 {
            assert_eq!(shares_minted_n, 0);
        } else {
            assert_eq!(shares_minted_n, 1);
        }
    }
}

#[test]
fn test_fractional_remainder_carryover_works_while_withdrawing_fees() {
    let mut tokens = HashMap::new();
    tokens.insert("USDC", TokenConfig::with_price(1.0));

    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);

    // Use small fees to ensure fractional behavior
    vault.management_fee_bps = 1; // 0.01%

    let start_timestamp = 1000000;
    vault.last_fee_charge_timestamp = start_timestamp;
    vault.shares_issued = 1000;

    // Set up a small profit scenario
    vault.set_prev_aum(DollarValue::from(Fraction::from(100u64))); // $100
                                                                   // Manually set pending fees to a known fractional value to test carryover
    vault.set_pending_fees(FractionalShares::from(Fraction::from_num(0.9999))); // 0.9999 shares pending
    vault.last_fee_charge_timestamp = start_timestamp;
    let WithdrawPendingFeesEffects {
        available_to_send_to_user,
    } = vault_operations::withdraw_pending_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(start_timestamp),
    )
    .unwrap();
    assert_eq!(available_to_send_to_user, ShareAmount::from(0u64));

    // Second charge - the 0.9999 should carry over and combine with new fees
    let timestamp2 = start_timestamp + u64::from(YEAR); // Another year
    let shares_before_2 = vault.shares_issued;
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(timestamp2),
    )
    .unwrap();

    let shares_after_2 = vault.shares_issued;
    let shares_minted_2 = shares_after_2 - shares_before_2;

    // Mint 1 share because we combined it with the 0.9999
    assert_eq!(shares_minted_2, 1);
    let WithdrawPendingFeesEffects {
        available_to_send_to_user,
    } = vault_operations::withdraw_pending_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(timestamp2),
    )
    .unwrap();
    assert_eq!(available_to_send_to_user, ShareAmount::from(1u64));

    // Simulate 9 more years
    // First 8 should yield 0 shares, but last one should mint 1 more
    // Also we mint/accumulate just like in the previous test even though we withdraw fees every action
    for i in 0..9 {
        let timestamp_n = start_timestamp + u64::from(YEAR) * (i + 2); // Another year
        let shares_before_n = vault.shares_issued;
        vault_operations::charge_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(timestamp_n),
        )
        .unwrap();
        let shares_after_n = vault.shares_issued;
        let shares_minted_n = shares_after_n - shares_before_n;
        let WithdrawPendingFeesEffects {
            available_to_send_to_user,
        } = vault_operations::withdraw_pending_fees(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            Timestamp::from(timestamp_n),
        )
        .unwrap();

        if i < 8 {
            assert_eq!(available_to_send_to_user, ShareAmount::from(0u64));
            assert_eq!(shares_minted_n, 0);
        } else {
            assert_eq!(available_to_send_to_user, ShareAmount::from(1u64));
            assert_eq!(shares_minted_n, 1);
        }
    }
}

#[test]
fn test_performance_fee_cooldown() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    let global_config = GlobalConfig::default();

    vault.performance_fee_bps = 1000; // 10%

    // Initial deposit
    let deposit = usdc(100.0);
    let current_timestamp = 1000;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(deposit),
        Timestamp::from(current_timestamp),
    )
    .unwrap();
    let perf_price_at_start = vault.last_perf_fee_price();

    // Set initial fee charge timestamp
    vault.last_fee_charge_timestamp = current_timestamp;
    vault.last_perf_fee_charge_timestamp = current_timestamp;

    // Add profit to trigger performance fees
    vault.vault_tokens[0].token_available += usdc(20.0); // 20% profit

    // Charge fees before cooldown has passed (should only charge management fees)
    let before_cooldown = current_timestamp + (u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2); // 12 hours later
    let shares_before_1 = vault.shares_issued;
    let fees_before_1 = vault.pending_fees();

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(before_cooldown),
    )
    .unwrap();

    let shares_after_1 = vault.shares_issued;
    let fees_after_1 = vault.pending_fees();

    assert!(shares_after_1 == shares_before_1);
    assert!(fees_after_1 == fees_before_1);

    // Verify performance fee timestamp wasn't updated (no performance fees charged)
    assert_eq!(vault.last_fee_charge_timestamp, before_cooldown);
    assert_eq!(vault.last_perf_fee_charge_timestamp, current_timestamp);
    assert_eq!(
        vault.last_perf_fee_price(),
        perf_price_at_start,
        "an in-cooldown call must not move the performance price checkpoint"
    );

    let after_cooldown = before_cooldown + u64::from(PERF_FEE_COOLDOWN_SECONDS); // 24 hours after initial
    let shares_before_2 = vault.shares_issued;
    let fees_before_2 = vault.pending_fees();

    // Add more profit to have something to charge performance fees on
    vault.vault_tokens[0].token_available += usdc(10.0); // Additional profit

    let new_aum = vault
        .compute_net_aum(&vault_scope_prices, NetAum::ZERO, RoundingMethod::Ceil)
        .try_non_negative()
        .unwrap();
    let checkpoint_value =
        perf_price_at_start.value_of(vault.shares_issued_amount(), RoundingMethod::Floor);
    let expected_perf_charge = vault_operations::common::get_shares_to_charge_for_vault_fee(
        vault.performance_fee_rate(),
        Ratio::of(new_aum.saturating_sub(checkpoint_value), new_aum),
        vault.shares_issued_amount().as_fractional(),
    )
    .floor_shares();

    let minted_at_cooldown = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(after_cooldown),
    )
    .unwrap();
    assert_eq!(
        minted_at_cooldown, expected_perf_charge,
        "the eligible charge must include profit observed by the earlier cooldown call"
    );

    let shares_after_2 = vault.shares_issued;
    let fees_after_2 = vault.pending_fees();

    // Verify more fees were charged
    let shares_minted_1 = shares_after_1 - shares_before_1;
    let shares_minted_2 = shares_after_2 - shares_before_2;

    // Should have charged more shares this time due to performance fees
    assert!(shares_minted_2 > shares_minted_1);
    assert!(fees_after_2 > fees_before_2);

    // Verify timestamps were updated correctly
    assert_eq!(vault.last_fee_charge_timestamp, after_cooldown);
    assert_eq!(vault.last_perf_fee_charge_timestamp, after_cooldown);
    // The checkpoint is the post-mint price, so the fee dilution is not next window's loss.
    assert_eq!(
        vault.last_perf_fee_price(),
        SharePrice::of(new_aum, vault.shares_issued_amount(), RoundingMethod::Floor)
    );

    // Test another fee charge immediately after - should not charge fees again
    let immediate_after = after_cooldown + 3600; // 1 hour later
    let shares_before_3 = vault.shares_issued;
    let fees_before_3 = vault.pending_fees();

    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(immediate_after),
    )
    .unwrap();

    let shares_after_3 = vault.shares_issued;
    let fees_after_3 = vault.pending_fees();

    let shares_minted_3 = shares_after_3 - shares_before_3;
    assert!(shares_minted_3 == 0);
    assert!(fees_after_3 == fees_before_3);

    // Verify performance fee timestamp wasn't updated (no performance fees charged)
    assert_eq!(vault.last_fee_charge_timestamp, immediate_after);
    assert_eq!(vault.last_perf_fee_charge_timestamp, after_cooldown); // Should remain the same
}

#[test]
fn test_first_touch_seeds_price_checkpoint_for_pre_checkpoint_vaults() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);

    // A vault deployed before the checkpoint existed: the slot holds zeroed padding while
    // shares, AUM, and the fee clocks are live mid-window, with an in-flight unrealized gain.
    vault.last_perf_fee_price_sf = 0;
    vault.vault_tokens[0].token_available += 20_000_200;

    let minted_at_seed = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_mid),
    )
    .unwrap();
    assert!(minted_at_seed.is_zero());

    let current_aum = vault
        .compute_net_aum(&vault_scope_prices, NetAum::ZERO, RoundingMethod::Ceil)
        .try_non_negative()
        .unwrap();
    assert_eq!(
        vault.last_perf_fee_price(),
        SharePrice::of(
            current_aum,
            vault.shares_issued_amount(),
            RoundingMethod::Floor
        ),
        "the first post-upgrade touch must seed the checkpoint from the current price"
    );

    let minted_at_boundary = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    assert!(
        minted_at_boundary.is_zero(),
        "gain that predates the seed is forgiven once, not charged at the next boundary"
    );
}

// ---------------------------------------------------------------------------
// Price-checkpoint semantics: performance = per-share price gain
// since the last eligible charge, borne by the shares outstanding at charge
// time. Amounts below are chosen so share prices stay exact (1.0, 0.8, 1.2).
// ---------------------------------------------------------------------------

/// USDC vault at token price 1.0 with a 10% performance fee (no mgmt fee), seeded by a user
/// deposit of `deposit` lamports at `t0` so the cooldown window starts at `t0`.
fn seed_perf_fee_vault(
    deposit: u64,
    t0: u64,
) -> (
    crate::MetavaultState,
    GlobalConfig,
    crate::utils::scope::VaultScopePrices,
    anchor_lang::prelude::Pubkey,
) {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);
    vault.performance_fee_bps = 1000;
    let mint = tokens["USDC"].mint;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        mint,
        TokenAmount::from(deposit),
        Timestamp::from(t0),
    )
    .unwrap();
    (vault, global_config, vault_scope_prices, mint)
}

#[test]
fn test_perf_charge_is_invariant_under_mid_cooldown_round_trip() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);

    // Twin vaults: identical seed deposit (price 1.0) and identical yield (price 1.2 exactly:
    // shares 100_001_000, AUM 120_001_200).
    let (mut plain, _, plain_prices, _) = seed_perf_fee_vault(100_000_000, t0);
    let (mut tripped, tripped_config, tripped_prices, tripped_mint) =
        seed_perf_fee_vault(100_000_000, t0);
    plain.vault_tokens[0].token_available += 20_000_200;
    tripped.vault_tokens[0].token_available += 20_000_200;

    // The tripped twin takes a flash-style round trip larger than the vault: deposit at price
    // 1.2 (mints 100_001_000 shares exactly), then withdraw the same shares at the same price.
    let effects = vault_operations::deposit(
        &mut tripped,
        &tripped_prices,
        NetAum::ZERO,
        &tripped_config,
        tripped_mint,
        TokenAmount::from(120_001_200_u64),
        Timestamp::from(t_mid),
    )
    .unwrap();
    vault_operations::withdraw(
        &mut tripped,
        &tripped_prices,
        NetAum::ZERO,
        &tripped_config,
        tripped_mint,
        Timestamp::from(t_mid),
        effects.shares_to_mint,
    )
    .unwrap();
    assert_eq!(plain.shares_issued, tripped.shares_issued);

    let minted_plain = vault_operations::charge_fees(
        &mut plain,
        &plain_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    let minted_tripped = vault_operations::charge_fees(
        &mut tripped,
        &tripped_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();

    assert!(!minted_plain.is_zero());
    assert_eq!(
        minted_plain, minted_tripped,
        "a deposit+withdraw round trip must not change the performance fee charged at the boundary"
    );
}

#[test]
fn test_perf_charge_zero_after_underwater_deposit_and_recovery() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, global_config, vault_scope_prices, mint) = seed_perf_fee_vault(100_000_000, t0);

    // Dip to price 0.8 exactly, then a depositor enters at the trough (mints 25_000_000 shares).
    vault.vault_tokens[0].token_available -= 20_000_200;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        mint,
        TokenAmount::from(20_000_000_u64),
        Timestamp::from(t_mid),
    )
    .unwrap();

    // Recover to exactly the checkpoint price of 1.0: AUM = shares = 125_001_000.
    vault.vault_tokens[0].token_available += 24_000_200;

    let minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    assert!(
        minted.is_zero(),
        "recovery back to the checkpoint price is not performance; neither is deposited \
         principal (got {minted} fee shares)"
    );
}

#[test]
fn test_perf_charge_halves_when_half_the_shares_exit_mid_cooldown() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);

    // Twin vaults at price 1.2 exactly after yield.
    let (mut full, _, full_prices, _) = seed_perf_fee_vault(100_000_000, t0);
    let (mut halved, halved_config, halved_prices, halved_mint) =
        seed_perf_fee_vault(100_000_000, t0);
    full.vault_tokens[0].token_available += 20_000_200;
    halved.vault_tokens[0].token_available += 20_000_200;

    // Half of all shares genuinely exit mid-cooldown, taking their profit with them.
    vault_operations::withdraw(
        &mut halved,
        &halved_prices,
        NetAum::ZERO,
        &halved_config,
        halved_mint,
        Timestamp::from(t_mid),
        ShareAmount::from(50_000_500_u64),
    )
    .unwrap();

    let minted_full = vault_operations::charge_fees(
        &mut full,
        &full_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    let minted_halved = vault_operations::charge_fees(
        &mut halved,
        &halved_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();

    assert!(!minted_full.is_zero());
    // An exit of half the shares must halve the performance fee base.
    assert_fuzzy_eq!(u64::from(minted_halved), u64::from(minted_full) / 2, 1);
}

#[test]
fn test_perf_charge_includes_mid_cooldown_entrant_shares() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, global_config, vault_scope_prices, mint) = seed_perf_fee_vault(100_000_000, t0);

    // Yield to price 1.2 exactly, then an entrant deposits at 1.2 (mints 50_000_500 shares)
    // and stays through the boundary.
    vault.vault_tokens[0].token_available += 20_000_200;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        mint,
        TokenAmount::from(60_000_600_u64),
        Timestamp::from(t_mid),
    )
    .unwrap();

    // Accepted trade-off of the price-checkpoint design: every outstanding share pays the full
    // per-share gain since
    // the checkpoint. Base = (1.2 - 1.0) x 150_001_500 shares, so f = 10% x base/AUM = 1/60 and
    // the dilution-corrected mint is shares x f/(1-f) = 150_001_500 / 59.
    let minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    // A staying entrant's shares are part of the performance fee base.
    assert_fuzzy_eq!(u64::from(minted), 2_542_398_u64, 1);
}

#[test]
fn test_perf_checkpoint_is_a_high_water_mark_across_an_observed_drawdown() {
    let cooldown = u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let t0 = 1_000_u64;
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);

    // Window 1: +20% (price 1.2 exactly), charged at the boundary.
    vault.vault_tokens[0].token_available += 20_000_200;
    let charged_on_the_way_up = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t0 + cooldown),
    )
    .unwrap();
    assert!(!charged_on_the_way_up.is_zero());

    // Window 2: drawdown to 1.1, observed at the boundary by anyone (`refresh_vault` is
    // permissionless). Nothing is charged, and the checkpoint must not ratchet down to the
    // trough.
    vault.vault_tokens[0].token_available -= 10_000_100;
    let charged_in_the_drawdown = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t0 + 2 * cooldown),
    )
    .unwrap();
    assert!(charged_in_the_drawdown.is_zero());

    // Window 3: recovery to exactly where window 1 ended. That interest already paid a
    // performance fee once, so the rebound must charge nothing.
    vault.vault_tokens[0].token_available += 10_000_100;
    let charged_on_the_rebound = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t0 + 3 * cooldown),
    )
    .unwrap();
    assert!(
        charged_on_the_rebound.is_zero(),
        "recovering to a previously charged high is not fresh performance (got \
         {charged_on_the_rebound} fee shares)"
    );
}

#[test]
fn test_mid_window_mgmt_mint_preserves_the_perf_fee_basis() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);
    vault.management_fee_bps = 1000;

    vault.vault_tokens[0].token_available += 20_000_200;
    let basis_before = vault
        .last_perf_fee_price()
        .value_of(vault.shares_issued_amount(), RoundingMethod::Floor);

    // An in-cooldown call charges management fees only. The shares it mints cost nothing, so
    // they must not be handed the standing per-share basis — that would inflate the baseline
    // and erase `minted x checkpoint_price` of yield from the next performance charge.
    let minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_mid),
    )
    .unwrap();
    assert!(!minted.is_zero());

    // The carried basis is re-divided over the larger supply with Ceil, so it can only grow,
    // and by at most one price quantum per outstanding share.
    let basis_after = vault
        .last_perf_fee_price()
        .value_of(vault.shares_issued_amount(), RoundingMethod::Floor);
    let quantization_dust = u128::from(vault.shares_issued);
    assert!(basis_after >= basis_before);
    assert_fuzzy_eq!(
        basis_after.to_bits(),
        basis_before.to_bits(),
        quantization_dust
    );
}

#[test]
fn test_raise_perf_fee_checkpoint_never_lowers_it() {
    let t0 = 1_000_u64;
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);
    let seeded = vault.last_perf_fee_price();

    // Underwater but still solvent: a fee-rate update must not re-arm the fee on the recovery.
    vault.vault_tokens[0].token_available -= 20_000_200;
    vault_operations::raise_perf_fee_checkpoint(&mut vault, &vault_scope_prices, NetAum::ZERO);
    assert_eq!(vault.last_perf_fee_price(), seeded);

    // Net AUM below zero has no share price at all — `prev_aum` is stale by then, and reading
    // it as if it were current is what used to lower the checkpoint here.
    let obligations_debt = NetAum::net_from_diff(
        DollarValue::ZERO,
        DollarValue::from(Fraction::from(1_000u64)),
    );
    vault_operations::raise_perf_fee_checkpoint(&mut vault, &vault_scope_prices, obligations_debt);
    assert_eq!(vault.last_perf_fee_price(), seeded);

    // A genuine new high does move it.
    vault.vault_tokens[0].token_available += 40_000_400;
    vault_operations::raise_perf_fee_checkpoint(&mut vault, &vault_scope_prices, NetAum::ZERO);
    assert!(vault.last_perf_fee_price() > seeded);
}

/// The op-level sequence `handler_update_vault_config` performs for a `PerformanceFeeBps`
/// update: charge under the old config, rebase the checkpoint, then apply the new rate.
fn charge_fees_and_update_perf_fee_bps(
    vault: &mut crate::MetavaultState,
    vault_scope_prices: &crate::utils::scope::VaultScopePrices,
    timestamp: u64,
    new_perf_fee_bps: u64,
) {
    vault_operations::charge_fees(
        vault,
        vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(timestamp),
    )
    .unwrap();
    vault_operations::raise_perf_fee_checkpoint(vault, vault_scope_prices, NetAum::ZERO);
    vault.performance_fee_bps = new_perf_fee_bps;
}

#[test]
fn test_perf_rate_increase_mid_cooldown_charges_only_post_change_gain() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);
    vault.performance_fee_bps = 0;

    // Yield to price 1.2 exactly (shares 100_001_000, AUM 120_001_200) under the 0% rate.
    vault.vault_tokens[0].token_available += 20_000_200;

    charge_fees_and_update_perf_fee_bps(&mut vault, &vault_scope_prices, t_mid, 5000);

    // Post-change yield to price 1.5: 0.3/share over the rebased 1.2 checkpoint.
    vault.vault_tokens[0].token_available += 30_000_300;

    let minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    // f = 50% x (30_000_300 / 150_001_500) = 10%, so mint = shares x f/(1-f) = 100_001_000/9.
    // Applying 50% retroactively to the full 0.5/share window would mint 100_001_000/5 instead.
    assert_fuzzy_eq!(u64::from(minted), 100_001_000 / 9, 1);
}

#[test]
fn test_perf_rate_decrease_mid_cooldown_charges_only_post_change_gain() {
    let t0 = 1_000_u64;
    let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);
    vault.performance_fee_bps = 5000;

    // Yield to price 1.2 under the 50% rate; the cooldown blocks charging it before the change,
    // so the rebase forgives it (a rate toggle must not become a cooldown bypass).
    vault.vault_tokens[0].token_available += 20_000_200;

    charge_fees_and_update_perf_fee_bps(&mut vault, &vault_scope_prices, t_mid, 1000);

    // Post-change yield to price 1.5.
    vault.vault_tokens[0].token_available += 30_000_300;

    let minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_boundary),
    )
    .unwrap();
    // f = 10% x (30_000_300 / 150_001_500) = 2%, so mint = 100_001_000/49; charging the whole
    // window at 10% would mint 100_001_000/29 instead.
    assert_fuzzy_eq!(u64::from(minted), 100_001_000 / 49, 1);
}

#[test]
fn test_perf_charge_zero_after_give_up_with_no_further_yield() {
    let t0 = 1_000_u64;
    let t1 = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let t2 = t1 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);

    // Yield to price 1.2 exactly, then an eligible charge mints the perf fee shares.
    vault.vault_tokens[0].token_available += 20_000_200;
    let shares_before_charge = vault.shares_issued;
    let minted_at_t1 = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t1),
    )
    .unwrap();
    assert!(!minted_at_t1.is_zero());

    // The admin waives all pending fees an hour later; the burn raises the share price.
    vault.block_deposits = 1;
    vault_operations::give_up_pending_fee(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t1 + 3_600),
        ShareAmount::from(u64::MAX),
    )
    .unwrap();
    assert_eq!(
        vault.shares_issued, shares_before_charge,
        "all fee shares burned"
    );

    // No further yield: the waiver-induced price rise must not be re-charged as performance.
    let minted_at_t2 = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t2),
    )
    .unwrap();
    assert!(
        minted_at_t2.is_zero(),
        "give-up windfall re-charged as performance: {minted_at_t2} fee shares"
    );
    assert!(
        vault.pending_fees().floor_shares().is_zero(),
        "waiver re-accrued as pending fees"
    );
}

#[test]
fn test_give_up_preserves_genuine_in_window_performance() {
    let t0 = 1_000_u64;
    let t1 = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let t_mid2 = t1 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
    let t2 = t1 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let (mut vault, _, vault_scope_prices, _) = seed_perf_fee_vault(100_000_000, t0);

    // Yield to price 1.2, then an eligible charge starts the second window.
    vault.vault_tokens[0].token_available += 20_000_200;
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t1),
    )
    .unwrap();

    // Genuine yield inside the second window, before the waiver.
    vault.vault_tokens[0].token_available += 30_000_300;
    let checkpoint_value_before_give_up = vault
        .last_perf_fee_price()
        .value_of(vault.shares_issued_amount(), RoundingMethod::Floor);

    vault.block_deposits = 1;
    vault_operations::give_up_pending_fee(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t_mid2),
        ShareAmount::from(u64::MAX),
    )
    .unwrap();

    // The boundary fee base must be exactly the pre-waiver base: the burn neither creates
    // performance (the windfall) nor erases the genuine in-window gain.
    let new_aum = vault
        .compute_net_aum(&vault_scope_prices, NetAum::ZERO, RoundingMethod::Ceil)
        .try_non_negative()
        .unwrap();
    let expected = vault_operations::common::get_shares_to_charge_for_vault_fee(
        vault.performance_fee_rate(),
        Ratio::of(
            new_aum.saturating_sub(checkpoint_value_before_give_up),
            new_aum,
        ),
        vault.shares_issued_amount().as_fractional(),
    )
    .floor_shares();

    let minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(t2),
    )
    .unwrap();
    assert!(!minted.is_zero());
    assert_fuzzy_eq!(u64::from(minted), u64::from(expected), 2);
}

proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000, max_global_rejects: 10_000, ..Default::default()})]

    /// Core invariant of the price-checkpoint design: at constant token prices, any sequence
    /// of mid-cooldown
    /// deposit+withdraw round trips leaves the boundary performance charge unchanged (up to one
    /// share-lamport of donated rounding dust per flow).
    #[test]
    fn test_perf_charge_invariant_under_roundtrip_flows(
        yield_pct in 0_u64..50,
        trip_amounts in prop::collection::vec(1_000_000_u64..2_000_000_000, 1..5),
    ) {
        let t0 = 1_000_u64;
        let t_mid = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS) / 2;
        let t_boundary = t0 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
        let deposit = 100_000_000_u64;

        let (mut plain, _, plain_prices, _) = seed_perf_fee_vault(deposit, t0);
        let (mut tripped, tripped_config, tripped_prices, tripped_mint) =
            seed_perf_fee_vault(deposit, t0);
        let yield_amount = deposit * yield_pct / 100;
        plain.vault_tokens[0].token_available += yield_amount;
        tripped.vault_tokens[0].token_available += yield_amount;

        for &amount in &trip_amounts {
            let deposited = vault_operations::deposit(
                &mut tripped,
                &tripped_prices,
                NetAum::ZERO,
                &tripped_config,
                tripped_mint,
                TokenAmount::from(amount),
                Timestamp::from(t_mid),
            );
            let Ok(effects) = deposited else { continue };
            let withdrawn = vault_operations::withdraw(
                &mut tripped,
                &tripped_prices,
                NetAum::ZERO,
                &tripped_config,
                tripped_mint,
                Timestamp::from(t_mid),
                effects.shares_to_mint,
            );
            prop_assume!(withdrawn.is_ok());
        }

        let minted_plain = u64::from(vault_operations::charge_fees(
            &mut plain,
            &plain_prices,
            NetAum::ZERO,
            Timestamp::from(t_boundary),
        ).unwrap());
        let minted_tripped = u64::from(vault_operations::charge_fees(
            &mut tripped,
            &tripped_prices,
            NetAum::ZERO,
            Timestamp::from(t_boundary),
        ).unwrap());

        let tolerance = trip_amounts.len() as u64 + 1;
        prop_assert!(
            minted_plain.abs_diff(minted_tripped) <= tolerance,
            "round trips changed the boundary charge: plain {} vs tripped {} (tolerance {})",
            minted_plain,
            minted_tripped,
            tolerance
        );
    }
}

// ---------------------------------------------------------------------------
// Consecutive charge_fees invariants (proptest)
// ---------------------------------------------------------------------------
proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn test_consecutive_charge_fees_invariants(
        price_f in 0.1_f64..10_000.0,
        decimals in 4_u8..10,
        deposit_amount in 100_000_u64..1_000_000_000,
        management_fee_bps in 0_u64..1000,
        performance_fee_bps in 0_u64..5000,
        time_deltas in prop::collection::vec(1_u64..200_000, 3..8),
        price_change_pcts in prop::collection::vec(-10_i64..50, 3..8),
    ) {
        let tokens = HashMap::from_iter([
            ("TOKEN", TokenConfig::with_price_and_decimals(price_f, decimals)),
        ]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);

        vault.management_fee_bps = management_fee_bps;
        vault.performance_fee_bps = performance_fee_bps;

        // Initial deposit
        let deposit_result = vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["TOKEN"].mint,
            TokenAmount::from(deposit_amount),
            Timestamp::from(0u64),
        );
        prop_assume!(deposit_result.is_ok());
        prop_assume!(vault.shares_issued > 0);

        let mut timestamp = 1000_u64;
        let mut prev_cumulative_mgmt = vault.cumulative_mgmt_fees();
        let mut prev_cumulative_perf = vault.cumulative_perf_fees();

        for (i, &dt) in time_deltas.iter().enumerate() {
            timestamp += dt;

            // Simulate price change by adding/removing tokens from vault
            if i < price_change_pcts.len() {
                let pct = price_change_pcts[i];
                let token = vault.get_vault_token_mut_by_mint(&tokens["TOKEN"].mint).unwrap();
                let current = token.token_available;
                let change = (current as i128 * pct as i128 / 100) as i64;
                if change > 0 {
                    token.token_available = current.saturating_add(change as u64);
                } else {
                    token.token_available = current.saturating_sub((-change) as u64);
                }
            }

            let shares_before = vault.shares_issued;
            let result = vault_operations::charge_fees(
                &mut vault,
                &vault_scope_prices,
                NetAum::ZERO,
                Timestamp::from(timestamp),
            );
            prop_assume!(result.is_ok());

            // Invariant 1: cumulative management fees monotonically increase
            let curr_cumulative_mgmt = vault.cumulative_mgmt_fees();
            prop_assert!(
                curr_cumulative_mgmt >= prev_cumulative_mgmt,
                "Cumulative mgmt fees decreased: {:?} < {:?}",
                curr_cumulative_mgmt,
                prev_cumulative_mgmt
            );

            // Invariant 2: cumulative performance fees monotonically increase
            let curr_cumulative_perf = vault.cumulative_perf_fees();
            prop_assert!(
                curr_cumulative_perf >= prev_cumulative_perf,
                "Cumulative perf fees decreased: {:?} < {:?}",
                curr_cumulative_perf,
                prev_cumulative_perf
            );

            // Invariant 3: pending_fees (floor) never exceeds shares_issued
            let pending_fees_floor = u64::from(vault.pending_fees().floor_shares());
            prop_assert!(
                pending_fees_floor <= vault.shares_issued,
                "Pending fees {} exceed shares issued {}",
                pending_fees_floor,
                vault.shares_issued
            );

            // Invariant 4: shares can only increase from fee charging
            prop_assert!(
                vault.shares_issued >= shares_before,
                "Shares decreased after charge_fees: {} < {}",
                vault.shares_issued,
                shares_before
            );

            prev_cumulative_mgmt = curr_cumulative_mgmt;
            prev_cumulative_perf = curr_cumulative_perf;
        }
    }
}

#[test]
fn test_perf_fee_with_positive_obligation_aum() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    vault.management_fee_bps = 0;
    vault.performance_fee_bps = 2000;

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(10_000_000u64),
        Timestamp::from(1_000u64),
    )
    .unwrap();
    let prev_aum_before = vault.prev_aum();
    let shares_before = vault.shares_issued;

    // charge_fees with $5 of positive obligation AUM, after the perf-fee cooldown elapses
    let new_timestamp = 1_000 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let obligations_aum = NetAum::from(DollarValue::from(Fraction::from_num(5.0)));
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        obligations_aum,
        Timestamp::from(new_timestamp),
    )
    .unwrap();

    assert_gt!(vault.shares_issued, shares_before);
    assert_gt!(vault.prev_aum(), prev_aum_before);
    assert_eq!(vault.last_fee_charge_timestamp, new_timestamp);
}

#[test]
fn test_charge_fees_skipped_under_negative_net_aum() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    vault.management_fee_bps = 1000;
    vault.performance_fee_bps = 2000;

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(10_000_000u64),
        Timestamp::from(1_000u64),
    )
    .unwrap();
    let healthy_prev_aum = vault.prev_aum();
    let shares_before = vault.shares_issued;
    let pending_fees_before = vault.pending_fees();

    // -$100 of obligation debt against $10 of free AUM → strictly negative net AUM
    let obligations_aum = NetAum {
        abs_value: DollarValue::from(Fraction::from_num(100.0)),
        negative: true,
    };
    let new_timestamp = 1_000 + u64::from(PERF_FEE_COOLDOWN_SECONDS);
    let fees_minted = vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        obligations_aum,
        Timestamp::from(new_timestamp),
    )
    .unwrap();

    assert_eq!(fees_minted, ShareAmount::ZERO);
    assert_eq!(vault.shares_issued, shares_before);
    assert_eq!(vault.pending_fees(), pending_fees_before);
    assert_eq!(vault.prev_aum(), healthy_prev_aum);
    assert_eq!(vault.last_fee_charge_timestamp, new_timestamp);
    assert_eq!(vault.last_perf_fee_charge_timestamp, new_timestamp);
}

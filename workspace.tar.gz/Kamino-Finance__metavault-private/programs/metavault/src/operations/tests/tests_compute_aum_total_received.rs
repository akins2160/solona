use kamino_lending::fraction::Fraction;

use crate::{
    operations::{
        tests::tests_utils::EPSILON_F,
        vault_operations::common::compute_aum_total_received_on_withdraw,
    },
    types::{DollarValue, Ratio, ShareAmount},
};

#[test]
fn test_compute_aum_total_received_standard_scenarios() {
    struct TestCase {
        shares_issued: u64,
        vault_total_holdings: f64,
        shares_to_withdraw: u64,
        expected_aum: f64,
    }

    let test_cases = vec![
        TestCase {
            shares_issued: 100_000_000,     // 100 shares
            vault_total_holdings: 1000.0,   // $1000 AUM
            shares_to_withdraw: 25_000_000, // 25 shares
            expected_aum: 250.0,            // $250 AUM (25% of vault)
        },
        TestCase {
            shares_issued: 200_000_000,
            vault_total_holdings: 2000.0,
            shares_to_withdraw: 100_000_000, // 50% of shares
            expected_aum: 1000.0,            // $1000 AUM
        },
        TestCase {
            shares_issued: 1_000_000,
            vault_total_holdings: 500.0,
            shares_to_withdraw: 100_000, // 10% of shares
            expected_aum: 50.0,          // $50 AUM
        },
        TestCase {
            shares_issued: 1_000_000_000_000,    // Large vault
            vault_total_holdings: 1_000_000.0,   // $1M AUM
            shares_to_withdraw: 100_000_000_000, // 10% of shares
            expected_aum: 100_000.0,             // $100K AUM
        },
        TestCase {
            shares_issued: 333,
            vault_total_holdings: 999.0,
            shares_to_withdraw: 111, // 1/3 of shares
            expected_aum: 333.0,     // $333 AUM
        },
    ];

    for test in test_cases {
        let result = compute_aum_total_received_on_withdraw(
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            Ratio::of(
                ShareAmount::from(test.shares_to_withdraw),
                ShareAmount::from(test.shares_issued),
            ),
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert_eq!(Fraction::from(result), expected);
    }
}

#[test]
fn test_compute_aum_total_received_full_withdrawal() {
    struct TestCase {
        shares_issued: u64,
        vault_total_holdings: f64,
        expected_aum: f64,
    }

    let test_cases = vec![
        TestCase {
            shares_issued: 100_000_000,
            vault_total_holdings: 1000.0,
            expected_aum: 1000.0, // Get entire vault
        },
        TestCase {
            shares_issued: 1,
            vault_total_holdings: 0.001,
            expected_aum: 0.001, // Single share vault
        },
        TestCase {
            shares_issued: u64::MAX / 2,
            vault_total_holdings: 999_999.999,
            expected_aum: 999_999.999, // Large vault
        },
    ];

    for test in test_cases {
        let result = compute_aum_total_received_on_withdraw(
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            Ratio::of(
                ShareAmount::from(test.shares_issued),
                ShareAmount::from(test.shares_issued),
            ), // Withdraw all shares
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert_eq!(Fraction::from(result), expected);
    }
}

#[test]
fn test_compute_aum_total_received_edge_cases() {
    // Zero shares to withdraw
    let result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(ShareAmount::from(0), ShareAmount::from(100_000_000)),
    );
    assert_eq!(Fraction::from(result), Fraction::ZERO);

    // Empty vault
    let result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::ZERO),
        Ratio::of(
            ShareAmount::from(25_000_000),
            ShareAmount::from(100_000_000),
        ),
    );
    assert_eq!(Fraction::from(result), Fraction::ZERO);

    // Single share from single share vault
    let result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(100.0)),
        Ratio::of(ShareAmount::from(1), ShareAmount::from(1)),
    );
    assert_eq!(Fraction::from(result), Fraction::from_num(100.0));

    // Very small withdrawal
    let result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1_000_000.0)),
        Ratio::of(ShareAmount::from(1), ShareAmount::from(1_000_000_000_000)),
    );
    let expected = Fraction::from_num(1_000_000.0) / Fraction::from_num(1_000_000_000_000u64);
    assert_eq!(Fraction::from(result), expected);
}

#[test]
fn test_compute_aum_total_received_precision_scenarios() {
    struct TestCase {
        shares_issued: u64,
        vault_total_holdings: f64,
        shares_to_withdraw: u64,
        expected_aum: f64,
    }

    let test_cases = vec![
        TestCase {
            shares_issued: 3,
            vault_total_holdings: 10.0,
            shares_to_withdraw: 1, // 1/3 of vault
            expected_aum: 3.333333333333333,
        },
        TestCase {
            shares_issued: 7,
            vault_total_holdings: 3.0,
            shares_to_withdraw: 1, // 1/7 of vault
            expected_aum: 0.42857142857142855,
        },
        TestCase {
            shares_issued: 999_999_999,
            vault_total_holdings: 1_000_000_000.0,
            shares_to_withdraw: 1, // Tiny fraction
            expected_aum: 1.000000001,
        },
        TestCase {
            shares_issued: 777_777_777,
            vault_total_holdings: 12345.6789,
            shares_to_withdraw: 123_456,
            expected_aum: 1.95961903174,
        },
        TestCase {
            shares_issued: 1_000_000_000_000,
            vault_total_holdings: 999.999,
            shares_to_withdraw: 1_000_000,
            expected_aum: 0.000999999,
        },
    ];

    for test in test_cases {
        let result = compute_aum_total_received_on_withdraw(
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            Ratio::of(
                ShareAmount::from(test.shares_to_withdraw),
                ShareAmount::from(test.shares_issued),
            ),
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert!(Fraction::from(result).abs_diff(expected) < EPSILON_F);
    }
}

#[test]
fn test_compute_aum_total_received_mathematical_properties() {
    // Test proportionality: 2x shares withdrawn = 2x AUM
    let base_result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
    );
    let double_result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(20_000_000),
            ShareAmount::from(100_000_000),
        ),
    );
    assert_eq!(
        Fraction::from(double_result),
        Fraction::from(base_result) * Fraction::from_num(2)
    );

    // Test vault scaling: 2x vault holdings = 2x AUM per share
    let base_vault_result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
    );
    let double_vault_result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(2000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
    );
    assert_eq!(
        Fraction::from(double_vault_result),
        Fraction::from(base_vault_result) * Fraction::from_num(2)
    );

    // Test share dilution: 2x total shares = 0.5x AUM per share
    let base_shares_result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
    );
    let double_shares_result = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(200_000_000),
        ),
    );
    assert_eq!(
        Fraction::from(double_shares_result) * Fraction::from_num(2),
        Fraction::from(base_shares_result)
    );

    // Test full withdrawal optimization
    let shares_issued = 123_456_789u64;
    let vault_holdings = DollarValue::from(Fraction::from_num(987654.321));
    let full_withdrawal = compute_aum_total_received_on_withdraw(
        vault_holdings,
        Ratio::of(
            ShareAmount::from(shares_issued),
            ShareAmount::from(shares_issued),
        ),
    );

    assert_eq!(full_withdrawal, vault_holdings);

    // Test linearity: sum of withdrawals = total withdrawal
    let shares_1 = 30_000_000u64;
    let shares_2 = 20_000_000u64;
    let total_shares = shares_1 + shares_2;

    let withdrawal_1 = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(ShareAmount::from(shares_1), ShareAmount::from(100_000_000)),
    );
    let withdrawal_2 = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(ShareAmount::from(shares_2), ShareAmount::from(100_000_000)),
    );
    let total_withdrawal = compute_aum_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(total_shares),
            ShareAmount::from(100_000_000),
        ),
    );

    assert_eq!(withdrawal_1 + withdrawal_2, total_withdrawal);
}

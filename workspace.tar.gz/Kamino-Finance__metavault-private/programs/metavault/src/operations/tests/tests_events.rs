#[cfg(test)]
mod tests {
    use anchor_lang::prelude::Pubkey;

    use crate::{
        events::{RebalanceEndReason, RebalanceEndWatch},
        types::{RebalanceState, Timestamp},
        MetavaultState,
    };

    #[test]
    fn test_admin_stop_reports_a_live_rebalance() {
        let vault = vault_in_window();
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &vault, ts(1_500));

        let ended = watch.on_admin_stop();

        assert_eq!(ended.reason, RebalanceEndReason::Stopped);
    }

    #[test]
    fn test_admin_stop_reports_a_rebalance_that_ran_out_of_clock() {
        // The window elapsed with nobody closing it, so the watch opens outside it. The stop
        // still ended a rebalance that was unfinished, so it must not be silent.
        let vault = vault_in_window();
        assert!(!vault.rebalance.is_within(ts(9_999)));
        assert!(vault.rebalance.is_unfinished());
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &vault, ts(9_999));

        let ended = watch.on_admin_stop();

        assert_eq!(ended.reason, RebalanceEndReason::Stopped);
    }

    #[test]
    fn test_balance_change_reports_settled_when_the_rebalance_ends() {
        let vault = vault_in_window();
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &vault, ts(1_500));
        let mut after = vault_in_window();
        after.rebalance.finish();

        let ended = watch
            .on_balances_changed(&after)
            .expect("the rebalance ended during this instruction");

        assert_eq!(ended.reason, RebalanceEndReason::Settled);
    }

    #[test]
    fn test_balance_change_stays_silent_while_the_rebalance_lives() {
        let vault = vault_in_window();
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &vault, ts(1_500));

        assert!(watch.on_balances_changed(&vault).is_none());
    }

    #[test]
    fn test_balance_change_stays_silent_when_nothing_was_running() {
        let vault = MetavaultState::default();
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &vault, ts(1_500));

        assert!(watch.on_balances_changed(&vault).is_none());
    }

    #[test]
    fn test_new_start_reports_only_a_rebalance_it_replaced() {
        let replaced = vault_in_window();
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &replaced, ts(1_500));
        let ended = watch
            .on_new_rebalance_start()
            .expect("the previous rebalance was live, so starting one ended it");
        assert_eq!(ended.reason, RebalanceEndReason::Settled);

        let never_ran = MetavaultState::default();
        let watch = RebalanceEndWatch::open(Pubkey::new_unique(), &never_ran, ts(1_500));
        assert!(watch.on_new_rebalance_start().is_none());
    }

    fn ts(seconds: u64) -> Timestamp {
        Timestamp::from(seconds)
    }

    fn vault_in_window() -> MetavaultState {
        MetavaultState {
            rebalance: RebalanceState {
                start_timestamp: 1_000,
                end_timestamp: 1_000 + 3_600,
                ..RebalanceState::default()
            },
            ..MetavaultState::default()
        }
    }
}

use std::collections::HashMap;

use anchor_lang::prelude::Pubkey;
use kamino_lending::fraction;
use kamino_lending::fraction::Fraction;
use proptest::prelude::*;

use crate::{
    operations::{
        deposit_order_operations::{admissible_tokens, open_deposit_order, OrderToken},
        order_basket::OrderBasket,
        rebalance_basket::RebalanceBasket,
        tests::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig},
        vault_operations::compute_max_deposit_by_target_bound,
    },
    order::DepositOrder,
    state::MetavaultState,
    types::{
        DollarValue, Duration, Ratio, RebalanceLimits, RoundingMethod, ShareAmount, Timestamp,
        TokenAmount, TokenPrice,
    },
    utils::scope::VaultScopePrices,
    KaminoVaultError,
};

#[test]
fn test_two_tokens_land_exactly_on_their_ceilings() {
    // Four tokens holding $1000 each, equal weights, 12.5% deviation: every ceiling is 1/4 + 1/8
    // = 3/8 of the post-absorb vault. $10_000 locked of two of them solves to
    // (1000 + x)/(4000 + 2x) = 3/8, i.e. $2000 each, both landing exactly on the ceiling.
    let mut fixture = dollar_vault(&[
        ("A", 1000, 1, 1250),
        ("B", 1000, 1, 1250),
        ("C", 1000, 1, 1250),
        ("D", 1000, 1, 1250),
    ]);

    let tokens = fixture.admissible(&[("A", 10_000), ("B", 10_000)]);

    assert_eq!(tokens.len(), 2);
    for token in &tokens {
        assert_eq!(token.admitted_aum, dollars(2000));
    }
}

#[test]
fn test_a_token_that_fits_whole_is_admitted_whole() {
    let mut fixture = dollar_vault(&[
        ("A", 1000, 1, 1250),
        ("B", 1000, 1, 1250),
        ("C", 1000, 1, 1250),
        ("D", 1000, 1, 1250),
    ]);

    let tokens = fixture.admissible(&[("A", 10)]);

    assert_eq!(tokens.len(), 1);
    assert_eq!(tokens[0].admitted_aum, dollars(10));
}

#[test]
fn test_an_unbounded_token_goes_in_whole() {
    // No max deviation configured on A: no ceiling, however over-weight it already is.
    let mut fixture = dollar_vault(&[("A", 2900, 1, 0), ("B", 100, 1, 1000)]);

    let tokens = fixture.admissible(&[("A", 100_000)]);

    assert_eq!(tokens.len(), 1);
    assert_eq!(tokens[0].admitted_aum, dollars(100_000));
}

#[test]
fn test_a_lone_unbounded_token_goes_in_whole_at_an_inexact_value() {
    // A is the whole vault, at a value its rounded-up and rounded-down forms disagree on: only the
    // missing ceiling (not the rounding) may decide.
    let mut fixture = dollar_vault(&[("A", 10, 1, 0)]);
    let a = fixture
        .vault
        .get_vault_token_id_by_mint(&fixture.mints["A"])
        .unwrap();
    fixture.vault.get_vault_token_mut_by_id(a).token_available += 1; // $10.000001

    let tokens = fixture.admissible(&[("A", 10)]);

    assert_eq!(tokens.len(), 1);
    let locked_aum = tokens[0]
        .locked
        .to_aum(fixture.prices.by_id(a), RoundingMethod::Floor);
    assert!(!locked_aum.is_zero());
    assert_eq!(tokens[0].admitted_aum, locked_aum);
}

#[test]
fn test_a_token_already_past_its_ceiling_admits_nothing() {
    // A's ceiling is 1/20 + 5% = 10% of the vault, and it already holds 90% of it.
    let mut fixture = dollar_vault(&[("A", 900, 1, 500), ("B", 100, 19, 500)]);

    let tokens = fixture.admissible(&[("A", 100)]);

    assert_eq!(tokens.len(), 1);
    assert_eq!(tokens[0].admitted_aum, DollarValue::ZERO);
}

#[test]
fn test_a_lone_token_matches_the_plain_deposit_bound() {
    // An order carrying a single token must admit exactly what the same plain deposit would.
    // Balances sit at target: $800 USDC (w4), $600 SOL (w3), $200 BTC (w1) of a $1600 vault.
    let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
    let sol = TokenConfig::with_price_and_decimals(100.0, 9);
    let btc = TokenConfig::with_price_and_decimals(50_000.0, 8);
    let mints = [usdc.mint, sol.mint, btc.mint];
    let tokens = HashMap::from_iter([("USDC", usdc), ("SOL", sol), ("BTC", btc)]);
    let (mut vault, prices) = setup_vault_with_tokens(&tokens);
    for token in vault.vault_tokens.iter_mut() {
        if token.mint == mints[0] {
            token.token_available = 800_000_000;
            token.weight = 4;
        } else if token.mint == mints[1] {
            token.token_available = 6_000_000_000;
            token.weight = 3;
        } else if token.mint == mints[2] {
            token.token_available = 400_000;
            token.weight = 1;
        }
        token.max_deviation_bps = 1_000;
    }

    for mint in mints {
        let id = vault.get_vault_token_id_by_mint(&mint).unwrap();
        let price = prices.by_id(id);
        let deposit_bound = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        let mut order = DepositOrder::default();
        let mut basket = OrderBasket {
            order: &mut order,
            vault: &mut vault,
        };
        basket.credit(
            id,
            dollars(1_000_000_000).to_tokens(price, RoundingMethod::Floor),
        );

        let tokens = admissible_tokens(&basket, &prices);

        let admitted = tokens[0]
            .admitted_aum
            .to_tokens(price, RoundingMethod::Floor);
        assert_eq!(
            admitted, deposit_bound,
            "lone token on {mint} admitted {admitted}, plain deposit would take {deposit_bound}",
        );
    }
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(5_000))]

    #[test]
    fn test_admitted_tokens_never_cross_their_ceiling(
        // Per token: dollars held by the vault, weight, max deviation in bps (0 = no ceiling).
        specs in prop::collection::vec(
            (0_u64..500_000, 1_u64..=10, prop_oneof![Just(0_u64), 100_u64..9_000]),
            1..=6,
        ),
        locked in prop::collection::vec(0_u64..2_000_000, 6),
    ) {
        let names = ["A", "B", "C", "D", "E", "F"];
        let vault_specs: Vec<(&str, u64, u64, u64)> = specs
            .iter()
            .enumerate()
            .map(|(index, &(held, weight, max_deviation_bps))| {
                (names[index], held, weight, max_deviation_bps)
            })
            .collect();
        let locks: Vec<(&str, u64)> = names
            .iter()
            .zip(&locked)
            .take(specs.len())
            .map(|(name, &dollars_locked)| (*name, dollars_locked))
            .collect();
        let mut fixture = dollar_vault(&vault_specs);

        let tokens = fixture.admissible(&locks);

        // Exactly the tokens with something locked come back.
        let locked_count = locks.iter().filter(|(_, dollars_locked)| *dollars_locked > 0).count();
        prop_assert_eq!(tokens.len(), locked_count);
        let vault = &fixture.vault;
        let free_aum = vault.compute_free_aum(&fixture.prices, RoundingMethod::Floor);
        let total_weight = vault.tokens().total_weight();
        let realized: DollarValue = tokens.iter().map(|token| token.admitted_aum).sum();
        for token in &tokens {
            let price = fixture.prices.by_id(token.id);
            let locked_aum = token.locked.to_aum(price, RoundingMethod::Floor);
            prop_assert!(
                token.admitted_aum <= locked_aum,
                "admitted {} beyond the locked {locked_aum}",
                token.admitted_aum
            );
            let vault_token = vault.get_vault_token_by_id(token.id);
            let Some(max_deviation) = vault_token.max_deviation() else {
                // No ceiling: the whole amount goes in (up to the solve's flooring dust).
                let dust = DollarValue::from(fraction!(0.00000000000001));
                prop_assert!(
                    locked_aum.saturating_sub(token.admitted_aum) < dust,
                    "unbounded token admitted {} of its locked {locked_aum}",
                    token.admitted_aum
                );
                continue;
            };
            if token.admitted_aum.is_zero() {
                // A token already past its ceiling admits nothing; it is not pushed further out.
                continue;
            }
            // Against the total realized (Ceil on the ceiling absorbs the Floor-rounded dust):
            let max_weight = Ratio::of(vault_token.weight(), total_weight) + max_deviation;
            let ceiling = free_aum
                .saturating_add(realized)
                .apply_ratio(max_weight, RoundingMethod::Ceil);
            let vault_token_aum = vault_token.compute_aum(price, RoundingMethod::Ceil);
            prop_assert!(
                vault_token_aum.saturating_add(token.admitted_aum) <= ceiling,
                "vault holding {vault_token_aum} admitted {}, past its ceiling {ceiling}",
                token.admitted_aum,
            );
        }
    }
}

#[test]
fn test_a_basket_worth_nothing_is_refused_at_open() {
    // A lamport priced at 10^-13 $ is worth less than a `DollarValue` can hold: a worthless basket.
    let mut fixture = dollar_vault(&[("A", 1000, 1, 0), ("B", 1000, 1, 0)]);
    fixture.vault.deposit_order_creation_enabled = 1;
    let b = fixture
        .vault
        .get_vault_token_id_by_mint(&fixture.mints["B"])
        .unwrap();
    fixture.prices.prices[b.input_account_index] = TokenPrice::new(Fraction::from_num(1e-13), 6);
    let mut order = DepositOrder::default();

    let res = open_deposit_order(
        &mut order,
        &mut fixture.vault,
        &fixture.prices,
        &[TokenAmount::ZERO, TokenAmount::from(1)],
        Duration::from_secs(3600),
        RebalanceLimits::default(),
        ShareAmount::from(1),
        Timestamp::ZERO,
    );

    assert_eq!(
        res.unwrap_err(),
        KaminoVaultError::DepositAmountsZero.into()
    );
}

// A vault of $1-priced, 6-decimal tokens, each given as (name, dollars held, weight, max deviation
// in bps, where 0 configures none), with orders opened against it.
struct Fixture {
    vault: MetavaultState,
    prices: VaultScopePrices,
    mints: HashMap<String, Pubkey>,
}

impl Fixture {
    // Locks `dollars` of each named token in a fresh order and returns what the bounds admit.
    fn admissible(&mut self, locks: &[(&str, u64)]) -> Vec<OrderToken> {
        let mut order = DepositOrder::default();
        let mut basket = OrderBasket {
            order: &mut order,
            vault: &mut self.vault,
        };
        for (name, dollars_locked) in locks {
            let id = basket
                .vault
                .get_vault_token_id_by_mint(&self.mints[*name])
                .unwrap();
            let amount =
                dollars(*dollars_locked).to_tokens(self.prices.by_id(id), RoundingMethod::Floor);
            basket.credit(id, amount);
        }
        admissible_tokens(&basket, &self.prices)
    }
}

fn dollar_vault(specs: &[(&str, u64, u64, u64)]) -> Fixture {
    let configs: HashMap<&str, TokenConfig> = specs
        .iter()
        .map(|(name, ..)| (*name, TokenConfig::with_price_and_decimals(1.0, 6)))
        .collect();
    let (mut vault, prices) = setup_vault_with_tokens(&configs);
    for (name, held, weight, max_deviation_bps) in specs {
        let mint = configs[*name].mint;
        let token = vault
            .vault_tokens
            .iter_mut()
            .find(|token| token.mint == mint)
            .unwrap();
        token.token_available = held * 1_000_000;
        token.weight = *weight;
        token.max_deviation_bps = *max_deviation_bps;
    }
    Fixture {
        vault,
        prices,
        mints: configs
            .iter()
            .map(|(name, config)| (name.to_string(), config.mint))
            .collect(),
    }
}

fn dollars(value: u64) -> DollarValue {
    DollarValue::from(Fraction::from_num(value))
}

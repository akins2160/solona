use kamino_lending::fraction::Fraction;

use crate::types::{DollarValue, RoundingMethod, TokenPrice};

fn aum_to_tokens(aum: Fraction, price: Fraction, decimals: u8, rounding: RoundingMethod) -> u64 {
    let token_price = TokenPrice::new(price, decimals);
    DollarValue::from(aum)
        .to_tokens(&token_price, rounding)
        .into()
}

#[test]
fn test_aum_to_tokens_standard_scenarios() {
    struct TestCase {
        aum: f64,
        token_price: f64,
        token_decimals: u8,
        rounding_method: RoundingMethod,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // Standard 6-decimal token scenarios
        TestCase {
            aum: 1.0,         // $1.00 AUM
            token_price: 1.0, // $1.00
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 1_000_000, // 1 token
        },
        TestCase {
            aum: 7.5,         // $7.50 AUM
            token_price: 3.0, // $3.00
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 2_500_000, // 2.5 tokens
        },
        TestCase {
            aum: 50.0,         // $50.00 AUM
            token_price: 0.50, // $0.50
            token_decimals: 6,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 100_000_000, // 100 tokens
        },
        TestCase {
            aum: 1000.0,         // $1000 AUM
            token_price: 2000.0, // $2000 (expensive token)
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 500_000, // 0.5 tokens
        },
        // Different decimal scenarios
        TestCase {
            aum: 5.0,         // $5.00 AUM
            token_price: 5.0, // $5.00
            token_decimals: 2,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 100, // 1 token (2 decimals)
        },
        TestCase {
            aum: 10.0,         // $10.00 AUM
            token_price: 10.0, // $10.00
            token_decimals: 9,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 1_000_000_000, // 1 token (9 decimals)
        },
        TestCase {
            aum: 0.001,         // $0.001 AUM
            token_price: 0.001, // $0.001
            token_decimals: 12,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 1_000_000_000_000, // 1 token (12 decimals)
        },
    ];

    for test in test_cases {
        let result = aum_to_tokens(
            Fraction::from_num(test.aum),
            Fraction::from_num(test.token_price),
            test.token_decimals,
            test.rounding_method,
        );

        assert_eq!(result, test.expected_tokens);
    }
}

#[test]
fn test_aum_to_tokens_rounding_differences() {
    struct TestCase {
        aum: f64,
        token_price: f64,
        token_decimals: u8,
        expected_floor: u64,
        expected_ceil: u64,
    }

    let test_cases = vec![
        // Cases where floor and ceil differ
        TestCase {
            aum: 10.0,        // $10 AUM
            token_price: 3.0, // $3 token price
            token_decimals: 6,
            expected_floor: 3_333_333, // 3.333333 tokens -> floor
            expected_ceil: 3_333_334,  // 3.333333 tokens -> ceil
        },
        TestCase {
            aum: 1.0,         // $1 AUM
            token_price: 7.0, // $7 token price
            token_decimals: 6,
            expected_floor: 142_857, // 0.142857 tokens -> floor
            expected_ceil: 142_858,  // 0.142857 tokens -> ceil
        },
        TestCase {
            aum: 100.0,         // $100 AUM
            token_price: 333.0, // $333 token price
            token_decimals: 6,
            expected_floor: 300_300, // 0.300300 tokens -> floor
            expected_ceil: 300_301,  // 0.300300 tokens -> ceil
        },
        TestCase {
            aum: 0.001,       // $0.001 AUM (tiny amount)
            token_price: 3.0, // $3 token price
            token_decimals: 6,
            expected_floor: 333, // 0.000333 tokens -> floor
            expected_ceil: 334,  // 0.000333 tokens -> ceil
        },
        // High precision rounding
        TestCase {
            aum: 999.999,        // $999.999 AUM
            token_price: 1000.0, // $1000 token price
            token_decimals: 12,
            expected_floor: 999_999_000_000, // 0.999999 tokens -> floor
            expected_ceil: 999_999_000_001,  // 0.999999 tokens -> ceil
        },
    ];

    for test in test_cases {
        let floor_result = aum_to_tokens(
            Fraction::from_num(test.aum),
            Fraction::from_num(test.token_price),
            test.token_decimals,
            RoundingMethod::Floor,
        );

        let ceil_result = aum_to_tokens(
            Fraction::from_num(test.aum),
            Fraction::from_num(test.token_price),
            test.token_decimals,
            RoundingMethod::Ceil,
        );

        assert_eq!(floor_result, test.expected_floor);
        assert_eq!(ceil_result, test.expected_ceil);
    }
}

#[test]
fn test_aum_to_tokens_edge_cases() {
    // Zero AUM
    let result = aum_to_tokens(
        Fraction::ZERO,
        Fraction::from_num(100.0),
        6,
        RoundingMethod::Floor,
    );
    assert_eq!(result, 0);

    let result = aum_to_tokens(
        Fraction::ZERO,
        Fraction::from_num(100.0),
        6,
        RoundingMethod::Ceil,
    );
    assert_eq!(result, 0);

    // Very small AUM with expensive token (might round to zero with floor)
    let result_floor = aum_to_tokens(
        Fraction::from_num(0.0001), // $0.0001 AUM
        Fraction::from_num(1000.0), // $1000 token
        6,
        RoundingMethod::Floor,
    );
    assert_eq!(result_floor, 0); // Rounds down to 0

    let result_ceil = aum_to_tokens(
        Fraction::from_num(0.0001), // $0.0001 AUM
        Fraction::from_num(1000.0), // $1000 token
        6,
        RoundingMethod::Ceil,
    );
    assert_eq!(result_ceil, 1); // Rounds up to 1 lamport

    // Very large AUM
    let result = aum_to_tokens(
        Fraction::from_num(1_000_000_000.0), // $1B AUM
        Fraction::from_num(0.001),           // $0.001 token
        6,
        RoundingMethod::Floor,
    );
    assert_eq!(result, 1_000_000_000_000_000_000 - 21); // 1 quintillion tokens but loses some precision and floors it
}

#[test]
fn test_aum_to_tokens_precision_scenarios() {
    struct TestCase {
        aum: f64,
        token_price: f64,
        token_decimals: u8,
        rounding_method: RoundingMethod,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // Fractional results needing precise rounding
        TestCase {
            aum: 0.999999,    // $0.999999 AUM
            token_price: 3.0, // $3.00
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 333_333, // Floor of 0.333333
        },
        TestCase {
            aum: 0.999999,    // $0.999999 AUM
            token_price: 3.0, // $3.00
            token_decimals: 6,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 333_333, // Ceil of 0.333333
        },
        TestCase {
            aum: 777.777777,    // $777.777777 AUM
            token_price: 1.001, // $1.001
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 777_000_777, // Floor calculation
        },
        TestCase {
            aum: 777.777777,    // $777.777777 AUM
            token_price: 1.001, // $1.001
            token_decimals: 6,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 777_000_778, // Ceil calculation
        },
        // Very small amounts
        TestCase {
            aum: 0.00000001,   // Tiny AUM
            token_price: 0.01, // 1 cent
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 0, // Rounds to 0
        },
        TestCase {
            aum: 0.00000001,   // Tiny AUM
            token_price: 0.01, // 1 cent
            token_decimals: 6,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 1, // Rounds to 1
        },
        // High precision calculations
        TestCase {
            aum: 308.641_972_530_864_2, // Complex AUM
            token_price: 2.5,           // $2.50
            token_decimals: 12,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 123_456_789_012_345, // Floor result
        },
        TestCase {
            aum: 308.641_972_530_864_2, // Complex AUM
            token_price: 2.5,           // $2.50
            token_decimals: 12,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 123_456_789_012_346, // Ceil result
        },
    ];

    for test in test_cases {
        let result = aum_to_tokens(
            Fraction::from_num(test.aum),
            Fraction::from_num(test.token_price),
            test.token_decimals,
            test.rounding_method,
        );

        // Use epsilon comparison for floating point precision issues
        let expected_range = match test.rounding_method {
            RoundingMethod::Floor => (
                test.expected_tokens.saturating_sub(1),
                test.expected_tokens + 1,
            ),
            RoundingMethod::Ceil => (
                test.expected_tokens.saturating_sub(1),
                test.expected_tokens + 1,
            ),
        };

        assert!(
            result >= expected_range.0 && result <= expected_range.1,
            "Expected tokens in range [{}, {}], got {}",
            expected_range.0,
            expected_range.1,
            result
        );
    }
}

#[test]
fn test_aum_to_tokens_different_token_types() {
    struct TestCase {
        aum: f64,
        token_price: f64,
        token_decimals: u8,
        rounding_method: RoundingMethod,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // Stablecoin-like (6 decimals, $1)
        TestCase {
            aum: 50.0,        // $50 AUM
            token_price: 1.0, // $1.00
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 50_000_000, // 50 USDC
        },
        // Bitcoin-like (8 decimals)
        TestCase {
            aum: 45000.0,         // $45,000 AUM
            token_price: 45000.0, // $45,000
            token_decimals: 8,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 100_000_000, // 1 BTC
        },
        // High precision token (12 decimals)
        TestCase {
            aum: 5000.0,         // $5,000 AUM
            token_price: 2500.0, // $2,500
            token_decimals: 12,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 2_000_000_000_000, // 2 tokens
        },
        // Low precision token (2 decimals)
        TestCase {
            aum: 97.40205,      // ~$97.40 AUM
            token_price: 0.789, // $0.789
            token_decimals: 2,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 12_345, // 12345 tokens (ceil)
        },
        // Ceil low precision token (2 decimals)
        TestCase {
            aum: 97.402,        // ~$97.40 AUM
            token_price: 0.789, // $0.789
            token_decimals: 2,
            rounding_method: RoundingMethod::Ceil,
            expected_tokens: 12_345, // 12344.9936629 tokens (ceil)
        },
        // Very cheap token (many tokens needed)
        TestCase {
            aum: 1.0,              // $1.00 AUM
            token_price: 0.000001, // $0.000001
            token_decimals: 6,
            rounding_method: RoundingMethod::Floor,
            expected_tokens: 1_000_000_000_000 - 1, // 1M tokens but loses very little precision and floors
        },
    ];

    for test in test_cases {
        let result = aum_to_tokens(
            Fraction::from_num(test.aum),
            Fraction::from_num(test.token_price),
            test.token_decimals,
            test.rounding_method,
        );

        assert_eq!(result, test.expected_tokens);
    }
}

#[test]
fn test_aum_to_tokens_mathematical_properties() {
    // Test linearity: 2x AUM = 2x tokens
    let base_result = aum_to_tokens(
        Fraction::from_num(5.0),
        Fraction::from_num(1.0),
        6,
        RoundingMethod::Floor,
    );
    let double_result = aum_to_tokens(
        Fraction::from_num(10.0),
        Fraction::from_num(1.0),
        6,
        RoundingMethod::Floor,
    );
    assert_eq!(double_result, base_result * 2);

    // Test price scaling: 2x price = 0.5x tokens
    let base_price_result = aum_to_tokens(
        Fraction::from_num(100.0),
        Fraction::from_num(10.0),
        6,
        RoundingMethod::Floor,
    );
    let double_price_result = aum_to_tokens(
        Fraction::from_num(100.0),
        Fraction::from_num(20.0),
        6,
        RoundingMethod::Floor,
    );
    assert_eq!(double_price_result * 2, base_price_result);

    // Test decimal independence: same economic value across decimals
    let result_6_decimals = aum_to_tokens(
        Fraction::from_num(200.0),
        Fraction::from_num(2.0),
        6,
        RoundingMethod::Floor,
    ); // Should be 100 tokens
    let result_8_decimals = aum_to_tokens(
        Fraction::from_num(200.0),
        Fraction::from_num(2.0),
        8,
        RoundingMethod::Floor,
    ); // Should be 100 tokens
    let result_12_decimals = aum_to_tokens(
        Fraction::from_num(200.0),
        Fraction::from_num(2.0),
        12,
        RoundingMethod::Floor,
    ); // Should be 100 tokens

    // Convert to same decimal scale for comparison
    let normalized_6 = result_6_decimals; // 100_000_000
    let normalized_8 = result_8_decimals / 100; // 10_000_000_000 / 100 = 100_000_000
    let normalized_12 = result_12_decimals / 1_000_000; // 100_000_000_000_000 / 1M = 100_000_000

    assert_eq!(normalized_6, normalized_8);
    assert_eq!(normalized_6, normalized_12);
    assert_eq!(normalized_6, 100_000_000); // 100 tokens in 6 decimals
}

#[test]
#[should_panic]
fn test_aum_to_tokens_zero_price() {
    aum_to_tokens(
        Fraction::from_num(100.0),
        Fraction::ZERO, // Zero price should panic
        6,
        RoundingMethod::Floor,
    );
}

use std::collections::HashMap;

use kamino_lending::{fraction::Fraction, program_test::common::math::usdc_decimal_to_u64 as usdc};

use super::tests_utils::fixtures::setup_vault_with_tokens_and_config;
use super::tests_utils::TokenConfig;
use crate::{
    operations::vault_operations,
    types::{DollarValue, NetAum, RoundingMethod, ShareAmount, Timestamp, TokenAmount},
    utils::consts::{PERF_FEE_COOLDOWN_SECONDS, YEAR},
};

#[test]
fn charge_fees_is_noop_when_net_aum_is_negative() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);
    vault.management_fee_bps = 100;
    vault.performance_fee_bps = 1000;

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(usdc(100.0)),
        Timestamp::from(0),
    )
    .unwrap();
    let prev_aum_at_health = vault.prev_aum();
    let shares_issued_at_health = vault.shares_issued;
    let pending_at_health = vault.pending_fees();
    let last_charge_at_health = vault.last_fee_charge_timestamp;

    // charge_fees after a year, with net AUM driven negative by obligation debt
    let free_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil);
    let net_negative = make_net_negative_obligations(free_aum, DollarValue::ZERO);
    let later_ts = last_charge_at_health + u64::from(YEAR);
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        net_negative,
        Timestamp::from(later_ts),
    )
    .unwrap();

    assert_eq!(vault.prev_aum(), prev_aum_at_health);
    assert_eq!(vault.shares_issued, shares_issued_at_health);
    assert_eq!(vault.pending_fees(), pending_at_health);
    assert_eq!(vault.last_fee_charge_timestamp, later_ts);
    assert_eq!(vault.last_perf_fee_charge_timestamp, later_ts);
}

#[test]
fn recovery_from_net_negative_aum_does_not_charge_perf_fee_on_rebound() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);
    vault.management_fee_bps = 0; // isolate perf-fee behavior
    vault.performance_fee_bps = 1000;

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(usdc(100.0)),
        Timestamp::from(0),
    )
    .unwrap();
    let healthy_prev_aum = vault.prev_aum();
    let shares_at_healthy = vault.shares_issued;

    // charge_fees once with net AUM negative
    let free_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil);
    let net_negative = make_net_negative_obligations(free_aum, DollarValue::ZERO);
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        net_negative,
        Timestamp::from(1_000),
    )
    .unwrap();
    assert_eq!(vault.prev_aum(), healthy_prev_aum);

    // rebound: klend socialize_loss writes the debt off, free AUM is the only AUM again
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(2_000 + u64::from(PERF_FEE_COOLDOWN_SECONDS)),
    )
    .unwrap();

    // No growth above the preserved prev_aum, so no perf-fee shares minted on the rebound.
    assert_eq!(vault.shares_issued, shares_at_healthy);
}

#[test]
fn withdraw_pending_fees_still_pulls_pre_loss_accruals_when_net_aum_is_negative() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price(1.0))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);
    vault.management_fee_bps = 200;

    let deposit_ts = 1_000u64;
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(usdc(1_000.0)),
        Timestamp::from(deposit_ts),
    )
    .unwrap();

    // Accrue mgmt fees over a year while healthy.
    vault_operations::charge_fees(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        Timestamp::from(deposit_ts + u64::from(YEAR)),
    )
    .unwrap();
    let pending_pre_loss = vault.pending_fees();
    assert!(!pending_pre_loss.is_zero());

    // Vault goes net negative; admin pulls pending fees.
    let free_aum = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil);
    let net_negative = make_net_negative_obligations(free_aum, DollarValue::ZERO);
    let effects = vault_operations::withdraw_pending_fees(
        &mut vault,
        &vault_scope_prices,
        net_negative,
        Timestamp::from(deposit_ts + u64::from(YEAR) + 1_000),
    )
    .unwrap();

    // Pre-loss accruals are claimable (minted during healthy operation); no fresh accrual.
    assert_eq!(
        effects.available_to_send_to_user,
        ShareAmount::from(u64::from(pending_pre_loss.floor_shares()))
    );
    assert_eq!(u64::from(vault.pending_fees().floor_shares()), 0);
}

// Builds a `NetAum` that drives the vault `excess_debt + 1` dollars net-negative when combined
// with `free_aum`.
fn make_net_negative_obligations(free_aum: DollarValue, excess_debt: DollarValue) -> NetAum {
    NetAum {
        abs_value: free_aum + excess_debt + DollarValue::from(Fraction::from(1u64)),
        negative: true,
    }
}

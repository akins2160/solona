use kamino_lending::assert_fuzzy_eq_f;
use kamino_lending::utils::FractionExtra;
use kamino_lending::{fraction::Fraction, utils::FULL_BPS};

use crate::operations::tests::tests_utils::EPSILON_F;
use crate::types::ratio::Ratio;
use crate::types::{FractionalShares, ShareAmount};
use crate::{
    operations::vault_operations::common::get_shares_to_charge_for_vault_fee,
    utils::consts::MAX_CHARGED_RATE_FOR_VAULT_FEE,
};

#[test]
fn test_get_shares_to_charge_standard_scenarios() {
    struct TestCase {
        fee_bps: u64,
        proportion_numerator: u64,
        proportion_denominator: u64,
        shares_issued: u64,
        expected_shares: f64,
    }

    let test_cases = vec![
        TestCase {
            fee_bps: 5000,           // 50% fee
            proportion_numerator: 1, // Full ratio
            proportion_denominator: 1,
            shares_issued: 10,
            expected_shares: 10.0, // 10 * 50% / (100% - 50%) = 10
        },
        TestCase {
            fee_bps: 1000, // 10% fee
            proportion_numerator: 1,
            proportion_denominator: 1,
            shares_issued: 100,
            expected_shares: 11.111_111_111_111_11, // 100 * 10% / 90% = 11.111...
        },
        TestCase {
            fee_bps: 250, // 2.5% fee
            proportion_numerator: 1,
            proportion_denominator: 1,
            shares_issued: 1000,
            expected_shares: 25.641_025_641_025_64, // 1000 * 2.5% / 97.5% = 25.641...
        },
        TestCase {
            fee_bps: 100, // 1% fee
            proportion_numerator: 1,
            proportion_denominator: 1,
            shares_issued: 10000,
            expected_shares: 101.01010101010101, // 10000 * 1% / 99% = 101.0101...
        },
        TestCase {
            fee_bps: 2000,           // 20% fee
            proportion_numerator: 1, // Half ratio (10% effective)
            proportion_denominator: 2,
            shares_issued: 100,
            expected_shares: 11.111_111_111_111_11, // 100 * 10% / 90% = 11.111...
        },
    ];

    for test in test_cases {
        let result = get_shares_to_charge_for_vault_fee(
            Ratio::from_bps(test.fee_bps),
            Ratio::of(test.proportion_numerator, test.proportion_denominator),
            ShareAmount::from(test.shares_issued).as_fractional(),
        );

        assert_fuzzy_eq_f!(
            Fraction::from(result),
            Fraction::from_num(test.expected_shares),
            EPSILON_F
        );
    }
}

#[test]
fn test_get_shares_to_charge_fee_ratio_scenarios() {
    struct TestCase {
        fee_bps: u64,
        proportion_numerator: u64,
        proportion_denominator: u64,
        shares_issued: u64,
        expected_shares: f64,
    }

    let test_cases = vec![
        TestCase {
            fee_bps: 1000,              // 10% annual fee
            proportion_numerator: 6,    // 6 months passed
            proportion_denominator: 12, // Out of 12 months
            shares_issued: 1000,
            expected_shares: 52.631_578_947_368_42, // 1000 * 5% / 95% = 52.6315...
        },
        TestCase {
            fee_bps: 2000,                // 20% performance fee
            proportion_numerator: 100,    // $100 profit
            proportion_denominator: 1000, // Out of $1000 AUM (10% profit)
            shares_issued: 1000,
            expected_shares: 20.408163265306122, // 1000 * 2% / 98% = 20.408...
        },
        TestCase {
            fee_bps: 500,               // 5% annual fee
            proportion_numerator: 1,    // 1 month passed
            proportion_denominator: 12, // Out of 12 months
            shares_issued: 10000,
            expected_shares: 41.841_004_184_100_42, // 10000 * 0.417% / 99.583% = 41.84...
        },
        TestCase {
            fee_bps: 1500,                // 15% performance fee
            proportion_numerator: 500,    // $500 profit
            proportion_denominator: 2000, // Out of $2000 AUM (25% profit)
            shares_issued: 2000,
            expected_shares: 77.922_077_922_077_92, // 2000 * 3.75% / 96.25% = 77.922...
        },
    ];

    for test in test_cases {
        let result = get_shares_to_charge_for_vault_fee(
            Ratio::from_bps(test.fee_bps),
            Ratio::of(test.proportion_numerator, test.proportion_denominator),
            ShareAmount::from(test.shares_issued).as_fractional(),
        );

        assert_fuzzy_eq_f!(
            Fraction::from(result),
            Fraction::from_num(test.expected_shares),
            EPSILON_F
        );
    }
}

#[test]
fn test_get_shares_to_charge_max_fee_cap() {
    struct TestCase {
        fee_bps: u64,
        proportion_numerator: u64,
        proportion_denominator: u64,
        shares_issued: u64,
        expected_shares: f64,
    }

    let test_cases = vec![
        // Fee capped at MAX_CHARGED_RATE_FOR_VAULT_FEE (50%)
        TestCase {
            fee_bps: 8000, // 80% fee (exceeds max)
            proportion_numerator: 1,
            proportion_denominator: 1,
            shares_issued: 100,
            expected_shares: 100.0, // Capped at 50% -> 100 * 50% / 50% = 100
        },
        TestCase {
            fee_bps: 6000, // 60% fee (exceeds max)
            proportion_numerator: 1,
            proportion_denominator: 1,
            shares_issued: 200,
            expected_shares: 200.0, // Capped at 50% -> 200 * 50% / 50% = 200
        },
        TestCase {
            fee_bps: 10000, // 100% fee (way exceeds max)
            proportion_numerator: 1,
            proportion_denominator: 1,
            shares_issued: 50,
            expected_shares: 50.0, // Capped at 50% -> 50 * 50% / 50% = 50
        },
        TestCase {
            fee_bps: 2000,           // 20% fee
            proportion_numerator: 5, // 5x ratio (100% effective)
            proportion_denominator: 1,
            shares_issued: 100,
            expected_shares: 100.0, // Capped at 50% -> 100 * 50% / 50% = 100
        },
    ];

    for test in test_cases {
        let result = get_shares_to_charge_for_vault_fee(
            Ratio::from_bps(test.fee_bps),
            Ratio::of(test.proportion_numerator, test.proportion_denominator),
            ShareAmount::from(test.shares_issued).as_fractional(),
        );

        assert_fuzzy_eq_f!(
            Fraction::from(result),
            Fraction::from_num(test.expected_shares),
            EPSILON_F
        );
    }
}

#[test]
fn test_get_shares_to_charge_edge_cases() {
    // Zero shares issued
    let result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(1000),
        Ratio::of(1u64, 1u64),
        ShareAmount::ZERO.as_fractional(),
    );
    assert_eq!(result, FractionalShares::ZERO);

    // Zero fee
    let result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(0),
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    assert_eq!(result, FractionalShares::ZERO);

    // Zero numerator (no time passed / no profit)
    let result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(1000),
        Ratio::of(0u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    assert_eq!(result, FractionalShares::ZERO);

    // Very small fee (very close to 0)
    let result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(1), // 0.01% fee
        Ratio::of(1u64, 1000u64),
        ShareAmount::from(10).as_fractional(), // Small shares
    );
    assert_fuzzy_eq_f!(
        Fraction::from(result),
        Fraction::from_num(0.000001000000099994),
        EPSILON_F
    );

    // Very large shares issued
    let result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(100), // 1% fee
        Ratio::of(1u64, 1u64),
        ShareAmount::from(u64::MAX / 2).as_fractional(), // Large number
    );
    assert!(result > FractionalShares::ZERO);

    // Fraction > 1 (more profit than AUM)
    let result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(2000), // 20% performance fee
        Ratio::of(2u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    let expected_fee = Fraction::from_bps(4000).min(Fraction::from_bps(5000u64));
    let expected_shares = Fraction::from(1000u64) * expected_fee / (Fraction::ONE - expected_fee);
    assert_fuzzy_eq_f!(Fraction::from(result), expected_shares, EPSILON_F);
}

#[test]
fn test_get_shares_to_charge_precision_scenarios() {
    struct TestCase {
        fee_bps: u64,
        proportion_numerator: u64,
        proportion_denominator: u64,
        shares_issued: u64,
        expected_shares: f64,
    }

    let test_cases = vec![
        TestCase {
            fee_bps: 333, // 3.33% fee
            proportion_numerator: 1,
            proportion_denominator: 3, // 1/3 ratio
            shares_issued: 9999,
            expected_shares: 112.234_705_228_031_15,
        },
        TestCase {
            fee_bps: 1234, // 12.34% fee
            proportion_numerator: 7,
            proportion_denominator: 11, // 7/11 ratio
            shares_issued: 12345,
            expected_shares: 1_052.032_418_460_567,
        },
        TestCase {
            fee_bps: 567, // 5.67% fee
            proportion_numerator: 123,
            proportion_denominator: 456,
            shares_issued: 7890,
            expected_shares: 122.544_487_968_288_69,
        },
    ];

    for test in test_cases {
        let result = get_shares_to_charge_for_vault_fee(
            Ratio::from_bps(test.fee_bps),
            Ratio::of(test.proportion_numerator, test.proportion_denominator),
            ShareAmount::from(test.shares_issued).as_fractional(),
        );

        assert_fuzzy_eq_f!(
            Fraction::from(result),
            Fraction::from_num(test.expected_shares),
            EPSILON_F
        );
    }
}

#[test]
fn test_get_shares_to_charge_floor_rounding() {
    struct TestCase {
        fee_bps: u64,
        proportion_numerator: u64,
        proportion_denominator: u64,
        shares_issued: u64,
        expected_shares: f64,
    }

    let test_cases = vec![
        // Cases where floor rounding matters
        TestCase {
            fee_bps: 100, // 1% fee
            proportion_numerator: 1,
            proportion_denominator: 3, // 1/3 ratio = 0.333...% effective fee
            shares_issued: 1000,
            expected_shares: 3.344_481_605_351_170_6, // 3.36... shares
        },
        TestCase {
            fee_bps: 500, // 5% fee
            proportion_numerator: 1,
            proportion_denominator: 7, // 1/7 ratio = 0.714...% effective fee
            shares_issued: 1000,
            expected_shares: 7.194_244_604_316_546, // 7.20... shares
        },
        TestCase {
            fee_bps: 200, // 2% fee
            proportion_numerator: 3,
            proportion_denominator: 8, // 3/8 ratio = 0.75% effective fee
            shares_issued: 1000,
            expected_shares: 7.556_675_062_972_292, // 7.55... shares
        },
    ];

    for test in test_cases {
        let result = get_shares_to_charge_for_vault_fee(
            Ratio::from_bps(test.fee_bps),
            Ratio::of(test.proportion_numerator, test.proportion_denominator),
            ShareAmount::from(test.shares_issued).as_fractional(),
        );

        assert_fuzzy_eq_f!(
            Fraction::from(result),
            Fraction::from_num(test.expected_shares),
            EPSILON_F
        );

        let effective_fee = Fraction::from_bps(test.fee_bps)
            * Fraction::from(test.proportion_numerator)
            / Fraction::from(test.proportion_denominator);
        let capped_fee = effective_fee.min(Fraction::from_bps(5000u64));
        let exact_shares =
            Fraction::from(test.shares_issued) * capped_fee / (Fraction::ONE - capped_fee);

        assert_fuzzy_eq_f!(exact_shares, Fraction::from(result), EPSILON_F);
    }
}

#[test]
fn test_get_shares_to_charge_mathematical_properties() {
    // Test proportionality: 2x shares = 2x fee shares
    let base_result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(1000),
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    let double_result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(1000),
        Ratio::of(1u64, 1u64),
        ShareAmount::from(2000).as_fractional(),
    );
    assert_fuzzy_eq_f!(
        Fraction::from(double_result),
        Fraction::from(base_result) * Fraction::from(2u64),
        EPSILON_F
    );

    // Test fee scaling: 2x fee BPS ≈ 2x fee shares (approximately)
    let base_fee_result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(500), // 5%
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    let double_fee_result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(1000), // 10%
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    // Not exactly 2x due to different denominators in formula
    assert!(Fraction::from(double_fee_result) > Fraction::from(base_fee_result) * 2);

    // Test ratio scaling: 2xratio = 2x fee shares
    let fee_bps = 1000;
    let base_ratio_result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(fee_bps),
        Ratio::of(1u64, 2u64), // 50% ratio
        ShareAmount::from(1000000).as_fractional(),
    );
    let double_ratio_result = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(fee_bps),
        Ratio::of(1u64, 1u64), // 100% ratio (2x)
        ShareAmount::from(1000000).as_fractional(),
    );
    // F = 1/2 * fee_bps
    // (SI * F) / (1 - F)
    // If we double F we have (2 * SI * F) / (1 - 2F)
    // This means that double_ratio_result = base_ratio_result * (2 - 2F) / (1 - 2F)
    //                                     = base_ratio_result * (2 - fee_bps) / (1 - fee_bps)
    assert_fuzzy_eq_f!(
        Fraction::from(double_ratio_result),
        Fraction::from(base_ratio_result) * Fraction::from_num(2 * FULL_BPS as u64 - fee_bps)
            / Fraction::from_num(FULL_BPS as u64 - fee_bps),
        EPSILON_F
    );

    // Test fee cap consistency: any fee above max should give same result
    let capped_result_1 = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(6000), // 60% (above 50% cap)
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    let capped_result_2 = get_shares_to_charge_for_vault_fee(
        Ratio::from_bps(8000), // 80% (above 50% cap)
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );
    let max_result = get_shares_to_charge_for_vault_fee(
        MAX_CHARGED_RATE_FOR_VAULT_FEE, // Exactly 50%
        Ratio::of(1u64, 1u64),
        ShareAmount::from(1000).as_fractional(),
    );

    assert_eq!(capped_result_1, max_result);
    assert_eq!(capped_result_2, max_result);
    assert_eq!(capped_result_1, capped_result_2);
}

use std::collections::HashMap;

use proptest::prelude::*;

use crate::{
    operations::{
        effects::{DepositEffects, WithdrawEffects},
        tests::tests_utils::{fixtures::setup_vault_with_tokens_and_config, TokenConfig},
        vault_operations,
    },
    types::{NetAum, RoundingMethod, ShareAmount, Timestamp, TokenAmount, Weight},
    KaminoVaultError,
};
use anchor_lang::error::Error as AnchorError;
use kamino_lending::fraction::Fraction;
use kamino_lending::utils::{FULL_BPS, U256};

/// Build a 3-token vault where token weights and per-token `max_deviation_bps` can be fuzzed.
/// Token AUM values are seeded uniformly and the `max_deviation_bps` is applied on every token.
fn setup_vault(
    prices: [f64; 3],
    decimals: [u8; 3],
    weights: [u64; 3],
    deviations_bps: [u64; 3],
    available: [u64; 3],
) -> (
    crate::MetavaultState,
    crate::GlobalConfig,
    crate::utils::scope::VaultScopePrices,
    [solana_program::pubkey::Pubkey; 3],
) {
    let tokens = [
        (
            "BTC",
            TokenConfig::with_price_and_decimals(prices[0], decimals[0]),
        ),
        (
            "SOL",
            TokenConfig::with_price_and_decimals(prices[1], decimals[1]),
        ),
        (
            "USDC",
            TokenConfig::with_price_and_decimals(prices[2], decimals[2]),
        ),
    ];
    let mint_btc = tokens[0].1.mint;
    let mint_sol = tokens[1].1.mint;
    let mint_usdc = tokens[2].1.mint;
    let map = HashMap::from_iter(tokens);
    let (mut vault, config, scope_prices) = setup_vault_with_tokens_and_config(&map, 0, 0);

    for token in vault.vault_tokens.iter_mut() {
        if token.mint == mint_btc {
            token.token_available = available[0];
            token.weight = weights[0];
            token.max_deviation_bps = deviations_bps[0];
        } else if token.mint == mint_sol {
            token.token_available = available[1];
            token.weight = weights[1];
            token.max_deviation_bps = deviations_bps[1];
        } else if token.mint == mint_usdc {
            token.token_available = available[2];
            token.weight = weights[2];
            token.max_deviation_bps = deviations_bps[2];
        }
    }

    (vault, config, scope_prices, [mint_btc, mint_sol, mint_usdc])
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(10_000))]

    /// After any successful deposit with `max_deviation_bps > 0`, the resulting per-token weight
    /// must not exceed `target + deviation`. With the pre-fee clamp and Floor-rounded bound math,
    /// this is strict — no fee-donation slack in the deposited portion.
    #[test]
    fn test_deposit_upper_bound_holds(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in [100_u64..=5000, 100_u64..=5000, 100_u64..=5000],
        available in [
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
        ],
        token_idx in 0_usize..3,
        deposit_amount in 1_u64..10_000_000_000,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, dev_bps, available);

        let target_mint = mints[token_idx];
        let res = vault_operations::deposit(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, TokenAmount::new(deposit_amount), Timestamp::from(3600),
        );

        // The deposit is allowed to fail (e.g. TargetBoundExceeded, shares-zero, etc.); only
        // assert the invariant when it succeeds.
        if let Ok(DepositEffects { .. }) = res {
            let sum_weights: u64 = vault.iter_enabled_tokens().map(|t| t.weight).sum();
            let weight_k = vault.get_vault_token_by_mint(&target_mint).unwrap().weight;
            let dev_k = vault.get_vault_token_by_mint(&target_mint).unwrap().max_deviation_bps;

            // Measure post-deposit v_k/total in the direction that *over-estimates* the ratio —
            // Ceil on v_k, Floor on total — so an off-by-one violation is surfaced rather than
            // absorbed by f64 noise.
            let vault_token_idx = vault
                .get_vault_token_id_by_mint(&target_mint)
                .unwrap()
                .input_account_index;
            let v_k = Fraction::from(
                vault
                    .get_vault_token_by_mint(&target_mint)
                    .unwrap()
                    .compute_aum(&scope_prices.prices[vault_token_idx], RoundingMethod::Ceil),
            );
            let total = Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Floor));
            prop_assume!(total > Fraction::ZERO);

            // upper = (weight_k * FULL_BPS + dev_k * sum_weights) / (sum_weights * FULL_BPS).
            // Check v_k / total <= upper via U256 cross-multiplication — no f64.
            let upper_num = u128::from(weight_k) * u128::from(FULL_BPS)
                + u128::from(dev_k) * u128::from(sum_weights);
            let upper_denom = u128::from(sum_weights) * u128::from(FULL_BPS);
            let lhs = U256::from(v_k.to_bits()) * U256::from(upper_denom);
            let rhs = U256::from(total.to_bits()) * U256::from(upper_num);
            prop_assert!(
                lhs <= rhs,
                "post-deposit weight {v_k}/{total} exceeds upper \
                 {upper_num}/{upper_denom} (dev_bps={dev_k})",
            );
        }
    }

    /// Symmetric lower-bound invariant on withdraw.
    #[test]
    fn test_withdraw_lower_bound_holds(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in [100_u64..=5000, 100_u64..=5000, 100_u64..=5000],
        available in [
            1_000_000_000_u64..100_000_000_000,
            1_000_000_000_u64..100_000_000_000,
            1_000_000_000_u64..100_000_000_000,
        ],
        token_idx in 0_usize..3,
        withdraw_shares in 1_u64..500,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, dev_bps, available);

        let target_mint = mints[token_idx];
        let res = vault_operations::withdraw(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, Timestamp::from(3600), ShareAmount::new(withdraw_shares),
        );

        if let Ok(WithdrawEffects { .. }) = res {
            let sum_weights: u64 = vault.iter_enabled_tokens().map(|t| t.weight).sum();
            let weight_k = vault.get_vault_token_by_mint(&target_mint).unwrap().weight;
            let dev_k = vault.get_vault_token_by_mint(&target_mint).unwrap().max_deviation_bps;
            // If target <= deviation, lower clamps to 0 and the invariant is vacuous.
            let weight_scaled = u128::from(weight_k) * u128::from(FULL_BPS);
            let dev_scaled = u128::from(dev_k) * u128::from(sum_weights);
            if weight_scaled <= dev_scaled {
                return Ok(());
            }

            // Measure post-withdraw v_k/total in the direction that *under-estimates* the ratio —
            // Floor on v_k, Ceil on total — so an off-by-one violation is surfaced.
            let vault_token_idx = vault
                .get_vault_token_id_by_mint(&target_mint)
                .unwrap()
                .input_account_index;
            let v_k = Fraction::from(
                vault
                    .get_vault_token_by_mint(&target_mint)
                    .unwrap()
                    .compute_aum(&scope_prices.prices[vault_token_idx], RoundingMethod::Floor),
            );
            let total = Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Ceil));
            prop_assume!(total > Fraction::ZERO);

            // lower = (weight_k * FULL_BPS - dev_k * sum_weights) / (sum_weights * FULL_BPS).
            // Check v_k / total >= lower via U256 cross-multiplication.
            let lower_num = weight_scaled - dev_scaled;
            let lower_denom = u128::from(sum_weights) * u128::from(FULL_BPS);
            let lhs = U256::from(v_k.to_bits()) * U256::from(lower_denom);
            let rhs = U256::from(total.to_bits()) * U256::from(lower_num);
            prop_assert!(
                lhs >= rhs,
                "post-withdraw weight {v_k}/{total} below lower \
                 {lower_num}/{lower_denom} (dev_bps={dev_k})",
            );
        }
    }

    /// Clamp is monotonic: a deposit with a huge `max_user_tokens_to_deposit` never results in
    /// more tokens deposited than a deposit with exactly `bound_max`. Practically we assert that
    /// the deposit never admits more than what the bound helper returns as the clamp ceiling.
    #[test]
    fn test_deposit_does_not_exceed_bound(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in [100_u64..=5000, 100_u64..=5000, 100_u64..=5000],
        available in [
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
        ],
        token_idx in 0_usize..3,
        deposit_amount in 100_u64..10_000_000_000,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, dev_bps, available);
        let target_mint = mints[token_idx];
        let vault_token_id = vault.get_vault_token_id_by_mint(&target_mint).unwrap();
        let bound_max = vault_operations::compute_max_deposit_by_target_bound(
            &vault,
            &scope_prices,
            vault_token_id,
        )
        .unwrap();

        let res = vault_operations::deposit(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, TokenAmount::new(deposit_amount), Timestamp::from(3600),
        );

        if let Ok(DepositEffects { token_to_deposit, .. }) = res {
            prop_assert!(
                u64::from(token_to_deposit) <= u64::from(bound_max),
                "actual deposit {token_to_deposit} exceeded bound_max {bound_max}",
            );
        }
    }

    /// Withdraw clamp is monotonic in the same way as deposit: a successful withdraw never sends
    /// more tokens than the lower-bound helper allowed before the operation.
    #[test]
    fn test_withdraw_does_not_exceed_bound(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in [100_u64..=5000, 100_u64..=5000, 100_u64..=5000],
        available in [
            1_000_000_000_u64..100_000_000_000,
            1_000_000_000_u64..100_000_000_000,
            1_000_000_000_u64..100_000_000_000,
        ],
        token_idx in 0_usize..3,
        withdraw_shares in 1_u64..500,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, dev_bps, available);
        let target_mint = mints[token_idx];
        let vault_token_id = vault.get_vault_token_id_by_mint(&target_mint).unwrap();
        let bound_max = vault_operations::compute_max_withdraw_by_target_bound(
            &vault,
            &scope_prices,
            vault_token_id,
        )
        .unwrap();

        let res = vault_operations::withdraw(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, Timestamp::from(3600), ShareAmount::new(withdraw_shares),
        );

        if let Ok(WithdrawEffects { available_to_send_to_user, .. }) = res {
            prop_assert!(
                u64::from(available_to_send_to_user) <= u64::from(bound_max),
                "actual withdraw {available_to_send_to_user} exceeded bound_max {bound_max}",
            );
        }
    }

    /// When deviation is 0 on every token the clamp is a no-op; the function must never
    /// spontaneously return MORE tokens than the user requested (same safety as the existing
    /// `DepositAmountGreaterThanRequestedAmount` invariant).
    #[test]
    fn test_disabled_bound_never_inflates_deposit(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        available in [
            1_000_000_u64..100_000_000,
            1_000_000_u64..100_000_000,
            1_000_000_u64..100_000_000,
        ],
        token_idx in 0_usize..3,
        deposit_amount in 10_000_u64..1_000_000_000,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, [0, 0, 0], available);
        let target_mint = mints[token_idx];
        let res = vault_operations::deposit(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, TokenAmount::new(deposit_amount), Timestamp::from(3600),
        );
        if let Ok(DepositEffects { token_to_deposit, .. }) = res {
            prop_assert!(
                u64::from(token_to_deposit) <= deposit_amount,
                "disabled-bound deposit must not exceed requested \
                 ({token_to_deposit} vs {deposit_amount})",
            );
        }
    }

    /// Deposits that fail solely because of the clamp ⇒ the returned error must be the new
    /// `TargetBoundExceeded` (never e.g. `DepositAmountsZero` masquerading as the same thing).
    /// We only assert when the helper itself returns bound_max == 0 (pre-existing out-of-bound
    /// state), so the error source is unambiguous. Prices/decimals are fixed to uniform $1 / 6
    /// decimals so the heavy `available[token_idx]` skew reliably drives the target token above
    /// its upper bound — without this, non-uniform prices would under-weight the "heavy" token and
    /// the assertion would silently skip via the `prop_assume!`.
    #[test]
    fn test_zero_bound_triggers_specific_error(
        weights in [1_u64..10, 1_u64..10, 1_u64..10],
        dev_bps in 100_u64..1000,
        token_idx in 0_usize..3,
        deposit_amount in 1_u64..1_000_000,
    ) {
        let mut available = [1_000_000_u64; 3];
        available[token_idx] = 1_000_000_000_000;
        let (mut vault, config, scope_prices, mints) =
            setup_vault([1.0; 3], [6; 3], weights, [dev_bps; 3], available);
        let target_mint = mints[token_idx];
        let vault_token_id = vault.get_vault_token_id_by_mint(&target_mint).unwrap();
        let bound_max = vault_operations::compute_max_deposit_by_target_bound(
            &vault, &scope_prices, vault_token_id,
        )
        .unwrap();
        prop_assume!(bound_max == TokenAmount::ZERO);

        let res = vault_operations::deposit(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, TokenAmount::new(deposit_amount), Timestamp::from(3600),
        );
        let expected: Result<DepositEffects, AnchorError> = Err(AnchorError::from(
            KaminoVaultError::TargetBoundExceeded,
        ));
        prop_assert_eq!(res, expected);
    }

    /// Running N deposits in a row must leave the upper-bound invariant intact after every step:
    /// accumulated fixed-point rounding never pushes the weight above `target + deviation`.
    #[test]
    fn test_consecutive_deposits_never_cross_upper_bound(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in [100_u64..=5000, 100_u64..=5000, 100_u64..=5000],
        available in [
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
        ],
        token_idx in 0_usize..3,
        per_step_deposit in 1_u64..10_000_000_000,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, dev_bps, available);
        let target_mint = mints[token_idx];

        for _ in 0..10 {
            let res = vault_operations::deposit(
                &mut vault, &scope_prices, NetAum::ZERO, &config,
                target_mint, TokenAmount::new(per_step_deposit), Timestamp::from(3600),
            );
            if res.is_err() {
                continue;
            }

            let sum_weights: u64 = vault.iter_enabled_tokens().map(|t| t.weight).sum();
            let weight_k = vault.get_vault_token_by_mint(&target_mint).unwrap().weight;
            let dev_k = vault.get_vault_token_by_mint(&target_mint).unwrap().max_deviation_bps;

            let vault_token_idx = vault
                .get_vault_token_id_by_mint(&target_mint)
                .unwrap()
                .input_account_index;
            let v_k = Fraction::from(
                vault
                    .get_vault_token_by_mint(&target_mint)
                    .unwrap()
                    .compute_aum(&scope_prices.prices[vault_token_idx], RoundingMethod::Ceil),
            );
            let total = Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Floor));
            prop_assume!(total > Fraction::ZERO);

            let upper_num = u128::from(weight_k) * u128::from(FULL_BPS)
                + u128::from(dev_k) * u128::from(sum_weights);
            let upper_denom = u128::from(sum_weights) * u128::from(FULL_BPS);
            let lhs = U256::from(v_k.to_bits()) * U256::from(upper_denom);
            let rhs = U256::from(total.to_bits()) * U256::from(upper_num);
            prop_assert!(
                lhs <= rhs,
                "step violated upper: {v_k}/{total} vs {upper_num}/{upper_denom}",
            );
        }
    }

    /// In a sequence of alternating deposit/withdraw operations, each successful op on token k
    /// must leave token k inside the bound that applied to it. Ops on OTHER tokens can legitimately
    /// move k's weight outside its bound (e.g. a withdraw on j shrinks total_aum, inflating k's
    /// weight), so we only check the target of the *current* successful op — this verifies the
    /// bound computation stays correct against accumulated state, not just the fresh setup.
    #[test]
    fn test_alternating_deposit_withdraw_respects_per_op_bound(
        // Realistic Solana token shapes: prices >= $1 and decimals 6..=9 reflect
        // stablecoins/major tokens; 4-decimal tokens at hundreds of dollars (the
        // adversarial input that produced ~2e8 lamports/$) don't exist in production.
        prices in [1.0_f64..500.0, 1.0_f64..500.0, 1.0_f64..500.0],
        decimals in [6_u8..=9, 6_u8..=9, 6_u8..=9],
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        // 1-20% deviation tolerance covers the realistic policy range; >=50% would
        // imply a vault almost fully concentrated in one token.
        dev_bps in [100_u64..=2000, 100_u64..=2000, 100_u64..=2000],
        // Same range as the single-op tests: large enough that withdraws stay solvent
        // but bounded so the worst-case bound math fits in u64 lamports.
        available in [
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
        ],
        deposit_amount in 1_u64..100_000_000,
        withdraw_shares in 1_u64..200,
        token_sequence in proptest::array::uniform16(0_usize..3),
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights, dev_bps, available);

        for (step, &token_idx) in token_sequence.iter().enumerate() {
            let target_mint = mints[token_idx];
            let is_deposit = step % 2 == 0;
            let op_succeeded = if is_deposit {
                vault_operations::deposit(
                    &mut vault, &scope_prices, NetAum::ZERO, &config,
                    target_mint, TokenAmount::new(deposit_amount), Timestamp::from(3600),
                ).is_ok()
            } else {
                vault_operations::withdraw(
                    &mut vault, &scope_prices, NetAum::ZERO, &config,
                    target_mint, Timestamp::from(3600), ShareAmount::new(withdraw_shares),
                ).is_ok()
            };
            if !op_succeeded {
                continue;
            }

            let sum_weights: u64 = vault.iter_enabled_tokens().map(|t| t.weight).sum();
            let weight_k = vault.get_vault_token_by_mint(&target_mint).unwrap().weight;
            let dev_k = vault.get_vault_token_by_mint(&target_mint).unwrap().max_deviation_bps;

            let vault_token_idx = vault
                .get_vault_token_id_by_mint(&target_mint)
                .unwrap()
                .input_account_index;
            let price = &scope_prices.prices[vault_token_idx];
            let denom = u128::from(sum_weights) * u128::from(FULL_BPS);

            if is_deposit {
                // Upper: Ceil v_k, Floor total — over-estimate the ratio. Vacuous when upper >= 1,
                // mirroring the lower <= 0 case below: no allocation can exceed 100%, so
                // `compute_max_deposit_by_target_bound` disables the clamp. Once the other tokens
                // have been withdrawn to zero, token k *is* the whole vault and the deliberately
                // skewed rounding puts Ceil(v_k) one ulp above Floor(total) on its own.
                let upper_num = u128::from(weight_k) * u128::from(FULL_BPS)
                    + u128::from(dev_k) * u128::from(sum_weights);
                if upper_num >= denom {
                    continue;
                }
                let v_k = Fraction::from(
                    vault
                        .get_vault_token_by_mint(&target_mint)
                        .unwrap()
                        .compute_aum(price, RoundingMethod::Ceil),
                );
                let total = Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Floor));
                prop_assume!(total > Fraction::ZERO);
                prop_assert!(
                    U256::from(v_k.to_bits()) * U256::from(denom)
                        <= U256::from(total.to_bits()) * U256::from(upper_num),
                    "post-deposit upper violated at step {step}: {v_k}/{total}",
                );
            } else {
                // Lower: Floor v_k, Ceil total — under-estimate the ratio. Vacuous when lower <= 0.
                let weight_scaled = u128::from(weight_k) * u128::from(FULL_BPS);
                let dev_scaled = u128::from(dev_k) * u128::from(sum_weights);
                if weight_scaled <= dev_scaled {
                    continue;
                }
                let v_k = Fraction::from(
                    vault
                        .get_vault_token_by_mint(&target_mint)
                        .unwrap()
                        .compute_aum(price, RoundingMethod::Floor),
                );
                let total = Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Ceil));
                prop_assume!(total > Fraction::ZERO);
                let lower_num = weight_scaled - dev_scaled;
                prop_assert!(
                    U256::from(v_k.to_bits()) * U256::from(denom)
                        >= U256::from(total.to_bits()) * U256::from(lower_num),
                    "post-withdraw lower violated at step {step}: {v_k}/{total}",
                );
            }
        }
    }

    /// After admin updates the weight array, subsequent deposits must respect the *new* target
    /// (not the weights that were in effect at the previous op).
    #[test]
    fn test_weight_update_then_deposit_respects_new_bounds(
        prices in [0.5_f64..500.0, 0.5_f64..500.0, 0.5_f64..500.0],
        decimals in [4_u8..9, 4_u8..9, 4_u8..9],
        weights_before in [1_u64..20, 1_u64..20, 1_u64..20],
        weights_after in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in [100_u64..=5000, 100_u64..=5000, 100_u64..=5000],
        available in [
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
            1_000_000_u64..1_000_000_000,
        ],
        token_idx in 0_usize..3,
        deposit_amount in 1_u64..10_000_000_000,
    ) {
        let (mut vault, config, scope_prices, mints) =
            setup_vault(prices, decimals, weights_before, dev_bps, available);

        // Point the vault at the new weights; production update_token_weights expects a Vec length
        // matching the enabled token count and a non-zero sum — both guarded by the input range.
        vault_operations::update_token_weights(
            &mut vault,
            weights_after.iter().copied().map(Weight::from).collect(),
            Timestamp::ZERO,
        )
        .unwrap();

        let target_mint = mints[token_idx];
        let res = vault_operations::deposit(
            &mut vault, &scope_prices, NetAum::ZERO, &config,
            target_mint, TokenAmount::new(deposit_amount), Timestamp::from(3600),
        );
        if res.is_err() {
            return Ok(());
        }

        let sum_weights: u64 = vault.iter_enabled_tokens().map(|t| t.weight).sum();
        let weight_k = vault.get_vault_token_by_mint(&target_mint).unwrap().weight;
        let dev_k = vault.get_vault_token_by_mint(&target_mint).unwrap().max_deviation_bps;

        let vault_token_idx = vault
            .get_vault_token_id_by_mint(&target_mint)
            .unwrap()
            .input_account_index;
        let v_k = Fraction::from(
            vault
                .get_vault_token_by_mint(&target_mint)
                .unwrap()
                .compute_aum(&scope_prices.prices[vault_token_idx], RoundingMethod::Ceil),
        );
        let total = Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Floor));
        prop_assume!(total > Fraction::ZERO);

        let upper_num = u128::from(weight_k) * u128::from(FULL_BPS)
            + u128::from(dev_k) * u128::from(sum_weights);
        let upper_denom = u128::from(sum_weights) * u128::from(FULL_BPS);
        prop_assert!(
            U256::from(v_k.to_bits()) * U256::from(upper_denom)
                <= U256::from(total.to_bits()) * U256::from(upper_num),
            "post-update deposit weight {v_k}/{total} exceeds new upper \
             {upper_num}/{upper_denom}",
        );
    }

    /// Withdraws that fail solely because the token is already below its lower target bound must
    /// return the target-bound error, not a generic withdraw amount error.
    #[test]
    fn test_zero_withdraw_bound_triggers_specific_error(
        weights in [1_u64..20, 1_u64..20, 1_u64..20],
        dev_bps in 100_u64..1000,
        token_idx in 0_usize..3,
        withdraw_shares in 1_u64..500,
    ) {
        let mut available = [1_000_000_000_000_u64; 3];
        available[token_idx] = 1_000_000;
        let (mut vault, config, scope_prices, mints) =
            setup_vault([1.0; 3], [6; 3], weights, [dev_bps; 3], available);
        let target_mint = mints[token_idx];
        let vault_token_id = vault.get_vault_token_id_by_mint(&target_mint).unwrap();
        let bound_max = vault_operations::compute_max_withdraw_by_target_bound(
            &vault, &scope_prices, vault_token_id,
        )
        .unwrap();

        if bound_max == TokenAmount::ZERO {
            let res = vault_operations::withdraw(
                &mut vault, &scope_prices, NetAum::ZERO, &config,
                target_mint, Timestamp::from(3600), ShareAmount::new(withdraw_shares),
            );
            let expected: Result<WithdrawEffects, AnchorError> = Err(AnchorError::from(
                KaminoVaultError::TargetBoundExceeded,
            ));
            prop_assert_eq!(res, expected);
        }
    }
}

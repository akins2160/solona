use kamino_lending::fraction::Fraction;

use crate::operations::vault_operations::common::compute_user_total_received_on_withdraw;
use crate::types::{DollarValue, Ratio, ShareAmount, TokenAmount, TokenPrice};

#[test]
fn test_compute_user_total_received_standard_scenarios() {
    struct TestCase {
        shares_issued: u64,
        vault_total_holdings: f64,
        shares_to_withdraw: u64,
        token_price: f64,
        token_decimals: u8,
        expected_tokens: u64,
    }

    let test_cases = vec![
        TestCase {
            shares_issued: 100_000_000,     // 100 shares
            vault_total_holdings: 1000.0,   // $1000 AUM
            shares_to_withdraw: 25_000_000, // 25 shares = $250 AUM
            token_price: 2.50,              // $2.50
            token_decimals: 6,
            expected_tokens: 100_000_000, // 100 tokens
        },
        TestCase {
            shares_issued: 200_000_000,
            vault_total_holdings: 2000.0,
            shares_to_withdraw: 100_000_000, // 50% = $1000 AUM
            token_price: 1.0,                // $1.00
            token_decimals: 6,
            expected_tokens: 1_000_000_000, // 1000 tokens
        },
        TestCase {
            shares_issued: 1_000_000,
            vault_total_holdings: 500.0,
            shares_to_withdraw: 100_000, // 10% = $50 AUM
            token_price: 0.50,           // $0.50
            token_decimals: 6,
            expected_tokens: 100_000_000, // 100 tokens
        },
        TestCase {
            shares_issued: 333,
            vault_total_holdings: 999.0,
            shares_to_withdraw: 111, // 1/3 = $333 AUM
            token_price: 3.0,        // $3.00
            token_decimals: 6,
            expected_tokens: 111_000_000, // 111 tokens
        },
    ];

    for test in test_cases {
        let result = compute_user_total_received_on_withdraw(
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            Ratio::of(
                ShareAmount::from(test.shares_to_withdraw),
                ShareAmount::from(test.shares_issued),
            ),
            &TokenPrice::new(Fraction::from_num(test.token_price), test.token_decimals),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
fn test_compute_user_total_received_different_decimals() {
    struct TestCase {
        shares_issued: u64,
        vault_total_holdings: f64,
        shares_to_withdraw: u64,
        token_price: f64,
        token_decimals: u8,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // 2 decimal token scenarios
        TestCase {
            shares_issued: 100_000_000,
            vault_total_holdings: 1000.0,
            shares_to_withdraw: 25_000_000, // $250 AUM
            token_price: 2.50,              // $2.50
            token_decimals: 2,
            expected_tokens: 10_000, // 100 tokens (2 decimals)
        },
        // 8 decimal token scenarios
        TestCase {
            shares_issued: 100_000_000,
            vault_total_holdings: 1000.0,
            shares_to_withdraw: 25_000_000, // $250 AUM
            token_price: 2.50,              // $2.50
            token_decimals: 8,
            expected_tokens: 10_000_000_000, // 100 tokens (8 decimals)
        },
        // 9 decimal token scenarios
        TestCase {
            shares_issued: 1_000_000_000,
            vault_total_holdings: 1000.0,
            shares_to_withdraw: 100_000_000, // 10% = $100 AUM
            token_price: 10.0,               // $10.00
            token_decimals: 9,
            expected_tokens: 10_000_000_000, // 10 tokens (9 decimals)
        },
        // 12 decimal token scenarios
        TestCase {
            shares_issued: 1_000_000_000_000,
            vault_total_holdings: 1_000_000.0,
            shares_to_withdraw: 100_000_000_000, // 10% = $100K AUM
            token_price: 2500.0,                 // $2500
            token_decimals: 12,
            expected_tokens: 40_000_000_000_000, // 40 tokens (12 decimals)
        },
    ];

    for test in test_cases {
        let result = compute_user_total_received_on_withdraw(
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            Ratio::of(
                ShareAmount::from(test.shares_to_withdraw),
                ShareAmount::from(test.shares_issued),
            ),
            &TokenPrice::new(Fraction::from_num(test.token_price), test.token_decimals),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
fn test_compute_user_total_received_different_token_prices() {
    struct TestCase {
        token_price: f64,
        shares_to_withdraw: u64,
        expected_tokens: u64,
    }

    // Vault: 100 shares, $1000 AUM, so $10 per share, 6 decimal tokens
    let vault_shares = ShareAmount::from(100_000_000);
    let vault_aum = DollarValue::from(Fraction::from_num(1000.0));

    let test_cases = vec![
        TestCase {
            token_price: 1.0,               // $1 token
            shares_to_withdraw: 10_000_000, // 10 shares = $100 AUM
            expected_tokens: 100_000_000,   // 100 tokens
        },
        TestCase {
            token_price: 0.50,              // $0.50 token
            shares_to_withdraw: 10_000_000, // 10 shares = $100 AUM
            expected_tokens: 200_000_000,   // 200 tokens
        },
        TestCase {
            token_price: 2.0,               // $2.00 token
            shares_to_withdraw: 10_000_000, // 10 shares = $100 AUM
            expected_tokens: 50_000_000,    // 50 tokens
        },
        TestCase {
            token_price: 100.0,             // $100 token
            shares_to_withdraw: 10_000_000, // 10 shares = $100 AUM
            expected_tokens: 1_000_000,     // 1 token
        },
        TestCase {
            token_price: 0.001,                   // $0.001 token
            shares_to_withdraw: 10_000_000,       // 10 shares = $100 AUM
            expected_tokens: 100_000_000_000 - 1, // 100,000 tokens but lose 1 due to fraction precision
        },
        TestCase {
            token_price: 45000.0,           // $45K token (Bitcoin-like)
            shares_to_withdraw: 45_000_000, // 45 shares = $450 AUM
            expected_tokens: 10_000,        // 0.01 tokens (6 decimals)
        },
    ];

    for test in test_cases {
        let result = compute_user_total_received_on_withdraw(
            vault_aum,
            Ratio::of(ShareAmount::from(test.shares_to_withdraw), vault_shares),
            &TokenPrice::new(Fraction::from_num(test.token_price), 6),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
fn test_compute_user_total_received_floor_rounding() {
    struct TestCase {
        shares_issued: u64,
        vault_total_holdings: f64,
        shares_to_withdraw: u64,
        token_price: f64,
        token_decimals: u8,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // Cases where floor rounding matters
        TestCase {
            shares_issued: 3,
            vault_total_holdings: 10.0,
            shares_to_withdraw: 1, // 1/3 = $3.333... AUM
            token_price: 1.0,      // $1.00
            token_decimals: 6,
            expected_tokens: 3_333_333, // Floor of 3333333.
        },
        TestCase {
            shares_issued: 7,
            vault_total_holdings: 3.0,
            shares_to_withdraw: 1, // 1/7 = $0.428571... AUM
            token_price: 1.0,      // $1.00
            token_decimals: 6,
            expected_tokens: 428_571, // Floor of 428571.
        },
        TestCase {
            shares_issued: 1000,
            vault_total_holdings: 333.0,
            shares_to_withdraw: 1, // 0.1% = $0.333 AUM
            token_price: 1.0,      // $1.00
            token_decimals: 6,
            expected_tokens: 333_000 - 1, // Floor of 333000. but lose 1 due fraction precision
        },
        // Very small withdrawal that rounds to zero
        TestCase {
            shares_issued: 1_000_000_000_000,
            vault_total_holdings: 1.0,
            shares_to_withdraw: 1, // Tiny fraction
            token_price: 1000.0,   // Expensive token
            token_decimals: 6,
            expected_tokens: 0, // Rounds down to 0
        },
    ];

    for test in test_cases {
        let result = compute_user_total_received_on_withdraw(
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            Ratio::of(
                ShareAmount::from(test.shares_to_withdraw),
                ShareAmount::from(test.shares_issued),
            ),
            &TokenPrice::new(Fraction::from_num(test.token_price), test.token_decimals),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
#[should_panic]
fn test_compute_user_total_received_zero_price() {
    // Zero token price
    compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(25_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::ZERO, 6),
    );
}

#[test]
fn test_compute_user_total_received_edge_cases() {
    // Zero shares to withdraw
    let result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(ShareAmount::from(0), ShareAmount::from(100_000_000)),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    assert_eq!(result, TokenAmount::from(0));

    // Empty vault
    let result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::ZERO),
        Ratio::of(
            ShareAmount::from(25_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    assert_eq!(result, TokenAmount::from(0));

    // Single share from single share vault
    let result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(100.0)),
        Ratio::of(ShareAmount::from(1), ShareAmount::from(1)),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    assert_eq!(result, TokenAmount::from(100_000_000));

    // Full vault withdrawal
    let result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(500.0)),
        Ratio::of(ShareAmount::from(1_000_000), ShareAmount::from(1_000_000)),
        &TokenPrice::new(Fraction::from_num(0.5), 6),
    );
    assert_eq!(result, TokenAmount::from(1_000_000_000)); // 1000 tokens
}

#[test]
fn test_compute_user_total_received_mathematical_properties() {
    // Test proportionality: 2x shares = 2x tokens
    let base_result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    let double_result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(20_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    assert_eq!(double_result, TokenAmount::from(u64::from(base_result) * 2));

    // Test price scaling: 2x price = 0.5x tokens
    let base_price_result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::from_num(10.0), 6),
    );
    let double_price_result = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(1000.0)),
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::from_num(20.0), 6),
    );
    assert_eq!(
        u64::from(double_price_result) * 2,
        u64::from(base_price_result)
    );

    // Test decimal scaling: same economic value across decimals
    let result_6_decimals = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(200.0)), // $200 vault
        Ratio::of(
            ShareAmount::from(50_000_000),
            ShareAmount::from(100_000_000),
        ), // 50% withdrawal = $100
        &TokenPrice::new(Fraction::from_num(2.0), 6), // $2 token
    );
    let result_8_decimals = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(200.0)),
        Ratio::of(
            ShareAmount::from(50_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::from_num(2.0), 8),
    );
    let result_12_decimals = compute_user_total_received_on_withdraw(
        DollarValue::from(Fraction::from_num(200.0)),
        Ratio::of(
            ShareAmount::from(50_000_000),
            ShareAmount::from(100_000_000),
        ),
        &TokenPrice::new(Fraction::from_num(2.0), 12),
    );

    // Convert to same decimal scale for comparison
    let normalized_6 = u64::from(result_6_decimals);
    let normalized_8 = u64::from(result_8_decimals) / 100;
    let normalized_12 = u64::from(result_12_decimals) / 1_000_000;

    assert_eq!(normalized_6, normalized_8);
    assert_eq!(normalized_6, normalized_12);
    assert_eq!(normalized_6, 50_000_000); // 50 tokens in 6 decimals

    // Test floor rounding property: result <= exact calculation
    let shares_issued = ShareAmount::from(3);
    let vault_holdings = DollarValue::from(Fraction::from_num(10.0));
    let shares_to_withdraw = ShareAmount::from(1);
    let token_price = TokenPrice::new(Fraction::ONE, 6);

    let result = compute_user_total_received_on_withdraw(
        vault_holdings,
        Ratio::of(shares_to_withdraw, shares_issued),
        &token_price,
    );

    // Calculate exact AUM then exact tokens
    let exact_aum = Fraction::from_num(10.0) * Fraction::from_num(1u64) / Fraction::from_num(3u64);
    let exact_tokens_f64 = exact_aum.to_num::<f64>() * 10f64.powi(6);
    let exact_tokens_floor = exact_tokens_f64.floor() as u64;

    assert_eq!(result, TokenAmount::from(exact_tokens_floor));
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use anchor_lang::error::Error;

    use crate::{
        operations::{
            tests::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig},
            vault_operations::{
                compute_max_deposit_by_target_bound, compute_max_withdraw_by_target_bound,
            },
        },
        types::{TokenAmount, Weight},
        KaminoVaultError,
    };

    /// Resolve a vault token id by mint (test helper to avoid borrow checker gymnastics).
    fn vault_token_id(
        vault: &mut crate::MetavaultState,
        mint: solana_program::pubkey::Pubkey,
    ) -> crate::types::VaultTokenId {
        vault.get_vault_token_id_by_mint(&mint).unwrap()
    }

    fn two_token_equal_setup(
        dev_bps_usdc: u64,
        dev_bps_usdt: u64,
    ) -> (
        crate::MetavaultState,
        crate::utils::scope::VaultScopePrices,
        solana_program::pubkey::Pubkey,
        solana_program::pubkey::Pubkey,
    ) {
        // Two tokens, both $1.0, 6 decimals, equal target weight. After seed deposit of the
        // alphabetically-first token, only USDC has token_available. We manually top up USDT
        // so both have equal AUM = 1000_000_000 lamports ($1000) — easy-to-verify math.
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdt = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdc_mint = usdc.mint;
        let usdt_mint = usdt.mint;
        let tokens = HashMap::from_iter([("USDC", usdc), ("USDT", usdt)]);
        let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);

        // Fund both tokens with the same lamport amount so current weights are exactly 50/50.
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint || token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
        }
        // Set equal target weights (50/50) and configured deviations.
        for token in vault.vault_tokens.iter_mut() {
            token.weight = 1;
            if token.mint == usdc_mint {
                token.max_deviation_bps = dev_bps_usdc;
            } else if token.mint == usdt_mint {
                token.max_deviation_bps = dev_bps_usdt;
            }
        }

        (vault, vault_scope_prices, usdc_mint, usdt_mint)
    }

    fn mixed_price_setup(
        dev_bps: u64,
    ) -> (
        crate::MetavaultState,
        crate::utils::scope::VaultScopePrices,
        solana_program::pubkey::Pubkey,
        solana_program::pubkey::Pubkey,
    ) {
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let sol = TokenConfig::with_price_and_decimals(100.0, 9);
        let usdc_mint = usdc.mint;
        let sol_mint = sol.mint;
        let tokens = HashMap::from_iter([("USDC", usdc), ("SOL", sol)]);
        let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint {
                token.token_available = 1_000_000_000; // $1000
            } else if token.mint == sol_mint {
                token.token_available = 10_000_000_000; // 10 SOL at $100 = $1000
            }
            if token.mint == usdc_mint || token.mint == sol_mint {
                token.weight = 1;
                token.max_deviation_bps = dev_bps;
            }
        }

        (vault, vault_scope_prices, usdc_mint, sol_mint)
    }

    #[test]
    fn test_deposit_bound_disabled_when_deviation_zero() {
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(0, 0);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_deposit_bound_disabled_when_upper_above_one() {
        // Single token vault — target ratio = 1, so upper = 1 + dev > 1 → unbounded.
        let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);
        let mint = vault.vault_tokens[0].mint;
        vault.vault_tokens[0].weight = 1;
        vault.vault_tokens[0].max_deviation_bps = 500;

        let id = vault_token_id(&mut vault, mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_deposit_bound_disabled_when_upper_is_exactly_one() {
        // target = 0.5, dev = 0.5 => upper = 1 exactly. This must remain an unbounded deposit
        // path rather than panicking inside `Ratio::reverse()`.
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(5_000, 5_000);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_deposit_bound_clamps_at_exact_boundary() {
        // target=0.5, dev=10% → upper=0.6. v_k = V_other = $1000 in lamports; V = $2000.
        // a_max_usd = (0.6*2000 - 1000)/(1-0.6) = 200/0.4 = 500 → 500_000_000 lamports.
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(1000, 1000);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::new(500_000_000));
    }

    #[test]
    fn test_deposit_bound_clamps_with_mixed_prices_and_decimals() {
        // Same $1000/$1000 AUM setup as the exact-bound test, but SOL is $100 with 9 decimals.
        // target=0.5, dev=10% allows $500 of extra SOL => 5 SOL => 5_000_000_000 lamports.
        let (mut vault, prices, _, sol_mint) = mixed_price_setup(1000);
        let id = vault_token_id(&mut vault, sol_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::new(5_000_000_000));
    }

    #[test]
    fn test_deposit_bound_returns_zero_when_already_above_upper() {
        // Skew USDC's balance so it exceeds upper bound.
        let (mut vault, prices, usdc_mint, usdt_mint) = two_token_equal_setup(500, 500);
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint {
                token.token_available = 10_000_000_000; // 10x more
            } else if token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
        }
        // USDC weight now >= 10/11 ≈ 0.909, way above upper=0.55.
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::ZERO);
    }

    #[test]
    fn test_withdraw_bound_disabled_when_deviation_zero() {
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(0, 0);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_withdraw_bound_disabled_when_lower_at_or_below_zero() {
        // target = 0.5, dev = 60% → lower = -0.1 < 0 → unbounded.
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(6_000, 6_000);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_withdraw_bound_disabled_when_lower_is_exactly_zero() {
        // target = 0.5, dev = 0.5 => lower = 0 exactly, so withdraws remain unbounded.
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(5_000, 5_000);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_withdraw_bound_clamps_at_exact_boundary() {
        // target=0.5, dev=10% → lower=0.4. v_k = $1000, V = $2000.
        // a_max_usd = (1000 - 0.4*2000)/(1-0.4) = 200/0.6 = 333.33... → 333_333_333 lamports (floor).
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(1000, 1000);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::new(333_333_333));
    }

    #[test]
    fn test_withdraw_bound_clamps_with_mixed_prices_and_decimals() {
        // target=0.5, dev=10% allows $333.33... of SOL out.
        // At $100/SOL this is 3.333333333 SOL => 3_333_333_333 lamports.
        let (mut vault, prices, _, sol_mint) = mixed_price_setup(1000);
        let id = vault_token_id(&mut vault, sol_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::new(3_333_333_333));
    }

    #[test]
    fn test_withdraw_bound_returns_zero_when_already_below_lower() {
        let (mut vault, prices, usdc_mint, usdt_mint) = two_token_equal_setup(500, 500);
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint {
                token.token_available = 100_000_000; // 10x less
            } else if token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
        }
        // USDC weight ≈ 0.091, well below lower = 0.45.
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::ZERO);
    }

    #[test]
    fn test_deposit_underweight_token_has_room_when_sibling_above_upper() {
        // USDC=10e9, USDT=1e9, total=11e9, weights 1:1, dev=5% (500 bps). target_USDT=0.5,
        // upper=0.55. max_usdt_aum = (upper*total - token_aum)/(1-upper)
        //   = (0.55*11e9 - 1e9) / 0.45 = 5.05e9 / 0.45 = 11_222_222_222.22... → floor = 11_222_222_222.
        let (mut vault, prices, usdc_mint, usdt_mint) = two_token_equal_setup(500, 500);
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint {
                token.token_available = 10_000_000_000;
            } else if token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
        }

        let id = vault_token_id(&mut vault, usdt_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::new(11_222_222_222));
    }

    #[test]
    fn test_withdraw_overweight_token_has_room_when_above_upper() {
        // USDC=10e9, USDT=1e9, total=11e9, weights 1:1, dev=5% (500 bps). target_USDC=0.5,
        // lower=0.45. max_usdc_aum = (token_aum - lower*total)/(1-lower)
        //   = (10e9 - 0.45*11e9) / 0.55 = 5.05e9 / 0.55 = 9_181_818_181.81... → floor = 9_181_818_181.
        let (mut vault, prices, usdc_mint, usdt_mint) = two_token_equal_setup(500, 500);
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint {
                token.token_available = 10_000_000_000;
            } else if token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
        }

        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::new(9_181_818_181));
    }

    #[test]
    fn test_weights_zero_sum_is_refused_as_unconfigured() {
        // With no weights anywhere there is no target to bound against, and a vault in that
        // state is one nobody has shaped yet rather than one whose bound is switched off.
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(500, 500);
        for token in vault.vault_tokens.iter_mut() {
            token.weight = 0;
        }
        let id = vault_token_id(&mut vault, usdc_mint);
        for bound in [
            compute_max_deposit_by_target_bound(&vault, &prices, id),
            compute_max_withdraw_by_target_bound(&vault, &prices, id),
        ] {
            assert_eq!(
                bound.unwrap_err(),
                Error::from(KaminoVaultError::InvalidWeightsSum)
            );
        }
    }

    mod deposit_withdraw_integration {
        use super::*;
        use crate::{
            operations::{
                effects::{DepositEffects, WithdrawEffects},
                tests::tests_utils::fixtures::setup_vault_with_tokens_and_config,
                vault_operations,
            },
            types::{NetAum, ShareAmount, Timestamp},
            KaminoVaultError,
        };
        use anchor_lang::err;

        fn setup_two_token_vault_with_global(
            dev_bps: u64,
        ) -> (
            crate::MetavaultState,
            crate::GlobalConfig,
            crate::utils::scope::VaultScopePrices,
            solana_program::pubkey::Pubkey,
            solana_program::pubkey::Pubkey,
        ) {
            let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
            let usdt = TokenConfig::with_price_and_decimals(1.0, 6);
            let usdc_mint = usdc.mint;
            let usdt_mint = usdt.mint;
            let tokens = HashMap::from_iter([("USDC", usdc), ("USDT", usdt)]);
            let (mut vault, global_config, prices) =
                setup_vault_with_tokens_and_config(&tokens, 0, 0);

            // Fund both tokens with equal AUM so targets are initially met.
            for token in vault.vault_tokens.iter_mut() {
                if token.mint == usdc_mint || token.mint == usdt_mint {
                    token.token_available = 1_000_000_000;
                }
                token.weight = 1;
                if token.mint == usdc_mint || token.mint == usdt_mint {
                    token.max_deviation_bps = dev_bps;
                }
            }
            (vault, global_config, prices, usdc_mint, usdt_mint)
        }

        #[test]
        fn test_deposit_clamps_to_upper_bound() {
            let (mut vault, config, prices, usdc_mint, _) = setup_two_token_vault_with_global(1000);

            // Bound allows ~500_000_000 lamports; request 10x that.
            let DepositEffects {
                token_to_deposit, ..
            } = vault_operations::deposit(
                &mut vault,
                &prices,
                NetAum::ZERO,
                &config,
                usdc_mint,
                TokenAmount::new(5_000_000_000),
                Timestamp::ZERO,
            )
            .unwrap();
            assert_eq!(token_to_deposit, TokenAmount::new(500_000_000));
        }

        #[test]
        fn test_deposit_passes_through_when_bound_disabled() {
            let (mut vault, config, prices, usdc_mint, _) = setup_two_token_vault_with_global(0);

            let DepositEffects {
                token_to_deposit, ..
            } = vault_operations::deposit(
                &mut vault,
                &prices,
                NetAum::ZERO,
                &config,
                usdc_mint,
                TokenAmount::new(5_000_000_000),
                Timestamp::ZERO,
            )
            .unwrap();
            assert_eq!(token_to_deposit, TokenAmount::new(5_000_000_000));
        }

        #[test]
        fn test_deposit_errors_when_token_already_above_upper_bound() {
            let (mut vault, config, prices, usdc_mint, usdt_mint) =
                setup_two_token_vault_with_global(500); // 5% deviation → upper = 0.55
            for token in vault.vault_tokens.iter_mut() {
                if token.mint == usdc_mint {
                    token.token_available = 10_000_000_000;
                } else if token.mint == usdt_mint {
                    token.token_available = 1_000_000_000;
                }
            }

            let result = vault_operations::deposit(
                &mut vault,
                &prices,
                NetAum::ZERO,
                &config,
                usdc_mint,
                TokenAmount::new(1_000_000),
                Timestamp::ZERO,
            );
            assert_eq!(result, err!(KaminoVaultError::TargetBoundExceeded));
        }

        #[test]
        fn test_withdraw_clamps_to_lower_bound() {
            let (mut vault, config, prices, usdc_mint, _) = setup_two_token_vault_with_global(1000);

            // Request a withdrawal of all shares — should clamp to the ~333M-lamport lower bound.
            let total_shares = vault.shares_issued_amount();
            let WithdrawEffects {
                available_to_send_to_user,
                ..
            } = vault_operations::withdraw(
                &mut vault,
                &prices,
                NetAum::ZERO,
                &config,
                usdc_mint,
                Timestamp::ZERO,
                total_shares,
            )
            .unwrap();
            assert_eq!(available_to_send_to_user, TokenAmount::new(333_333_333));
        }

        #[test]
        fn test_withdraw_errors_when_token_already_below_lower_bound() {
            let (mut vault, config, prices, usdc_mint, usdt_mint) =
                setup_two_token_vault_with_global(500);
            for token in vault.vault_tokens.iter_mut() {
                if token.mint == usdc_mint {
                    token.token_available = 100_000_000;
                } else if token.mint == usdt_mint {
                    token.token_available = 1_000_000_000;
                }
            }

            let result = vault_operations::withdraw(
                &mut vault,
                &prices,
                NetAum::ZERO,
                &config,
                usdc_mint,
                Timestamp::ZERO,
                ShareAmount::new(1),
            );
            assert_eq!(result, err!(KaminoVaultError::TargetBoundExceeded));
        }

        #[test]
        fn test_withdraw_passes_through_when_bound_disabled() {
            let (mut vault, config, prices, usdc_mint, _) = setup_two_token_vault_with_global(0);
            // Vault has INITIAL_DEPOSIT_SIZE (=1000) shares backed by $2000 of USDC+USDT. A
            // withdraw of 500 shares entitles the user to $1000 worth of USDC ⇒ 1_000_000_000
            // lamports (6 decimals, $1/token), with no fee and no bound clamp.
            let WithdrawEffects {
                available_to_send_to_user,
                ..
            } = vault_operations::withdraw(
                &mut vault,
                &prices,
                NetAum::ZERO,
                &config,
                usdc_mint,
                Timestamp::ZERO,
                ShareAmount::new(500),
            )
            .unwrap();
            assert_eq!(available_to_send_to_user, TokenAmount::new(1_000_000_000));
        }
    }

    #[test]
    fn test_deposit_bound_three_token_asymmetric_weights_prices_decimals() {
        // Weights [1, 3, 4] (total=8) ⇒ targets 1/8, 3/8, 4/8.
        // BTC ($50k, 8 dec), SOL ($100, 9 dec), USDC ($1, 6 dec) with initial balances at target
        // and total AUM=$800: BTC=$100, SOL=$300, USDC=$400.
        //
        // Deviations picked so upper is a clean fraction of the total:
        //   BTC dev=3750 bps (3/8)  → upper=1/2
        //   SOL dev=1250 bps (1/8)  → upper=1/2
        //   USDC dev=2500 bps (1/4) → upper=3/4
        //
        // max_aum = (upper * total - token_aum) / (1 - upper)
        //   BTC:  (0.5 * 800 - 100) / 0.5  = $600 ⇒ 0.012 BTC = 1_200_000 lamports (8 dec)
        //   SOL:  (0.5 * 800 - 300) / 0.5  = $200 ⇒ 2 SOL    = 2_000_000_000 lamports (9 dec)
        //   USDC: (0.75 * 800 - 400) / 0.25 = $800 ⇒ 800 USDC = 800_000_000 lamports (6 dec)
        let btc = TokenConfig::with_price_and_decimals(50_000.0, 8);
        let sol = TokenConfig::with_price_and_decimals(100.0, 9);
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let (btc_mint, sol_mint, usdc_mint) = (btc.mint, sol.mint, usdc.mint);
        let tokens = HashMap::from_iter([("BTC", btc), ("SOL", sol), ("USDC", usdc)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == btc_mint {
                token.token_available = 200_000; // 0.002 BTC = $100
                token.weight = 1;
                token.max_deviation_bps = 3750;
            } else if token.mint == sol_mint {
                token.token_available = 3_000_000_000; // 3 SOL = $300
                token.weight = 3;
                token.max_deviation_bps = 1250;
            } else if token.mint == usdc_mint {
                token.token_available = 400_000_000; // $400
                token.weight = 4;
                token.max_deviation_bps = 2500;
            }
        }

        let btc_id = vault_token_id(&mut vault, btc_mint);
        let sol_id = vault_token_id(&mut vault, sol_mint);
        let usdc_id = vault_token_id(&mut vault, usdc_mint);
        assert_eq!(
            compute_max_deposit_by_target_bound(&vault, &prices, btc_id).unwrap(),
            TokenAmount::new(1_200_000),
        );
        assert_eq!(
            compute_max_deposit_by_target_bound(&vault, &prices, sol_id).unwrap(),
            TokenAmount::new(2_000_000_000),
        );
        assert_eq!(
            compute_max_deposit_by_target_bound(&vault, &prices, usdc_id).unwrap(),
            TokenAmount::new(800_000_000),
        );
    }

    #[test]
    fn test_withdraw_bound_three_token_asymmetric_weights_prices_decimals() {
        // Weights [1, 2, 5] (total=8) ⇒ targets 1/8, 2/8, 5/8.
        // BTC, SOL, USDC with balances at target and total AUM=$800.
        //   BTC=$100, SOL=$200, USDC=$500.
        //
        // Token 2 (USDC, target=5/8): dev=2500 (1/4) → lower=3/8.
        //   max_aum_w = (500 - (3/8)*800) / (1 - 3/8) = 200 / (5/8) = $320 ⇒ 320_000_000 lamports.
        let btc = TokenConfig::with_price_and_decimals(50_000.0, 8);
        let sol = TokenConfig::with_price_and_decimals(100.0, 9);
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let (btc_mint, sol_mint, usdc_mint) = (btc.mint, sol.mint, usdc.mint);
        let tokens = HashMap::from_iter([("BTC", btc), ("SOL", sol), ("USDC", usdc)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == btc_mint {
                token.token_available = 200_000; // $100
                token.weight = 1;
                token.max_deviation_bps = 625; // target=1/8, lower=1/16, but we don't assert here
            } else if token.mint == sol_mint {
                token.token_available = 2_000_000_000; // $200
                token.weight = 2;
                token.max_deviation_bps = 625;
            } else if token.mint == usdc_mint {
                token.token_available = 500_000_000; // $500
                token.weight = 5;
                token.max_deviation_bps = 2500;
            }
        }

        let usdc_id = vault_token_id(&mut vault, usdc_mint);
        assert_eq!(
            compute_max_withdraw_by_target_bound(&vault, &prices, usdc_id).unwrap(),
            TokenAmount::new(320_000_000),
        );
    }

    #[test]
    fn test_deposit_bound_seeds_new_token_when_token_aum_is_zero() {
        // Existing 2-token vault where one token has zero balance; bound must allow a first
        // deposit equal to upper / (1 - upper) * total_aum (tokens ⇒ applied at token price).
        // Weights [1, 1], target=0.5 on USDC. USDC token_aum=0, USDT has $1000 AUM. dev=2500 bps:
        //   upper = 0.5 + 0.25 = 0.75
        //   max_aum = (0.75 * 1000 - 0) / 0.25 = $3000 ⇒ 3_000_000_000 lamports (6 dec, $1).
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdt = TokenConfig::with_price_and_decimals(1.0, 6);
        let (usdc_mint, usdt_mint) = (usdc.mint, usdt.mint);
        let tokens = HashMap::from_iter([("USDC", usdc), ("USDT", usdt)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint {
                token.token_available = 0; // empty
                token.weight = 1;
                token.max_deviation_bps = 2500;
            } else if token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
                token.weight = 1;
                token.max_deviation_bps = 2500;
            }
        }

        let id = vault_token_id(&mut vault, usdc_mint);
        assert_eq!(
            compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap(),
            TokenAmount::new(3_000_000_000),
        );
    }

    #[test]
    fn test_deposit_bound_at_near_unity_deviation() {
        // dev=9999 bps → target + dev is a proper fraction just below 1.
        // Token A weight=1, Token B weight=1, A at $1000 (at target), B at $1000.
        // target_A = 0.5, dev = 0.9999, upper = 1.4999 > 1 → bound disabled (TokenAmount::MAX).
        //
        // With unequal weights: A weight=9, B weight=1 ⇒ target_A = 0.9, dev=999 (0.0999),
        // upper = 0.9999 < 1.
        //   max_aum = (0.9999 * 2000 - 1000) / 0.0001 = $999.8 / 0.0001 = $9_998_000
        //   Expected tokens = 9_998_000 USDC = 9_998_000_000_000 lamports, minus a single lamport
        //   lost to the 64.64 fixed-point representation of (1 - 0.9999) = 0.0001, which is not
        //   exactly representable in binary (the `reverse(upper)` term amplifies this quantization).
        let a = TokenConfig::with_price_and_decimals(1.0, 6);
        let b = TokenConfig::with_price_and_decimals(1.0, 6);
        let (a_mint, b_mint) = (a.mint, b.mint);
        let tokens = HashMap::from_iter([("TKA", a), ("TKB", b)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == a_mint {
                token.token_available = 1_000_000_000; // $1000
                token.weight = 9;
                token.max_deviation_bps = 999; // upper = 0.9 + 0.0999 = 0.9999
            } else if token.mint == b_mint {
                token.token_available = 1_000_000_000;
                token.weight = 1;
                token.max_deviation_bps = 0;
            }
        }

        let id = vault_token_id(&mut vault, a_mint);
        assert_eq!(
            compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap(),
            TokenAmount::new(9_997_999_999_999),
        );
    }

    #[test]
    fn test_token_with_weight_zero_allows_no_deposit_when_already_at_deviation_cap() {
        // USDC weight=0 (target=0), dev=5% → upper=0.05. v_k = $1000, V = $2000.
        // USDC current weight = 0.5 >> 0.05 → above upper, return 0.
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdt = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdc_mint = usdc.mint;
        let usdt_mint = usdt.mint;
        let tokens = HashMap::from_iter([("USDC", usdc), ("USDT", usdt)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint || token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
            if token.mint == usdc_mint {
                token.weight = u64::from(Weight::from(0));
                token.max_deviation_bps = 500;
            } else if token.mint == usdt_mint {
                token.weight = u64::from(Weight::from(1));
                token.max_deviation_bps = 500;
            }
        }
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::ZERO);
    }

    #[test]
    fn test_withdraw_bound_disabled_when_weight_zero_with_nonzero_deviation() {
        // USDC weight=0, dev=5% → target=0, lower = max(0, target - dev) collapses to 0.
        // Production returns `TokenAmount::MAX` when `target <= deviation`, meaning the lower bound
        // is non-positive and imposes no constraint on withdraws regardless of current balance.
        let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdt = TokenConfig::with_price_and_decimals(1.0, 6);
        let usdc_mint = usdc.mint;
        let usdt_mint = usdt.mint;
        let tokens = HashMap::from_iter([("USDC", usdc), ("USDT", usdt)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);
        for token in vault.vault_tokens.iter_mut() {
            if token.mint == usdc_mint || token.mint == usdt_mint {
                token.token_available = 1_000_000_000;
            }
            if token.mint == usdc_mint {
                token.weight = u64::from(Weight::from(0));
                token.max_deviation_bps = 500;
            } else if token.mint == usdt_mint {
                token.weight = u64::from(Weight::from(1));
                token.max_deviation_bps = 500;
            }
        }
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_withdraw_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_deposit_bound_saturates_when_bound_exceeds_u64() {
        // Cheap (1 cent) 9-decimal token, target 80%, deviation 10% => upper = 0.9, so the
        // allowance is amplified 10x. Free AUM is $21M held in USDC and the cheap token's
        // balance is 0, giving (0.9 * 21M) / (1 - 0.9) = $189M => 1.89e19 lamports, just past
        // u64::MAX. The bound must saturate rather than panic in the dollar->token conversion,
        // otherwise every deposit of this token reverts however small.
        let mut cheap = TokenConfig::with_price_and_decimals(0.01, 9);
        cheap.weight = 8;
        let mut usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        usdc.weight = 2;
        usdc.available = 21_000_000_000_000;
        let cheap_mint = cheap.mint;
        let usdc_mint = usdc.mint;
        let tokens = HashMap::from_iter([("AAA_CHEAP", cheap), ("USDC", usdc)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == cheap_mint {
                token.token_available = 0;
                token.weight = 8;
                token.max_deviation_bps = 1_000;
            } else if token.mint == usdc_mint {
                token.token_available = 21_000_000_000_000;
                token.weight = 2;
                token.max_deviation_bps = 1_000;
            }
        }

        let id = vault_token_id(&mut vault, cheap_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_deposit_bound_saturates_when_bound_exceeds_the_fraction_range() {
        // Same shape as the test above, but priced so the bound lands past `Fraction::MAX`
        // (2^68 ~ 2.95e20) rather than merely past `u64::MAX` (1.84e19). At $0.0006 a 9-decimal
        // token converts at 1.67e12 lamports/$, so the $189M bound is ~3.15e20 lamports.
        //
        // The two overflows are in *different* places: the `u64` one is the final narrowing,
        // this one is the intermediate `Fraction` product, which aborts inside klend. Saturating
        // only the former leaves a ~16x band that works and everything above it bricking every
        // deposit of the token, at any size.
        let mut cheap = TokenConfig::with_price_and_decimals(0.0006, 9);
        cheap.weight = 8;
        let mut usdc = TokenConfig::with_price_and_decimals(1.0, 6);
        usdc.weight = 2;
        usdc.available = 21_000_000_000_000;
        let cheap_mint = cheap.mint;
        let usdc_mint = usdc.mint;
        let tokens = HashMap::from_iter([("AAA_CHEAP", cheap), ("USDC", usdc)]);
        let (mut vault, prices) = setup_vault_with_tokens(&tokens);

        for token in vault.vault_tokens.iter_mut() {
            if token.mint == cheap_mint {
                token.token_available = 0;
                token.weight = 8;
                token.max_deviation_bps = 1_000;
            } else if token.mint == usdc_mint {
                token.token_available = 21_000_000_000_000;
                token.weight = 2;
                token.max_deviation_bps = 1_000;
            }
        }

        let id = vault_token_id(&mut vault, cheap_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }

    #[test]
    fn test_deposit_bound_disabled_when_upper_strictly_above_one() {
        // Near-miss for `upper_ratio >= Ratio::one()` guard at vault_operations.rs:456:
        // target=0.5, dev=50.01% → upper = 1.0001 > 1 → unbounded deposit path.
        let (mut vault, prices, usdc_mint, _) = two_token_equal_setup(5_001, 5_001);
        let id = vault_token_id(&mut vault, usdc_mint);
        let result = compute_max_deposit_by_target_bound(&vault, &prices, id).unwrap();
        assert_eq!(result, TokenAmount::MAX);
    }
}

//! Unit tests for the [`rolling_cap`] tumbling-window primitive and the [`RollingCap`]
//! admin-config helper.
//!
//! Cap-bit values used here are raw `DollarValue::from_bits` payloads (`u128`). The semantic
//! "USD" interpretation does not matter for the algorithm; what matters is the boundary, the
//! tumble, and the overflow guard. Small integers keep the tests easy to read.

use anchor_lang::err;
use borsh::BorshSerialize;

use crate::{
    operations::rolling_cap,
    types::{DollarValue, Timestamp},
    utils::consts::MAX_ROLLING_CAP_INTERVAL_SECONDS,
    KaminoVaultError, RollingCap,
};

fn cap(max_bits: u128, accumulated_bits: u128, interval: u64, last_start: u64) -> RollingCap {
    RollingCap {
        max_usd_sf: max_bits,
        accumulated_usd_sf: accumulated_bits,
        interval_seconds: interval,
        last_interval_start_timestamp: last_start,
    }
}

// ── tumble_window_if_needed ───────────────────────────────────────────

#[test]
fn test_tumble_resets_at_interval_boundary() {
    // elapsed == interval triggers the reset (`>=` is the inclusive boundary).
    let mut c = cap(1000, 500, 100, 0);
    rolling_cap::tumble_window_if_needed(&mut c, Timestamp::new(100)).unwrap();
    assert_eq!(c.accumulated_usd_sf, 0);
    assert_eq!(c.last_interval_start_timestamp, 100);
}

#[test]
fn test_tumble_no_op_before_interval() {
    let mut c = cap(1000, 500, 100, 0);
    rolling_cap::tumble_window_if_needed(&mut c, Timestamp::new(99)).unwrap();
    assert_eq!(c.accumulated_usd_sf, 500);
    assert_eq!(c.last_interval_start_timestamp, 0);
}

#[test]
fn test_tumble_disabled_is_noop() {
    // interval == 0 means disabled — even a far-future timestamp must not touch state.
    let mut c = cap(0, 999, 0, 42);
    rolling_cap::tumble_window_if_needed(&mut c, Timestamp::new(1_000_000)).unwrap();
    assert_eq!(c.accumulated_usd_sf, 999);
    assert_eq!(c.last_interval_start_timestamp, 42);
}

// ── accumulate_deposit / accumulate_withdraw ──────────────────────────

#[test]
fn test_accumulate_equality_passes() {
    // accumulated + flow == max must succeed (strict `>` boundary).
    let mut c = cap(1000, 0, 100, 0);
    rolling_cap::accumulate_deposit(&mut c, DollarValue::from_bits(1000), Timestamp::new(50))
        .unwrap();
    assert_eq!(c.accumulated_usd_sf, 1000);
}

#[test]
fn test_accumulate_one_above_max_fails_deposit() {
    let mut c = cap(1000, 0, 100, 0);
    let res =
        rolling_cap::accumulate_deposit(&mut c, DollarValue::from_bits(1001), Timestamp::new(50));
    assert_eq!(res, err!(KaminoVaultError::RollingDepositCapExceeded));
}

#[test]
fn test_accumulate_one_above_max_fails_withdraw() {
    // The withdraw-direction wrapper maps to the withdraw-specific error variant.
    let mut c = cap(1000, 500, 100, 0);
    let res =
        rolling_cap::accumulate_withdraw(&mut c, DollarValue::from_bits(501), Timestamp::new(50));
    assert_eq!(res, err!(KaminoVaultError::RollingWithdrawCapExceeded));
}

#[test]
fn test_accumulate_leaves_state_unchanged_on_rejection() {
    let mut c = cap(1000, 800, 100, 25);
    let _ =
        rolling_cap::accumulate_deposit(&mut c, DollarValue::from_bits(500), Timestamp::new(50))
            .unwrap_err();
    // Tumble did not fire (elapsed=25 < 100), so accumulator stays at 800 and anchor stays at 25.
    assert_eq!(c.accumulated_usd_sf, 800);
    assert_eq!(c.last_interval_start_timestamp, 25);
}

#[test]
fn test_accumulate_disabled_is_noop() {
    // interval == 0: even max == 0 and a giant flow must succeed without state changes.
    let mut c = cap(0, 0, 0, 0);
    rolling_cap::accumulate_deposit(
        &mut c,
        DollarValue::from_bits(u128::MAX / 2),
        Timestamp::new(0),
    )
    .unwrap();
    assert_eq!(c.accumulated_usd_sf, 0);
    assert_eq!(c.last_interval_start_timestamp, 0);
}

#[test]
fn test_accumulate_tumbles_then_succeeds() {
    // A saturated window must reopen when time crosses the interval boundary.
    let mut c = cap(1000, 1000, 100, 0);
    rolling_cap::accumulate_deposit(&mut c, DollarValue::from_bits(800), Timestamp::new(101))
        .unwrap();
    // Tumbled at t=101: accumulated reset, anchor moved, then 800 added.
    assert_eq!(c.accumulated_usd_sf, 800);
    assert_eq!(c.last_interval_start_timestamp, 101);
}

// ── apply_config_bytes (admin update) ────────────────────────────────

#[test]
fn test_apply_config_preserves_accumulator_and_anchor() {
    // Klend-style preservation: admin updates max + interval; in-flight accumulator stays.
    let mut c = cap(1000, 700, 100, 50);
    let mut payload = Vec::with_capacity(24);
    payload.extend_from_slice(&2000u128.to_le_bytes());
    payload.extend_from_slice(&200u64.to_le_bytes());

    // t=120 is still inside the old 100s window anchored at 50, so nothing tumbles.
    c.apply_config_bytes(&payload, "deposit", Timestamp::new(120))
        .unwrap();

    assert_eq!(c.max_usd_sf, 2000);
    assert_eq!(c.interval_seconds, 200);
    assert_eq!(c.accumulated_usd_sf, 700); // preserved
    assert_eq!(c.last_interval_start_timestamp, 50); // preserved
}

#[test]
fn test_apply_config_settles_expired_window_under_old_interval() {
    // The 100s window anchored at 50 expired at 150 but never tumbled (no flow since).
    // Stretching the interval to 7 days must not revive it: settle under the old interval
    // first, so the exhausted accumulator is cleared instead of blocking flow until t=604_850.
    let mut c = cap(1000, 1000, 100, 50);
    let mut payload = Vec::with_capacity(24);
    payload.extend_from_slice(&1000u128.to_le_bytes());
    payload.extend_from_slice(&604_800u64.to_le_bytes());

    c.apply_config_bytes(&payload, "deposit", Timestamp::new(200))
        .unwrap();

    assert_eq!(c.interval_seconds, 604_800);
    assert_eq!(c.accumulated_usd_sf, 0);
    assert_eq!(c.last_interval_start_timestamp, 200);
}

#[test]
fn test_apply_config_rejects_interval_above_max() {
    let mut c = RollingCap::default();
    let mut payload = Vec::with_capacity(24);
    payload.extend_from_slice(&1u128.to_le_bytes());
    payload.extend_from_slice(&(u64::from(MAX_ROLLING_CAP_INTERVAL_SECONDS) + 1).to_le_bytes());

    let res = c.apply_config_bytes(&payload, "deposit", Timestamp::new(1));
    assert_eq!(res, err!(KaminoVaultError::RollingCapIntervalTooLong));
}

#[test]
fn test_apply_config_rejects_short_payload() {
    let mut c = RollingCap::default();
    let res = c.apply_config_bytes(&1u128.to_le_bytes(), "deposit", Timestamp::new(1));
    assert_eq!(res, err!(KaminoVaultError::ConfigValueTooShort));
}

#[test]
fn test_apply_config_max_interval_accepted() {
    let mut c = RollingCap::default();
    let mut payload = Vec::with_capacity(24);
    payload.extend_from_slice(&1u128.to_le_bytes());
    payload.extend_from_slice(&u64::from(MAX_ROLLING_CAP_INTERVAL_SECONDS).to_le_bytes());

    c.apply_config_bytes(&payload, "deposit", Timestamp::new(1))
        .unwrap();
    assert_eq!(
        c.interval_seconds,
        u64::from(MAX_ROLLING_CAP_INTERVAL_SECONDS)
    );
}

#[test]
fn test_default_rolling_cap_is_disabled() {
    let c = RollingCap::default();
    assert!(c.is_disabled());
    assert_eq!(c.max_usd_sf, 0);
    assert_eq!(c.accumulated_usd_sf, 0);
}

// ── Borsh round-trip sanity ───────────────────────────────────────────

#[test]
fn test_borsh_roundtrip_serialization_shape() {
    // Confirms the 24-byte payload shape expected by `apply_config_bytes`. If this breaks, the
    // test client and on-chain dispatch will both need to adjust.
    let max: u128 = 1_234_567;
    let interval: u64 = 4242;
    let bytes = max
        .try_to_vec()
        .into_iter()
        .chain(interval.try_to_vec())
        .flatten()
        .collect::<Vec<_>>();
    assert_eq!(bytes.len(), 24);
}

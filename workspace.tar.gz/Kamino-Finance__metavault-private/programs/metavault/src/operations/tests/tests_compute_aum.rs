use crate::types::RoundingMethod;
use std::collections::HashMap;

use kamino_lending::assert_fuzzy_eq_f;
use kamino_lending::fraction::Fraction;

use super::tests_utils::fixtures::setup_vault_with_tokens;
use crate::{
    operations::tests::tests_utils::{TokenConfig, EPSILON_F},
    VaultToken,
};

#[test]
fn test_compute_aum_single_token() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].token_available = 1_000_000; // 1.0 tokens

    let aum = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    assert_eq!(aum, Fraction::ONE);
}

#[test]
fn test_compute_aum_two_tokens() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].token_available = 1_000_000_000; // 1.0 tokens
    vault.vault_tokens[1].token_available = 1_000_000; // 1.0 tokens

    let aum = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    assert_fuzzy_eq_f!(aum, Fraction::from_num(101.0), EPSILON_F);
}

#[test]
fn test_compute_aum_two_tokens_sparse() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].token_available = 1_000_000_000; // 1.0 tokens
    vault.vault_tokens[2].token_available = 1_000_000; // 1.0 tokens
                                                       // Copy USDC to 2nd index and remove it from 1st to make a sparse array
    vault.vault_tokens[2].decimals = vault.vault_tokens[1].decimals;
    vault.vault_tokens[2].mint = vault.vault_tokens[1].mint;
    vault.vault_tokens[1] = VaultToken::default();

    // Should work as if it was a dense vec
    let aum = Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    assert_fuzzy_eq_f!(aum, Fraction::from_num(101.0), EPSILON_F);
}

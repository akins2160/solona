use crate::types::NetAum;
use std::collections::HashMap;

use anchor_lang::err;
use kamino_lending::fraction::Fraction;

use crate::{
    operations::{
        tests::tests_utils::fixtures::setup_vault_with_tokens_and_config, vault_operations,
    },
    types::{DollarValue, RoundingMethod, ShareAmount, Timestamp, TokenAmount},
    KaminoVaultError, VaultConfigField,
};

use super::tests_utils::TokenConfig;

// T2: DepositAmountBelowMinimum
#[test]
fn test_deposit_below_min_deposit_amount() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let vault_token = vault
        .vault_tokens
        .iter_mut()
        .find(|t| t.mint == tokens["USDC"].mint)
        .unwrap();
    vault_token.min_deposit_amount = 1000;

    let result = vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(500),
        Timestamp::ZERO,
    );

    assert_eq!(result, err!(KaminoVaultError::DepositAmountBelowMinimum));
}

// T3: WithdrawAmountBelowMinimum
#[test]
fn test_withdraw_below_min_withdraw_amount() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Deposit enough to have meaningful shares
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(10_000),
        Timestamp::ZERO,
    )
    .unwrap();

    // Set min_withdraw_amount high enough that a small withdrawal fails
    let vault_token = vault
        .vault_tokens
        .iter_mut()
        .find(|t| t.mint == tokens["USDC"].mint)
        .unwrap();
    vault_token.min_withdraw_amount = 500;

    // Withdraw 100 shares -> yields ~100 lamports which is < 500 min
    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(100),
    );

    assert_eq!(result, err!(KaminoVaultError::WithdrawAmountBelowMinimum));
}

// T4: DepositAmountsZero -- deposit results in zero shares
#[test]
fn test_deposit_results_in_zero_shares() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Make a large deposit to inflate AUM
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(100_000_000),
        Timestamp::ZERO,
    )
    .unwrap();

    // Deposit 1 lamport — rounds to 0 shares
    let result = vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(1),
        Timestamp::ZERO,
    );

    assert_eq!(result, err!(KaminoVaultError::DepositAmountsZero));
}

// T5: WithdrawResultsInZeroShares — withdraw from a token with zero available
// when vault AUM comes from another token
#[test]
fn test_withdraw_results_in_zero_shares() {
    let tokens = HashMap::from_iter([
        ("AAA", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["AAA"].mint,
        TokenAmount::new(10_000_000),
        Timestamp::ZERO,
    )
    .unwrap();

    // Withdraw from USDC: user has shares entitling them to AUM (total_for_user > 0)
    // but USDC token_available = 0, so available_to_send_to_user = 0 and shares_to_burn = 0
    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(1000),
    );

    assert_eq!(
        result,
        err!(KaminoVaultError::WithdrawAmountLessThanWithdrawalFee)
    );
}

// T6: VaultSharesZero
#[test]
fn test_withdraw_with_zero_shares_issued() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Deposit to establish AUM and token_available
    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(10_000),
        Timestamp::ZERO,
    )
    .unwrap();

    vault.shares_issued = 0;

    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(100),
    );

    assert_eq!(result, err!(KaminoVaultError::VaultSharesZero));
}

// T7: VaultAUMZero
#[test]
fn test_withdraw_with_zero_aum() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let vault_token = vault
        .vault_tokens
        .iter_mut()
        .find(|t| t.mint == tokens["USDC"].mint)
        .unwrap();
    vault_token.token_available = 0;

    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(100),
    );

    assert_eq!(result, err!(KaminoVaultError::VaultAUMZero));
}

// T9: CannotWithdrawZeroShares
#[test]
fn test_cannot_withdraw_zero_shares() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(0),
    );

    assert_eq!(result, err!(KaminoVaultError::CannotWithdrawZeroShares));
}

// T10: WithdrawSharesExceedIssued
#[test]
fn test_withdraw_shares_exceed_issued() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(10_000),
        Timestamp::ZERO,
    )
    .unwrap();

    let shares_issued = vault.shares_issued;
    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(shares_issued + 1),
    );

    assert_eq!(result, err!(KaminoVaultError::WithdrawSharesExceedIssued));
}

#[test]
fn test_deposit_halts_when_net_aum_is_negative() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(10_000),
        Timestamp::ZERO,
    )
    .unwrap();

    let net_negative = NetAum {
        abs_value: vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil)
            + DollarValue::from(Fraction::from(1u64)),
        negative: true,
    };

    let result = vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        net_negative,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::new(10_000),
        Timestamp::ZERO,
    );

    assert_eq!(result, err!(KaminoVaultError::VaultAUMZero));
}

#[test]
fn test_withdraw_halts_when_net_aum_is_negative() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    vault_operations::deposit(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &global_config,
        tokens["USDC"].mint,
        TokenAmount::from(10_000),
        Timestamp::from(0),
    )
    .unwrap();

    let net_negative = NetAum {
        abs_value: vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil)
            + DollarValue::from(Fraction::from(1u64)),
        negative: true,
    };

    let result = vault_operations::withdraw(
        &mut vault,
        &vault_scope_prices,
        net_negative,
        &global_config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        ShareAmount::new(100),
    );

    assert_eq!(result, err!(KaminoVaultError::VaultAUMZero));
}

#[test]
fn test_max_price_ages_are_bounded() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, _, _) = setup_vault_with_tokens_and_config(&tokens, 0, 0);
    let mint = tokens["USDC"].mint;
    for field in [
        VaultConfigField::VaultTokenMaxAgePriceSeconds,
        VaultConfigField::VaultTokenMaxAgeTwapSeconds,
    ] {
        for (seconds, accepted) in [(0u64, false), (1, true), (86_400, true), (86_401, false)] {
            let mut value = mint.to_bytes().to_vec();
            value.extend_from_slice(&seconds.to_le_bytes());
            let result = vault.update_config(field, &value, Timestamp::ZERO);
            if accepted {
                result.unwrap();
            } else {
                assert_eq!(result, err!(KaminoVaultError::MaxPriceAgeOutOfRange));
            }
        }
    }
}

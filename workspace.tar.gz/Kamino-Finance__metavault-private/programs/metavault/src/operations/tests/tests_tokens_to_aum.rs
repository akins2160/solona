use kamino_lending::fraction::Fraction;

use crate::{
    operations::tests::tests_utils::EPSILON_F,
    types::{RoundingMethod, TokenAmount, TokenPrice},
};

fn tokens_to_aum(tokens: u64, price: Fraction, decimals: u8) -> Fraction {
    let token_price = TokenPrice::new(price, decimals);
    Fraction::from(TokenAmount::from(tokens).to_aum(&token_price, RoundingMethod::Floor))
}

#[test]
fn test_tokens_to_aum_standard_scenarios() {
    struct TestCase {
        tokens: u64,
        token_price: f64,
        token_decimals: u8,
        expected_aum: f64,
    }

    let test_cases = vec![
        // Standard 6-decimal token scenarios
        TestCase {
            tokens: 1_000_000, // 1 token
            token_price: 1.0,  // $1.00
            token_decimals: 6,
            expected_aum: 1.0, // $1.00 AUM
        },
        TestCase {
            tokens: 2_500_000, // 2.5 tokens
            token_price: 3.0,  // $3.00
            token_decimals: 6,
            expected_aum: 7.5, // $7.50 AUM
        },
        TestCase {
            tokens: 100_000_000, // 100 tokens
            token_price: 0.50,   // $0.50
            token_decimals: 6,
            expected_aum: 50.0, // $50.00 AUM
        },
        TestCase {
            tokens: 500_000,     // 0.5 tokens
            token_price: 2000.0, // $2000 (expensive token)
            token_decimals: 6,
            expected_aum: 1000.0, // $1000 AUM
        },
        // Different decimal scenarios
        TestCase {
            tokens: 100,      // 1 token (2 decimals)
            token_price: 5.0, // $5.00
            token_decimals: 2,
            expected_aum: 5.0, // $5.00 AUM
        },
        TestCase {
            tokens: 1_000_000_000, // 1 token (9 decimals)
            token_price: 10.0,     // $10.00
            token_decimals: 9,
            expected_aum: 10.0, // $10.00 AUM
        },
        TestCase {
            tokens: 1_000_000_000_000, // 1 token (12 decimals)
            token_price: 0.001,        // $0.001
            token_decimals: 12,
            expected_aum: 0.001, // $0.001 AUM
        },
    ];

    for test in test_cases {
        let result = tokens_to_aum(
            test.tokens,
            Fraction::from_num(test.token_price),
            test.token_decimals,
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert_eq!(result, expected);
    }
}

#[test]
fn test_tokens_to_aum_edge_cases() {
    // Zero tokens
    let result = tokens_to_aum(0, Fraction::from_num(100.0), 6);
    assert_eq!(result, Fraction::ZERO);

    // Zero price
    let result = tokens_to_aum(1_000_000, Fraction::ZERO, 6);
    assert_eq!(result, Fraction::ZERO);

    // Very large token amount
    let result = tokens_to_aum(
        u64::MAX,
        Fraction::from_num(0.000001), // Very small price to avoid overflow
        6,
    );
    assert!(result > Fraction::ZERO);

    // Maximum precision token (12 decimals)
    let result = tokens_to_aum(
        1,                          // 1 smallest unit
        Fraction::from_num(3000.0), // High precision price
        12,
    );
    let expected = Fraction::from_num(3000.0) / Fraction::from_num(1e12);
    assert_eq!(result, expected);
}

#[test]
fn test_tokens_to_aum_precision_scenarios() {
    struct TestCase {
        tokens: u64,
        token_price: f64,
        token_decimals: u8,
        expected_aum: f64,
    }

    let test_cases = vec![
        // Fractional token amounts with precise calculations
        TestCase {
            tokens: 333_333,  // 0.333333 tokens
            token_price: 3.0, // $3.00
            token_decimals: 6,
            expected_aum: 0.999999, // $0.999999 AUM
        },
        TestCase {
            tokens: 1,              // 0.000001 tokens (smallest 6-decimal unit)
            token_price: 1000000.0, // $1M price
            token_decimals: 6,
            expected_aum: 1.0, // $1.00 AUM
        },
        TestCase {
            tokens: 777_777_777, // 777.777777 tokens
            token_price: 1.001,  // $1.001
            token_decimals: 6,
            expected_aum: 778.555554777, // Precise calculation
        },
        // Very small amounts
        TestCase {
            tokens: 1,         // Smallest unit
            token_price: 0.01, // 1 cent
            token_decimals: 6,
            expected_aum: 0.00000001, // Tiny AUM
        },
        // High precision calculations
        TestCase {
            tokens: 123_456_789_012_345, // Large amount (12 decimals)
            token_price: 2.5,            // $2.50
            token_decimals: 12,
            expected_aum: 308.641_972_530_864_2, // 123.456789... * 2.5
        },
    ];

    for test in test_cases {
        let result = tokens_to_aum(
            test.tokens,
            Fraction::from_num(test.token_price),
            test.token_decimals,
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert!(result.abs_diff(expected) < EPSILON_F);
    }
}

#[test]
fn test_tokens_to_aum_different_token_types() {
    struct TestCase {
        tokens: u64,
        token_price: f64,
        token_decimals: u8,
        expected_aum: f64,
    }

    let test_cases = vec![
        // Stablecoin-like (6 decimals, $1)
        TestCase {
            tokens: 50_000_000, // 50 USDC
            token_price: 1.0,   // $1.00
            token_decimals: 6,
            expected_aum: 50.0, // $50.00
        },
        // Bitcoin-like (8 decimals)
        TestCase {
            tokens: 100_000_000,  // 1 BTC
            token_price: 45000.0, // $45,000
            token_decimals: 8,
            expected_aum: 45000.0, // $45,000
        },
        // High precision token (12 decimals)
        TestCase {
            tokens: 2_000_000_000_000, // 2 tokens
            token_price: 2500.0,       // $2,500
            token_decimals: 12,
            expected_aum: 5000.0, // $5,000
        },
        // Low precision token (2 decimals)
        TestCase {
            tokens: 12_345,     // 123.45 tokens
            token_price: 0.789, // $0.789
            token_decimals: 2,
            expected_aum: 97.40205, // 123.45 * 0.789
        },
        // Very cheap token (many tokens needed)
        TestCase {
            tokens: 1_000_000_000_000, // 1M tokens
            token_price: 0.000001,     // $0.000001
            token_decimals: 6,
            expected_aum: 1.0, // $1.00 total
        },
    ];

    for test in test_cases {
        let result = tokens_to_aum(
            test.tokens,
            Fraction::from_num(test.token_price),
            test.token_decimals,
        );

        let expected = Fraction::from_num(test.expected_aum);
        assert!(result.abs_diff(expected) < EPSILON_F);
    }
}

#[test]
fn test_tokens_to_aum_mathematical_properties() {
    // Test linearity: 2x tokens = 2x AUM
    let base_result = tokens_to_aum(1_000_000, Fraction::from_num(5.0), 6);
    let double_result = tokens_to_aum(2_000_000, Fraction::from_num(5.0), 6);
    assert_eq!(double_result, base_result * Fraction::from_num(2));

    // Test price scaling: 2x price = 2x AUM
    let base_price_result = tokens_to_aum(1_000_000, Fraction::from_num(10.0), 6);
    let double_price_result = tokens_to_aum(1_000_000, Fraction::from_num(20.0), 6);
    assert_eq!(
        double_price_result,
        base_price_result * Fraction::from_num(2)
    );

    // Test decimal independence: same economic value across decimals
    let result_6_decimals = tokens_to_aum(100_000_000, Fraction::from_num(2.0), 6); // 100 tokens
    let result_8_decimals = tokens_to_aum(10_000_000_000, Fraction::from_num(2.0), 8); // 100 tokens
    let result_12_decimals = tokens_to_aum(100_000_000_000_000, Fraction::from_num(2.0), 12); // 100 tokens

    assert_eq!(result_6_decimals, result_8_decimals);
    assert_eq!(result_6_decimals, result_12_decimals);
    assert_eq!(result_6_decimals, Fraction::from_num(200.0)); // 100 * $2 = $200
}

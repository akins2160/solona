use std::collections::HashMap;

use anchor_lang::Id;
use anchor_spl::token::Token;
use kamino_lending::fraction::Fraction;
use kamino_lending::{fraction, ScopeConfiguration};
use solana_program::pubkey::Pubkey;

use crate::{
    operations::{
        effects::{DepositEffects, WithdrawEffects},
        rebalance_basket::RebalanceBasket,
        vault_operations,
    },
    types::{BasketToken, Timestamp, VaultTokenId},
    MetavaultState,
};

pub const EPSILON_F: Fraction = fraction!(0.000000001); // 1e-9
pub const EPSILON: f64 = 0.000000001; // 1e-9

pub fn make_vault_with_tokens<'a>(
    tokens: &'a HashMap<&'a str, TokenConfig>,
) -> (MetavaultState, Vec<(&'a str, &'a TokenConfig)>) {
    let mut vault = MetavaultState {
        vault_admin_authority: Pubkey::new_unique(),
        base_vault_authority: Pubkey::new_unique(),
        shares_mint: Pubkey::new_unique(),
        base_vault_authority_bump: 255,
        ..MetavaultState::default()
    };
    // Sort tokens by name to ensure deterministic order
    let mut sorted_tokens: Vec<(&str, &TokenConfig)> = tokens
        .iter()
        .map(|(&name, config)| (name, config))
        .collect();
    sorted_tokens.sort_by_key(|(name, _)| *name);

    let first_token = sorted_tokens[0];
    init_vault(&mut vault, first_token.1);

    // Add remaining tokens in sorted order
    for (token_name, token_config) in sorted_tokens.iter().skip(1) {
        if *token_name != first_token.0 {
            vault
                .add_vault_token_if_not_present(
                    token_config.mint,
                    Pubkey::new_unique(),
                    Token::id(),
                    token_config.decimals,
                    ScopeConfiguration::default(),
                    Timestamp::ZERO,
                )
                .unwrap();
            let vault_token = vault
                .get_vault_token_mut_by_mint(&token_config.mint)
                .unwrap();
            vault_token.token_available = token_config.available;
            vault_token.min_withdraw_amount = token_config.min_withdraw;
            vault_token.weight = token_config.weight;
        }
    }
    (vault, sorted_tokens)
}

pub fn init_vault(vault: &mut MetavaultState, token_config: &TokenConfig) {
    vault_operations::initialize(
        vault,
        vault.vault_admin_authority,
        vault.base_vault_authority,
        vault.shares_mint,
        vault.base_vault_authority_bump,
        token_config.decimals,
        Timestamp::ZERO,
    )
    .unwrap();
    vault
        .add_vault_token_if_not_present(
            token_config.mint,
            Pubkey::new_unique(),
            Token::id(),
            token_config.decimals,
            ScopeConfiguration::default(),
            Timestamp::ZERO,
        )
        .unwrap();
    vault.vault_tokens[0].token_available = token_config.available;
    vault.vault_tokens[0].min_withdraw_amount = token_config.min_withdraw;
    vault.vault_tokens[0].weight = token_config.weight;
    vault.vault_tokens[0].weight = token_config.weight;
}

#[derive(Debug, Clone)]
pub struct UserState {
    pub tokens: HashMap<String, u64>,
    pub shares: u64,
}

impl UserState {
    pub fn new(token_name: &str, tokens: u64) -> UserState {
        UserState {
            tokens: HashMap::from_iter([(token_name.to_string(), tokens)]),
            shares: 0,
        }
    }

    pub fn consume_deposit(&mut self, token_name: &str, effect: DepositEffects) {
        if !self.tokens.contains_key(token_name) {
            panic!(
                "Trying to deposit token {} which user doesn't have any",
                token_name
            );
        }

        *self.tokens.get_mut(token_name).unwrap() -= u64::from(effect.token_to_deposit);
        self.shares += u64::from(effect.shares_to_mint);
    }

    pub fn consume_withdraw(&mut self, token_name: &str, effect: WithdrawEffects) {
        if !self.tokens.contains_key(token_name) {
            self.tokens.insert(token_name.to_string(), 0);
        }

        *self.tokens.get_mut(token_name).unwrap() += u64::from(effect.available_to_send_to_user);
        self.shares -= u64::from(effect.shares_to_burn);
    }

    pub fn consume_charge_fees(&mut self, fees: u64) {
        self.shares += fees;
    }
}
#[derive(Debug, Clone)]
pub struct TokenConfig {
    pub mint: Pubkey,
    pub decimals: u8,
    pub price: f64,
    pub available: u64,
    pub min_withdraw: u64,
    pub weight: u64,
}

impl Default for TokenConfig {
    fn default() -> Self {
        TokenConfig {
            mint: Pubkey::new_unique(),
            decimals: 6,
            price: 0.0,
            available: 0,
            min_withdraw: 0,
            weight: 1,
        }
    }
}

impl TokenConfig {
    pub fn with_price(price: f64) -> TokenConfig {
        TokenConfig {
            price,
            ..Default::default()
        }
    }

    pub fn with_price_and_decimals(price: f64, decimals: u8) -> TokenConfig {
        TokenConfig {
            price,
            decimals,
            ..Default::default()
        }
    }

    pub fn with_weight_price_available_decimals(
        weight: u64,
        price: f64,
        available: u64,
        decimals: u8,
    ) -> TokenConfig {
        TokenConfig {
            weight,
            price,
            available,
            decimals,
            ..Default::default()
        }
    }
}

pub mod fixtures {

    use std::collections::HashMap;

    use kamino_lending::fraction::Fraction;

    use super::*;
    use crate::{
        operations::vault_operations,
        types::{Timestamp, TokenPrice},
        utils::scope::VaultScopePrices,
        GlobalConfig, MetavaultState,
    };

    pub fn setup_vault_with_tokens(
        tokens: &HashMap<&str, TokenConfig>,
    ) -> (MetavaultState, VaultScopePrices) {
        let (mut vault, sorted_tokens) = make_vault_with_tokens(tokens);
        let mut vault_scope_prices = VaultScopePrices::default();
        for (_, token) in &sorted_tokens {
            vault_scope_prices.prices.push(TokenPrice::new(
                Fraction::from_num(token.price),
                token.decimals,
            ));
        }

        // Seed deposit to establish initial shares (mirrors on-chain handler_init_vault)
        let first_mint = sorted_tokens[0].1.mint;
        vault_operations::perform_initial_deposit(
            &mut vault,
            &vault_scope_prices,
            first_mint,
            Timestamp::ZERO,
        )
        .unwrap();

        (vault, vault_scope_prices)
    }

    pub fn setup_vault_with_tokens_and_config(
        tokens: &HashMap<&str, TokenConfig>,
        withdrawal_fee_lamports: u64,
        withdrawal_fee_bps: u64,
    ) -> (MetavaultState, GlobalConfig, VaultScopePrices) {
        let (vault, vault_scope_prices) = setup_vault_with_tokens(tokens);
        let config = GlobalConfig {
            withdrawal_fee_lamports,
            withdrawal_fee_bps,
            ..Default::default()
        };

        (vault, config, vault_scope_prices)
    }
}

// The basket's token of the given id (which always exists, as ids only come from the basket).
pub fn token_by_id(basket: &impl RebalanceBasket, id: VaultTokenId) -> BasketToken {
    basket
        .tokens()
        .into_iter()
        .find(|token| token.id == id)
        .expect("a VaultTokenId always names a token the basket holds")
}

#[test]
fn test_init_vault() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (vault, vault_scope_prices) = fixtures::setup_vault_with_tokens(&tokens);

    assert_eq!(vault.shares_mint_decimals, 6);
    assert!(vault.vault_tokens[0].mint != Pubkey::default());
    assert_eq!(vault.vault_tokens[0].decimals, 6);
    assert_eq!(vault.vault_tokens[0].token_program, Token::id());
    assert_eq!(
        vault_scope_prices.prices[0].price(),
        Fraction::from_num(1.0)
    );
    assert_eq!(vault_scope_prices.prices[0].decimals(), 6);
}

#[test]
fn test_init_vault_sorted() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("AUSDC", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (vault, vault_scope_prices) = fixtures::setup_vault_with_tokens(&tokens);

    assert_eq!(vault.vault_tokens[0].decimals, 9);
    assert_eq!(
        vault_scope_prices.prices[0].price(),
        Fraction::from_num(100.0)
    );
    assert_eq!(vault.vault_tokens[1].decimals, 6);
    assert_eq!(
        vault_scope_prices.prices[1].price(),
        Fraction::from_num(1.0)
    );
}

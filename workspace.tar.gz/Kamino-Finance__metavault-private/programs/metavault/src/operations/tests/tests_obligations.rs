use std::collections::HashMap;

use anchor_lang::prelude::Pubkey;
use kamino_lending::{
    fraction::Fraction, utils::FractionExtra, LendingMarket, Obligation, ObligationCollateral,
    ObligationLiquidity, Reserve,
};

use crate::{
    operations::{
        effects::WithdrawObligationCollateralEffects,
        obligation_operations::{
            borrow_obligation_liquidity, compute_withdraw_obligation_collateral_effects,
            deposit_obligation_collateral, repay_obligation_liquidity,
            withdraw_obligation_collateral,
        },
        tests::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig},
        vault_checks::{
            check_borrow_ltv_ceiling, check_obligation_ltv_ceiling, check_reserve_price_basis,
            check_withdraw_ltv_ceiling, find_enabled_token_and_price,
            post_withdraw_obligation_collateral_checks, WithdrawObligationCollateralBalances,
        },
    },
    state::VaultObligation,
    types::{
        amounts::AllAvailableOr, DollarValue, NetAum, Ratio, RebalanceLimits, RebalanceState,
        RoundingMethod, Timestamp, TokenAmount,
    },
    utils::{consts::MAX_OBLIGATIONS_PER_VAULT, scope::VaultScopePrices},
    KaminoVaultError, MetavaultState, VaultConfigField,
};

fn assert_obligation_operation_blocked<T>(result: anchor_lang::Result<T>) {
    assert_eq!(
        result.err().unwrap(),
        anchor_lang::error::Error::from(KaminoVaultError::ObligationOperationDuringRebalance)
    );
}

#[test]
fn active_rebalance_blocks_all_obligation_inventory_operations() {
    // A rebalance that is still fillable at these prices: 5 SOL ($500) against 1500 USDC at
    // equal weights, inside its window. The gate ends a rebalance that is over before it
    // checks, so the one being tested must have something left to fill.
    let tokens = HashMap::from([
        (
            "SOL",
            TokenConfig::with_weight_price_available_decimals(5000, 100.0, 5_000_000_000, 9),
        ),
        (
            "USDC",
            TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_500_000_000, 6),
        ),
    ]);
    let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
    // A running rebalance with some loss recorded: obligation operations bypass the auction, so
    // they are refused outright and leave it untouched.
    let rebalance = RebalanceState {
        start_timestamp: 1_000_000,
        end_timestamp: 1_003_600,
        limits: RebalanceLimits {
            max_fill_slippage_bps: 100,
            max_loss_bps: 100,
        },
        lost_usd_sf: DollarValue::from(Fraction::from(5_u64)).to_bits(),
        ceiling_at_start_usd_sf: DollarValue::from(Fraction::from(20_u64)).to_bits(),
    };
    vault.rebalance = rebalance;

    let reserve = Reserve::default();
    let lending_market = LendingMarket::default();
    let obligation = Obligation::default();
    let liquidity_mint = Pubkey::new_unique();
    let reserve_address = Pubkey::new_unique();
    let amount = TokenAmount::from(1);
    let slot = 0;
    let timestamp = Timestamp::from(1_000_100);

    assert_obligation_operation_blocked(deposit_obligation_collateral(
        &mut vault,
        &scope_prices,
        NetAum::ZERO,
        &reserve,
        &liquidity_mint,
        amount,
        slot,
        timestamp,
    ));
    assert_obligation_operation_blocked(withdraw_obligation_collateral(
        &mut vault,
        &scope_prices,
        NetAum::ZERO,
        &reserve,
        &lending_market,
        &obligation,
        &reserve_address,
        &liquidity_mint,
        AllAvailableOr::Exactly(amount),
        slot,
        timestamp,
    ));
    assert_obligation_operation_blocked(borrow_obligation_liquidity(
        &mut vault,
        &scope_prices,
        NetAum::ZERO,
        &reserve,
        &lending_market,
        &obligation,
        &liquidity_mint,
        amount,
        slot,
        timestamp,
    ));
    assert_obligation_operation_blocked(repay_obligation_liquidity(
        &mut vault,
        &scope_prices,
        NetAum::ZERO,
        &reserve,
        &obligation,
        &reserve_address,
        &liquidity_mint,
        amount,
        slot,
        timestamp,
    ));

    assert!(vault.rebalance.is_unfinished());
    assert_eq!(vault.rebalance, rebalance);
}

#[test]
fn is_set_recognises_empty_vs_populated_slot() {
    let empty = VaultObligation::default();
    assert!(!empty.is_set());

    let populated = VaultObligation {
        obligation: obligation_address(1),
        ..Default::default()
    };
    assert!(populated.is_set());
}

#[test]
fn add_obligation_fills_first_empty_slot() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    let b = obligation_address(2);

    let id_a = vault.add_obligation_if_not_present(a).unwrap();
    assert_eq!(id_a.storage_index, 0);
    assert_eq!(vault.obligations[0].obligation, a);

    let id_b = vault.add_obligation_if_not_present(b).unwrap();
    assert_eq!(id_b.storage_index, 1);
    assert_eq!(vault.obligations[1].obligation, b);

    assert_eq!(vault.get_obligations_count(), 2);
}

#[test]
fn add_obligation_rejects_duplicate() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    vault.add_obligation_if_not_present(a).unwrap();

    let err = vault.add_obligation_if_not_present(a).unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationAlreadyExists)
    );
}

#[test]
fn add_obligation_rejects_when_exhausted() {
    let mut vault = MetavaultState::default();
    for i in 0..MAX_OBLIGATIONS_PER_VAULT {
        vault
            .add_obligation_if_not_present(obligation_address(i as u8))
            .unwrap();
    }
    let err = vault
        .add_obligation_if_not_present(obligation_address(255))
        .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationsSpaceExhausted)
    );
}

#[test]
fn get_obligation_id_by_address_returns_slot_not_found_when_missing() {
    let vault = MetavaultState::default();
    let err = vault
        .get_obligation_id_by_address(&obligation_address(1))
        .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationSlotNotFound)
    );
}

#[test]
fn get_obligation_id_by_address_returns_storage_index_across_sparse_array() {
    let mut vault = MetavaultState::default();
    // Slots 0 and 2 populated, slot 1 empty (sparse array, as if after a removal).
    let a = obligation_address(1);
    let c = obligation_address(3);
    vault.obligations[0] = VaultObligation {
        obligation: a,
        ..Default::default()
    };
    vault.obligations[2] = VaultObligation {
        obligation: c,
        ..Default::default()
    };

    assert_eq!(
        vault
            .get_obligation_id_by_address(&a)
            .unwrap()
            .storage_index,
        0
    );
    assert_eq!(
        vault
            .get_obligation_id_by_address(&c)
            .unwrap()
            .storage_index,
        2
    );
}

#[test]
fn iter_enabled_obligations_skips_empty_slots() {
    let mut vault = MetavaultState::default();
    vault.obligations[0] = VaultObligation {
        obligation: obligation_address(1),
        ..Default::default()
    };
    vault.obligations[2] = VaultObligation {
        obligation: obligation_address(3),
        ..Default::default()
    };
    let keys: Vec<Pubkey> = vault
        .iter_enabled_obligations()
        .map(|o| o.obligation)
        .collect();
    assert_eq!(keys, vec![obligation_address(1), obligation_address(3)]);
}

#[test]
fn compute_net_aum_equals_compute_free_aum_when_no_obligations() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].token_available = 1_000_000; // $1.0

    let obligations = NetAum::ZERO;
    let free = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);
    let net = vault.compute_net_aum(&vault_scope_prices, obligations, RoundingMethod::Floor);

    assert_eq!(NetAum::from(free), net);
}

#[test]
fn empty_obligations_aum_has_zero_net_value() {
    let obligations = NetAum::ZERO;
    assert_eq!(obligations.abs_value, DollarValue::ZERO);
    assert!(!obligations.negative);
}

#[test]
fn remove_obligation_clears_slot() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    let id = vault.add_obligation_if_not_present(a).unwrap();
    assert_eq!(vault.get_obligations_count(), 1);

    vault.remove_obligation(id).unwrap();
    assert_eq!(vault.get_obligations_count(), 0);
    assert!(!vault.obligations[id.storage_index].is_set());
}

#[test]
fn remove_then_add_reuses_storage_index() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    let b = obligation_address(2);

    let id_a = vault.add_obligation_if_not_present(a).unwrap();
    vault.remove_obligation(id_a).unwrap();

    let id_b = vault.add_obligation_if_not_present(b).unwrap();
    assert_eq!(
        id_b.storage_index, id_a.storage_index,
        "the freed slot should be the first one chosen by add_obligation_if_not_present"
    );
    assert_eq!(vault.obligations[id_b.storage_index].obligation, b);
}

#[test]
fn remove_obligation_rejects_unset_slot() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    let id = vault.add_obligation_if_not_present(a).unwrap();
    vault.remove_obligation(id).unwrap();

    let err = vault.remove_obligation(id).unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationSlotNotFound)
    );
}

#[test]
fn compute_max_redeemable_ctoken_amount_zero_collateral_value_is_blocked() {
    // Obligation total `deposited_value_sf` is non-zero (passes the obligation-total guard) but
    // the specific collateral entry has zero market value. `AllAvailable` + one active borrow
    // force the path through `compute_max_redeemable_ctoken_amount`.
    let withdraw_reserve_pk = obligation_address(7);
    let some_borrow_reserve_pk = obligation_address(8);

    let mut obligation = Obligation::default();
    obligation.deposits[0] = ObligationCollateral {
        deposit_reserve: withdraw_reserve_pk,
        deposited_amount: 100,
        market_value_sf: 0,
        ..Default::default()
    };
    obligation.borrows[0] = ObligationLiquidity {
        borrow_reserve: some_borrow_reserve_pk,
        ..Default::default()
    };
    obligation.deposited_value_sf = 1u128 << 60;

    let reserve = Reserve::default();
    let lending_market = LendingMarket::default();

    let err = compute_withdraw_obligation_collateral_effects(
        &reserve,
        &lending_market,
        &obligation,
        &withdraw_reserve_pk,
        AllAvailableOr::AllAvailable,
    )
    .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::MaximumWithdrawValueZero)
    );
}

/// The all-available prediction replicates klend's sizing bit-exactly: the withdraw ratio is
/// truncated to `Fraction` precision *before* multiplying by the deposited amount. A
/// full-precision ratio application would predict one more ctoken here (floor(10 * 1/5) = 2)
/// than klend actually burns — which used to require a reconciliation path.
#[test]
fn all_available_prediction_matches_klend_truncated_ratio_sizing() {
    let deposited_amount = 10u64;
    let withdraw_value = Fraction::from(1u64);
    let collateral_value = Fraction::from(5u64);

    // Klend first truncates 1/5 to U68F60, then multiplies by 10, which floors to 1 — one
    // fewer than the full-precision floor(10 * 1 / 5) = 2.
    let klend_withdraw_ratio = withdraw_value / collateral_value;
    let klend_amount: u64 = (klend_withdraw_ratio * u128::from(deposited_amount)).to_floor();
    assert_eq!(klend_amount, 1);

    let withdraw_reserve_pk = obligation_address(9);
    let borrow_reserve_pk = obligation_address(10);
    // 100% max LTV, so max_withdraw_value = allowed_borrow_value - bf debt = $1 exactly.
    let mut reserve = reserve_with_unit_price(100, 100);
    reserve.config.loan_to_value_pct = 100;
    let lending_market = LendingMarket::default();

    let mut obligation = Obligation::default();
    obligation.deposits[0] = ObligationCollateral {
        deposit_reserve: withdraw_reserve_pk,
        deposited_amount,
        market_value_sf: collateral_value.to_bits(),
        ..Default::default()
    };
    obligation.borrows[0] = ObligationLiquidity {
        borrow_reserve: borrow_reserve_pk,
        borrowed_amount_sf: Fraction::from(1u64).to_bits(),
        ..Default::default()
    };
    obligation.deposited_value_sf = collateral_value.to_bits();
    obligation.allowed_borrow_value_sf = withdraw_value.to_bits();

    let effects = compute_withdraw_obligation_collateral_effects(
        &reserve,
        &lending_market,
        &obligation,
        &withdraw_reserve_pk,
        AllAvailableOr::AllAvailable,
    )
    .unwrap();
    assert_eq!(effects.ctokens_to_redeem, TokenAmount::from(klend_amount));
}

fn obligation_address(n: u8) -> Pubkey {
    let mut bytes = [0u8; 32];
    bytes[0] = 0xDE;
    bytes[1] = 0xAD;
    bytes[31] = n;
    Pubkey::new_from_array(bytes)
}

#[test]
fn ltv_ceiling_config_sets_field_for_matching_obligation_only() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    let b = obligation_address(2);
    vault.add_obligation_if_not_present(a).unwrap();
    vault.add_obligation_if_not_present(b).unwrap();

    let mut value = a.to_bytes().to_vec();
    value.extend_from_slice(&8_000u64.to_le_bytes());
    vault
        .update_config(
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps,
            &value,
            Timestamp::ZERO,
        )
        .unwrap();

    assert_eq!(vault.obligations[0].max_unhealthy_ltv_fraction_bps, 8_000);
    assert_eq!(vault.obligations[1].max_unhealthy_ltv_fraction_bps, 0);
}

#[test]
fn ltv_ceiling_config_rejects_unknown_obligation() {
    let mut vault = MetavaultState::default();
    vault
        .add_obligation_if_not_present(obligation_address(1))
        .unwrap();

    let mut value = obligation_address(9).to_bytes().to_vec();
    value.extend_from_slice(&1_000u64.to_le_bytes());
    let err = vault
        .update_config(
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps,
            &value,
            Timestamp::ZERO,
        )
        .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationSlotNotFound)
    );
}

#[test]
fn ltv_ceiling_config_rejects_value_above_full_bps() {
    let mut vault = MetavaultState::default();
    let a = obligation_address(1);
    vault.add_obligation_if_not_present(a).unwrap();

    let mut value = a.to_bytes().to_vec();
    value.extend_from_slice(&10_001u64.to_le_bytes());
    let err = vault
        .update_config(
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps,
            &value,
            Timestamp::ZERO,
        )
        .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::BPSValueTooBig)
    );
}

#[test]
fn ltv_ceiling_config_rejects_short_value() {
    let mut vault = MetavaultState::default();
    let err = vault
        .update_config(
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps,
            &[0u8; 31],
            Timestamp::ZERO,
        )
        .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ConfigValueTooShort)
    );
}

#[test]
fn ltv_ceiling_zero_disables_check() {
    check_obligation_ltv_ceiling(
        Ratio::from_bps(0),
        DollarValue::from_bits(Fraction::MAX.to_bits()),
        DollarValue::ZERO,
    )
    .unwrap();
}

#[test]
fn ltv_ceiling_allows_boundary_and_blocks_above() {
    // $1000 of liquidation-threshold value
    let unhealthy = DollarValue::from_bits(Fraction::from(1_000u64).to_bits());
    // 80% ceiling -> $800 allowance.
    let max_unhealthy_ltv_fraction = Ratio::from_bps(8_000);
    check_obligation_ltv_ceiling(
        max_unhealthy_ltv_fraction,
        DollarValue::from_bits(Fraction::from(800u64).to_bits()),
        unhealthy,
    )
    .unwrap();
    let err = check_obligation_ltv_ceiling(
        max_unhealthy_ltv_fraction,
        DollarValue::from_bits(Fraction::from(801u64).to_bits()),
        unhealthy,
    )
    .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationLtvCeilingExceeded)
    );
}

/// Reserve fixture with unit price and 0 decimals so `liquidity_amount_to_market_value` is the
/// identity, making expected values readable.
fn reserve_with_unit_price(liquidation_threshold_pct: u8, borrow_factor_pct: u64) -> Reserve {
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_decimals = 0;
    reserve.liquidity.market_price_sf = Fraction::ONE.to_bits();
    reserve.config.liquidation_threshold_pct = liquidation_threshold_pct;
    reserve.config.borrow_factor_pct = borrow_factor_pct;
    reserve
}

fn obligation_with_ltv_ceiling(bps: u64) -> VaultObligation {
    VaultObligation {
        max_unhealthy_ltv_fraction_bps: bps,
        ..Default::default()
    }
}

#[test]
fn borrow_ltv_ceiling_adds_borrow_factor_adjusted_new_debt() {
    let reserve = reserve_with_unit_price(80, 100); // neutral borrow factor
    let obligation = Obligation {
        unhealthy_borrow_value_sf: Fraction::from(800u64).to_bits(),
        borrow_factor_adjusted_debt_value_sf: Fraction::from(500u64).to_bits(),
        ..Obligation::default()
    };
    let vault_obligation = obligation_with_ltv_ceiling(8_000);

    // 80% ceiling -> $640 allowance. $140 new debt -> exactly $640: allowed.
    check_borrow_ltv_ceiling(
        &vault_obligation,
        &reserve,
        &obligation,
        TokenAmount::from(140).into(),
    )
    .unwrap();
    // $141 -> $641: blocked.
    let err = check_borrow_ltv_ceiling(
        &vault_obligation,
        &reserve,
        &obligation,
        TokenAmount::from(141).into(),
    )
    .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationLtvCeilingExceeded)
    );
}

#[test]
fn borrow_ltv_ceiling_applies_reserve_borrow_factor() {
    let reserve = reserve_with_unit_price(80, 200); // 2x borrow factor
    let obligation = Obligation {
        unhealthy_borrow_value_sf: Fraction::from(800u64).to_bits(),
        borrow_factor_adjusted_debt_value_sf: Fraction::from(500u64).to_bits(),
        ..Obligation::default()
    };
    let vault_obligation = obligation_with_ltv_ceiling(8_000);

    // $70 new debt x 2.0 borrow factor -> bf debt $640: allowed; $71 -> $642: blocked.
    check_borrow_ltv_ceiling(
        &vault_obligation,
        &reserve,
        &obligation,
        TokenAmount::from(70).into(),
    )
    .unwrap();
    check_borrow_ltv_ceiling(
        &vault_obligation,
        &reserve,
        &obligation,
        TokenAmount::from(71).into(),
    )
    .unwrap_err();
}

#[test]
fn withdraw_ltv_ceiling_subtracts_removed_threshold_value() {
    let reserve = reserve_with_unit_price(80, 100);
    let lending_market = LendingMarket::default();
    // Unhealthy value $800 (e.g. $1000 deposits at 80% threshold); bf debt $500.
    let obligation = Obligation {
        unhealthy_borrow_value_sf: Fraction::from(800u64).to_bits(),
        borrow_factor_adjusted_debt_value_sf: Fraction::from(500u64).to_bits(),
        ..Obligation::default()
    };
    let vault_obligation = obligation_with_ltv_ceiling(9_000);

    // 90% ceiling. Withdraw $300 -> unhealthy $800 - $240 = $560 -> allowance $504 >= $500: OK.
    check_withdraw_ltv_ceiling(
        &vault_obligation,
        &reserve,
        &lending_market,
        &obligation,
        TokenAmount::from(300).into(),
    )
    .unwrap();
    // Withdraw $310 -> unhealthy $552 -> allowance $496.8 < $500: blocked.
    let err = check_withdraw_ltv_ceiling(
        &vault_obligation,
        &reserve,
        &lending_market,
        &obligation,
        TokenAmount::from(310).into(),
    )
    .unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ObligationLtvCeilingExceeded)
    );
}

fn withdraw_balances(
    vault_token_balance: u64,
    reserve_liquidity_supply: u64,
    reserve_source_collateral: u64,
) -> WithdrawObligationCollateralBalances {
    WithdrawObligationCollateralBalances {
        vault_token_balance: TokenAmount::from(vault_token_balance),
        reserve_liquidity_supply: TokenAmount::from(reserve_liquidity_supply),
        reserve_source_collateral: TokenAmount::from(reserve_source_collateral),
    }
}

fn predicted_withdraw_effects() -> WithdrawObligationCollateralEffects {
    WithdrawObligationCollateralEffects {
        ctokens_to_redeem: TokenAmount::from(40),
        liquidity_to_receive: TokenAmount::from(50),
    }
}

fn assert_balance_mismatch(result: anchor_lang::Result<()>) {
    assert_eq!(
        result.unwrap_err(),
        anchor_lang::error::Error::from(KaminoVaultError::BalanceAfterObligationCpiMismatch)
    );
}

#[test]
fn post_withdraw_checks_accept_exactly_predicted_movements() {
    let pre = withdraw_balances(1_000, 500, 100);
    // Vault +50, reserve -50, collateral escrow -40: exactly the prediction.
    let post = withdraw_balances(1_050, 450, 60);
    post_withdraw_obligation_collateral_checks(&pre, &post, &predicted_withdraw_effects()).unwrap();
}

#[test]
fn post_withdraw_checks_reject_vault_reserve_flow_mismatch() {
    let pre = withdraw_balances(1_000, 500, 100);
    // The reserve released 50 but the vault only gained 49.
    let post = withdraw_balances(1_049, 450, 60);
    assert_balance_mismatch(post_withdraw_obligation_collateral_checks(
        &pre,
        &post,
        &predicted_withdraw_effects(),
    ));
}

#[test]
fn post_withdraw_checks_reject_unexpected_collateral_burn() {
    let pre = withdraw_balances(1_000, 500, 100);
    // One fewer ctoken burned than predicted — the old all-available allowance, now rejected.
    let post = withdraw_balances(1_050, 450, 61);
    assert_balance_mismatch(post_withdraw_obligation_collateral_checks(
        &pre,
        &post,
        &predicted_withdraw_effects(),
    ));
}

#[test]
fn post_withdraw_checks_reject_unexpected_liquidity_amount() {
    let pre = withdraw_balances(1_000, 500, 100);
    // Internally consistent flows (vault gained exactly what the reserve released) that are
    // nevertheless one lamport short of the prediction.
    let post = withdraw_balances(1_049, 451, 60);
    assert_balance_mismatch(post_withdraw_obligation_collateral_checks(
        &pre,
        &post,
        &predicted_withdraw_effects(),
    ));
}

#[test]
fn price_basis_accepts_bit_equal_price() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;
    let (vault_token, token_price) =
        find_enabled_token_and_price(&vault, &vault_scope_prices, &mint).unwrap();
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.market_price_sf = token_price.price().to_bits();
    check_reserve_price_basis(vault_token, token_price, &reserve).unwrap();
}

#[test]
fn price_basis_rejects_one_ulp_divergence_in_both_directions() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;
    let (vault_token, token_price) =
        find_enabled_token_and_price(&vault, &vault_scope_prices, &mint).unwrap();
    let exact = token_price.price().to_bits();
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    for diverged in [exact + 1, exact - 1] {
        reserve.liquidity.market_price_sf = diverged;
        let err = check_reserve_price_basis(vault_token, token_price, &reserve).unwrap_err();
        assert_eq!(
            err,
            anchor_lang::error::Error::from(KaminoVaultError::ReservePriceMismatch)
        );
    }
}

#[test]
fn price_basis_rejects_reserve_with_unknown_mint() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    let unknown_mint = Pubkey::new_unique();
    let err = find_enabled_token_and_price(&vault, &vault_scope_prices, &unknown_mint).unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::TokenNotEnabledInVault)
    );
}

#[test]
fn price_basis_tolerance_window_accepts_within_and_rejects_beyond() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].max_price_divergence_bps = 100; // 1%
    let vault_token = &vault.vault_tokens[0];
    let token_price = &vault_scope_prices.prices[0];
    let scope = token_price.price();

    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = vault_token.mint;

    // within: 0.5% below and above
    for px in [scope * 995 / 1000, scope * 1005 / 1000] {
        reserve.liquidity.market_price_sf = px.to_bits();
        check_reserve_price_basis(vault_token, token_price, &reserve).unwrap();
    }
    // exactly at the bound: <= semantics accepts
    reserve.liquidity.market_price_sf = (scope * 101 / 100).to_bits();
    check_reserve_price_basis(vault_token, token_price, &reserve).unwrap();
    // beyond: 2%
    reserve.liquidity.market_price_sf = (scope * 102 / 100).to_bits();
    let err = check_reserve_price_basis(vault_token, token_price, &reserve).unwrap_err();
    assert_eq!(
        err,
        anchor_lang::error::Error::from(KaminoVaultError::ReservePriceMismatch)
    );
}

/// One whole $1.00 token in 6-decimals raw units, so amounts that are multiples of it convert
/// to dollars with zero fractional remainder regardless of rounding method.
const ONE_TOKEN: u64 = 1_000_000;

/// Vault fixture for the scope-basis coherence tests: one $1.00 token (6 decimals — a vault's
/// `shares_mint_decimals` must be non-zero, so unlike `reserve_with_unit_price` this can't use 0
/// decimals), with the free balance and AUM checkpoint reset to a round, comfortably large
/// figure (independent of whatever `INITIAL_DEPOSIT_SIZE` seeded).
fn vault_with_round_dollar_balance(whole_tokens: u64) -> (MetavaultState, VaultScopePrices) {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].token_available = whole_tokens * ONE_TOKEN;
    vault.set_prev_aum(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil));
    (vault, vault_scope_prices)
}

/// The reserve's cached price is NOT an AUM input: with the reserve diverged 10% from scope,
/// repaying is AUM-neutral — the free leg (-X at scope) and the obligation leg (+X at scope)
/// cancel exactly.
#[test]
fn repay_aum_delta_is_scope_priced_regardless_of_reserve_price() {
    let (mut vault, vault_scope_prices) = vault_with_round_dollar_balance(1_000);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;

    let slot = 1;
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.mint_decimals = 6;
    // Cached 10% above the vault's $1.00 scope price; must not move the AUM delta.
    reserve.liquidity.market_price_sf = Fraction::from_num(1.10).to_bits();
    reserve
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());

    let reserve_pk = Pubkey::new_unique();
    let mut obligation = Obligation::default();
    obligation.borrows[0] = ObligationLiquidity {
        borrow_reserve: reserve_pk,
        borrowed_amount_sf: Fraction::from(500 * ONE_TOKEN).to_bits(), // $500 owed
        ..Default::default()
    };

    let prev_aum_before = vault.prev_aum();
    repay_obligation_liquidity(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &reserve,
        &obligation,
        &reserve_pk,
        &mint,
        TokenAmount::from(100 * ONE_TOKEN), // repay $100
        slot,
        Timestamp::from(0),
    )
    .unwrap();

    assert_eq!(vault.prev_aum(), prev_aum_before);
}

/// Borrow analog: net AUM drops by exactly the origination fee valued at scope, regardless of
/// the reserve's cached price.
#[test]
fn borrow_aum_delta_is_scope_priced_regardless_of_reserve_price() {
    let (mut vault, vault_scope_prices) = vault_with_round_dollar_balance(1_000);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;

    let slot = 1;
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.mint_decimals = 6;
    // Cached 10% above the vault's $1.00 scope price; must not move the AUM delta.
    reserve.liquidity.market_price_sf = Fraction::from_num(1.10).to_bits();
    reserve.liquidity.total_available_amount = 1_000 * ONE_TOKEN;
    reserve.config.borrow_limit = 1_000 * ONE_TOKEN;
    // Origination fee rate is an exact power-of-two fraction (1/128), so the fee on a
    // 128-token borrow is exactly 1 token ($1), with no `to_round` ambiguity.
    reserve.config.fees.origination_fee_sf = 1u64 << 53;
    reserve
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());

    let lending_market = LendingMarket::default();
    let obligation = Obligation {
        // $1,000,000 borrow-value ceiling: comfortably above the $141.90 (129 tokens x $1.10
        // reserve-cached price) that klend's internal LTV check computes off the diverged price.
        allowed_borrow_value_sf: Fraction::from(1_000_000u64).to_bits(),
        ..Default::default()
    };

    let prev_aum_before = vault.prev_aum();
    borrow_obligation_liquidity(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &reserve,
        &lending_market,
        &obligation,
        &mint,
        TokenAmount::from(128 * ONE_TOKEN), // request 128 tokens
        slot,
        Timestamp::from(0),
    )
    .unwrap();

    let origination_fee = DollarValue::from_bits(Fraction::from(1u64).to_bits());
    assert_eq!(vault.prev_aum(), prev_aum_before - origination_fee);
}

/// Reserve fixture with a 3:2 ctoken:liquidity exchange rate, so klend's ctoken mint rounds on
/// odd liquidity amounts — the case where the deposit-leg booking (minted ctokens) and the
/// liquidity charged for them genuinely differ.
fn reserve_with_three_to_two_exchange_rate(mint: Pubkey, slot: u64) -> Reserve {
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.mint_decimals = 6;
    // Cached 10% above the vault's $1.00 scope price; must not move any AUM delta.
    reserve.liquidity.market_price_sf = Fraction::from_num(1.10).to_bits();
    reserve.collateral.mint_total_supply = 3 * ONE_TOKEN;
    reserve.liquidity.total_available_amount = 2 * ONE_TOKEN;
    reserve
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());
    reserve
}

/// The deposit delta books the minted ctokens (what the loader recomputes for the leg next
/// time), valued at scope with floor — NOT the ceil'd liquidity klend charges for them, and NOT
/// klend's cached reserve price.
#[test]
fn deposit_collateral_aum_delta_books_minted_ctokens_at_scope_price() {
    let (mut vault, vault_scope_prices) = vault_with_round_dollar_balance(1_000);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;
    let slot = 1;
    let reserve = reserve_with_three_to_two_exchange_rate(mint, slot);

    let effects = deposit_obligation_collateral(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &reserve,
        &mint,
        TokenAmount::from(ONE_TOKEN + 1), // odd amount: the ctoken mint floors
        slot,
        Timestamp::from(0),
    )
    .unwrap();

    // klend: ctokens = floor(1_000_001 * 3/2) = 1_500_001; liquidity charged = ceil(back) = all.
    assert_eq!(u64::from(effects.ctokens_to_receive), 1_500_001);
    assert_eq!(u64::from(effects.liquidity_to_deposit), ONE_TOKEN + 1);

    // The booked leg is the loader's per-leg formula exactly: ctokens -> liquidity through the
    // reserve's exchange rate, valued at the $1.00 scope price with floor.
    let (_, token_price) =
        find_enabled_token_and_price(&vault, &vault_scope_prices, &mint).unwrap();
    let leg_liquidity = reserve
        .collateral_exchange_rate()
        .fraction_collateral_to_liquidity(effects.ctokens_to_receive.as_fraction());
    let leg_value = token_price.fraction_to_aum(leg_liquidity, RoundingMethod::Floor);

    // Fixture non-degeneracy: the two candidate bookings must actually differ here, else this
    // test would pass under either quantity basis.
    let charged_value = effects
        .liquidity_to_deposit
        .to_aum(token_price, RoundingMethod::Floor);
    assert!(leg_value < charged_value);

    assert_eq!(
        vault.prev_aum(),
        vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil) + leg_value
    );
}

/// Loose bound for comparing the delta-booked `prev_aum` against a whole-leg recompute: each
/// dollar-valuation step rounds independently on the `Fraction` grid, so the two ways of
/// slicing the same quantities may differ by a few 2^-60 ULPs (~1e-17 dollars) — but never by
/// token-lamport-scale value.
fn assert_dollar_values_within_ulps(a: DollarValue, b: DollarValue, msg: &str) {
    let a = Fraction::from(a);
    let b = Fraction::from(b);
    let diff = if a >= b { a - b } else { b - a };
    assert!(
        diff <= Fraction::from_bits(8),
        "{msg}: {a} vs {b} differ by {diff} > 8 ULPs"
    );
}

/// A full repay settles the obligation's *fractional* debt (`settle_amount`) while the vault
/// transfers its ceiling; the AUM delta must book the settled amount — what the loader
/// recomputes next operation — not the transferred integer. Booking the transfer would leave
/// `prev_aum` overstated by the ceil dust (here half a lamport ~ $0.0000005).
#[test]
fn full_repay_of_fractional_debt_books_settled_debt_into_prev_aum() {
    let (mut vault, vault_scope_prices) = vault_with_round_dollar_balance(1_000);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;

    let slot = 1;
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.mint_decimals = 6;
    reserve.liquidity.market_price_sf = Fraction::ONE.to_bits();
    reserve
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());

    // Debt with half a lamport of accrued interest: 500.0000005 tokens.
    let leg_f = Fraction::from(500 * ONE_TOKEN) + Fraction::from_num(0.5);
    let reserve_pk = Pubkey::new_unique();
    let mut obligation = Obligation::default();
    obligation.borrows[0] = ObligationLiquidity {
        borrow_reserve: reserve_pk,
        borrowed_amount_sf: leg_f.to_bits(),
        ..Default::default()
    };

    // Mirror the loader's per-leg formula on the pre-CPI obligation state.
    let (_, token_price) =
        find_enabled_token_and_price(&vault, &vault_scope_prices, &mint).unwrap();
    let pre_obligations_aum = NetAum::net_from_diff(
        DollarValue::ZERO,
        token_price.fraction_to_aum(leg_f, RoundingMethod::Ceil),
    );

    let effects = repay_obligation_liquidity(
        &mut vault,
        &vault_scope_prices,
        pre_obligations_aum,
        &reserve,
        &obligation,
        &reserve_pk,
        &mint,
        TokenAmount::from(u64::MAX), // full repay
        slot,
        Timestamp::from(0),
    )
    .unwrap();
    // klend: settle = 500_000_000.5 (leg goes to zero); transfer = ceil = 500_000_001.
    assert_eq!(u64::from(effects.liquidity_to_repay), 500 * ONE_TOKEN + 1);
    assert_eq!(Fraction::from(effects.debt_decrease), leg_f);

    // What the loader recomputes at the next operation (same slot, same prices): no borrows left.
    let recomputed_aum = vault
        .compute_net_aum(&vault_scope_prices, NetAum::ZERO, RoundingMethod::Ceil)
        .try_non_negative()
        .unwrap();
    assert_dollar_values_within_ulps(
        vault.prev_aum(),
        recomputed_aum,
        "prev_aum after full repay vs loader recompute",
    );
}

/// An all-available borrow books *fractional* debt (`borrow_amount_f`) in klend; the AUM delta
/// must book that same fractional amount — what the loader recomputes next operation — not the
/// integer `receive + origination_fee = floor(borrow_amount_f)`, which would leave `prev_aum`
/// overstated by the fractional part's value.
#[test]
fn all_available_borrow_of_fractional_capacity_books_fractional_debt_into_prev_aum() {
    let (mut vault, vault_scope_prices) = vault_with_round_dollar_balance(1_000);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;

    let slot = 1;
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.mint_decimals = 6;
    reserve.liquidity.market_price_sf = Fraction::ONE.to_bits();
    reserve.liquidity.total_available_amount = 1_000 * ONE_TOKEN;
    reserve.config.borrow_limit = 1_000 * ONE_TOKEN;
    reserve
        .last_update
        .update_slot(slot, kamino_lending::PriceStatusFlags::all());

    let lending_market = LendingMarket::default();
    // The binding cap: a fractional allowed-borrow value, so klend's all-available sizing
    // yields fractional debt of 500.0000005 tokens.
    let obligation = Obligation {
        allowed_borrow_value_sf: Fraction::from_num(500.0000005).to_bits(),
        ..Default::default()
    };

    let effects = borrow_obligation_liquidity(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &reserve,
        &lending_market,
        &obligation,
        &mint,
        TokenAmount::from(u64::MAX), // all available
        slot,
        Timestamp::from(0),
    )
    .unwrap();
    // klend books borrow_amount_f (fractional); the vault receives its floor, fee-free here.
    assert_eq!(u64::from(effects.liquidity_to_receive), 500 * ONE_TOKEN);
    assert_eq!(u64::from(effects.origination_fee), 0);
    // The booked debt carries the sub-lamport part the integer fields cannot express.
    assert!(Fraction::from(effects.debt_increase) > Fraction::from(500 * ONE_TOKEN));

    // What the loader recomputes at the next operation: the leg holds the fractional debt,
    // reconstructed here independently of the effects.
    let booked_debt_f = Fraction::from_num(500.0000005) * Fraction::from(ONE_TOKEN);
    let (_, token_price) =
        find_enabled_token_and_price(&vault, &vault_scope_prices, &mint).unwrap();
    let recomputed_obligations_aum = NetAum::net_from_diff(
        DollarValue::ZERO,
        token_price.fraction_to_aum(booked_debt_f, RoundingMethod::Ceil),
    );
    let recomputed_aum = vault
        .compute_net_aum(
            &vault_scope_prices,
            recomputed_obligations_aum,
            RoundingMethod::Ceil,
        )
        .try_non_negative()
        .unwrap();
    assert_dollar_values_within_ulps(
        vault.prev_aum(),
        recomputed_aum,
        "prev_aum after all-available borrow vs loader recompute",
    );
}

/// Withdraw analog: the delta books the redeemed ctokens' scope value (ceil — vault-favorable),
/// regardless of the reserve's cached price.
#[test]
fn withdraw_collateral_aum_delta_is_scope_priced_regardless_of_reserve_price() {
    let (mut vault, vault_scope_prices) = vault_with_round_dollar_balance(1_000);
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;
    let slot = 1;
    let reserve = reserve_with_three_to_two_exchange_rate(mint, slot);
    let lending_market = LendingMarket::default();

    let reserve_pk = Pubkey::new_unique();
    let mut obligation = Obligation::default();
    obligation.deposits[0] = ObligationCollateral {
        deposit_reserve: reserve_pk,
        deposited_amount: 3 * ONE_TOKEN, // 3M ctokens = $2 of liquidity at the 3:2 rate
        ..Default::default()
    };

    let effects = withdraw_obligation_collateral(
        &mut vault,
        &vault_scope_prices,
        NetAum::ZERO,
        &reserve,
        &lending_market,
        &obligation,
        &reserve_pk,
        &mint,
        AllAvailableOr::Exactly(TokenAmount::from(1_500_001u64)), // odd: redeem floors
        slot,
        Timestamp::from(0),
    )
    .unwrap();

    assert_eq!(u64::from(effects.ctokens_to_redeem), 1_500_001);
    assert_eq!(u64::from(effects.liquidity_to_receive), ONE_TOKEN);

    let (_, token_price) =
        find_enabled_token_and_price(&vault, &vault_scope_prices, &mint).unwrap();
    let leg_liquidity = reserve
        .collateral_exchange_rate()
        .fraction_collateral_to_liquidity(effects.ctokens_to_redeem.as_fraction());
    let leg_value = token_price.fraction_to_aum(leg_liquidity, RoundingMethod::Ceil);

    // Vault-favorable: the obligation gives up marginally more value than lands free.
    let received_value = effects
        .liquidity_to_receive
        .to_aum(token_price, RoundingMethod::Floor);
    assert!(received_value < leg_value);

    assert_eq!(
        vault.prev_aum(),
        vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Ceil) - leg_value
    );
}

//! Property tests for the AUM-continuity invariant of the four obligation operations: the
//! `prev_aum` booked at the end of an operation must match what the shared loader recomputes
//! from the post-CPI obligation state on the same slot and prices.
//!
//! The recompute mirrors the loader's per-leg formula on the post-op leg quantities, using the
//! *pre-CPI* reserve state — deliberately excluding the reserve exchange-rate micro-shift that
//! klend's own rounding causes (see the `obligation_operations` module docs), which a delta
//! booking cannot see by construction. What remains is pure rounding sub-additivity, bounded
//! far below one token lamport's value.

use std::collections::HashMap;

use kamino_lending::fraction::Fraction;
use kamino_lending::{
    LendingMarket, Obligation, ObligationCollateral, ObligationLiquidity, PriceStatusFlags, Reserve,
};
use proptest::prelude::*;
use solana_program::pubkey::Pubkey;

use super::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig};
use crate::operations::obligation_operations::{
    borrow_obligation_liquidity, deposit_obligation_collateral, repay_obligation_liquidity,
    withdraw_obligation_collateral,
};
use crate::operations::vault_checks::find_enabled_token_and_price;
use crate::types::{amounts::AllAvailableOr, NetAum, RoundingMethod, Timestamp, TokenAmount};
use crate::utils::scope::VaultScopePrices;
use crate::MetavaultState;

/// Maximum tolerated difference between the delta-booked `prev_aum` and the whole-leg
/// recompute: independent floors/ceils on the `Fraction` grid (2^-60 dollars, scaled by up to
/// price/10^decimals when the rounding happens in token space) accumulate to well under 1e-13
/// dollars for the generated ranges. A lamport-scale booking bug is at least 1e-10 dollars
/// here (price >= 0.1, decimals <= 9), so this bound separates the two by orders of magnitude.
const MAX_AUM_DUST: Fraction = kamino_lending::fraction::fraction!(0.000000000001); // 1e-12

const SLOT: u64 = 1;

struct Fixture {
    vault: MetavaultState,
    prices: VaultScopePrices,
    mint: Pubkey,
    reserve: Reserve,
    reserve_pk: Pubkey,
    obligation: Obligation,
    deposit_leg_ctokens: u64,
    borrow_leg_debt_f: Fraction,
}

/// Single-token vault plus a reserve/obligation pair holding one deposit leg (`ctokens`) and
/// one borrow leg (integer debt + sub-lamport interest dust). The borrow leg is capped at a
/// quarter of the free balance so net AUM stays clearly positive through every operation
/// (`update_prev_aum_if_not_negative` never skips). The klend-cached reserve price is
/// `reserve_price_pct`% of the scope price: valuation must never read it, so the recompute
/// stays exact for any multiplier — a regression back to reserve-priced AUM deltas fails
/// these properties instead of hiding behind price equality.
#[allow(clippy::too_many_arguments)]
fn fixture(
    price: f64,
    decimals: u8,
    free_lamports: u64,
    ctoken_supply: u64,
    liquidity_available: u64,
    deposit_leg_ctokens: u64,
    debt_int: u64,
    debt_frac_bits: u64,
    reserve_price_pct: u64,
) -> Fixture {
    let tokens =
        HashMap::from_iter([("TOK", TokenConfig::with_price_and_decimals(price, decimals))]);
    let (mut vault, prices) = setup_vault_with_tokens(&tokens);
    vault.vault_tokens[0].token_available = free_lamports;
    let mint = vault.iter_enabled_tokens().next().unwrap().mint;

    let (_, token_price) = find_enabled_token_and_price(&vault, &prices, &mint).unwrap();
    let mut reserve = Reserve::default();
    reserve.liquidity.mint_pubkey = mint;
    reserve.liquidity.mint_decimals = u64::from(decimals);
    let reserve_price =
        token_price.price() * Fraction::from(reserve_price_pct) / Fraction::from(100_u64);
    reserve.liquidity.market_price_sf = reserve_price.to_bits();
    reserve.collateral.mint_total_supply = ctoken_supply;
    reserve.liquidity.total_available_amount = liquidity_available;
    reserve
        .last_update
        .update_slot(SLOT, PriceStatusFlags::all());

    let borrow_leg_debt_f = Fraction::from(debt_int) + Fraction::from_bits(debt_frac_bits.into());
    let reserve_pk = Pubkey::new_unique();
    let mut obligation = Obligation::default();
    obligation.deposits[0] = ObligationCollateral {
        deposit_reserve: reserve_pk,
        deposited_amount: deposit_leg_ctokens,
        ..Default::default()
    };
    obligation.borrows[0] = ObligationLiquidity {
        borrow_reserve: reserve_pk,
        borrowed_amount_sf: borrow_leg_debt_f.to_bits(),
        ..Default::default()
    };

    Fixture {
        vault,
        prices,
        mint,
        reserve,
        reserve_pk,
        obligation,
        deposit_leg_ctokens,
        borrow_leg_debt_f,
    }
}

/// Mirrors `load_obligations_aum`'s per-leg valuation: deposit legs ctokens -> liquidity through
/// the reserve's exchange rate, floored at scope; borrow legs as fractional liquidity, ceiled at
/// scope.
fn loader_obligations_aum(fx: &Fixture, deposit_ctokens: u64, debt_f: Fraction) -> NetAum {
    let (_, token_price) = find_enabled_token_and_price(&fx.vault, &fx.prices, &fx.mint).unwrap();
    let liquidity_f = fx
        .reserve
        .collateral_exchange_rate()
        .fraction_collateral_to_liquidity(TokenAmount::from(deposit_ctokens).as_fraction());
    let deposited = token_price.fraction_to_aum(liquidity_f, RoundingMethod::Floor);
    let borrowed = token_price.fraction_to_aum(debt_f, RoundingMethod::Ceil);
    NetAum::net_from_diff(deposited, borrowed)
}

/// Asserts the booked `prev_aum` equals the loader recompute of the post-op leg state.
fn assert_prev_aum_matches_recompute(
    fx: &Fixture,
    post_deposit_ctokens: u64,
    post_debt_f: Fraction,
) -> Result<(), TestCaseError> {
    let recomputed_obligations = loader_obligations_aum(fx, post_deposit_ctokens, post_debt_f);
    let recomputed = fx
        .vault
        .compute_net_aum(&fx.prices, recomputed_obligations, RoundingMethod::Ceil)
        .try_non_negative()
        .expect("fixture keeps net AUM positive");

    let prev = Fraction::from(fx.vault.prev_aum());
    let recomputed = Fraction::from(recomputed);
    let diff = if prev >= recomputed {
        prev - recomputed
    } else {
        recomputed - prev
    };
    prop_assert!(
        diff <= MAX_AUM_DUST,
        "prev_aum {prev} vs recompute {recomputed}: diff {diff} exceeds dust bound"
    );
    Ok(())
}

prop_compose! {
    /// Reserve/vault dimensions shared by all four operation properties. The ctoken supply is
    /// kept within 2x of the liquidity so exchange rates stay in [0.5, 2] and conversions of
    /// up-to-1e15-lamport amounts cannot overflow u64.
    fn base_state()(
        price in 0.1_f64..10_000.0,
        // The vault fixture reuses the token decimals for the shares mint, which rejects 0.
        decimals in 1_u8..=9,
        free_lamports in 1_000_000_u64..1_000_000_000_000_000,
        liquidity_available in 1_000_000_u64..1_000_000_000,
        supply_ratio_pct in 50_u64..=200,
        deposit_leg_ctokens in 1_u64..1_000_000_000_000,
        debt_frac_bits in 0_u64..(1 << 60),
        reserve_price_pct in 50_u64..=200,
    ) -> (f64, u8, u64, u64, u64, u64, u64, u64) {
        let ctoken_supply = liquidity_available * supply_ratio_pct / 100;
        (price, decimals, free_lamports, ctoken_supply, liquidity_available,
         deposit_leg_ctokens, debt_frac_bits, reserve_price_pct)
    }
}

proptest! {
    // Operation errors surface as counted rejections (`TestCaseError::reject`), never silent
    // passes: every property must reach `cases` genuine executions, and a strategy regression
    // that mostly errors trips `max_global_rejects` instead of passing vacuously.
    #![proptest_config(ProptestConfig{cases: 10_000, max_global_rejects: 100_000, ..Default::default()})]

    #[test]
    fn deposit_collateral_prev_aum_matches_loader_recompute(
        (price, decimals, free_lamports, ctoken_supply, liquidity_available,
         deposit_leg_ctokens, debt_frac_bits, reserve_price_pct) in base_state(),
        debt_int_pct in 0_u64..25,
        amount_pct in 1_u64..50,
    ) {
        let debt_int = free_lamports / 100 * debt_int_pct;
        let mut fx = fixture(price, decimals, free_lamports, ctoken_supply,
            liquidity_available, deposit_leg_ctokens, debt_int, debt_frac_bits,
            reserve_price_pct);
        let pre_aum = loader_obligations_aum(&fx, fx.deposit_leg_ctokens, fx.borrow_leg_debt_f);

        let amount = free_lamports / 100 * amount_pct;
        let Fixture { vault, prices, reserve, mint, .. } = &mut fx;
        let effects = deposit_obligation_collateral(
            vault, prices, pre_aum, reserve, mint,
            TokenAmount::from(amount), SLOT, Timestamp::from(0),
        ).map_err(|err| TestCaseError::reject(format!("deposit errored: {err}")))?;

        // klend merges the minted ctokens into the existing leg.
        let post_ctokens = fx.deposit_leg_ctokens + u64::from(effects.ctokens_to_receive);
        assert_prev_aum_matches_recompute(&fx, post_ctokens, fx.borrow_leg_debt_f)?;
    }

    #[test]
    fn withdraw_collateral_prev_aum_matches_loader_recompute(
        (price, decimals, free_lamports, ctoken_supply, liquidity_available,
         deposit_leg_ctokens, debt_frac_bits, reserve_price_pct) in base_state(),
        debt_int_pct in 0_u64..25,
        amount_pct in 1_u64..=100,
        all_available in any::<bool>(),
        collateral_market_value in 1_u64..1_000_000_000,
        allowed_borrow_value in 1_u64..1_000_000_000,
        max_ltv_pct in 1_u8..=90,
    ) {
        let debt_int = free_lamports / 100 * debt_int_pct;
        let mut fx = fixture(price, decimals, free_lamports, ctoken_supply,
            liquidity_available, deposit_leg_ctokens, debt_int, debt_frac_bits,
            reserve_price_pct);
        // Aggregates read only by klend's max-withdraw sizing; the AUM recompute never uses them.
        fx.reserve.config.loan_to_value_pct = max_ltv_pct;
        fx.reserve.config.liquidation_threshold_pct = max_ltv_pct;
        fx.obligation.deposits[0].market_value_sf = Fraction::from(collateral_market_value).to_bits();
        fx.obligation.deposited_value_sf = Fraction::from(collateral_market_value).to_bits();
        fx.obligation.allowed_borrow_value_sf = Fraction::from(allowed_borrow_value).to_bits();
        let pre_aum = loader_obligations_aum(&fx, fx.deposit_leg_ctokens, fx.borrow_leg_debt_f);

        let requested = if all_available {
            AllAvailableOr::AllAvailable
        } else {
            AllAvailableOr::Exactly(TokenAmount::from(deposit_leg_ctokens / 100 * amount_pct))
        };
        let lending_market = LendingMarket::default();
        let (reserve_pk, mint) = (fx.reserve_pk, fx.mint);
        let obligation = fx.obligation;
        let effects = withdraw_obligation_collateral(
            &mut fx.vault, &fx.prices, pre_aum, &fx.reserve, &lending_market, &obligation,
            &reserve_pk, &mint, requested, SLOT, Timestamp::from(0),
        ).map_err(|err| TestCaseError::reject(format!("withdraw errored: {err}")))?;

        let post_ctokens = fx.deposit_leg_ctokens - u64::from(effects.ctokens_to_redeem);
        assert_prev_aum_matches_recompute(&fx, post_ctokens, fx.borrow_leg_debt_f)?;
    }

    #[test]
    fn borrow_liquidity_prev_aum_matches_loader_recompute(
        (price, decimals, free_lamports, ctoken_supply, liquidity_available,
         deposit_leg_ctokens, debt_frac_bits, reserve_price_pct) in base_state(),
        debt_int_pct in 0_u64..25,
        amount_pct in 1_u64..25,
        all_available in any::<bool>(),
        allowed_value_int in 1_u64..1_000_000,
        allowed_value_frac_bits in 0_u64..(1 << 60),
        origination_fee_sf in 0_u64..(1 << 55),
    ) {
        let debt_int = free_lamports / 100 * debt_int_pct;
        let mut fx = fixture(price, decimals, free_lamports, ctoken_supply,
            liquidity_available, deposit_leg_ctokens, debt_int, debt_frac_bits,
            reserve_price_pct);
        fx.reserve.config.borrow_limit = u64::MAX;
        fx.reserve.config.fees.origination_fee_sf = origination_fee_sf;
        // All-available sizing binds on the (fractional) allowed borrow value (or the reserve's
        // integer liquidity, whichever is lower); exact borrows get a generous allowance
        // instead so the request itself is the binding constraint, capped by the reserve's
        // available liquidity.
        let amount = if all_available {
            fx.obligation.allowed_borrow_value_sf =
                (Fraction::from(allowed_value_int) + Fraction::from_bits(allowed_value_frac_bits.into())).to_bits();
            u64::MAX
        } else {
            fx.obligation.allowed_borrow_value_sf = Fraction::from(10_000_000_000_000_000_000_u64).to_bits();
            free_lamports.min(liquidity_available) / 100 * amount_pct
        };
        let pre_aum = loader_obligations_aum(&fx, fx.deposit_leg_ctokens, fx.borrow_leg_debt_f);

        let lending_market = LendingMarket::default();
        let mint = fx.mint;
        let obligation = fx.obligation;
        let effects = borrow_obligation_liquidity(
            &mut fx.vault, &fx.prices, pre_aum, &fx.reserve, &lending_market, &obligation,
            &mint, TokenAmount::from(amount), SLOT, Timestamp::from(0),
        ).map_err(|err| TestCaseError::reject(format!("borrow errored: {err}")))?;
        // A degenerate all-available allowance can size the borrow to zero lamports; such a
        // case asserts nothing about the booking, so it must not count toward the case budget.
        prop_assume!(!Fraction::from(effects.debt_increase).is_zero());

        // klend books the fractional borrow_amount_f into the existing leg.
        let post_debt_f = fx.borrow_leg_debt_f + Fraction::from(effects.debt_increase);
        assert_prev_aum_matches_recompute(&fx, fx.deposit_leg_ctokens, post_debt_f)?;
    }

    #[test]
    fn repay_liquidity_prev_aum_matches_loader_recompute(
        (price, decimals, free_lamports, ctoken_supply, liquidity_available,
         deposit_leg_ctokens, debt_frac_bits, reserve_price_pct) in base_state(),
        debt_int_pct in 1_u64..25,
        amount_pct in 1_u64..=200,
        full_repay in any::<bool>(),
    ) {
        let debt_int = (free_lamports / 100 * debt_int_pct).max(1);
        let mut fx = fixture(price, decimals, free_lamports, ctoken_supply,
            liquidity_available, deposit_leg_ctokens, debt_int, debt_frac_bits,
            reserve_price_pct);
        let pre_aum = loader_obligations_aum(&fx, fx.deposit_leg_ctokens, fx.borrow_leg_debt_f);

        // Over-requesting (up to 2x the debt) exercises klend's min-with-debt settling.
        let amount = if full_repay { u64::MAX } else { (debt_int / 100 * amount_pct).max(1) };
        let (reserve_pk, mint) = (fx.reserve_pk, fx.mint);
        let obligation = fx.obligation;
        let effects = repay_obligation_liquidity(
            &mut fx.vault, &fx.prices, pre_aum, &fx.reserve, &obligation,
            &reserve_pk, &mint, TokenAmount::from(amount), SLOT, Timestamp::from(0),
        ).map_err(|err| TestCaseError::reject(format!("repay errored: {err}")))?;

        // klend settles the fractional settle_amount off the leg.
        let post_debt_f = fx.borrow_leg_debt_f - Fraction::from(effects.debt_decrease);
        assert_prev_aum_matches_recompute(&fx, fx.deposit_leg_ctokens, post_debt_f)?;
    }
}

use kamino_lending::{
    fraction::Fraction, program_test::common::math::usdc_decimal_to_u64 as usdc,
    utils::FractionExtra,
};
use proptest::prelude::*;

use crate::operations::vault_operations::common::compute_amount_to_deposit_from_shares_to_mint;
use crate::types::{DollarValue, Ratio, ShareAmount, TokenAmount, TokenPrice};

use kamino_lending::assert_fuzzy_eq;

#[test]
fn test_compute_deposit_shares_to_amount_price_marginally_above_1() {
    let vault_total_shares = ShareAmount::from(16386);
    let vault_total_holdings = DollarValue::from(Fraction::from_num(16386.0001220));
    let shares_to_mint = ShareAmount::from(1);
    let amount_to_deposit = compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(shares_to_mint, vault_total_shares),
        vault_total_holdings,
        &TokenPrice::new(Fraction::ONE, 0),
    );
    assert_eq!(amount_to_deposit, TokenAmount::from(2));
}

proptest! {
    #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 1_000_000, ..Default::default()})]
    #[test]
    fn test_compute_deposit_shares_to_amount(
        holdings_total_sum in 0.0001_f64..1_000_000_000.0,
        shares_to_deposit_lamports in 1_u64..10_000_000_000,
        shares_issued_lamports in 10_u64..100_000_000_000
    ) {
        let token_total_holdings = Fraction::from_num(holdings_total_sum);

        // The deposit amount (holdings * shares_to_deposit / shares_issued * 10^decimals)
        // must fit in u64 (max ~1.84e19). With decimals=6, we need:
        // estimated_deposit * 1e6 < u64::MAX -> estimated_deposit < 1.84e13.
        // Use 1e13 for safety margin against ceiling rounding.
        let estimated_deposit = holdings_total_sum
            * (shares_to_deposit_lamports as f64)
            / (shares_issued_lamports as f64);
        prop_assume!(estimated_deposit < 1e13);
        let amount_to_deposit = compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(ShareAmount::from(shares_to_deposit_lamports), ShareAmount::from(shares_issued_lamports)),
            DollarValue::from(token_total_holdings),
            &TokenPrice::new(Fraction::ONE, 6),
        );

        let expected_amount_to_deposit = test_compute_deposit_amount_from_shares(
            shares_issued_lamports,
            token_total_holdings,
            shares_to_deposit_lamports,
            Fraction::ONE,
            6
        );
        // allow 1 lamport diff as in our test function we do division first and then multiplication so we can lose 1 lamport of precision
        assert_fuzzy_eq!(u64::from(amount_to_deposit), expected_amount_to_deposit, 1);
        assert!(amount_to_deposit >= TokenAmount::from(expected_amount_to_deposit));
    }
}

#[test]
fn test_compute_deposit_shares_to_amount_specific_case_1() {
    let holding_sum = 0.0001;
    let shares_to_deposit_lamports = 5214;
    let shares_issued_lamports = 56606809585606603;
    let token_total_holdings = Fraction::from(usdc(holding_sum));

    let amount_to_deposit = compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(shares_to_deposit_lamports),
            ShareAmount::from(shares_issued_lamports),
        ),
        DollarValue::from(token_total_holdings),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    let expected_amount_to_deposit = test_compute_deposit_amount_from_shares(
        shares_issued_lamports,
        token_total_holdings,
        shares_to_deposit_lamports,
        Fraction::ONE,
        6,
    );
    assert_eq!(
        amount_to_deposit,
        TokenAmount::from(expected_amount_to_deposit)
    );
}

#[test]
fn test_compute_deposit_shares_to_amount_specific_case_2() {
    let holding_sum = 0.0001;
    let shares_to_deposit_lamports = 18768;
    let shares_issued_lamports = 9828827831260417;
    let token_total_holdings = Fraction::from(usdc(holding_sum));

    let amount_to_deposit = compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(shares_to_deposit_lamports),
            ShareAmount::from(shares_issued_lamports),
        ),
        DollarValue::from(token_total_holdings),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    let expected_amount_to_deposit = test_compute_deposit_amount_from_shares(
        shares_issued_lamports,
        token_total_holdings,
        shares_to_deposit_lamports,
        Fraction::ONE,
        6,
    );
    assert_eq!(
        amount_to_deposit,
        TokenAmount::from(expected_amount_to_deposit)
    );
}

pub fn test_compute_deposit_amount_from_shares(
    total_shares_issued: u64,
    token_total_holdings: Fraction,
    shares_amount: u64,
    token_price: Fraction,
    token_decimals: u8,
) -> u64 {
    let aum_to_deposit_f = (Fraction::from(shares_amount) / Fraction::from(total_shares_issued))
        * token_total_holdings;
    let amount_to_deposit_f =
        aum_to_deposit_f / token_price * Fraction::from(10u64.pow(token_decimals.into()));
    amount_to_deposit_f.to_ceil()
}

#[test]
fn test_compute_deposit_from_shares_scenarios() {
    struct TestCase {
        vault_total_shares: u64,
        vault_total_holdings: u64, // In AUM terms
        shares_to_mint: u64,
        token_price: f64,
        token_decimals: u8,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // Standard scenarios
        TestCase {
            vault_total_shares: 100_000_000, // 100 shares
            vault_total_holdings: 1000,      // $1000 AUM
            shares_to_mint: 10_000_000,      // 10 shares to mint
            token_price: 1.0,                // $1.00
            token_decimals: 6,
            expected_tokens: 100_000_000, // 100 tokens
        },
        TestCase {
            vault_total_shares: 200_000_000,
            vault_total_holdings: 2000,
            shares_to_mint: 50_000_000, // 50 shares
            token_price: 2.5,           // $2.50
            token_decimals: 6,
            expected_tokens: 200_000_000, // 200 tokens
        },
        // Ceiling rounding cases
        TestCase {
            vault_total_shares: 3,
            vault_total_holdings: 10,
            shares_to_mint: 1, // 1/3 of shares = $3.33... AUM
            token_price: 1.0,  // $1.00
            token_decimals: 6,
            expected_tokens: 3_333_334, // Ceiling of 3.333333
        },
        // High precision tokens
        TestCase {
            vault_total_shares: 1_000_000_000_000_000_000, // 18 decimals
            vault_total_holdings: 1000,
            shares_to_mint: 100_000_000_000_000_000, // 10% of shares
            token_price: 1.0,                        // $1.00
            token_decimals: 12,
            expected_tokens: 100_000_000_000_000, // 100 tokens (12 decimals)
        },
        // Low precision tokens
        TestCase {
            vault_total_shares: 100_000_000,
            vault_total_holdings: 1000,
            shares_to_mint: 10_000_000, // 10% of shares
            token_price: 1.0,           // $1.00
            token_decimals: 2,
            expected_tokens: 10_000, // 100 tokens (2 decimals)
        },
    ];

    for test in test_cases {
        let result = compute_amount_to_deposit_from_shares_to_mint(
            Ratio::of(
                ShareAmount::from(test.shares_to_mint),
                ShareAmount::from(test.vault_total_shares),
            ),
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            &TokenPrice::new(Fraction::from_num(test.token_price), test.token_decimals),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
fn test_compute_deposit_from_shares_edge_cases() {
    // Zero shares to mint
    let result = compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(ShareAmount::from(0), ShareAmount::from(100_000_000)),
        DollarValue::from(Fraction::from_num(1000)),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    assert_eq!(result, TokenAmount::from(0));

    // Tiny vault with large share mint
    let result = compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(ShareAmount::from(1_000_000), ShareAmount::from(1)),
        DollarValue::from(Fraction::from_num(1)),
        &TokenPrice::new(Fraction::ONE, 6),
    );
    assert_eq!(result, TokenAmount::from(1_000_000_000_000)); // 1M tokens needed
}

#[test]
fn test_compute_deposit_ceiling_rounding_precision() {
    struct TestCase {
        vault_total_shares: u64,
        vault_total_holdings: u64,
        shares_to_mint: u64,
        expected_tokens: u64,
    }

    let test_cases = vec![
        // Fractional results that need ceiling
        TestCase {
            vault_total_shares: 3,
            vault_total_holdings: 7,
            shares_to_mint: 1,
            expected_tokens: 2_333_334, // 2.333333... -> ceiling
        },
        TestCase {
            vault_total_shares: 7,
            vault_total_holdings: 3,
            shares_to_mint: 1,
            expected_tokens: 428_572, // 0.428571... -> ceiling
        },
        TestCase {
            vault_total_shares: 1000,
            vault_total_holdings: 333,
            shares_to_mint: 1,
            expected_tokens: 333_001, // 0.333 -> ceiling
        },
        // Near-exact calculations
        TestCase {
            vault_total_shares: 1_000_000,
            vault_total_holdings: 1_000_000,
            shares_to_mint: 1,
            expected_tokens: 1_000_000, // Exactly 1.0
        },
        TestCase {
            vault_total_shares: 1_000_000,
            vault_total_holdings: 999_999,
            shares_to_mint: 1,
            expected_tokens: 1_000_000, // 0.999999 -> ceiling to 1
        },
    ];

    for test in test_cases {
        let result = compute_amount_to_deposit_from_shares_to_mint(
            Ratio::of(
                ShareAmount::from(test.shares_to_mint),
                ShareAmount::from(test.vault_total_shares),
            ),
            DollarValue::from(Fraction::from_num(test.vault_total_holdings)),
            &TokenPrice::new(Fraction::ONE, 6),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
fn test_compute_deposit_different_token_prices() {
    struct TestCase {
        token_price_dollars: f64,
        shares_to_mint: u64,
        expected_tokens: u64,
    }

    // Vault: 100 shares, $1000 AUM, so $10 per share
    let vault_shares = ShareAmount::from(100_000_000);
    let vault_aum = DollarValue::from(Fraction::from_num(1000));

    let test_cases = vec![
        TestCase {
            token_price_dollars: 1.0,     // $1 token
            shares_to_mint: 10_000_000,   // 10 shares = $100 AUM
            expected_tokens: 100_000_000, // 100 tokens
        },
        TestCase {
            token_price_dollars: 0.50,    // $0.50 token
            shares_to_mint: 10_000_000,   // 10 shares = $100 AUM
            expected_tokens: 200_000_000, // 200 tokens
        },
        TestCase {
            token_price_dollars: 2.0,    // $2.00 token
            shares_to_mint: 10_000_000,  // 10 shares = $100 AUM
            expected_tokens: 50_000_000, // 50 tokens
        },
        TestCase {
            token_price_dollars: 100.0, // $100 token
            shares_to_mint: 10_000_000, // 10 shares = $100 AUM
            expected_tokens: 1_000_000, // 1 token
        },
        TestCase {
            token_price_dollars: 0.001,       // $0.001 token
            shares_to_mint: 10_000_000,       // 10 shares = $100 AUM
            expected_tokens: 100_000_000_000, // 100,000 tokens
        },
    ];

    for test in test_cases {
        let result = compute_amount_to_deposit_from_shares_to_mint(
            Ratio::of(ShareAmount::from(test.shares_to_mint), vault_shares),
            vault_aum,
            &TokenPrice::new(Fraction::from_num(test.token_price_dollars), 6),
        );

        assert_eq!(result, TokenAmount::from(test.expected_tokens));
    }
}

#[test]
#[should_panic]
fn test_compute_deposit_from_shares_zero_price() {
    compute_amount_to_deposit_from_shares_to_mint(
        Ratio::of(
            ShareAmount::from(10_000_000),
            ShareAmount::from(100_000_000),
        ),
        DollarValue::from(Fraction::from_num(1000.0)),
        &TokenPrice::new(Fraction::ZERO, 6),
    );
}

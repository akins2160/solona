#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use itertools::izip;

    use crate::{
        operations::{
            tests::tests_utils::{fixtures::setup_vault_with_tokens, TokenConfig},
            vault_operations::update_token_weights,
        },
        types::{Timestamp, Weight},
        KaminoVaultError,
    };

    #[test]
    fn test_update_token_weights_success() {
        let tokens = HashMap::from([
            ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("USDT", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        let weights = vec![Weight::from(3), Weight::from(5), Weight::from(2)]; // 30%, 50%, 20% ratio

        let result = update_token_weights(&mut vault, weights.clone(), Timestamp::ZERO);
        result.unwrap();

        // Verify weights were set correctly for enabled tokens
        for (token, weight) in izip!(vault.iter_enabled_tokens(), weights) {
            assert_eq!(token.weight, u64::from(weight));
        }
    }

    #[test]
    fn test_update_token_weights_zero_sum() {
        let tokens = HashMap::from([
            ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("USDT", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        let weights = vec![Weight::from(0), Weight::from(0), Weight::from(0)]; // Sum is 0, invalid

        let result = update_token_weights(&mut vault, weights, Timestamp::ZERO);
        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::InvalidWeightsSum.into()
        );
    }

    #[test]
    fn test_update_token_weights_array_length_mismatch() {
        let tokens = HashMap::from([
            ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("USDT", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        let weights = vec![Weight::from(1), Weight::from(1)]; // Only 2 weights for 3 tokens

        let result = update_token_weights(&mut vault, weights, Timestamp::ZERO);
        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::TokenArrayLengthMismatch.into()
        );
    }

    #[test]
    fn test_update_token_weights_single_token() {
        let tokens = HashMap::from([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        let weights = vec![Weight::from(1)]; // 100% for single token

        let result = update_token_weights(&mut vault, weights, Timestamp::ZERO);
        result.unwrap();
        assert_eq!(vault.vault_tokens[0].weight, 1);
    }

    #[test]
    fn test_update_token_weights_equal_distribution() {
        let tokens = HashMap::from([
            ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("USDT", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("DAI", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("BUSD", TokenConfig::with_price_and_decimals(1.0, 6)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        let weights = vec![
            Weight::from(1),
            Weight::from(1),
            Weight::from(1),
            Weight::from(1),
        ]; // 25% each

        let result = update_token_weights(&mut vault, weights, Timestamp::ZERO);
        result.unwrap();

        // Verify all enabled tokens have equal weight
        for token in vault.iter_enabled_tokens() {
            assert_eq!(token.weight, 1);
        }
    }

    #[test]
    fn test_update_token_weights_zero_weight() {
        let tokens = HashMap::from([
            ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("USDT", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        let weights = vec![Weight::from(0), Weight::from(1), Weight::from(0)]; // Middle token gets 100%

        let result = update_token_weights(&mut vault, weights.clone(), Timestamp::ZERO);
        result.unwrap();

        // Check weights match what was set
        for (token, weight) in izip!(vault.iter_enabled_tokens(), weights) {
            assert_eq!(token.weight, u64::from(weight));
        }
    }

    #[test]
    fn test_update_token_weights_two_tokens() {
        let tokens = HashMap::from([
            ("ETH", TokenConfig::with_price_and_decimals(2000.0, 18)),
            ("BTC", TokenConfig::with_price_and_decimals(40000.0, 8)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        // Tokens are sorted alphabetically: BTC first, ETH second
        let weights = vec![Weight::from(2), Weight::from(3)]; // 40% BTC, 60% ETH ratio

        let result = update_token_weights(&mut vault, weights, Timestamp::ZERO);
        result.unwrap();

        // Verify weights match what was set (alphabetical order)
        let enabled_tokens: Vec<_> = vault.iter_enabled_tokens().collect();

        assert_eq!(enabled_tokens[0].weight, 2); // BTC (alphabetically first)
        assert_eq!(enabled_tokens[1].weight, 3); // ETH (alphabetically second)
    }

    #[test]
    fn test_update_token_weights_many_tokens() {
        let tokens = HashMap::from([
            ("A", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("B", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("C", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("D", TokenConfig::with_price_and_decimals(1.0, 6)),
            ("E", TokenConfig::with_price_and_decimals(1.0, 6)),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        // Unequal distribution
        let weights = vec![
            Weight::from(2),
            Weight::from(3),
            Weight::from(4),
            Weight::from(5),
            Weight::from(6),
        ];

        let result = update_token_weights(&mut vault, weights.clone(), Timestamp::ZERO);
        result.unwrap();

        // Verify weights match (tokens are sorted alphabetically)
        for (token, weight) in izip!(vault.iter_enabled_tokens(), weights) {
            assert_eq!(token.weight, u64::from(weight));
        }
    }
}

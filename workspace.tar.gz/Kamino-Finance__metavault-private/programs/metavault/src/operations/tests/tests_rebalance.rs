#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use anchor_lang::prelude::Pubkey;

    use crate::types::{DollarValue, NetAum};
    use crate::{
        operations::effects::RebalanceFillEffects,
        operations::rebalance_basket::RebalanceBasket,
        operations::rebalance_operations::common::validate_swap_pair,
        operations::rebalance_operations::*,
        operations::tests::tests_utils::{
            fixtures::setup_vault_with_tokens, token_by_id, TokenConfig,
        },
        operations::vault_operations,
        state::quote_swap,
        types::{
            amounts::Weight, BasketToken, Duration, Ratio, RebalanceTargets, RoundingMethod,
            StartRebalanceAuthority, Timestamp, TokenAmount, TokenPrice, VaultTokenId,
        },
        utils::consts::{MAX_REBALANCE_COOLDOWN, MAX_REBALANCE_DURATION, MIN_REBALANCE_DURATION},
        utils::scope::VaultScopePrices,
        GlobalConfig, KaminoVaultError, MetavaultState, VaultConfigField,
    };
    use kamino_lending::{assert_fuzzy_eq, fraction::Fraction, utils::FULL_BPS};

    #[test]
    fn test_start_rebalance_basic() {
        // Create tokens with weights: USDC 50%, SOL 30%, ETH 20%
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(
                    2000,        // 20% weight
                    2000.0,      // $2000 price
                    500_000_000, // 0.5 ETH
                    9,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    3000,           // 30% weight
                    100.0,          // $100 price
                    10_000_000_000, // 10 SOL
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_000_000_000, // 1000 USDC
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000; // 1 share

        // Start rebalance with USDC as base token
        start_rebalance(
            &mut vault,
            Duration::from(7200), // 2 hours
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000), // timestamp
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();

        assert!(vault.rebalance.is_unfinished());
        assert_eq!(
            {
                let window = vault.rebalance.window().unwrap();
                window.end - window.start
            },
            Duration::from(7200)
        );

        // Check that target lamports are calculated correctly
        // The seed deposit adds 1000 lamports to ETH (first alphabetically), so:
        // Total AUM = 0.500001 ETH * $2000 + 10 SOL * $100 + 1000 USDC = $1000.002 + $1000 + $1000 = $3000.002
        // Tokens are sorted alphabetically: [0]=ETH, [1]=SOL, [2]=USDC

        let targets = targets_of(&vault, &scope_prices);

        // Token 0 (ETH) should be 20% of $3000.002 / $2000 (allow for small rounding error)
        assert_fuzzy_eq!(targets[0], 300_000_199, 1);

        // Token 1 (SOL) should be 30% of $3000.002 / $100
        assert_fuzzy_eq!(targets[1], 9_000_005_999u64, 1);

        // Token 2 (USDC) should be 50% of $3000.002 / $1
        assert_fuzzy_eq!(targets[2], 1_500_001_000u64, 1);
    }

    #[test]
    fn test_start_rebalance_already_active() {
        // Use 2 tokens whose balances are far from their targets, so the vault
        // stays in an active (non-settled) rebalance within the duration window.
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    3000,          // 30% weight
                    100.0,         // $100 price
                    5_000_000_000, // 5 SOL (needs 3 SOL for 30% of $1000 AUM)
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    7000,        // 70% weight
                    1.0,         // $1 price
                    500_000_000, // 500 USDC (needs 700 USDC for 70% of $1000 AUM)
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        // Simulate an active rebalance already in progress
        vault.rebalance.start_timestamp = 1_000_000;
        vault.rebalance.end_timestamp = 1_000_000 + 3_600;
        // Derived targets: 3 SOL (far from 5) and 700 USDC (far from 500), so it cannot finish.

        // Try to start another rebalance within the active window (100s in, window is 3600s)
        let result = start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_100),
            StartRebalanceAuthority::AllocationDelegate,
        );

        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::RebalanceInProgress)
        );
    }

    #[test]
    fn test_start_rebalance_invalid_duration() {
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
        )]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);

        // Test duration too short
        let result = start_rebalance(
            &mut vault,
            Duration::from(u64::from(MIN_REBALANCE_DURATION) - 1),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000), // timestamp
            StartRebalanceAuthority::AllocationDelegate,
        );
        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::InvalidRebalanceDuration)
        );

        // Test duration too long
        let result = start_rebalance(
            &mut vault,
            Duration::from(u64::from(MAX_REBALANCE_DURATION) + 1),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000), // timestamp
            StartRebalanceAuthority::AllocationDelegate,
        );
        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::InvalidRebalanceDuration)
        );
    }

    #[test]
    fn test_start_rebalance_rejected_when_all_but_one_token_settled() {
        // Set up tokens with specific amounts so that 2 tokens will be within tolerance
        // after calculating rebalance targets
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(
                    2000,        // 20% weight
                    2000.0,      // $2000 price
                    299_999_800, // seed deposit adds 1000 → effective 300_000_800 (0.3000008 ETH)
                    9,           // will be within 700 lamports of target
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    3000,          // 30% weight
                    100.0,         // $100 price
                    9_000_002_000, // 9.000002 SOL - will be within 1000 lamports of target
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_499_999_200, // 1499.9992 USDC - will be 1300 lamports from target (NOT within tolerance)
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        // After seed deposit, effective amounts:
        // ETH available = 299_999_800 + 1000 (seed) = 300_000_800
        // Total AUM = 0.3000008 ETH * $2000 + 9.000002 SOL * $100 + 1499.9992 USDC * $1
        //           = $600.0016 + $900.0002 + $1499.9992 = $3000.001
        //
        // Calculated targets:
        // ETH target (20% of $3000.001): $600.0002 = 0.3000001 ETH = 300_000_100 lamports
        // SOL target (30% of $3000.001): $900.0003 = 9.000003 SOL = 9_000_003_000 lamports
        // USDC target (50% of $3000.001): $1500.0005 = 1500.0005 USDC = 1_500_000_500 lamports

        let result = start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        );
        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::VaultAlreadyRebalanced)
        );

        // ETH: available=300_000_800, target=300_000_100, diff=700 (< 1000 tolerance) ✓
        // SOL: available=9_000_002_000, target=9_000_003_000, diff=1000 (= 1000 tolerance) ✓
        // USDC: available=1_499_999_200, target=1_500_000_500, diff=1300 (> 1000 tolerance) ✗
        // All tokens but one are within tolerance, so the vault reads as rebalanced.
        let targets = vault.tokens().targets(&scope_prices);
        let settled: Vec<bool> = vault
            .tokens()
            .into_iter()
            .map(|token| token.is_settled(targets.of(token.id)))
            .collect();
        assert_eq!(settled, vec![true, true, false]);
        assert!(is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_000)
        ));
    }

    #[test]
    fn test_is_rebalance_complete() {
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(2000, 2000.0, 500_000_000, 9),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(3000, 100.0, 10_000_000_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
            ),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        vault.rebalance.start_timestamp = 1_000_000;
        vault.rebalance.end_timestamp = 1_000_000 + 3_600;
        let now = Timestamp::from(1_000_100); // 100s into a 3600s window
        let available: Vec<u64> = vault
            .iter_enabled_tokens()
            .map(|token| token.token_available)
            .collect();

        // Not complete while one token is settled, one is in deficit and one in excess.
        let targets = targets_from([available[0], 12_000_000_000, 500_000_000]);
        assert!(!is_rebalance_over(&vault, &targets, now));

        // Over once only one token is unsettled: it has nothing to swap against
        let targets = targets_from([available[0], available[1], 500_000_000]);
        assert!(is_rebalance_over(&vault, &targets, now));

        // Complete if all tokens are settled
        let targets = targets_from([available[0], available[1], available[2]]);
        assert!(is_rebalance_over(&vault, &targets, now));

        // Trivially rebalanced when vault is not in an active rebalance session
        vault.rebalance.end_timestamp = 0;
        let targets = targets_from([available[0], 12_000_000_000, 500_000_000]);
        assert!(is_rebalance_over(&vault, &targets, now));
    }

    #[test]
    fn test_complete_rebalance_if_ready() {
        // 10 SOL ($1000) and 1000 USDC ($1000) at equal weights sit at their derived targets
        // (the 1000-lamport seed deposit on SOL shifts them by well under the tolerance).
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(5000, 100.0, 10_000_000_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.rebalance.start_timestamp = 1000;
        vault.rebalance.end_timestamp = 1000 + 3600;

        vault.finish_rebalance_if_over(&scope_prices, Timestamp::from(1100));

        assert!(!vault.rebalance.is_unfinished());
        assert_eq!(vault.rebalance.end_timestamp, 0);
    }

    #[test]
    fn test_weights_not_configured_for_all() {
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(0, 2000.0, 500_000_000, 9),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(0, 100.0, 10_000_000_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(0, 1.0, 1_000_000_000, 6),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);

        let result = start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        );

        // All tokens have 0 weight
        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::InvalidWeightsSum)
        );
    }

    #[test]
    fn test_start_rebalance_already_balanced() {
        // Test case where all tokens are already at their exact target weights
        // This should trigger VaultAlreadyRebalanced error
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(
                    2000,        // 20% weight
                    2000.0,      // $2000 price
                    300_000_000, // 0.3 ETH - exactly 20% of $3000 AUM
                    9,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    3000,          // 30% weight
                    100.0,         // $100 price
                    9_000_000_000, // 9 SOL - exactly 30% of $3000 AUM
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_500_000_000, // 1500 USDC - exactly 50% of $3000 AUM
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        let result = start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        );

        // Should error because all tokens are already at their target weights
        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::VaultAlreadyRebalanced)
        );
    }

    #[test]
    fn test_rebalance_single_token() {
        // Test rebalance with only one token in the vault
        // With a single token at 100% weight, it's always at target
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(
                10000,       // 100% weight
                1.0,         // $1 price
                800_000_000, // 800 USDC
                6,
            ),
        )]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        let result = start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        );

        // With single token at 100% weight, target equals current amount
        // So it's immediately rebalanced and fails
        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::VaultAlreadyRebalanced)
        );
    }

    #[test]
    fn test_rebalance_time_elapsed() {
        // Test that rebalance is considered complete when duration has elapsed
        // Use multiple tokens with different weights to create a real rebalance scenario
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    7000,        // 70% weight
                    1.0,         // $1 price
                    500_000_000, // 500 USDC (needs 700 USDC for 70% of $1000)
                    6,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    3000,          // 30% weight
                    100.0,         // $100 price
                    5_000_000_000, // 5 SOL (needs 3 SOL for 30% of $1000)
                    9,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        start_rebalance(
            &mut vault,
            Duration::from(3600), // 1 hour duration
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();

        // Tokens are not at target (SOL is off by 2 SOL = 200M lamports)
        let targets = vault.tokens().targets(&scope_prices);
        let sol_id = vault
            .get_vault_token_id_by_mint(&tokens["SOL"].mint)
            .unwrap();
        let usdc_id = vault
            .get_vault_token_id_by_mint(&tokens["USDC"].mint)
            .unwrap();
        assert!(!token_by_id(&vault, sol_id).is_settled(targets.of(sol_id)));
        assert!(!token_by_id(&vault, usdc_id).is_settled(targets.of(usdc_id)));
        assert!(!is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_000)
        ));

        // Check before time elapsed
        assert!(!is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_000 + 1800)
        )); // 30 minutes later

        // The window is the half-open `[start, start + duration)`: the last live second is
        // T+duration-1, and at exactly T+duration the rebalance is already over.
        assert!(!is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_000 + 3599)
        ));
        assert!(is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_000 + 3600)
        ));

        // Finish the rebalance
        vault.finish_rebalance_if_over(&scope_prices, Timestamp::from(1_000_000 + 3600));
        assert!(!vault.rebalance.is_unfinished());
    }

    #[test]
    fn test_rebalance_equal_weights_but_diff_decimals_and_prices() {
        // Test rebalance with all tokens having equal weights
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(
                    3333,        // 33.33% weight
                    2000.0,      // $2000 price
                    500_000_000, // 0.5 ETH
                    9,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    3333,           // 33.33% weight
                    100.0,          // $100 price
                    10_000_000_000, // 10 SOL
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    3334,          // 33.34% weight (to make 100%)
                    1.0,           // $1 price
                    1_000_000_000, // 1000 USDC
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();

        // Seed deposit adds 1000 lamports to ETH (first alphabetically), so:
        // Total AUM = $1000.002 + $1000 + $1000 = $3000.002
        // Each token should get approximately $1000 (33.33%)

        let targets = targets_of(&vault, &scope_prices);

        // ETH target: $3000.002 * (3333/10000) / $2000 lamports
        assert_fuzzy_eq!(targets[0], 499_950_333, 2);

        // SOL target: $3000.002 * (3333/10000) / $100 lamports
        assert_fuzzy_eq!(targets[1], 9_999_006_665u64, 2);

        // USDC target: $3000.002 * (3334/10000) / $1 lamports
        assert_fuzzy_eq!(targets[2], 1_000_200_666u64, 2);
    }

    #[test]
    fn test_stop_rebalance_success() {
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
        )]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);

        // Start a rebalance
        vault.rebalance.start_timestamp = 1000;
        vault.rebalance.end_timestamp = 1000 + 3600;

        // Stop the rebalance
        let result = stop_rebalance(&mut vault);
        assert!(result.is_ok());

        // Check that rebalance is stopped
        assert!(!vault.rebalance.is_unfinished());
        assert_eq!(vault.rebalance.end_timestamp, 0);
    }

    #[test]
    fn test_stop_rebalance_ends_an_expired_rebalance_too() {
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
        )]);
        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        vault.rebalance.start_timestamp = 1000;
        vault.rebalance.end_timestamp = 1000 + 3600;

        // The clock is past the end but nothing closed it yet: stop still ends it.
        stop_rebalance(&mut vault).unwrap();
        assert!(!vault.rebalance.is_unfinished());
    }

    #[test]
    fn test_stop_rebalance_not_active() {
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
        )]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);

        // Rebalance is not active

        // Should fail
        let result = stop_rebalance(&mut vault);
        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::RebalanceNotInProgress.into()
        );
    }

    #[test]
    fn test_vault_finish_rebalance_if_not_completed() {
        // 1000 USDC ($1000) vs 3000 SOL ($3000 at $1) at equal weights: USDC is in deficit and
        // SOL in excess, so the rebalance can still make progress.
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 3_000_000_000, 6),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);

        // Start a rebalance
        vault.rebalance.start_timestamp = 1000;
        vault.rebalance.end_timestamp = 1000 + 3600;

        // Call finish_rebalance_if_over when NOT over
        vault.finish_rebalance_if_over(&scope_prices, Timestamp::from(2000)); // Only 1000 seconds passed

        // Verify rebalance was NOT finished
        assert!(vault.rebalance.is_unfinished());
        assert_eq!(vault.rebalance.start_timestamp, 1000);
        assert_eq!(vault.rebalance.end_timestamp, 1000 + 3600);
    }

    #[test]
    fn test_token_settled_deficit_and_excess_against_a_target() {
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
        )]);

        let (vault, _) = setup_vault_with_tokens(&tokens);
        let token = token_by_id(
            &vault,
            VaultTokenId {
                storage_index: 0,
                input_account_index: 0,
            },
        );
        let available = token.available;

        // Far below the target: unsettled, in deficit, no excess
        let target = available + TokenAmount::from(1_000_000_000);
        assert!(!token.is_settled(target));
        assert_eq!(token.deficit(target), TokenAmount::from(1_000_000_000));
        assert_eq!(token.excess(target), TokenAmount::ZERO);

        // Within tolerance on either side: settled, and both sides still report the residue
        for target in [
            available - TokenAmount::from(1_000),
            available + TokenAmount::from(1_000),
        ] {
            assert!(token.is_settled(target));
        }
        assert!(!token.is_settled(available + TokenAmount::from(1_001)));

        // Above the target: unsettled, in excess, no deficit
        let target = available - TokenAmount::from(600_000_000);
        assert!(!token.is_settled(target));
        assert_eq!(token.deficit(target), TokenAmount::ZERO);
        assert_eq!(token.excess(target), TokenAmount::from(600_000_000));
    }

    #[test]
    fn test_vault_finish_rebalance_clears_all_state() {
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(3000, 1.0, 1_000_000_000, 6),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(7000, 100.0, 10_000_000_000, 9),
            ),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);

        // Set up active rebalance state
        vault.rebalance.start_timestamp = 12345;
        vault.rebalance.end_timestamp = 12345 + 7200;

        // Finish it directly
        vault.rebalance.finish();

        // Verify ALL state is cleared
        assert!(!vault.rebalance.is_unfinished());
        assert_eq!(vault.rebalance.end_timestamp, 0);
    }

    #[test]
    fn test_auction_quote_swap_basic() {
        // Test basic swap: 100 USDC -> SOL at 1 USDC = $1, 1 SOL = $100
        let usdc_price = TokenPrice::new(Fraction::from(1u64), 6);
        let sol_price = TokenPrice::new(Fraction::from(100u64), 9);
        let amount_in = 100_000_000; // 100 USDC (6 decimals)

        let amount_out = quote_swap(TokenAmount::from(amount_in), &usdc_price, &sol_price).unwrap();
        let amount_out = u64::from(amount_out);

        // Should get 1 SOL (9 decimals) for 100 USDC
        assert_eq!(amount_out, 1_000_000_000);
    }

    #[test]
    fn test_auction_quote_swap_basic_reverse() {
        // Test basic swap: 1 SOL -> 100 USDC at 1 USDC = $1, 1 SOL = $100
        let usdc_price = TokenPrice::new(Fraction::from(1u64), 6);
        let sol_price = TokenPrice::new(Fraction::from(100u64), 9);
        let amount_in = 1_000_000_000; // 1 SOL

        let amount_out = quote_swap(TokenAmount::from(amount_in), &sol_price, &usdc_price).unwrap();
        let amount_out = u64::from(amount_out);

        // Should get 100 USDC (6 decimals)
        assert_eq!(amount_out, 100_000_000);
    }

    #[test]
    fn test_auction_quote_swap_same_decimals() {
        // Test basic swap: 100 USDC -> USDT at 1 USDC = $1, 1 USDT = $1
        let usdc_price = TokenPrice::new(Fraction::from(1u64), 6);
        let usdt_price = TokenPrice::new(Fraction::from(1u64), 6);
        let amount_in = 100_000_000; // 100 USDC (6 decimals)

        let amount_out =
            quote_swap(TokenAmount::from(amount_in), &usdc_price, &usdt_price).unwrap();
        let amount_out = u64::from(amount_out);

        // Should get 100 USDT (6 decimals) for 100 USDC
        assert_eq!(amount_out, 100_000_000);
    }

    #[test]
    fn test_auction_quote_swap_fractional_prices() {
        // Test with fractional prices: ETH=$2500.50, USDC=$0.999
        let usdc_price = TokenPrice::new(Fraction::from_num(0.999f64), 6);
        let eth_price = TokenPrice::new(Fraction::from_num(2500.5f64), 18);

        let amount_in = 2_500_500_000; // 2500.5 USDC

        let amount_out = quote_swap(TokenAmount::from(amount_in), &usdc_price, &eth_price).unwrap();
        let amount_out = u64::from(amount_out);

        // Should get approximately 1 ETH (18 decimals)
        // 2500.5 USDC * $0.999 = $2497.99995
        // $2497.99995 / $2500.50 ≈ 0.999 ETH
        assert_fuzzy_eq!(amount_out, 999_000_000_000_000_000u64, 1);
    }

    #[test]
    fn test_validate_swap_pair_success() {
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_000_000_000, // 1000 USDC - below target
                    6,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,           // 50% weight
                    100.0,          // $100 price
                    15_000_000_000, // 15 SOL - above target
                    9,
                ),
            ),
        ]);

        let (vault, _) = setup_vault_with_tokens(&tokens);

        // Targets: vault needs more USDC and has excess SOL
        // Note: tokens are sorted alphabetically, so SOL is index 0, USDC is index 1
        let targets = targets_from([
            10_000_000_000, // SOL has excess
            1_500_000_000,  // USDC needs 500 more
        ]);

        // Should succeed: user providing USDC (vault needs more), getting SOL (vault has excess)
        let result = validate_swap_pair(
            basket_token(&vault, 1), // USDC (token in)
            basket_token(&vault, 0), // SOL (token out)
            &targets,
        );
        assert!(result.is_ok());
    }

    #[test]
    fn test_validate_swap_pair_rejects_reversed_pair() {
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_000_000_000, // 1000 USDC - below target
                    6,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,           // 50% weight
                    100.0,          // $100 price
                    15_000_000_000, // 15 SOL - above target
                    9,
                ),
            ),
        ]);

        let (vault, _) = setup_vault_with_tokens(&tokens);

        // Note: tokens are sorted alphabetically, so SOL is index 0, USDC is index 1
        let targets = targets_from([
            10_000_000_000, // SOL has excess
            1_500_000_000,  // USDC needs more
        ]);

        // Should fail: user trying wrong direction (providing SOL when vault has excess, wanting USDC when vault needs more)
        let result = validate_swap_pair(
            basket_token(&vault, 0), // SOL (token in) - WRONG, vault has excess
            basket_token(&vault, 1), // USDC (token out) - WRONG, vault needs more
            &targets,
        );

        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::InvalidSwapPair)
        );
    }

    #[test]
    fn test_validate_swap_pair_token_already_settled() {
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_500_000_000, // 1500 USDC - exactly at target
                    6,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,           // 50% weight
                    100.0,          // $100 price
                    10_000_000_000, // 10 SOL - exactly at target
                    9,
                ),
            ),
        ]);

        let (vault, _) = setup_vault_with_tokens(&tokens);

        // Both tokens sit exactly at their targets (settled)
        // Note: tokens are sorted alphabetically, so SOL is index 0, USDC is index 1
        let targets = targets_from([10_000_000_000, 1_500_000_000]);

        // Should fail: a settled token is not in deficit, so it cannot be the `token_in` side
        let result = validate_swap_pair(
            basket_token(&vault, 0), // SOL (token in) - settled
            basket_token(&vault, 1), // SOL (token out)
            &targets,
        );

        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::InvalidSwapPair)
        );
    }

    #[test]
    fn test_validate_swap_pair_both_tokens_need_more() {
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,        // 50% weight
                    1.0,         // $1 price
                    500_000_000, // 500 USDC - below target
                    6,
                ),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    100.0,         // $100 price
                    5_000_000_000, // 5 SOL - also below target
                    9,
                ),
            ),
        ]);

        let (vault, _) = setup_vault_with_tokens(&tokens);

        // Both tokens are below target
        // Note: tokens are sorted alphabetically, so SOL is index 0, USDC is index 1
        let targets = targets_from([
            10_000_000_000, // needs more SOL
            1_000_000_000,  // needs more USDC too
        ]);

        // Should fail: both tokens are below target (no excess to swap)
        let result = validate_swap_pair(
            basket_token(&vault, 0), // SOL (token in) - needs more
            basket_token(&vault, 1), // SOL (token out) - also needs more!
            &targets,
        );

        assert_eq!(
            result.unwrap_err(),
            anchor_lang::error::Error::from(KaminoVaultError::InvalidSwapPair)
        );
    }

    #[test]
    fn test_a_settled_token_reopens_when_a_deposit_elsewhere_moves_its_target() {
        // Targets are derived from the current balances and prices, so there is nothing to
        // latch: a token within tolerance of its target is settled only for as long as that
        // holds. 2 ETH ($4000) is overweight, 5 SOL ($500) underweight, and USDC is exactly
        // its 50% of the AUM (the 1000-lamport seed deposit on ETH adds $0.002, hence 4500.001).
        let tokens = HashMap::from([
            (
                "ETH",
                TokenConfig::with_weight_price_available_decimals(2000, 2000.0, 2_000_000_000, 9),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(3000, 100.0, 5_000_000_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 4_500_001_000, 6),
            ),
        ]);
        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;
        let usdc_id = vault
            .get_vault_token_id_by_mint(&tokens["USDC"].mint)
            .unwrap();
        let sol_id = vault
            .get_vault_token_id_by_mint(&tokens["SOL"].mint)
            .unwrap();

        // USDC sits on its target: settled.
        let targets = vault.tokens().targets(&scope_prices);
        assert!(token_by_id(&vault, usdc_id).is_settled(targets.of(usdc_id)));

        // A one-sided 10 SOL ($1000) deposit raises the free AUM, so USDC's target moves while
        // its balance does not: it is in deficit again.
        vault.get_vault_token_mut_by_id(sol_id).token_available += 10_000_000_000;
        let targets = vault.tokens().targets(&scope_prices);
        assert!(!token_by_id(&vault, usdc_id).is_settled(targets.of(usdc_id)));
        assert!(token_by_id(&vault, usdc_id).deficit(targets.of(usdc_id)) > TokenAmount::ZERO);

        // A sub-tolerance change leaves it settled: 10_000 SOL lamports ($0.001) move USDC's
        // target by ~500 lamports.
        vault.get_vault_token_mut_by_id(sol_id).token_available -= 10_000_000_000;
        vault.get_vault_token_mut_by_id(sol_id).token_available += 10_000;
        let targets = vault.tokens().targets(&scope_prices);
        assert!(token_by_id(&vault, usdc_id).is_settled(targets.of(usdc_id)));
    }

    /// Reproduces a stuck state observed on mainnet: one token is settled
    /// (within tolerance) while the other two sit in small excess above
    /// target. No unsettled deficit token exists so no swap can make
    /// progress — vault should be considered rebalanced.
    #[test]
    fn test_is_rebalance_over_stuck_no_deficit_token() {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(3333, 150.0, 8_772_968, 9),
            ),
            (
                "JITOSOL",
                TokenConfig::with_weight_price_available_decimals(3333, 175.0, 6_913_861, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(3334, 1.0, 6_321_960, 6),
            ),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        vault.rebalance.start_timestamp = 1_000_000;
        vault.rebalance.end_timestamp = 1_000_000 + 1_800;

        // JITOSOL (idx 0, sorted): excess by 4158 (> 1000 tolerance)
        // SOL (idx 1, sorted): excess by 5260 (> 1000 tolerance)
        // USDC (idx 2, sorted): deficit by 606 (< 1000 tolerance), settled
        let targets = targets_from([6_909_703, 8_767_708, 6_322_566]);
        let settled: Vec<bool> = vault
            .tokens()
            .into_iter()
            .map(|token| token.is_settled(targets.of(token.id)))
            .collect();
        assert_eq!(settled, vec![false, false, true]);

        // Two tokens are unsettled, but no unsettled deficit token exists, so no swap can
        // make progress.
        assert!(is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_429)
        ));
    }

    /// Mirror of the no-deficit test: one token is settled while the other
    /// two sit in small deficit below target. No unsettled excess token
    /// exists, so the vault should be considered rebalanced.
    #[test]
    fn test_is_rebalance_over_stuck_no_excess_token() {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(3333, 150.0, 8_760_000, 9),
            ),
            (
                "JITOSOL",
                TokenConfig::with_weight_price_available_decimals(3333, 175.0, 6_905_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(3334, 1.0, 6_325_000, 6),
            ),
        ]);

        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        vault.rebalance.start_timestamp = 1_000_000;
        vault.rebalance.end_timestamp = 1_000_000 + 1_800;

        // JITOSOL (idx 0, sorted): deficit by 4703 (> 1000 tolerance)
        // SOL (idx 1, sorted): deficit by 7708 (> 1000 tolerance)
        // USDC (idx 2, sorted): excess by 434 (< 1000 tolerance), settled
        let targets = targets_from([6_909_703, 8_767_708, 6_324_566]);
        let settled: Vec<bool> = vault
            .tokens()
            .into_iter()
            .map(|token| token.is_settled(targets.of(token.id)))
            .collect();
        assert_eq!(settled, vec![false, false, true]);

        // Two tokens are unsettled, but no unsettled excess token exists, so no swap can
        // make progress.
        assert!(is_rebalance_over(
            &vault,
            &targets,
            Timestamp::from(1_000_429)
        ));
    }

    #[test]
    fn test_update_weights_during_rebalance_rejected() {
        // Amounts don't match 50/50 distribution so rebalance is needed
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    100.0,         // $100 price
                    7_000_000_000, // 7 SOL = $700
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,        // 50% weight
                    1.0,         // $1 price
                    300_000_000, // 300 USDC = $300
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        start_rebalance(
            &mut vault,
            Duration::from(3600),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
        assert!(vault.rebalance.is_unfinished());

        // Updating weights during active rebalance should fail
        let result = vault_operations::update_token_weights(
            &mut vault,
            vec![Weight::from(8000), Weight::from(2000)],
            Timestamp::from(1_000_100), // inside the window opened above
        );

        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::CannotUpdateWeightsDuringRebalance.into()
        );

        // Weights should remain unchanged
        assert_eq!(vault.vault_tokens[0].weight, 5000);
        assert_eq!(vault.vault_tokens[1].weight, 5000);
    }

    #[test]
    fn test_update_weights_during_idle_no_effect_on_rebalance() {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    100.0,         // $100 price
                    5_000_000_000, // 5 SOL
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,        // 50% weight
                    1.0,         // $1 price
                    500_000_000, // 500 USDC
                    6,
                ),
            ),
        ]);

        let (mut vault, ..) = setup_vault_with_tokens(&tokens);

        // No rebalance active, update weights
        vault_operations::update_token_weights(
            &mut vault,
            vec![Weight::from(8000), Weight::from(2000)],
            Timestamp::ZERO,
        )
        .unwrap();

        // Weights are updated
        assert_eq!(vault.vault_tokens[0].weight, 8000);
        assert_eq!(vault.vault_tokens[1].weight, 2000);

        // Rebalance state should remain idle
        assert!(!vault.rebalance.is_unfinished());
    }

    #[test]
    fn test_update_weights_rejected_even_when_targets_match_current() {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    100.0,         // $100 price
                    5_000_000_000, // 5 SOL = $500
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,          // 50% weight
                    1.0,           // $1 price
                    1_500_000_000, // 1500 USDC = $1500
                    6,
                ),
            ),
        ]);

        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        // Total AUM = $2000. Start rebalance with equal weights.
        start_rebalance(
            &mut vault,
            Duration::from(3600),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
        assert!(vault.rebalance.is_unfinished());

        // Even weights that would match current distribution are rejected
        let result = vault_operations::update_token_weights(
            &mut vault,
            vec![Weight::from(2500), Weight::from(7500)],
            Timestamp::from(1_000_100), // inside the window opened above
        );

        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::CannotUpdateWeightsDuringRebalance.into()
        );
    }

    #[test]
    fn test_rebalance_swap_direction_follows_current_prices() {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,
                    100.0,
                    15_000_000_000, // 15 SOL = $1500, initially overweight
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,
                    1.0,
                    500_000_000, // 500 USDC = $500, initially underweight
                    6,
                ),
            ),
        ]);
        let (mut vault, mut scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        let start_timestamp = 1_000_000;
        start_rebalance(
            &mut vault,
            Duration::from(7_200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(start_timestamp),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();

        let sol_mint = tokens["SOL"].mint;
        let usdc_mint = tokens["USDC"].mint;
        let sol_id = vault.get_vault_token_id_by_mint(&sol_mint).unwrap();
        let usdc_id = vault.get_vault_token_id_by_mint(&usdc_mint).unwrap();

        // At the start prices the vault should receive USDC and send SOL.
        let targets = vault.tokens().targets(&scope_prices);
        assert!(vault.get_vault_token_by_id(usdc_id).available() < targets.of(usdc_id));
        assert!(vault.get_vault_token_by_id(sol_id).available() > targets.of(sol_id));

        // SOL falls from $100 to $10. At current values SOL is now underweight and USDC is
        // overweight, so the old USDC -> SOL direction is harmful.
        scope_prices.prices[sol_id.input_account_index] =
            TokenPrice::new(Fraction::from_num(10), 9);

        let result = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: usdc_mint,
                token_out_mint: sol_mint,
                amount_in: TokenAmount::from(10_000_000),
                requested_out_amount: // 10 USDC
            TokenAmount::ZERO,
                now: Timestamp::from(start_timestamp + 1),
            },
        );

        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::InvalidSwapPair.into()
        );
        let targets = vault.tokens().targets(&scope_prices);
        assert!(vault.get_vault_token_by_id(sol_id).available() < targets.of(sol_id));
        assert!(vault.get_vault_token_by_id(usdc_id).available() > targets.of(usdc_id));
    }

    /// P2-21 coverage: `calculate_rebalance_swap` rejects dust amounts with
    /// `RebalanceSwapAmountBelowMinimum`.
    #[test]
    fn test_rebalance_swap_rejects_dust_amount_in() {
        let tokens = HashMap::from([
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
            ),
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(5000, 100.0, 15_000_000_000, 9),
            ),
        ]);
        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;

        start_rebalance(
            &mut vault,
            Duration::from(7200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();

        // Dust amount below MIN_REBALANCE_SWAP_AMOUNT_LAMPORTS = 1000
        let token_in = vault.vault_tokens[1].mint; // USDC
        let token_out = vault.vault_tokens[0].mint; // SOL
        let result = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: token_in,
                token_out_mint: token_out,
                amount_in: TokenAmount::from(50),
                requested_out_amount: TokenAmount::from(0),
                now: Timestamp::from(1_000_001),
            },
        );

        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::RebalanceSwapAmountBelowMinimum.into()
        );
    }

    #[test]
    fn test_swap_authority_unset_allows_any_signer() {
        let vault = MetavaultState::default();
        assert!(vault.validate_swap_authority(Pubkey::new_unique()).is_ok());
    }

    #[test]
    fn test_swap_authority_allows_configured_signer() {
        let authority = Pubkey::new_unique();
        let vault = MetavaultState {
            swap_authority: authority,
            ..MetavaultState::default()
        };

        assert!(vault.validate_swap_authority(authority).is_ok());
    }

    #[test]
    fn test_swap_authority_rejects_other_signer() {
        let vault = MetavaultState {
            swap_authority: Pubkey::new_unique(),
            ..MetavaultState::default()
        };

        let result = vault.validate_swap_authority(Pubkey::new_unique());

        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::SwapAuthorityIncorrect.into()
        );
    }

    #[test]
    fn test_update_swap_authority_config_round_trips_and_clears() {
        let authority = Pubkey::new_unique();
        let mut vault = MetavaultState::default();

        vault
            .update_config(
                VaultConfigField::SwapAuthority,
                &authority.to_bytes(),
                Timestamp::ZERO,
            )
            .unwrap();
        assert_eq!(vault.swap_authority, authority);

        vault
            .update_config(
                VaultConfigField::SwapAuthority,
                &Pubkey::default().to_bytes(),
                Timestamp::ZERO,
            )
            .unwrap();
        assert_eq!(vault.swap_authority, Pubkey::default());
    }

    #[test]
    fn rebalance_cooldown_config_roundtrip_and_bound() {
        let mut vault = MetavaultState::default();

        vault
            .update_config(
                VaultConfigField::RebalanceCooldownSeconds,
                &3_600u64.to_le_bytes(),
                Timestamp::ZERO,
            )
            .unwrap();
        assert_eq!(vault.rebalance_cooldown_seconds, 3_600);

        let too_long = u64::from(MAX_REBALANCE_COOLDOWN) + 1;
        let err = vault
            .update_config(
                VaultConfigField::RebalanceCooldownSeconds,
                &too_long.to_le_bytes(),
                Timestamp::ZERO,
            )
            .unwrap_err();
        assert_eq!(
            err,
            anchor_lang::error::Error::from(KaminoVaultError::RebalanceCooldownTooLong)
        );
        assert_eq!(vault.rebalance_cooldown_seconds, 3_600);
    }

    /// Two-token fixture that is NOT settled (weights differ from balances), so start_rebalance
    /// stays active and stop-then-restart is meaningful.
    fn unsettled_vault() -> (MetavaultState, crate::utils::scope::VaultScopePrices) {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,
                    100.0,
                    5_000_000_000, // 5 SOL = $500 (needs 10 SOL for 50% of $2000)
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,
                    1.0,
                    1_500_000_000, // 1500 USDC = $1500 (needs 1000 USDC for 50% of $2000)
                    6,
                ),
            ),
        ]);
        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;
        (vault, scope_prices)
    }

    #[test]
    fn cooldown_blocks_allocation_restart_within_window() {
        let (mut vault, scope_prices) = unsettled_vault();
        vault.rebalance_cooldown_seconds = 3_600;
        let t0 = Timestamp::from(1_000_000);

        start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            t0,
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
        stop_rebalance(&mut vault).unwrap();

        // 10 minutes later: allocation key blocked, admin bypass allowed.
        let t1 = Timestamp::from(1_000_600);
        let err = start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            t1,
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap_err();
        assert_eq!(
            err,
            anchor_lang::error::Error::from(KaminoVaultError::RebalanceCooldownNotElapsed)
        );
        start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            t1,
            StartRebalanceAuthority::VaultAdmin,
        )
        .unwrap();
    }

    #[test]
    fn cooldown_allows_restart_after_window_and_zero_disables() {
        let (mut vault, scope_prices) = unsettled_vault();
        vault.rebalance_cooldown_seconds = 3_600;
        let t0 = Timestamp::from(1_000_000);

        start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            t0,
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
        stop_rebalance(&mut vault).unwrap();

        // Exactly one cooldown after the last start: allowed (>= semantics).
        let t1 = Timestamp::from(1_003_600);
        start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            t1,
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
        stop_rebalance(&mut vault).unwrap();

        // Zero cooldown: immediate restart allowed.
        vault.rebalance_cooldown_seconds = 0;
        start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_003_601),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
    }

    #[test]
    fn cooldown_never_blocks_first_start() {
        let (mut vault, scope_prices) = unsettled_vault();
        vault.rebalance_cooldown_seconds = u64::from(MAX_REBALANCE_COOLDOWN);
        // A never-started vault has `rebalance.start_timestamp == 0`, and the explicit
        // zero-anchor guard skips the cooldown check entirely.
        start_rebalance(
            &mut vault,
            MIN_REBALANCE_DURATION,
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
    }

    #[test]
    fn test_rebalance_swap_pays_exactly_the_requested_amount_below_the_curve() {
        let (mut vault, scope_prices, usdc_mint, sol_mint, start_timestamp) =
            setup_active_sol_usdc_rebalance();
        let now = Timestamp::from(start_timestamp + 1);
        let amount_in = TokenAmount::from(100_000_000); // 100 USDC

        let curve = quote_rebalance_swap(
            &vault.tokens(),
            &vault.rebalance,
            &scope_prices,
            &usdc_mint,
            &sol_mint,
            amount_in,
            now,
        )
        .unwrap();
        let ask = curve.max_out_from_curve - TokenAmount::from(1_000_000); // 0.001 SOL below the curve

        let sol_before = vault
            .get_vault_token_by_mint(&sol_mint)
            .unwrap()
            .available();
        let usdc_before = vault
            .get_vault_token_by_mint(&usdc_mint)
            .unwrap()
            .available();
        let aum_before = vault.compute_free_aum(&scope_prices, RoundingMethod::Floor);

        let effects = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: usdc_mint,
                token_out_mint: sol_mint,
                amount_in,
                requested_out_amount: ask,
                now,
            },
        )
        .unwrap();

        assert_eq!(effects.amount_in, amount_in);
        assert_eq!(
            vault
                .get_vault_token_by_mint(&sol_mint)
                .unwrap()
                .available(),
            sol_before - ask
        );
        assert_eq!(
            vault
                .get_vault_token_by_mint(&usdc_mint)
                .unwrap()
                .available(),
            usdc_before + amount_in
        );
        // The vault keeps the surplus between the curve and the ask.
        let aum_after = vault.compute_free_aum(&scope_prices, RoundingMethod::Floor);
        assert!(aum_after > aum_before);
    }

    #[test]
    fn test_rebalance_swap_rejects_a_request_above_the_curve() {
        let (mut vault, scope_prices, usdc_mint, sol_mint, start_timestamp) =
            setup_active_sol_usdc_rebalance();
        let now = Timestamp::from(start_timestamp + 1);
        let amount_in = TokenAmount::from(100_000_000); // 100 USDC

        let curve = quote_rebalance_swap(
            &vault.tokens(),
            &vault.rebalance,
            &scope_prices,
            &usdc_mint,
            &sol_mint,
            amount_in,
            now,
        )
        .unwrap();
        let sol_before = vault
            .get_vault_token_by_mint(&sol_mint)
            .unwrap()
            .available();
        let usdc_before = vault
            .get_vault_token_by_mint(&usdc_mint)
            .unwrap()
            .available();

        let result = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: usdc_mint,
                token_out_mint: sol_mint,
                amount_in,
                requested_out_amount: curve.max_out_from_curve + TokenAmount::from(1),
                now,
            },
        );

        assert_eq!(
            result.unwrap_err(),
            KaminoVaultError::SlippageExceeded.into()
        );
        assert_eq!(
            vault
                .get_vault_token_by_mint(&sol_mint)
                .unwrap()
                .available(),
            sol_before
        );
        assert_eq!(
            vault
                .get_vault_token_by_mint(&usdc_mint)
                .unwrap()
                .available(),
            usdc_before
        );
    }

    #[test]
    fn test_rebalance_swap_request_within_max_loss_passes_where_the_curve_would_not() {
        let (mut vault, scope_prices, usdc_mint, sol_mint, start_timestamp) =
            setup_active_sol_usdc_rebalance();
        // The vault tolerates no loss (default cap of 0 bps), and at auction end its curve
        // over-credits USDC by 20% while under-pricing SOL by 20%.
        vault.vault_tokens[1]
            .dutch_auction_scales
            .end_scale_bps_when_buying = 12_000;
        vault.vault_tokens[0]
            .dutch_auction_scales
            .end_scale_bps_when_selling = 8_000;
        // The last second inside the half-open window, where the curve sits on its end scales.
        let at_end = Timestamp::from(start_timestamp + 7_200 - 1);
        let amount_in = TokenAmount::from(100_000_000); // 100 USDC
        let fair = TokenAmount::from(1_000_000_000); // 1 SOL at oracle prices

        let curve = quote_rebalance_swap(
            &vault.tokens(),
            &vault.rebalance,
            &scope_prices,
            &usdc_mint,
            &sol_mint,
            amount_in,
            at_end,
        )
        .unwrap();
        assert!(curve.max_out_from_curve > fair);

        // The loss bound is checked after the balances move, so a rejected fill leaves the
        // in-memory vault dirty (on-chain the transaction reverts); attempt it on a copy.
        let mut rejected = vault;
        let at_curve = calculate_rebalance_swap(
            &mut rejected,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: usdc_mint,
                token_out_mint: sol_mint,
                amount_in,
                requested_out_amount: curve.max_out_from_curve,
                now: at_end,
            },
        );
        assert_eq!(
            at_curve.unwrap_err(),
            KaminoVaultError::RebalanceSwapExceedsMaxLoss.into()
        );

        let sol_before = vault
            .get_vault_token_by_mint(&sol_mint)
            .unwrap()
            .available();

        let effects = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: usdc_mint,
                token_out_mint: sol_mint,
                amount_in,
                requested_out_amount: fair,
                now: at_end,
            },
        )
        .unwrap();
        assert_eq!(effects.amount_in, amount_in);
        assert_eq!(
            vault
                .get_vault_token_by_mint(&sol_mint)
                .unwrap()
                .available(),
            sol_before - fair
        );
    }

    #[test]
    fn test_rebalance_max_loss_bounds_the_sum_of_per_swap_losses() {
        // $2000 of AUM, so the rebalance may lose at most ~$20 in total.
        let (vault, scope_prices, usdc_mint, sol_mint, start_timestamp) =
            setup_active_sol_usdc_rebalance_with_max_loss(100);

        let (fills, rejection, _) = fill_until_rejected(
            vault,
            &scope_prices,
            &usdc_mint,
            &sol_mint,
            start_timestamp,
            MidRebalanceFlow::None,
        );

        assert_eq!(
            rejection,
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        // Several fills cleared the per-fill limit before the loss ceiling bound.
        assert!(fills >= 2, "expected several fills to pass, got {fills}");
    }

    #[test]
    fn test_rebalance_loss_ceiling_is_not_raised_by_a_mid_rebalance_deposit() {
        // A deposit doubling the vault right after the start buys none of the doubled ceiling.
        let baseline = setup_active_sol_usdc_rebalance_with_max_loss(100);
        let (fills_without_deposit, _, loss_without_deposit) = fill_until_rejected(
            baseline.0,
            &baseline.1,
            &baseline.2,
            &baseline.3,
            baseline.4,
            MidRebalanceFlow::None,
        );

        let inflated = setup_active_sol_usdc_rebalance_with_max_loss(100);
        let ceiling_at_start = inflated.0.rebalance.ceiling_at_start();
        let (fills_with_deposit, rejection, loss_with_deposit) = fill_until_rejected(
            inflated.0,
            &inflated.1,
            &inflated.2,
            &inflated.3,
            inflated.4,
            // +20 SOL = +$2000, doubling the $2000 the rebalance opened against
            MidRebalanceFlow::DepositSol(20_000_000_000),
        );

        assert_eq!(
            rejection,
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        // Capped at the start ceiling (the current value alone would allow ~$40 here):
        assert!(
            loss_with_deposit <= ceiling_at_start,
            "a mid-rebalance deposit must not lift the ceiling above the start ceiling: lost \
             {loss_with_deposit:?} against a {ceiling_at_start:?} ceiling"
        );
        // ... but it may win back what the vault's own losses took off the current ceiling:
        assert!(
            fills_with_deposit >= fills_without_deposit
                && loss_with_deposit >= loss_without_deposit,
            "an inflow relieves the current ceiling, it does not tighten it"
        );
        // 100 bps of the ~$2000 the vault held when the rebalance opened.
        assert!(
            ceiling_at_start > DollarValue::from(Fraction::from(19_u64))
                && ceiling_at_start < DollarValue::from(Fraction::from(21_u64)),
            "loss ceiling should be ~$20, got {ceiling_at_start:?}"
        );
    }

    #[test]
    fn test_rebalance_loss_ceiling_is_lowered_by_a_mid_rebalance_withdrawal() {
        // A withdrawal right after the start re-sizes the ceiling to the smaller vault.
        let baseline = setup_active_sol_usdc_rebalance_with_max_loss(100);
        let (fills_without_withdrawal, _, loss_without_withdrawal) = fill_until_rejected(
            baseline.0,
            &baseline.1,
            &baseline.2,
            &baseline.3,
            baseline.4,
            MidRebalanceFlow::None,
        );

        let shrunk = setup_active_sol_usdc_rebalance_with_max_loss(100);
        let ceiling_at_start = shrunk.0.rebalance.ceiling_at_start();
        let (fills_after_withdrawal, rejection, loss_after_withdrawal) = fill_until_rejected(
            shrunk.0,
            &shrunk.1,
            &shrunk.2,
            &shrunk.3,
            shrunk.4,
            // -400 USDC, a fifth of the $2000 the rebalance opened against
            MidRebalanceFlow::WithdrawUsdc(400_000_000),
        );

        assert_eq!(
            rejection,
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        assert!(
            fills_after_withdrawal < fills_without_withdrawal,
            "a fifth of the vault leaving must cost the rebalance fills, got {fills_after_withdrawal} \
             against {fills_without_withdrawal}"
        );
        // 100 bps of the ~$1600 left, not of the $2000 at the start (125 bps of what is left):
        assert!(
            loss_after_withdrawal < loss_without_withdrawal
                && loss_after_withdrawal < DollarValue::from(Fraction::from(16_u64)),
            "expected the ceiling to re-size to the ~$1600 that remains, lost \
             {loss_after_withdrawal:?} against a {ceiling_at_start:?} start ceiling"
        );
    }

    // A user flow right after the start (never toward the targets, so it cannot end the run).
    #[derive(Clone, Copy)]
    enum MidRebalanceFlow {
        None,
        DepositSol(u64),   // into the overweight leg
        WithdrawUsdc(u64), // out of the underweight leg
    }

    // Losing fills (after `flow`) until one is refused: the fills made, the refusal, the loss.
    fn fill_until_rejected(
        mut vault: MetavaultState,
        scope_prices: &VaultScopePrices,
        usdc_mint: &Pubkey,
        sol_mint: &Pubkey,
        start_timestamp: u64,
        flow: MidRebalanceFlow,
    ) -> (u32, anchor_lang::error::Error, DollarValue) {
        // A curve losing on every fill (each loss within the per-fill limit):
        vault.vault_tokens[1]
            .dutch_auction_scales
            .end_scale_bps_when_buying = 12_000;
        vault.vault_tokens[0]
            .dutch_auction_scales
            .end_scale_bps_when_selling = 8_000;
        vault.rebalance.limits.max_fill_slippage_bps = 6_000; // the running rebalance's own limit
        match flow {
            MidRebalanceFlow::None => {}
            MidRebalanceFlow::DepositSol(lamports) => {
                vault.vault_tokens[0].deposit_tokens(TokenAmount::from(lamports));
            }
            MidRebalanceFlow::WithdrawUsdc(lamports) => {
                vault.vault_tokens[1].withdraw_tokens(TokenAmount::from(lamports));
            }
        }

        // The last second of the (half-open) window, where the curve is at its widest.
        let at_end = Timestamp::from(start_timestamp + 7_200 - 1);
        // 4 USDC, ~$2 lost a fill: fine enough for a run to stop on the ~$20 ceiling itself.
        let amount_in = TokenAmount::from(4_000_000_u64);
        let mut fills = 0;
        let rejection = loop {
            let quote = quote_rebalance_swap(
                &vault.tokens(),
                &vault.rebalance,
                scope_prices,
                usdc_mint,
                sol_mint,
                amount_in,
                at_end,
            )
            .unwrap();
            match calculate_rebalance_swap(
                &mut vault,
                scope_prices,
                NetAum::ZERO,
                FillRequest {
                    token_in_mint: *usdc_mint,
                    token_out_mint: *sol_mint,
                    amount_in,
                    requested_out_amount: quote.max_out_from_curve,
                    now: at_end,
                },
            ) {
                Ok(_) => fills += 1,
                Err(err) => break err,
            }
            assert!(fills < 20, "the loss ceiling never bound");
        };
        (fills, rejection, vault.rebalance.lost())
    }

    #[test]
    fn test_rebalance_loss_restarts_with_a_new_rebalance() {
        let (mut vault, scope_prices, _, _, start_timestamp) =
            setup_active_sol_usdc_rebalance_with_max_loss(100);
        vault.rebalance.lost_usd_sf = DollarValue::from(Fraction::from(1_000_u64)).to_bits();

        stop_rebalance(&mut vault).unwrap();
        start_rebalance(
            &mut vault,
            Duration::from(7_200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(start_timestamp + 100_000),
            StartRebalanceAuthority::VaultAdmin,
        )
        .unwrap();

        assert_eq!(vault.rebalance.lost(), DollarValue::ZERO);
    }

    fn setup_active_sol_usdc_rebalance() -> (MetavaultState, VaultScopePrices, Pubkey, Pubkey, u64)
    {
        setup_active_sol_usdc_rebalance_with_max_loss(u64::from(FULL_BPS))
    }

    // The max loss is set before the start (the rebalance keeps the limits it started with).
    fn setup_active_sol_usdc_rebalance_with_max_loss(
        max_rebalance_loss_bps: u64,
    ) -> (MetavaultState, VaultScopePrices, Pubkey, Pubkey, u64) {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(
                    5000,
                    100.0,
                    15_000_000_000, // 15 SOL = $1500, overweight
                    9,
                ),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(
                    5000,
                    1.0,
                    500_000_000, // 500 USDC = $500, underweight
                    6,
                ),
            ),
        ]);
        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 1_000_000_000;
        vault.rebalance_limits.max_loss_bps = max_rebalance_loss_bps;

        let start_timestamp = 1_000_000;
        start_rebalance(
            &mut vault,
            Duration::from(7_200),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(start_timestamp),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();

        let sol_mint = vault.vault_tokens[0].mint;
        let usdc_mint = vault.vault_tokens[1].mint;
        (vault, scope_prices, usdc_mint, sol_mint, start_timestamp)
    }

    // (1) The wedge that stored targets had: a deposit that lands a token exactly on the target
    // it had a moment ago. With stored targets the vault then read as rebalanced (that token
    // settled, its partner left alone), the recalculation was skipped, and every later fill was
    // refused. With derived targets the deposit moves the targets with the free AUM, the
    // rebalance stays open and a fill goes through.
    #[test]
    fn test_deposit_onto_the_stale_target_keeps_the_rebalance_fillable() {
        let (mut vault, scope_prices, sol_mint, usdc_mint) = start_sol_usdc_rebalance();
        let sol_id = vault.get_vault_token_id_by_mint(&sol_mint).unwrap();
        let usdc_id = vault.get_vault_token_id_by_mint(&usdc_mint).unwrap();
        let targets_before = vault.tokens().targets(&scope_prices);
        let sol_deficit = token_by_id(&vault, sol_id).deficit(targets_before.of(sol_id));
        assert!(sol_deficit > TokenAmount::ZERO);

        vault_operations::deposit(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            &GlobalConfig::default(),
            sol_mint,
            sol_deficit,
            Timestamp::from(1_000_060),
        )
        .unwrap();

        // The wedge precondition: against the targets of a moment ago, SOL is now settled.
        assert!(token_by_id(&vault, sol_id).is_settled(targets_before.of(sol_id)));
        // Against the current targets it is not, and the rebalance is still open.
        assert!(vault.rebalance.is_unfinished());
        let targets = vault.tokens().targets(&scope_prices);
        assert!(!token_by_id(&vault, sol_id).is_settled(targets.of(sol_id)));
        assert!(token_by_id(&vault, usdc_id).excess(targets.of(usdc_id)) > TokenAmount::ZERO);

        let RebalanceFillEffects { amount_in, .. } = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: sol_mint,
                token_out_mint: usdc_mint,
                amount_in: TokenAmount::from(1_000_000_000),
                requested_out_amount: TokenAmount::ZERO,
                now: Timestamp::from(1_000_120),
            },
        )
        .unwrap();
        assert_eq!(amount_in, TokenAmount::from(1_000_000_000));
    }

    // A solver may offer more of the deficit token than the vault still wants. The quote takes
    // only the deficit, so the surplus is never pulled in and the fill cannot overshoot the
    // target it is closing.
    #[test]
    fn test_fill_clamps_an_oversized_input_to_the_deficit() {
        let (mut vault, scope_prices, sol_mint, usdc_mint) = start_sol_usdc_rebalance();
        let sol_id = vault.get_vault_token_id_by_mint(&sol_mint).unwrap();
        let sol_deficit =
            token_by_id(&vault, sol_id).deficit(vault.tokens().targets(&scope_prices).of(sol_id));
        assert!(sol_deficit > TokenAmount::ZERO);

        let RebalanceFillEffects { amount_in, .. } = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: sol_mint,
                token_out_mint: usdc_mint,
                amount_in: sol_deficit + TokenAmount::from(1_000_000_000),
                requested_out_amount: TokenAmount::ZERO,
                now: Timestamp::from(1_000_120),
            },
        )
        .unwrap();
        assert_eq!(amount_in, sol_deficit);
    }

    // The same wedge through the other user entry point: a withdrawal that lands the excess
    // token exactly on its stale target.
    #[test]
    fn test_withdraw_onto_the_stale_target_keeps_the_rebalance_fillable() {
        let (mut vault, scope_prices, sol_mint, usdc_mint) = start_sol_usdc_rebalance();
        let usdc_id = vault.get_vault_token_id_by_mint(&usdc_mint).unwrap();
        let targets_before = vault.tokens().targets(&scope_prices);
        let usdc_excess = token_by_id(&vault, usdc_id).excess(targets_before.of(usdc_id));
        assert!(usdc_excess > TokenAmount::ZERO);

        // Shares worth exactly the USDC excess: the vault holds $2000 against the issued shares.
        let usdc_price = &scope_prices.prices[usdc_id.input_account_index];
        let excess_value = usdc_excess.to_aum(usdc_price, RoundingMethod::Floor);
        let total_value = vault.compute_free_aum(&scope_prices, RoundingMethod::Floor);
        let shares = vault
            .shares_issued_amount()
            .apply_ratio(Ratio::of(excess_value, total_value), RoundingMethod::Floor);

        vault_operations::withdraw(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            &GlobalConfig::default(),
            usdc_mint,
            Timestamp::from(1_000_060),
            shares,
        )
        .unwrap();

        // The wedge precondition: against the targets of a moment ago, USDC is now settled.
        assert!(token_by_id(&vault, usdc_id).is_settled(targets_before.of(usdc_id)));
        assert!(vault.rebalance.is_unfinished());
        let targets = vault.tokens().targets(&scope_prices);
        assert!(!token_by_id(&vault, usdc_id).is_settled(targets.of(usdc_id)));

        let RebalanceFillEffects { amount_in, .. } = calculate_rebalance_swap(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            FillRequest {
                token_in_mint: sol_mint,
                token_out_mint: usdc_mint,
                amount_in: TokenAmount::from(1_000_000_000),
                requested_out_amount: TokenAmount::ZERO,
                now: Timestamp::from(1_000_120),
            },
        )
        .unwrap();
        assert_eq!(amount_in, TokenAmount::from(1_000_000_000));
    }

    // A rebalance that is over at the current prices is ended on entry to a deposit, before the
    // deposit moves any balance: the deposit cannot reopen it with fresh deficit and excess.
    #[test]
    fn test_deposit_cannot_reopen_a_rebalance_that_is_over() {
        // 10 SOL ($1000) and 1000 USDC ($1000) at equal weights sit on their targets: nothing
        // is fillable, but nobody has closed the rebalance yet.
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(5000, 100.0, 10_000_000_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_000_000_000, 6),
            ),
        ]);
        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 2_000_000_000;
        vault.rebalance.start_timestamp = 1_000_000;
        vault.rebalance.end_timestamp = 1_000_000 + 3600;
        assert!(!vault.tokens().is_progress_possible(&scope_prices));

        // A one-sided 10 SOL deposit would create a SOL excess and a USDC deficit worth filling
        // at the curve, if the rebalance were still open afterwards.
        vault_operations::deposit(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            &GlobalConfig::default(),
            tokens["SOL"].mint,
            TokenAmount::from(10_000_000_000),
            Timestamp::from(1_000_060),
        )
        .unwrap();
        assert!(!vault.rebalance.is_unfinished());
        assert!(vault.tokens().is_progress_possible(&scope_prices));
    }

    // A deposit can also be what ends a rebalance, and then it says so.
    #[test]
    fn test_deposit_that_completes_the_rebalance_ends_it() {
        let (mut vault, scope_prices, sol_mint, _) = start_sol_usdc_rebalance();
        // Depositing 5 SOL raises the AUM to $2500 and the SOL target to 12.5, so 10 SOL is still
        // short; for the deposit itself to carry SOL onto its new target it needs
        // 5 + x >= 0.5 * (2000 + 100x) / 100, i.e. x >= 10 SOL.
        vault_operations::deposit(
            &mut vault,
            &scope_prices,
            NetAum::ZERO,
            &GlobalConfig::default(),
            sol_mint,
            TokenAmount::from(10_000_000_000),
            Timestamp::from(1_000_060),
        )
        .unwrap();
        assert!(!vault.rebalance.is_unfinished());
    }

    // 5 SOL ($500) and 1500 USDC at equal weights: SOL is 5 SOL short of its target, USDC 500
    // over. Started at t=1_000_000 for an hour.
    fn start_sol_usdc_rebalance() -> (MetavaultState, VaultScopePrices, Pubkey, Pubkey) {
        let tokens = HashMap::from([
            (
                "SOL",
                TokenConfig::with_weight_price_available_decimals(5000, 100.0, 5_000_000_000, 9),
            ),
            (
                "USDC",
                TokenConfig::with_weight_price_available_decimals(5000, 1.0, 1_500_000_000, 6),
            ),
        ]);
        let (mut vault, scope_prices) = setup_vault_with_tokens(&tokens);
        vault.shares_issued = 2_000_000_000;
        start_rebalance(
            &mut vault,
            Duration::from(3600),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        )
        .unwrap();
        (vault, scope_prices, tokens["SOL"].mint, tokens["USDC"].mint)
    }

    fn targets_of(vault: &MetavaultState, scope_prices: &VaultScopePrices) -> Vec<u64> {
        vault
            .tokens()
            .targets(scope_prices)
            .iter()
            .map(u64::from)
            .collect()
    }

    /// The composite the production code no longer spells out: a rebalance is over once the
    /// clock has left its window, or the balances leave nothing to swap. Kept here because it is
    /// the behaviour under test, while the callers each ask the cheaper half first.
    fn is_rebalance_over(
        vault: &MetavaultState,
        targets: &RebalanceTargets,
        now: Timestamp,
    ) -> bool {
        !vault.rebalance.is_within(now) || !vault.tokens().is_progress_possible_toward(targets)
    }

    fn basket_token(vault: &MetavaultState, storage_index: usize) -> BasketToken {
        vault
            .tokens()
            .by_mint(&vault.vault_tokens[storage_index].mint)
            .unwrap()
    }

    fn targets_from<const N: usize>(lamports: [u64; N]) -> RebalanceTargets {
        lamports.into_iter().map(TokenAmount::from).collect()
    }
}

use crate::types::RoundingMethod;
use std::collections::HashMap;

use kamino_lending::fraction::Fraction;

use super::tests_utils::fixtures::setup_vault_with_tokens_and_config;
use crate::operations::{
    effects::DepositEffects,
    tests::tests_utils::{TokenConfig, UserState, EPSILON},
    vault_operations,
};
use crate::types::{NetAum, ShareAmount, Timestamp, TokenAmount};
use crate::utils::consts::INITIAL_DEPOSIT_SIZE;

/// Compute the ideal shares for the first deposit after the seed, from first principles.
///
/// `shares = floor(INITIAL_DEPOSIT_SIZE * deposit_lamports * deposit_price / deposit_factor
///                / (INITIAL_DEPOSIT_SIZE * seed_price / seed_factor))`
///
/// which simplifies to `floor(deposit_lamports * deposit_price * seed_factor
///                           / (deposit_factor * seed_price))`
///
/// Due to Fraction arithmetic rounding the actual on-chain result may be up to 1 less.
fn expected_shares_for_deposit(
    seed_price: f64,
    seed_decimals: u8,
    deposit_lamports: u64,
    deposit_price: f64,
    deposit_decimals: u8,
) -> u64 {
    let seed_factor = 10u64.pow(seed_decimals as u32) as f64;
    let deposit_factor = 10u64.pow(deposit_decimals as u32) as f64;
    (deposit_lamports as f64 * deposit_price * seed_factor / (deposit_factor * seed_price)) as u64
}

/// Assert that `actual` is within `tolerance` of `expected`.
fn assert_approx(actual: u64, expected: u64, tolerance: u64, label: &str) {
    let diff = (actual as i64 - expected as i64).unsigned_abs();
    assert!(
        diff <= tolerance,
        "{}: expected ~{}, got {} (diff {})",
        label,
        expected,
        actual,
        diff,
    );
}

#[test]
fn test_deposit_different_decimals_same_shares_minted() {
    for decimals in 2..9 {
        let tokens =
            HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, decimals))]);
        let (mut vault, global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);

        let deposit = TokenAmount::new(100);
        let DepositEffects {
            shares_to_mint,
            fee_shares_to_mint,
            token_to_deposit,
            ..
        } = vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            deposit,
            Timestamp::ZERO,
        )
        .unwrap();

        // Shares have same decimals as first added token (seed deposit causes up to 1 share rounding loss)
        assert!(
            u64::from(shares_to_mint) >= 99 && u64::from(shares_to_mint) <= 100,
            "Expected ~100 shares, got {}",
            shares_to_mint
        );
        assert_eq!(fee_shares_to_mint, ShareAmount::new(0));
        assert_eq!(token_to_deposit, TokenAmount::new(100));
    }
}

#[test]
fn test_deposit_multiple_decimals() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(1.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Each user deposits same lamports but receives different number of shares because tokens have different decimals
    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    assert_eq!(alice.tokens["USDC"], 1_000_000_000);
    // Seed is in SOL (first alphabetically, 9 decimals), so shares have 9-decimal precision
    // Alice deposits USDC worth much more than the seed, so shares ≈ 123456 * 10^3 (decimal shift)
    let alice_expected = expected_shares_for_deposit(1.0, 9, 123456, 1.0, 6);
    assert_approx(alice.shares, alice_expected, 1, "alice shares (multi-dec)");

    let mut bob = UserState::new("SOL", 1_000_123_001);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Same price as USDC but 3 more decimals - with seed deposit, bob gets proportional shares.
    // Bob asked to deposit 123456 SOL lamports; the back-conversion may consume slightly fewer
    // due to rounding, so bob retains ≈ initial - requested.
    let bob_initial = 1_000_123_001u64;
    let bob_requested = 123456u64;
    assert_approx(
        bob.tokens["SOL"],
        bob_initial - bob_requested,
        1,
        "bob tokens (multi-dec)",
    );
    // Bob deposits same lamports as Alice but in SOL (9 dec), which is 1000x less AUM.
    // So bob receives ≈ alice_expected / 1000 shares.
    assert_approx(
        bob.shares,
        alice_expected / 1000,
        1,
        "bob shares (multi-dec)",
    );
}

#[test]
fn test_deposit_multiple_prices() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price(1.0)),
        ("SOL", TokenConfig::with_price(2.0)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Back-conversion from shares to tokens may deposit 1 fewer lamport than requested
    let alice_initial = 1_000_123_456u64;
    let alice_requested = 123456u64;
    assert_approx(
        alice.tokens["USDC"],
        alice_initial - alice_requested,
        1,
        "alice tokens (multi-price)",
    );
    // Seed is SOL (6 dec, $2); Alice deposits USDC (6 dec, $1)
    let alice_expected = expected_shares_for_deposit(2.0, 6, alice_requested, 1.0, 6);
    assert_approx(
        alice.shares,
        alice_expected,
        1,
        "alice shares (multi-price)",
    );

    let mut bob = UserState::new("SOL", 1_000_061_728);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(61728),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // SOL price is 2x so 61728 lamports ≈ same dollar value. With seed deposit, shares are proportional.
    let bob_expected_shares = expected_shares_for_deposit(2.0, 6, alice_requested, 1.0, 6);
    assert_approx(
        bob.shares,
        bob_expected_shares,
        1,
        "bob shares (multi-price)",
    );
}

#[test]
fn test_deposit_multiple_decimals_and_prices() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(2.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    assert_eq!(alice.tokens["USDC"], 1_000_000_000);
    // Seed in SOL (9 dec, $2), shares have 9-decimal precision
    let alice_expected = expected_shares_for_deposit(2.0, 9, 123456, 1.0, 6);
    assert_approx(alice.shares, alice_expected, 1, "alice shares (dec+price)");

    let mut bob = UserState::new("SOL", 1_000_061_728);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(61728),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Bob's 61728 SOL lamports at $2 with 9 decimals is 1000x less AUM than Alice's USDC deposit.
    // Bob is the second depositor, so shares = total_shares * bob_aum / vault_aum (proportional).
    // His share count is ≈ alice_expected / 1000 due to the 1000x AUM difference.
    assert_approx(
        bob.shares,
        alice_expected / 1000,
        1,
        "bob shares (dec+price)",
    );
}

#[test]
fn test_deposit_multiple_decimals_and_big_second_price() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    assert_eq!(alice.tokens["USDC"], 1_000_000_000);
    // Seed in SOL (9 dec, $100), shares have 9-decimal precision
    let alice_expected = expected_shares_for_deposit(100.0, 9, 123456, 1.0, 6);
    assert_approx(alice.shares, alice_expected, 1, "alice shares (big-price)");

    let mut bob = UserState::new("SOL", 1_000_001_234);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(1234),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Bob deposits 1234 SOL lamports (9 dec, $100) which is ≈ same AUM as alice/1000.
    // As second depositor: shares = total_shares * bob_aum / vault_aum.
    assert_approx(
        bob.shares,
        alice_expected / 1000,
        1,
        "bob shares (big-price)",
    );
}

#[test]
fn test_deposit_2_deposits_then_withdraw_from_their_deposit() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(1.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Each user deposits same lamports but receives different number of shares because tokens have different decimals
    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    let mut bob = UserState::new("SOL", 1_000_123_001);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    // Alice withdraws almost all USDC deposited
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );
    // Bob withdraws almost all SOL deposited
    bob.consume_withdraw(
        "SOL",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            Timestamp::ZERO,
            ShareAmount::new(bob.shares),
        )
        .unwrap(),
    );
    assert_eq!(alice.tokens["USDC"], 1_000_123_456); // same lamports as at the start
    assert!(!alice.tokens.contains_key("SOL"));
    assert_eq!(ShareAmount::from(alice.shares), ShareAmount::new(0));
    assert!(!bob.tokens.contains_key("USDC"));
    assert_eq!(bob.tokens["SOL"], 1_000_123_000); // lost 1 lamport
    assert_eq!(ShareAmount::from(bob.shares), ShareAmount::new(0));
}

#[test]
fn test_deposit_2_deposits_then_withdraw_from_eachother() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(1.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    let mut bob = UserState::new("SOL", 1_000_123_001);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    // Alice who has more shares will withdraw all SOL
    alice.consume_withdraw(
        "SOL",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );
    let usdc_available = vault
        .vault_tokens
        .iter()
        .find(|token| token.mint == tokens["USDC"].mint)
        .unwrap()
        .token_available;
    let expected_alice_usdc_received = alice.shares * usdc_available / vault.shares_issued;
    let expected_bob_usdc_received = bob.shares * usdc_available / vault.shares_issued;
    // And withdraw some of the USDC
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );
    // Bob who has less shares will withdraw all remaining USDC
    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(bob.shares),
        )
        .unwrap(),
    );
    assert_eq!(
        alice.tokens["USDC"],
        1_000_000_000 + expected_alice_usdc_received
    );
    // SOL available = seed deposit + bob's deposit of 123456
    let bob_deposited = 123456u64;
    assert_eq!(alice.tokens["SOL"], INITIAL_DEPOSIT_SIZE + bob_deposited);
    // Small residual shares remain due to seed deposit rounding
    assert!(
        alice.shares < INITIAL_DEPOSIT_SIZE,
        "alice residual shares: {}",
        alice.shares
    );
    assert_eq!(bob.tokens["USDC"], expected_bob_usdc_received);
    // Bob's remaining SOL = initial - deposited amount
    let bob_initial_sol = 1_000_123_001u64;
    assert_eq!(bob.tokens["SOL"], bob_initial_sol - bob_deposited);
    assert!(
        bob.shares < INITIAL_DEPOSIT_SIZE,
        "bob residual shares: {}",
        bob.shares
    );
}

#[test]
fn test_deposit_2_deposits_then_withdraw_from_eachother_diff_prices() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Each user deposits same lamports but receives different number of shares because tokens have different decimals
    let mut alice = UserState::new("USDC", 1_000_123_456);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(123456),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    let mut bob = UserState::new("SOL", 1_000_000_121);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(121), // Deposit 10 times less than alice
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    alice.consume_withdraw(
        "SOL",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );
    let usdc_available = vault
        .vault_tokens
        .iter()
        .find(|token| token.mint == tokens["USDC"].mint)
        .unwrap()
        .token_available;
    let expected_alice_usdc_received = alice.shares * usdc_available / vault.shares_issued;
    let expected_bob_usdc_received = bob.shares * usdc_available / vault.shares_issued;
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );
    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(bob.shares),
        )
        .unwrap(),
    );
    assert_eq!(
        alice.tokens["USDC"],
        1_000_000_000 + expected_alice_usdc_received
    );
    // SOL available = seed deposit + bob's deposit of 121
    let bob_deposited = 121u64;
    assert_eq!(alice.tokens["SOL"], INITIAL_DEPOSIT_SIZE + bob_deposited);
    // Small residual shares remain due to seed deposit rounding
    assert!(
        alice.shares < INITIAL_DEPOSIT_SIZE,
        "alice residual shares: {}",
        alice.shares
    );
    assert_eq!(bob.tokens["USDC"], expected_bob_usdc_received);
    assert_eq!(bob.tokens["SOL"], 1_000_000_000);
    assert!(
        bob.shares < INITIAL_DEPOSIT_SIZE,
        "bob residual shares: {}",
        bob.shares
    );
}

#[test]
fn test_first_depositor_advantage_attack() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // With seed deposit of INITIAL_DEPOSIT_SIZE shares / INITIAL_DEPOSIT_SIZE lamports, the attacker's small deposit
    // gets only 1 share (floor rounding), mitigating the first-depositor advantage attack
    let mut attacker = UserState::new("USDC", 1_000_001);
    attacker.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(2),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Seed mitigates: attacker gets only 1 share for 2 lamports (rounding loss to attacker)
    assert_eq!(attacker.shares, 1);

    attacker.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(1),
        )
        .unwrap(),
    );

    let mut victim = UserState::new("USDC", 1_001_000_000);
    victim.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(1_000_000),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // After attacker withdrew, vault has INITIAL_DEPOSIT_SIZE shares and INITIAL_DEPOSIT_SIZE+1 lamports (attacker left 1 lamport).
    // Victim deposits 1_000_000 lamports: shares = floor(INITIAL_DEPOSIT_SIZE * 1_000_000 / (INITIAL_DEPOSIT_SIZE + 1))
    let victim_deposit = 1_000_000u64;
    let vault_aum_lamports = INITIAL_DEPOSIT_SIZE + 1; // seed + attacker's 1 donated lamport
    let victim_expected_shares = INITIAL_DEPOSIT_SIZE * victim_deposit / vault_aum_lamports;
    assert_approx(victim.shares, victim_expected_shares, 1, "victim shares");

    victim.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(victim.shares),
        )
        .unwrap(),
    );
    // Victim gets back essentially all deposited value (minus tiny rounding)
    assert!(victim.tokens["USDC"] >= 1_000_999_999);
    // Attacker got back at most what they deposited (attack is not profitable)
    assert!(attacker.tokens["USDC"] <= 1_000_001);
}

#[test]
fn test_share_dilution_attack_high_precision() {
    let tokens = HashMap::from_iter([
        ("WBTC", TokenConfig::with_price_and_decimals(50000.0, 8)),
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut attacker = UserState::new("WBTC", 1_000_000_001);
    attacker.consume_deposit(
        "WBTC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["WBTC"].mint,
            TokenAmount::new(1), // 0.00000001 WBTC = $0.0005
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let mut victim = UserState::new("USDC", 1_000_500_000);
    victim.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(500_000), // $0.50
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    // Include the seed deposit (USDC at $1, 6 dec) in AUM calculations
    let seed_aum = INITIAL_DEPOSIT_SIZE as f64 / 1_000_000.0;
    let total_aum_deposited = seed_aum + 50000.0 * 1.0 / 100_000_000.0 + 500_000.0 / 1_000_000.0;
    let attacker_share_ratio = (50000.0 * 1.0 / 100_000_000.0) / total_aum_deposited;
    let victim_share_ratio = (500_000.0 / 1_000_000.0) / total_aum_deposited;

    // Use vault.shares_issued (includes seed shares) for proportions
    let total_shares = vault.shares_issued;
    let attacker_expected_share_pct = (attacker.shares as f64) / (total_shares as f64);
    let victim_expected_share_pct = (victim.shares as f64) / (total_shares as f64);

    // Epsilon: the seed's fraction of total AUM bounds the proportional shift
    let share_epsilon = seed_aum / total_aum_deposited;
    assert!(
        (attacker_expected_share_pct - attacker_share_ratio).abs() < share_epsilon,
        "attacker share pct: {} vs ratio: {}",
        attacker_expected_share_pct,
        attacker_share_ratio
    );
    assert!(
        (victim_expected_share_pct - victim_share_ratio).abs() < share_epsilon,
        "victim share pct: {} vs ratio: {}",
        victim_expected_share_pct,
        victim_share_ratio
    );

    victim.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(victim.shares),
        )
        .unwrap(),
    );
    // Attacker's 1 WBTC lamport ($0.0005) is too small relative to vault AUM to withdraw as WBTC
    // (would round to 0 lamports), so withdraw as USDC instead
    attacker.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(attacker.shares),
        )
        .unwrap(),
    );

    assert!(victim.tokens["USDC"] >= 1_000_499_999);
    // Attacker got back their deposit value as USDC (not WBTC), no profit
    assert!(attacker.tokens["WBTC"] <= 1_000_000_001);
}

#[test]
fn test_cross_token_precision_loss() {
    let tokens = HashMap::from_iter([
        ("TOKEN_2", TokenConfig::with_price_and_decimals(1.0, 2)),
        ("TOKEN_12", TokenConfig::with_price_and_decimals(1.0, 12)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut user_a = UserState::new("TOKEN_2", 1_000_000);
    user_a.consume_deposit(
        "TOKEN_2",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["TOKEN_2"].mint,
            TokenAmount::new(50_000), // 500.00 tokens
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let mut user_b = UserState::new("TOKEN_12", 500_000_000_000_000);
    user_b.consume_deposit(
        "TOKEN_12",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["TOKEN_12"].mint,
            TokenAmount::new(500_000_000_000_000), // 500.000000000000 tokens
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let share_ratio = user_a.shares as f64 / user_b.shares as f64;
    assert!((share_ratio - 1.0).abs() < EPSILON);

    let user_a_initial_token_12 = *user_a.tokens.get("TOKEN_12").unwrap_or(&0);
    let user_b_initial_token_2 = *user_b.tokens.get("TOKEN_2").unwrap_or(&0);

    user_a.consume_withdraw(
        "TOKEN_12",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["TOKEN_12"].mint,
            Timestamp::ZERO,
            ShareAmount::new(user_a.shares / 2), // Half shares
        )
        .unwrap(),
    );
    user_b.consume_withdraw(
        "TOKEN_2",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["TOKEN_2"].mint,
            Timestamp::ZERO,
            ShareAmount::new(user_b.shares / 2), // Half shares
        )
        .unwrap(),
    );

    let user_a_token_12_received = user_a.tokens["TOKEN_12"] - user_a_initial_token_12;
    let user_b_token_2_received = user_b.tokens["TOKEN_2"] - user_b_initial_token_2;

    let user_a_dollar_value = user_a_token_12_received as f64 / 1_000_000_000_000.0;
    let user_b_dollar_value = user_b_token_2_received as f64 / 100.0;

    // TOKEN_2 has only 2 decimals so precision is limited to 1/10^2 = $0.01; use appropriate epsilon
    assert!(
        (user_a_dollar_value - user_b_dollar_value).abs() < 0.01,
        "user_a: {}, user_b: {}, diff: {}",
        user_a_dollar_value,
        user_b_dollar_value,
        (user_a_dollar_value - user_b_dollar_value).abs()
    );
}

#[test]
fn test_conservation_of_value_3_users() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(100.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // Seed deposit: SOL (first alphabetically, $100, 9 dec)
    let mut total_value_deposited = INITIAL_DEPOSIT_SIZE as f64 * 100.0 / 1_000_000_000.0;

    let mut alice = UserState::new("USDC", 1_001_000_000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(1_000_000), // $1.00
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    total_value_deposited += 1.0;

    let mut bob = UserState::new("SOL", 1_000_020_000);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(20_000), // 0.00002 SOL = $0.002
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    total_value_deposited += 0.002;

    let mut charlie = UserState::new("USDC", 1_002_500_000);
    charlie.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(2_500_000), // $2.50
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    total_value_deposited += 2.50;

    let vault_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    let vault_aum_dollars = vault_aum.to_num::<f64>();
    assert!((vault_aum_dollars - total_value_deposited).abs() < 0.001);

    alice.consume_withdraw(
        "SOL",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares / 2),
        )
        .unwrap(),
    );
    bob.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(bob.shares),
        )
        .unwrap(),
    );
    charlie.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(charlie.shares / 3),
        )
        .unwrap(),
    );

    let mut total_user_value = 0.0f64;
    total_user_value += alice
        .tokens
        .get("USDC")
        .unwrap_or(&0)
        .saturating_sub(1_000_000_000) as f64
        / 1_000_000.0;
    total_user_value += *alice.tokens.get("SOL").unwrap_or(&0) as f64 / 1_000_000_000.0 * 100.0;
    total_user_value += *bob.tokens.get("USDC").unwrap_or(&0) as f64 / 1_000_000.0;
    total_user_value += (*bob.tokens.get("SOL").unwrap_or(&0)).saturating_sub(1_000_000_000) as f64
        / 1_000_000_000.0
        * 100.0;
    total_user_value += charlie
        .tokens
        .get("USDC")
        .unwrap_or(&0)
        .saturating_sub(1_000_000_000) as f64
        / 1_000_000.0;
    total_user_value += *charlie.tokens.get("SOL").unwrap_or(&0) as f64 / 1_000_000_000.0 * 100.0;

    let remaining_vault_aum =
        Fraction::from(vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor));
    let remaining_vault_dollars = remaining_vault_aum.to_num::<f64>();
    let total_final_value = total_user_value + remaining_vault_dollars;
    assert!((total_final_value - total_value_deposited).abs() < EPSILON);
}

#[test]
fn test_no_free_money_creation() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("WETH", TokenConfig::with_price_and_decimals(3000.0, 18)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut user1 = UserState::new("USDC", 1_100_000_000);
    let mut user2 = UserState::new("WETH", 1_333_333_333_333_333_333);

    let initial_user1_value = 100.0;
    let initial_user2_value = 1000.0;

    user1.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(100_000_000),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    user2.consume_deposit(
        "WETH",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["WETH"].mint,
            TokenAmount::new(333_333_333_333_333_333), // ~$1000 worth
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    user1.consume_withdraw(
        "WETH",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["WETH"].mint,
            Timestamp::ZERO,
            ShareAmount::new(user1.shares),
        )
        .unwrap(),
    );
    user2.consume_withdraw(
        "WETH",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["WETH"].mint,
            Timestamp::ZERO,
            ShareAmount::new(user2.shares),
        )
        .unwrap(),
    );
    user2.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(user2.shares),
        )
        .unwrap(),
    );

    let user1_final_usdc = user1
        .tokens
        .get("USDC")
        .unwrap_or(&0)
        .saturating_sub(1_000_000_000) as f64
        / 1_000_000.0;
    let user1_final_eth_value =
        *user1.tokens.get("WETH").unwrap_or(&0) as f64 / 1_000_000_000_000_000_000.0 * 3000.0;
    let user1_final_value = user1_final_usdc + user1_final_eth_value;

    let user2_final_usdc = *user2.tokens.get("USDC").unwrap_or(&0) as f64 / 1_000_000.0;
    let user2_final_eth_value = user2
        .tokens
        .get("WETH")
        .unwrap_or(&0)
        .saturating_sub(1_000_000_000_000_000_000) as f64
        / 1_000_000_000_000_000_000.0
        * 3000.0;
    let user2_final_value = user2_final_usdc + user2_final_eth_value;

    // Seed deposit's dollar value (USDC at $1, 6 decimals) bounds the proportional shift
    let seed_epsilon = INITIAL_DEPOSIT_SIZE as f64 / 1_000_000.0;
    assert!(
        (user1_final_value - initial_user1_value).abs() <= seed_epsilon,
        "user1 value diff: {}",
        (user1_final_value - initial_user1_value).abs()
    );
    assert!(
        (user2_final_value - initial_user2_value).abs() <= seed_epsilon,
        "user2 value diff: {}",
        (user2_final_value - initial_user2_value).abs()
    );
}

#[test]
fn test_late_depositor_protection() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    // With seed deposit of INITIAL_DEPOSIT_SIZE lamports / INITIAL_DEPOSIT_SIZE shares already in the vault,
    // we deposit a larger amount to test the late depositor scenario
    let mut early_user = UserState::new("USDC", 1_010_000);
    early_user.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(10_000),
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    // Simulate price inflation: someone donates 990_000 lamports to the vault
    let vault_token = vault
        .vault_tokens
        .iter_mut()
        .find(|t| t.mint == tokens["USDC"].mint)
        .unwrap();
    vault_token.token_available += 990_000;

    // Vault now has INITIAL_DEPOSIT_SIZE (seed) + 10000 (early) + 990000 (donation) = 1_001_000 lamports
    // but only INITIAL_DEPOSIT_SIZE (seed) + ~10000 (early) shares
    let mut late_user = UserState::new("USDC", 1_001_000_000);
    late_user.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(1_000_000), // $1
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    // Late user should get fair proportional shares based on AUM, not inflated price
    let vault_aum_before_late = 1_001_000.0 / 1_000_000.0; // ~$1.001
    let late_deposit_value = 1.0f64;
    let expected_late_share_pct = late_deposit_value / (vault_aum_before_late + late_deposit_value);
    let actual_late_share_pct = late_user.shares as f64 / vault.shares_issued as f64;

    // Epsilon: the seed's fraction of total AUM bounds the proportional shift
    let seed_aum = INITIAL_DEPOSIT_SIZE as f64 / 1_000_000.0;
    let total_aum = vault_aum_before_late + late_deposit_value;
    let late_epsilon = seed_aum / total_aum;
    assert!(
        (actual_late_share_pct - expected_late_share_pct).abs() < late_epsilon,
        "Late depositor share pct: {}, expected: {}",
        actual_late_share_pct,
        expected_late_share_pct
    );

    let late_user_shares_backup = late_user.shares;
    late_user.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(late_user_shares_backup),
        )
        .unwrap(),
    );

    // Late user should get back approximately what they deposited (no exploitation)
    let late_user_received = late_user.tokens["USDC"] as f64 - (1_001_000_000 - 1_000_000) as f64;
    assert!(
        late_user_received >= 999_000.0,
        "Late user should recover most of their deposit, got {}",
        late_user_received
    );
}

#[test]
fn test_proportional_withdrawal_rights_three_users() {
    let tokens = HashMap::from_iter([
        ("USDC", TokenConfig::with_price_and_decimals(1.0, 6)),
        ("SOL", TokenConfig::with_price_and_decimals(200.0, 9)),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut alice = UserState::new("USDC", 1_005_000_000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(5_000_000),
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let mut bob = UserState::new("SOL", 1_000_015_000_000);
    bob.consume_deposit(
        "SOL",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            TokenAmount::new(15_000_000),
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let mut charlie = UserState::new("USDC", 1_002_000_000);
    charlie.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(2_000_000),
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    // Seed: SOL (first alphabetically, $200, 9 dec)
    let seed_value = INITIAL_DEPOSIT_SIZE as f64 * 200.0 / 1_000_000_000.0;
    let total_deposited = 10.0f64 + seed_value;
    let alice_proportion = 5.0 / total_deposited;
    let bob_proportion = 3.0 / total_deposited;
    let charlie_proportion = 2.0 / total_deposited;

    let total_shares = vault.shares_issued;
    let alice_share_pct = alice.shares as f64 / total_shares as f64;
    let bob_share_pct = bob.shares as f64 / total_shares as f64;
    let charlie_share_pct = charlie.shares as f64 / total_shares as f64;

    // Epsilon: the seed's fraction of total AUM bounds the proportional shift
    let proportion_epsilon = seed_value / total_deposited;
    assert!((alice_share_pct - alice_proportion).abs() < proportion_epsilon);
    assert!((bob_share_pct - bob_proportion).abs() < proportion_epsilon);
    assert!((charlie_share_pct - charlie_proportion).abs() < proportion_epsilon);

    charlie.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(charlie.shares),
        )
        .unwrap(),
    );
    bob.consume_withdraw(
        "SOL",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["SOL"].mint,
            Timestamp::ZERO,
            ShareAmount::new(bob.shares),
        )
        .unwrap(),
    );
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );

    let alice_withdrawal = alice.tokens["USDC"] - 1_000_000_000;
    let bob_withdrawal_value =
        (bob.tokens["SOL"] - 1_000_000_000_000) as f64 / 1_000_000_000.0 * 200.0;
    let charlie_withdrawal = charlie.tokens["USDC"] - 1_000_000_000;

    // Small rounding differences from seed deposit proportional math
    assert!((alice_withdrawal as i64 - 5_000_000i64).unsigned_abs() <= 1);
    assert!((bob_withdrawal_value - 3.0).abs() < 0.001);
    assert!((charlie_withdrawal as i64 - 2_000_000i64).unsigned_abs() <= 1);
}

#[test]
fn test_cheap_and_expensive_same_value_deposited() {
    let tokens = HashMap::from_iter([
        ("CHEAP", TokenConfig::with_price_and_decimals(1.0, 6)),
        (
            "EXPENSIVE",
            TokenConfig::with_price_and_decimals(10000.0, 6),
        ),
    ]);
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let mut expensive_user = UserState::new("EXPENSIVE", 1_000_000_100);
    expensive_user.consume_deposit(
        "EXPENSIVE",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["EXPENSIVE"].mint,
            TokenAmount::new(100), // 0.0001 EXPENSIVE = $1
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let mut cheap_user = UserState::new("CHEAP", 1_001_000_000);
    cheap_user.consume_deposit(
        "CHEAP",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["CHEAP"].mint,
            TokenAmount::new(1_000_000), // 1 CHEAP = $1, so 1M CHEAP = $1 (because it has 6 decimals)
            Timestamp::ZERO,
        )
        .unwrap(),
    );

    let expensive_user_value = 100.0 * 10000.0 / 1_000_000.0;
    let cheap_user_value = 1_000_000.0 * 1.0 / 1_000_000.0;

    let total_shares = expensive_user.shares + cheap_user.shares;
    let expensive_user_share_pct = expensive_user.shares as f64 / total_shares as f64;
    let cheap_user_share_pct = cheap_user.shares as f64 / total_shares as f64;

    // Epsilon: the seed's fraction of total AUM bounds the proportional shift
    let seed_aum = INITIAL_DEPOSIT_SIZE as f64 / 1_000_000.0;
    let total_aum = seed_aum + expensive_user_value + cheap_user_value;
    let share_epsilon = seed_aum / total_aum;
    assert!((expensive_user_share_pct - 0.5).abs() < share_epsilon);
    assert!((cheap_user_share_pct - 0.5).abs() < share_epsilon);

    expensive_user.consume_withdraw(
        "CHEAP",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["CHEAP"].mint,
            Timestamp::ZERO,
            ShareAmount::new(expensive_user.shares),
        )
        .unwrap(),
    );
    cheap_user.consume_withdraw(
        "EXPENSIVE",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["EXPENSIVE"].mint,
            Timestamp::ZERO,
            ShareAmount::new(cheap_user.shares),
        )
        .unwrap(),
    );

    let expensive_user_cheap_received = expensive_user.tokens.get("CHEAP").unwrap_or(&0);
    let cheap_user_expensive_received = cheap_user.tokens.get("EXPENSIVE").unwrap_or(&0);

    let expensive_user_value_received = *expensive_user_cheap_received as f64 * 1.0 / 1_000_000.0;
    let cheap_user_value_received = *cheap_user_expensive_received as f64 * 10000.0 / 1_000_000.0;

    // Seed deposit causes small dollar-value differences due to rounding at token granularity
    let value_epsilon = seed_aum / total_aum;
    assert!((expensive_user_value_received - cheap_user_value_received).abs() < value_epsilon);
    assert!((expensive_user_value_received - expensive_user_value).abs() <= value_epsilon);
    assert!((cheap_user_value_received - cheap_user_value).abs() <= value_epsilon);
}

#[test]
fn test_deposit_fee_donation_increases_share_price_for_existing_holders() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let deposit_fee_bps = 500;
    let (mut vault, mut global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, 0);
    global_config.deposit_fee_bps = deposit_fee_bps;

    let alice_deposit = 10_000_000;
    let mut alice = UserState::new("USDC", 1_000_000_000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(alice_deposit),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Alice's net deposit after the 5% fee is 9_500_000, and that is exactly what her stake is
    // worth: shares are priced against post-fee AUM, so the donation lands on the pre-existing
    // (seed) holder instead of flowing back to her own fresh shares. Her share *count* is
    // therefore much smaller than her net deposit — the donation repriced the seed vault.
    //
    // The seed vault holds 1000 lamports against 1000 shares, so the 500_000 donated lamports
    // reprice a share to ~501 lamports; the deposit itself is quantized to that granularity,
    // hence `alice_deposited` rather than the requested amount.
    let alice_deposited = 1_000_000_000 - alice.tokens["USDC"];
    let alice_net_deposit = alice_deposited * (10_000 - deposit_fee_bps) / 10_000;
    let aum_after_alice = alice_deposited + INITIAL_DEPOSIT_SIZE;
    // The tolerance is one share quantum, derived rather than guessed: a stake is an integer
    // number of shares, so it can only be expressed to the nearest share price. Anything looser
    // would stop distinguishing a pricing regression from this quantization.
    let share_quantum = aum_after_alice / vault.shares_issued + 1;
    assert_approx(
        stake_value(alice.shares, aum_after_alice, vault.shares_issued),
        alice_net_deposit,
        share_quantum,
        "alice stake value (fee donation)",
    );
    // Vault has seed + alice's full deposit (fee is donated, not removed)
    assert_eq!(
        vault.vault_tokens[0].token_available,
        alice_deposited + INITIAL_DEPOSIT_SIZE
    );

    let bob_deposit = 10_000_000;
    let mut bob = UserState::new("USDC", 1_000_000_000);
    bob.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(bob_deposit),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Bob pays the same 5%, whatever the vault already holds.
    let bob_deposited = 1_000_000_000 - bob.tokens["USDC"];
    let aum_after_bob = alice_deposited + bob_deposited + INITIAL_DEPOSIT_SIZE;
    let share_quantum = aum_after_bob / vault.shares_issued + 1;
    assert_approx(
        stake_value(bob.shares, aum_after_bob, vault.shares_issued),
        bob_deposited * (10_000 - deposit_fee_bps) / 10_000,
        share_quantum,
        "bob stake value (fee donation)",
    );
    assert_eq!(
        vault.shares_issued,
        alice.shares + bob.shares + INITIAL_DEPOSIT_SIZE
    ); // alice + bob + seed
    assert_eq!(vault.vault_tokens[0].token_available, aum_after_bob); // includes seed

    let alice_shares_before_exit = alice.shares;
    let no_fee_config = crate::GlobalConfig::default();
    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &no_fee_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - (1_000_000_000 - alice_deposited);
    // Alice exits with her net deposit plus her pro-rata slice of Bob's donated fee — she no
    // longer recaptures her own, so the round trip costs her the configured rate.
    assert!(alice_received < alice_deposited);
    let bob_fee = bob_deposited * deposit_fee_bps / 10_000;
    let alice_slice_of_bob_fee =
        bob_fee * alice_shares_before_exit / (alice_shares_before_exit + INITIAL_DEPOSIT_SIZE);
    // Alice's entry quantized her stake to a whole number of shares and her exit quantizes the
    // payout back to lamports, so the round trip carries at most two share quanta of rounding
    // (both vault-favourable) on top of the integer division in the expectation above.
    assert_approx(
        alice_received,
        alice_net_deposit + alice_slice_of_bob_fee,
        2 * share_quantum + 1,
        "alice exit (own fee paid in full, pro-rata slice of bob's earned)",
    );
}

/// The value a holding is worth at the vault's current share price, in token lamports.
fn stake_value(shares: u64, vault_aum: u64, shares_issued: u64) -> u64 {
    u64::try_from(u128::from(shares) * u128::from(vault_aum) / u128::from(shares_issued)).unwrap()
}

#[test]
fn test_realized_deposit_fee_does_not_decay_with_deposit_size() {
    // The fee has to keep working as an economic barrier against atomic manipulation: a
    // flash-loaned deposit many times the size of the vault must still pay the full nominal
    // rate, not `nominal x A/(A+N)`.
    let deposit_fee_bps = 500;
    for deposit in [10_000_u64, 1_000_000, 100_000_000, 10_000_000_000] {
        let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
        let (mut vault, mut global_config, vault_scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);

        // Warm the vault up to 1_000_000 of AUM held by incumbents, fee-free.
        let incumbent_deposit = 1_000_000_u64;
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(incumbent_deposit),
            Timestamp::ZERO,
        )
        .unwrap();
        let incumbent_shares = vault.shares_issued;
        let aum_before = incumbent_deposit + INITIAL_DEPOSIT_SIZE;

        global_config.deposit_fee_bps = deposit_fee_bps;
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            TokenAmount::new(deposit),
            Timestamp::ZERO,
        )
        .unwrap();

        let aum_after = aum_before + deposit;
        let incumbent_gain =
            stake_value(incumbent_shares, aum_after, vault.shares_issued) - aum_before;
        let nominal_fee = deposit * deposit_fee_bps / 10_000;
        assert_approx(
            incumbent_gain,
            nominal_fee,
            2,
            &format!("realized fee on a deposit of {deposit}"),
        );
    }
}

#[test]
fn test_withdrawal_fee_stays_in_vault_and_full_exit_burns_all_shares() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let withdrawal_fee_bps = 500;
    let (mut vault, global_config, vault_scope_prices) =
        setup_vault_with_tokens_and_config(&tokens, 0, withdrawal_fee_bps);
    let no_fee_config = crate::GlobalConfig::default();

    let deposit_amount = 10_000_000;
    let mut alice = UserState::new("USDC", 1_000_000_000);
    alice.consume_deposit(
        "USDC",
        vault_operations::deposit(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &no_fee_config,
            tokens["USDC"].mint,
            TokenAmount::new(deposit_amount),
            Timestamp::ZERO,
        )
        .unwrap(),
    );
    // Seed deposit causes 1 share rounding loss
    assert_eq!(alice.shares, deposit_amount - 1);
    let alice_shares_before_withdraw = alice.shares;
    let expected_fee = (alice_shares_before_withdraw * withdrawal_fee_bps + 9_999) / 10_000;

    alice.consume_withdraw(
        "USDC",
        vault_operations::withdraw(
            &mut vault,
            &vault_scope_prices,
            NetAum::ZERO,
            &global_config,
            tokens["USDC"].mint,
            Timestamp::ZERO,
            ShareAmount::new(alice.shares),
        )
        .unwrap(),
    );

    let alice_received = alice.tokens["USDC"] - (1_000_000_000 - deposit_amount);
    assert_eq!(alice_received, alice_shares_before_withdraw - expected_fee);
    assert_eq!(alice.shares, 0);
    assert_eq!(vault.shares_issued, INITIAL_DEPOSIT_SIZE);
    assert_eq!(
        vault.vault_tokens[0].token_available,
        INITIAL_DEPOSIT_SIZE + (deposit_amount - alice_shares_before_withdraw) + expected_fee
    );
}

#[cfg(test)]
mod tests {
    use kamino_lending::{fraction::Fraction, utils::FULL_BPS};
    use proptest::prelude::*;

    use crate::types::ratio::Ratio;
    use crate::types::RoundingMethod;
    use crate::types::*;
    use crate::KaminoVaultError;

    // ─── WrapperU64 / ShareAmount / TokenAmount / Weight ────────────────────────

    #[test]
    fn test_share_amount_add() {
        let a = ShareAmount::from(100);
        let b = ShareAmount::from(200);
        assert_eq!(a + b, ShareAmount::from(300));
    }

    #[test]
    fn test_share_amount_sub() {
        let a = ShareAmount::from(300);
        let b = ShareAmount::from(100);
        assert_eq!(a - b, ShareAmount::from(200));
    }

    #[test]
    fn test_token_amount_add() {
        let a = TokenAmount::from(500);
        let b = TokenAmount::from(500);
        assert_eq!(a + b, TokenAmount::from(1000));
    }

    #[test]
    fn test_token_amount_sub() {
        let a = TokenAmount::from(1000);
        let b = TokenAmount::from(400);
        assert_eq!(a - b, TokenAmount::from(600));
    }

    #[test]
    fn test_weight_add_sub() {
        let a = Weight::from(7000);
        let b = Weight::from(3000);
        assert_eq!(a + b, Weight::from(10000));
        assert_eq!(a - b, Weight::from(4000));
    }

    #[test]
    fn test_checked_add_overflow() {
        let a = ShareAmount::MAX;
        let b = ShareAmount::ONE;
        assert_eq!(a.checked_add(b), None);
    }

    #[test]
    fn test_checked_sub_underflow() {
        let a = TokenAmount::ZERO;
        let b = TokenAmount::ONE;
        assert_eq!(a.checked_sub(b), None);
    }

    #[test]
    fn test_saturating_sub_clamps_to_zero() {
        let a = ShareAmount::from(5);
        let b = ShareAmount::from(10);
        assert_eq!(a.saturating_sub(b), ShareAmount::ZERO);
    }

    #[test]
    fn test_saturating_sub_no_clamp() {
        let a = TokenAmount::from(10);
        let b = TokenAmount::from(3);
        assert_eq!(a.saturating_sub(b), TokenAmount::from(7));
    }

    #[test]
    fn test_is_zero() {
        assert!(ShareAmount::ZERO.is_zero());
        assert!(!ShareAmount::ONE.is_zero());
        assert!(TokenAmount::ZERO.is_zero());
        assert!(!Weight::from(1).is_zero());
    }

    #[test]
    fn test_constants() {
        assert_eq!(ShareAmount::ZERO, ShareAmount::from(0));
        assert_eq!(ShareAmount::ONE, ShareAmount::from(1));
        assert_eq!(ShareAmount::MAX, ShareAmount::from(u64::MAX));

        assert_eq!(TokenAmount::ZERO, TokenAmount::from(0));
        assert_eq!(TokenAmount::ONE, TokenAmount::from(1));
        assert_eq!(TokenAmount::MAX, TokenAmount::from(u64::MAX));

        assert_eq!(Weight::ZERO, Weight::from(0));
        assert_eq!(Weight::ONE, Weight::from(1));
        assert_eq!(Weight::MAX, Weight::from(u64::MAX));
    }

    // ─── Timestamp / Duration ────────────────────────────────────────────────────

    #[test]
    fn test_timestamp_sub_returns_duration() {
        let t1 = Timestamp::from(1000);
        let t2 = Timestamp::from(400);
        let d: Duration = t1 - t2;
        assert_eq!(d, Duration::from(600));
    }

    #[test]
    fn test_timestamp_sub_saturates() {
        let t1 = Timestamp::from(100);
        let t2 = Timestamp::from(500);
        let d: Duration = t1 - t2;
        assert_eq!(d, Duration::ZERO);
    }

    #[test]
    fn test_duration_constants() {
        assert_eq!(Duration::ZERO, Duration::from(0));
        assert_eq!(Duration::ONE, Duration::from(1));
        assert_eq!(Duration::MAX, Duration::from(u64::MAX));
    }

    #[test]
    fn test_duration_checked_add_overflow() {
        assert_eq!(Duration::MAX.checked_add(Duration::ONE), None);
    }

    // ─── DollarValue ─────────────────────────────────────────────────────────────

    #[test]
    fn test_dollar_value_add() {
        let a = DollarValue::from_bits(Fraction::from(100u64).to_bits());
        let b = DollarValue::from_bits(Fraction::from(200u64).to_bits());
        let expected = DollarValue::from_bits(Fraction::from(300u64).to_bits());
        assert_eq!(a + b, expected);
    }

    #[test]
    fn test_dollar_value_sub() {
        let a = DollarValue::from_bits(Fraction::from(500u64).to_bits());
        let b = DollarValue::from_bits(Fraction::from(200u64).to_bits());
        let expected = DollarValue::from_bits(Fraction::from(300u64).to_bits());
        assert_eq!(a - b, expected);
    }

    #[test]
    fn test_dollar_value_from_to_bits_roundtrip() {
        let original = Fraction::from_num(42.5_f64);
        let dv = DollarValue::from_bits(original.to_bits());
        assert_eq!(dv.to_bits(), original.to_bits());
    }

    #[test]
    fn test_dollar_value_is_zero() {
        assert!(DollarValue::ZERO.is_zero());
        let non_zero = DollarValue::from_bits(Fraction::from(1u64).to_bits());
        assert!(!non_zero.is_zero());
    }

    #[test]
    fn test_dollar_value_saturating_sub() {
        let a = DollarValue::from_bits(Fraction::from(10u64).to_bits());
        let b = DollarValue::from_bits(Fraction::from(50u64).to_bits());
        assert!(a.saturating_sub(b).is_zero());
    }

    #[test]
    fn test_dollar_value_apply_ratio_floor() {
        // 1/3 of $30 = $10
        let total = DollarValue::from(Fraction::from(30u64));
        let result = total.apply_ratio(
            Ratio::of(ShareAmount::from(1), ShareAmount::from(3)),
            RoundingMethod::Floor,
        );
        assert_eq!(result, DollarValue::from(Fraction::from(10u64)));
    }

    #[test]
    fn test_dollar_value_apply_ratio_ceil() {
        // 1/3 of $10 = $3.333... → ceil > 3.333
        let total = DollarValue::from(Fraction::from(10u64));
        let result = total.apply_ratio(
            Ratio::of(ShareAmount::from(1), ShareAmount::from(3)),
            RoundingMethod::Ceil,
        );
        let three = DollarValue::from(Fraction::from(3u64));
        let four = DollarValue::from(Fraction::from(4u64));
        assert!(result > three);
        assert!(result <= four);
    }

    fn dollar_value(value: u64) -> DollarValue {
        DollarValue::from(Fraction::from(value))
    }

    fn negative_net_aum(value: u64) -> NetAum {
        NetAum {
            abs_value: dollar_value(value),
            negative: true,
        }
    }

    #[test]
    fn test_net_aum_sub_positive_operands() {
        assert_eq!(
            NetAum::from(dollar_value(100)) - NetAum::from(dollar_value(30)),
            NetAum::from(dollar_value(70))
        );
        assert_eq!(
            NetAum::from(dollar_value(30)) - NetAum::from(dollar_value(100)),
            negative_net_aum(70)
        );
        assert_eq!(
            NetAum::from(dollar_value(5)) - NetAum::from(dollar_value(5)),
            NetAum::ZERO
        );
    }

    #[test]
    fn test_net_aum_sub_negative_operands() {
        assert_eq!(
            negative_net_aum(50) - negative_net_aum(20),
            negative_net_aum(30)
        );
        assert_eq!(
            negative_net_aum(20) - negative_net_aum(50),
            NetAum::from(dollar_value(30))
        );
    }

    #[test]
    fn test_net_aum_sub_mixed_signs() {
        assert_eq!(
            NetAum::from(dollar_value(30)) - negative_net_aum(20),
            NetAum::from(dollar_value(50))
        );
        assert_eq!(
            negative_net_aum(30) - NetAum::from(dollar_value(20)),
            negative_net_aum(50)
        );
    }

    // ─── TokenPrice ──────────────────────────────────────────────────────────────

    #[test]
    fn test_tokens_to_aum_usdc_1_dollar() {
        // 1000 USDC at $1, 6 decimals → $1000
        let price = TokenPrice::new(Fraction::from(1u64), 6);
        let tokens = TokenAmount::from(1_000_000_000); // 1000 USDC (6 dec)
        let aum = tokens.to_aum(&price, RoundingMethod::Floor);
        let expected = DollarValue::from_bits(Fraction::from(1000u64).to_bits());
        assert_eq!(aum, expected);
    }

    #[test]
    fn test_tokens_to_aum_eth_2000_dollar() {
        // 0.5 ETH at $2000, 9 decimals → $1000
        let price = TokenPrice::new(Fraction::from(2000u64), 9);
        let tokens = TokenAmount::from(500_000_000); // 0.5 ETH (9 dec)
        let aum = tokens.to_aum(&price, RoundingMethod::Floor);
        let expected = DollarValue::from_bits(Fraction::from(1000u64).to_bits());
        assert_eq!(aum, expected);
    }

    #[test]
    fn test_aum_to_tokens_roundtrip() {
        // Start with 1000 USDC, convert to AUM, convert back
        let price = TokenPrice::new(Fraction::from(1u64), 6);
        let original = TokenAmount::from(1_000_000_000);
        let aum = original.to_aum(&price, RoundingMethod::Floor);
        let recovered = aum.to_tokens(&price, RoundingMethod::Floor);
        assert_eq!(recovered, original);
    }

    #[test]
    fn test_aum_to_tokens_floor_vs_ceil() {
        // $1 of a $3 token, 6 decimals → 333333.333...
        // floor = 333333, ceil = 333334
        let price = TokenPrice::new(Fraction::from(3u64), 6);
        let aum = DollarValue::from_bits(Fraction::from(1u64).to_bits());
        let floor = aum.to_tokens(&price, RoundingMethod::Floor);
        let ceil = aum.to_tokens(&price, RoundingMethod::Ceil);
        assert_eq!(floor, TokenAmount::from(333_333));
        assert_eq!(ceil, TokenAmount::from(333_334));
    }

    // ─── TokenAmount::apply_ratio ────────────────────────────────────────────────

    #[test]
    fn test_apply_ratio_5_pct() {
        // 500 bps = 5%; apply to 10000 tokens → 500
        let ratio: Ratio<u64> = Ratio::from_bps(500);
        let result = TokenAmount::from(10_000).apply_ratio(ratio, RoundingMethod::Ceil);
        assert_eq!(result, TokenAmount::from(500));
    }

    #[test]
    fn test_apply_ratio_above_unity() {
        // 10500/10000 = 1.05; apply to 10000 → 10500
        let ratio = Ratio::of(10_500u64, 10_000u64);
        let result = TokenAmount::from(10_000).apply_ratio(ratio, RoundingMethod::Ceil);
        assert_eq!(result, TokenAmount::from(10_500));
    }

    #[test]
    fn test_apply_ratio_below_unity() {
        // 9500/10000 = 0.95; apply to 10000 → 9500
        let ratio = Ratio::of(9_500u64, 10_000u64);
        let result = TokenAmount::from(10_000).apply_ratio(ratio, RoundingMethod::Floor);
        assert_eq!(result, TokenAmount::from(9_500));
    }

    // ─── Ratio<N> ────────────────────────────────────────────────────────────────

    #[test]
    #[should_panic(expected = "Cannot create a ratio with zero denominator")]
    fn test_ratio_zero_denominator_panics() {
        Ratio::of(1u64, 0u64);
    }

    #[test]
    fn test_ratio_complement() {
        // complement of 1/2 should yield a ratio equivalent to 1/2
        let r = Ratio::of(1u64, 2u64);
        let c = r.complement().unwrap();
        // Verify via full_mul: complement(1/2) applied to 100 = 50
        assert_eq!(
            c.full_mul(Fraction::from(100u64), RoundingMethod::Floor),
            Fraction::from(50u64)
        );

        // complement of ratio > 1 returns None
        assert!(Ratio::of(3u64, 2u64).complement().is_none());

        // complement of 1/1 = 0
        let c2 = Ratio::of(1u64, 1u64).complement().unwrap();
        assert_eq!(
            c2.full_mul(Fraction::from(100u64), RoundingMethod::Floor),
            Fraction::from(0u64)
        );
    }

    #[test]
    fn test_ratio_reverse() {
        // reverse of 1/4 = 1/(4-1) = 1/3
        let r = Ratio::of(1u64, 4u64);
        let rev = r.reverse().unwrap();
        // 1/3 applied to 300 = 100
        assert_eq!(
            rev.full_mul(Fraction::from(300u64), RoundingMethod::Floor),
            Fraction::from(100u64)
        );

        // reverse of ratio > 1 returns None (denominator - numerator underflows)
        assert!(Ratio::of(3u64, 2u64).reverse().is_none());
    }

    #[test]
    fn test_ratio_full_mul() {
        // Ratio 1/2 applied to Fraction(100) = 50
        let r = Ratio::of(1u64, 2u64);
        let result = r.full_mul(Fraction::from(100u64), RoundingMethod::Floor);
        assert_eq!(result, Fraction::from(50u64));
    }

    #[test]
    fn test_ratio_limit_at_most() {
        let big: Ratio<u64> = Ratio::from_bps(8000); // 80%
        let cap: Ratio<u64> = Ratio::from_bps(5000); // 50%
        let clamped = big.limit_at_most(cap);
        // clamped applied to 100 should give 50, not 80
        assert_eq!(
            clamped.full_mul(Fraction::from(100u64), RoundingMethod::Floor),
            Fraction::from(50u64)
        );

        // already below cap — unchanged
        let small: Ratio<u64> = Ratio::from_bps(3000); // 30%
        let unchanged = small.limit_at_most(cap);
        assert_eq!(
            unchanged.full_mul(Fraction::from(100u64), RoundingMethod::Floor),
            Fraction::from(30u64)
        );
    }

    #[test]
    fn test_ratio_mul() {
        // (1/2) * (3/4) = 3/8; applied to 800 = 300
        let a = Ratio::of(1u64, 2u64);
        let b = Ratio::of(3u64, 4u64);
        let product = a * b;
        assert_eq!(
            product.full_mul(Fraction::from(800u64), RoundingMethod::Floor),
            Fraction::from(300u64)
        );
    }

    #[test]
    fn test_ratio_add() {
        // (1/4) + (1/4) = 1/2; applied to 100 = 50
        let a = Ratio::of(1u64, 4u64);
        let sum = a + a;
        assert_eq!(
            sum.full_mul(Fraction::from(100u64), RoundingMethod::Floor),
            Fraction::from(50u64)
        );
    }

    #[test]
    fn test_ratio_sub() {
        // (3/4) - (1/4) = 1/2; applied to 100 = 50
        let a = Ratio::of(3u64, 4u64);
        let b = Ratio::of(1u64, 4u64);
        let diff = a - b;
        assert_eq!(
            diff.full_mul(Fraction::from(100u64), RoundingMethod::Floor),
            Fraction::from(50u64)
        );
    }

    #[test]
    fn test_ratio_ord() {
        assert!(Ratio::<u64>::from_bps(500) < Ratio::from_bps(1000));
        assert!(Ratio::<u64>::from_bps(1000) > Ratio::from_bps(500));
        assert_eq!(Ratio::<u64>::from_bps(500), Ratio::from_bps(500));
        // Cross-denominator: 1/3 < 1/2
        assert!(Ratio::of(1u64, 3u64) < Ratio::of(1u64, 2u64));
    }

    // ─── RebalanceBounds ─────────────────────────────────────────────────────────

    #[test]
    fn test_rebalance_bounds_lerp() {
        let bounds = RebalanceBounds {
            start_price_rate: Ratio::from_bps(9500), // 0.95
            end_price_rate: Ratio::from_bps(10500),  // 1.05
        };
        let base_price = TokenPrice::new(Fraction::from(10_000u64), 0);

        // At t=0: should be start_price_rate (0.95 * 10000 = 9500)
        let at_start = bounds.clone().adjust_price_after(
            &base_price,
            Ratio::of(Duration::from(0), Duration::from(100)),
            RoundingMethod::Floor,
        );
        assert_eq!(at_start.price(), Fraction::from(9_500u64));

        // At t=duration: should be end_price_rate (1.05 * 10000 = 10500)
        let at_end = bounds.clone().adjust_price_after(
            &base_price,
            Ratio::of(Duration::from(100), Duration::from(100)),
            RoundingMethod::Floor,
        );
        assert_eq!(at_end.price(), Fraction::from(10_500u64));

        // At t=duration/2: midpoint of 0.95 and 1.05 is 1.0 → 10000
        let at_mid = bounds.adjust_price_after(
            &base_price,
            Ratio::of(Duration::from(50), Duration::from(100)),
            RoundingMethod::Floor,
        );
        assert_eq!(at_mid.price(), Fraction::from(10_000u64));
    }

    proptest! {
        #![proptest_config(ProptestConfig {
            cases: 10_000,
            max_global_rejects: 100_000,
            ..Default::default()
        })]

        /// P2-02: on non-integral adjusted prices, sell-side Ceil rounding must be
        /// vault-favorable: it yields no more tokens out than Floor rounding for the same AUM.
        #[test]
        fn test_rebalance_bounds_sell_side_ceil_is_vault_favorable(
            base_price_num in 1_u64..1_000_000,
            base_price_den in 1_u64..10_000,
            rate_num in 1_u64..20_000,
            rate_den in 1_u64..20_000,
            decimals in 0_u8..10,
        ) {
            let bounds = RebalanceBounds {
                start_price_rate: Ratio::of(rate_num, rate_den),
                end_price_rate: Ratio::of(rate_num, rate_den),
            };
            let base_price = TokenPrice::new(
                Fraction::from(base_price_num) / Fraction::from(base_price_den),
                decimals,
            );
            let elapsed = Ratio::of(Duration::from(1), Duration::from(2));

            let floor_price =
                bounds
                    .clone()
                    .adjust_price_after(&base_price, elapsed, RoundingMethod::Floor);
            let ceil_price =
                bounds.adjust_price_after(&base_price, elapsed, RoundingMethod::Ceil);

            prop_assume!(ceil_price.price() > floor_price.price());

            let fixed_aum = DollarValue::from(Fraction::from(1_000_000u64));
            let tokens_out_with_floor_price =
                fixed_aum.to_tokens(&floor_price, RoundingMethod::Floor);
            let tokens_out_with_ceil_price =
                fixed_aum.to_tokens(&ceil_price, RoundingMethod::Floor);

            prop_assert!(
                tokens_out_with_ceil_price <= tokens_out_with_floor_price,
                "ceil sell-side price must not increase tokens out: floor_price={} ceil_price={} floor_out={} ceil_out={}",
                floor_price.price(),
                ceil_price.price(),
                tokens_out_with_floor_price,
                tokens_out_with_ceil_price
            );
        }
    }

    // ─── TokenPrice::apply_ratio ─────────────────────────────────────────────────

    #[test]
    fn test_token_price_apply_ratio() {
        // price=100, ratio=10500/10000 (1.05) → price=105
        let base_price = TokenPrice::new(Fraction::from(100u64), 6);
        let ratio = Ratio::of(10_500u64, 10_000u64);
        let scaled = base_price.apply_ratio(ratio, RoundingMethod::Floor);
        assert_eq!(scaled.price(), Fraction::from(105u64));
        assert_eq!(scaled.decimals(), 6);
    }

    #[test]
    fn test_token_price_apply_ratio_from_bps() {
        // price=100, ratio=500/10000 (5%) → price=5
        let base_price = TokenPrice::new(Fraction::from(100u64), 6);
        let scaled = base_price.apply_ratio(Ratio::<u64>::from_bps(500), RoundingMethod::Floor);
        assert_eq!(scaled.price(), Fraction::from(5u64));
        assert_eq!(scaled.decimals(), 6);
    }

    // ─── MinFeeSpec ──────────────────────────────────────────────────────────────

    #[test]
    fn test_min_fee_spec_bps_wins_when_larger() {
        // 10% of 10000 = 1000, lamport min = 5 → bps wins
        let fee_spec = MinFeeSpec::new(Ratio::from_bps(1000), TokenAmount::from(5));
        let fee = fee_spec.calculate_fee_from(TokenAmount::from(10_000));
        assert_eq!(fee, TokenAmount::from(1_000));
    }

    #[test]
    fn test_min_fee_spec_lamports_wins_when_larger() {
        // 1% of 100 = 1, lamport min = 50 → lamports win
        let fee_spec = MinFeeSpec::new(Ratio::from_bps(100), TokenAmount::from(50));
        let fee = fee_spec.calculate_fee_from(TokenAmount::from(100));
        assert_eq!(fee, TokenAmount::from(50));
    }

    #[test]
    fn test_min_fee_spec_combine_max_takes_max_of_each_dimension() {
        // global: 500 bps, 10 lamports
        // vault:  200 bps, 20 lamports
        // resolved: 500 bps, 20 lamports
        let global = MinFeeSpec::new(Ratio::from_bps(500), TokenAmount::from(10));
        let vault = MinFeeSpec::new(Ratio::from_bps(200), TokenAmount::from(20));
        let resolved = MinFeeSpec::combine_max(global, vault);

        // Apply to a large amount where bps dominates to verify ratio dimension
        let fee_large = resolved.calculate_fee_from(TokenAmount::from(100_000));
        // 500 bps of 100_000 = 5_000; 20 lamports → bps wins
        assert_eq!(fee_large, TokenAmount::from(5_000));

        // Apply to a tiny amount where lamports dominate
        let fee_small = resolved.calculate_fee_from(TokenAmount::from(1));
        // 500 bps of 1 = 1 (ceil); 20 lamports → lamports win
        assert_eq!(fee_small, TokenAmount::from(20));
    }

    #[test]
    fn test_min_fee_spec_zero_amount() {
        let spec = MinFeeSpec::new(Ratio::from_bps(1000), TokenAmount::from(5));
        let fee = spec.calculate_fee_from(TokenAmount::ZERO);
        // 10% of 0 = 0, min lamports = 5 → lamports win
        assert_eq!(fee, TokenAmount::from(5));
    }

    // ─── RebalanceState ───────────────────────────────────────────────────

    fn usd(value: u64) -> DollarValue {
        DollarValue::from(Fraction::from(value))
    }

    fn started(max_loss_bps: u64, value: DollarValue) -> RebalanceState {
        started_with(u64::from(FULL_BPS), max_loss_bps, value)
    }

    fn started_with(
        max_fill_slippage_bps: u64,
        max_loss_bps: u64,
        value: DollarValue,
    ) -> RebalanceState {
        let limits = RebalanceLimits {
            max_fill_slippage_bps,
            max_loss_bps,
        };
        RebalanceState::started(Timestamp::from(1_000), Duration::from(3_600), value, limits)
    }

    // A fill of the whole basket, so that no per-fill limit can bind.
    fn lose(
        rebalance: &mut RebalanceState,
        loss: DollarValue,
        value_before: DollarValue,
    ) -> anchor_lang::Result<()> {
        rebalance.record_fill(value_before, value_before, value_before - loss)
    }

    #[test]
    fn test_loss_ceiling_caps_the_sum_of_fills_at_the_start_value() {
        // 1% of $1000 opened: $10 in total, however the fills split it.
        let mut rebalance = started(100, usd(1000));
        lose(&mut rebalance, usd(6), usd(1000)).unwrap();
        lose(&mut rebalance, usd(4), usd(994)).unwrap();
        assert_eq!(rebalance.lost(), usd(10));
        assert_eq!(
            lose(&mut rebalance, usd(1), usd(990)).unwrap_err(),
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        assert_eq!(rebalance.lost(), usd(10));
    }

    #[test]
    fn test_prior_losses_do_not_shrink_their_own_allowance() {
        // $9 lost already, $991 left: 1% of $991 alone would refuse the last $1.
        let mut rebalance = started(100, usd(1000));
        lose(&mut rebalance, usd(9), usd(1000)).unwrap();
        lose(&mut rebalance, usd(1), usd(991)).unwrap();
    }

    #[test]
    fn test_loss_ceiling_is_not_raised_by_an_inflow() {
        // The basket doubles after the start, the ceiling stays at 1% of what it started with.
        let mut rebalance = started(100, usd(1000));
        assert_eq!(
            lose(&mut rebalance, usd(11), usd(2000)).unwrap_err(),
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        lose(&mut rebalance, usd(10), usd(2000)).unwrap();
    }

    #[test]
    fn test_loss_ceiling_is_lowered_by_an_outflow() {
        // Down to $100 after the start: 1% of what remains ($1), not of what it started with.
        let mut rebalance = started(100, usd(1000));
        assert_eq!(
            lose(&mut rebalance, usd(2), usd(100)).unwrap_err(),
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        lose(&mut rebalance, usd(1), usd(100)).unwrap();
    }

    #[test]
    fn test_a_zero_max_loss_refuses_any_loss() {
        let mut rebalance = started(0, usd(1000));
        assert_eq!(
            lose(&mut rebalance, DollarValue::from_bits(1), usd(1000)).unwrap_err(),
            KaminoVaultError::RebalanceLossCeilingExceeded.into()
        );
        lose(&mut rebalance, DollarValue::ZERO, usd(1000)).unwrap();
    }

    #[test]
    fn test_a_full_max_loss_admits_losing_the_whole_basket() {
        // The current ceiling never binds at 100%: $1000 lost over fills, down to nothing.
        let mut rebalance = started(u64::from(FULL_BPS), usd(1000));
        lose(&mut rebalance, usd(600), usd(1000)).unwrap();
        lose(&mut rebalance, usd(400), usd(400)).unwrap();
        assert_eq!(rebalance.lost(), usd(1000));
    }

    #[test]
    fn test_fill_slippage_caps_each_fill_at_its_input_value() {
        // 1% of a $100 input: $1 per fill, however much the rebalance may still lose.
        let mut rebalance = started_with(100, u64::from(FULL_BPS), usd(1000));
        assert_eq!(
            rebalance
                .record_fill(usd(100), usd(1000), usd(998))
                .unwrap_err(),
            KaminoVaultError::RebalanceSwapExceedsMaxLoss.into()
        );
        assert_eq!(rebalance.lost(), DollarValue::ZERO);
        rebalance
            .record_fill(usd(100), usd(1000), usd(999))
            .unwrap();
        assert_eq!(rebalance.lost(), usd(1));
    }

    #[test]
    fn test_a_fill_gaining_value_records_no_loss() {
        let mut rebalance = started_with(0, 0, usd(1000));
        rebalance
            .record_fill(usd(100), usd(1000), usd(1001))
            .unwrap();
        assert_eq!(rebalance.lost(), DollarValue::ZERO);
    }
}

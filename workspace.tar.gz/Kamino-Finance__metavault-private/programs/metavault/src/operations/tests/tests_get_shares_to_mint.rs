use kamino_lending::{fraction::Fraction, utils::FractionExtra};
use proptest::prelude::*;

use crate::operations::vault_operations::common::get_shares_to_mint;
use crate::types::{DollarValue, ShareAmount, TokenAmount, TokenPrice};

use kamino_lending::assert_fuzzy_eq;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1_000_000))]
    #[test]
    fn test_get_shares_to_mint(
        holdings_total_sum in 10.0_f64..100_000_000.0,
        token_amount_to_deposit_lamports in 1_000_000_u64..100_000_000_000_000,
        shares_issued_lamports in 100_u64..100_000_000_000) {
        let token_total_holdings = DollarValue::from(Fraction::from_num(holdings_total_sum));

        let shares_to_mint = get_shares_to_mint(
            token_total_holdings,
            TokenAmount::from(token_amount_to_deposit_lamports),
            ShareAmount::from(shares_issued_lamports),
            &TokenPrice::new(Fraction::ONE, 6),
        );

        let expected_shares_to_mint = test_compute_shares_to_mint(
            Fraction::from_num(holdings_total_sum),
            token_amount_to_deposit_lamports,
            shares_issued_lamports,
            Fraction::ONE,
            6
        );
        // allow 1 lamport diff as in our test function we do division first and then multiplication so we can lose 1 lamport of precision
        assert_fuzzy_eq!(u64::from(shares_to_mint), expected_shares_to_mint, 1);
    }
}

#[test]
fn test_get_shares_to_mint_specific_case_1() {
    let holding_sum = 1.0;
    let token_amount_to_deposit_lamports = 5_214_000_000;
    let shares_issued_lamports = 56606809585603;
    let token_total_holdings = DollarValue::from(Fraction::from_num(holding_sum));

    let shares_to_mint = get_shares_to_mint(
        token_total_holdings,
        TokenAmount::from(token_amount_to_deposit_lamports),
        ShareAmount::from(shares_issued_lamports),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    let expected_shares_to_mint = test_compute_shares_to_mint(
        Fraction::from_num(holding_sum),
        token_amount_to_deposit_lamports,
        shares_issued_lamports,
        Fraction::ONE,
        6,
    );
    assert_eq!(shares_to_mint, ShareAmount::from(expected_shares_to_mint));
}

#[test]
fn test_get_shares_to_mint_specific_case_2() {
    let holding_sum = 1.0;
    let token_amount_to_deposit_lamports = 18_768_000_000;
    let shares_issued_lamports = 9828827831267;
    let token_total_holdings = DollarValue::from(Fraction::from_num(holding_sum));

    let shares_to_mint = get_shares_to_mint(
        token_total_holdings,
        TokenAmount::from(token_amount_to_deposit_lamports),
        ShareAmount::from(shares_issued_lamports),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    let expected_shares_to_mint = test_compute_shares_to_mint(
        Fraction::from_num(holding_sum),
        token_amount_to_deposit_lamports,
        shares_issued_lamports,
        Fraction::ONE,
        6,
    );
    assert_eq!(shares_to_mint, ShareAmount::from(expected_shares_to_mint));
}

#[test]
fn test_get_shares_to_mint_specific_case_3() {
    let holding_sum = 1.0;
    let token_amount_to_deposit_lamports = 193_056_832_925_000_000;
    let shares_issued_lamports = 1521533;
    let token_total_holdings = DollarValue::from(Fraction::from_num(holding_sum));

    let shares_to_mint = get_shares_to_mint(
        token_total_holdings,
        TokenAmount::from(token_amount_to_deposit_lamports),
        ShareAmount::from(shares_issued_lamports),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    let expected_shares_to_mint = test_compute_shares_to_mint(
        Fraction::from_num(holding_sum),
        token_amount_to_deposit_lamports,
        shares_issued_lamports,
        Fraction::ONE,
        6,
    );
    assert_eq!(shares_to_mint, ShareAmount::from(expected_shares_to_mint));
}

#[test]
#[should_panic(expected = "Cannot create a ratio with zero denominator")]
fn test_zero_aum_with_existing_shares_panics() {
    get_shares_to_mint(
        DollarValue::from(Fraction::ZERO),
        TokenAmount::from(1_000_000),
        ShareAmount::from(100_000_000),
        &TokenPrice::new(Fraction::ONE, 6),
    );
}

#[test]
fn test_standard_deposit_calculation() {
    let result = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(1000)),
        TokenAmount::from(100_000_000),
        ShareAmount::from(100_000_000),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    // Depositing $100 into $1000 vault should mint 10 shares
    // (100 shares * $100 deposit) / $1000 vault = 10 shares
    assert_eq!(result, ShareAmount::from(10_000_000)); // 10 shares
}

#[test]
fn test_different_token_prices() {
    struct TestCase {
        token_price: f64,
        tokens_to_deposit: u64,
        expected_shares_ratio: f64, // Expected shares as ratio of existing
    }

    let test_cases = vec![
        TestCase {
            token_price: 2500.0,
            tokens_to_deposit: 1_000_000, // 1 token
            expected_shares_ratio: 2.5,   // $2500 deposit into $1000 vault = 2.5x shares
        },
        TestCase {
            token_price: 0.01,
            tokens_to_deposit: 10_000_000_000, // 10,000 tokens
            expected_shares_ratio: 0.1,        // $100 deposit into $1000 vault = 0.1x shares
        },
        TestCase {
            token_price: 1.337,
            tokens_to_deposit: 74_796_918,     // ~74.8 tokens for ~$100
            expected_shares_ratio: 0.10000347, // ~$100 deposit into $1000 vault = 0.1x shares
        },
    ];

    for test_case in test_cases {
        let result = get_shares_to_mint(
            DollarValue::from(Fraction::from_num(1000)),
            TokenAmount::from(test_case.tokens_to_deposit),
            ShareAmount::from(100_000_000),
            &TokenPrice::new(Fraction::from_num(test_case.token_price), 6),
        );

        let expected_shares = (100.0 * test_case.expected_shares_ratio * 1_000_000.0) as u64;

        assert_eq!(result, ShareAmount::from(expected_shares));
    }
}

#[test]
fn test_get_shares_to_mint_zero_price() {
    let result = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(1000.0)),
        TokenAmount::from(1_000_000),
        ShareAmount::from(100_000_000),
        &TokenPrice::new(Fraction::ZERO, 6),
    );
    assert_eq!(result, ShareAmount::from(0));
}

#[test]
fn test_different_token_decimals() {
    struct TestCase {
        decimals: u8,
        tokens_amount: u64, // Always represents 100 tokens
    }

    let test_cases = vec![
        TestCase {
            decimals: 6,
            tokens_amount: 100_000_000,
        },
        TestCase {
            decimals: 8,
            tokens_amount: 10_000_000_000,
        },
        TestCase {
            decimals: 9,
            tokens_amount: 100_000_000_000,
        },
        TestCase {
            decimals: 12,
            tokens_amount: 100_000_000_000_000,
        },
    ];

    for test in test_cases {
        let result = get_shares_to_mint(
            DollarValue::from(Fraction::from_num(1000)),
            TokenAmount::from(test.tokens_amount),
            ShareAmount::from(10u64.pow(test.decimals as u32) * 10),
            &TokenPrice::new(Fraction::ONE, test.decimals),
        );

        // Should mint 10 shares for $100 deposit into $1000 vault
        let expected = 10u64.pow(test.decimals as u32);
        assert_eq!(result, ShareAmount::from(expected));
    }
}

#[test]
fn test_precision_edge_cases() {
    let result = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(1_000_000_000)),
        TokenAmount::from(1),
        ShareAmount::from(1_000_000_000_000),
        &TokenPrice::new(Fraction::from_num(1_000_000), 6),
    );

    // Even tiny deposits should mint at least some shares due to floor rounding
    // 1 lamport * $1M price / 1M decimals = $1 deposit
    // $1 / $1B AUM * 1T shares = 1000 shares
    assert_eq!(result, ShareAmount::from(1000));
}

#[test]
fn test_large_deposit_scenarios() {
    let result = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(1000)),
        TokenAmount::from(5_000_000_000),
        ShareAmount::from(100_000_000),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    // $5000 deposit into $1000 vault should mint 500 shares
    // (100 shares * $5000) / $1000 = 500 shares
    assert_eq!(result, ShareAmount::from(500_000_000));
}

#[test]
fn test_rounding_behavior_consistency() {
    let vault_aum = DollarValue::from(Fraction::from_num(3));
    let shares_issued = ShareAmount::from(7);
    let deposit_amount = TokenAmount::from(1_000_000);

    let result = get_shares_to_mint(
        vault_aum,
        deposit_amount,
        shares_issued,
        &TokenPrice::new(Fraction::ONE, 6),
    );

    // (7 shares * $1 deposit) / $3 vault = 2.333... shares
    // Floor rounding should give us 2 shares
    assert_eq!(result, ShareAmount::from(2));
}

#[test]
fn test_equivalent_deposit_ratios() {
    let base_case = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(1000)),
        TokenAmount::from(100_000_000),
        ShareAmount::from(100_000_000),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    let double_case = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(2000)),
        TokenAmount::from(200_000_000),
        ShareAmount::from(200_000_000),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    // Both should mint the same proportion: 10% of existing shares
    assert_eq!(base_case, ShareAmount::from(10_000_000)); // 10 shares
    assert_eq!(double_case, ShareAmount::from(20_000_000)); // 20 shares (proportional)
}

#[test]
fn test_zero_deposit_amount() {
    let result = get_shares_to_mint(
        DollarValue::from(Fraction::from_num(1000)),
        TokenAmount::from(0),
        ShareAmount::from(100_000_000),
        &TokenPrice::new(Fraction::ONE, 6),
    );

    // Zero deposit should mint zero shares
    assert_eq!(result, ShareAmount::from(0));
}

#[test]
fn test_token_shares_decimal_mismatch() {
    // Test scenarios where token decimals != share decimals
    struct TestCase {
        token_decimals: u8,
        token_amount: u64,
        shares_issued: u64,
        vault_aum: u64,
        expected_shares: u64,
    }

    let test_cases = vec![
        TestCase {
            token_decimals: 9,
            token_amount: 100_000_000_000,
            shares_issued: 100_000_000,
            vault_aum: 1000,
            expected_shares: 10_000_000,
        },
        TestCase {
            token_decimals: 2,
            token_amount: 10_000,
            shares_issued: 100_000_000,
            vault_aum: 1000,
            expected_shares: 10_000_000,
        },
        TestCase {
            token_decimals: 12,
            token_amount: 100_000_000_000_000,
            shares_issued: 100_000_000,
            vault_aum: 1000,
            expected_shares: 10_000_000,
        },
        TestCase {
            token_decimals: 2,
            token_amount: 1, // 0.01 tokens (smallest unit)
            shares_issued: 1_000_000_000_000,
            vault_aum: 1000,
            expected_shares: 9_999_999,
        },
        TestCase {
            token_decimals: 18,
            token_amount: 1_000_000_000_000_000_000,
            shares_issued: 100_000_000,
            vault_aum: 1000,
            expected_shares: 100_000,
        },
    ];

    for test in test_cases {
        let result = get_shares_to_mint(
            DollarValue::from(Fraction::from_num(test.vault_aum)),
            TokenAmount::from(test.token_amount),
            ShareAmount::from(test.shares_issued),
            &TokenPrice::new(Fraction::ONE, test.token_decimals),
        );

        assert_eq!(result, ShareAmount::from(test.expected_shares));
    }
}

#[test]
fn test_token_shares_decimal_mismatch_same_shares_minted() {
    // Economic invariant test: same dollar value should produce identical shares
    // regardless of token decimal configuration
    let vault_aum = DollarValue::from(Fraction::from_num(1000));
    let shares_issued = ShareAmount::from(100_000_000);

    let invariant_cases = vec![
        (6, 50_000_000),          // 50 tokens (6 decimals)
        (9, 50_000_000_000),      // 50 tokens (9 decimals)
        (12, 50_000_000_000_000), // 50 tokens (12 decimals)
        (2, 5_000),               // 50 tokens (2 decimals)
    ];

    let mut invariant_results = Vec::new();
    for (decimals, token_amount) in invariant_cases {
        let result = get_shares_to_mint(
            vault_aum,
            TokenAmount::from(token_amount),
            shares_issued,
            &TokenPrice::new(Fraction::ONE, decimals),
        );
        invariant_results.push(u64::from(result));
    }

    // All should be identical (same $50 economic value)
    let first_result = invariant_results[0];
    for &result in invariant_results.iter().skip(1) {
        assert_eq!(result, first_result);
    }
}

fn test_compute_shares_to_mint(
    token_total_holdings: Fraction,
    token_amount: u64,
    shares_issued: u64,
    token_price: Fraction,
    token_decimals: u8,
) -> u64 {
    let token_to_deposit_aum = Fraction::from(token_amount) * token_price
        / Fraction::from(10u64.pow(token_decimals.into()));
    let shares_to_mint_f =
        (token_to_deposit_aum / token_total_holdings) * Fraction::from(shares_issued);
    shares_to_mint_f.to_floor()
}

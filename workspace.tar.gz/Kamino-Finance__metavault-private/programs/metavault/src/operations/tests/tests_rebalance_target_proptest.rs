use crate::operations::rebalance_basket::RebalanceBasket;
use crate::types::NetAum;
use std::collections::HashMap;

use proptest::prelude::*;

use super::tests_utils::{fixtures::setup_vault_with_tokens_and_config, TokenConfig};
use crate::operations::rebalance_operations;
use crate::types::{Duration, RoundingMethod, StartRebalanceAuthority, Timestamp};
use kamino_lending::fraction::Fraction;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(1_000_000))]

    #[test]
    fn test_rebalance_target_distribution_invariant(
        token_weights in prop::collection::vec(10_u64..1000, 4),
        initial_amounts in prop::collection::vec(1_000_u64..1_000_000_000, 4),
        operations in prop::collection::vec(
            prop_oneof![
                Just((true, 100_000_u64)),
                Just((true, 100_000_000_u64)),
                Just((false, 5_000_u64)),
                Just((false, 5_000_000_u64)),
            ],
            10
        ),
    ) {
        let tokens = HashMap::from_iter([
            ("BTC", TokenConfig::with_weight_price_available_decimals(
                token_weights[0], 50000.0, initial_amounts[0], 9
            )),
            ("ETH", TokenConfig::with_weight_price_available_decimals(
                token_weights[1], 3000.0, initial_amounts[1], 9
            )),
            ("SOL", TokenConfig::with_weight_price_available_decimals(
                token_weights[2], 100.0, initial_amounts[2], 9
            )),
            ("USDC", TokenConfig::with_weight_price_available_decimals(
                token_weights[3], 1.0, initial_amounts[3], 6
            )),
        ]);

        let (mut vault, _global_config, scope_prices) =
            setup_vault_with_tokens_and_config(&tokens, 0, 0);

        vault.rebalance.start_timestamp = 1_000_000;
        vault.rebalance.end_timestamp = 1_000_000 + 3600;

        let _result = rebalance_operations::start_rebalance(
            &mut vault,
            Duration::from(3600),
            &scope_prices,
            NetAum::ZERO,
            Timestamp::from(1_000_000),
            StartRebalanceAuthority::AllocationDelegate,
        );

        let initial_targets: Vec<u64> = vault
            .tokens().targets(&scope_prices)
            .iter()
            .map(u64::from)
            .collect();

        let mut initial_ratios = vec![];
        for i in 0..initial_targets.len() {
            for j in i+1..initial_targets.len() {
                if initial_targets[j] > 1_000_000 && initial_targets[i] > 1_000_000 {
                    let ratio = Fraction::from_num(initial_targets[i])
                        / Fraction::from_num(initial_targets[j]);
                    initial_ratios.push((i, j, ratio));
                }
            }
        }

        for (op_idx, &(is_deposit, amount)) in operations.iter().enumerate() {
            // Apply the simulated deposit/withdraw by mutating one token's `token_available`
            // (rotating through the enabled tokens). Targets are derived from the free AUM, so
            // they see the actual post-op state rather than a synthetic AUM.
            let token_idx = op_idx % 4;
            let token = &mut vault.vault_tokens[token_idx];
            if is_deposit {
                token.token_available = token.token_available.saturating_add(amount);
            } else {
                token.token_available = token.token_available.saturating_sub(amount);
            }

            let new_aum =
                Fraction::from(vault.compute_free_aum(&scope_prices, RoundingMethod::Floor));
            if new_aum < Fraction::from_num(100_000.0) {
                continue;
            }

            let current_targets: Vec<u64> = vault
                .tokens().targets(&scope_prices)
                .iter()
                .map(u64::from)
                .collect();

            for &(idx_i, idx_j, initial_ratio) in &initial_ratios {
                // Skip settled tokens (target zeroed)
                if current_targets[idx_j] <= 1_000_000 || current_targets[idx_i] <= 1_000_000 {
                    continue;
                }
                let current_ratio = Fraction::from_num(current_targets[idx_i])
                    / Fraction::from_num(current_targets[idx_j]);

                let ratio_diff = if current_ratio > initial_ratio {
                    current_ratio - initial_ratio
                } else {
                    initial_ratio - current_ratio
                };

                // Use relative error to handle extreme weight ratios
                let relative_error = ratio_diff / initial_ratio;
                let max_relative_error = Fraction::from_num(1e-6);
                prop_assert!(
                    relative_error <= max_relative_error,
                    "Ratio not preserved: initial {}, current {}, relative_err {}",
                    initial_ratio, current_ratio, relative_error
                );
            }
        }
    }
}

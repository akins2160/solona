use std::collections::HashMap;

use anchor_lang::Result;
use kamino_lending::fraction::Fraction;

use super::tests_utils::{fixtures::setup_vault_with_tokens_and_config, TokenConfig};
use crate::{
    operations::vault_operations::{self, WithdrawExchangeRateQuote},
    types::{DollarValue, NetAum, RoundingMethod, ShareAmount, Timestamp, TokenAmount},
    KaminoVaultError,
};

fn quote(
    vault: &crate::MetavaultState,
    prices: &crate::utils::scope::VaultScopePrices,
    config: &crate::GlobalConfig,
    mint: solana_program::pubkey::Pubkey,
) -> Result<WithdrawExchangeRateQuote> {
    vault_operations::quote_withdraw_exchange_rate(vault, prices, NetAum::ZERO, config, mint)
}

// The shared fixture seeds `INITIAL_DEPOSIT_SIZE` (1_000) shares against 1_000 USDC lamports, so the
// canonical one-whole-share unit (`10^6`) is clamped to the 1_000-share supply: every quote below
// redeems the full supply. Net AUM for 1_000 USDC lamports floors to 999 token lamports.
const SUPPLY: u64 = 1_000;
const GROSS_TOKENS: u64 = 999;

#[test]
fn quote_uses_token_specific_min_fee_over_global_min_fee() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 10, 0);
    vault.vault_tokens[0].withdraw_fee_lamports = 30;

    let quote = quote(&vault, &prices, &config, tokens["USDC"].mint).unwrap();

    // Token min fee (30) wins over the global min fee (10): net = 999 - 30.
    assert_eq!(quote.net_tokens_out, TokenAmount::new(GROSS_TOKENS - 30));
    assert_eq!(quote.quoted_shares, ShareAmount::new(SUPPLY));
    assert_eq!(quote.token_mint_decimals, 6);
    let expected_rate_bits = (Fraction::from(GROSS_TOKENS - 30) / Fraction::from(SUPPLY)).to_bits();
    assert_eq!(
        quote.rate.to_fraction_bits(RoundingMethod::Floor),
        expected_rate_bits
    );
}

#[test]
fn quote_applies_bps_fee() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 0, 1_000);

    let quote = quote(&vault, &prices, &config, tokens["USDC"].mint).unwrap();

    // 10% fee on 999 rounds up to 100: net = 999 - 100.
    assert_eq!(quote.net_tokens_out, TokenAmount::new(GROSS_TOKENS - 100));
    assert_eq!(quote.quoted_shares, ShareAmount::new(SUPPLY));
}

#[test]
fn quote_ignores_withdraw_target_bound() {
    let usdc = TokenConfig::with_price_and_decimals(1.0, 6);
    let usdt = TokenConfig::with_price_and_decimals(1.0, 6);
    let usdc_mint = usdc.mint;
    let tokens = HashMap::from_iter([("USDC", usdc), ("USDT", usdt)]);
    let (mut vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 0, 0);

    for token in vault.iter_mut_enabled_tokens() {
        token.token_available = 1_000_000_000;
        token.weight = 1;
        token.max_deviation_bps = 1_000;
    }

    let quote = quote(&vault, &prices, &config, usdc_mint).unwrap();

    // The full $2,000 AUM is redeemed in USDC despite the per-token target-weight bound.
    assert_eq!(quote.net_tokens_out, TokenAmount::new(2_000_000_000));
    assert!(quote.net_tokens_out > vault.vault_tokens[0].available());
}

#[test]
fn quote_ignores_available_liquidity() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 0, 0);
    // Almost all AUM sits in (illiquid) obligations; only 100 USDC lamports are on hand.
    vault.vault_tokens[0].token_available = 100;
    let obligations_aum = NetAum::from(DollarValue::from(Fraction::from(90u64)));

    let quote = vault_operations::quote_withdraw_exchange_rate(
        &vault,
        &prices,
        obligations_aum,
        &config,
        tokens["USDC"].mint,
    )
    .unwrap();

    // The quote redeems the full proportional claim even though it far exceeds the on-hand balance.
    assert!(quote.net_tokens_out > vault.vault_tokens[0].available());
}

#[test]
fn quote_matches_real_withdraw_when_unbounded() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 0, 500);
    vault.vault_tokens[0].weight = 1;
    vault.vault_tokens[0].max_deviation_bps = 10_000;

    let quote = quote(&vault, &prices, &config, tokens["USDC"].mint).unwrap();

    // A real withdraw of the same `quoted_shares` (no liquidity/bound binding, no pending fees)
    // must deliver exactly the quoted net tokens.
    let mut withdraw_vault = vault;
    let effects = vault_operations::withdraw(
        &mut withdraw_vault,
        &prices,
        NetAum::ZERO,
        &config,
        tokens["USDC"].mint,
        Timestamp::ZERO,
        quote.quoted_shares,
    )
    .unwrap();

    assert_eq!(effects.available_to_send_to_user, quote.net_tokens_out);
}

#[test]
fn quote_errs_when_min_fee_exceeds_gross() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    // A min fee (2_000) larger than the whole redeemable amount (999): the quote surfaces the same
    // error a real withdraw would, rather than reporting a misleading zero rate.
    let (vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 2_000, 0);

    let result = quote(&vault, &prices, &config, tokens["USDC"].mint);

    assert_eq!(
        result.unwrap_err(),
        KaminoVaultError::WithdrawAmountLessThanWithdrawalFee.into()
    );
}

#[test]
fn quote_errs_on_unknown_mint() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 0, 0);

    let result = quote(
        &vault,
        &prices,
        &config,
        solana_program::pubkey::Pubkey::new_unique(),
    );

    assert_eq!(
        result.unwrap_err(),
        KaminoVaultError::TokenNotEnabledInVault.into()
    );
}

#[test]
fn quote_errs_when_aum_not_positive() {
    let tokens = HashMap::from_iter([("USDC", TokenConfig::with_price_and_decimals(1.0, 6))]);
    let (mut vault, config, prices) = setup_vault_with_tokens_and_config(&tokens, 0, 0);
    // Drain on-hand liquidity and pass no obligations: net AUM is zero.
    vault.vault_tokens[0].token_available = 0;

    let result = quote(&vault, &prices, &config, tokens["USDC"].mint);

    assert_eq!(result.unwrap_err(), KaminoVaultError::VaultAUMZero.into());
}

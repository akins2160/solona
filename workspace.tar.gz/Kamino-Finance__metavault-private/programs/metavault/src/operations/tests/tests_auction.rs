#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use crate::{
        operations::rebalance_basket::RebalanceBasket,
        operations::{
            rebalance_operations::{self, FillRequest},
            tests::tests_utils::{
                fixtures::setup_vault_with_tokens, token_by_id, TokenConfig, EPSILON_F,
            },
        },
        state::{quote_swap, quote_swap_with_dutch_auction},
        types::{
            DollarValue, Duration, DutchAuctionBounds, DutchAuctionScales, NetAum, Ratio,
            RoundingMethod, StartRebalanceAuthority, Timestamp, TokenAmount, TokenPrice,
            VaultTokenId,
        },
        KaminoVaultError, VaultToken,
    };
    use anchor_lang::err;
    use kamino_lending::{assert_fuzzy_eq, fraction::Fraction, utils::FractionExtra};
    use proptest::prelude::*;
    use solana_program::pubkey::Pubkey;

    fn tokens_to_aum(tokens: u64, price: Fraction, decimals: u8) -> Fraction {
        Fraction::from(
            TokenAmount::from(tokens)
                .to_aum(&TokenPrice::new(price, decimals), RoundingMethod::Floor),
        )
    }

    fn auction_progress(
        current_timestamp: u64,
        auction_start_timestamp: u64,
        rebalance_duration: u64,
    ) -> Ratio<Duration> {
        Ratio::of(
            Timestamp::from(current_timestamp) - Timestamp::from(auction_start_timestamp),
            Duration::from(rebalance_duration),
        )
    }

    fn quote_swap_raw(
        amount_in: u64,
        token_in_price: Fraction,
        token_in_decimals: u8,
        token_out_price: Fraction,
        token_out_decimals: u8,
    ) -> anchor_lang::Result<u64> {
        quote_swap(
            TokenAmount::from(amount_in),
            &TokenPrice::new(token_in_price, token_in_decimals),
            &TokenPrice::new(token_out_price, token_out_decimals),
        )
        .map(Into::into)
    }

    fn quote_swap_with_dutch_auction_raw(
        progress: Ratio<Duration>,
        amount_in: u64,
        token_in_price: Fraction,
        token_out_price: Fraction,
        token_in: &VaultToken,
        token_out: &VaultToken,
    ) -> anchor_lang::Result<u64> {
        let bounds = DutchAuctionBounds {
            buying: token_in.dutch_auction_scales.buying_bounds(),
            selling: token_out.dutch_auction_scales.selling_bounds(),
        };
        quote_swap_with_dutch_auction(
            progress,
            TokenAmount::from(amount_in),
            &TokenPrice::new(token_in_price, token_in.decimals),
            &TokenPrice::new(token_out_price, token_out.decimals),
            &bounds,
        )
        .map(Into::into)
    }

    #[test]
    fn test_quote_swap_identity_same_token() {
        let amount_in = 1_000_000_000; // 1000 USDC
        let price = Fraction::from_num(1.0);
        let decimals = 6;
        let price_tp = TokenPrice::new(price, decimals);

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_tp, &price_tp)
            .unwrap()
            .into();

        assert_eq!(amount_out, amount_in);
    }

    #[test]
    fn test_quote_swap_equal_prices_different_decimals() {
        let amount_in = 1_000_000_000; // 1000 tokens with 6 decimals
        let price = Fraction::from_num(1.0);
        let price_in = TokenPrice::new(price, 6);
        let price_out = TokenPrice::new(price, 9);

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_in, &price_out)
            .unwrap()
            .into();

        assert_eq!(amount_out, 1_000_000_000_000); // 1000 tokens with 9 decimals
    }

    #[test]
    fn test_quote_swap_different_prices() {
        let amount_in = 1_000_000_000; // 1000 USDC (6 decimals)
        let price_in = TokenPrice::new(Fraction::from_num(1.0), 6);
        let price_out = TokenPrice::new(Fraction::from_num(100.0), 9); // SOL at $100

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_in, &price_out)
            .unwrap()
            .into();

        assert_eq!(amount_out, 10_000_000_000); // 10 SOL (9 decimals)
    }

    #[test]
    fn test_quote_swap_fractional_result_floors() {
        let amount_in = 1_000_000; // 1 USDC
        let price_in = TokenPrice::new(Fraction::from_num(1.0), 6);
        let price_out = TokenPrice::new(Fraction::from_num(3.0), 6); // Token worth $3

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_in, &price_out)
            .unwrap()
            .into();

        assert_eq!(amount_out, 333_333); // 0.333333 tokens (floored from 0.333...)
    }

    #[test]
    fn test_quote_swap_zero_amount() {
        let price_in = TokenPrice::new(Fraction::from_num(1.0), 6);
        let price_out = TokenPrice::new(Fraction::from_num(100.0), 9);

        let amount_out: u64 = quote_swap(TokenAmount::from(0), &price_in, &price_out)
            .unwrap()
            .into();

        assert_eq!(amount_out, 0);
    }

    #[test]
    fn test_quote_swap_one_lamport() {
        let price_in = TokenPrice::new(Fraction::from_num(1.0), 6);
        let price_out = TokenPrice::new(Fraction::from_num(1.0), 6);

        let result = quote_swap(TokenAmount::from(1), &price_in, &price_out);

        // 1 lamport with 6 decimals is 0.000001 token
        // Due to precision this rounds to 0
        assert_eq!(result, err!(KaminoVaultError::SwapQuoteRoundsToZero));
    }

    #[test]
    fn test_quote_swap_high_price_disparity() {
        let amount_in = 1_000_000; // 1 token (6 decimals)
        let price_in = TokenPrice::new(Fraction::from_num(100000.0), 6); // $100k per token
        let price_out = TokenPrice::new(Fraction::from_num(0.01), 6); // $0.01 per token

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_in, &price_out)
            .unwrap()
            .into();

        // 1 token * $100k / $0.01 = 10,000,000 tokens
        // Due to floor rounding, we might get 1 less
        let expected = 10_000_000_000_000u64;
        assert_fuzzy_eq!(amount_out, expected, 1);
    }

    #[test]
    fn test_quote_swap_small_fractional_prices() {
        let amount_in = 1_000_000_000; // 1000 tokens
        let price_in = TokenPrice::new(Fraction::from_num(0.0001), 6); // $0.0001 per token
        let price_out = TokenPrice::new(Fraction::from_num(0.99999), 6); // $0.99999 per token

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_in, &price_out)
            .unwrap()
            .into();

        assert_eq!(amount_out, 100_001);
    }

    #[test]
    fn test_quote_swap_max_decimals() {
        let amount_in = 1_000_000_000_000_000_000; // 1 token with 18 decimals
        let price_in = TokenPrice::new(Fraction::from_num(2000.0), 18); // ETH at $2000
        let price_out = TokenPrice::new(Fraction::from_num(1.0), 6); // USDC at $1

        let amount_out: u64 = quote_swap(TokenAmount::from(amount_in), &price_in, &price_out)
            .unwrap()
            .into();

        assert_eq!(amount_out, 2_000_000_000); // 2000 USDC
    }

    const ORACLE: u64 = 10_000; // 1.0x oracle in bps

    fn create_vault_token_with_scales(
        decimals: u8,
        start_scale_bps_when_buying: u64,
        end_scale_bps_when_buying: u64,
        start_scale_bps_when_selling: u64,
        end_scale_bps_when_selling: u64,
    ) -> VaultToken {
        VaultToken {
            mint: Pubkey::new_unique(),
            vault: Pubkey::new_unique(),
            token_program: Pubkey::new_unique(),
            decimals,
            dutch_auction_scales: DutchAuctionScales {
                start_scale_bps_when_buying,
                end_scale_bps_when_buying,
                start_scale_bps_when_selling,
                end_scale_bps_when_selling,
            },
            ..Default::default()
        }
    }

    fn create_vault_token_for_buying(
        decimals: u8,
        start_scale_bps: u64,
        end_scale_bps: u64,
    ) -> VaultToken {
        create_vault_token_with_scales(decimals, start_scale_bps, end_scale_bps, ORACLE, ORACLE)
    }

    fn create_vault_token_for_selling(
        decimals: u8,
        start_scale_bps: u64,
        end_scale_bps: u64,
    ) -> VaultToken {
        create_vault_token_with_scales(decimals, ORACLE, ORACLE, start_scale_bps, end_scale_bps)
    }

    #[test]
    fn test_quote_swap_dutch_auction_start() {
        // At auction start (t=0), vault gets worst prices:
        // - Buys at lowest price (100% - lower_bound_bps)
        // - Sells at highest price (100% + upper_bound_bps)
        let auction = auction_progress(0, 0, 3600); // current_time = 0, start = 0

        let token_in = create_vault_token_for_buying(
            6,     // decimals
            9500,  // start_scale_bps (0.95x oracle)
            10200, // end_scale_bps (1.02x oracle)
        );

        let token_out = create_vault_token_for_selling(
            9,     // decimals
            10400, // start_scale_bps (1.04x oracle)
            9700,  // end_scale_bps (0.97x oracle)
        );

        let amount_in = 1_000_000_000; // 1000 USDC
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let amount_out = quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in, price_out, &token_in, &token_out,
        )
        .unwrap();

        // At t=0:
        // token_in price = 1.0 * 0.95 = 0.95
        // token_out price = 100.0 * 1.04 = 104.0
        // Expected: 1000 * 0.95 / 104.0 = 9.134615... SOL
        let expected = 9_134_615_384u64;
        assert_fuzzy_eq!(amount_out, expected, 10);
    }

    #[test]
    fn test_quote_swap_dutch_auction_end() {
        // At auction end (t=duration), vault gets best prices
        let duration = 3600;
        let auction = auction_progress(duration, 0, duration);

        let token_in = create_vault_token_for_buying(
            6,     // decimals
            9500,  // start_scale_bps (0.95x oracle)
            10200, // end_scale_bps (1.02x oracle)
        );

        let token_out = create_vault_token_for_selling(
            9,     // decimals
            10400, // start_scale_bps (1.04x oracle)
            9700,  // end_scale_bps (0.97x oracle)
        );

        let amount_in = 1_000_000_000; // 1000 USDC
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let amount_out = quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in, price_out, &token_in, &token_out,
        )
        .unwrap();

        // At t=duration:
        // token_in price = 1.0 * 1.02 = 1.02
        // token_out price = 100.0 * 0.97 = 97.0
        // Expected: 1000 * 1.02 / 97.0 = 10.51546... SOL
        let expected = 10_515_463_917u64;
        assert_fuzzy_eq!(amount_out, expected, 10);
    }

    #[test]
    fn test_quote_swap_dutch_auction_middle() {
        // At middle of auction (t=duration/2), prices should be at midpoint
        let duration = 3600;
        let auction = auction_progress(duration / 2, 0, duration);

        let token_in = create_vault_token_for_buying(
            6,     // decimals
            9500,  // start_scale_bps (0.95x oracle)
            10200, // end_scale_bps (1.02x oracle)
        );

        let token_out = create_vault_token_for_selling(
            9,     // decimals
            10400, // start_scale_bps (1.04x oracle)
            9700,  // end_scale_bps (0.97x oracle)
        );

        let amount_in = 1_000_000_000; // 1000 USDC
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let amount_out = quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in, price_out, &token_in, &token_out,
        )
        .unwrap();

        // At t=duration/2:
        // token_in price = 1.0 * (0.95 + (1.02 - 0.95) / 2) = 1.0 * 0.985 = 0.985
        // token_out price = 100.0 * (1.04 - (1.04 - 0.97) / 2) = 100.0 * 1.005 = 100.5
        // Expected: 1000 * 0.985 / 100.5 = 9.80099... SOL
        let expected = 9_800_995_024u64;
        assert_fuzzy_eq!(amount_out, expected, 10);
    }

    #[test]
    fn test_quote_swap_dutch_auction_quarter_points() {
        // Test at 25% and 75% progress for precise interpolation
        let duration = 10000;

        // Test at 25% progress
        let auction_25 = auction_progress(2500, 0, duration);
        let token_in = create_vault_token_for_buying(6, 9000, 10500);
        let token_out = create_vault_token_for_selling(9, 10600, 9800);

        let amount_out_25 = quote_swap_with_dutch_auction_raw(
            auction_25,
            1_000_000_000,
            Fraction::from_num(1.0),
            Fraction::from_num(100.0),
            &token_in,
            &token_out,
        )
        .unwrap();

        // At 25%:
        // token_in: 1.0 * (0.9 + 0.25 * (1.05 - 0.9)) = 1.0 * 0.9375 = 0.9375
        // token_out: 100.0 * (1.06 - 0.25 * (1.06 - 0.98)) = 100.0 * 1.04 = 104.0
        // Expected: 1000 * 0.9375 / 104.0 = 9.014423... SOL
        let expected_25 = 9_014_423_076u64;
        assert_fuzzy_eq!(amount_out_25, expected_25, 10);

        // Test at 75% progress
        let auction_75 = auction_progress(7500, 0, duration);
        let amount_out_75 = quote_swap_with_dutch_auction_raw(
            auction_75,
            1_000_000_000,
            Fraction::from_num(1.0),
            Fraction::from_num(100.0),
            &token_in,
            &token_out,
        )
        .unwrap();

        // At 75%:
        // token_in: 1.0 * (0.9 + 0.75 * (1.05 - 0.9)) = 1.0 * 1.0125 = 1.0125
        // token_out: 100.0 * (1.06 - 0.75 * (1.06 - 0.98)) = 100.0 * 1.0 = 100.0
        // Expected: 1000 * 1.0125 / 100.0 = 10.125 SOL
        let expected_75 = 10_125_000_000u64;
        assert_fuzzy_eq!(amount_out_75, expected_75, 10);
    }

    #[test]
    fn test_quote_swap_dutch_auction_no_adjustment() {
        // With all bounds set to 1.0x oracle (no adjustment), should match regular quote_swap
        let auction = auction_progress(1800, 0, 3600); // midpoint

        let token_in = create_vault_token_for_buying(6, ORACLE, ORACLE);
        let token_out = create_vault_token_for_selling(9, ORACLE, ORACLE);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let amount_out_dutch = quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in, price_out, &token_in, &token_out,
        )
        .unwrap();

        let amount_out_regular = quote_swap_raw(
            amount_in,
            price_in,
            token_in.decimals,
            price_out,
            token_out.decimals,
        )
        .unwrap();

        assert_eq!(amount_out_dutch, amount_out_regular);
    }

    #[test]
    fn test_quote_swap_dutch_auction_asymmetric_bounds() {
        // Test with very different bounds for buy/sell sides
        let auction = auction_progress(1800, 0, 3600); // midpoint

        let token_in = create_vault_token_for_buying(
            6, 8000,  // start: 0.8x oracle
            10100, // end: 1.01x oracle
        );

        let token_out = create_vault_token_for_selling(
            9, 11500, // start: 1.15x oracle
            9950,  // end: 0.995x oracle
        );

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let amount_out = quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in, price_out, &token_in, &token_out,
        )
        .unwrap();

        // At midpoint:
        // token_in: 1.0 * (0.8 + 0.5 * (1.01 - 0.8)) = 1.0 * 0.905 = 0.905
        // token_out: 100.0 * (1.15 - 0.5 * (1.15 - 0.995)) = 100.0 * 1.0725 = 107.25
        // Expected: 1000 * 0.905 / 107.25 = 8.438228... SOL
        let expected = 8_438_228_438u64;
        assert_fuzzy_eq!(amount_out, expected, 10);
    }

    #[test]
    fn test_quote_swap_dutch_auction_past_duration() {
        // When elapsed > duration, should clamp to duration values
        let duration = 3600;
        let auction_past = auction_progress(7200, 0, duration); // 2x duration
        let auction_end = auction_progress(duration, 0, duration);

        let token_in = create_vault_token_for_buying(6, 9500, 10200);
        let token_out = create_vault_token_for_selling(9, 10400, 9700);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let amount_out_past = quote_swap_with_dutch_auction_raw(
            auction_past,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();

        let amount_out_end = quote_swap_with_dutch_auction_raw(
            auction_end,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();

        // Should be exactly the same
        assert_eq!(amount_out_past, amount_out_end);
    }

    #[test]
    fn test_quote_swap_dutch_auction_different_decimals() {
        // Test with various decimal combinations
        let auction = auction_progress(1800, 0, 3600);

        // 18 decimals to 6 decimals
        let token_in_18 = create_vault_token_for_buying(18, 9700, 10200);
        let token_out_6 = create_vault_token_for_selling(6, 10150, 9900);

        let amount_in = 1_000_000_000_000_000_000; // 1 token with 18 decimals
        let price_in = Fraction::from_num(2000.0); // ETH
        let price_out = Fraction::from_num(1.0); // USDC

        let amount_out = quote_swap_with_dutch_auction_raw(
            auction,
            amount_in,
            price_in,
            price_out,
            &token_in_18,
            &token_out_6,
        )
        .unwrap();

        // At midpoint:
        // token_in: 2000 * (0.97 + 0.5 * (1.02 - 0.97)) = 2000 * 0.995 = 1990
        // token_out: 1.0 * (1.015 - 0.5 * (1.015 - 0.99)) = 1.0 * 1.0025 = 1.0025
        // Expected: 1 * 1990 / 1.0025 = 1985.0374... USDC
        let expected = 1_985_037_406u64;
        assert_fuzzy_eq!(amount_out, expected, 10);
    }

    #[test]
    fn test_quote_swap_dutch_auction_zero_amount() {
        let auction = auction_progress(1800, 0, 3600);

        let token_in = create_vault_token_for_buying(6, 9500, 10200);
        let token_out = create_vault_token_for_selling(9, 10400, 9700);

        let amount_out = quote_swap_with_dutch_auction_raw(
            auction,
            0,
            Fraction::from_num(1.0),
            Fraction::from_num(100.0),
            &token_in,
            &token_out,
        )
        .unwrap();

        assert_eq!(amount_out, 0);
    }

    #[test]
    fn test_quote_swap_both_bounds_above_oracle_buy() {
        // Both buy bounds above oracle: 1.02x → 1.08x
        let duration = 3600;

        let token_in = create_vault_token_for_buying(6, 10200, 10800);
        let token_out = create_vault_token_for_selling(9, ORACLE, ORACLE);

        let amount_in = 1_000_000_000; // 1000 USDC
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        // At t=0: token_in price = 1.0 * 1.02 = 1.02
        let auction_start = auction_progress(0, 0, duration);
        let out_start = quote_swap_with_dutch_auction_raw(
            auction_start,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 1.02 / 100.0 = 10.2 SOL
        let expected_start = 10_200_000_000u64;
        assert_fuzzy_eq!(out_start, expected_start, 10);

        // At t=duration: token_in price = 1.0 * 1.08 = 1.08
        let auction_end = auction_progress(duration, 0, duration);
        let out_end = quote_swap_with_dutch_auction_raw(
            auction_end,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 1.08 / 100.0 = 10.8 SOL
        let expected_end = 10_800_000_000u64;
        assert_fuzzy_eq!(out_end, expected_end, 10);

        // Monotonicity: end >= start
        assert!(out_end >= out_start);
    }

    #[test]
    fn test_quote_swap_both_bounds_below_oracle_buy() {
        // Both buy bounds below oracle: 0.90x → 0.97x
        let duration = 3600;

        let token_in = create_vault_token_for_buying(6, 9000, 9700);
        let token_out = create_vault_token_for_selling(9, ORACLE, ORACLE);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        // At t=0: token_in price = 1.0 * 0.90 = 0.90
        let auction_start = auction_progress(0, 0, duration);
        let out_start = quote_swap_with_dutch_auction_raw(
            auction_start,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 0.90 / 100.0 = 9.0 SOL
        let expected_start = 9_000_000_000u64;
        assert_fuzzy_eq!(out_start, expected_start, 10);

        // At t=duration: token_in price = 1.0 * 0.97 = 0.97
        let auction_end = auction_progress(duration, 0, duration);
        let out_end = quote_swap_with_dutch_auction_raw(
            auction_end,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 0.97 / 100.0 = 9.7 SOL
        let expected_end = 9_700_000_000u64;
        assert_fuzzy_eq!(out_end, expected_end, 10);

        assert!(out_end >= out_start);
    }

    #[test]
    fn test_quote_swap_both_bounds_above_oracle_sell() {
        // Both sell bounds above oracle: 1.10x → 1.03x (decreasing over time)
        let duration = 3600;

        let token_in = create_vault_token_for_buying(6, ORACLE, ORACLE);
        let token_out = create_vault_token_for_selling(9, 11000, 10300);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        // At t=0: token_out price = 100.0 * 1.10 = 110.0
        let auction_start = auction_progress(0, 0, duration);
        let out_start = quote_swap_with_dutch_auction_raw(
            auction_start,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 1.0 / 110.0 = 9.0909... SOL
        let expected_start = 9_090_909_090u64;
        assert_fuzzy_eq!(out_start, expected_start, 10);

        // At t=duration: token_out price = 100.0 * 1.03 = 103.0
        let auction_end = auction_progress(duration, 0, duration);
        let out_end = quote_swap_with_dutch_auction_raw(
            auction_end,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 1.0 / 103.0 = 9.70873... SOL
        let expected_end = 9_708_737_864u64;
        assert_fuzzy_eq!(out_end, expected_end, 10);

        // Monotonicity: end >= start (sell price decreases → more output)
        assert!(out_end >= out_start);
    }

    #[test]
    fn test_quote_swap_both_bounds_below_oracle_sell() {
        // Both sell bounds below oracle: 0.98x → 0.92x (decreasing over time)
        let duration = 3600;

        let token_in = create_vault_token_for_buying(6, ORACLE, ORACLE);
        let token_out = create_vault_token_for_selling(9, 9800, 9200);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        // At t=0: token_out price = 100.0 * 0.98 = 98.0
        let auction_start = auction_progress(0, 0, duration);
        let out_start = quote_swap_with_dutch_auction_raw(
            auction_start,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 1.0 / 98.0 = 10.20408... SOL
        let expected_start = 10_204_081_632u64;
        assert_fuzzy_eq!(out_start, expected_start, 10);

        // At t=duration: token_out price = 100.0 * 0.92 = 92.0
        let auction_end = auction_progress(duration, 0, duration);
        let out_end = quote_swap_with_dutch_auction_raw(
            auction_end,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        // 1000 * 1.0 / 92.0 = 10.86956... SOL
        let expected_end = 10_869_565_217u64;
        assert_fuzzy_eq!(out_end, expected_end, 10);

        assert!(out_end >= out_start);
    }

    #[test]
    fn test_quote_swap_both_sides_above_oracle() {
        // Both buy and sell bounds above oracle simultaneously
        let duration = 3600;

        // Buy: 1.01x → 1.05x, Sell: 1.08x → 1.02x
        let token_in = create_vault_token_with_scales(6, 10100, 10500, 10800, 10200);
        let token_out = create_vault_token_with_scales(9, 10100, 10500, 10800, 10200);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        // At midpoint:
        // token_in buy: 1.0 * (1.01 + 0.5*(1.05-1.01)) = 1.0 * 1.03 = 1.03
        // token_out sell: 100.0 * (1.08 - 0.5*(1.08-1.02)) = 100.0 * 1.05 = 105.0
        // Expected: 1000 * 1.03 / 105.0 = 9.80952... SOL
        let auction_mid = auction_progress(duration / 2, 0, duration);
        let out_mid = quote_swap_with_dutch_auction_raw(
            auction_mid,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        let expected_mid = 9_809_523_809u64;
        assert_fuzzy_eq!(out_mid, expected_mid, 10);
    }

    #[test]
    fn test_quote_swap_both_sides_below_oracle() {
        // Both buy and sell bounds below oracle simultaneously
        let duration = 3600;

        // Buy: 0.92x → 0.98x, Sell: 0.97x → 0.91x
        let token_in = create_vault_token_with_scales(6, 9200, 9800, 9700, 9100);
        let token_out = create_vault_token_with_scales(9, 9200, 9800, 9700, 9100);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        // At midpoint:
        // token_in buy: 1.0 * (0.92 + 0.5*(0.98-0.92)) = 1.0 * 0.95 = 0.95
        // token_out sell: 100.0 * (0.97 - 0.5*(0.97-0.91)) = 100.0 * 0.94 = 94.0
        // Expected: 1000 * 0.95 / 94.0 = 10.10638... SOL
        let auction_mid = auction_progress(duration / 2, 0, duration);
        let out_mid = quote_swap_with_dutch_auction_raw(
            auction_mid,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();
        let expected_mid = 10_106_382_978u64;
        assert_fuzzy_eq!(out_mid, expected_mid, 10);
    }

    #[test]
    fn test_quote_swap_equal_start_end_flat_auction() {
        // Equal start and end: constant multiplier throughout
        let duration = 3600;

        let token_in = create_vault_token_for_buying(6, 10500, 10500);
        let token_out = create_vault_token_for_selling(9, 9500, 9500);

        let amount_in = 1_000_000_000;
        let price_in = Fraction::from_num(1.0);
        let price_out = Fraction::from_num(100.0);

        let auction_start = auction_progress(0, 0, duration);
        let out_start = quote_swap_with_dutch_auction_raw(
            auction_start,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();

        let auction_mid = auction_progress(duration / 2, 0, duration);
        let out_mid = quote_swap_with_dutch_auction_raw(
            auction_mid,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();

        let auction_end = auction_progress(duration, 0, duration);
        let out_end = quote_swap_with_dutch_auction_raw(
            auction_end,
            amount_in,
            price_in,
            price_out,
            &token_in,
            &token_out,
        )
        .unwrap();

        // All should be equal: price is constant
        assert_eq!(out_start, out_mid);
        assert_eq!(out_mid, out_end);

        // 1000 * 1.05 / 95.0 = 11.05263... SOL
        let expected = 11_052_631_578u64;
        assert_fuzzy_eq!(out_start, expected, 10);
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(1_000_000))]
        #[test]
        fn test_value_conservation_in_dollars(
            amount_in in 0.01f64..=10_000.0f64,
            price_in in 0.001f64..1000.0,
            price_out in 0.001f64..10000.0,
            decimals_in in 6u8..=9u8,
            decimals_out in 6u8..=9u8,
        ) {
            // Make sure that no matter what we always give less in AUM terms as quote
            // But also that we give just a bit less, not a big difference
            let amount_in = (amount_in * 10f64.powi(decimals_in as i32)) as u64;

            let price_in_f = Fraction::from_num(price_in);
            let price_out_f = Fraction::from_num(price_out);
            let price_in_tp = TokenPrice::new(price_in_f, decimals_in);
            let price_out_tp = TokenPrice::new(price_out_f, decimals_out);

            let amount_out = quote_swap(TokenAmount::from(amount_in), &price_in_tp, &price_out_tp);
            prop_assume!(amount_out.is_ok());
            let amount_out = amount_out.unwrap().into();

            let value_in = tokens_to_aum(amount_in, price_in_f, decimals_in);
            let value_out = tokens_to_aum(amount_out, price_out_f, decimals_out);
            prop_assert!(value_in >= value_out);

            let diff = if value_in > value_out {
                value_in - value_out
            } else {
                value_out - value_in
            };

            let epsilon = Fraction::from_num(0.01);
            prop_assert!(diff <= epsilon);
        }

        #[test]
        fn test_round_trip_swap(
            amount_in in 0.01f64..=10_000.0f64,
            price_a in 1.0f64..100.0,
            price_b in 1.0f64..100.0,
            decimals_a in 6u8..=9u8,
            decimals_b in 6u8..=9u8,
        ) {
            // Make sure that if we swap back and forth we always get less tokens
            let amount_in = (amount_in * 10f64.powi(decimals_a as i32)) as u64;

            let price_a_f = Fraction::from_num(price_a);
            let price_b_f = Fraction::from_num(price_b);
            let price_a_tp = TokenPrice::new(price_a_f, decimals_a);
            let price_b_tp = TokenPrice::new(price_b_f, decimals_b);

            let amount_b = quote_swap(TokenAmount::from(amount_in), &price_a_tp, &price_b_tp);
            prop_assume!(amount_b.is_ok());
            let amount_b = amount_b.unwrap();

            let amount_a_back = quote_swap(amount_b, &price_b_tp, &price_a_tp);
            prop_assume!(amount_a_back.is_ok());
            let amount_a_back: u64 = amount_a_back.unwrap().into();
            prop_assert!(amount_a_back <= amount_in);

        }

        #[test]
        fn test_dutch_auction_value_conservation(
            amount_in in 0.01f64..=10_000.0f64,
            price_in in 0.001f64..1000.0,
            price_out in 0.001f64..10000.0,
            decimals_in in 6u8..=9u8,
            decimals_out in 6u8..=9u8,
            bounds_offset in 50u64..=5000u64,
            elapsed_fraction in 0u64..=4u64,
        ) {
            // Symmetric bounds around oracle: at 50% elapsed quotes at oracle price
            let duration = 3600;
            let elapsed = duration * elapsed_fraction / 4;
            let auction = auction_progress(elapsed, 0, duration);

            let amount_in = (amount_in * 10f64.powi(decimals_in as i32)) as u64;

            let token_in = create_vault_token_for_buying(
                decimals_in,
                ORACLE - bounds_offset,
                ORACLE + bounds_offset,
            );
            let token_out = create_vault_token_for_selling(
                decimals_out,
                ORACLE + bounds_offset,
                ORACLE - bounds_offset,
            );

            let price_in_f = Fraction::from_num(price_in);
            let price_out_f = Fraction::from_num(price_out);

            let amount_out =
                quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in_f, price_out_f, &token_in, &token_out);
            prop_assume!(amount_out.is_ok());
            let amount_out = amount_out.unwrap();

            let value_in = tokens_to_aum(amount_in, price_in_f, decimals_in);
            let value_out = tokens_to_aum(amount_out, price_out_f, decimals_out);
            // For the first half of rebalance we quote only in our favour, then 2nd half we quote in solver favour
            if elapsed_fraction <= 2 {
                prop_assert!(value_in >= value_out);
            } else {
                prop_assert!(value_in <= value_out);
            }
        }

        #[test]
        fn test_dutch_auction_monotonicity(
            amount_in in 1_000_000u64..=1_000_000_000u64,
            price_in in 0.1f64..100.0,
            price_out in 0.1f64..100.0,
            start_buy_bps in 5000u64..=10000u64,
            end_buy_bps in 10000u64..=30000u64,
            start_sell_bps in 10000u64..=30000u64,
            end_sell_bps in 5000u64..=10000u64,
        ) {
            // Test that later timestamps always give better or equal rates for the vault
            let duration = 3600;

            let token_in = create_vault_token_for_buying(
                6,
                start_buy_bps,
                end_buy_bps,
            );
            let token_out = create_vault_token_for_selling(
                9,
                start_sell_bps,
                end_sell_bps,
            );

            let price_in_f = Fraction::from_num(price_in);
            let price_out_f = Fraction::from_num(price_out);

            // Sample at different time points
            let times = vec![0, duration / 4, duration / 2, 3 * duration / 4, duration];
            let mut outputs = vec![];

            for &time in &times {
                let auction = auction_progress(time, 0, duration);
                let output =
                    quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in_f, price_out_f, &token_in, &token_out)
                        .unwrap();
                outputs.push(output);
            }

            // Verify monotonicity: outputs should be non-decreasing
            for i in 1..outputs.len() {
                prop_assert!(outputs[i] >= outputs[i-1],
                    "Output at time {} ({}) should be >= output at time {} ({})",
                    times[i], outputs[i], times[i-1], outputs[i-1]);
            }
        }

        #[test]
        fn test_dutch_auction_bounds_respected(
            amount_in in 1_000_000u64..=1_000_000_000u64,
            price_in in 0.1f64..100.0,
            price_out in 0.1f64..100.0,
            buy_lo in 5000u64..=30000u64,
            buy_hi in 5000u64..=30000u64,
            sell_lo in 5000u64..=30000u64,
            sell_hi in 5000u64..=30000u64,
            elapsed_fraction in 0.0f64..=1.2f64, // Allow > 1.0 to test clamping
        ) {
            // Sort to ensure valid ordering: buy start <= end, sell start >= end
            let (start_buy_bps, end_buy_bps) = (buy_lo.min(buy_hi), buy_lo.max(buy_hi));
            let (end_sell_bps, start_sell_bps) = (sell_lo.min(sell_hi), sell_lo.max(sell_hi));

            let duration = 3600;
            let elapsed = (duration as f64 * elapsed_fraction) as u64;
            let auction = auction_progress(elapsed, 0, duration);

            let token_in = create_vault_token_for_buying(
                6,
                start_buy_bps,
                end_buy_bps,
            );
            let token_out = create_vault_token_for_selling(
                9,
                start_sell_bps,
                end_sell_bps,
            );

            let price_in_f = Fraction::from_num(price_in);
            let price_out_f = Fraction::from_num(price_out);

            let amount_out =
                quote_swap_with_dutch_auction_raw(
            auction, amount_in, price_in_f, price_out_f, &token_in, &token_out)
                    .unwrap();

            // Min output: worst prices for vault (start of auction)
            let min_in_price = price_in_f * Fraction::from_bps(start_buy_bps);
            let max_out_price = price_out_f * Fraction::from_bps(start_sell_bps);
            let min_output = quote_swap_raw(amount_in, min_in_price, 6, max_out_price, 9).unwrap();

            // Max output: best prices for vault (end of auction)
            let max_in_price = price_in_f * Fraction::from_bps(end_buy_bps);
            let min_out_price = price_out_f * Fraction::from_bps(end_sell_bps);
            let max_output = quote_swap_raw(amount_in, max_in_price, 6, min_out_price, 9).unwrap();

            // Output should be within bounds (with tiny tolerance for rounding)
            prop_assert!(amount_out >= min_output.saturating_sub(10),
                "Output {} should be >= min bound {}", amount_out, min_output);
            prop_assert!(amount_out <= max_output + 10,
                "Output {} should be <= max bound {}", amount_out, max_output);
        }

        #[test]
        fn test_dutch_auction_interpolation_linearity(
            amount_in in 1_000_000_000u64..=10_000_000_000u64,
            price in 1.0f64..100.0,
            start_buy_bps in 5000u64..=9900u64,
            end_buy_bps in 10100u64..=30000u64,
        ) {
            // Test that price adjustments are linear over time
            let duration = 10000;
            let token_in = create_vault_token_for_buying(
                6,
                start_buy_bps,
                end_buy_bps,
            );
            let token_out = create_vault_token_for_selling(6, ORACLE, ORACLE);

            let price_f = Fraction::from_num(price);

            // Get outputs at 25%, 50%, 75% progress
            let auction_25 = auction_progress(2500, 0, duration);
            let out_25 =
                quote_swap_with_dutch_auction_raw(
            auction_25, amount_in, price_f, price_f, &token_in, &token_out)
                    .unwrap();

            let auction_50 = auction_progress(5000, 0, duration);
            let out_50 =
                quote_swap_with_dutch_auction_raw(
            auction_50, amount_in, price_f, price_f, &token_in, &token_out)
                    .unwrap();

            let auction_75 = auction_progress(7500, 0, duration);
            let out_75 =
                quote_swap_with_dutch_auction_raw(
            auction_75, amount_in, price_f, price_f, &token_in, &token_out)
                    .unwrap();

            // Check linearity: out_50 should be approximately the midpoint
            let expected_mid = (out_25 + out_75) / 2;
            assert_fuzzy_eq!(out_50, expected_mid, 10);
        }

        #[test]
        fn test_dutch_auction_buy_price_increasing(
            amount_in in 1_000_000u64..=1_000_000_000u64,
            price_in in 0.1f64..100.0,
            price_out in 0.1f64..100.0,
            buy_a in 5000u64..=30000u64,
            buy_b in 5000u64..=30000u64,
            decimals_in in 6u8..=9u8,
            decimals_out in 6u8..=9u8,
        ) {
            let (start_buy_bps, end_buy_bps) = (buy_a.min(buy_b), buy_a.max(buy_b));
            // Verify that buy price increases over time (better for vault)
            let duration = 3600;
            let token_in = create_vault_token_for_buying(
                decimals_in,
                start_buy_bps,
                end_buy_bps,
            );
            let token_out = create_vault_token_for_selling(decimals_out, ORACLE, ORACLE);

            let price_in_f = Fraction::from_num(price_in);
            let price_out_f = Fraction::from_num(price_out);

            // Compare outputs at early and late times. At the extremes of these ranges the
            // quote can legitimately round a sub-lamport output down to nothing (a 0.001-token
            // input worth $0.0001 against a scaled-up sell price); that is
            // `test_dutch_auction_quote_rounds_to_zero_error`'s subject, not this one's.
            let auction_early = auction_progress(duration / 6, 0, duration); // ~17%
            let amount_out_early = quote_swap_with_dutch_auction_raw(
                auction_early,
                amount_in,
                price_in_f,
                price_out_f,
                &token_in,
                &token_out,
            );
            prop_assume!(amount_out_early.is_ok());
            let amount_out_early = amount_out_early.unwrap();

            let auction_late = auction_progress(5 * duration / 6, 0, duration); // ~83%
            let amount_out_late = quote_swap_with_dutch_auction_raw(
                auction_late,
                amount_in,
                price_in_f,
                price_out_f,
                &token_in,
                &token_out,
            );
            prop_assume!(amount_out_late.is_ok());
            let amount_out_late = amount_out_late.unwrap();

            // Later should give more output (vault buys at higher price)
            prop_assert!(amount_out_late >= amount_out_early,
                "Output should increase over time: early {} vs late {}",
                amount_out_early, amount_out_late);
        }

        #[test]
        fn test_dutch_auction_sell_price_decreasing(
            amount_in in 1_000_000u64..=1_000_000_000u64,
            price_in in 0.1f64..100.0,
            price_out in 0.1f64..100.0,
            sell_a in 5000u64..=30000u64,
            sell_b in 5000u64..=30000u64,
            decimals_in in 6u8..=9u8,
            decimals_out in 6u8..=9u8,
        ) {
            let (end_sell_bps, start_sell_bps) = (sell_a.min(sell_b), sell_a.max(sell_b));
            // Verify that sell price decreases over time (better for vault)
            let duration = 3600;
            let token_in = create_vault_token_for_buying(decimals_in, ORACLE, ORACLE);
            let token_out = create_vault_token_for_selling(
                decimals_out,
                start_sell_bps,
                end_sell_bps,
            );

            let price_in_f = Fraction::from_num(price_in);
            let price_out_f = Fraction::from_num(price_out);

            // Compare outputs at early and late times. At the extremes of these ranges the
            // quote can legitimately round a sub-lamport output down to nothing (a 0.001-token
            // input worth $0.0001 against a scaled-up sell price); that is
            // `test_dutch_auction_quote_rounds_to_zero_error`'s subject, not this one's.
            let auction_early = auction_progress(duration / 6, 0, duration); // ~17%
            let amount_out_early = quote_swap_with_dutch_auction_raw(
                auction_early,
                amount_in,
                price_in_f,
                price_out_f,
                &token_in,
                &token_out,
            );
            prop_assume!(amount_out_early.is_ok());
            let amount_out_early = amount_out_early.unwrap();

            let auction_late = auction_progress(5 * duration / 6, 0, duration); // ~83%
            let amount_out_late = quote_swap_with_dutch_auction_raw(
                auction_late,
                amount_in,
                price_in_f,
                price_out_f,
                &token_in,
                &token_out,
            );
            prop_assume!(amount_out_late.is_ok());
            let amount_out_late = amount_out_late.unwrap();

            // Later should give more output (vault sells at lower price)
            prop_assert!(amount_out_late >= amount_out_early,
                "Output should increase over time: early {} vs late {}",
                amount_out_early, amount_out_late);
        }
    }

    #[test]
    fn test_dutch_auction_quote_rounds_to_zero_error() {
        let duration = 3600;
        let elapsed_fraction = 3_u64;
        let elapsed = duration * elapsed_fraction / 4;
        let auction = auction_progress(elapsed, 0, duration);

        let decimals_in = 6_u8;
        let decimals_out = 6_u8;
        let amount_in = (0.01_f64 * 10_f64.powi(decimals_in as i32)) as u64;

        let token_in = create_vault_token_for_buying(decimals_in, 9950, 10050);
        let token_out = create_vault_token_for_selling(decimals_out, 10050, 9950);

        let price_in_f = Fraction::from_num(0.001);
        let price_out_f = Fraction::from_num(9_170.728_939_795_532);

        let result = quote_swap_with_dutch_auction_raw(
            auction,
            amount_in,
            price_in_f,
            price_out_f,
            &token_in,
            &token_out,
        );

        assert_eq!(result, err!(KaminoVaultError::SwapQuoteRoundsToZero));
    }

    #[test]
    fn test_zero_length_rebalance_window_has_no_progress() {
        let tokens = HashMap::from([(
            "USDC",
            TokenConfig::with_weight_price_available_decimals(10_000, 1.0, 1_000_000, 6),
        )]);
        let (mut vault, _) = setup_vault_with_tokens(&tokens);
        vault.rebalance.start_timestamp = 1_000;
        vault.rebalance.end_timestamp = 1_000;

        // An empty range contains nothing, so no clock reads as inside it — which is also what
        // keeps the progress ratio's denominator away from zero.
        assert_eq!(vault.rebalance.progress(Timestamp::from(1_100)), None);
        assert_eq!(vault.rebalance.progress(Timestamp::from(1_000)), None);
        assert_eq!(vault.rebalance.progress(Timestamp::from(999)), None);
    }

    // ---------------------------------------------------------------------------
    // Rebalance swap should never decrease AUM in first half with symmetric
    // bounds around oracle (start = oracle-offset, end = oracle+offset).
    // At 50% elapsed the auction quotes at oracle price and
    // the first half is vault-favorable.
    // ---------------------------------------------------------------------------
    proptest! {
        #![proptest_config(ProptestConfig{cases: 1_000_000, max_global_rejects: 100_000, ..Default::default()})]

        #[test]
        fn test_rebalance_swap_never_decreases_aum_symmetric_bounds(
            price_a_f in 0.1_f64..1_000.0,
            price_b_f in 0.1_f64..1_000.0,
            decimals_a in 6_u8..=9,
            decimals_b in 6_u8..=9,
            weight_a in 1000_u64..9000,
            available_a in 1_000_000_u64..10_000_000_000,
            available_b in 1_000_000_u64..10_000_000_000,
            bounds_offset in 50_u64..500,
            elapsed_fraction in 0_u64..2,
        ) {
            let weight_b = 10000 - weight_a;
            let tokens = HashMap::from_iter([
                ("ALPHA", TokenConfig::with_weight_price_available_decimals(
                    weight_a, price_a_f, available_a, decimals_a,
                )),
                ("BETA", TokenConfig::with_weight_price_available_decimals(
                    weight_b, price_b_f, available_b, decimals_b,
                )),
            ]);
            let (mut vault, vault_scope_prices) = setup_vault_with_tokens(&tokens);
            vault.shares_issued = 1_000_000_000;

            // Symmetric bounds around oracle
            // At 50% elapsed the auction quotes at oracle price
            // First half (elapsed_fraction 0..2 of 4) is vault-favorable
            for token in vault.iter_mut_enabled_tokens() {
                token.dutch_auction_scales = DutchAuctionScales {
                    start_scale_bps_when_buying: ORACLE - bounds_offset,
                    end_scale_bps_when_buying: ORACLE + bounds_offset,
                    start_scale_bps_when_selling: ORACLE + bounds_offset,
                    end_scale_bps_when_selling: ORACLE - bounds_offset,
                };
            }

            // Start rebalance
            let duration = 3600_u64;
            let start_ts = 1_000_000_u64;
            let rebalance_result = rebalance_operations::start_rebalance(
                &mut vault,
                Duration::from(duration),
                &vault_scope_prices,
                NetAum::ZERO,
                Timestamp::from(start_ts),
                StartRebalanceAuthority::AllocationDelegate,
            );
            prop_assume!(rebalance_result.is_ok());

            // Find which token has excess and which has deficit
            let targets = vault.tokens().targets(&vault_scope_prices);
            let token_0_id = VaultTokenId {
                storage_index: 0,
                input_account_index: 0,
            };
            let token_0_has_excess =
                token_by_id(&vault, token_0_id).excess(targets.of(token_0_id)) > TokenAmount::ZERO;

            let (token_in_mint, token_out_mint) = if token_0_has_excess {
                (vault.vault_tokens[1].mint, vault.vault_tokens[0].mint)
            } else {
                (vault.vault_tokens[0].mint, vault.vault_tokens[1].mint)
            };

            // Swap half the deficit of token_in
            let token_in_id = vault.get_vault_token_id_by_mint(&token_in_mint).unwrap();
            let deficit = u64::from(token_by_id(&vault, token_in_id).deficit(targets.of(token_in_id)));
            let amount_in = deficit / 2;
            if amount_in == 0 {
                return Ok(());
            }

            // First half only (0..2 out of 4 fractions = 0..50%)
            let elapsed = duration * elapsed_fraction / 4;
            let current_ts = start_ts + elapsed;

            // Verify value conservation at the quote level
            let progress = auction_progress(current_ts, start_ts, duration);
            let token_in_idx = vault
                .get_vault_token_id_by_mint(&token_in_mint)
                .unwrap()
                .input_account_index;
            let token_out_idx = vault
                .get_vault_token_id_by_mint(&token_out_mint)
                .unwrap()
                .input_account_index;
            let token_in_price = &vault_scope_prices.prices[token_in_idx];
            let token_out_price = &vault_scope_prices.prices[token_out_idx];
            let token_in_ref = vault.get_vault_token_by_mint(&token_in_mint).unwrap();
            let token_out_ref = vault.get_vault_token_by_mint(&token_out_mint).unwrap();

            let quote_result = quote_swap_with_dutch_auction(
                progress,
                TokenAmount::from(amount_in),
                token_in_price,
                token_out_price,
                &DutchAuctionBounds {
                    buying: token_in_ref.dutch_auction_scales.buying_bounds(),
                    selling: token_out_ref.dutch_auction_scales.selling_bounds(),
                },
            );
            prop_assume!(quote_result.is_ok());
            let amount_out = quote_result.unwrap();

            let value_in = tokens_to_aum(amount_in, token_in_price.price(), token_in_ref.decimals);
            let value_out = tokens_to_aum(u64::from(amount_out), token_out_price.price(), token_out_ref.decimals);

            // Core invariant: swap quote is vault-favorable in first half
            prop_assert!(
                value_in >= value_out,
                "Swap quote not vault-favorable: value_in {} < value_out {}",
                value_in.to_num::<f64>(),
                value_out.to_num::<f64>()
            );

            // Also execute the swap and verify vault AUM doesn't decrease
            // beyond rounding tolerance
            let aum_before_swap = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);
            let Ok(quote) = rebalance_operations::quote_rebalance_swap(
                &vault.tokens(),
                &vault.rebalance,
                &vault_scope_prices,
                &token_in_mint,
                &token_out_mint,
                TokenAmount::from(amount_in),
                Timestamp::from(current_ts),
            ) else {
                return Ok(());
            };
            let swap_result = rebalance_operations::calculate_rebalance_swap(
                &mut vault,
                &vault_scope_prices,
                NetAum::ZERO,
                FillRequest {
                    token_in_mint,
                    token_out_mint,
                    amount_in: TokenAmount::from(amount_in),
                    requested_out_amount: quote.max_out_from_curve,
                    now: Timestamp::from(current_ts),
                },
            );
            if swap_result.is_err() {
                return Ok(());
            }

            let aum_after_swap = vault.compute_free_aum(&vault_scope_prices, RoundingMethod::Floor);

            // Allow rounding tolerance for integer arithmetic
            prop_assert!(
                aum_after_swap + DollarValue::from(EPSILON_F) >= aum_before_swap,
                "AUM decreased beyond rounding tolerance: before {} after {}",
                Fraction::from(aum_before_swap).to_num::<f64>(),
                Fraction::from(aum_after_swap).to_num::<f64>()
            );
        }
    }
}

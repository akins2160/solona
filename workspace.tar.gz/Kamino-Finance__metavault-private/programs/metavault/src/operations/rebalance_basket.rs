use crate::{
    state::MetavaultState,
    types::{
        BasketToken, BasketTokens, Duration, RebalanceLimits, RebalanceState, RoundingMethod,
        Timestamp, TokenAmount, VaultTokenId,
    },
    utils::scope::VaultScopePrices,
};

/// A set of tokens (amounts + weights) that a dutch auction rebalances toward its weights: the
/// vault itself, a deposit order, a withdraw order. They differ only in how their inventory moves
/// and where their [RebalanceState] lives; the rest derives from [BasketTokens] and the state.
pub trait RebalanceBasket {
    /// The basket's tokens, in dense order.
    fn tokens(&self) -> BasketTokens;

    /// Adds `amount` of the token `id` to the basket (a fill's `token_in`).
    fn credit(&mut self, id: VaultTokenId, amount: TokenAmount);

    /// Takes `amount` of the token `id` off the basket (a fill's `token_out`).
    fn debit(&mut self, id: VaultTokenId, amount: TokenAmount);

    /// The basket's rebalance.
    fn rebalance(&mut self) -> &mut RebalanceState;

    /// Starts a rebalance running for `duration` from `now` under `limits`, its loss ceiling set on
    /// what the basket is worth at these prices.
    fn start_rebalance(
        &mut self,
        duration: Duration,
        prices: &VaultScopePrices,
        now: Timestamp,
        limits: RebalanceLimits,
    ) {
        let value = self.tokens().value(prices, RoundingMethod::Floor);
        *self.rebalance() = RebalanceState::started(now, duration, value, limits);
    }

    /// Clears the rebalance state once [RebalanceState::is_over]. Every instruction that has prices
    /// runs this on entry, before moving balances (so no move can reopen one that is already over).
    fn finish_rebalance_if_over(&mut self, prices: &VaultScopePrices, now: Timestamp) {
        let tokens = self.tokens();
        let rebalance = self.rebalance();
        if rebalance.is_over(&tokens, prices, now) {
            rebalance.finish();
        }
    }
}

impl RebalanceBasket for MetavaultState {
    fn tokens(&self) -> BasketTokens {
        self.enumerate_enabled_tokens()
            .map(|(id, token)| BasketToken {
                id,
                mint: token.mint,
                available: token.available(),
                weight: token.weight(),
                scales: token.dutch_auction_scales,
            })
            .collect()
    }

    fn credit(&mut self, id: VaultTokenId, amount: TokenAmount) {
        self.get_vault_token_mut_by_id(id).deposit_tokens(amount);
    }

    fn debit(&mut self, id: VaultTokenId, amount: TokenAmount) {
        self.get_vault_token_mut_by_id(id).withdraw_tokens(amount);
    }

    fn rebalance(&mut self) -> &mut RebalanceState {
        &mut self.rebalance
    }
}

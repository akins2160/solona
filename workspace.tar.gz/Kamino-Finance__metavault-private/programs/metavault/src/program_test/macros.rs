// Re-export the assert_fuzzy_eq macro from kamino_lending to avoid duplication
pub use kamino_lending::assert_fuzzy_eq;

#[macro_export]
macro_rules! metavault_error {
    ($err: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            0,
            solana_sdk::instruction::InstructionError::Custom(6000 + $err as u32),
        )
    };

    ($err: expr, $index: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            $index,
            solana_sdk::instruction::InstructionError::Custom(6000 + $err as u32),
        )
    };
}

use anchor_lang::{AccountDeserialize, Discriminator};
use kamino_lending::{
    program_test::common::{consts::SCOPE_PROGRAM_ID, token_operations, types::TestContext},
    utils::scope::ScopePrices,
};
use solana_program::pubkey::Pubkey;
use solana_sdk::{account::Account, signer::Signer};

use crate::{utils::consts, MetavaultState};

use super::{ScopePrice, VaultAccounts};

pub async fn get_scope_token_price(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_name: &str,
) -> f64 {
    let (scope_price_acc, scope_info) = get_scope_prices(ctx, vault_accounts, token_name).await;
    let dated_price = &scope_price_acc.prices[scope_info.price_index];
    dated_price.price.value as f64 / 10_f64.powi(dated_price.price.exp as i32)
}

pub async fn get_scope_prices<'a>(
    ctx: &mut TestContext,
    vault_accounts: &'a VaultAccounts,
    token_name: &str,
) -> (ScopePrices, &'a ScopePrice) {
    let vault_token = &vault_accounts.vault_tokens[token_name];
    let scope_info = &vault_accounts.scope_prices[&vault_token.token_mint];
    let scope_price_acc_info = ctx
        .get_account(scope_info.scope_feed)
        .await
        .unwrap()
        .unwrap();
    let mut data: &[u8] = &scope_price_acc_info.data;
    let scope_price_acc = ScopePrices::try_deserialize(&mut data).unwrap();
    (scope_price_acc, scope_info)
}

async fn update_scope_px(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_name: &str,
    px: f64,
) {
    let (mut scope_price_acc, scope_info) = get_scope_prices(ctx, vault_accounts, token_name).await;
    let dated_price = &mut scope_price_acc.prices[scope_info.price_index];
    let clock = ctx.get_clock().await;
    dated_price.last_updated_slot = clock.slot;
    dated_price.unix_timestamp = clock.unix_timestamp as u64;
    dated_price.price.value = (px * 10_f64.powi(dated_price.price.exp as i32)) as u64;

    let mut account = Account::new(
        u32::MAX as u64,
        8 + std::mem::size_of::<ScopePrices>(),
        &SCOPE_PROGRAM_ID,
    );
    account.data[..8].copy_from_slice(&ScopePrices::discriminator());
    account.data[8..].copy_from_slice(bytemuck::bytes_of(&scope_price_acc));
    ctx.set_account(&scope_info.scope_feed, account);
}

pub async fn update_scope_px_and_twap(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_name: &str,
    px: f64,
    twap_px: f64,
) {
    update_scope_px(ctx, vault_accounts, token_name, px).await;
    update_scope_twap(ctx, vault_accounts, token_name, twap_px).await;
}

pub async fn inflate_tokens_in_vault(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_name: &str,
    lamports: u64,
) {
    let expected_token = &vault_accounts.vault_tokens[token_name];
    let vault_acc_info = ctx
        .get_account(vault_accounts.vault_state.pubkey())
        .await
        .unwrap()
        .unwrap();
    let mut data: &[u8] = &vault_acc_info.data;
    let mut vault_acc = MetavaultState::try_deserialize(&mut data).unwrap();
    let vault_token = vault_acc
        .vault_tokens
        .iter_mut()
        .find(|token| token.mint == expected_token.token_mint)
        .unwrap();
    vault_token.token_available += lamports;

    let mut account = Account::new(
        u32::MAX as u64,
        8 + std::mem::size_of::<MetavaultState>(),
        &crate::id(),
    );
    account.data[..8].copy_from_slice(&MetavaultState::discriminator());
    account.data[8..].copy_from_slice(bytemuck::bytes_of(&vault_acc));
    ctx.set_account(&vault_accounts.vault_state.pubkey(), account);

    // Airdrop tokens to token vault
    let (ata, _) = Pubkey::find_program_address(
        &[
            consts::TOKEN_VAULT_SEED,
            expected_token.token_mint.as_ref(),
            vault_accounts.vault_state.pubkey().as_ref(),
        ],
        &crate::ID,
    );
    token_operations::mint_to(ctx, &expected_token.token_mint, &ata, lamports)
        .await
        .unwrap();
}

pub async fn update_scope_twap(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_name: &str,
    px: f64,
) {
    let (mut scope_price_acc, scope_info) = get_scope_prices(ctx, vault_accounts, token_name).await;
    let dated_price = &mut scope_price_acc.prices[scope_info.twap_index];
    let clock = ctx.get_clock().await;
    dated_price.last_updated_slot = clock.slot;
    dated_price.unix_timestamp = clock.unix_timestamp as u64;
    dated_price.price.value = (px * 10_f64.powi(dated_price.price.exp as i32)) as u64;

    let mut account = Account::new(
        u32::MAX as u64,
        8 + std::mem::size_of::<ScopePrices>(),
        &SCOPE_PROGRAM_ID,
    );
    account.data[..8].copy_from_slice(&ScopePrices::discriminator());
    account.data[8..].copy_from_slice(bytemuck::bytes_of(&scope_price_acc));
    ctx.set_account(&scope_info.scope_feed, account);
}

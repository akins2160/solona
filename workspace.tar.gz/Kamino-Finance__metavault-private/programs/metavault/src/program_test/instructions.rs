use anchor_lang::{prelude::Rent, system_program::System, Id, InstructionData, ToAccountMetas};
use anchor_spl::{
    associated_token::get_associated_token_address_with_program_id, token::Token,
    token_2022::Token2022,
};
use kamino_lending::{
    program_test::common::{
        setup::KP,
        types::{LendingMarketAccounts, ReserveAccounts, TestContext},
    },
    readable, send_transaction, writable, ReserveFarmKind, ScopeConfiguration,
};
use solana_program::{
    pubkey::Pubkey,
    system_instruction,
    sysvar::{instructions as sysvar_instructions, SysvarId},
};
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction,
    instruction::{AccountMeta, Instruction},
    signature::Keypair,
    signer::Signer,
    transaction::Transaction,
};

use super::{event_authority_pda, VaultAccounts, VaultDepositorAccounts, VaultToken};
use crate::{
    utils::{global_config::UpdateGlobalConfigMode, pda},
    VaultConfigField,
};

pub async fn init_global_config(
    ctx: &mut TestContext,
    owner: &KP,
    global_config: &Pubkey,
) -> Transaction {
    let accounts = crate::accounts::InitGlobalConfig {
        payer: owner.pubkey(),
        global_config: *global_config,
        program_data: pda::program_data(),
        system_program: System::id(),
        rent: Rent::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    let data = crate::instruction::InitGlobalConfig {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn update_global_config(
    ctx: &mut TestContext,
    owner: &KP,
    global_config: &Pubkey,
    mode: UpdateGlobalConfigMode,
    value: Vec<u8>,
) -> Transaction {
    let accounts = crate::accounts::UpdateGlobalConfig {
        global_admin: owner.pubkey(),
        global_config: *global_config,
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);

    let data = crate::instruction::UpdateGlobalConfig { mode, value }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn update_global_config_admin(
    ctx: &mut TestContext,
    global_config: &Pubkey,
    new_owner: &KP,
) -> Transaction {
    let accounts = crate::accounts::ApplyGlobalConfigAdmin {
        pending_admin: new_owner.pubkey(),
        global_config: *global_config,
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);

    let data = crate::instruction::UpdateGlobalConfigAdmin {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], new_owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_vault(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    vault_token: &VaultToken,
    scope_account: Pubkey,
    scope_configuration: ScopeConfiguration,
    user_lookup_table: Pubkey,
) -> Transaction {
    init_vault_with_acl_accounts(
        ctx,
        owner,
        vault_accounts,
        vault_token,
        scope_account,
        scope_configuration,
        user_lookup_table,
        vault_accounts
            .gating_program
            .map(|_| vault_accounts.shares_mint_config),
        vault_accounts
            .gating_program
            .map(|_| vault_accounts.token_acl_program),
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_vault_with_acl_accounts(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    vault_token: &VaultToken,
    scope_account: Pubkey,
    scope_configuration: ScopeConfiguration,
    user_lookup_table: Pubkey,
    shares_mint_config: Option<Pubkey>,
    token_acl_program: Option<Pubkey>,
) -> Transaction {
    let create_account_ix = system_instruction::create_account(
        &owner.pubkey(),
        &vault_accounts.vault_state.pubkey(),
        ctx.get_rent_zero_copy::<crate::MetavaultState>(),
        std::mem::size_of::<crate::MetavaultState>() as u64 + 8,
        &crate::id(),
    );

    let owner_token_ata = get_associated_token_address_with_program_id(
        &owner.pubkey(),
        &vault_token.token_mint,
        &vault_token.token_program,
    );
    let user_metadata = pda::vault_user_metadata(&vault_accounts.base_vault_authority);

    let mut accounts = crate::accounts::InitVault {
        global_config: vault_accounts.global_config,
        admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        token_mint: vault_token.token_mint,
        token_vault: vault_token.token_vault,
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        admin_token_account: owner_token_ata,
        user_metadata,
        lending_program: kamino_lending::ID,
        rent: Rent::id(),
        token_program: vault_token.token_program,
        system_program: System::id(),
        shares_token_program: Token2022::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
        shares_mint_config,
        token_acl_program,
    }
    .to_account_metas(None);
    accounts.push(readable!(scope_account));
    let data = crate::instruction::InitVault {
        scope_configuration,
        user_lookup_table,
        gating_program: vault_accounts.gating_program,
    }
    .data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer_and_extra_signers(
        [create_account_ix, instruction],
        owner,
        [vault_accounts.vault_state.as_ref()],
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub async fn deposit(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    vault_token: &VaultToken,
    token_name: &str,
    scope_accounts: Vec<Pubkey>,
    amount: u64,
    min_shares_out: u64,
) -> Transaction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::Deposit {
        global_config: vault_accounts.global_config,
        user: depositor.owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        token_vault: vault_token.token_vault,
        token_mint: vault_token.token_mint,
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        user_token_ata: *depositor.token_atas.get(token_name).unwrap(),
        user_shares_ata: depositor.shares_ata,
        token_program: vault_token.token_program,
        shares_token_program: vault_accounts.shares_token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let data = crate::instruction::Buy {
        max_amount: amount,
        min_shares_out,
    }
    .data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], &depositor.owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub fn withdraw_ix(
    program_id: Pubkey,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    vault_token: &VaultToken,
    token_name: &str,
    scope_accounts: Vec<Pubkey>,
    amount: u64,
    min_tokens_out: u64,
) -> Instruction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::Withdraw {
        user: depositor.owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        global_config: vault_accounts.global_config,
        token_vault: vault_token.token_vault,
        base_vault_authority: vault_accounts.base_vault_authority,
        token_mint: vault_token.token_mint,
        user_token_ata: *depositor.token_atas.get(token_name).unwrap(),
        user_shares_ata: depositor.shares_ata,
        shares_mint: vault_accounts.shares_mint,
        token_program: vault_token.token_program,
        shares_token_program: Token2022::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let data = crate::instruction::Sell {
        shares_amount: amount,
        min_tokens_out,
    }
    .data();
    Instruction {
        program_id,
        accounts,
        data,
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn withdraw<'a>(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    vault_token: &VaultToken,
    token_name: &str,
    scope_accounts: Vec<Pubkey>,
    amount: u64,
    min_tokens_out: u64,
) -> Transaction {
    let instruction = withdraw_ix(
        crate::id(),
        vault_accounts,
        depositor,
        vault_token,
        token_name,
        scope_accounts,
        amount,
        min_tokens_out,
    );

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], &depositor.owner)
        .await
}

/// [withdraw], with the klend refresh prelude for one obligation bundled into the same
/// transaction — the shape production user withdrawals must take, since klend's same-slot
/// freshness rule means the refreshes cannot ride in a separate transaction. Exists so tx-size
/// tests measure the real user-facing packet.
#[allow(clippy::too_many_arguments)]
pub async fn withdraw_with_refresh_prelude<'a>(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    vault_token: &VaultToken,
    token_name: &str,
    scope_accounts: Vec<Pubkey>,
    amount: u64,
    min_tokens_out: u64,
    market: &LendingMarketAccounts,
    refresh_target_reserve: &ReserveAccounts,
    obligation: Pubkey,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let instruction = withdraw_ix(
        crate::id(),
        vault_accounts,
        depositor,
        vault_token,
        token_name,
        scope_accounts,
        amount,
        min_tokens_out,
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    let mut all_ixs = vec![cu_ix];
    all_ixs.extend(build_obligations_prelude(
        refresh_target_reserve,
        obligation,
        market.market.pubkey(),
        &obligation_deposit_reserves,
        &obligation_borrow_reserves,
    ));
    all_ixs.push(instruction);
    ctx.create_transaction_with_payer(all_ixs, &depositor.owner)
        .await
}

pub async fn withdraw_pending_fees(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    vault_admin: &VaultDepositorAccounts,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let mut accounts = crate::accounts::WithdrawPendingFees {
        vault_admin_authority: vault_admin.owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        shares_mint: vault_accounts.shares_mint,
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_token_program: vault_accounts.shares_token_program,
        admin_shares_ata: vault_admin.shares_ata,
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::WithdrawPendingFees {}.data(),
    };

    ctx.create_transaction_with_payer([instruction], &vault_admin.owner)
        .await
}

pub async fn give_up_pending_fees(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    vault_admin: &Keypair,
    scope_accounts: Vec<Pubkey>,
    max_amount_to_give_up: u64,
) -> Transaction {
    let mut accounts = crate::accounts::GiveUpPendingFees {
        vault_admin_authority: vault_admin.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::GiveUpPendingFees {
            max_amount_to_give_up,
        }
        .data(),
    };

    ctx.create_transaction_with_payer([instruction], vault_admin)
        .await
}

pub async fn refresh_vault(
    ctx: &mut TestContext,
    payer: &KP,
    vault_accounts: &VaultAccounts,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let mut accounts = crate::accounts::RefreshVault {
        vault_state: vault_accounts.vault_state.pubkey(),
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority: event_authority_pda(),
        program: crate::id(),
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RefreshVault {}.data(),
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub fn aum_ix(
    program_id: Pubkey,
    vault_accounts: &VaultAccounts,
    scope_accounts: Vec<Pubkey>,
) -> Instruction {
    let mut accounts = crate::accounts::Aum {
        vault_state: vault_accounts.vault_state.pubkey(),
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    Instruction {
        program_id,
        accounts,
        data: crate::instruction::Aum {}.data(),
    }
}

pub async fn aum(
    ctx: &mut TestContext,
    payer: &KP,
    vault_accounts: &VaultAccounts,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let instruction = aum_ix(crate::id(), vault_accounts, scope_accounts);
    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub fn exchange_rate_ix(
    program_id: Pubkey,
    vault_accounts: &VaultAccounts,
    mint: Pubkey,
    scope_accounts: Vec<Pubkey>,
) -> Instruction {
    let mut accounts = crate::accounts::ExchangeRate {
        vault_state: vault_accounts.vault_state.pubkey(),
        global_config: vault_accounts.global_config,
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    Instruction {
        program_id,
        accounts,
        data: crate::instruction::ExchangeRate { mint }.data(),
    }
}

pub async fn exchange_rate(
    ctx: &mut TestContext,
    payer: &KP,
    vault_accounts: &VaultAccounts,
    mint: Pubkey,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let instruction = exchange_rate_ix(crate::id(), vault_accounts, mint, scope_accounts);
    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn init_shares_metadata(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    name: String,
    symbol: String,
    uri: String,
) -> Transaction {
    let accounts = crate::accounts::InitializeSharesMetadata {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        shares_mint: vault_accounts.shares_mint,
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_token_program: Token2022::id(),
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
        shares_mint_config: vault_accounts
            .gating_program
            .map(|_| vault_accounts.shares_mint_config),
    }
    .to_account_metas(None);

    let data = crate::instruction::InitializeSharesMetadata { name, symbol, uri }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn update_shares_metadata(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    name: String,
    symbol: String,
    uri: String,
) -> Transaction {
    let accounts = crate::accounts::UpdateSharesMetadata {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        shares_mint: vault_accounts.shares_mint,
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_token_program: Token2022::id(),
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);

    let data = crate::instruction::UpdateSharesMetadata { name, symbol, uri }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn thaw_shares_account(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    user_shares_account: Pubkey,
) -> Transaction {
    let accounts = crate::accounts::ThawSharesAccount {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        shares_mint_config: vault_accounts.shares_mint_config,
        user_shares_account,
        token_acl_program: vault_accounts.token_acl_program,
        shares_token_program: Token2022::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    let data = crate::instruction::ThawSharesAccount {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], authority)
        .await
}

pub async fn freeze_shares_account(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    user_shares_account: Pubkey,
) -> Transaction {
    let accounts = crate::accounts::FreezeSharesAccount {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        shares_mint_config: vault_accounts.shares_mint_config,
        user_shares_account,
        token_acl_program: vault_accounts.token_acl_program,
        shares_token_program: Token2022::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    let data = crate::instruction::FreezeSharesAccount {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], authority)
        .await
}

pub async fn set_shares_gating_program(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    new_gating_program: Pubkey,
) -> Transaction {
    let accounts = crate::accounts::SetSharesGatingProgram {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        shares_mint_config: vault_accounts.shares_mint_config,
        token_acl_program: vault_accounts.token_acl_program,
        shares_token_program: Token2022::id(),
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    let data = crate::instruction::SetSharesGatingProgram { new_gating_program }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn toggle_shares_permissionless(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    freeze_enabled: bool,
    thaw_enabled: bool,
) -> Transaction {
    let accounts = crate::accounts::ToggleSharesPermissionless {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        shares_mint_config: vault_accounts.shares_mint_config,
        token_acl_program: vault_accounts.token_acl_program,
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    let data = crate::instruction::ToggleSharesPermissionless {
        freeze_enabled,
        thaw_enabled,
    }
    .data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn delete_shares_config(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
) -> Transaction {
    let accounts = crate::accounts::DeleteSharesConfig {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        shares_mint_config: vault_accounts.shares_mint_config,
        token_acl_program: vault_accounts.token_acl_program,
        shares_token_program: Token2022::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    let data = crate::instruction::DeleteSharesConfig {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub async fn update_vault_config(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    entry: VaultConfigField,
    field_data: Vec<u8>,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let mut accounts = crate::accounts::UpdateVaultConfig {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let data = crate::instruction::UpdateVaultConfig {
        entry,
        data: field_data,
    }
    .data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(650_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], owner)
        .await
}

pub async fn add_vault_token(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    mint: Pubkey,
    vault: Pubkey,
    token_program: Pubkey,
    scope_configuration: ScopeConfiguration,
) -> Transaction {
    let accounts = crate::accounts::AddVaultToken {
        vault_admin_authority: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        token_vault: vault,
        token_mint: mint,
        token_program,
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);

    let data = crate::instruction::AddVaultToken {
        scope_configuration,
    }
    .data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(650_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], owner)
        .await
}

pub async fn apply_pending_admin(
    ctx: &mut TestContext,
    vault: &Pubkey,
    pending_admin: &KP,
) -> Transaction {
    let accounts = crate::accounts::ApplyPendingAdmin {
        pending_admin: pending_admin.pubkey(),
        vault_state: *vault,
        instruction_sysvar_account: sysvar_instructions::ID,
    }
    .to_account_metas(None);

    let data = crate::instruction::ApplyPendingAdmin {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], pending_admin)
        .await
}

pub async fn start_rebalance(
    ctx: &mut TestContext,
    authority: &KP,
    vault_state: &Pubkey,
    rebalance_duration: u64,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::StartRebalance {
        authority: authority.pubkey(),
        vault_state: *vault_state,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let data = crate::instruction::StartRebalance { rebalance_duration }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], authority)
        .await
}

pub async fn stop_rebalance(
    ctx: &mut TestContext,
    authority: &KP,
    vault_state: &Pubkey,
) -> Transaction {
    let event_authority = event_authority_pda();
    let accounts = crate::accounts::StopRebalance {
        authority: authority.pubkey(),
        vault_state: *vault_state,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    let data = crate::instruction::StopRebalance {}.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], authority)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn rebalance_swap(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    user_token_in_ata: &Pubkey,
    user_token_out_ata: &Pubkey,
    token_in: &VaultToken,
    token_out: &VaultToken,
    amount_in: u64,
    requested_out_amount: u64,
    scope_accounts: Vec<Pubkey>,
    krfq_authority: Option<&KP>,
    global_config: Pubkey,
    // `krfq_fill_marker` is the marker to pass, or `None` to omit the account
    // entirely. Honest callers derive it with `utils::pda::krfq_fill_marker`; a
    // test proving the derivation is enforced passes a deliberately wrong pubkey.
    krfq_fill_marker: Option<Pubkey>,
    // The order to fill instead of the vault, if any (passing both is malformed: refused).
    deposit_order: Option<Pubkey>,
    withdraw_order: Option<Pubkey>,
) -> Transaction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::RebalanceSwap {
        user: user.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        token_in_mint: token_in.token_mint,
        token_in_vault: token_in.token_vault,
        user_token_in_ata: *user_token_in_ata,
        token_out_mint: token_out.token_mint,
        token_out_vault: token_out.token_vault,
        user_token_out_ata: *user_token_out_ata,
        token_in_program: token_in.token_program,
        token_out_program: token_out.token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        krfq_authority: krfq_authority.map(|kp| kp.pubkey()),
        global_config,
        krfq_fill_marker,
        deposit_order,
        withdraw_order,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let data = crate::instruction::RebalanceSwap {
        amount_in,
        requested_out_amount,
    }
    .data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };

    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    match krfq_authority {
        Some(krfq_authority) => {
            ctx.create_transaction_with_payer_and_extra_signers(
                [cu_ix, instruction],
                user,
                [krfq_authority],
            )
            .await
        }
        None => {
            ctx.create_transaction_with_payer([cu_ix, instruction], user)
                .await
        }
    }
}

// ── Order ixs (both kinds) ───────────────────────────────────────────

/// One token's `[mint, token_vault, owner_ata, token_program]` remaining accounts of an order's
/// open, settle or cancel.
#[derive(Clone)]
pub struct OrderTokenAccounts {
    pub token: VaultToken,
    pub owner_ata: Pubkey,
}

impl OrderTokenAccounts {
    fn push_to(&self, accounts: &mut Vec<AccountMeta>) {
        accounts.push(readable!(self.token.token_mint));
        accounts.push(writable!(self.token.token_vault));
        accounts.push(writable!(self.owner_ata));
        accounts.push(readable!(self.token.token_program));
    }
}

// ── Deposit order ixs ────────────────────────────────────────────────

#[allow(clippy::too_many_arguments)]
pub fn open_deposit_order_ix(
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    deposit_order: Pubkey,
    id: u8,
    per_token: &[OrderTokenAccounts],
    amounts: Vec<u64>,
    duration_seconds: u64,
    min_shares_out: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
    scope_accounts: Vec<Pubkey>,
) -> Instruction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::OpenDepositOrder {
        owner: depositor.owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        deposit_order,
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for token_accounts in per_token {
        token_accounts.push_to(&mut accounts);
    }
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }

    let data = crate::instruction::OpenDepositOrder {
        id,
        amounts,
        duration_seconds,
        min_shares_out,
        max_fill_slippage_bps,
        max_loss_bps,
    }
    .data();
    Instruction {
        program_id: crate::id(),
        accounts,
        data,
    }
}

#[allow(clippy::too_many_arguments)]
pub fn settle_deposit_order_ix(
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    owner: Pubkey,
    owner_shares_ata: Pubkey,
    aum_accounts: Vec<Pubkey>,
    per_token: &[OrderTokenAccounts],
) -> Instruction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::SettleDepositOrder {
        signer: signer.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        global_config: vault_accounts.global_config,
        deposit_order,
        owner,
        base_vault_authority: vault_accounts.base_vault_authority,
        shares_mint: vault_accounts.shares_mint,
        owner_shares_ata,
        shares_token_program: vault_accounts.shares_token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for aum_account in aum_accounts {
        accounts.push(readable!(aum_account));
    }
    for token_accounts in per_token {
        token_accounts.push_to(&mut accounts);
    }

    let data = crate::instruction::SettleDepositOrder {}.data();
    Instruction {
        program_id: crate::id(),
        accounts,
        data,
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn open_deposit_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    deposit_order: Pubkey,
    id: u8,
    per_token: &[OrderTokenAccounts],
    amounts: Vec<u64>,
    duration_seconds: u64,
    min_shares_out: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
    scope_accounts: Vec<Pubkey>,
) -> Transaction {
    let open = open_deposit_order_ix(
        vault_accounts,
        depositor,
        deposit_order,
        id,
        per_token,
        amounts,
        duration_seconds,
        min_shares_out,
        max_fill_slippage_bps,
        max_loss_bps,
        scope_accounts,
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(600_000);
    ctx.create_transaction_with_payer([cu_ix, open], &depositor.owner)
        .await
}

/// Opens and settles in one transaction (so a refused settle leaves no order behind).
#[allow(clippy::too_many_arguments)]
pub async fn open_and_settle_deposit_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    deposit_order: Pubkey,
    id: u8,
    per_token: &[OrderTokenAccounts],
    amounts: Vec<u64>,
    duration_seconds: u64,
    min_shares_out: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
    scope_accounts: Vec<Pubkey>,
    aum_accounts: Vec<Pubkey>,
) -> Transaction {
    let open = open_deposit_order_ix(
        vault_accounts,
        depositor,
        deposit_order,
        id,
        per_token,
        amounts,
        duration_seconds,
        min_shares_out,
        max_fill_slippage_bps,
        max_loss_bps,
        scope_accounts,
    );
    let settle = settle_deposit_order_ix(
        &depositor.owner,
        vault_accounts,
        deposit_order,
        depositor.owner.pubkey(),
        depositor.shares_ata,
        aum_accounts,
        per_token,
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_200_000);
    ctx.create_transaction_with_payer([cu_ix, open, settle], &depositor.owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn settle_deposit_order(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    owner: Pubkey,
    owner_shares_ata: Pubkey,
    aum_accounts: Vec<Pubkey>,
    per_token: &[OrderTokenAccounts],
) -> Transaction {
    let settle = settle_deposit_order_ix(
        signer,
        vault_accounts,
        deposit_order,
        owner,
        owner_shares_ata,
        aum_accounts,
        per_token,
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(600_000);
    ctx.create_transaction_with_payer([cu_ix, settle], signer)
        .await
}

pub async fn cancel_deposit_order(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    per_token: &[OrderTokenAccounts],
) -> Transaction {
    let instruction = cancel_deposit_order_ix(owner, vault_accounts, deposit_order, per_token);
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], owner)
        .await
}

pub fn cancel_deposit_order_ix(
    owner: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    per_token: &[OrderTokenAccounts],
) -> Instruction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::CancelDepositOrder {
        owner: owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        deposit_order,
        base_vault_authority: vault_accounts.base_vault_authority,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for token_accounts in per_token {
        token_accounts.push_to(&mut accounts);
    }

    let data = crate::instruction::CancelDepositOrder {}.data();
    Instruction {
        program_id: crate::id(),
        accounts,
        data,
    }
}

// ── Withdraw order ixs ───────────────────────────────────────────────

#[allow(clippy::too_many_arguments)]
pub async fn open_withdraw_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    withdraw_order: Pubkey,
    id: u8,
    shares_amount: u64,
    weights: Vec<u64>,
    duration_seconds: u64,
    min_tokens_out: Vec<u64>,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
    aum_accounts: Vec<Pubkey>,
) -> Transaction {
    let open = open_withdraw_order_ix(
        vault_accounts,
        holder,
        withdraw_order,
        id,
        shares_amount,
        weights,
        duration_seconds,
        min_tokens_out,
        max_fill_slippage_bps,
        max_loss_bps,
        aum_accounts,
    );
    // A ten-token vault with a legged obligation needs about 700k (see the full-vault test):
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_000_000);
    ctx.create_transaction_with_payer([cu_ix, open], &holder.owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub fn open_withdraw_order_ix(
    vault_accounts: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    withdraw_order: Pubkey,
    id: u8,
    shares_amount: u64,
    weights: Vec<u64>,
    duration_seconds: u64,
    min_tokens_out: Vec<u64>,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
    aum_accounts: Vec<Pubkey>,
) -> Instruction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::OpenWithdrawOrder {
        owner: holder.owner.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        global_config: vault_accounts.global_config,
        withdraw_order,
        shares_mint: vault_accounts.shares_mint,
        owner_shares_ata: holder.shares_ata,
        shares_token_program: vault_accounts.shares_token_program,
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for aum_account in aum_accounts {
        accounts.push(readable!(aum_account));
    }

    let data = crate::instruction::OpenWithdrawOrder {
        id,
        shares_amount,
        weights,
        duration_seconds,
        min_tokens_out,
        max_fill_slippage_bps,
        max_loss_bps,
    }
    .data();
    Instruction {
        program_id: crate::id(),
        accounts,
        data,
    }
}

pub async fn settle_withdraw_order(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    owner: Pubkey,
    scope_accounts: Vec<Pubkey>,
    per_token: &[OrderTokenAccounts],
) -> Transaction {
    let instruction = settle_withdraw_order_ix(
        signer,
        vault_accounts,
        withdraw_order,
        owner,
        scope_accounts,
        per_token,
    );
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], signer)
        .await
}

pub fn settle_withdraw_order_ix(
    signer: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    owner: Pubkey,
    scope_accounts: Vec<Pubkey>,
    per_token: &[OrderTokenAccounts],
) -> Instruction {
    let event_authority = event_authority_pda();
    let mut accounts = crate::accounts::SettleWithdrawOrder {
        signer: signer.pubkey(),
        owner,
        vault_state: vault_accounts.vault_state.pubkey(),
        withdraw_order,
        base_vault_authority: vault_accounts.base_vault_authority,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for scope_account in scope_accounts {
        accounts.push(readable!(scope_account));
    }
    for token_accounts in per_token {
        token_accounts.push_to(&mut accounts);
    }

    let data = crate::instruction::SettleWithdrawOrder {}.data();
    Instruction {
        program_id: crate::id(),
        accounts,
        data,
    }
}

// ── Obligation admin ixs ─────────────────────────────────────────────

pub use crate::utils::consts::{FARMS_PROGRAM_ID, FARMS_USER_STATE_SEED};

/// `refresh_reserve` discriminator — sha256("global:refresh_reserve")[..8].
const DISC_KLEND_REFRESH_RESERVE: [u8; 8] = [2, 218, 138, 235, 79, 201, 25, 102];
/// `refresh_obligation` discriminator — sha256("global:refresh_obligation")[..8].
const DISC_KLEND_REFRESH_OBLIGATION: [u8; 8] = [33, 132, 147, 228, 151, 192, 72, 89];

/// Builds a klend `refresh_reserve` instruction for the given reserve using
/// whichever oracles it was configured with.
pub fn build_klend_refresh_reserve_ix(reserve: &ReserveAccounts) -> Instruction {
    let pyth = reserve.pyth_price;
    let sb_price = reserve.switchboard_feed;
    let sb_twap = reserve.switchboard_twap_feed;
    let scope = reserve.scope_prices;
    let slot = |pk: Pubkey| {
        if pk == Pubkey::default() {
            AccountMeta::new_readonly(kamino_lending::ID, false)
        } else {
            AccountMeta::new_readonly(pk, false)
        }
    };
    Instruction {
        program_id: kamino_lending::ID,
        accounts: vec![
            AccountMeta::new(reserve.address.pubkey(), false),
            AccountMeta::new_readonly(reserve.lending_market, false),
            slot(pyth),
            slot(sb_price),
            slot(sb_twap),
            slot(scope),
        ],
        data: DISC_KLEND_REFRESH_RESERVE.to_vec(),
    }
}

fn obligation_farm_user_state_pda(farm_state: Pubkey, obligation: Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[
            FARMS_USER_STATE_SEED,
            farm_state.as_ref(),
            obligation.as_ref(),
        ],
        &FARMS_PROGRAM_ID,
    )
    .0
}

fn target_farm_remaining_accounts(
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    farm_kind: ReserveFarmKind,
) -> Vec<Pubkey> {
    reserve.admin_farm_accounts[farm_kind as usize]
        .as_ref()
        .map(|farm_accounts| {
            vec![
                obligation_farm_user_state_pda(farm_accounts.farm_state, obligation),
                farm_accounts.farm_state,
            ]
        })
        .unwrap_or_default()
}

pub fn vault_obligation_pda(
    lending_market: &Pubkey,
    base_vault_authority: &Pubkey,
    id: u8,
) -> Pubkey {
    pda::vault_obligation(lending_market, base_vault_authority, id)
}

pub async fn init_obligation<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation_id: u8,
) -> Transaction {
    let obligation = vault_obligation_pda(
        &market.market.pubkey(),
        &vault_accounts.base_vault_authority,
        obligation_id,
    );
    let user_metadata = pda::vault_user_metadata(&vault_accounts.base_vault_authority);
    let event_authority = event_authority_pda();

    let accounts = crate::accounts::InitObligation {
        vault_admin_authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        seed1_account: Pubkey::default(),
        seed2_account: Pubkey::default(),
        owner_user_metadata: user_metadata,
        lending_program: kamino_lending::ID,
        rent: Rent::id(),
        system_program: System::id(),
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    let data = crate::instruction::InitObligation {}.data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);
    ctx.create_transaction_with_payer([cu_ix, instruction], authority)
        .await
}

pub fn build_klend_refresh_obligation_ix(
    obligation: Pubkey,
    lending_market: Pubkey,
    deposit_reserves: &[&ReserveAccounts],
    borrow_reserves: &[&ReserveAccounts],
) -> Instruction {
    let mut accounts = vec![readable!(lending_market), writable!(obligation)];
    for reserve in deposit_reserves.iter().chain(borrow_reserves.iter()) {
        accounts.push(writable!(reserve.address.pubkey()));
    }
    Instruction {
        program_id: kamino_lending::ID,
        accounts,
        data: DISC_KLEND_REFRESH_OBLIGATION.to_vec(),
    }
}

fn build_obligations_prelude(
    target_reserve: &ReserveAccounts,
    obligation: Pubkey,
    lending_market: Pubkey,
    deposit_reserves: &[&ReserveAccounts],
    borrow_reserves: &[&ReserveAccounts],
) -> Vec<Instruction> {
    let mut seen: Vec<Pubkey> = vec![target_reserve.address.pubkey()];
    let mut ixs = vec![build_klend_refresh_reserve_ix(target_reserve)];
    for reserve in deposit_reserves.iter().chain(borrow_reserves.iter()) {
        let k = reserve.address.pubkey();
        if !seen.contains(&k) {
            seen.push(k);
            ixs.push(build_klend_refresh_reserve_ix(reserve));
        }
    }
    ixs.push(build_klend_refresh_obligation_ix(
        obligation,
        lending_market,
        deposit_reserves,
        borrow_reserves,
    ));
    ixs
}

/// Refreshes the obligation's reserves + the obligation itself in a standalone transaction —
/// for tests that need the op transaction to run WITHOUT a bundled refresh.
pub async fn submit_obligation_refresh<'a>(
    ctx: &mut TestContext,
    payer: &KP,
    market: &LendingMarketAccounts,
    target_reserve: &ReserveAccounts,
    obligation: Pubkey,
    deposit_reserves: Vec<&'a ReserveAccounts>,
    borrow_reserves: Vec<&'a ReserveAccounts>,
) {
    let ixs = build_obligations_prelude(
        target_reserve,
        obligation,
        market.market.pubkey(),
        &deposit_reserves,
        &borrow_reserves,
    );
    let tx = ctx.create_transaction_with_payer(ixs, payer).await;
    send_transaction!(ctx, tx).unwrap();
}

#[allow(clippy::too_many_arguments)]
fn deposit_obligation_collateral_op_ixs(
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
) -> Vec<Instruction> {
    let event_authority = event_authority_pda();
    let vault_token = vault_accounts.vault_tokens.get(token_name).unwrap();

    let mut accounts = crate::accounts::DepositObligationCollateral {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        reserve: reserve.address.pubkey(),
        reserve_liquidity_mint: reserve.liquidity_mint.pubkey(),
        reserve_liquidity_supply: reserve.liquidity_supply,
        reserve_collateral_mint: reserve.collateral_mint,
        reserve_destination_deposit_collateral: reserve.collateral_supply,
        token_vault: vault_token.token_vault,
        collateral_token_program: Token::id(),
        liquidity_token_program: reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for account in scope_and_obligation_accounts {
        accounts.push(readable!(account));
    }
    for account in target_farm_remaining_accounts(reserve, obligation, ReserveFarmKind::Collateral)
    {
        accounts.push(writable!(account));
    }

    let data = crate::instruction::DepositObligationCollateral { amount }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    vec![cu_ix, instruction]
}

#[allow(clippy::too_many_arguments)]
pub async fn deposit_obligation_collateral<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let mut all_ixs = deposit_obligation_collateral_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        amount,
        scope_and_obligation_accounts,
    );
    let instruction = all_ixs.pop().unwrap();
    all_ixs.extend(build_obligations_prelude(
        reserve,
        obligation,
        market.market.pubkey(),
        &obligation_deposit_reserves,
        &obligation_borrow_reserves,
    ));
    all_ixs.push(instruction);
    ctx.create_transaction_with_payer(all_ixs, authority).await
}

/// [deposit_obligation_collateral], but the transaction carries no klend refresh prelude — for
/// tests that need full control over refresh timing (e.g. the price-basis gate tests).
#[allow(clippy::too_many_arguments)]
pub async fn deposit_obligation_collateral_no_prelude(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
) -> Transaction {
    let ixs = deposit_obligation_collateral_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        amount,
        scope_and_obligation_accounts,
    );
    ctx.create_transaction_with_payer(ixs, authority).await
}

#[allow(clippy::too_many_arguments)]
fn withdraw_obligation_collateral_op_ixs(
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    collateral_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
) -> Vec<Instruction> {
    let event_authority = event_authority_pda();
    let vault_token = vault_accounts.vault_tokens.get(token_name).unwrap();

    let mut accounts = crate::accounts::WithdrawObligationCollateral {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        withdraw_reserve: reserve.address.pubkey(),
        reserve_liquidity_mint: reserve.liquidity_mint.pubkey(),
        reserve_source_collateral: reserve.collateral_supply,
        reserve_collateral_mint: reserve.collateral_mint,
        reserve_liquidity_supply: reserve.liquidity_supply,
        token_vault: vault_token.token_vault,
        collateral_token_program: Token::id(),
        liquidity_token_program: reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);
    for account in scope_and_obligation_accounts {
        accounts.push(readable!(account));
    }
    for account in target_farm_remaining_accounts(reserve, obligation, ReserveFarmKind::Collateral)
    {
        accounts.push(writable!(account));
    }

    let data = crate::instruction::WithdrawObligationCollateral { collateral_amount }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    vec![cu_ix, instruction]
}

#[allow(clippy::too_many_arguments)]
pub async fn withdraw_obligation_collateral<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    collateral_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let mut all_ixs = withdraw_obligation_collateral_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        collateral_amount,
        scope_and_obligation_accounts,
    );
    let instruction = all_ixs.pop().unwrap();
    all_ixs.extend(build_obligations_prelude(
        reserve,
        obligation,
        market.market.pubkey(),
        &obligation_deposit_reserves,
        &obligation_borrow_reserves,
    ));
    all_ixs.push(instruction);
    ctx.create_transaction_with_payer(all_ixs, authority).await
}

/// [withdraw_obligation_collateral], but the transaction carries no klend refresh prelude — for
/// tests that need full control over refresh timing (e.g. the price-basis gate tests).
#[allow(clippy::too_many_arguments)]
pub async fn withdraw_obligation_collateral_no_prelude(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    collateral_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
) -> Transaction {
    let ixs = withdraw_obligation_collateral_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        collateral_amount,
        scope_and_obligation_accounts,
    );
    ctx.create_transaction_with_payer(ixs, authority).await
}

#[allow(clippy::too_many_arguments)]
fn borrow_obligation_liquidity_op_ixs(
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: &[&ReserveAccounts],
) -> Vec<Instruction> {
    let event_authority = event_authority_pda();
    let vault_token = vault_accounts.vault_tokens.get(token_name).unwrap();

    let mut accounts = crate::accounts::BorrowObligationLiquidity {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        borrow_reserve: reserve.address.pubkey(),
        borrow_reserve_liquidity_mint: reserve.liquidity_mint.pubkey(),
        reserve_source_liquidity: reserve.liquidity_supply,
        borrow_reserve_liquidity_fee_receiver: reserve.fee_receiver,
        token_vault: vault_token.token_vault,
        token_program: reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    // Scope-price + obligation + leg-reserve accounts go first (consumed by metavault's
    // `AumAccounts::parse`), followed by the obligation's deposit
    // reserves (which metavault forwards into klend's borrow CPI for the post-borrow LTV check).
    for account in scope_and_obligation_accounts {
        accounts.push(readable!(account));
    }
    for deposit_reserve in obligation_deposit_reserves {
        accounts.push(writable!(deposit_reserve.address.pubkey()));
    }
    for account in target_farm_remaining_accounts(reserve, obligation, ReserveFarmKind::Debt) {
        accounts.push(writable!(account));
    }

    let data = crate::instruction::BorrowObligationLiquidity { liquidity_amount }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    vec![cu_ix, instruction]
}

#[allow(clippy::too_many_arguments)]
pub async fn borrow_obligation_liquidity<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let mut all_ixs = borrow_obligation_liquidity_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        liquidity_amount,
        scope_and_obligation_accounts,
        &obligation_deposit_reserves,
    );
    let instruction = all_ixs.pop().unwrap();
    all_ixs.extend(build_obligations_prelude(
        reserve,
        obligation,
        market.market.pubkey(),
        &obligation_deposit_reserves,
        &obligation_borrow_reserves,
    ));
    all_ixs.push(instruction);
    ctx.create_transaction_with_payer(all_ixs, authority).await
}

/// [borrow_obligation_liquidity], but the transaction carries no klend refresh prelude — for
/// tests that need full control over refresh timing (e.g. the price-basis gate tests).
#[allow(clippy::too_many_arguments)]
pub async fn borrow_obligation_liquidity_no_prelude<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let ixs = borrow_obligation_liquidity_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        liquidity_amount,
        scope_and_obligation_accounts,
        &obligation_deposit_reserves,
    );
    ctx.create_transaction_with_payer(ixs, authority).await
}

#[allow(clippy::too_many_arguments)]
fn repay_obligation_liquidity_op_ixs(
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: &[&ReserveAccounts],
) -> Vec<Instruction> {
    let event_authority = event_authority_pda();
    let vault_token = vault_accounts.vault_tokens.get(token_name).unwrap();

    let mut accounts = crate::accounts::RepayObligationLiquidity {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_market_authority: market.authority,
        repay_reserve: reserve.address.pubkey(),
        reserve_liquidity_mint: reserve.liquidity_mint.pubkey(),
        reserve_destination_liquidity: reserve.liquidity_supply,
        token_vault: vault_token.token_vault,
        token_program: reserve.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar_instructions::ID,
        farms_program: FARMS_PROGRAM_ID,
        lending_program: kamino_lending::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    // Scope-price + obligation + leg-reserve accounts go first (consumed by metavault's
    // `AumAccounts::parse`), followed by the obligation's deposit
    // reserves (forwarded into klend's repay CPI for the elevation-group debt-tracker update;
    // klend marks them mutable in `update_elevation_group_debt_trackers_on_repay`).
    for account in scope_and_obligation_accounts {
        accounts.push(readable!(account));
    }
    for deposit_reserve in obligation_deposit_reserves {
        accounts.push(writable!(deposit_reserve.address.pubkey()));
    }
    for account in target_farm_remaining_accounts(reserve, obligation, ReserveFarmKind::Debt) {
        accounts.push(writable!(account));
    }

    let data = crate::instruction::RepayObligationLiquidity { liquidity_amount }.data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_400_000);
    vec![cu_ix, instruction]
}

#[allow(clippy::too_many_arguments)]
pub async fn repay_obligation_liquidity<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let mut all_ixs = repay_obligation_liquidity_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        liquidity_amount,
        scope_and_obligation_accounts,
        &obligation_deposit_reserves,
    );
    let instruction = all_ixs.pop().unwrap();
    all_ixs.extend(build_obligations_prelude(
        reserve,
        obligation,
        market.market.pubkey(),
        &obligation_deposit_reserves,
        &obligation_borrow_reserves,
    ));
    all_ixs.push(instruction);
    ctx.create_transaction_with_payer(all_ixs, authority).await
}

/// [repay_obligation_liquidity], but the transaction carries no klend refresh prelude — for
/// tests that need full control over refresh timing (e.g. the price-basis gate tests).
#[allow(clippy::too_many_arguments)]
pub async fn repay_obligation_liquidity_no_prelude<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    scope_and_obligation_accounts: Vec<Pubkey>,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let ixs = repay_obligation_liquidity_op_ixs(
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        liquidity_amount,
        scope_and_obligation_accounts,
        &obligation_deposit_reserves,
    );
    ctx.create_transaction_with_payer(ixs, authority).await
}

#[allow(clippy::too_many_arguments)]
pub async fn request_elevation_group<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation: Pubkey,
    new_elevation_group: u8,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Transaction {
    let event_authority = event_authority_pda();

    let mut accounts = crate::accounts::RequestElevationGroup {
        authority: authority.pubkey(),
        vault_state: vault_accounts.vault_state.pubkey(),
        base_vault_authority: vault_accounts.base_vault_authority,
        obligation,
        lending_market: market.market.pubkey(),
        lending_program: kamino_lending::ID,
        instruction_sysvar_account: sysvar_instructions::ID,
        event_authority,
        program: crate::id(),
    }
    .to_account_metas(None);

    // Klend's remaining_accounts contract: `[deposit_reserves...][borrow_reserves...]
    // [referrer_token_states...]`. Metavault never sets a referrer, so the trailing segment is
    // empty. All reserves are passed writable (klend mutates the elevation-group debt trackers).
    for reserve in &obligation_deposit_reserves {
        accounts.push(writable!(reserve.address.pubkey()));
    }
    for reserve in &obligation_borrow_reserves {
        accounts.push(writable!(reserve.address.pubkey()));
    }

    let data = crate::instruction::RequestElevationGroup {
        new_elevation_group,
    }
    .data();
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data,
    };
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(400_000);

    // Klend requires the obligation to be fully refreshed before request_elevation_group. Reuse
    // the existing prelude builder; its "target reserve" arg is just for de-dup against the
    // forwarded set, so pass the first deposit reserve (any of them works).
    let mut all_ixs = vec![cu_ix];
    if let Some(target_reserve) = obligation_deposit_reserves.first() {
        all_ixs.extend(build_obligations_prelude(
            target_reserve,
            obligation,
            market.market.pubkey(),
            &obligation_deposit_reserves,
            &obligation_borrow_reserves,
        ));
    }
    all_ixs.push(instruction);
    ctx.create_transaction_with_payer(all_ixs, authority).await
}

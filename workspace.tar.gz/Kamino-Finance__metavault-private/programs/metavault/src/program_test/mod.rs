use std::{collections::HashMap, ops::AddAssign, sync::Arc};

use anchor_lang::Id;
use anchor_spl::token_2022::{spl_token_2022, Token2022};
use spl_token_2022::extension::StateWithExtensions;

use kamino_lending::{
    fraction::Fraction,
    program_test::common::{
        setup::{funded_new_kp, kp},
        token_operations,
        types::{MintAccounts, TestContext},
    },
    LendingError,
};
use solana_program::{
    instruction::InstructionError, native_token::LAMPORTS_PER_SOL, pubkey::Pubkey,
};
use solana_sdk::{signature::Keypair, signer::Signer, transaction::TransactionError};

use crate::{
    utils::{
        consts::{self, EVENT_AUTHORITY},
        pda,
    },
    GlobalConfig, MetavaultState,
};

pub mod client;
pub mod fixtures;
pub mod instructions;
pub mod macros;
pub mod setup;
pub mod test_cpi_caller;
pub mod token_acl;
pub mod types;

#[derive(Clone, Debug, PartialEq)]
pub struct VaultAccounts {
    pub vault_state: Arc<Keypair>,
    pub global_config: Pubkey,
    // Name to token mapping
    // Example: 'SOL' -> (mint, vault, program)
    pub vault_tokens: HashMap<String, VaultToken>,
    // Token mint to scope_feed mapping
    pub scope_prices: HashMap<Pubkey, ScopePrice>,
    pub shares_token_program: Pubkey,
    pub klend_program: Pubkey,
    pub shares_mint: Pubkey,
    pub base_vault_authority: Pubkey,
    pub base_vault_authority_bump: u8,
    /// Token-acl MintConfig PDA of the shares mint (always derivable; only exists
    /// on-chain for permissioned vaults).
    pub shares_mint_config: Pubkey,
    /// `Some(gate)` makes `init_vault` create a permissioned vault through token-acl.
    pub gating_program: Option<Pubkey>,
    /// Token ACL program passed on the permissioned path; a field (like
    /// `shares_token_program`) so security tests can tamper with it.
    pub token_acl_program: Pubkey,
}

#[derive(Debug)]
pub struct VaultBalances {
    pub token_vaults: HashMap<String, u64>,
    pub shares_supply: u64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct VaultToken {
    pub token_mint: Pubkey,
    pub token_vault: Pubkey,
    pub token_program: Pubkey,
}

#[derive(Debug, Clone, PartialEq)]
pub struct ScopePrice {
    pub scope_feed: Pubkey,
    pub price_index: usize,
    pub twap_index: usize,
}

impl VaultAccounts {
    pub fn new(
        mint: &Pubkey,
        token_name: &str,
        token_program: &Pubkey,
        scope_feed: Pubkey,
    ) -> Self {
        let vault_state = kp();

        let token_vault = token_vault_pda(*mint, vault_state.pubkey());

        let (base_vault_authority, base_vault_authority_bump) = Pubkey::find_program_address(
            &[
                consts::BASE_VAULT_AUTHORITY_SEED,
                vault_state.pubkey().as_ref(),
            ],
            &crate::ID,
        );

        let (shares_mint, _) = Pubkey::find_program_address(
            &[consts::SHARES_SEEDS, vault_state.pubkey().as_ref()],
            &crate::ID,
        );

        let (shares_mint_config, _) = crate::utils::token_acl::mint_config_pda(&shares_mint);

        VaultAccounts {
            scope_prices: HashMap::from_iter(vec![(
                *mint,
                ScopePrice {
                    scope_feed,
                    price_index: 0,
                    twap_index: 1,
                },
            )]),
            vault_state,
            global_config: pda::global_config(),
            vault_tokens: HashMap::from_iter(vec![(
                token_name.to_string(),
                VaultToken {
                    token_mint: *mint,
                    token_vault,
                    token_program: *token_program,
                },
            )]),
            shares_token_program: Token2022::id(),
            klend_program: kamino_lending::ID,
            shares_mint,
            base_vault_authority,
            base_vault_authority_bump,
            shares_mint_config,
            gating_program: None,
            token_acl_program: crate::utils::token_acl::TOKEN_ACL_PROGRAM_ID,
        }
    }

    pub fn from_mint(mint: &MintAccounts, token_name: &str, scope_feed: Pubkey) -> Self {
        Self::new(&mint.mint, token_name, &mint.token_program, scope_feed)
    }

    pub fn permissioned(mut self, gating_program: Pubkey) -> Self {
        self.gating_program = Some(gating_program);
        self
    }

    pub async fn state(&self, ctx: &mut TestContext) -> MetavaultState {
        kamino_lending::program_test::common::runner::state::get::<crate::MetavaultState>(
            ctx,
            self.vault_state.pubkey(),
        )
        .await
    }

    pub async fn balances(&self, ctx: &mut TestContext) -> VaultBalances {
        let mut token_vaults = HashMap::new();

        for (token_name, token) in &self.vault_tokens {
            let tokens_in_vault = ctx.get_balance(&token.token_vault).await;
            token_vaults.insert(token_name.clone(), tokens_in_vault);
        }

        // klend's `mint_info` uses the legacy exact-length unpack, which rejects an
        // extended Token-2022 mint — read the supply through StateWithExtensions.
        let shares_mint_data = ctx
            .get_account(self.shares_mint)
            .await
            .unwrap()
            .unwrap()
            .data;
        let shares_supply =
            StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&shares_mint_data)
                .unwrap()
                .base
                .supply;

        VaultBalances {
            token_vaults,
            shares_supply,
        }
    }

    pub async fn token_to_aum(
        &self,
        ctx: &mut TestContext,
        token_name: &str,
        tokens: u64,
    ) -> Fraction {
        let vault_state = self.state(ctx).await;
        let mint = self.vault_tokens[token_name].token_mint;
        let token = vault_state
            .vault_tokens
            .iter()
            .find(|token| token.mint == mint)
            .unwrap();
        let decimals = token.decimals;
        let price = setup::get_scope_token_price(ctx, self, token_name).await;
        let token_factor = 10u64.pow(decimals.into());
        Fraction::from_num(tokens as f64 * price / token_factor as f64)
    }

    pub async fn token_to_shares(
        &self,
        ctx: &mut TestContext,
        token_name: &str,
        tokens: u64,
    ) -> Fraction {
        let vault_state = self.state(ctx).await;
        let price = setup::get_scope_token_price(ctx, self, token_name).await;
        let total_aum = self.total_aum(ctx).await;
        let tokens_aum = Fraction::from_num(tokens as f64 * price);
        tokens_aum * Fraction::from(vault_state.shares_issued) / total_aum
    }

    pub async fn total_aum(&self, ctx: &mut TestContext) -> Fraction {
        let vault_state = self.state(ctx).await;
        let mut total_aum = Fraction::ZERO;
        for (token_name, vault_token) in &self.vault_tokens {
            let token = vault_state
                .vault_tokens
                .iter()
                .find(|token| token.mint == vault_token.token_mint)
                .unwrap();
            total_aum += self
                .token_to_aum(ctx, token_name, token.token_available)
                .await;
        }
        total_aum
    }

    pub async fn shares_to_aum(&self, ctx: &mut TestContext, shares: u64) -> Fraction {
        let vault_state = self.state(ctx).await;
        self.total_aum(ctx).await * Fraction::from(shares)
            / Fraction::from(vault_state.shares_issued)
    }

    pub fn get_first_scope_idx_for_feed(&self, scope_feed: Pubkey) -> (u16, u16) {
        let mut highest_idx_found = 0;
        for scope_price in self.scope_prices.values() {
            if scope_price.scope_feed == scope_feed {
                highest_idx_found = highest_idx_found.max(scope_price.price_index as u16);
                highest_idx_found = highest_idx_found.max(scope_price.twap_index as u16);
            }
        }
        (highest_idx_found + 1, highest_idx_found + 2)
    }

    pub fn get_token_name_by_mint(&self, mint: Pubkey) -> String {
        self.vault_tokens
            .iter()
            .find(|(_, token)| token.token_mint == mint)
            .unwrap()
            .0
            .to_string()
    }
}

#[derive(Debug, Eq, PartialEq, Clone, Default)]
pub struct VaultDepositorBalances {
    pub tokens: HashMap<String, u64>, // token name -> balance
    pub shares: u64,
}

#[derive(Clone, Debug)]
pub struct VaultDepositorAccounts {
    pub owner: Arc<Keypair>,
    pub token_atas: HashMap<String, Pubkey>, // Map of token name -> ATA
    pub shares_ata: Pubkey,
}

impl VaultDepositorAccounts {
    pub async fn new(
        ctx: &mut TestContext,
        vault_accounts: &VaultAccounts,
        token_name: &str,
        initial_amount: u64,
    ) -> Self {
        Self::new_multi_token(
            ctx,
            vault_accounts,
            [(token_name.to_string(), initial_amount)].into(),
        )
        .await
    }

    pub async fn new_with_owner(
        ctx: &mut TestContext,
        owner: Arc<Keypair>,
        token_name: &str,
        vault_accounts: &VaultAccounts,
    ) -> Self {
        Self::new_multi_token_with_owner(
            ctx,
            owner,
            vault_accounts,
            [(token_name.to_string(), 0)].into(), // No initial minting for this version
        )
        .await
    }

    pub async fn new_multi_token(
        ctx: &mut TestContext,
        vault_accounts: &VaultAccounts,
        token_amounts: HashMap<String, u64>, // token name -> initial amount
    ) -> Self {
        let owner = funded_new_kp(ctx, LAMPORTS_PER_SOL);
        Self::new_multi_token_with_owner(ctx, owner, vault_accounts, token_amounts).await
    }

    pub async fn new_multi_token_with_owner(
        ctx: &mut TestContext,
        owner: Arc<Keypair>,
        vault_accounts: &VaultAccounts,
        token_amounts: HashMap<String, u64>, // token name -> initial amount
    ) -> Self {
        let mut token_atas = HashMap::new();

        // Create ATAs for all requested tokens
        for (token_name, initial_amount) in &token_amounts {
            let mint = vault_accounts.vault_tokens[token_name].token_mint;
            let ata = token_operations::create_ata_if_not_exists(ctx, &owner, &mint).await;

            if *initial_amount > 0 {
                token_operations::mint_to(ctx, &mint, &ata, *initial_amount)
                    .await
                    .unwrap();
            }

            token_atas.insert(token_name.clone(), ata);
        }

        // Create shares ATA
        let shares_ata =
            token_operations::create_ata_if_not_exists(ctx, &owner, &vault_accounts.shares_mint)
                .await;

        if token_atas.is_empty() {
            panic!("Must provide at least one token")
        }

        VaultDepositorAccounts {
            owner,
            token_atas,
            shares_ata,
        }
    }

    pub async fn balances(&self, ctx: &mut TestContext) -> VaultDepositorBalances {
        let shares_ata = ctx.get_balance(&self.shares_ata).await;
        let mut tokens = HashMap::new();

        // Get balances for all token ATAs
        for (token_name, token_ata) in &self.token_atas {
            let balance = ctx.get_balance(token_ata).await;
            tokens.insert(token_name.clone(), balance);
        }

        VaultDepositorBalances {
            tokens,
            shares: shares_ata,
        }
    }

    // Helper method to get balance for a specific token
    pub async fn token_balance(&self, ctx: &mut TestContext, token_name: &str) -> u64 {
        let token_ata = self.token_atas.get(token_name).unwrap();
        ctx.get_balance(token_ata).await
    }

    pub async fn total_aum(
        &self,
        ctx: &mut TestContext,
        vault_accounts: &VaultAccounts,
    ) -> Fraction {
        let vault_state = vault_accounts.state(ctx).await;
        let mut total_aum = Fraction::ZERO;
        for token_name in self.token_atas.keys() {
            let tokens = self.token_balance(ctx, token_name).await;
            let mint = vault_accounts.vault_tokens[token_name].token_mint;
            let token = vault_state
                .vault_tokens
                .iter()
                .find(|token| token.mint == mint)
                .unwrap();
            let decimals = token.decimals;
            let price = setup::get_scope_token_price(ctx, vault_accounts, token_name).await;
            let token_factor = 10u64.pow(decimals.into());
            let token_aum = Fraction::from_num(tokens as f64 * price / token_factor as f64);
            total_aum += token_aum;
        }
        total_aum
    }
}

impl VaultDepositorAccounts {
    pub fn to_investor_for_token(&self, token_name: &str) -> VaultInvestorAccounts {
        VaultInvestorAccounts {
            owner: self.owner.clone(),
            token_ata: *self.token_atas.get(token_name).unwrap(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct VaultInvestorAccounts {
    pub owner: Arc<Keypair>,
    pub token_ata: Pubkey,
}

impl VaultInvestorAccounts {
    pub async fn new(ctx: &mut TestContext, mint: Pubkey, initial_amount: u64) -> Self {
        let owner = funded_new_kp(ctx, LAMPORTS_PER_SOL);

        let ata = token_operations::create_ata(ctx, &owner, &mint).await;

        if initial_amount > 0 {
            token_operations::mint_to(ctx, &mint, &ata, initial_amount)
                .await
                .unwrap();
        }

        VaultInvestorAccounts {
            owner,
            token_ata: ata,
        }
    }

    pub async fn token_balance(&self, ctx: &mut TestContext) -> u64 {
        ctx.get_balance(&self.token_ata).await
    }
}

pub fn add_padding(string: String, max_len: usize) -> String {
    let len = string.len();
    let mut new_string = string.clone();
    for _ in len..max_len {
        new_string.add_assign("\0");
    }
    new_string
}

pub fn event_authority_pda() -> Pubkey {
    let (event_authority, _) = Pubkey::find_program_address(&[EVENT_AUTHORITY], &crate::ID);

    event_authority
}

pub fn token_vault_pda(mint: Pubkey, vault: Pubkey) -> Pubkey {
    let (token_vault, _) = Pubkey::find_program_address(
        &[consts::TOKEN_VAULT_SEED, mint.as_ref(), vault.as_ref()],
        &crate::ID,
    );

    token_vault
}

pub async fn get_global_config_state(
    ctx: &mut TestContext,
    global_config: &Pubkey,
) -> GlobalConfig {
    kamino_lending::program_test::common::runner::state::get::<crate::GlobalConfig>(
        ctx,
        *global_config,
    )
    .await
}

pub fn usdc_u64_to_decimal(usdc: u64) -> f64 {
    usdc as f64 / 10_f64.powi(6)
}

pub fn klend_error(error: LendingError, ix_index: u8) -> TransactionError {
    TransactionError::InstructionError(ix_index, InstructionError::Custom(6000 + error as u32))
}

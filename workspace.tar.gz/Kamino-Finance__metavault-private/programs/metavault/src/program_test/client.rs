use std::collections::HashMap;

use anchor_lang::{error, AccountDeserialize, Id};

use anchor_spl::{associated_token::get_associated_token_address_with_program_id, token::Token};
use borsh::BorshSerialize;
use kamino_lending::program_test::common::runner::state::try_get;
use kamino_lending::program_test::common::types::{LendingMarketAccounts, ReserveAccounts};
use kamino_lending::{
    program_test::common::{
        setup::{kp, KP},
        token_operations,
        types::TestContext,
    },
    send_transaction,
    utils::FULL_BPS,
    Obligation, ScopeConfiguration,
};
use solana_program::pubkey::Pubkey;
use solana_program_test::BanksClientError;
use solana_sdk::{
    account_info::IntoAccountInfo, compute_budget::ComputeBudgetInstruction,
    instruction::Instruction, signature::Keypair, signer::Signer,
};

use super::{
    instructions::OrderTokenAccounts, token_vault_pda, ScopePrice, VaultAccounts,
    VaultDepositorAccounts, VaultToken,
};
use crate::operations::{
    order_basket::{Order, OrderBasket},
    rebalance_basket::RebalanceBasket,
    rebalance_operations,
};
use crate::order::DepositOrder;
use crate::order::WithdrawOrder;
use crate::program_test::setup;
use crate::state::VaultToken as VaultTokenState;
use crate::types::{Timestamp, TokenAmount};
use crate::utils::remaining_accounts::RemainingAccounts;
use crate::utils::scope::VaultScopePrices;
use crate::utils::{consts::INITIAL_DEPOSIT_SIZE, global_config::UpdateGlobalConfigMode, pda};
use crate::{KaminoVaultError, MetavaultState, VaultConfigField};

pub async fn init_global_config(
    ctx: &mut TestContext,
    owner: &KP,
    global_config: &Pubkey,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::init_global_config(ctx, owner, global_config).await;

    send_transaction!(ctx, tx)
}

pub async fn update_global_config(
    ctx: &mut TestContext,
    global_config: &Pubkey,
    mode: UpdateGlobalConfigMode,
    value: Vec<u8>,
    owner: &KP,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::update_global_config(
        ctx,
        owner,
        global_config,
        mode,
        value,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn update_global_config_admin(
    ctx: &mut TestContext,
    global_config: &Pubkey,
    new_owner: &KP,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::update_global_config_admin(
        ctx,
        global_config,
        new_owner,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn init_vault(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
) -> Result<(), BanksClientError> {
    init_vault_with_acl_accounts(
        ctx,
        vault,
        vault.gating_program.map(|_| vault.shares_mint_config),
        vault.gating_program.map(|_| vault.token_acl_program),
    )
    .await
}

pub async fn init_vault_with_acl_accounts(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    shares_mint_config: Option<Pubkey>,
    token_acl_program: Option<Pubkey>,
) -> Result<(), BanksClientError> {
    let vault_token = &vault
        .vault_tokens
        .iter()
        .next()
        .expect("Vault accounts should set at least 1 token")
        .1;
    // Send minimum deposit amount to owner ata
    let owner = &ctx.initial_market_owner.clone();
    let owner_token_ata =
        token_operations::create_ata_if_not_exists(ctx, &owner.clone(), &vault_token.token_mint)
            .await;
    token_operations::mint_to(
        ctx,
        &vault_token.token_mint,
        &owner_token_ata,
        INITIAL_DEPOSIT_SIZE,
    )
    .await
    .unwrap();

    let scope_price = &vault.scope_prices[&vault_token.token_mint];
    let tx = crate::program_test::instructions::init_vault_with_acl_accounts(
        ctx,
        owner,
        vault,
        vault_token,
        scope_price.scope_feed,
        ScopeConfiguration {
            price_feed: scope_price.scope_feed,
            price_chain: [scope_price.price_index as u16, u16::MAX, u16::MAX, u16::MAX],
            twap_chain: [scope_price.twap_index as u16, u16::MAX, u16::MAX, u16::MAX],
        },
        Pubkey::default(),
        shares_mint_config,
        token_acl_program,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn deposit(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    token_name: &str,
    amount: u64,
) {
    try_deposit(ctx, vault, depositor, token_name, amount, 0)
        .await
        .unwrap();
}

pub async fn try_deposit(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    vault_depositor: &VaultDepositorAccounts,
    token_name: &str,
    amount: u64,
    min_shares_out: u64,
) -> Result<(), BanksClientError> {
    let vault_token = vault_accounts.vault_tokens.get(token_name).unwrap();
    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::deposit(
        ctx,
        vault_accounts,
        vault_depositor,
        vault_token,
        token_name,
        scope_accounts,
        amount,
        min_shares_out,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn withdraw_pending_fees(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    vault_admin: &VaultDepositorAccounts,
) {
    try_withdraw_pending_fees(ctx, vault, vault_admin)
        .await
        .unwrap();
}
pub async fn withdraw_pending_fees_and_redeem(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    vault_admin: &VaultDepositorAccounts,
    token_name: &str,
) {
    let owner_token_balance_before = vault_admin.balances(ctx).await.shares;
    try_withdraw_pending_fees(ctx, vault, vault_admin)
        .await
        .unwrap();
    let owner_token_balance_after = vault_admin.balances(ctx).await.shares;
    let fees_earned = owner_token_balance_after - owner_token_balance_before;
    try_withdraw(ctx, vault, vault_admin, fees_earned, token_name, 0)
        .await
        .unwrap();
}

pub async fn try_withdraw_pending_fees(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    vault_admin: &VaultDepositorAccounts,
) -> Result<(), BanksClientError> {
    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::withdraw_pending_fees(
        ctx,
        vault_accounts,
        vault_admin,
        scope_accounts,
    )
    .await;

    send_transaction!(ctx, tx)
}
pub async fn give_up_pending_fees(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    payer: &Keypair,
    max_amount_to_give_up: u64,
) {
    try_give_up_pending_fees(ctx, vault, payer, max_amount_to_give_up)
        .await
        .unwrap();
}

pub async fn try_give_up_pending_fees(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    payer: &Keypair,
    max_amount_to_give_up: u64,
) -> Result<(), BanksClientError> {
    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::give_up_pending_fees(
        ctx,
        vault_accounts,
        payer,
        scope_accounts,
        max_amount_to_give_up,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn refresh_vault(ctx: &mut TestContext, vault: &VaultAccounts, payer: &KP) {
    try_refresh_vault(ctx, vault, payer).await.unwrap();
}

pub async fn try_refresh_vault(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    payer: &KP,
) -> Result<(), BanksClientError> {
    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::refresh_vault(
        ctx,
        payer,
        vault_accounts,
        scope_accounts,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn get_ordered_scope_accounts(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
) -> Vec<Pubkey> {
    let vault = vault_accounts.state(ctx).await;
    let scope_accounts = vault
        .vault_tokens
        .iter()
        .filter_map(|token| {
            if token.is_token_set() {
                let token_name = vault_accounts.get_token_name_by_mint(token.mint);
                let mint = vault_accounts.vault_tokens[&token_name].token_mint;
                Some(vault_accounts.scope_prices[&mint].scope_feed)
            } else {
                None
            }
        })
        .collect();
    scope_accounts
}

pub async fn get_ordered_obligation_accounts(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
) -> Vec<Pubkey> {
    vault_accounts
        .state(ctx)
        .await
        .iter_enabled_obligations()
        .map(|o| o.obligation)
        .collect()
}

/// Reads a klend zero-copy `Obligation` from the test ledger.
async fn read_klend_obligation(ctx: &mut TestContext, address: Pubkey) -> Obligation {
    let account = ctx.get_account(address).await.unwrap().unwrap();
    bytemuck::pod_read_unaligned(&account.data[8..8 + std::mem::size_of::<Obligation>()])
}

/// Leg-reserve segment: for each enabled obligation, its active deposit reserves then active
/// borrow reserves — the segment-3 layout of `AumAccounts::parse`.
pub async fn get_ordered_leg_reserve_accounts(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
) -> Vec<Pubkey> {
    let mut reserves = vec![];
    for obligation_address in get_ordered_obligation_accounts(ctx, vault_accounts).await {
        let obligation = read_klend_obligation(ctx, obligation_address).await;
        reserves.extend(obligation.active_deposits().map(|d| d.deposit_reserve));
        reserves.extend(obligation.active_borrows().map(|b| b.borrow_reserve));
    }
    reserves
}

/// Returns `[scope_acc...][obligation_acc...][leg_reserve_acc...]` matching the layout expected
/// by `AumAccounts::parse()`.
pub async fn get_ordered_scope_and_obligation_accounts(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
) -> Vec<Pubkey> {
    [
        get_ordered_scope_accounts(ctx, vault_accounts).await,
        get_ordered_obligation_accounts(ctx, vault_accounts).await,
        get_ordered_leg_reserve_accounts(ctx, vault_accounts).await,
    ]
    .concat()
}

pub async fn withdraw(
    ctx: &mut TestContext,
    vault: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    amount: u64,
    token_name: &str,
) {
    try_withdraw(ctx, vault, depositor, amount, token_name, 0)
        .await
        .unwrap();
}

pub async fn try_withdraw(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    vault_depositor: &VaultDepositorAccounts,
    amount: u64,
    token_name: &str,
    min_tokens_out: u64,
) -> Result<(), BanksClientError> {
    let vault_token = vault_accounts.vault_tokens.get(token_name).unwrap();
    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::withdraw(
        ctx,
        vault_accounts,
        vault_depositor,
        vault_token,
        token_name,
        scope_accounts,
        amount,
        min_tokens_out,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn init_shares_metadata(
    ctx: &mut TestContext,
    payer: &KP,
    vault_accounts: &VaultAccounts,
    name: String,
    symbol: String,
    uri: String,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::init_shares_metadata(
        ctx,
        payer,
        vault_accounts,
        name,
        symbol,
        uri,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn update_shares_metadata(
    ctx: &mut TestContext,
    payer: &KP,
    vault_accounts: &VaultAccounts,
    name: String,
    symbol: String,
    uri: String,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::update_shares_metadata(
        ctx,
        payer,
        vault_accounts,
        name,
        symbol,
        uri,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn thaw_shares_account(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    user_shares_account: Pubkey,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::thaw_shares_account(
        ctx,
        authority,
        vault_accounts,
        user_shares_account,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn freeze_shares_account(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    user_shares_account: Pubkey,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::freeze_shares_account(
        ctx,
        authority,
        vault_accounts,
        user_shares_account,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn set_shares_gating_program(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    new_gating_program: Pubkey,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::set_shares_gating_program(
        ctx,
        owner,
        vault_accounts,
        new_gating_program,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn toggle_shares_permissionless(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    freeze_enabled: bool,
    thaw_enabled: bool,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::toggle_shares_permissionless(
        ctx,
        owner,
        vault_accounts,
        freeze_enabled,
        thaw_enabled,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn delete_shares_config(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
) -> Result<(), BanksClientError> {
    let tx =
        crate::program_test::instructions::delete_shares_config(ctx, owner, vault_accounts).await;

    send_transaction!(ctx, tx)
}

#[derive(Debug, Clone)]
pub enum UpdateVaultConfigParams {
    PerformanceFeeBps(u64),
    ManagementFeeBps(u64),
    PendingVaultAdmin(Pubkey),
    VaultLookupTable(Pubkey),
    VaultFarm(Pubkey),
    VaultName(String),
    VaultTokenScope(Pubkey, ScopeConfiguration),
    VaultTokenMaxTwapDivergenceBps(Pubkey, u64),
    VaultTokenMaxAgePriceSeconds(Pubkey, u64),
    VaultTokenMaxAgeTwapSeconds(Pubkey, u64),
    VaultTokenMinDepositAmount(Pubkey, u64),
    VaultTokenMinWithdrawAmount(Pubkey, u64),
    VaultTokenDepositFeeBps(Pubkey, u64),
    VaultTokenDepositFeeLamports(Pubkey, u64),
    VaultTokenWithdrawFeeBps(Pubkey, u64),
    VaultTokenWithdrawFeeLamports(Pubkey, u64),
    VaultTokenMaxDeviationBps(Pubkey, u64),
    VaultTokenMaxPriceDivergenceBps(Pubkey, u64),
    VaultTokenWeights(Vec<u64>),
    VaultTokenDutchAuctionBounds(Pubkey, u64, u64, u64, u64), // mint, start_sell, end_sell, start_buy, end_buy
    DepositCapUsd(u128),                                      // raw DollarValue bits (0 disables)
    RollingDepositCap {
        max_usd_sf: u128,
        interval_seconds: u64,
    },
    RollingWithdrawCap {
        max_usd_sf: u128,
        interval_seconds: u64,
    },
    EmergencyCouncil(Pubkey),
    UnfreezeAuthority(Pubkey),
    EmergencyMode(bool),
    BlockDeposits(bool),
    BlockWithdraws(bool),
    SwapAuthority(Pubkey),
    MaxRebalanceSwapSlippageBps(u64),
    MaxRebalanceLossBps(u64),
    AllocationAdminAuthority(Pubkey),
    VaultObligationMaxUnhealthyLtvFractionBps(Pubkey, u64), // obligation, bps
    RebalanceCooldownSeconds(u64),
    KrfqEnabled(bool),
    DepositOrderCreationEnabled(bool),
    DepositOrderFillEnabled(bool),
    DepositOrderSettleEnabled(bool),
    OrderMinOpenUsd(u128),
    WithdrawOrderCreationEnabled(bool),
    WithdrawOrderFillEnabled(bool),
}

pub async fn try_update_vault_config(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    update: UpdateVaultConfigParams,
) -> Result<(), BanksClientError> {
    let (field, data) = match update {
        UpdateVaultConfigParams::PerformanceFeeBps(value) => (
            VaultConfigField::PerformanceFeeBps,
            value.try_to_vec().unwrap(),
        ),
        UpdateVaultConfigParams::ManagementFeeBps(value) => (
            VaultConfigField::ManagementFeeBps,
            value.try_to_vec().unwrap(),
        ),
        UpdateVaultConfigParams::PendingVaultAdmin(value) => (
            VaultConfigField::PendingVaultAdmin,
            value.to_bytes().to_vec(),
        ),
        UpdateVaultConfigParams::VaultLookupTable(value) => {
            (VaultConfigField::LookupTable, value.to_bytes().to_vec())
        }
        UpdateVaultConfigParams::VaultFarm(value) => {
            (VaultConfigField::Farm, value.to_bytes().to_vec())
        }
        UpdateVaultConfigParams::VaultName(value) => {
            (VaultConfigField::Name, value.as_bytes().to_vec())
        }
        UpdateVaultConfigParams::VaultTokenScope(mint, value) => (
            VaultConfigField::VaultTokenScope,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMaxTwapDivergenceBps(mint, value) => (
            VaultConfigField::VaultTokenMaxTwapDivergenceBps,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMaxAgePriceSeconds(mint, value) => (
            VaultConfigField::VaultTokenMaxAgePriceSeconds,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMaxAgeTwapSeconds(mint, value) => (
            VaultConfigField::VaultTokenMaxAgeTwapSeconds,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMinDepositAmount(mint, value) => (
            VaultConfigField::VaultTokenMinDepositAmount,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMinWithdrawAmount(mint, value) => (
            VaultConfigField::VaultTokenMinWithdrawAmount,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenDepositFeeBps(mint, value) => (
            VaultConfigField::VaultTokenDepositFeeBps,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenDepositFeeLamports(mint, value) => (
            VaultConfigField::VaultTokenDepositFeeLamports,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenWithdrawFeeBps(mint, value) => (
            VaultConfigField::VaultTokenWithdrawFeeBps,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenWithdrawFeeLamports(mint, value) => (
            VaultConfigField::VaultTokenWithdrawFeeLamports,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMaxDeviationBps(mint, value) => (
            VaultConfigField::VaultTokenMaxDeviationBps,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenMaxPriceDivergenceBps(mint, value) => (
            VaultConfigField::VaultTokenMaxPriceDivergenceBps,
            [mint.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::VaultTokenWeights(weights) => (
            VaultConfigField::TokenWeights,
            weights.iter().flat_map(|&n| n.to_le_bytes()).collect(),
        ),
        UpdateVaultConfigParams::VaultTokenDutchAuctionBounds(
            mint,
            start_sell,
            end_sell,
            start_buy,
            end_buy,
        ) => (
            VaultConfigField::VaultTokenDutchAuctionBounds,
            [
                mint.to_bytes().to_vec(),
                start_sell.try_to_vec().unwrap(),
                end_sell.try_to_vec().unwrap(),
                start_buy.try_to_vec().unwrap(),
                end_buy.try_to_vec().unwrap(),
            ]
            .concat()
            .to_vec(),
        ),
        UpdateVaultConfigParams::DepositCapUsd(value) => (
            VaultConfigField::DepositCapUsd,
            value.to_le_bytes().to_vec(),
        ),
        UpdateVaultConfigParams::RollingDepositCap {
            max_usd_sf,
            interval_seconds,
        } => (
            VaultConfigField::RollingDepositCap,
            [
                max_usd_sf.to_le_bytes().to_vec(),
                interval_seconds.to_le_bytes().to_vec(),
            ]
            .concat()
            .to_vec(),
        ),
        UpdateVaultConfigParams::RollingWithdrawCap {
            max_usd_sf,
            interval_seconds,
        } => (
            VaultConfigField::RollingWithdrawCap,
            [
                max_usd_sf.to_le_bytes().to_vec(),
                interval_seconds.to_le_bytes().to_vec(),
            ]
            .concat()
            .to_vec(),
        ),
        UpdateVaultConfigParams::EmergencyCouncil(value) => (
            VaultConfigField::EmergencyCouncil,
            value.to_bytes().to_vec(),
        ),
        UpdateVaultConfigParams::UnfreezeAuthority(value) => (
            VaultConfigField::UnfreezeAuthority,
            value.to_bytes().to_vec(),
        ),
        UpdateVaultConfigParams::SwapAuthority(value) => {
            (VaultConfigField::SwapAuthority, value.to_bytes().to_vec())
        }
        UpdateVaultConfigParams::MaxRebalanceSwapSlippageBps(value) => (
            VaultConfigField::MaxRebalanceSwapSlippageBps,
            value.try_to_vec().unwrap(),
        ),
        UpdateVaultConfigParams::MaxRebalanceLossBps(value) => (
            VaultConfigField::MaxRebalanceLossBps,
            value.try_to_vec().unwrap(),
        ),
        UpdateVaultConfigParams::AllocationAdminAuthority(value) => (
            VaultConfigField::AllocationAdminAuthority,
            value.to_bytes().to_vec(),
        ),
        UpdateVaultConfigParams::EmergencyMode(value) => {
            (VaultConfigField::EmergencyMode, vec![u8::from(value)])
        }
        UpdateVaultConfigParams::BlockDeposits(value) => {
            (VaultConfigField::BlockDeposits, vec![u8::from(value)])
        }
        UpdateVaultConfigParams::BlockWithdraws(value) => {
            (VaultConfigField::BlockWithdraws, vec![u8::from(value)])
        }
        UpdateVaultConfigParams::VaultObligationMaxUnhealthyLtvFractionBps(obligation, value) => (
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps,
            [obligation.to_bytes().to_vec(), value.try_to_vec().unwrap()]
                .concat()
                .to_vec(),
        ),
        UpdateVaultConfigParams::RebalanceCooldownSeconds(value) => (
            VaultConfigField::RebalanceCooldownSeconds,
            value.try_to_vec().unwrap(),
        ),
        UpdateVaultConfigParams::KrfqEnabled(value) => {
            (VaultConfigField::KrfqEnabled, vec![u8::from(value)])
        }
        UpdateVaultConfigParams::DepositOrderCreationEnabled(value) => (
            VaultConfigField::DepositOrderCreationEnabled,
            vec![u8::from(value)],
        ),
        UpdateVaultConfigParams::DepositOrderFillEnabled(value) => (
            VaultConfigField::DepositOrderFillEnabled,
            vec![u8::from(value)],
        ),
        UpdateVaultConfigParams::DepositOrderSettleEnabled(value) => (
            VaultConfigField::DepositOrderSettleEnabled,
            vec![u8::from(value)],
        ),
        UpdateVaultConfigParams::WithdrawOrderCreationEnabled(value) => (
            VaultConfigField::WithdrawOrderCreationEnabled,
            vec![u8::from(value)],
        ),
        UpdateVaultConfigParams::WithdrawOrderFillEnabled(value) => (
            VaultConfigField::WithdrawOrderFillEnabled,
            vec![u8::from(value)],
        ),
        UpdateVaultConfigParams::OrderMinOpenUsd(value) => (
            VaultConfigField::OrderMinOpenUsd,
            value.to_le_bytes().to_vec(),
        ),
    };

    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::update_vault_config(
        ctx,
        owner,
        vault_accounts,
        field,
        data,
        scope_accounts,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn update_vault_config(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    update: UpdateVaultConfigParams,
) {
    try_update_vault_config(ctx, owner, vault_accounts, update)
        .await
        .unwrap();
}

pub async fn try_add_vault_token(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &mut VaultAccounts,
    token_name: &str,
    mint: Pubkey,
    scope_feed: Pubkey,
) -> Result<(), BanksClientError> {
    let (price_index, twap_index) = vault_accounts.get_first_scope_idx_for_feed(scope_feed);
    add_vault_token_with_scope_config_inner(
        ctx,
        owner,
        vault_accounts,
        token_name,
        mint,
        ScopeConfiguration {
            price_feed: scope_feed,
            price_chain: [price_index, u16::MAX, u16::MAX, u16::MAX],
            twap_chain: [twap_index, u16::MAX, u16::MAX, u16::MAX],
        },
    )
    .await
}

/// Variant that uses a caller-supplied `ScopeConfiguration` verbatim instead of auto-assigning
/// scope chain indices. Used by test fixtures to mirror klend's per-reserve scope chain onto
/// the matching metavault vault_token, which the new per-handler scope-config equality
/// constraint requires.
pub async fn add_vault_token_with_scope_config(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &mut VaultAccounts,
    token_name: &str,
    mint: Pubkey,
    scope_config: ScopeConfiguration,
) {
    add_vault_token_with_scope_config_inner(
        ctx,
        owner,
        vault_accounts,
        token_name,
        mint,
        scope_config,
    )
    .await
    .unwrap()
}

async fn add_vault_token_with_scope_config_inner(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &mut VaultAccounts,
    token_name: &str,
    mint: Pubkey,
    scope_config: ScopeConfiguration,
) -> Result<(), BanksClientError> {
    let vault = token_vault_pda(mint, vault_accounts.vault_state.pubkey());
    let token_program = ctx
        .get_account(mint)
        .await
        .unwrap()
        .map(|acc| acc.owner)
        .unwrap_or(Token::id());
    let tx = crate::program_test::instructions::add_vault_token(
        ctx,
        owner,
        vault_accounts,
        mint,
        vault,
        token_program,
        scope_config,
    )
    .await;

    send_transaction!(ctx, tx)?;

    vault_accounts.vault_tokens.insert(
        token_name.to_string(),
        VaultToken {
            token_mint: mint,
            token_vault: vault,
            token_program,
        },
    );
    vault_accounts.scope_prices.insert(
        mint,
        ScopePrice {
            scope_feed: scope_config.price_feed,
            price_index: scope_config.price_chain[0] as usize,
            twap_index: scope_config.twap_chain[0] as usize,
        },
    );

    Ok(())
}

pub async fn add_vault_token(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &mut VaultAccounts,
    token_name: &str,
    mint: Pubkey,
    scope_feed: Pubkey,
) {
    try_add_vault_token(ctx, owner, vault_accounts, token_name, mint, scope_feed)
        .await
        .unwrap();
    give_every_token_an_equal_weight(ctx, vault_accounts).await;
}

/// Leaves the vault configured: a token carrying no target weight takes no deposits, and a
/// harness that added one without giving it a target would be describing a vault nobody shaped.
/// Tests wanting particular targets set them afterwards.
pub async fn give_every_token_an_equal_weight(ctx: &mut TestContext, vault: &VaultAccounts) {
    let admin = ctx.initial_market_owner.clone();
    update_vault_config(
        ctx,
        &admin,
        vault,
        UpdateVaultConfigParams::VaultTokenWeights(vec![1; vault.vault_tokens.len()]),
    )
    .await;
}

pub async fn try_apply_pending_admin(
    ctx: &mut TestContext,
    vault: &Pubkey,
    new_admin: &KP,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::apply_pending_admin(ctx, vault, new_admin).await;

    send_transaction!(ctx, tx)
}

pub async fn apply_pending_admin(ctx: &mut TestContext, vault: &Pubkey, new_admin: &KP) {
    try_apply_pending_admin(ctx, vault, new_admin)
        .await
        .unwrap();
}

pub async fn try_start_rebalance(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    rebalance_duration: u64,
) -> Result<(), BanksClientError> {
    let scope_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;

    let tx = crate::program_test::instructions::start_rebalance(
        ctx,
        authority,
        &vault_accounts.vault_state.pubkey(),
        rebalance_duration,
        scope_accounts,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn start_rebalance(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    rebalance_duration: u64,
) {
    try_start_rebalance(ctx, authority, vault_accounts, rebalance_duration)
        .await
        .unwrap();
}

pub async fn try_stop_rebalance(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::stop_rebalance(
        ctx,
        authority,
        &vault_accounts.vault_state.pubkey(),
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn stop_rebalance(ctx: &mut TestContext, authority: &KP, vault_accounts: &VaultAccounts) {
    try_stop_rebalance(ctx, authority, vault_accounts)
        .await
        .unwrap();
}

/// What a test asks the vault to pay out for a fill.
#[derive(Debug, Clone, Copy)]
pub enum RequestedOut {
    /// Exactly the dutch-auction quote at the current clock, computed off-chain with the
    /// program's own quoting path on a copy of the vault state. This reproduces the payout the
    /// vault used to make unconditionally, so the vault gives up no surplus.
    AtCurve,
    Exact(u64),
}

/// The curve quote for a fill at the current clock, or the error the vault would raise for the
/// request (wrong direction, expired rebalance, dust input, ...).
pub async fn curve_quote(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
) -> anchor_lang::Result<u64> {
    let vault_state = vault_accounts.state(ctx).await;
    let (prices, timestamp) = load_scope_prices(ctx, vault_accounts, &vault_state).await?;
    let quote = rebalance_operations::quote_rebalance_swap(
        &vault_state.tokens(),
        &vault_state.rebalance,
        &prices,
        &vault_accounts.vault_tokens[token_in_name].token_mint,
        &vault_accounts.vault_tokens[token_out_name].token_mint,
        TokenAmount::from(amount_in),
        timestamp,
    )?;
    Ok(quote.max_out_from_curve.into())
}

/// The vault's rebalance targets at the current on-chain prices, one per enabled token in token
/// order, exactly as the program derives them.
pub async fn rebalance_targets(ctx: &mut TestContext, vault_accounts: &VaultAccounts) -> Vec<u64> {
    let vault_state = vault_accounts.state(ctx).await;
    let (prices, _) = load_scope_prices(ctx, vault_accounts, &vault_state)
        .await
        .expect("scope prices");
    vault_state
        .tokens()
        .targets(&prices)
        .iter()
        .map(u64::from)
        .collect()
}

/// The rebalance target of one token, by name, at the current on-chain prices.
pub async fn rebalance_target(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token_name: &str,
) -> u64 {
    let vault_state = vault_accounts.state(ctx).await;
    let id = vault_state
        .get_vault_token_id_by_mint(&vault_accounts.vault_tokens[token_name].token_mint)
        .unwrap();
    rebalance_targets(ctx, vault_accounts).await[id.input_account_index]
}

async fn load_scope_prices(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    vault_state: &MetavaultState,
) -> anchor_lang::Result<(VaultScopePrices, Timestamp)> {
    let mut scope_accounts = Vec::new();
    for key in get_ordered_scope_accounts(ctx, vault_accounts).await {
        // A test pointing a token at a missing feed expects the on-chain rejection, not a panic.
        let Some(account) = ctx.get_account(key).await.ok().flatten() else {
            return Err(error!(KaminoVaultError::InvalidScopePriceAccount));
        };
        scope_accounts.push((key, account));
    }
    let scope_account_infos: Vec<_> = scope_accounts
        .iter_mut()
        .map(|(key, account)| (&*key, account).into_account_info())
        .collect();
    let clock = ctx.get_clock().await;
    let timestamp = Timestamp::capture(&clock)?;
    let prices = VaultScopePrices::load_and_validate_from_remaining_accounts(
        vault_state,
        &mut RemainingAccounts::new(&scope_account_infos),
        timestamp,
    )?;
    Ok((prices, timestamp))
}

#[allow(clippy::too_many_arguments)]
pub async fn try_rebalance_swap_with_krfq(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
    krfq_authority: Option<&KP>,
    global_config: Pubkey,
) -> Result<(), BanksClientError> {
    try_rebalance_swap_with_krfq_marker(
        ctx,
        user,
        vault_accounts,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
        krfq_authority,
        global_config,
        // A co-signed fill carries the marker its identity derives to; the
        // permissionless path omits it, as real callers do.
        KrfqMarker::Derived,
    )
    .await
}

/// What a `rebalance_swap` fills: the vault itself, or one order held inside it.
#[derive(Debug, Clone, Copy)]
pub enum FillTarget {
    Vault,
    DepositOrder(Pubkey),
    WithdrawOrder(Pubkey),
}

/// Which marker a test hands to `rebalance_swap`. `Derived` is what an honest
/// caller sends; the others exist so the enforcement can be proven.
#[derive(Debug, Clone, Copy)]
pub enum KrfqMarker {
    /// Derive it from the fill's own vault and mint pair.
    Derived,
    /// Omit the account entirely.
    Omitted,
    /// Send this pubkey instead — a marker for some other fill.
    Wrong(Pubkey),
}

#[allow(clippy::too_many_arguments)]
pub async fn try_rebalance_swap_with_krfq_marker(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
    krfq_authority: Option<&KP>,
    global_config: Pubkey,
    marker: KrfqMarker,
) -> Result<(), BanksClientError> {
    let requested_out_amount = match requested_out {
        RequestedOut::Exact(amount) => amount,
        // A request the vault refuses anyway has no quote; send 0 so the test observes the
        // on-chain error it is after, not a client-side unwrap.
        RequestedOut::AtCurve => curve_quote(
            ctx,
            vault_accounts,
            token_in_name,
            token_out_name,
            amount_in,
        )
        .await
        .unwrap_or(0),
    };
    try_fill_with_krfq_marker(
        ctx,
        user,
        vault_accounts,
        FillTarget::Vault,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out_amount,
        krfq_authority,
        global_config,
        marker,
    )
    .await
}

/// A fill against `target`, with the token accounts, the remaining accounts and the marker as
/// the honest caller would pass them: a vault fill carries the whole AUM layout and is keyed on
/// the vault, an order fill carries the scope prices alone and is keyed on the order.
#[allow(clippy::too_many_arguments)]
pub async fn try_fill_with_krfq_marker(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    target: FillTarget,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out_amount: u64,
    krfq_authority: Option<&KP>,
    global_config: Pubkey,
    marker: KrfqMarker,
) -> Result<(), BanksClientError> {
    let token_in = &vault_accounts.vault_tokens[token_in_name];
    let token_out = &vault_accounts.vault_tokens[token_out_name];
    let user_token_in_ata =
        token_operations::create_ata_if_not_exists(ctx, user, &token_in.token_mint).await;
    let user_token_out_ata =
        token_operations::create_ata_if_not_exists(ctx, user, &token_out.token_mint).await;
    let (basket, remaining_accounts, deposit_order, withdraw_order) = match target {
        FillTarget::Vault => (
            vault_accounts.vault_state.pubkey(),
            get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await,
            None,
            None,
        ),
        FillTarget::DepositOrder(order) => (
            order,
            get_ordered_scope_accounts(ctx, vault_accounts).await,
            Some(order),
            None,
        ),
        FillTarget::WithdrawOrder(order) => (
            order,
            get_ordered_scope_accounts(ctx, vault_accounts).await,
            None,
            Some(order),
        ),
    };
    let krfq_fill_marker = match marker {
        KrfqMarker::Omitted => None,
        KrfqMarker::Wrong(key) => Some(key),
        KrfqMarker::Derived => krfq_authority
            .map(|_| pda::krfq_fill_marker(&basket, &token_in.token_mint, &token_out.token_mint)),
    };

    let tx = crate::program_test::instructions::rebalance_swap(
        ctx,
        user,
        vault_accounts,
        &user_token_in_ata,
        &user_token_out_ata,
        token_in,
        token_out,
        amount_in,
        requested_out_amount,
        remaining_accounts,
        krfq_authority,
        global_config,
        krfq_fill_marker,
        deposit_order,
        withdraw_order,
    )
    .await;
    send_transaction!(ctx, tx)
}

pub async fn try_rebalance_swap(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
) -> Result<(), BanksClientError> {
    try_rebalance_swap_with_krfq(
        ctx,
        user,
        vault_accounts,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
        None,
        pda::global_config(),
    )
    .await
}

pub async fn rebalance_swap(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
) {
    try_rebalance_swap(
        ctx,
        user,
        vault_accounts,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
    )
    .await
    .unwrap();
}

// ── Deposit order client helpers ────────────────────────────────────

pub fn deposit_order_pda(vault_accounts: &VaultAccounts, owner: &Pubkey, id: u8) -> Pubkey {
    pda::deposit_order(&vault_accounts.vault_state.pubkey(), owner, id)
}

pub async fn deposit_order_state(ctx: &mut TestContext, deposit_order: Pubkey) -> DepositOrder {
    try_deposit_order_state(ctx, deposit_order)
        .await
        .expect("the deposit order exists")
}

/// [None] once the order is closed (its account deleted).
pub async fn try_deposit_order_state(
    ctx: &mut TestContext,
    deposit_order: Pubkey,
) -> Option<DepositOrder> {
    try_get::<DepositOrder>(ctx, deposit_order).await.ok()
}

/// Locks `amounts` by token name (unnamed tokens as zero) and settles what the vault's bounds admit
/// at once, in one transaction.
pub async fn open_and_settle_deposit_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    id: u8,
    amounts: &[(&str, u64)],
    duration_seconds: u64,
) -> Pubkey {
    try_open_and_settle_deposit_order(
        ctx,
        vault_accounts,
        depositor,
        id,
        amounts,
        duration_seconds,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    deposit_order_pda(vault_accounts, &depositor.owner.pubkey(), id)
}

/// Locks `amounts` by token name and leaves every lamport of it on the auction.
pub async fn open_deposit_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    id: u8,
    amounts: &[(&str, u64)],
    duration_seconds: u64,
) -> Pubkey {
    try_open_deposit_order(
        ctx,
        vault_accounts,
        depositor,
        id,
        amounts,
        duration_seconds,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    deposit_order_pda(vault_accounts, &depositor.owner.pubkey(), id)
}

#[allow(clippy::too_many_arguments)]
pub async fn try_open_and_settle_deposit_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    id: u8,
    amounts: &[(&str, u64)],
    duration_seconds: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<(), BanksClientError> {
    let (dense_amounts, per_token) =
        order_token_accounts_and_amounts(ctx, vault_accounts, depositor, amounts).await;
    try_open_and_settle_deposit_order_raw(
        ctx,
        vault_accounts,
        depositor,
        id,
        &per_token,
        dense_amounts,
        duration_seconds,
        max_fill_slippage_bps,
        max_loss_bps,
    )
    .await
}

/// Locks the basket and leaves all of it on the auction, absorbing none.
#[allow(clippy::too_many_arguments)]
pub async fn try_open_deposit_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    id: u8,
    amounts: &[(&str, u64)],
    duration_seconds: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<(), BanksClientError> {
    let (dense_amounts, per_token) =
        order_token_accounts_and_amounts(ctx, vault_accounts, depositor, amounts).await;
    let deposit_order = deposit_order_pda(vault_accounts, &depositor.owner.pubkey(), id);
    let scope_accounts = get_ordered_scope_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::open_deposit_order(
        ctx,
        vault_accounts,
        depositor,
        deposit_order,
        id,
        &per_token,
        dense_amounts,
        duration_seconds,
        0,
        max_fill_slippage_bps,
        max_loss_bps,
        scope_accounts,
    )
    .await;
    send_transaction!(ctx, tx)
}

/// Opens and settles with the `amounts` and token accounts exactly as given (for account tests).
#[allow(clippy::too_many_arguments)]
pub async fn try_open_and_settle_deposit_order_raw(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    id: u8,
    per_token: &[OrderTokenAccounts],
    amounts: Vec<u64>,
    duration_seconds: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<(), BanksClientError> {
    let deposit_order = deposit_order_pda(vault_accounts, &depositor.owner.pubkey(), id);
    let scope_accounts = get_ordered_scope_accounts(ctx, vault_accounts).await;
    let aum_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::open_and_settle_deposit_order(
        ctx,
        vault_accounts,
        depositor,
        deposit_order,
        id,
        per_token,
        amounts,
        duration_seconds,
        0,
        max_fill_slippage_bps,
        max_loss_bps,
        scope_accounts,
        aum_accounts,
    )
    .await;
    send_transaction!(ctx, tx)
}

/// Opens and settles, refusing a share price above what `min_shares_out` implies for the basket.
#[allow(clippy::too_many_arguments)]
pub async fn try_open_and_settle_deposit_order_with_min_shares(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    id: u8,
    amounts: &[(&str, u64)],
    duration_seconds: u64,
    min_shares_out: u64,
) -> Result<(), BanksClientError> {
    let (dense_amounts, per_token) =
        order_token_accounts_and_amounts(ctx, vault_accounts, depositor, amounts).await;
    let deposit_order = deposit_order_pda(vault_accounts, &depositor.owner.pubkey(), id);
    let scope_accounts = get_ordered_scope_accounts(ctx, vault_accounts).await;
    let aum_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::open_and_settle_deposit_order(
        ctx,
        vault_accounts,
        depositor,
        deposit_order,
        id,
        &per_token,
        dense_amounts,
        duration_seconds,
        min_shares_out,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
        scope_accounts,
        aum_accounts,
    )
    .await;
    send_transaction!(ctx, tx)
}

/// The deposit order's rebalance targets at the current on-chain prices, by token name.
pub async fn order_rebalance_target(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    token_name: &str,
) -> u64 {
    let mut order = deposit_order_state(ctx, deposit_order).await;
    rebalance_target_of(ctx, vault_accounts, &mut order, token_name).await
}

#[allow(clippy::too_many_arguments)]
pub async fn fill_deposit_order(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
) {
    try_fill_deposit_order(
        ctx,
        user,
        vault_accounts,
        deposit_order,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
    )
    .await
    .unwrap();
}

#[allow(clippy::too_many_arguments)]
pub async fn try_fill_deposit_order(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
) -> Result<(), BanksClientError> {
    try_fill_deposit_order_with_krfq_marker(
        ctx,
        user,
        vault_accounts,
        deposit_order,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
        None,
        pda::global_config(),
        KrfqMarker::Derived,
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub async fn try_fill_deposit_order_with_krfq_marker(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
    krfq_authority: Option<&KP>,
    global_config: Pubkey,
    marker: KrfqMarker,
) -> Result<(), BanksClientError> {
    let requested_out_amount = match requested_out {
        RequestedOut::Exact(amount) => amount,
        RequestedOut::AtCurve => order_curve_quote(
            ctx,
            vault_accounts,
            deposit_order,
            token_in_name,
            token_out_name,
            amount_in,
        )
        .await
        .unwrap_or(0),
    };
    try_fill_with_krfq_marker(
        ctx,
        user,
        vault_accounts,
        FillTarget::DepositOrder(deposit_order),
        token_in_name,
        token_out_name,
        amount_in,
        requested_out_amount,
        krfq_authority,
        global_config,
        marker,
    )
    .await
}

pub async fn settle_deposit_order(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
) {
    try_settle_deposit_order(ctx, signer, vault_accounts, deposit_order)
        .await
        .unwrap();
}

pub async fn try_settle_deposit_order(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
) -> Result<(), BanksClientError> {
    let order = deposit_order_state(ctx, deposit_order).await;
    let per_token = order_payout_accounts(ctx, vault_accounts, &order).await;
    try_settle_deposit_order_raw(
        ctx,
        signer,
        vault_accounts,
        deposit_order,
        order.base.owner,
        &per_token,
    )
    .await
}

pub async fn try_settle_deposit_order_raw(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    owner: Pubkey,
    per_token: &[OrderTokenAccounts],
) -> Result<(), BanksClientError> {
    let owner_shares_ata = get_associated_token_address_with_program_id(
        &owner,
        &vault_accounts.shares_mint,
        &vault_accounts.shares_token_program,
    );
    try_settle_deposit_order_into_raw(
        ctx,
        signer,
        vault_accounts,
        deposit_order,
        owner,
        owner_shares_ata,
        per_token,
    )
    .await
}

/// Pays the shares into `owner_shares_account` (any shares TA of the owner's).
pub async fn try_settle_deposit_order_into(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    owner_shares_account: Pubkey,
) -> Result<(), BanksClientError> {
    let order = deposit_order_state(ctx, deposit_order).await;
    let per_token = order_payout_accounts(ctx, vault_accounts, &order).await;
    try_settle_deposit_order_into_raw(
        ctx,
        signer,
        vault_accounts,
        deposit_order,
        order.base.owner,
        owner_shares_account,
        &per_token,
    )
    .await
}

pub async fn cancel_deposit_order(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
) {
    try_cancel_deposit_order(ctx, owner, vault_accounts, deposit_order)
        .await
        .unwrap();
}

/// Refunds go to the order owner's associated token accounts, which the depositor fixtures
/// create.
pub async fn try_cancel_deposit_order(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
) -> Result<(), BanksClientError> {
    let order = deposit_order_state(ctx, deposit_order).await;
    let per_token = order_payout_accounts(ctx, vault_accounts, &order).await;
    try_cancel_deposit_order_raw(ctx, owner, vault_accounts, deposit_order, &per_token).await
}

pub async fn try_cancel_deposit_order_raw(
    ctx: &mut TestContext,
    owner: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    per_token: &[OrderTokenAccounts],
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::cancel_deposit_order(
        ctx,
        owner,
        vault_accounts,
        deposit_order,
        per_token,
    )
    .await;
    send_transaction!(ctx, tx)
}

// ── Order suite helpers (both kinds) ─────────────────────────────────

/// Sends `ix` alone behind a compute budget (so its error is at index 1), signed by `payer`.
pub async fn try_send_ix(
    ctx: &mut TestContext,
    payer: &KP,
    ix: Instruction,
) -> Result<(), BanksClientError> {
    let cu_ix = ComputeBudgetInstruction::set_compute_unit_limit(1_000_000);
    let tx = ctx.create_transaction_with_payer([cu_ix, ix], payer).await;
    send_transaction!(ctx, tx)
}

/// Moves the clock and keeps the oracle prices fresh across the move.
pub async fn skip(ctx: &mut TestContext, vault_accounts: &VaultAccounts, seconds: u64) {
    ctx.fast_forward_seconds(seconds).await;
    for (name, price) in [("USDC", 1.0), ("SOL", 100.0), ("ETH", 2000.0)] {
        if vault_accounts.vault_tokens.contains_key(name) {
            setup::update_scope_px_and_twap(ctx, vault_accounts, name, price, price).await;
        }
    }
}

pub async fn lamports_of(ctx: &mut TestContext, address: Pubkey) -> u64 {
    ctx.get_account(address)
        .await
        .unwrap()
        .map_or(0, |account| account.lamports)
}

/// A user holding `usdc` (and an empty SOL account) of the balanced vault's tokens.
pub async fn usdc_holder(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    usdc: u64,
) -> VaultDepositorAccounts {
    token_holder(ctx, vault_accounts, usdc, 0).await
}

/// A user holding `usdc` and `sol` of the balanced vault's tokens.
pub async fn token_holder(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    usdc: u64,
    sol: u64,
) -> VaultDepositorAccounts {
    VaultDepositorAccounts::new_multi_token(
        ctx,
        vault_accounts,
        HashMap::from([("USDC".to_string(), usdc), ("SOL".to_string(), sol)]),
    )
    .await
}

/// What the order (of either kind) at `order` holds of `token`.
pub async fn locked_amount_of<O: Order + AccountDeserialize>(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    order: Pubkey,
    token: &str,
) -> u64 {
    let order: O = try_get(ctx, order).await.expect("the order exists");
    let mint = vault_accounts.vault_tokens[token].token_mint;
    let storage_index = vault_accounts
        .state(ctx)
        .await
        .vault_tokens
        .iter()
        .position(|slot| slot.mint == mint)
        .unwrap();
    order.base().locked_amounts[storage_index]
}

/// A fresh spl token priced on the vault's existing scope feed, added to the vault by the admin.
pub async fn add_priced_spl_token(
    ctx: &mut TestContext,
    vault_accounts: &mut VaultAccounts,
    name: &str,
    decimals: u8,
    price: f64,
) {
    let admin = ctx.initial_market_owner.clone();
    let mint = kp();
    token_operations::create_mint(ctx, &mint, decimals, &admin.pubkey(), &Token::id(), None).await;
    let usdc_mint = vault_accounts.vault_tokens["USDC"].token_mint;
    let scope_feed = vault_accounts.scope_prices[&usdc_mint].scope_feed;
    add_vault_token(ctx, &admin, vault_accounts, name, mint.pubkey(), scope_feed).await;
    setup::update_scope_px_and_twap(ctx, vault_accounts, name, price, price).await;
}

/// The vault's own amount of `token` (what the orders hold is not included).
pub async fn available_of(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token: &str,
) -> u64 {
    vault_token_slot(ctx, vault_accounts, token)
        .await
        .available()
        .into()
}

/// What all the orders together hold of `token`.
pub async fn locked_total(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token: &str,
) -> u64 {
    vault_token_slot(ctx, vault_accounts, token)
        .await
        .locked_total
}

/// Every token account holds at least the vault's own amount plus what the orders lock.
pub async fn assert_vault_covers_locked(ctx: &mut TestContext, vault_accounts: &VaultAccounts) {
    let state = vault_accounts.state(ctx).await;
    let balances = vault_accounts.balances(ctx).await;
    for (name, token) in &vault_accounts.vault_tokens {
        let slot = state
            .vault_tokens
            .iter()
            .find(|slot| slot.mint == token.token_mint)
            .unwrap();
        assert!(
            balances.token_vaults[name] >= u64::from(slot.available()) + slot.locked_total,
            "{name}: balance {} < available {} + locked {}",
            balances.token_vaults[name],
            u64::from(slot.available()),
            slot.locked_total
        );
    }
}

// ── Withdraw order client helpers ───────────────────────────────────

pub fn withdraw_order_pda(vault_accounts: &VaultAccounts, owner: &Pubkey, id: u8) -> Pubkey {
    pda::withdraw_order(&vault_accounts.vault_state.pubkey(), owner, id)
}

pub async fn withdraw_order_state(ctx: &mut TestContext, withdraw_order: Pubkey) -> WithdrawOrder {
    try_withdraw_order_state(ctx, withdraw_order)
        .await
        .expect("the withdraw order exists")
}

/// [None] once the order is closed (its account deleted).
pub async fn try_withdraw_order_state(
    ctx: &mut TestContext,
    withdraw_order: Pubkey,
) -> Option<WithdrawOrder> {
    try_get::<WithdrawOrder>(ctx, withdraw_order).await.ok()
}

/// Burns `shares` for a pro-rata basket auctioned into `weights` by token name (every enabled
/// token not named gets weight zero, i.e. is sold off).
pub async fn open_withdraw_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    id: u8,
    shares: u64,
    weights: &[(&str, u64)],
    duration_seconds: u64,
) -> Pubkey {
    try_open_withdraw_order(
        ctx,
        vault_accounts,
        holder,
        id,
        shares,
        weights,
        duration_seconds,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await
    .unwrap();
    withdraw_order_pda(vault_accounts, &holder.owner.pubkey(), id)
}

#[allow(clippy::too_many_arguments)]
pub async fn try_open_withdraw_order(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    id: u8,
    shares: u64,
    weights: &[(&str, u64)],
    duration_seconds: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<(), BanksClientError> {
    let dense_weights = dense_by_token_name(ctx, vault_accounts, weights).await;
    let no_minimums = vec![0; dense_weights.len()];
    try_open_withdraw_order_raw(
        ctx,
        vault_accounts,
        holder,
        id,
        shares,
        dense_weights,
        duration_seconds,
        no_minimums,
        max_fill_slippage_bps,
        max_loss_bps,
    )
    .await
}

/// Opens with the least of each token the order must receive (by token name, others unlimited).
#[allow(clippy::too_many_arguments)]
pub async fn try_open_withdraw_order_with_min_tokens_out(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    id: u8,
    shares: u64,
    weights: &[(&str, u64)],
    duration_seconds: u64,
    min_tokens_out: &[(&str, u64)],
) -> Result<(), BanksClientError> {
    let dense_weights = dense_by_token_name(ctx, vault_accounts, weights).await;
    let min_tokens_out = dense_by_token_name(ctx, vault_accounts, min_tokens_out).await;
    try_open_withdraw_order_raw(
        ctx,
        vault_accounts,
        holder,
        id,
        shares,
        dense_weights,
        duration_seconds,
        min_tokens_out,
        u64::from(FULL_BPS),
        u64::from(FULL_BPS),
    )
    .await
}

/// Opens with the `weights` exactly as given (one per enabled token, dense order), for tests of
/// the argument validation.
#[allow(clippy::too_many_arguments)]
pub async fn try_open_withdraw_order_raw(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    holder: &VaultDepositorAccounts,
    id: u8,
    shares: u64,
    weights: Vec<u64>,
    duration_seconds: u64,
    min_tokens_out: Vec<u64>,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<(), BanksClientError> {
    let withdraw_order = withdraw_order_pda(vault_accounts, &holder.owner.pubkey(), id);
    let aum_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::open_withdraw_order(
        ctx,
        vault_accounts,
        holder,
        withdraw_order,
        id,
        shares,
        weights,
        duration_seconds,
        min_tokens_out,
        max_fill_slippage_bps,
        max_loss_bps,
        aum_accounts,
    )
    .await;
    send_transaction!(ctx, tx)
}

/// The withdraw order's rebalance targets at the current on-chain prices, by token name.
pub async fn withdraw_order_rebalance_target(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    token_name: &str,
) -> u64 {
    let mut order = withdraw_order_state(ctx, withdraw_order).await;
    rebalance_target_of(ctx, vault_accounts, &mut order, token_name).await
}

#[allow(clippy::too_many_arguments)]
pub async fn fill_withdraw_order(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
) {
    try_fill_withdraw_order(
        ctx,
        user,
        vault_accounts,
        withdraw_order,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
    )
    .await
    .unwrap();
}

#[allow(clippy::too_many_arguments)]
pub async fn try_fill_withdraw_order(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
) -> Result<(), BanksClientError> {
    try_fill_withdraw_order_with_krfq_marker(
        ctx,
        user,
        vault_accounts,
        withdraw_order,
        token_in_name,
        token_out_name,
        amount_in,
        requested_out,
        None,
        pda::global_config(),
        KrfqMarker::Derived,
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub async fn try_fill_withdraw_order_with_krfq_marker(
    ctx: &mut TestContext,
    user: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
    requested_out: RequestedOut,
    krfq_authority: Option<&KP>,
    global_config: Pubkey,
    marker: KrfqMarker,
) -> Result<(), BanksClientError> {
    let requested_out_amount = match requested_out {
        RequestedOut::Exact(amount) => amount,
        RequestedOut::AtCurve => withdraw_order_curve_quote(
            ctx,
            vault_accounts,
            withdraw_order,
            token_in_name,
            token_out_name,
            amount_in,
        )
        .await
        .unwrap_or(0),
    };
    try_fill_with_krfq_marker(
        ctx,
        user,
        vault_accounts,
        FillTarget::WithdrawOrder(withdraw_order),
        token_in_name,
        token_out_name,
        amount_in,
        requested_out_amount,
        krfq_authority,
        global_config,
        marker,
    )
    .await
}

pub async fn settle_withdraw_order(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
) {
    try_settle_withdraw_order(ctx, signer, vault_accounts, withdraw_order)
        .await
        .unwrap();
}

/// Payouts go to the order owner's associated token accounts, which the depositor fixtures
/// create; the scope prices go along exactly when the program reads them.
pub async fn try_settle_withdraw_order(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
) -> Result<(), BanksClientError> {
    let order = withdraw_order_state(ctx, withdraw_order).await;
    let per_token = order_payout_accounts(ctx, vault_accounts, &order).await;
    let scope_accounts = if signer.pubkey() == order.base.owner {
        vec![] // (only the owner settles without the prices)
    } else {
        get_ordered_scope_accounts(ctx, vault_accounts).await
    };
    try_settle_withdraw_order_raw(
        ctx,
        signer,
        vault_accounts,
        withdraw_order,
        order.base.owner,
        scope_accounts,
        &per_token,
    )
    .await
}

/// Settles with the `owner`, the scope prices and the payout accounts exactly as given, for tests
/// of the account layout.
pub async fn try_settle_withdraw_order_raw(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    owner: Pubkey,
    scope_accounts: Vec<Pubkey>,
    per_token: &[OrderTokenAccounts],
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::settle_withdraw_order(
        ctx,
        signer,
        vault_accounts,
        withdraw_order,
        owner,
        scope_accounts,
        per_token,
    )
    .await;
    send_transaction!(ctx, tx)
}

// ── Obligation admin client helpers ─────────────────────────────────

pub async fn try_init_obligation(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation_id: u8,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::init_obligation(
        ctx,
        authority,
        vault_accounts,
        market,
        obligation_id,
    )
    .await;
    send_transaction!(ctx, tx)
}

pub async fn init_obligation(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation_id: u8,
) {
    try_init_obligation(ctx, authority, vault_accounts, market, obligation_id)
        .await
        .unwrap();
}

#[allow(clippy::too_many_arguments)]
pub async fn try_deposit_obligation_collateral<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    amount: u64,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::deposit_obligation_collateral(
        ctx,
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        amount,
        scope_and_obligation_accounts,
        obligation_deposit_reserves,
        obligation_borrow_reserves,
    )
    .await;
    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
pub async fn try_withdraw_obligation_collateral<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    collateral_amount: u64,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::withdraw_obligation_collateral(
        ctx,
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        collateral_amount,
        scope_and_obligation_accounts,
        obligation_deposit_reserves,
        obligation_borrow_reserves,
    )
    .await;
    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
pub async fn try_borrow_obligation_liquidity<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::borrow_obligation_liquidity(
        ctx,
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        liquidity_amount,
        scope_and_obligation_accounts,
        obligation_deposit_reserves,
        obligation_borrow_reserves,
    )
    .await;
    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
pub async fn try_repay_obligation_liquidity<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    token_name: &str,
    liquidity_amount: u64,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Result<(), BanksClientError> {
    let scope_and_obligation_accounts =
        get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::repay_obligation_liquidity(
        ctx,
        authority,
        vault_accounts,
        market,
        reserve,
        obligation,
        token_name,
        liquidity_amount,
        scope_and_obligation_accounts,
        obligation_deposit_reserves,
        obligation_borrow_reserves,
    )
    .await;
    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
pub async fn try_request_elevation_group<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation: Pubkey,
    new_elevation_group: u8,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::instructions::request_elevation_group(
        ctx,
        authority,
        vault_accounts,
        market,
        obligation,
        new_elevation_group,
        obligation_deposit_reserves,
        obligation_borrow_reserves,
    )
    .await;
    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
pub async fn request_elevation_group<'a>(
    ctx: &mut TestContext,
    authority: &KP,
    vault_accounts: &VaultAccounts,
    market: &LendingMarketAccounts,
    obligation: Pubkey,
    new_elevation_group: u8,
    obligation_deposit_reserves: Vec<&'a ReserveAccounts>,
    obligation_borrow_reserves: Vec<&'a ReserveAccounts>,
) {
    try_request_elevation_group(
        ctx,
        authority,
        vault_accounts,
        market,
        obligation,
        new_elevation_group,
        obligation_deposit_reserves,
        obligation_borrow_reserves,
    )
    .await
    .unwrap();
}

/// The curve quote for a fill against `order` at the current clock, or the error the program would
/// raise for the request.
async fn curve_quote_of<O: Order>(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    order: &mut O,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
) -> anchor_lang::Result<u64> {
    let mut vault_state = vault_accounts.state(ctx).await;
    let (prices, timestamp) = load_scope_prices(ctx, vault_accounts, &vault_state).await?;
    let basket = OrderBasket {
        order,
        vault: &mut vault_state,
    };
    let quote = rebalance_operations::quote_rebalance_swap(
        &basket.tokens(),
        &basket.order.base().rebalance,
        &prices,
        &vault_accounts.vault_tokens[token_in_name].token_mint,
        &vault_accounts.vault_tokens[token_out_name].token_mint,
        TokenAmount::from(amount_in),
        timestamp,
    )?;
    Ok(quote.max_out_from_curve.into())
}

/// `order`'s rebalance target at the current on-chain prices, by token name.
async fn rebalance_target_of<O: Order>(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    order: &mut O,
    token_name: &str,
) -> u64 {
    let mut vault_state = vault_accounts.state(ctx).await;
    let (prices, _) = load_scope_prices(ctx, vault_accounts, &vault_state)
        .await
        .expect("scope prices");
    let id = vault_state
        .get_vault_token_id_by_mint(&vault_accounts.vault_tokens[token_name].token_mint)
        .unwrap();
    let basket = OrderBasket {
        order,
        vault: &mut vault_state,
    };
    basket.tokens().targets(&prices).of(id).into()
}

/// The values by token name in dense enabled-token order (zero for every token not named).
pub async fn dense_by_token_name(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    by_name: &[(&str, u64)],
) -> Vec<u64> {
    let vault_state = vault_accounts.state(ctx).await;
    vault_state
        .iter_enabled_tokens()
        .map(|token| {
            by_name
                .iter()
                .find(|(name, _)| vault_accounts.vault_tokens[*name].token_mint == token.mint)
                .map_or(0, |(_, value)| *value)
        })
        .collect()
}

pub async fn order_payout_accounts<O: Order>(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    order: &O,
) -> Vec<OrderTokenAccounts> {
    let vault_state = vault_accounts.state(ctx).await;
    order
        .base()
        .locked_amounts
        .iter()
        .enumerate()
        .filter(|(_, locked)| **locked != 0)
        .map(|(storage_index, _)| {
            let mint = vault_state.vault_tokens[storage_index].mint;
            let token = vault_accounts
                .vault_tokens
                .values()
                .find(|vault_token| vault_token.token_mint == mint)
                .expect("the order's token is a vault token")
                .clone();
            let owner_ata = get_associated_token_address_with_program_id(
                &order.base().owner,
                &mint,
                &token.token_program,
            );
            OrderTokenAccounts { token, owner_ata }
        })
        .collect()
}

/// [curve_quote_of] the deposit order at `deposit_order`.
async fn order_curve_quote(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
) -> anchor_lang::Result<u64> {
    let mut order = deposit_order_state(ctx, deposit_order).await;
    curve_quote_of(
        ctx,
        vault_accounts,
        &mut order,
        token_in_name,
        token_out_name,
        amount_in,
    )
    .await
}

/// [curve_quote_of] the withdraw order at `withdraw_order`.
async fn withdraw_order_curve_quote(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    withdraw_order: Pubkey,
    token_in_name: &str,
    token_out_name: &str,
    amount_in: u64,
) -> anchor_lang::Result<u64> {
    let mut order = withdraw_order_state(ctx, withdraw_order).await;
    curve_quote_of(
        ctx,
        vault_accounts,
        &mut order,
        token_in_name,
        token_out_name,
        amount_in,
    )
    .await
}

async fn vault_token_slot(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    token: &str,
) -> VaultTokenState {
    let mint = vault_accounts.vault_tokens[token].token_mint;
    *vault_accounts
        .state(ctx)
        .await
        .vault_tokens
        .iter()
        .find(|slot| slot.mint == mint)
        .unwrap()
}

/// `amounts` by token name, spread into one dense entry per enabled token plus the accounts of
/// each non-zero one.
pub async fn order_token_accounts_and_amounts(
    ctx: &mut TestContext,
    vault_accounts: &VaultAccounts,
    depositor: &VaultDepositorAccounts,
    amounts: &[(&str, u64)],
) -> (Vec<u64>, Vec<OrderTokenAccounts>) {
    let vault_state = vault_accounts.state(ctx).await;
    let mut dense_amounts = vec![0u64; vault_state.enumerate_enabled_tokens().count()];
    let mut per_token = Vec::new();
    for (token_id, token) in vault_state.enumerate_enabled_tokens() {
        let Some((name, amount)) = amounts
            .iter()
            .find(|(name, _)| vault_accounts.vault_tokens[*name].token_mint == token.mint)
        else {
            continue;
        };
        dense_amounts[token_id.input_account_index] = *amount;
        if *amount > 0 {
            per_token.push(OrderTokenAccounts {
                token: vault_accounts.vault_tokens[*name].clone(),
                owner_ata: depositor.token_atas[*name],
            });
        }
    }
    (dense_amounts, per_token)
}

async fn try_settle_deposit_order_into_raw(
    ctx: &mut TestContext,
    signer: &KP,
    vault_accounts: &VaultAccounts,
    deposit_order: Pubkey,
    owner: Pubkey,
    owner_shares_account: Pubkey,
    per_token: &[OrderTokenAccounts],
) -> Result<(), BanksClientError> {
    let aum_accounts = get_ordered_scope_and_obligation_accounts(ctx, vault_accounts).await;
    let tx = crate::program_test::instructions::settle_deposit_order(
        ctx,
        signer,
        vault_accounts,
        deposit_order,
        owner,
        owner_shares_account,
        aum_accounts,
        per_token,
    )
    .await;
    send_transaction!(ctx, tx)
}

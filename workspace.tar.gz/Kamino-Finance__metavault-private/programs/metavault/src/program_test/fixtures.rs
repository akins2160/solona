use std::collections::HashMap;

use kamino_lending::{
    program_test::common::{
        fixtures::{setup_markets_and_reserves_with_deps, test_reserve_config},
        math::usdc_decimal_to_u64,
        runner::{state, test::ProgramDep},
        setup::{new_borrower_accounts_with_initial_deposit, serialize_zero_copy, KP},
        types::{KaminoMarket, KaminoMarkets, MSpec, MarketsSpec, MintSpec, RSpec, TestContext},
    },
    utils::borrow_rate_curve::BorrowRateCurve,
    Reserve, ReserveConfig,
};
use solana_program::pubkey::Pubkey;
use solana_program_test::{anchor_processor, processor, ProgramTest};
use solana_sdk::{account::AccountSharedData, signer::Signer};
use usdc_decimal_to_u64 as usdc;

use super::{ScopePrice, VaultInvestorAccounts};
use crate::{
    program_test::{
        client::{self, UpdateVaultConfigParams},
        setup,
        types::{KaminoVault, VaultSpec},
        VaultAccounts, VaultDepositorAccounts,
    },
    utils::{consts::INITIAL_DEPOSIT_SIZE, pda},
    GlobalConfig,
};

use kamino_lending::program_test::common::fixtures::setup_markets as setup_klend_markets;

pub enum ProgramDependency {
    TestCpiCaller,
    TokenAcl,
    GateAlwaysAllow,
    GateAlwaysBlock,
    GateAlwaysAllowWithDeps,
}

/// Maps dependency variants to `ProgramDep` entries; a `None` processor loads
/// `tests/fixtures/<name>.so` as a BPF fixture.
pub fn to_program_deps(program_dependencies: Vec<ProgramDependency>) -> Vec<ProgramDep> {
    let mut deps: Vec<ProgramDep> = Vec::with_capacity(program_dependencies.len());
    for dep in program_dependencies {
        match dep {
            ProgramDependency::TestCpiCaller => {
                deps.push((
                    "test_cpi_caller",
                    super::test_cpi_caller::TEST_CPI_CALLER_ID,
                    processor!(super::test_cpi_caller::process_instruction),
                ));
            }
            ProgramDependency::TokenAcl => {
                deps.push(("token_acl", super::token_acl::TOKEN_ACL_ID, None));
            }
            ProgramDependency::GateAlwaysAllow => {
                deps.push(("always_allow", super::token_acl::ALWAYS_ALLOW_GATE_ID, None));
            }
            ProgramDependency::GateAlwaysBlock => {
                deps.push(("always_block", super::token_acl::ALWAYS_BLOCK_GATE_ID, None));
            }
            ProgramDependency::GateAlwaysAllowWithDeps => {
                deps.push((
                    "always_allow_with_deps",
                    super::token_acl::ALWAYS_ALLOW_WITH_DEPS_GATE_ID,
                    None,
                ));
            }
        }
    }
    deps
}

fn add_program_dependencies(
    program_deps: &mut Vec<ProgramDep>,
    program_dependencies: Option<Vec<ProgramDependency>>,
) {
    if let Some(deps) = program_dependencies {
        program_deps.extend(to_program_deps(deps));
    }
}

pub async fn setup_markets_with_dependencies(
    spec: &MarketsSpec,
    program_dependencies: Option<Vec<ProgramDependency>>,
) -> (TestContext, KaminoMarkets, VaultAccounts) {
    let mut program_deps: Vec<ProgramDep> =
        vec![("metavault", crate::ID, anchor_processor!(crate::entry))];
    add_program_dependencies(&mut program_deps, program_dependencies);

    let (mut ctx, markets) = setup_klend_markets(None, spec, None, Some(program_deps)).await;
    let first_token_name = if spec.mints.keys().any(|k| k == &"USDC".to_string()) {
        "USDC".to_string()
    } else {
        let name = spec.mints.keys().next().unwrap();
        name.clone()
    };
    let mint = markets.mints.get(&first_token_name).unwrap();

    // Mirror klend's reserve scope_configuration onto the matching metavault vault_token. The new
    // per-handler scope-config equality constraint demands these line up; klend's test fixtures
    // assign per-mint chain slots that the default 0/1 auto-assignment in `VaultAccounts::new`
    // does not match.
    let first_reserve_pk = markets.markets[0].reserves[&first_token_name]
        .address
        .pubkey();
    let first_reserve = state::get::<Reserve>(&mut ctx, first_reserve_pk).await;
    let first_scope_config = first_reserve.config.token_info.scope_configuration;

    let mut vault = VaultAccounts::from_mint(
        mint,
        &first_token_name,
        markets.markets[0].oracles.scope_prices_info,
    );
    vault.scope_prices.insert(
        mint.mint,
        ScopePrice {
            scope_feed: first_scope_config.price_feed,
            price_index: first_scope_config.price_chain[0] as usize,
            twap_index: first_scope_config.twap_chain[0] as usize,
        },
    );
    let global_admin = ctx.initial_market_owner.clone();
    set_global_config(
        &mut ctx,
        &GlobalConfig {
            global_admin: global_admin.pubkey(),
            ..Default::default()
        },
    );
    client::init_vault(&mut ctx, &vault).await.unwrap();

    // Sort mints by name to ensure deterministic setup order
    let mut sorted_mints: Vec<_> = spec.mints.iter().collect();
    sorted_mints.sort_by_key(|(name, _)| *name);

    for (name, spec) in sorted_mints {
        if name != &first_token_name {
            let reserve_pk = markets.markets[0].reserves[name].address.pubkey();
            let reserve = state::get::<Reserve>(&mut ctx, reserve_pk).await;
            let scope_config = reserve.config.token_info.scope_configuration;
            client::add_vault_token_with_scope_config(
                &mut ctx,
                &global_admin,
                &mut vault,
                name,
                markets.mints[name].mint,
                scope_config,
            )
            .await;
        }
        setup::update_scope_px_and_twap(&mut ctx, &vault, name, spec.price, spec.price).await;
    }
    set_global_config(&mut ctx, &GlobalConfig::default());

    client::give_every_token_an_equal_weight(&mut ctx, &vault).await;

    (ctx, markets, vault)
}

pub async fn setup_markets(spec: &MarketsSpec) -> (TestContext, KaminoMarkets, VaultAccounts) {
    setup_markets_with_dependencies(spec, None).await
}

pub async fn setup_markets_with_weights_and_dependencies(
    spec: &MarketsSpec,
    weights: Vec<u64>,
    program_dependencies: Option<Vec<ProgramDependency>>,
) -> (TestContext, KaminoMarkets, VaultAccounts) {
    let (mut ctx, markets, vault) =
        setup_markets_with_dependencies(spec, program_dependencies).await;
    let admin = ctx.initial_market_owner.clone();

    client::update_vault_config(
        &mut ctx,
        &admin,
        &vault,
        UpdateVaultConfigParams::VaultTokenWeights(weights),
    )
    .await;

    (ctx, markets, vault)
}

pub async fn setup_markets_with_weights(
    spec: &MarketsSpec,
    weights: Vec<u64>,
) -> (TestContext, KaminoMarkets, VaultAccounts) {
    setup_markets_with_weights_and_dependencies(spec, weights, None).await
}

/// A $2000 vault holding 1000 USDC and 10 SOL at equal weights, each token allowed 10% past its
/// weight, with the given `switches` on. The LP holds all its shares.
pub async fn setup_balanced_vault(
    switches: Vec<UpdateVaultConfigParams>,
) -> (TestContext, VaultAccounts, VaultDepositorAccounts) {
    const USDC: u64 = 1_000_000;
    const SOL: u64 = 1_000_000_000;
    let (mut ctx, _markets, vault) = setup_markets_with_weights(
        &MarketsSpec {
            mints: HashMap::from([
                ("USDC".to_string(), MintSpec::spl(6, 1.0)),
                ("SOL".to_string(), MintSpec::spl(9, 100.0)),
            ]),
            markets: vec![MSpec::new(vec![
                RSpec::new("USDC", 0),
                RSpec::new("SOL", 0),
            ])],
        },
        vec![5, 5],
    )
    .await;
    let admin = ctx.initial_market_owner.clone();
    let lp = VaultDepositorAccounts::new_multi_token(
        &mut ctx,
        &vault,
        HashMap::from([
            ("USDC".to_string(), 2000 * USDC),
            ("SOL".to_string(), 30 * SOL),
        ]),
    )
    .await;
    client::deposit(
        &mut ctx,
        &vault,
        &lp,
        "USDC",
        1000 * USDC - INITIAL_DEPOSIT_SIZE,
    )
    .await;
    client::deposit(&mut ctx, &vault, &lp, "SOL", 10 * SOL).await;
    for token in ["USDC", "SOL"] {
        client::update_vault_config(
            &mut ctx,
            &admin,
            &vault,
            UpdateVaultConfigParams::VaultTokenMaxDeviationBps(
                vault.vault_tokens[token].token_mint,
                1000,
            ),
        )
        .await;
    }
    for switch in switches {
        client::update_vault_config(&mut ctx, &admin, &vault, switch).await;
    }
    (ctx, vault, lp)
}

pub async fn setup_markets_with_vault(spec: &VaultSpec) -> (TestContext, KaminoVault) {
    let (ctx, markets, vault) = setup_markets(&spec.markets).await;

    (ctx, KaminoVault::new(&spec.token, vault, markets.markets))
}

pub async fn setup_markets_and_reserves_with_dependencies(
    num_markets: usize,
    program_dependencies: Option<Vec<ProgramDependency>>,
    global_config: Option<GlobalConfig>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_cfg(
        num_markets,
        None,
        true,
        program_dependencies,
        global_config,
    )
    .await
}

pub fn program() -> ProgramTest {
    ProgramTest::new("metavault", crate::ID, anchor_processor!(crate::entry))
}

pub fn set_global_config_with_address(
    ctx: &mut TestContext,
    address: &Pubkey,
    global_config: &GlobalConfig,
) {
    let mut account = AccountSharedData::new(u32::MAX as u64, 0, &crate::ID);
    account.set_data(serialize_zero_copy(global_config));
    ctx.set_account(address, account);
}

pub fn set_global_config(ctx: &mut TestContext, global_config: &GlobalConfig) {
    set_global_config_with_address(ctx, &pda::global_config(), global_config);
}

pub async fn setup_markets_and_reserves(
    num_markets: usize,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_cfg(num_markets, None, true, None, None).await
}

pub async fn setup_markets_and_reserves_with_global_config(
    num_markets: usize,
    global_config: Option<GlobalConfig>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_cfg(num_markets, None, true, None, global_config).await
}

pub async fn setup_markets_and_reserves_with_cfg(
    num_markets: usize,
    reserve_cfg: Option<ReserveConfig>,
    token_is_usdc: bool,
    program_dependencies: Option<Vec<ProgramDependency>>,
    global_config: Option<GlobalConfig>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_cfg_inner(
        num_markets,
        reserve_cfg,
        token_is_usdc,
        program_dependencies,
        global_config,
        None,
    )
    .await
}

async fn setup_markets_and_reserves_with_cfg_inner(
    num_markets: usize,
    reserve_cfg: Option<ReserveConfig>,
    token_is_usdc: bool,
    program_dependencies: Option<Vec<ProgramDependency>>,
    global_config: Option<GlobalConfig>,
    gating_program: Option<Pubkey>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    let mut program_deps: Vec<ProgramDep> = vec![
        ("metavault", crate::ID, anchor_processor!(crate::entry)),
        (
            "kamino_lending",
            kamino_lending::ID,
            anchor_processor!(kamino_lending::entry),
        ),
    ];

    add_program_dependencies(&mut program_deps, program_dependencies);

    let (mut ctx, owner, markets) =
        setup_markets_and_reserves_with_deps(program_deps.to_vec(), num_markets, reserve_cfg).await;
    if let Some(mut global_config) = global_config {
        global_config.global_admin = owner.pubkey();
        set_global_config(&mut ctx, &global_config);
    } else {
        set_global_config(
            &mut ctx,
            &GlobalConfig {
                global_admin: owner.pubkey(),
                ..Default::default()
            },
        );
    }
    let mint = if token_is_usdc {
        markets[0].usdc_reserve.liquidity_mint.pubkey()
    } else {
        markets[0].sol_reserve.liquidity_mint.pubkey()
    };
    let token_program = if token_is_usdc {
        markets[0].usdc_reserve.liquidity_mint_token_program
    } else {
        markets[0].sol_reserve.liquidity_mint_token_program
    };
    let token_name = if token_is_usdc { "USDC" } else { "SOL" };
    let token_price = if token_is_usdc { 1.0 } else { 100.0 };
    let mut vault = VaultAccounts::new(
        &mint,
        token_name,
        &token_program,
        markets[0].oracles.scope_prices,
    );
    vault.gating_program = gating_program;
    let investor = VaultInvestorAccounts::new(&mut ctx, mint, usdc(1000.0)).await;

    client::init_vault(&mut ctx, &vault).await.unwrap();
    setup::update_scope_px_and_twap(&mut ctx, &vault, token_name, token_price, token_price).await;
    client::give_every_token_an_equal_weight(&mut ctx, &vault).await;
    (ctx, vault, owner, investor, markets)
}

/// A permissioned USDC vault gated through the given gate program; loads the token-acl
/// fixture plus the requested gate fixtures.
pub async fn setup_markets_and_reserves_permissioned(
    gating_program: Pubkey,
    gate_dependencies: Vec<ProgramDependency>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    let mut deps = vec![ProgramDependency::TokenAcl];
    deps.extend(gate_dependencies);
    setup_markets_and_reserves_with_cfg_inner(1, None, true, Some(deps), None, Some(gating_program))
        .await
}

pub async fn setup_markets_and_reserves_with_yield(
    num_markets: usize,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_custom_yield(num_markets, 1000).await
}

/// Setup markets and reserves with yield on cTokens
/// Cfg with a flat borrow rate of 10%
/// Add some initial liquidity to the USDC reserves (10 000 USDC each)
/// Add some initial borrows to the USDC reserves (1 000 USDC each)
pub async fn setup_markets_and_reserves_with_yield_and_global_config(
    num_markets: usize,
    global_config: Option<GlobalConfig>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_custom_yield_and_global_config(num_markets, 1000, global_config)
        .await
}

pub async fn setup_markets_and_reserves_with_custom_yield(
    num_markets: usize,
    yearly_yield: u32,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    setup_markets_and_reserves_with_custom_yield_and_global_config(num_markets, yearly_yield, None)
        .await
}

/// Setup markets and reserves with yield on cTokens
/// Cfg with a flat borrow rate passed as param
/// Add some initial liquidity to the USDC reserves (10 000 USDC each)
/// Add some initial borrows to the USDC reserves (1 000 USDC each)
pub async fn setup_markets_and_reserves_with_custom_yield_and_global_config(
    num_markets: usize,
    yearly_yield: u32,
    global_config: Option<GlobalConfig>,
) -> (
    TestContext,
    VaultAccounts,
    KP,
    VaultInvestorAccounts,
    Vec<KaminoMarket>,
) {
    // Flat borrow rate
    let borrow_rate_curve = BorrowRateCurve::new_flat(yearly_yield);
    let reserve_cfg = ReserveConfig {
        borrow_rate_curve,
        ..test_reserve_config()
    };
    let (mut ctx, vault, owner, investor, markets) = setup_markets_and_reserves_with_cfg(
        num_markets,
        Some(reserve_cfg),
        true,
        None,
        global_config,
    )
    .await;

    // Deposit some liquidity
    for market in markets.iter() {
        let reserve = &market.usdc_reserve;
        let liquidity = usdc(10_000.0);
        let borrow = usdc(1_000.0);
        let borrower = new_borrower_accounts_with_initial_deposit(
            &mut ctx,
            &market.primary_market,
            reserve,
            reserve,
            &Pubkey::default(),
            liquidity,
        )
        .await;
        ctx.borrow_obligation_liquidity(
            &market.primary_market,
            reserve,
            &borrower.depositor_accounts,
            &borrower.obligation,
            borrow,
        )
        .await
        .unwrap();
    }

    (ctx, vault, owner, investor, markets)
}

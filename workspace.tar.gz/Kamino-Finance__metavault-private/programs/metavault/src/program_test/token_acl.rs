//! Test-side harness for the Token ACL program (sRFC-37) and its example gate programs.
//!
//! All instruction encodings and account orders are hand-rolled and pinned against
//! token-acl commit `9b24211` (`../token-acl`): the upstream `token-acl-client` and
//! `spl-tlv-account-resolution` crates target borsh 1.0 / solana 3.x and cannot link
//! against this workspace's solana 1.17 / borsh 0.10 stack.

use anchor_spl::token_2022::spl_token_2022;
use kamino_lending::program_test::common::{
    runner::test,
    setup::{funded_kp, KP},
    types::TestContext,
};
use solana_program::{
    hash,
    instruction::{AccountMeta, Instruction},
    native_token::LAMPORTS_PER_SOL,
    pubkey,
    pubkey::Pubkey,
    system_instruction, system_program,
};
use solana_sdk::{signature::Keypair, signer::Signer};
use spl_token_2022::{
    extension::ExtensionType,
    state::{AccountState, Mint},
};

use crate::program_test::fixtures::{self, ProgramDependency};

pub const TOKEN_ACL_ID: Pubkey = pubkey!("TACLkU6CiCdkQN2MjoyDkVg2yAH9zkxiHDsiztQ52TP");
pub const ALWAYS_ALLOW_GATE_ID: Pubkey = pubkey!("Eba1ts11111111111111111111111111111111111112");
pub const ALWAYS_BLOCK_GATE_ID: Pubkey = pubkey!("Eba1ts11111111111111111111111111111111111113");
pub const ALWAYS_ALLOW_WITH_DEPS_GATE_ID: Pubkey =
    pubkey!("Eba1ts11111111111111111111111111111111111114");

pub const MINT_CONFIG_SEED: &[u8] = b"MINT_CONFIG";
pub const FLAG_ACCOUNT_SEED: &[u8] = b"FLAG_ACCOUNT";
pub const THAW_EXTRA_ACCOUNT_METAS_SEED: &[u8] = b"thaw_extra_account_metas";

/// Custom error codes (token-acl `program/src/error.rs` enum order; the gate code is the
/// example gates' explicit discriminant).
pub mod error_code {
    pub const INVALID_AUTHORITY: u32 = 0;
    pub const INVALID_SYSTEM_PROGRAM: u32 = 1;
    pub const INVALID_TOKEN_PROGRAM: u32 = 2;
    pub const INVALID_TOKEN_MINT: u32 = 3;
    pub const INVALID_MINT_CONFIG: u32 = 4;
    pub const INVALID_GATING_PROGRAM: u32 = 5;
    pub const PERMISSIONLESS_THAW_NOT_ENABLED: u32 = 6;
    pub const PERMISSIONLESS_FREEZE_NOT_ENABLED: u32 = 7;
    pub const INVALID_TOKEN_ACCOUNT_OWNER: u32 = 8;
    pub const INVALID_FLAG_ACCOUNT: u32 = 9;
    pub const GATE_UNSUPPORTED_INSTRUCTION: u32 = 999_999_999;
}

/// 1-byte instruction discriminators (token-acl `program/src/instructions/*.rs`).
pub mod ix_disc {
    pub const CREATE_CONFIG: u8 = 0;
    pub const SET_AUTHORITY: u8 = 1;
    pub const SET_GATING_PROGRAM: u8 = 2;
    pub const DELETE_CONFIG: u8 = 3;
    pub const THAW: u8 = 4;
    pub const FREEZE: u8 = 5;
    pub const THAW_PERMISSIONLESS: u8 = 6;
    pub const FREEZE_PERMISSIONLESS: u8 = 7;
    pub const TOGGLE_PERMISSIONLESS: u8 = 8;
    pub const THAW_PERMISSIONLESS_IDEMPOTENT: u8 = 9;
    pub const FREEZE_PERMISSIONLESS_IDEMPOTENT: u8 = 10;
}

pub fn mint_config_pda(mint: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&[MINT_CONFIG_SEED, mint.as_ref()], &TOKEN_ACL_ID)
}

pub fn flag_account_pda(token_account: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&[FLAG_ACCOUNT_SEED, token_account.as_ref()], &TOKEN_ACL_ID)
}

/// The extra-account-metas PDA lives on the *gate* program, not on token-acl.
pub fn thaw_extra_account_metas_pda(mint: &Pubkey, gate: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&[THAW_EXTRA_ACCOUNT_METAS_SEED, mint.as_ref()], gate)
}

/// Parsed `MintConfig` account (100 bytes, discriminator 1).
///
/// The on-chain field holding the config admin is named `freeze_authority` — it is NOT
/// the token freeze authority (that is the MintConfig PDA itself once configured).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MintConfig {
    pub bump: u8,
    pub permissionless_thaw_enabled: bool,
    pub permissionless_freeze_enabled: bool,
    pub mint: Pubkey,
    pub config_admin: Pubkey,
    pub gating_program: Pubkey,
}

impl MintConfig {
    pub const LEN: usize = 100;
    pub const DISCRIMINATOR: u8 = 1;

    pub fn unpack(data: &[u8]) -> Option<Self> {
        if data.len() != Self::LEN || data[0] != Self::DISCRIMINATOR {
            return None;
        }
        Some(Self {
            bump: data[1],
            permissionless_thaw_enabled: data[2] != 0,
            permissionless_freeze_enabled: data[3] != 0,
            mint: Pubkey::try_from(&data[4..36]).unwrap(),
            config_admin: Pubkey::try_from(&data[36..68]).unwrap(),
            gating_program: Pubkey::try_from(&data[68..100]).unwrap(),
        })
    }
}

pub fn create_config_ix(
    payer: &Pubkey,
    authority: &Pubkey,
    mint: &Pubkey,
    gating_program: &Pubkey,
) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    let mut data = vec![ix_disc::CREATE_CONFIG];
    data.extend_from_slice(gating_program.as_ref());
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts: vec![
            AccountMeta::new(*payer, true),
            AccountMeta::new_readonly(*authority, true),
            AccountMeta::new(*mint, false),
            AccountMeta::new(mint_config, false),
            AccountMeta::new_readonly(system_program::ID, false),
            AccountMeta::new_readonly(spl_token_2022::ID, false),
        ],
        data,
    }
}

pub fn set_authority_ix(authority: &Pubkey, mint: &Pubkey, new_authority: &Pubkey) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    let mut data = vec![ix_disc::SET_AUTHORITY];
    data.extend_from_slice(new_authority.as_ref());
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts: vec![
            AccountMeta::new_readonly(*authority, true),
            AccountMeta::new(mint_config, false),
        ],
        data,
    }
}

pub fn set_gating_program_ix(
    authority: &Pubkey,
    mint: &Pubkey,
    new_gating_program: &Pubkey,
) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    let mut data = vec![ix_disc::SET_GATING_PROGRAM];
    data.extend_from_slice(new_gating_program.as_ref());
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts: vec![
            AccountMeta::new_readonly(*authority, true),
            AccountMeta::new(mint_config, false),
        ],
        data,
    }
}

/// `receiver` (rent destination) sits between `authority` and `mint` — pinned by
/// `test_delete_config`.
pub fn delete_config_ix(
    authority: &Pubkey,
    receiver: &Pubkey,
    mint: &Pubkey,
    new_freeze_authority: &Pubkey,
) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    let mut data = vec![ix_disc::DELETE_CONFIG];
    data.extend_from_slice(new_freeze_authority.as_ref());
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts: vec![
            AccountMeta::new_readonly(*authority, true),
            AccountMeta::new(*receiver, false),
            AccountMeta::new(*mint, false),
            AccountMeta::new(mint_config, false),
            AccountMeta::new_readonly(spl_token_2022::ID, false),
        ],
        data,
    }
}

fn thaw_or_freeze_ix(
    discriminator: u8,
    authority: &Pubkey,
    mint: &Pubkey,
    token_account: &Pubkey,
) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts: vec![
            AccountMeta::new_readonly(*authority, true),
            AccountMeta::new_readonly(*mint, false),
            AccountMeta::new(*token_account, false),
            AccountMeta::new_readonly(mint_config, false),
            AccountMeta::new_readonly(spl_token_2022::ID, false),
        ],
        data: vec![discriminator],
    }
}

pub fn thaw_ix(authority: &Pubkey, mint: &Pubkey, token_account: &Pubkey) -> Instruction {
    thaw_or_freeze_ix(ix_disc::THAW, authority, mint, token_account)
}

pub fn freeze_ix(authority: &Pubkey, mint: &Pubkey, token_account: &Pubkey) -> Instruction {
    thaw_or_freeze_ix(ix_disc::FREEZE, authority, mint, token_account)
}

pub fn toggle_permissionless_ix(
    authority: &Pubkey,
    mint: &Pubkey,
    freeze_enabled: bool,
    thaw_enabled: bool,
) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts: vec![
            AccountMeta::new_readonly(*authority, true),
            AccountMeta::new(mint_config, false),
        ],
        data: vec![
            ix_disc::TOGGLE_PERMISSIONLESS,
            u8::from(freeze_enabled),
            u8::from(thaw_enabled),
        ],
    }
}

/// `extra_metas` is the output of [`resolve_thaw_extra_account_metas`] — empty for gates
/// without an extra-account-metas config. The crank `authority` is writable: it fronts the
/// flag-account allocation and receives its lamports back within the instruction.
pub fn thaw_permissionless_ix(
    authority: &Pubkey,
    mint: &Pubkey,
    token_account: &Pubkey,
    token_account_owner: &Pubkey,
    gating_program: &Pubkey,
    extra_metas: Vec<AccountMeta>,
    idempotent: bool,
) -> Instruction {
    let (mint_config, _) = mint_config_pda(mint);
    let (flag_account, _) = flag_account_pda(token_account);
    let discriminator = if idempotent {
        ix_disc::THAW_PERMISSIONLESS_IDEMPOTENT
    } else {
        ix_disc::THAW_PERMISSIONLESS
    };
    let mut accounts = vec![
        AccountMeta::new(*authority, true),
        AccountMeta::new_readonly(*mint, false),
        AccountMeta::new(*token_account, false),
        AccountMeta::new(flag_account, false),
        AccountMeta::new_readonly(*token_account_owner, false),
        AccountMeta::new_readonly(mint_config, false),
        AccountMeta::new_readonly(spl_token_2022::ID, false),
        AccountMeta::new_readonly(system_program::ID, false),
        AccountMeta::new_readonly(*gating_program, false),
    ];
    accounts.extend(extra_metas);
    Instruction {
        program_id: TOKEN_ACL_ID,
        accounts,
        data: vec![discriminator],
    }
}

/// The example with-deps gate's `InitializeExtraMetas` (discriminator `[1; 8]`): registers
/// non-trivial extra-account-metas configs for both thaw and freeze.
pub fn initialize_extra_metas_ix(payer: &Pubkey, mint: &Pubkey, gate: &Pubkey) -> Instruction {
    let (thaw_extra_metas, _) = thaw_extra_account_metas_pda(mint, gate);
    let (freeze_extra_metas, _) =
        Pubkey::find_program_address(&[b"freeze_extra_account_metas", mint.as_ref()], gate);
    Instruction {
        program_id: *gate,
        accounts: vec![
            AccountMeta::new(*payer, true),
            AccountMeta::new_readonly(*mint, false),
            AccountMeta::new(thaw_extra_metas, false),
            AccountMeta::new(freeze_extra_metas, false),
            AccountMeta::new_readonly(system_program::ID, false),
        ],
        data: vec![1; 8],
    }
}

/// 8-byte sRFC discriminator of the gate-side `can_thaw_permissionless` instruction.
pub fn can_thaw_permissionless_discriminator() -> [u8; 8] {
    let digest =
        hash::hash(b"efficient-allow-block-list-standard:can-thaw-permissionless").to_bytes();
    digest[..8].try_into().unwrap()
}

/// Resolves the gate's thaw extra account metas, mirroring token-acl
/// `interface/src/offchain.rs` against the `spl-tlv-account-resolution` wire format.
///
/// Returns the metas to append to a permissionless-thaw instruction: the extra-metas
/// account itself followed by the resolved extras, or empty when the gate registered no
/// extra-metas account (e.g. the plain always-allow/always-block examples).
pub async fn resolve_thaw_extra_account_metas(
    ctx: &mut TestContext,
    gating_program: &Pubkey,
    crank_authority: &Pubkey,
    token_account: &Pubkey,
    mint: &Pubkey,
    token_account_owner: &Pubkey,
) -> Vec<AccountMeta> {
    let (extra_metas_address, _) = thaw_extra_account_metas_pda(mint, gating_program);
    let Some(account) = ctx.get_account(extra_metas_address).await.unwrap() else {
        return vec![];
    };
    let stored =
        parse_extra_account_meta_list(&account.data, &can_thaw_permissionless_discriminator());

    // Simulate the account list of the gate-side can_thaw CPI: 5 fixed accounts, the
    // extra-metas account, then each resolved meta (later configs may reference earlier
    // resolved accounts by index).
    let (flag_account, _) = flag_account_pda(token_account);
    let mut cpi_accounts = vec![
        AccountMeta::new_readonly(*crank_authority, false),
        AccountMeta::new_readonly(*token_account, false),
        AccountMeta::new_readonly(*mint, false),
        AccountMeta::new_readonly(*token_account_owner, false),
        AccountMeta::new_readonly(flag_account, false),
        AccountMeta::new_readonly(extra_metas_address, false),
    ];
    let cpi_ix_data = can_thaw_permissionless_discriminator();
    for raw in stored {
        let resolved =
            resolve_extra_account_meta(ctx, &raw, gating_program, &cpi_ix_data, &cpi_accounts)
                .await;
        cpi_accounts.push(resolved);
    }
    cpi_accounts.split_off(5)
}

/// One stored `ExtraAccountMeta` (35 bytes: discriminator, 32-byte address config, two
/// flag bytes).
struct RawExtraAccountMeta {
    discriminator: u8,
    address_config: [u8; 32],
    is_signer: bool,
    is_writable: bool,
}

/// Walks the TLV entries of an extra-account-metas account ([8-byte type discriminator]
/// [u32 LE value length][value]) and parses the meta list ([u32 LE count][35-byte metas])
/// stored under `type_discriminator`.
fn parse_extra_account_meta_list(
    data: &[u8],
    type_discriminator: &[u8; 8],
) -> Vec<RawExtraAccountMeta> {
    const META_LEN: usize = 35;
    let mut cursor = 0;
    while cursor + 12 <= data.len() {
        let entry_discriminator = &data[cursor..cursor + 8];
        let value_len =
            u32::from_le_bytes(data[cursor + 8..cursor + 12].try_into().unwrap()) as usize;
        let value = &data[cursor + 12..cursor + 12 + value_len];
        if entry_discriminator == type_discriminator {
            let count = u32::from_le_bytes(value[..4].try_into().unwrap()) as usize;
            return (0..count)
                .map(|i| {
                    let bytes = &value[4 + i * META_LEN..4 + (i + 1) * META_LEN];
                    RawExtraAccountMeta {
                        discriminator: bytes[0],
                        address_config: bytes[1..33].try_into().unwrap(),
                        is_signer: bytes[33] != 0,
                        is_writable: bytes[34] != 0,
                    }
                })
                .collect();
        }
        cursor += 12 + value_len;
    }
    panic!("extra-account-metas account holds no entry for the requested discriminator");
}

/// Mirrors `ExtraAccountMeta::resolve`: discriminator 0 = literal pubkey, 1 = PDA on the
/// gate, 2 = pubkey read from account/instruction data, >=128 = PDA on the program whose
/// address sits at CPI account index (discriminator - 128).
async fn resolve_extra_account_meta(
    ctx: &mut TestContext,
    raw: &RawExtraAccountMeta,
    gating_program: &Pubkey,
    cpi_ix_data: &[u8],
    cpi_accounts: &[AccountMeta],
) -> AccountMeta {
    let pubkey = match raw.discriminator {
        0 => Pubkey::try_from(&raw.address_config[..]).unwrap(),
        2 => resolve_pubkey_data(ctx, &raw.address_config, cpi_accounts).await,
        d if d == 1 || d >= 128 => {
            let program_id = if d == 1 {
                *gating_program
            } else {
                cpi_accounts[(d - 128) as usize].pubkey
            };
            let seeds = resolve_seeds(ctx, &raw.address_config, cpi_ix_data, cpi_accounts).await;
            let seed_slices: Vec<&[u8]> = seeds.iter().map(Vec::as_slice).collect();
            Pubkey::find_program_address(&seed_slices, &program_id).0
        }
        d => panic!("unknown ExtraAccountMeta discriminator {d}"),
    };
    AccountMeta {
        pubkey,
        is_signer: raw.is_signer,
        is_writable: raw.is_writable,
    }
}

/// Pubkey-data config: `[1, index]` = 32 bytes of instruction data at `index`;
/// `[2, account_index, data_index]` = 32 bytes of the account's data at `data_index`.
async fn resolve_pubkey_data(
    ctx: &mut TestContext,
    config: &[u8; 32],
    cpi_accounts: &[AccountMeta],
) -> Pubkey {
    match config[0] {
        2 => {
            let account_index = config[1] as usize;
            let data_index = config[2] as usize;
            let account = ctx
                .get_account(cpi_accounts[account_index].pubkey)
                .await
                .unwrap()
                .expect("pubkey-data source account missing");
            Pubkey::try_from(&account.data[data_index..data_index + 32]).unwrap()
        }
        d => panic!("unsupported PubkeyData discriminator {d}"),
    }
}

/// Seed configs, packed back to back: `[1, len, ..bytes]` literal, `[2, index, length]`
/// instruction data, `[3, index]` account key, `[4, account_index, data_index, length]`
/// account data. Zero terminates.
async fn resolve_seeds(
    ctx: &mut TestContext,
    config: &[u8; 32],
    cpi_ix_data: &[u8],
    cpi_accounts: &[AccountMeta],
) -> Vec<Vec<u8>> {
    let mut seeds = vec![];
    let mut i = 0;
    while i < config.len() {
        match config[i] {
            0 => break,
            1 => {
                let len = config[i + 1] as usize;
                seeds.push(config[i + 2..i + 2 + len].to_vec());
                i += 2 + len;
            }
            2 => {
                let start = config[i + 1] as usize;
                let len = config[i + 2] as usize;
                seeds.push(cpi_ix_data[start..start + len].to_vec());
                i += 3;
            }
            3 => {
                let index = config[i + 1] as usize;
                seeds.push(cpi_accounts[index].pubkey.as_ref().to_vec());
                i += 2;
            }
            4 => {
                let account_index = config[i + 1] as usize;
                let start = config[i + 2] as usize;
                let len = config[i + 3] as usize;
                let account = ctx
                    .get_account(cpi_accounts[account_index].pubkey)
                    .await
                    .unwrap()
                    .expect("seed source account missing");
                seeds.push(account.data[start..start + len].to_vec());
                i += 4;
            }
            d => panic!("unknown seed discriminator {d}"),
        }
    }
    seeds
}

/// Instructions initializing a Token-2022 mint with the `DefaultAccountState` and
/// `MetadataPointer` extensions — the exact creation sequence the reworked `init_vault`
/// will use (extension inits must precede `initialize_mint2`).
pub fn create_t22_mint_ixs(
    payer: &Pubkey,
    mint: &Pubkey,
    mint_authority: &Pubkey,
    freeze_authority: &Pubkey,
    decimals: u8,
    default_state: AccountState,
    rent_lamports_for: impl Fn(usize) -> u64,
) -> Vec<Instruction> {
    let space = ExtensionType::try_calculate_account_len::<Mint>(&[
        ExtensionType::DefaultAccountState,
        ExtensionType::MetadataPointer,
    ])
    .unwrap();
    vec![
        system_instruction::create_account(
            payer,
            mint,
            rent_lamports_for(space),
            space as u64,
            &spl_token_2022::ID,
        ),
        spl_token_2022::extension::default_account_state::instruction::initialize_default_account_state(
            &spl_token_2022::ID,
            mint,
            &default_state,
        )
        .unwrap(),
        spl_token_2022::extension::metadata_pointer::instruction::initialize(
            &spl_token_2022::ID,
            mint,
            Some(*mint_authority),
            Some(*mint),
        )
        .unwrap(),
        spl_token_2022::instruction::initialize_mint2(
            &spl_token_2022::ID,
            mint,
            mint_authority,
            Some(freeze_authority),
            decimals,
        )
        .unwrap(),
    ]
}

/// Test scaffold shared by the harness smoke tests: a lean context with token-acl and the
/// requested gate fixtures loaded (exercising the `ProgramDependency` mapping), a funded
/// admin, and one T22+DAS mint whose mint and freeze authority is the admin.
pub struct TokenAclTestBed {
    pub ctx: TestContext,
    pub admin: KP,
    pub mint: Pubkey,
}

pub async fn start_token_acl_test_bed(
    gates: Vec<ProgramDependency>,
    default_state: AccountState,
) -> TokenAclTestBed {
    let mut deps = vec![ProgramDependency::TokenAcl];
    deps.extend(gates);
    let mut program_test = test::program_with_deps(fixtures::to_program_deps(deps));
    let admin = funded_kp(&mut program_test, 1_000 * LAMPORTS_PER_SOL);
    let mut ctx = test::start(program_test, &admin).await;

    let mint_kp = Keypair::new();
    let rent = ctx.rent;
    let ixs = create_t22_mint_ixs(
        &admin.pubkey(),
        &mint_kp.pubkey(),
        &admin.pubkey(),
        &admin.pubkey(),
        6,
        default_state,
        |space| rent.minimum_balance(space),
    );
    let tx = ctx
        .create_transaction_with_payer_and_extra_signers(ixs, &admin, [&mint_kp])
        .await;
    kamino_lending::send_transaction!(ctx, tx).unwrap();

    TokenAclTestBed {
        ctx,
        admin,
        mint: mint_kp.pubkey(),
    }
}

use kamino_lending::program_test::common::types::{KaminoMarketGeneric, MarketsSpec};

use crate::program_test::VaultAccounts;

#[derive(Debug, Clone)]
pub struct VaultSpec {
    pub markets: MarketsSpec,
    pub token: String,
}

#[derive(Debug, Clone)]
pub struct KaminoVault {
    pub token: String,
    pub vault: VaultAccounts,
    pub markets: Vec<KaminoMarketGeneric>,
}

impl KaminoVault {
    pub fn new(token: &str, vault: VaultAccounts, markets: Vec<KaminoMarketGeneric>) -> Self {
        Self {
            token: token.to_string(),
            vault,
            markets,
        }
    }
}

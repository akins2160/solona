use anchor_lang::prelude::*;

use crate::{state::MetavaultState, types::Timestamp, utils::consts::MAX_TOKENS_PER_VAULT};

// Events
#[event]
pub struct DepositUserAtaBalanceEvent {
    pub user_ata_balance: u64,
}

#[event]
pub struct DepositResultEvent {
    pub shares_to_mint: u64,
    pub token_to_deposit: u64,
}

#[event]
pub struct SharesToWithdrawEvent {
    pub shares_amount: u64,
    pub user_shares_before: u64,
}

#[event]
pub struct WithdrawResultEvent {
    pub shares_to_burn: u64,
    pub available_to_send_to_user: u64,
}

#[event]
pub struct VaultRefreshedEvent {
    pub vault_state: Pubkey,
    pub timestamp: u64,
    pub fee_shares_to_mint: u64,
    pub prev_aum_sf: u128,
    pub pending_fees_sf: u128,
}

#[event]
pub struct ObligationInitializedEvent {
    pub storage_index: u8,
    pub obligation: Pubkey,
    pub lending_market: Pubkey,
}

#[event]
pub struct ObligationRemovedEvent {
    pub storage_index: u8,
    pub obligation: Pubkey,
}

#[event]
pub struct ObligationElevationGroupChangedEvent {
    pub storage_index: u8,
    pub obligation: Pubkey,
    pub new_elevation_group: u8,
}

#[event]
pub struct ObligationCollateralDepositEvent {
    pub storage_index: u8,
    pub reserve: Pubkey,
    pub amount: u64,
}

#[event]
pub struct ObligationCollateralWithdrawEvent {
    pub storage_index: u8,
    pub reserve: Pubkey,
    pub amount: u64,
}

#[event]
pub struct ObligationLiquidityBorrowEvent {
    pub storage_index: u8,
    pub reserve: Pubkey,
    pub amount: u64,
}

#[event]
pub struct ObligationLiquidityRepayEvent {
    pub storage_index: u8,
    pub reserve: Pubkey,
    pub amount: u64,
}

#[event]
pub struct RebalanceStartedEvent {
    pub vault_state: Pubkey,
    pub duration: u64,
    pub start_timestamp: u64,
}

/// Why a rebalance ended.
///
/// Note: an "expired" reason is not reported - it can be inferred from the [RebalanceStartedEvent]
/// (and is generally not auto-emittable on-chain when no transactions happen).
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, Debug, PartialEq, Eq)]
pub enum RebalanceEndReason {
    /// Inside the window, no fill could make progress any more: no token sat above its target
    /// while another sat below, both outside tolerance.
    ///
    /// This says nothing about *why* the vault ran out of fillable pairs. Reaching every target
    /// qualifies, and so does a deposit or withdrawal moving the targets to where the current
    /// balances already sit - hence "settled", not "completed".
    Settled,
    /// The allocation authority ended it forcibly while still inside the window.
    Stopped,
}

/// A deposit order was opened and its auction started.
#[event]
pub struct DepositOrderOpenedEvent {
    pub vault_state: Pubkey,
    pub order: Pubkey,
    pub owner: Pubkey,
    /// When the auction ends (unless a fill completes it earlier).
    pub rebalance_end_timestamp: u64,
    pub timestamp: u64,
}

/// A solver filled part of an order's auction (of either kind).
#[event]
pub struct OrderFillEvent {
    pub vault_state: Pubkey,
    pub order: Pubkey,
    pub token_in_mint: Pubkey,
    pub token_out_mint: Pubkey,
    pub amount_in: u64,
    pub amount_out: u64,
    /// Whether this fill ended the auction (else it ends at the opened event's end timestamp).
    pub auction_ended: bool,
    pub timestamp: u64,
}

/// How a deposit order ended.
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, Debug, PartialEq, Eq)]
pub enum DepositOrderEndReason {
    /// Settled: the vault took what it admitted and refunded the rest.
    Settled,
    /// Cancelled after the auction was already over.
    Cancelled,
    /// Cancelled while the auction was still running.
    CancelledMidAuction,
}

/// The order ended and its account was deleted (the only end event of an order).
#[event]
pub struct DepositOrderClosedEvent {
    pub vault_state: Pubkey,
    pub order: Pubkey,
    pub shares_minted: u64,
    /// What went back to the owner (in the vault's storage index order).
    pub refunds: [u64; MAX_TOKENS_PER_VAULT],
    pub reason: DepositOrderEndReason,
    pub timestamp: u64,
}

/// A withdraw order was opened and its auction started.
#[event]
pub struct WithdrawOrderOpenedEvent {
    pub vault_state: Pubkey,
    pub order: Pubkey,
    pub owner: Pubkey,
    pub shares_burned: u64,
    /// What the vault released into the order (in the vault's storage index order).
    pub released: [u64; MAX_TOKENS_PER_VAULT],
    /// When the auction ends (unless a fill completes it earlier).
    pub rebalance_end_timestamp: u64,
    pub timestamp: u64,
}

/// How a withdraw order ended.
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, Debug, PartialEq, Eq)]
pub enum WithdrawOrderEndReason {
    /// Paid out after the auction was already over.
    Settled,
    /// Paid out by the owner while the auction was still running.
    SettledMidAuction,
}

/// The order ended and its account was deleted (the only end event of an order).
#[event]
pub struct WithdrawOrderClosedEvent {
    pub vault_state: Pubkey,
    pub order: Pubkey,
    /// What the owner received (in the vault's storage index order).
    pub payouts: [u64; MAX_TOKENS_PER_VAULT],
    pub reason: WithdrawOrderEndReason,
    pub timestamp: u64,
}

#[event]
pub struct RebalanceEndedEvent {
    pub vault_state: Pubkey,
    pub timestamp: u64,
    pub reason: RebalanceEndReason,
}

/// Watches whether an instruction ends the rebalance that was running when it [Self::open()]ed.
#[derive(Debug, Clone, Copy)]
pub struct RebalanceEndWatch {
    vault_pk: Pubkey,

    now: Timestamp,

    was_within_rebalance_window: bool,
}

impl RebalanceEndWatch {
    pub fn open(vault_pk: Pubkey, vault: &MetavaultState, now: Timestamp) -> Self {
        Self {
            vault_pk,
            now,
            was_within_rebalance_window: vault.rebalance.is_within(now),
        }
    }

    pub fn on_balances_changed(&self, vault_state: &MetavaultState) -> Option<RebalanceEndedEvent> {
        if vault_state.rebalance.is_unfinished() {
            return None;
        }
        self.create_event_if_ended(RebalanceEndReason::Settled)
    }

    pub fn on_new_rebalance_start(&self) -> Option<RebalanceEndedEvent> {
        self.create_event_if_ended(RebalanceEndReason::Settled)
    }

    /// Always an ending: a stop closes an unfinished rebalance, even one whose window elapsed.
    pub fn on_admin_stop(&self) -> RebalanceEndedEvent {
        self.event(RebalanceEndReason::Stopped)
    }

    fn create_event_if_ended(&self, reason: RebalanceEndReason) -> Option<RebalanceEndedEvent> {
        if !self.was_within_rebalance_window {
            return None; // nothing could have ended
        }
        Some(self.event(reason))
    }

    fn event(&self, reason: RebalanceEndReason) -> RebalanceEndedEvent {
        RebalanceEndedEvent {
            vault_state: self.vault_pk,
            timestamp: self.now.into(),
            reason,
        }
    }
}

#[event]
pub struct RebalanceSwapEvent {
    pub vault_state: Pubkey,
    pub token_in_mint: Pubkey,
    pub token_out_mint: Pubkey,
    pub amount_in: u64,
    pub amount_out: u64,
    pub timestamp: u64,
}

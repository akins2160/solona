use crate::types::{Timestamp, TokenPrice, VaultTokenId};
use crate::utils::remaining_accounts::RemainingAccounts;
use crate::{KaminoVaultError, MetavaultState};
use anchor_lang::prelude::*;
use kamino_lending::PriceStatusFlags;
use kamino_lending::{
    utils::prices::checks::get_validated_price_with_args,
    utils::prices::scope::get_scope_price_and_twap,
};
use solana_program::clock::UnixTimestamp;

#[derive(Clone, Default)]
pub struct VaultScopePrices {
    pub prices: Vec<TokenPrice>,
}

impl VaultScopePrices {
    pub fn by_id(&self, id: VaultTokenId) -> &TokenPrice {
        &self.prices[id.input_account_index]
    }
}

/// The checks a vault token's price must pass: loaded and fresh, plus fresh and near its TWAP when
/// the token enables the TWAP check (`max_twap_divergence_bps > 0`; with it off, both TWAP flags
/// count as passed). No confidence-interval check is made: a fresh scope price is taken as is.
pub const ALL_METAVAULT_PRICE_CHECKS: PriceStatusFlags = PriceStatusFlags::PRICE_LOADED
    .union(PriceStatusFlags::PRICE_AGE_CHECKED)
    .union(PriceStatusFlags::TWAP_AGE_CHECKED)
    .union(PriceStatusFlags::TWAP_CHECKED);

impl VaultScopePrices {
    // Load only 1 price that is set to 1.0$
    // This should be used ONLY when vault is initialized
    //
    // Reasoning: Even though we have a correct price at the moment of initialization
    // using a very low price token as the first one can end up minting too few shares
    pub fn mock_scope_prices_for_vault_init(decimals: u8) -> VaultScopePrices {
        let mut vault_prices = VaultScopePrices::default();
        vault_prices.prices.push(TokenPrice::one_dollar(decimals));
        vault_prices
    }

    // Load remaining accounts based on which tokens are enabled in the vault
    //
    // Iterates through the enabled vault tokens, and for each expect a scope account passed as remaining accounts
    // This function checks that: - scope configuration is set up correctly and scope accounts passed are correct
    //                            - prices are valid based on max age and max twap divergence
    // else it fails the entire load fn as we always need all prices
    //
    // Returns a struct with a vec that should have Some(price) for each enabled & valid vault token
    pub fn load_and_validate_from_remaining_accounts(
        vault: &MetavaultState,
        remaining: &mut RemainingAccounts,
        timestamp: Timestamp,
    ) -> Result<VaultScopePrices> {
        let mut vault_scope_prices = VaultScopePrices::default();
        for vault_token in vault.iter_enabled_tokens() {
            let scope_account = remaining
                .next_or(ProgramError::NotEnoughAccountKeys)?
                .as_info();
            vault_token.validate_token_price_config(scope_account.key())?;
            require_keys_eq!(
                *scope_account.owner,
                scope::ID,
                KaminoVaultError::InvalidScopePriceAccount
            );

            // Get price and twap based on scope config & validate twap, age and confidence
            // These 2 functions called from klend already print messages for their errors so we are fine with just mapping the error
            let new_price = get_validated_price_with_args(
                get_scope_price_and_twap(scope_account, &vault_token.scope_configuration)?,
                vault_token.max_age_price_seconds,
                vault_token.max_age_twap_seconds,
                vault_token.max_twap_divergence_bps,
                vault_token.is_twap_enabled(),
                &vault_token.symbol(),
                UnixTimestamp::try_from(u64::from(timestamp)).unwrap(),
            )
            .ok_or(KaminoVaultError::InvalidScopePrice)?;

            if !new_price.status.contains(ALL_METAVAULT_PRICE_CHECKS) {
                crate::kmsg_sized!(
                    100,
                    "Price for mint {} has invalid status {:?}",
                    vault_token.mint,
                    new_price.status
                );
                return Err(KaminoVaultError::InvalidScopePrice.into());
            }

            require!(
                !new_price.price.is_zero(),
                KaminoVaultError::InvalidScopePrice
            );

            // Every check passed -> price is enabled and valid
            vault_scope_prices
                .prices
                .push(TokenPrice::new(new_price.price, vault_token.decimals));
        }
        Ok(vault_scope_prices)
    }
}

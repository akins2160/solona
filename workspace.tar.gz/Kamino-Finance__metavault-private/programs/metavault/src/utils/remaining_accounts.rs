use anchor_lang::prelude::*;
use anchor_lang::{CheckId, Owners, ZeroCopy};
use kamino_lending::utils::FatAccountLoader;

use crate::{kmsg_sized, KaminoVaultError};

/// Deals `remaining_accounts` out front to back, as [NextAccount]s. What is left after the segments
/// an instruction reads is either refused ([Self::check_none_remaining]) or handed over to forward
/// ([Self::rest]).
pub struct RemainingAccounts<'info> {
    /// The accounts not dealt yet.
    left: std::slice::Iter<'info, AccountInfo<'info>>,

    /// How many were dealt so far (the next one's position).
    dealt: usize,
}

impl<'info> RemainingAccounts<'info> {
    pub fn new(accounts: &'info [AccountInfo<'info>]) -> Self {
        Self {
            left: accounts.iter(),
            dealt: 0,
        }
    }

    /// The next account, or the `missing` error once they ran out.
    pub fn next_or<E: Into<Error>>(&mut self, missing: E) -> Result<NextAccount<'info>> {
        let info = self.left.next().ok_or_else(|| missing.into())?;
        let position = self.dealt;
        self.dealt += 1;
        Ok(NextAccount { info, position })
    }

    /// Fails if any accounts are left past the ones the instruction reads.
    pub fn check_none_remaining(&self) -> Result<()> {
        require!(
            self.left.len() == 0,
            KaminoVaultError::UnexpectedRemainingAccounts
        );
        Ok(())
    }

    /// Everything not dealt yet (for the instruction to forward).
    pub fn rest(self) -> &'info [AccountInfo<'info>] {
        self.left.as_slice()
    }
}

/// One dealt account, still to be checked against the expected key and read as its type.
#[derive(Clone, Copy)]
pub struct NextAccount<'info> {
    info: &'info AccountInfo<'info>,

    /// Its index within `remaining_accounts` (for error logs).
    position: usize,
}

impl<'info> NextAccount<'info> {
    /// Fails (logging the position, the slot's `name` and both keys) unless this is the `expected`
    /// account.
    pub fn check_key(self, expected: &Pubkey, name: &str) -> Result<Self> {
        if self.info.key() != *expected {
            kmsg_sized!(
                256,
                "Remaining account #{} ({}) is {}, expected {}",
                self.position,
                name,
                self.info.key(),
                expected
            );
            return err!(KaminoVaultError::RemainingAccountKeyMismatch);
        }
        Ok(self)
    }

    pub fn as_info(self) -> &'info AccountInfo<'info> {
        self.info
    }

    /// Reads it as a zero-copy `T` (via klend's loader).
    pub fn as_loader<T: ZeroCopy + Owner>(self) -> Result<FatAccountLoader<'info, T>> {
        FatAccountLoader::try_from(self.info)
    }

    /// Reads it as a token-interface `T` (a mint or a TA of either token program).
    pub fn as_interface_account<T: AccountSerialize + AccountDeserialize + Owners + Clone>(
        self,
    ) -> Result<InterfaceAccount<'info, T>> {
        InterfaceAccount::try_from(self.info)
    }

    /// Reads it as one of the programs `T` allows.
    pub fn as_interface<T: CheckId>(self) -> Result<Interface<'info, T>> {
        Interface::try_from(self.info)
    }
}

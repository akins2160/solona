use anchor_lang::prelude::*;
use anchor_lang::solana_program::clock::Slot;
use kamino_lending::utils::FatAccountLoader;
use kamino_lending::{Obligation, PriceStatusFlags, Reserve};

use crate::operations::vault_checks::{check_reserve_price_basis, find_enabled_token_and_price};
use crate::types::{
    DollarValue, FractionalTokenAmount, NetAum, RoundingMethod, Timestamp, TokenAmount, TokenPrice,
};
use crate::utils::remaining_accounts::RemainingAccounts;
use crate::utils::scope::VaultScopePrices;
use crate::{KaminoVaultError, MetavaultState};

/// The obligation segments of the remaining-accounts layout every AUM-loading instruction shares
/// (the scope prices come first, CPI-forwarded accounts may trail):
/// 1. one scope price account per enabled vault token, in `vault.iter_enabled_tokens()` order
///    ([VaultScopePrices::load_and_validate_from_remaining_accounts]);
/// 2. one klend `Obligation` account per enabled obligation, in `vault.iter_enabled_obligations()`
///    order;
/// 3. one klend `Reserve` account per active obligation leg: for each obligation in segment-2
///    order, its active deposit legs then its active borrow legs (array order);
/// 4. whatever the instruction owns past them ([RemainingAccounts::rest]).
///
/// Only constructible by parsing, which proves the leg count comes from on-chain obligation state
/// and every account is checked against the vault's registered state (the semantic checks live in
/// [load_obligations_aum]).
pub struct AumAccounts<'info> {
    obligations: Vec<FatAccountLoader<'info, Obligation>>,
    leg_reserves: Vec<FatAccountLoader<'info, Reserve>>,
}

impl<'info> AumAccounts<'info> {
    /// Deals the obligation and leg-reserve segments off `remaining`, reading each obligation to
    /// list its active legs. Failures here (accounts running out, wrong keys) mean a malformed
    /// transaction, never a market-state condition.
    pub fn parse(vault: &MetavaultState, remaining: &mut RemainingAccounts<'info>) -> Result<Self> {
        let mut obligations = Vec::with_capacity(vault.get_obligations_count());
        for vault_obligation in vault.iter_enabled_obligations() {
            let obligation = remaining
                .next_or(KaminoVaultError::ObligationAccountMissing)?
                .check_key(&vault_obligation.obligation, "obligation")?
                .as_loader::<Obligation>()?;
            obligations.push(obligation);
        }
        // The leg segment follows the whole obligation segment, in the same obligation order.
        let mut leg_reserves = Vec::new();
        for obligation_loader in &obligations {
            let obligation = obligation_loader.load()?;
            let deposit_legs = obligation.active_deposits().map(|leg| leg.deposit_reserve);
            let borrow_legs = obligation.active_borrows().map(|leg| leg.borrow_reserve);
            for expected in deposit_legs.chain(borrow_legs) {
                let reserve = remaining
                    .next_or(KaminoVaultError::ObligationAccountMissing)?
                    .check_key(&expected, "leg reserve")?
                    .as_loader::<Reserve>()?;
                leg_reserves.push(reserve);
            }
        }
        Ok(Self {
            obligations,
            leg_reserves,
        })
    }
}

/// The whole layout read and valued at once, for instructions without a CPI-forwarded tail: the
/// scope prices, then [AumAccounts::parse]'s segments, then nothing.
pub fn load_scope_prices_and_obligations_aum<'info>(
    vault: &MetavaultState,
    remaining_accounts: &'info [AccountInfo<'info>],
    slot: Slot,
    timestamp: Timestamp,
) -> Result<(VaultScopePrices, NetAum)> {
    let mut remaining = RemainingAccounts::new(remaining_accounts);
    let loaded =
        load_scope_prices_and_obligations_aum_from(vault, &mut remaining, slot, timestamp)?;
    remaining.check_none_remaining()?;
    Ok(loaded)
}

/// Like [load_scope_prices_and_obligations_aum], off a `remaining` reader that the instruction
/// keeps reading past them.
pub fn load_scope_prices_and_obligations_aum_from(
    vault: &MetavaultState,
    remaining: &mut RemainingAccounts,
    slot: Slot,
    timestamp: Timestamp,
) -> Result<(VaultScopePrices, NetAum)> {
    let scope_prices =
        VaultScopePrices::load_and_validate_from_remaining_accounts(vault, remaining, timestamp)?;
    let aum_accounts = AumAccounts::parse(vault, remaining)?;
    let obligations_aum = load_obligations_aum(vault, &scope_prices, &aum_accounts, slot)?;
    Ok((scope_prices, obligations_aum))
}

/// Recomputes obligation net AUM on the vault's own price basis from the parsed [AumAccounts]:
/// every obligation and leg reserve must be refreshed by klend in the current slot (leg amounts,
/// accrued interest and exchange rates current — klend's *prices* are not read for valuation),
/// and every leg reserve must stay within the per-token divergence bound
/// ([check_reserve_price_basis]).
///
/// Obligation AUM is vault-favorable: deposit legs are converted ctokens→liquidity through the
/// reserve's exchange rate and valued at the scope price with floor; borrow legs are valued as
/// fractional liquidity at the scope price with ceil.
pub fn load_obligations_aum(
    vault: &MetavaultState,
    scope_prices: &VaultScopePrices,
    accounts: &AumAccounts<'_>,
    slot: Slot,
) -> Result<NetAum> {
    let mut leg_reserves = accounts.leg_reserves.iter();

    let mut total_deposited = DollarValue::ZERO;
    let mut total_borrowed = DollarValue::ZERO;
    for obligation_loader in &accounts.obligations {
        let obligation = obligation_loader.load()?;
        require!(
            !obligation
                .last_update
                .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?,
            KaminoVaultError::ObligationStale
        );

        for collateral in obligation.active_deposits() {
            let reserve = next_pinned_leg_reserve(&mut leg_reserves)?.load()?;
            let token_price = validate_leg_reserve(vault, scope_prices, &reserve, slot)?;
            let liquidity_f = FractionalTokenAmount::from(
                reserve
                    .collateral_exchange_rate()
                    .fraction_collateral_to_liquidity(
                        TokenAmount::from(collateral.deposited_amount).as_fraction(),
                    ),
            );
            total_deposited += liquidity_f.to_aum(token_price, RoundingMethod::Floor);
        }
        for liquidity in obligation.active_borrows() {
            let reserve = next_pinned_leg_reserve(&mut leg_reserves)?.load()?;
            let token_price = validate_leg_reserve(vault, scope_prices, &reserve, slot)?;
            let borrowed_f = FractionalTokenAmount::from(liquidity.borrowed_amount());
            total_borrowed += borrowed_f.to_aum(token_price, RoundingMethod::Ceil);
        }
    }
    Ok(NetAum::net_from_diff(total_deposited, total_borrowed))
}

/// Parsing pinned one reserve per leg over the same obligation data this walk re-reads, so the
/// iterator cannot run dry; the guard stands in for an unreachable panic.
fn next_pinned_leg_reserve<'a, 'info>(
    leg_reserves: &mut std::slice::Iter<'a, FatAccountLoader<'info, Reserve>>,
) -> Result<&'a FatAccountLoader<'info, Reserve>> {
    leg_reserves
        .next()
        .ok_or_else(|| KaminoVaultError::ObligationAccountMissing.into())
}

fn validate_leg_reserve<'a>(
    vault: &'a MetavaultState,
    scope_prices: &'a VaultScopePrices,
    reserve: &Reserve,
    slot: Slot,
) -> Result<&'a TokenPrice> {
    require!(
        !reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?,
        KaminoVaultError::ReserveStale
    );
    let (vault_token, token_price) =
        find_enabled_token_and_price(vault, scope_prices, &reserve.liquidity.mint_pubkey)?;
    check_reserve_price_basis(vault_token, token_price, reserve)?;
    Ok(token_price)
}

use anchor_lang::prelude::*;
#[cfg(feature = "serde")]
use strum::EnumIter;
use strum::EnumString;

#[derive(AnchorSerialize, AnchorDeserialize, PartialEq, Eq, Clone, Copy, Debug, EnumString)]
#[cfg_attr(any(test, feature = "serde"), derive(EnumIter))]
#[repr(u8)]
pub enum UpdateGlobalConfigMode {
    PendingAdmin,
    MinWithdrawalFeeLamports,
    MinWithdrawalFeeBPS,
    MinDepositFeeLamports,
    MinDepositFeeBPS,
    /// 32-byte pubkey. The krfq auction server key that co-signs krfq-gated
    /// `rebalance_swap` fills. `Pubkey::default()` = unset (gated vaults fail closed).
    KrfqSwapAuthority,
}

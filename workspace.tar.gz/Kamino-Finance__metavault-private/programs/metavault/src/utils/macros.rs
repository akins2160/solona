#[macro_export]
macro_rules! gen_signer_seeds {
    (
    $seed: expr, $first_key: expr, $bump: expr
) => {
        &[$seed as &[u8], $first_key.as_ref(), &[$bump]]
    };
}

/// Rejects invocation through CPI, i.e. requires the instruction to sit at transaction level.
///
/// Applied only to the instructions anyone can call: `buy`, `sell`, `rebalance_swap`,
/// `refresh_vault` and `finish_rebalance`. There, top-level execution is the requirement — it
/// keeps user flows and solver fills from being wrapped by another program.
///
/// Deliberately NOT applied to administrative instructions. Those are already authenticated by a
/// signer plus a `has_one` authority check, and the guard would otherwise lock out on-chain
/// multisigs and governance programs (Squads and similar execute an approved instruction through
/// CPI from a vault PDA), which is exactly how the admin keys are expected to be held. It also
/// blocks nothing an authorized caller cannot already do by composing instructions at the top
/// level of one transaction.
///
/// Those instructions keep `instruction_sysvar_account` in their account layout even though they
/// no longer read it, so existing clients and the IDL stay valid; drop it from all of them
/// together whenever the next IDL-breaking change lands.
#[macro_export]
macro_rules! check_cpi {
    ($ctx:expr) => {{
        $crate::utils::check_cpi_call(&$ctx.accounts.instruction_sysvar_account)?;
    }};
}

#[macro_export]
macro_rules! require_msg {
    ($invariant:expr, $error:expr $(,)?, $message: expr) => {
        if !($invariant) {
            msg!($message);
            return Err(anchor_lang::error!($error));
        }
    };
}

#[macro_export]
macro_rules! arrform {
    ($size:expr, $($arg:tt)*) => {{
        let mut af = arrform::ArrForm::<$size>::new();

        af.format(format_args!($($arg)*)).unwrap_or_else(|_| {
            <arrform::ArrForm<$size> as ::std::fmt::Write>::write_str(&mut af, "Buffer overflow").unwrap();
        });
        af
    }}
}

/// Log a formatted message with automatic capacity estimation
/// Uses arrform! and msg! together for efficient logging
/// Capacity is conservatively estimated based on format string length
#[macro_export]
macro_rules! kmsg {
    // For formats without arguments
    ($fmt:expr) => {{
        // Choose capacity tier based on format string length
        match $fmt.len() {
            0..=50 => {
                let formatted = $crate::arrform!{250, $fmt};
                solana_program::log::sol_log(formatted.as_str());
            },
            51..=100 => {
                let formatted = $crate::arrform!{400, $fmt};
                solana_program::log::sol_log(formatted.as_str());
            },
            101..=200 => {
                let formatted = $crate::arrform!{700, $fmt};
                solana_program::log::sol_log(formatted.as_str());
            },
            _ => {
                let formatted = $crate::arrform!{1300, $fmt};
                solana_program::log::sol_log(formatted.as_str());
            }
        }
    }};

    // For formats with arguments
    ($fmt:expr, $($arg:expr),+) => {{
        // Choose capacity tier based on format string length
        // This is very conservative to avoid overflows
        match $fmt.len() {
            0..=50 => {
                let formatted = $crate::arrform!{150, $fmt, $($arg),+};
                solana_program::log::sol_log(formatted.as_str());
            },
            51..=100 => {
                let formatted = $crate::arrform!{300, $fmt, $($arg),+};
                solana_program::log::sol_log(formatted.as_str());
            },
            101..=200 => {
                let formatted = $crate::arrform!{600, $fmt, $($arg),+};
                solana_program::log::sol_log(formatted.as_str());
            },
            _ => {
                let formatted = $crate::arrform!{1200, $fmt, $($arg),+};
                solana_program::log::sol_log(formatted.as_str());
            }
        }
    }};
}

/// Same as kmsg! but allows specifying a custom capacity
#[macro_export]
macro_rules! kmsg_sized {
    ($capacity:expr, $fmt:expr) => {{
        let formatted = $crate::arrform!{$capacity, $fmt};
        solana_program::log::sol_log(formatted.as_str());
    }};
    ($capacity:expr, $fmt:expr, $($arg:expr),+) => {{
        let formatted = $crate::arrform!($capacity, $fmt, $($arg),+);
        solana_program::log::sol_log(formatted.as_str());
    }};
}

//! Hand-rolled CPIs into the Token ACL program (sRFC-37).
//!
//! The upstream `token-acl-client` crate targets borsh 1.0 / solana 3.x and cannot link
//! against this workspace's solana 1.17 / borsh 0.10 stack, so the wire formats are
//! encoded here directly. Account orders and discriminators are pinned against the real
//! program by `tests/tests_token_acl_harness.rs`.

use anchor_lang::{
    prelude::{AccountInfo, Pubkey, Result},
    require,
    solana_program::{
        instruction::{AccountMeta, Instruction},
        program::invoke_signed,
        pubkey,
    },
};
use anchor_spl::token_2022::spl_token_2022::{
    self,
    extension::{
        default_account_state::instruction::update_default_account_state,
        immutable_owner::ImmutableOwner, BaseStateWithExtensions, StateWithExtensions,
    },
    state::AccountState,
};

use super::consts::BASE_VAULT_AUTHORITY_SEED;
use crate::{gen_signer_seeds, KaminoVaultError, MetavaultState};

pub const TOKEN_ACL_PROGRAM_ID: Pubkey = pubkey!("TACLkU6CiCdkQN2MjoyDkVg2yAH9zkxiHDsiztQ52TP");
pub const MINT_CONFIG_SEED: &[u8] = b"MINT_CONFIG";

const CREATE_CONFIG_DISCRIMINATOR: u8 = 0;
const SET_GATING_PROGRAM_DISCRIMINATOR: u8 = 2;
const DELETE_CONFIG_DISCRIMINATOR: u8 = 3;
const THAW_DISCRIMINATOR: u8 = 4;
const FREEZE_DISCRIMINATOR: u8 = 5;
const TOGGLE_PERMISSIONLESS_DISCRIMINATOR: u8 = 8;

pub fn mint_config_pda(mint: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&[MINT_CONFIG_SEED, mint.as_ref()], &TOKEN_ACL_PROGRAM_ID)
}

/// Parsed token-acl `MintConfig` account (100 bytes, discriminator 1).
///
/// The on-chain field holding the config admin is named `freeze_authority` upstream — it
/// is NOT the token freeze authority (that is the MintConfig PDA itself once configured).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MintConfig {
    pub bump: u8,
    pub permissionless_thaw_enabled: bool,
    pub permissionless_freeze_enabled: bool,
    pub mint: Pubkey,
    pub config_admin: Pubkey,
    pub gating_program: Pubkey,
}

impl MintConfig {
    pub const LEN: usize = 100;
    pub const DISCRIMINATOR: u8 = 1;

    pub fn unpack(data: &[u8]) -> Option<Self> {
        if data.len() != Self::LEN || data[0] != Self::DISCRIMINATOR {
            return None;
        }
        Some(Self {
            bump: data[1],
            permissionless_thaw_enabled: data[2] != 0,
            permissionless_freeze_enabled: data[3] != 0,
            mint: Pubkey::try_from(&data[4..36]).unwrap(),
            config_admin: Pubkey::try_from(&data[36..68]).unwrap(),
            gating_program: Pubkey::try_from(&data[68..100]).unwrap(),
        })
    }
}

/// Shared guard of every ACL wrapper instruction: the vault must be permissioned (this
/// is also what keeps open vaults' parked freeze authority inert) and the passed config
/// account must be the token-acl MintConfig PDA of the shares mint.
pub fn validate_permissioned_vault_accounts(
    vault: &MetavaultState,
    shares_mint: &Pubkey,
    mint_config: &anchor_lang::prelude::AccountInfo,
) -> anchor_lang::Result<()> {
    require!(
        vault.shares_permissioned(),
        KaminoVaultError::SharesNotPermissioned
    );
    let (expected_mint_config, _) = mint_config_pda(shares_mint);
    require!(
        *mint_config.key == expected_mint_config && *mint_config.owner == TOKEN_ACL_PROGRAM_ID,
        KaminoVaultError::MintConfigIncorrect
    );
    let config = MintConfig::unpack(&mint_config.data.borrow())
        .ok_or(KaminoVaultError::MintConfigIncorrect)?;
    require!(
        config.mint == *shares_mint && config.config_admin == vault.base_vault_authority,
        KaminoVaultError::MintConfigIncorrect
    );
    Ok(())
}

/// Requires a shares token account to be one whose owner can never change.
///
/// A permissioned vault gates *accounts*: they are born frozen and only become usable once the
/// gating program (or an administrator) thaws them. Token-2022 nonetheless lets the owner of an
/// ordinary token account hand it over with `SetAuthority(AccountOwner)`, so an approved holder
/// could have an account thawed and then transfer the still-thawed account to an address the
/// gate would have rejected. Canonical associated token accounts carry `ImmutableOwner`, which
/// makes that instruction fail; requiring the extension explicitly is what stops a hand-rolled
/// account being used as a transferable wrapper around the gate.
///
/// Note this covers the paths that run through MetaVault. Token ACL's own permissionless thaw
/// is enabled at vault creation and never touches this program, so the gating program has to
/// apply the same requirement for the guarantee to hold end to end.
pub fn require_immutable_owner(shares_account: &AccountInfo) -> anchor_lang::Result<()> {
    let data = shares_account.data.borrow();
    let account = StateWithExtensions::<spl_token_2022::state::Account>::unpack(&data)
        .map_err(|_| KaminoVaultError::SharesAccountOwnerMutable)?;
    require!(
        account.get_extension::<ImmutableOwner>().is_ok(),
        KaminoVaultError::SharesAccountOwnerMutable
    );
    Ok(())
}

/// On a permissioned vault, requires the shares account the instruction mints into or burns from
/// to be one [require_immutable_owner] accepts (a thawed account whose owner can still be
/// reassigned is a way around the gate).
pub fn require_immutable_owner_if_permissioned(
    vault: &MetavaultState,
    shares_account: &AccountInfo,
) -> anchor_lang::Result<()> {
    if vault.shares_permissioned() {
        require_immutable_owner(shares_account)?;
    }
    Ok(())
}

/// Accounts common to the token-acl CPIs signed by `base_vault_authority` (the mint's
/// freeze authority at create_config time, the config admin afterwards).
pub struct TokenAclCpiAccounts<'a, 'info> {
    pub token_acl_program: &'a AccountInfo<'info>,
    pub mint_config: &'a AccountInfo<'info>,
    pub shares_mint: &'a AccountInfo<'info>,
    pub base_vault_authority: &'a AccountInfo<'info>,
    pub vault_state_key: &'a Pubkey,
    pub base_vault_authority_bump: u8,
}

/// CPI `CreateConfig`: hands the mint's freeze authority to the MintConfig PDA and makes
/// `base_vault_authority` the config admin. Both permissionless toggles start disabled.
pub fn cpi_create_config<'info>(
    accounts: &TokenAclCpiAccounts<'_, 'info>,
    payer: &AccountInfo<'info>,
    system_program: &AccountInfo<'info>,
    shares_token_program: &AccountInfo<'info>,
    gating_program: &Pubkey,
) -> Result<()> {
    let mut data = vec![CREATE_CONFIG_DISCRIMINATOR];
    data.extend_from_slice(gating_program.as_ref());
    let ix = Instruction {
        program_id: TOKEN_ACL_PROGRAM_ID,
        accounts: vec![
            AccountMeta::new(*payer.key, true),
            AccountMeta::new_readonly(*accounts.base_vault_authority.key, true),
            AccountMeta::new(*accounts.shares_mint.key, false),
            AccountMeta::new(*accounts.mint_config.key, false),
            AccountMeta::new_readonly(*system_program.key, false),
            AccountMeta::new_readonly(*shares_token_program.key, false),
        ],
        data,
    };
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &ix,
        &[
            payer.clone(),
            accounts.base_vault_authority.clone(),
            accounts.shares_mint.clone(),
            accounts.mint_config.clone(),
            system_program.clone(),
            shares_token_program.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

/// CPI the permissioned `Thaw` (4) or `Freeze` (5) — config-admin-signed; these never
/// consult the gate program.
fn cpi_thaw_or_freeze<'info>(
    accounts: &TokenAclCpiAccounts<'_, 'info>,
    shares_token_program: &AccountInfo<'info>,
    token_account: &AccountInfo<'info>,
    discriminator: u8,
) -> Result<()> {
    let ix = Instruction {
        program_id: TOKEN_ACL_PROGRAM_ID,
        accounts: vec![
            AccountMeta::new_readonly(*accounts.base_vault_authority.key, true),
            AccountMeta::new_readonly(*accounts.shares_mint.key, false),
            AccountMeta::new(*token_account.key, false),
            AccountMeta::new_readonly(*accounts.mint_config.key, false),
            AccountMeta::new_readonly(*shares_token_program.key, false),
        ],
        data: vec![discriminator],
    };
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &ix,
        &[
            accounts.base_vault_authority.clone(),
            accounts.shares_mint.clone(),
            token_account.clone(),
            accounts.mint_config.clone(),
            shares_token_program.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

pub fn cpi_thaw<'info>(
    accounts: &TokenAclCpiAccounts<'_, 'info>,
    shares_token_program: &AccountInfo<'info>,
    token_account: &AccountInfo<'info>,
) -> Result<()> {
    cpi_thaw_or_freeze(
        accounts,
        shares_token_program,
        token_account,
        THAW_DISCRIMINATOR,
    )
}

pub fn cpi_freeze<'info>(
    accounts: &TokenAclCpiAccounts<'_, 'info>,
    shares_token_program: &AccountInfo<'info>,
    token_account: &AccountInfo<'info>,
) -> Result<()> {
    cpi_thaw_or_freeze(
        accounts,
        shares_token_program,
        token_account,
        FREEZE_DISCRIMINATOR,
    )
}

/// CPI `SetGatingProgram` (config-admin-signed).
pub fn cpi_set_gating_program(
    accounts: &TokenAclCpiAccounts<'_, '_>,
    new_gating_program: &Pubkey,
) -> Result<()> {
    let mut data = vec![SET_GATING_PROGRAM_DISCRIMINATOR];
    data.extend_from_slice(new_gating_program.as_ref());
    let ix = Instruction {
        program_id: TOKEN_ACL_PROGRAM_ID,
        accounts: vec![
            AccountMeta::new_readonly(*accounts.base_vault_authority.key, true),
            AccountMeta::new(*accounts.mint_config.key, false),
        ],
        data,
    };
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &ix,
        &[
            accounts.base_vault_authority.clone(),
            accounts.mint_config.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

/// CPI `DeleteConfig`: closes the MintConfig (rent to `receiver`) and hands the mint's
/// freeze authority back to `base_vault_authority`.
pub fn cpi_delete_config<'info>(
    accounts: &TokenAclCpiAccounts<'_, 'info>,
    shares_token_program: &AccountInfo<'info>,
    receiver: &AccountInfo<'info>,
) -> Result<()> {
    let mut data = vec![DELETE_CONFIG_DISCRIMINATOR];
    data.extend_from_slice(accounts.base_vault_authority.key.as_ref());
    let ix = Instruction {
        program_id: TOKEN_ACL_PROGRAM_ID,
        accounts: vec![
            AccountMeta::new_readonly(*accounts.base_vault_authority.key, true),
            AccountMeta::new(*receiver.key, false),
            AccountMeta::new(*accounts.shares_mint.key, false),
            AccountMeta::new(*accounts.mint_config.key, false),
            AccountMeta::new_readonly(*shares_token_program.key, false),
        ],
        data,
    };
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &ix,
        &[
            accounts.base_vault_authority.clone(),
            receiver.clone(),
            accounts.shares_mint.clone(),
            accounts.mint_config.clone(),
            shares_token_program.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

/// Flips the mint's `DefaultAccountState` — only possible while `base_vault_authority`
/// holds the freeze authority (before `create_config` / after `delete_config`).
pub fn cpi_update_default_account_state<'info>(
    accounts: &TokenAclCpiAccounts<'_, 'info>,
    shares_token_program: &AccountInfo<'info>,
    state: AccountState,
) -> Result<()> {
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &update_default_account_state(
            shares_token_program.key,
            accounts.shares_mint.key,
            accounts.base_vault_authority.key,
            &[],
            &state,
        )?,
        &[
            accounts.shares_mint.clone(),
            accounts.base_vault_authority.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

/// CPI `TogglePermissionlessInstructions` (payload `[freeze, thaw]`), config-admin-signed.
pub fn cpi_toggle_permissionless(
    accounts: &TokenAclCpiAccounts<'_, '_>,
    freeze_enabled: bool,
    thaw_enabled: bool,
) -> Result<()> {
    let ix = Instruction {
        program_id: TOKEN_ACL_PROGRAM_ID,
        accounts: vec![
            AccountMeta::new_readonly(*accounts.base_vault_authority.key, true),
            AccountMeta::new(*accounts.mint_config.key, false),
        ],
        data: vec![
            TOGGLE_PERMISSIONLESS_DISCRIMINATOR,
            u8::from(freeze_enabled),
            u8::from(thaw_enabled),
        ],
    };
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &ix,
        &[
            accounts.base_vault_authority.clone(),
            accounts.mint_config.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

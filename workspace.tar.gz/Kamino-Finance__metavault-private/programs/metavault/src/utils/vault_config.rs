use anchor_lang::prelude::*;

#[derive(Clone, Copy, Debug, AnchorSerialize, AnchorDeserialize)]
pub enum VaultConfigField {
    PerformanceFeeBps,
    ManagementFeeBps,
    PendingVaultAdmin,
    Name,
    LookupTable,
    Farm,
    VaultTokenScope,
    VaultTokenMaxTwapDivergenceBps,
    VaultTokenMaxAgePriceSeconds,
    VaultTokenMaxAgeTwapSeconds,
    VaultTokenMinDepositAmount,
    VaultTokenMinWithdrawAmount,
    VaultTokenDepositFeeBps,
    VaultTokenDepositFeeLamports,
    VaultTokenWithdrawFeeBps,
    VaultTokenWithdrawFeeLamports,
    TokenWeights,
    VaultTokenMaxDeviationBps,
    VaultTokenDutchAuctionBounds,
    /// Hard ceiling on the vault's net AUM (USD, `DollarValue::to_bits`). 16-byte u128 value.
    DepositCapUsd,
    /// Tumbling-window deposit cap. 24-byte value: `u128 max_usd_sf ++ u64 interval_seconds` (LE).
    /// Setting `interval_seconds == 0` disables the cap. Accumulator + window anchor are
    /// preserved across updates (klend-style).
    RollingDepositCap,
    /// Tumbling-window withdraw cap. Same encoding as [`Self::RollingDepositCap`].
    RollingWithdrawCap,
    EmergencyCouncil,
    EmergencyMode,
    BlockDeposits,
    BlockWithdraws,
    UnfreezeAuthority,
    SwapAuthority,
    /// What each fill of one of the vault's own rebalances may lose, in bps of its input value
    /// (`u64` LE): `0` for no loss at all, `FULL_BPS` for no limit. Read when a rebalance starts.
    MaxRebalanceSwapSlippageBps,
    AllocationAdminAuthority,
    /// Obligation LTV ceiling. 40-byte value: obligation `Pubkey` ++ `u64` bps (LE).
    /// `0` disables. Settable by the vault admin only. Newly added (or re-initialized)
    /// obligations start with the ceiling disabled; the admin must set it after every
    /// `init_obligation`.
    VaultObligationMaxUnhealthyLtvFractionBps,
    /// Minimum period between consecutive rebalance starts, in seconds (`u64` LE).
    /// `0` disables. Settable by the vault admin only.
    RebalanceCooldownSeconds,
    /// Per-token tolerance (bps of the scope price) for the price-basis gate. `0` requires a
    /// bit-exact match between klend's cached reserve price and the vault's scope price.
    VaultTokenMaxPriceDivergenceBps,
    /// Enables the krfq auction gate on `rebalance_swap`. 1-byte value: `1` = every fill
    /// must be co-signed by the krfq server key in `GlobalConfig::krfq_swap_authority`,
    /// `0` = gate off. Settable by the vault admin only.
    KrfqEnabled,
    /// What one of the vault's own rebalances may lose across *all* its fills, in bps of the
    /// rebalanced value (`u64` LE): `0` for no loss at all, `FULL_BPS` for no limit. Read when a
    /// rebalance starts. (Orders set their own.)
    MaxRebalanceLossBps,
    /// Enables `open_deposit_order` (1 byte).
    DepositOrderCreationEnabled,
    /// Enables fills against deposit orders, independently of the vault's own fills (1 byte).
    DepositOrderFillEnabled,
    /// Enables `settle_deposit_order` (1 byte).
    DepositOrderSettleEnabled,
    /// The lowest value a basket may have to open an order (of either kind), or `0` for no minimum
    /// (16 bytes: USD as `DollarValue::to_bits`).
    OrderMinOpenUsd,
    /// Enables `open_withdraw_order` (1 byte).
    WithdrawOrderCreationEnabled,
    /// Enables fills against withdraw orders, independently of the vault's own fills (1 byte).
    WithdrawOrderFillEnabled,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allocation_admin_field_is_appended() {
        assert_eq!(
            VaultConfigField::MaxRebalanceSwapSlippageBps
                .try_to_vec()
                .unwrap(),
            vec![28]
        );
        assert_eq!(
            VaultConfigField::AllocationAdminAuthority
                .try_to_vec()
                .unwrap(),
            vec![29]
        );
        assert_eq!(
            VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps
                .try_to_vec()
                .unwrap(),
            vec![30]
        );
        assert_eq!(
            VaultConfigField::RebalanceCooldownSeconds
                .try_to_vec()
                .unwrap(),
            vec![31]
        );
        assert_eq!(
            VaultConfigField::VaultTokenMaxPriceDivergenceBps
                .try_to_vec()
                .unwrap(),
            vec![32]
        );
    }

    #[test]
    fn krfq_enabled_field_is_appended() {
        assert_eq!(
            VaultConfigField::KrfqEnabled.try_to_vec().unwrap(),
            vec![33]
        );
    }

    #[test]
    fn order_fields_are_appended() {
        for (field, index) in [
            (VaultConfigField::DepositOrderCreationEnabled, 35),
            (VaultConfigField::DepositOrderFillEnabled, 36),
            (VaultConfigField::DepositOrderSettleEnabled, 37),
            (VaultConfigField::OrderMinOpenUsd, 38),
            (VaultConfigField::WithdrawOrderCreationEnabled, 39),
            (VaultConfigField::WithdrawOrderFillEnabled, 40),
        ] {
            assert_eq!(field.try_to_vec().unwrap(), vec![index]);
        }
    }
}

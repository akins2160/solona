use anchor_lang::prelude::{AccountInfo, CpiContext, Result};
use anchor_spl::token_interface::{self};

use super::consts::BASE_VAULT_AUTHORITY_SEED;
use crate::gen_signer_seeds;

pub mod shares {

    use anchor_lang::prelude::{Rent, SolanaSysvar};
    use anchor_lang::solana_program::program::invoke;
    use anchor_spl::token_2022::spl_token_2022;
    use kamino_lending::utils::accounts::create_pda_account;
    use spl_token_2022::{
        extension::ExtensionType,
        state::{AccountState, Mint},
    };

    use crate::types::ShareAmount;
    use crate::utils::consts::SHARES_SEEDS;

    use super::*;

    /// Creates the shares mint as a Token-2022 mint with the `DefaultAccountState` and
    /// `MetadataPointer` extensions. Anchor 0.29 `#[account(init)]` cannot initialize
    /// extensions, and neither can ever be added to an existing mint, so the full layout
    /// is fixed here at creation: `default_state` is `Initialized` for open vaults
    /// (accounts born thawed) and `Frozen` for permissioned ones, the metadata pointer is
    /// self-referential (the mint holds its own `TokenMetadata`), and
    /// `base_vault_authority` holds mint, freeze and metadata-pointer authority. On open
    /// vaults the parked freeze authority is what keeps them migration-ready.
    #[allow(clippy::too_many_arguments)]
    pub fn create_mint<'info>(
        payer: AccountInfo<'info>,
        shares_mint: AccountInfo<'info>,
        vault_state: AccountInfo<'info>,
        base_vault_authority: AccountInfo<'info>,
        shares_token_program: AccountInfo<'info>,
        system_program: AccountInfo<'info>,
        shares_mint_bump: u8,
        decimals: u8,
        default_state: AccountState,
    ) -> Result<()> {
        let space = ExtensionType::try_calculate_account_len::<Mint>(&[
            ExtensionType::DefaultAccountState,
            ExtensionType::MetadataPointer,
        ])?;
        let lamports = Rent::get()?.minimum_balance(space);

        // The mint is a PDA of this program and signs its own creation. Go through klend's
        // `create_pda_account` rather than a bare `create_account`: the address is derivable
        // from the (public) vault state key, and a bare `create_account` fails outright if
        // anyone pre-funds it with a single lamport. `create_pda_account` sweeps any
        // pre-existing balance back to the payer first.
        let signer_seeds: &[&[u8]] = &[SHARES_SEEDS, vault_state.key.as_ref(), &[shares_mint_bump]];
        create_pda_account(
            system_program,
            payer,
            shares_mint.clone(),
            shares_token_program.key,
            lamports,
            space as u64,
            &[signer_seeds],
        )?;

        // Extension initializations must precede initialize_mint2.
        invoke(
            &spl_token_2022::extension::default_account_state::instruction::initialize_default_account_state(
                shares_token_program.key,
                shares_mint.key,
                &default_state,
            )?,
            &[shares_mint.clone()],
        )?;
        invoke(
            &spl_token_2022::extension::metadata_pointer::instruction::initialize(
                shares_token_program.key,
                shares_mint.key,
                Some(*base_vault_authority.key),
                Some(*shares_mint.key),
            )?,
            &[shares_mint.clone()],
        )?;
        invoke(
            &spl_token_2022::instruction::initialize_mint2(
                shares_token_program.key,
                shares_mint.key,
                base_vault_authority.key,
                Some(base_vault_authority.key),
                decimals,
            )?,
            &[shares_mint],
        )?;

        Ok(())
    }

    pub fn mint<'info>(
        token_program: AccountInfo<'info>,
        shares_mint: AccountInfo<'info>,
        vault_state: AccountInfo<'info>,
        base_vault_authority: AccountInfo<'info>,
        user_shares_ata: AccountInfo<'info>,
        base_vault_authority_bump: u8,
        shares_to_mint: ShareAmount,
    ) -> Result<()> {
        let signer_seeds = gen_signer_seeds!(
            BASE_VAULT_AUTHORITY_SEED,
            vault_state.key.as_ref(),
            base_vault_authority_bump
        );

        if !shares_to_mint.is_zero() {
            token_interface::mint_to(
                CpiContext::new_with_signer(
                    token_program,
                    token_interface::MintTo {
                        mint: shares_mint,
                        to: user_shares_ata,
                        authority: base_vault_authority,
                    },
                    &[signer_seeds],
                ),
                shares_to_mint.into(),
            )?;
        }

        Ok(())
    }

    pub fn burn<'info>(
        shares_mint: AccountInfo<'info>,
        user_shares_ata: AccountInfo<'info>,
        user: AccountInfo<'info>,
        token_program: AccountInfo<'info>,
        shares_to_burn: ShareAmount,
    ) -> Result<()> {
        token_interface::burn(
            CpiContext::new(
                token_program,
                token_interface::Burn {
                    mint: shares_mint,
                    from: user_shares_ata,
                    authority: user,
                },
            ),
            shares_to_burn.into(),
        )?;

        Ok(())
    }
}

pub mod tokens {
    use crate::types::TokenAmount;

    use super::*;

    pub struct VaultTransferAccounts<'info> {
        pub token_program: AccountInfo<'info>,
        pub token_vault: AccountInfo<'info>,
        pub token_ata: AccountInfo<'info>,
        pub token_mint: AccountInfo<'info>,
        pub base_vault_authority: AccountInfo<'info>,
        pub vault_state: AccountInfo<'info>,
    }

    pub struct UserTransferAccounts<'info> {
        pub token_program: AccountInfo<'info>,
        pub token_vault: AccountInfo<'info>,
        pub token_ata: AccountInfo<'info>,
        pub token_mint: AccountInfo<'info>,
        pub user_authority: AccountInfo<'info>,
    }

    pub fn transfer_to_token_account(
        accounts: &VaultTransferAccounts,
        base_vault_authority_bump: u8,
        amount: TokenAmount,
        decimals: u8,
    ) -> Result<()> {
        let signer_seeds = gen_signer_seeds!(
            BASE_VAULT_AUTHORITY_SEED,
            accounts.vault_state.key.as_ref(),
            base_vault_authority_bump
        );

        if !amount.is_zero() {
            token_interface::transfer_checked(
                CpiContext::new_with_signer(
                    accounts.token_program.clone(),
                    token_interface::TransferChecked {
                        to: accounts.token_ata.clone(),
                        from: accounts.token_vault.clone(),
                        authority: accounts.base_vault_authority.clone(),
                        mint: accounts.token_mint.clone(),
                    },
                    &[signer_seeds],
                ),
                amount.into(),
                decimals,
            )?;
        }

        Ok(())
    }

    pub fn transfer_to_vault(
        accounts: &UserTransferAccounts,
        amount: TokenAmount,
        decimals: u8,
    ) -> Result<()> {
        if amount.is_zero() {
            // Mirrors `transfer_to_token_account`: a zero-amount transfer is a no-op, so skip
            // the CPI rather than spending compute on it.
            return Ok(());
        }
        token_interface::transfer_checked(
            CpiContext::new(
                accounts.token_program.clone(),
                token_interface::TransferChecked {
                    from: accounts.token_ata.clone(),
                    to: accounts.token_vault.clone(),
                    authority: accounts.user_authority.clone(),
                    mint: accounts.token_mint.clone(),
                },
            ),
            amount.into(),
            decimals,
        )
    }
}

/// Multi-step token movements, built out of the primitives above.
pub mod composites {
    use anchor_lang::prelude::ToAccountInfo;

    use super::tokens::{transfer_to_token_account, VaultTransferAccounts};
    use super::*;
    use crate::types::TokenAmount;
    use crate::utils::consts::MAX_TOKENS_PER_VAULT;
    use crate::utils::order_accounts::OrderTokenAccounts;

    /// Sends every token's `payouts` amount from the vault's TA to the owner's, for each of the
    /// order's `per_token` account sets.
    pub fn transfer_all_payouts<'info>(
        per_token: &[OrderTokenAccounts<'info>],
        payouts: &[TokenAmount; MAX_TOKENS_PER_VAULT],
        base_vault_authority_bump: u8,
        vault_state: &AccountInfo<'info>,
        base_vault_authority: &AccountInfo<'info>,
    ) -> Result<()> {
        for accounts in per_token {
            transfer_to_token_account(
                &VaultTransferAccounts {
                    token_program: accounts.token_program.to_account_info(),
                    token_vault: accounts.token_vault.to_account_info(),
                    token_ata: accounts.owner_ata.to_account_info(),
                    token_mint: accounts.mint.to_account_info(),
                    base_vault_authority: base_vault_authority.clone(),
                    vault_state: vault_state.clone(),
                },
                base_vault_authority_bump,
                payouts[accounts.id.storage_index],
                accounts.mint.decimals,
            )?;
        }
        Ok(())
    }
}

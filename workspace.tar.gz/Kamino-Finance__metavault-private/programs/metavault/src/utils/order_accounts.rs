use anchor_lang::prelude::*;
use anchor_spl::token_interface::{Mint, TokenAccount, TokenInterface};
use kamino_lending::utils::{
    accounts::has_ata_address, token_2022::check_only_supported_liquidity_token_extensions,
};

use crate::{
    operations::{order_basket::Order, vault_checks::check_vault_balance_covers_locked},
    state::{MetavaultState, VaultToken},
    types::{TokenAmount, VaultTokenId},
    utils::remaining_accounts::RemainingAccounts,
    KaminoVaultError,
};

/// One token's `[mint, token_vault, owner_ata, token_program]`, checked against the vault token and
/// the owner.
pub struct OrderTokenAccounts<'info> {
    /// The vault token these accounts are for.
    pub id: VaultTokenId,

    pub mint: InterfaceAccount<'info, Mint>,

    /// The vault's TA for the mint (where the order's tokens physically sit).
    pub token_vault: InterfaceAccount<'info, TokenAccount>,

    /// The owner's TA: the source of a deposit order's open, the destination of any payout (the
    /// associated one, when someone else than the owner sends the payout).
    pub owner_ata: InterfaceAccount<'info, TokenAccount>,

    pub token_program: Interface<'info, TokenInterface>,
}

impl<'info> OrderTokenAccounts<'info> {
    /// Deals the next four accounts off `remaining`, checking them against `token` and `owner`
    /// (whose associated account it must be, unless `by_owner`), and refusing a mint whose live
    /// transfer fee would short the transfer (in either direction).
    pub fn pinned(
        id: VaultTokenId,
        token: &VaultToken,
        owner: &Pubkey,
        by_owner: bool,
        remaining: &mut RemainingAccounts<'info>,
    ) -> Result<Self> {
        let mint = remaining
            .next_or(KaminoVaultError::OrderTokensNotCovered)?
            .check_key(&token.mint, "mint")?
            .as_interface_account::<Mint>()?;
        let token_vault = remaining
            .next_or(KaminoVaultError::OrderTokensNotCovered)?
            .check_key(&token.vault, "token vault")?
            .as_interface_account::<TokenAccount>()?;
        let owner_ata = remaining
            .next_or(KaminoVaultError::OrderTokensNotCovered)?
            .as_interface_account::<TokenAccount>()?;
        require_keys_eq!(
            owner_ata.owner,
            *owner,
            KaminoVaultError::OrderAccountMismatch
        );
        require_keys_eq!(
            owner_ata.mint,
            token.mint,
            KaminoVaultError::OrderAccountMismatch
        );
        require_keys_eq!(
            *owner_ata.to_account_info().owner,
            token.token_program,
            KaminoVaultError::OrderAccountMismatch
        );
        // Someone else's payout goes only where the owner surely looks:
        require!(
            by_owner || has_ata_address(&owner_ata, owner, &token.mint, &token.token_program),
            KaminoVaultError::PayoutNotToAssociatedAccount
        );
        let token_program = remaining
            .next_or(KaminoVaultError::OrderTokensNotCovered)?
            .check_key(&token.token_program, "token program")?
            .as_interface::<TokenInterface>()?;
        check_only_supported_liquidity_token_extensions(
            &mint.to_account_info(),
            &token_vault.to_account_info(),
        )?;
        Ok(Self {
            id,
            mint,
            token_vault,
            owner_ata,
            token_program,
        })
    }
}

/// The payout accounts of every token the order holds, `[mint, token_vault, owner_ata,
/// token_program]` per held token (in the vault's storage index order), dealt off
/// `remaining_accounts` the way [crate::utils::obligations::AumAccounts] deals off the vault's
/// obligation ones.
///
/// Only constructible by parsing, which proves the token count comes from the order's own locked
/// amounts and every account is checked against its vault token and the order's owner.
pub struct PayoutAccounts<'info> {
    /// One per token the order holds, in storage order.
    pub per_token: Vec<OrderTokenAccounts<'info>>,
}

impl<'info> PayoutAccounts<'info> {
    /// Deals each held token's accounts off `remaining` (see [OrderTokenAccounts::pinned]).
    pub fn parse<O: Order>(
        order: &O,
        vault: &MetavaultState,
        by_owner: bool,
        remaining: &mut RemainingAccounts<'info>,
    ) -> Result<Self> {
        let mut per_token = Vec::new();
        for (id, token) in vault.enumerate_enabled_tokens() {
            if order.base().locked_amount(id).is_zero() {
                continue;
            }
            per_token.push(OrderTokenAccounts::pinned(
                id,
                token,
                &order.base().owner,
                by_owner,
                remaining,
            )?);
        }
        Ok(Self { per_token })
    }

    /// The post-check of a payout: every TA paid from still covers the vault's own amount plus what
    /// the orders lock.
    pub fn check_vault_balances_cover_locked(&self, vault: &MetavaultState) -> Result<()> {
        for accounts in &self.per_token {
            check_vault_balance_covers_locked(
                TokenAmount::of_account(&accounts.token_vault.to_account_info())?,
                vault.get_vault_token_by_id(accounts.id),
            )?;
        }
        Ok(())
    }
}

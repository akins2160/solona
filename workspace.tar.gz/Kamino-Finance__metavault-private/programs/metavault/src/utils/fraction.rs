use crate::types::RoundingMethod;
use kamino_lending::fraction::{Fraction, FractionExtra};
use kamino_lending::utils::U256;

pub fn full_mul_fraction(
    fraction: Fraction,
    numerator: Fraction,
    denominator: Fraction,
    rounding: RoundingMethod,
) -> Fraction {
    full_mul_int(
        fraction,
        numerator.to_bits(),
        denominator.to_bits(),
        rounding,
    )
}

pub fn full_mul_int(
    fraction: Fraction,
    numerator: impl Into<U256>,
    denominator: impl Into<U256>,
    rounding: RoundingMethod,
) -> Fraction {
    match rounding {
        RoundingMethod::Floor => fraction.full_mul_int_ratio(numerator, denominator),
        RoundingMethod::Ceil => fraction.full_mul_int_ratio_ceil(numerator, denominator),
    }
}

/// Floor-rounded [`full_mul_fraction`] that reports overflow instead of aborting the program.
///
/// klend's `full_mul_int_ratio` narrows its `U256` accumulator back to the `u128` behind a
/// [`Fraction`] with an `.expect(..)`, so a product above `Fraction::MAX` (2^68, since
/// `Fraction` is U68F60) panics rather than returning. A panic gives no error code and no
/// actionable message, so anywhere the overflow is a reachable consequence of vault
/// configuration rather than a bug, use this and decide what the saturated case means.
pub fn try_full_mul_fraction_floor(
    fraction: Fraction,
    numerator: Fraction,
    denominator: Fraction,
) -> Option<Fraction> {
    let scaled = U256::from(fraction.to_bits()) * U256::from(numerator.to_bits())
        / U256::from(denominator.to_bits());
    u128::try_from(scaled).ok().map(Fraction::from_bits)
}

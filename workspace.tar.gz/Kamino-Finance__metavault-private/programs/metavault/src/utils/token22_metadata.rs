//! Token-2022-native shares metadata CPIs (`spl_token_metadata_interface`).
//!
//! The metadata lives inside the shares mint account itself: the `MetadataPointer`
//! extension is initialized self-referential at mint creation, and `base_vault_authority`
//! is both the mint authority (signs `Initialize`) and the metadata update authority
//! (signs `UpdateField`). `TokenMetadata` is variable-length, so every write first tops
//! up the mint's lamports to stay rent-exempt at the grown size — the token program
//! validates rent but never funds it. Shrinking updates leave the freed rent parked on
//! the mint (token-2022 has no lamport withdrawal for mints); the amounts are dust and
//! admin-paid, and later growth consumes them before topping up again.

use anchor_lang::{
    prelude::{AccountInfo, Pubkey, Rent, Result, SolanaSysvar},
    solana_program::{
        program::{invoke, invoke_signed},
        system_instruction,
    },
};
use anchor_spl::token_2022::spl_token_2022;
use spl_token_2022::extension::{BaseStateWithExtensions, StateWithExtensions};
use spl_token_metadata_interface::state::{Field, TokenMetadata};

use super::consts::BASE_VAULT_AUTHORITY_SEED;
use crate::gen_signer_seeds;

/// Ecosystem gate-discovery convention: permissioned mints advertise their token-acl
/// gating program under this metadata key.
pub const TOKEN_ACL_METADATA_KEY: &str = "token_acl";

pub struct SharesMetadataAccounts<'a, 'info> {
    pub shares_mint: &'a AccountInfo<'info>,
    pub base_vault_authority: &'a AccountInfo<'info>,
    pub shares_token_program: &'a AccountInfo<'info>,
    pub vault_state_key: Pubkey,
    pub base_vault_authority_bump: u8,
}

/// Transfers lamports from `payer` so the mint stays rent-exempt after growing by
/// `additional_bytes`.
fn fund_mint_rent<'info>(
    payer: &AccountInfo<'info>,
    shares_mint: &AccountInfo<'info>,
    system_program: &AccountInfo<'info>,
    additional_bytes: usize,
) -> Result<()> {
    let target_len = shares_mint.data_len() + additional_bytes;
    let required = Rent::get()?.minimum_balance(target_len);
    let current = shares_mint.lamports();
    if required > current {
        invoke(
            &system_instruction::transfer(payer.key, shares_mint.key, required - current),
            &[payer.clone(), shares_mint.clone(), system_program.clone()],
        )?;
    }
    Ok(())
}

/// Initializes the shares `TokenMetadata`; permissioned vaults additionally record the
/// gate under the [`TOKEN_ACL_METADATA_KEY`] key.
pub fn cpi_initialize<'info>(
    accounts: &SharesMetadataAccounts<'_, 'info>,
    payer: &AccountInfo<'info>,
    system_program: &AccountInfo<'info>,
    name: String,
    symbol: String,
    uri: String,
    token_acl_gate: Option<Pubkey>,
) -> Result<()> {
    // Fund the full final size up front (base metadata + the optional gate key entry).
    let mut final_metadata = TokenMetadata {
        update_authority: Some(*accounts.base_vault_authority.key).try_into()?,
        mint: *accounts.shares_mint.key,
        name: name.clone(),
        symbol: symbol.clone(),
        uri: uri.clone(),
        additional_metadata: vec![],
    };
    if let Some(gate) = token_acl_gate.as_ref() {
        final_metadata
            .additional_metadata
            .push((TOKEN_ACL_METADATA_KEY.to_string(), gate.to_string()));
    }
    // `tlv_size_of` sizes the entry with the interface's 12-byte TLV header (8-byte
    // discriminator + u32 length), but token-2022 stores mint extensions with a 4-byte
    // header (u16 type + u16 length), so the account grows 8 bytes less than that. The
    // constant header cancels out of the update path's size delta.
    const INTERFACE_VS_MINT_TLV_HEADER_DELTA: usize = 8;
    fund_mint_rent(
        payer,
        accounts.shares_mint,
        system_program,
        final_metadata
            .tlv_size_of()?
            .saturating_sub(INTERFACE_VS_MINT_TLV_HEADER_DELTA),
    )?;

    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &spl_token_metadata_interface::instruction::initialize(
            accounts.shares_token_program.key,
            accounts.shares_mint.key,
            accounts.base_vault_authority.key,
            accounts.shares_mint.key,
            accounts.base_vault_authority.key,
            name,
            symbol,
            uri,
        ),
        &[
            accounts.shares_mint.clone(),
            accounts.base_vault_authority.clone(),
        ],
        &[signer_seeds],
    )?;
    if let Some(gate) = token_acl_gate {
        cpi_update_field_inner(
            accounts,
            Field::Key(TOKEN_ACL_METADATA_KEY.to_string()),
            gate.to_string(),
        )?;
    }
    Ok(())
}

/// Applies the given field updates to the existing shares `TokenMetadata`, topping up
/// rent once for the net growth.
pub fn cpi_update_fields<'info>(
    accounts: &SharesMetadataAccounts<'_, 'info>,
    payer: &AccountInfo<'info>,
    system_program: &AccountInfo<'info>,
    updates: Vec<(Field, String)>,
) -> Result<()> {
    let (old_size, new_size) = {
        let mint_data = accounts.shares_mint.data.borrow();
        let mint_state = StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&mint_data)?;
        let mut metadata = mint_state.get_variable_len_extension::<TokenMetadata>()?;
        let old_size = metadata.tlv_size_of()?;
        for (field, value) in &updates {
            metadata.update(field.clone(), value.clone());
        }
        (old_size, metadata.tlv_size_of()?)
    };
    fund_mint_rent(
        payer,
        accounts.shares_mint,
        system_program,
        new_size.saturating_sub(old_size),
    )?;

    for (field, value) in updates {
        cpi_update_field_inner(accounts, field, value)?;
    }
    Ok(())
}

fn cpi_update_field_inner(
    accounts: &SharesMetadataAccounts<'_, '_>,
    field: Field,
    value: String,
) -> Result<()> {
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &spl_token_metadata_interface::instruction::update_field(
            accounts.shares_token_program.key,
            accounts.shares_mint.key,
            accounts.base_vault_authority.key,
            field,
            value,
        ),
        &[
            accounts.shares_mint.clone(),
            accounts.base_vault_authority.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

/// Removes a custom metadata key. `idempotent` lets administrative cleanup succeed
/// when metadata exists but the key was already removed by a prior migration.
pub fn cpi_remove_key(
    accounts: &SharesMetadataAccounts<'_, '_>,
    key: String,
    idempotent: bool,
) -> Result<()> {
    let signer_seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        accounts.vault_state_key.as_ref(),
        accounts.base_vault_authority_bump
    );
    invoke_signed(
        &spl_token_metadata_interface::instruction::remove_key(
            accounts.shares_token_program.key,
            accounts.shares_mint.key,
            accounts.base_vault_authority.key,
            key,
            idempotent,
        ),
        &[
            accounts.shares_mint.clone(),
            accounts.base_vault_authority.clone(),
        ],
        &[signer_seeds],
    )?;
    Ok(())
}

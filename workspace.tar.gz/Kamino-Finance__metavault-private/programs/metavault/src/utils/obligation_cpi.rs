//! The klend CPIs of the vault's obligation instructions. Metavault checks every account it
//! forwards against the reserve, obligation and market it loads itself; what klend then does with
//! them is up to the deployed klend program (not the crate version compiled in here), which the
//! post-CPI balance checks bound.

use anchor_lang::{
    prelude::*,
    solana_program::{
        instruction::{AccountMeta, Instruction},
        program::invoke_signed,
    },
    InstructionData, ToAccountInfos, ToAccountMetas,
};
use kamino_lending::{
    accounts as klend_accounts, instruction as klend_ix, InitObligationArgs, Obligation,
};

use crate::handlers::{
    BorrowObligationLiquidity, DepositObligationCollateral, InitObligation, InitVault,
    RepayObligationLiquidity, RequestElevationGroup, WithdrawObligationCollateral,
};
use crate::types::amounts::AllAvailableOr;
use crate::types::TokenAmount;
use crate::utils::consts::{BASE_VAULT_AUTHORITY_SEED, FARMS_PROGRAM_ID, FARMS_USER_STATE_SEED};
use crate::{gen_signer_seeds, KaminoVaultError};

pub const KLEND_OPTIONAL_FARM_ACCOUNTS_LEN: usize = 2;

fn target_farm_accounts_len(target_farm: Pubkey) -> usize {
    if target_farm == Pubkey::default() {
        0
    } else {
        KLEND_OPTIONAL_FARM_ACCOUNTS_LEN
    }
}

/// Counts the obligation's deposits that reference a real reserve (klend stores `Pubkey::default()`
/// in unused deposit slots).
pub fn active_deposit_reserves_count(obligation: &Obligation) -> usize {
    active_deposit_reserves(obligation).count()
}

pub fn active_deposit_reserves(obligation: &Obligation) -> impl Iterator<Item = Pubkey> + '_ {
    obligation
        .active_deposits()
        .map(|deposit| deposit.deposit_reserve)
}

pub fn active_borrow_reserves(obligation: &Obligation) -> impl Iterator<Item = Pubkey> + '_ {
    obligation
        .active_borrows()
        .map(|borrow| borrow.borrow_reserve)
}

/// The reserves forwarded to klend alongside an obligation are exactly the expected reserves of
/// its active positions, in the obligation's own order (the order klend walks them in).
pub fn check_forwarded_reserves(
    forwarded_reserves: &[AccountInfo],
    mut expected_reserves: impl Iterator<Item = Pubkey>,
) -> Result<()> {
    for forwarded_reserve in forwarded_reserves {
        let expected_reserve = expected_reserves
            .next()
            .ok_or_else(|| error!(KaminoVaultError::UnexpectedRemainingAccounts))?;
        require_keys_eq!(
            forwarded_reserve.key(),
            expected_reserve,
            KaminoVaultError::RemainingAccountKeyMismatch
        );
    }
    require!(
        expected_reserves.next().is_none(),
        KaminoVaultError::ObligationAccountMissing
    );
    Ok(())
}

pub fn split_trailing_target_farm_accounts<'info>(
    trailing_accounts: &'info [AccountInfo<'info>],
    leading_accounts_len: usize,
    target_farm: Pubkey,
    obligation: Pubkey,
) -> Result<(&'info [AccountInfo<'info>], &'info [AccountInfo<'info>])> {
    let farm_accounts_len = target_farm_accounts_len(target_farm);
    require_eq!(
        trailing_accounts.len(),
        leading_accounts_len + farm_accounts_len,
        KaminoVaultError::ObligationAccountMissing
    );
    let (leading_accounts, farm_accounts) = trailing_accounts.split_at(leading_accounts_len);
    check_target_farm_accounts(farm_accounts, target_farm, obligation)?;
    Ok((leading_accounts, farm_accounts))
}

pub fn split_optional_leading_accounts_and_target_farm_accounts<'info>(
    trailing_accounts: &'info [AccountInfo<'info>],
    optional_leading_accounts_len: usize,
    target_farm: Pubkey,
    obligation: Pubkey,
) -> Result<(&'info [AccountInfo<'info>], &'info [AccountInfo<'info>])> {
    let farm_accounts_len = target_farm_accounts_len(target_farm);
    let leading_accounts_len = match trailing_accounts.len() {
        len if len == farm_accounts_len => 0,
        len if len == optional_leading_accounts_len + farm_accounts_len => {
            optional_leading_accounts_len
        }
        _ => return err!(KaminoVaultError::ObligationAccountMissing),
    };
    let (leading_accounts, farm_accounts) = trailing_accounts.split_at(leading_accounts_len);
    check_target_farm_accounts(farm_accounts, target_farm, obligation)?;
    Ok((leading_accounts, farm_accounts))
}

/// The farm accounts klend takes for `target_farm`: the obligation's user state in that farm (the
/// farms program's PDA for the farm and this obligation), then the reserve's own farm state.
fn check_target_farm_accounts(
    farm_accounts: &[AccountInfo],
    target_farm: Pubkey,
    obligation: Pubkey,
) -> Result<()> {
    let [user_state, farm_state] = farm_accounts else {
        return Ok(()); // no farm on this side of the reserve (the length is checked by the caller)
    };
    require_keys_eq!(
        farm_state.key(),
        target_farm,
        KaminoVaultError::FarmAccountMismatch
    );
    let (expected_user_state, _) = Pubkey::find_program_address(
        &[
            FARMS_USER_STATE_SEED,
            target_farm.as_ref(),
            obligation.as_ref(),
        ],
        &FARMS_PROGRAM_ID,
    );
    require_keys_eq!(
        user_state.key(),
        expected_user_state,
        KaminoVaultError::FarmAccountMismatch
    );
    Ok(())
}

pub fn cpi_init_user_metadata(
    accounts: &InitVault,
    base_vault_authority_bump: u8,
    user_lookup_table: Pubkey,
) -> Result<()> {
    let metas = klend_accounts::InitUserMetadata {
        owner: accounts.base_vault_authority.key(),
        fee_payer: accounts.admin_authority.key(),
        user_metadata: accounts.user_metadata.key(),
        referrer_user_metadata: None,
        rent: accounts.rent.key(),
        system_program: accounts.system_program.key(),
    }
    .to_account_metas(None);
    invoke_klend(
        accounts.to_account_infos(),
        accounts.vault_state.key(),
        metas,
        &klend_ix::InitUserMetadata { user_lookup_table },
        base_vault_authority_bump,
    )
}

pub fn cpi_init_obligation(
    accounts: &InitObligation,
    base_vault_authority_bump: u8,
    args: InitObligationArgs,
) -> Result<()> {
    let metas = klend_accounts::InitObligation {
        obligation_owner: accounts.base_vault_authority.key(),
        fee_payer: accounts.vault_admin_authority.key(),
        obligation: accounts.obligation.key(),
        lending_market: accounts.lending_market.key(),
        seed1_account: accounts.seed1_account.key(),
        seed2_account: accounts.seed2_account.key(),
        owner_user_metadata: accounts.owner_user_metadata.key(),
        rent: accounts.rent.key(),
        system_program: accounts.system_program.key(),
    }
    .to_account_metas(None);
    invoke_klend(
        accounts.to_account_infos(),
        accounts.vault_state.key(),
        metas,
        &klend_ix::InitObligation { args },
        base_vault_authority_bump,
    )
}

pub fn cpi_deposit_reserve_liquidity_and_obligation_collateral<'info>(
    accounts: &DepositObligationCollateral<'info>,
    farm_accounts: &[AccountInfo<'info>],
    base_vault_authority_bump: u8,
    liquidity_amount: TokenAmount,
) -> Result<()> {
    let klend_accounts = klend_accounts::DepositReserveLiquidityAndObligationCollateralV2 {
        deposit_accounts: klend_accounts::DepositReserveLiquidityAndObligationCollateral {
            owner: accounts.base_vault_authority.key(),
            obligation: accounts.obligation.key(),
            lending_market: accounts.lending_market.key(),
            lending_market_authority: accounts.lending_market_authority.key(),
            reserve: accounts.reserve.key(),
            reserve_liquidity_mint: accounts.reserve_liquidity_mint.key(),
            reserve_liquidity_supply: accounts.reserve_liquidity_supply.key(),
            reserve_collateral_mint: accounts.reserve_collateral_mint.key(),
            reserve_destination_deposit_collateral: accounts
                .reserve_destination_deposit_collateral
                .key(),
            user_source_liquidity: accounts.token_vault.key(),
            placeholder_user_destination_collateral: None,
            collateral_token_program: accounts.collateral_token_program.key(),
            liquidity_token_program: accounts.liquidity_token_program.key(),
            instruction_sysvar_account: accounts.instruction_sysvar_account.key(),
        },
        farms_accounts: optional_obligation_farms_accounts(farm_accounts)?,
        farms_program: accounts.farms_program.key(),
    };
    let metas = klend_accounts.to_account_metas(None);
    let mut account_infos = accounts.to_account_infos();
    account_infos.extend(farm_accounts.iter().cloned());

    invoke_klend(
        account_infos,
        accounts.vault_state.key(),
        metas,
        &klend_ix::DepositReserveLiquidityAndObligationCollateralV2 {
            liquidity_amount: liquidity_amount.into(),
        },
        base_vault_authority_bump,
    )
}

pub fn cpi_withdraw_obligation_collateral_and_redeem_reserve_collateral<'info>(
    accounts: &WithdrawObligationCollateral<'info>,
    farm_accounts: &[AccountInfo<'info>],
    base_vault_authority_bump: u8,
    collateral_amount: AllAvailableOr<TokenAmount>,
) -> Result<()> {
    let klend_accounts = klend_accounts::WithdrawObligationCollateralAndRedeemReserveCollateralV2 {
        withdraw_accounts: klend_accounts::WithdrawObligationCollateralAndRedeemReserveCollateral {
            owner: accounts.base_vault_authority.key(),
            obligation: accounts.obligation.key(),
            lending_market: accounts.lending_market.key(),
            lending_market_authority: accounts.lending_market_authority.key(),
            withdraw_reserve: accounts.withdraw_reserve.key(),
            reserve_liquidity_mint: accounts.reserve_liquidity_mint.key(),
            reserve_source_collateral: accounts.reserve_source_collateral.key(),
            reserve_collateral_mint: accounts.reserve_collateral_mint.key(),
            reserve_liquidity_supply: accounts.reserve_liquidity_supply.key(),
            user_destination_liquidity: accounts.token_vault.key(),
            placeholder_user_destination_collateral: None,
            collateral_token_program: accounts.collateral_token_program.key(),
            liquidity_token_program: accounts.liquidity_token_program.key(),
            instruction_sysvar_account: accounts.instruction_sysvar_account.key(),
        },
        farms_accounts: optional_obligation_farms_accounts(farm_accounts)?,
        farms_program: accounts.farms_program.key(),
    };
    let metas = klend_accounts.to_account_metas(None);
    let mut account_infos = accounts.to_account_infos();
    account_infos.extend(farm_accounts.iter().cloned());

    invoke_klend(
        account_infos,
        accounts.vault_state.key(),
        metas,
        &klend_ix::WithdrawObligationCollateralAndRedeemReserveCollateralV2 {
            collateral_amount: collateral_amount.into(),
        },
        base_vault_authority_bump,
    )
}

pub fn cpi_borrow_obligation_liquidity<'info>(
    accounts: &BorrowObligationLiquidity<'info>,
    deposit_reserves: &[AccountInfo<'info>],
    farm_accounts: &[AccountInfo<'info>],
    base_vault_authority_bump: u8,
    liquidity_amount: TokenAmount,
) -> Result<()> {
    // Klend's elevation-group debt-tracker update iterates the obligation's active deposits and
    // requires one matching mutable deposit reserve per active deposit in remaining_accounts (same
    // order). Outside elevation groups the iterator is unused.
    let borrow_accounts = klend_accounts::BorrowObligationLiquidityV2 {
        borrow_accounts: klend_accounts::BorrowObligationLiquidity {
            owner: accounts.base_vault_authority.key(),
            obligation: accounts.obligation.key(),
            lending_market: accounts.lending_market.key(),
            lending_market_authority: accounts.lending_market_authority.key(),
            borrow_reserve: accounts.borrow_reserve.key(),
            borrow_reserve_liquidity_mint: accounts.borrow_reserve_liquidity_mint.key(),
            reserve_source_liquidity: accounts.reserve_source_liquidity.key(),
            borrow_reserve_liquidity_fee_receiver: accounts
                .borrow_reserve_liquidity_fee_receiver
                .key(),
            user_destination_liquidity: accounts.token_vault.key(),
            referrer_token_state: None,
            token_program: accounts.token_program.key(),
            instruction_sysvar_account: accounts.instruction_sysvar_account.key(),
        },
        farms_accounts: optional_obligation_farms_accounts(farm_accounts)?,
        farms_program: accounts.farms_program.key(),
    };
    let mut metas = borrow_accounts.to_account_metas(None);
    let mut account_infos = accounts.to_account_infos();
    account_infos.extend(farm_accounts.iter().cloned());
    for reserve in deposit_reserves {
        metas.push(AccountMeta::new(reserve.key(), false));
        account_infos.push(reserve.clone());
    }
    invoke_klend(
        account_infos,
        accounts.vault_state.key(),
        metas,
        &klend_ix::BorrowObligationLiquidityV2 {
            liquidity_amount: liquidity_amount.into(),
        },
        base_vault_authority_bump,
    )
}

pub fn cpi_repay_obligation_liquidity<'info>(
    accounts: &RepayObligationLiquidity<'info>,
    deposit_reserves: &[AccountInfo<'info>],
    farm_accounts: &[AccountInfo<'info>],
    base_vault_authority_bump: u8,
    liquidity_amount: TokenAmount,
) -> Result<()> {
    // Klend's elevation-group debt-tracker update iterates the obligation's active deposits and
    // requires one matching mutable deposit reserve per active deposit in remaining_accounts (same
    // order). Outside elevation groups the iterator is unused.
    let repay_accounts = klend_accounts::RepayObligationLiquidityV2 {
        repay_accounts: klend_accounts::RepayObligationLiquidity {
            owner: accounts.base_vault_authority.key(),
            obligation: accounts.obligation.key(),
            lending_market: accounts.lending_market.key(),
            repay_reserve: accounts.repay_reserve.key(),
            reserve_liquidity_mint: accounts.reserve_liquidity_mint.key(),
            reserve_destination_liquidity: accounts.reserve_destination_liquidity.key(),
            user_source_liquidity: accounts.token_vault.key(),
            token_program: accounts.token_program.key(),
            instruction_sysvar_account: accounts.instruction_sysvar_account.key(),
        },
        farms_accounts: optional_obligation_farms_accounts(farm_accounts)?,
        lending_market_authority: accounts.lending_market_authority.key(),
        farms_program: accounts.farms_program.key(),
    };
    let mut metas = repay_accounts.to_account_metas(None);
    let mut account_infos = accounts.to_account_infos();
    account_infos.extend(farm_accounts.iter().cloned());
    for reserve in deposit_reserves {
        metas.push(AccountMeta::new(reserve.key(), false));
        account_infos.push(reserve.clone());
    }
    invoke_klend(
        account_infos,
        accounts.vault_state.key(),
        metas,
        &klend_ix::RepayObligationLiquidityV2 {
            liquidity_amount: liquidity_amount.into(),
        },
        base_vault_authority_bump,
    )
}

pub fn cpi_request_elevation_group<'info>(
    accounts: &RequestElevationGroup<'info>,
    klend_remaining: &[AccountInfo<'info>],
    base_vault_authority_bump: u8,
    new_elevation_group: u8,
) -> Result<()> {
    // Klend expects `[deposit_reserves...][borrow_reserves...][referrer_token_states...]` in
    // remaining_accounts. Metavault never sets a referrer, so the trailing segment is empty.
    let request_accounts = klend_accounts::RequestElevationGroup {
        owner: accounts.base_vault_authority.key(),
        obligation: accounts.obligation.key(),
        lending_market: accounts.lending_market.key(),
    };
    let mut metas = request_accounts.to_account_metas(None);
    let mut account_infos = accounts.to_account_infos();
    for reserve in klend_remaining {
        metas.push(AccountMeta::new(reserve.key(), false));
        account_infos.push(reserve.clone());
    }
    invoke_klend(
        account_infos,
        accounts.vault_state.key(),
        metas,
        &klend_ix::RequestElevationGroup {
            elevation_group: new_elevation_group,
        },
        base_vault_authority_bump,
    )
}

fn optional_obligation_farms_accounts(
    farm_accounts: &[AccountInfo],
) -> Result<klend_accounts::OptionalObligationFarmsAccounts> {
    match farm_accounts.len() {
        0 => Ok(klend_accounts::OptionalObligationFarmsAccounts {
            obligation_farm_user_state: None,
            reserve_farm_state: None,
        }),
        KLEND_OPTIONAL_FARM_ACCOUNTS_LEN => Ok(klend_accounts::OptionalObligationFarmsAccounts {
            obligation_farm_user_state: Some(farm_accounts[0].key()),
            reserve_farm_state: Some(farm_accounts[1].key()),
        }),
        _ => err!(KaminoVaultError::ObligationAccountMissing),
    }
}

/// Invoke a klend CPI signed by `base_vault_authority` derived from `vault_state_key`.
fn invoke_klend(
    account_infos: Vec<AccountInfo<'_>>,
    vault_state_key: Pubkey,
    metas: Vec<AccountMeta>,
    data: &impl InstructionData,
    base_vault_authority_bump: u8,
) -> Result<()> {
    let seeds = gen_signer_seeds!(
        BASE_VAULT_AUTHORITY_SEED,
        vault_state_key.as_ref(),
        base_vault_authority_bump
    );
    invoke_signed(
        &Instruction {
            program_id: kamino_lending::ID,
            accounts: metas,
            data: data.data(),
        },
        &account_infos,
        &[seeds],
    )?;
    Ok(())
}

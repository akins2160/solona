use anchor_lang::{
    prelude::*,
    solana_program::{
        instruction::{get_stack_height, Instruction, TRANSACTION_LEVEL_STACK_HEIGHT},
        sysvar::instructions::{load_current_index_checked, load_instruction_at_checked},
    },
};

use crate::KaminoVaultError;

pub trait InstructionLoader {
    fn load_instruction_at(&self, index: usize) -> std::result::Result<Instruction, ProgramError>;

    fn load_current_index(&self) -> std::result::Result<u16, ProgramError>;

    fn stack_height(&self) -> usize;

    fn is_forbidden_cpi_call(&self) -> Result<bool> {
        let current_index = self.load_current_index()? as usize;
        let current_ix = self.load_instruction_at(current_index)?;

        if current_ix.program_id != crate::ID {
            return Ok(true);
        }

        Ok(self.stack_height() > TRANSACTION_LEVEL_STACK_HEIGHT)
    }
}

pub fn check_cpi_call(instruction_sysvar_account_info: &AccountInfo) -> Result<()> {
    check_cpi_call_with_loader(&BpfInstructionLoader::new(instruction_sysvar_account_info))
}

pub fn check_cpi_call_with_loader(ix_loader: &impl InstructionLoader) -> Result<()> {
    if ix_loader.is_forbidden_cpi_call()? {
        msg!("Instruction was called via CPI");
        return err!(KaminoVaultError::CpiDisabled);
    }

    Ok(())
}

pub struct BpfInstructionLoader<'a, 'info> {
    pub instruction_sysvar_account_info: &'a AccountInfo<'info>,
}

impl BpfInstructionLoader<'_, '_> {
    pub fn new<'a, 'info>(
        instruction_sysvar_account_info: &'a AccountInfo<'info>,
    ) -> BpfInstructionLoader<'a, 'info> {
        BpfInstructionLoader {
            instruction_sysvar_account_info,
        }
    }
}

impl InstructionLoader for BpfInstructionLoader<'_, '_> {
    fn load_instruction_at(&self, index: usize) -> std::result::Result<Instruction, ProgramError> {
        load_instruction_at_checked(index, self.instruction_sysvar_account_info)
    }

    fn load_current_index(&self) -> std::result::Result<u16, ProgramError> {
        load_current_index_checked(self.instruction_sysvar_account_info)
    }

    fn stack_height(&self) -> usize {
        get_stack_height()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct MockInstructionLoader {
        current_index: u16,
        instructions: Vec<Instruction>,
        stack_height: usize,
    }

    impl MockInstructionLoader {
        fn new(program_id: Pubkey, stack_height: usize) -> Self {
            Self {
                current_index: 0,
                instructions: vec![Instruction {
                    program_id,
                    accounts: vec![],
                    data: vec![],
                }],
                stack_height,
            }
        }
    }

    impl InstructionLoader for MockInstructionLoader {
        fn load_instruction_at(
            &self,
            index: usize,
        ) -> std::result::Result<Instruction, ProgramError> {
            self.instructions
                .get(index)
                .cloned()
                .ok_or(ProgramError::InvalidInstructionData)
        }

        fn load_current_index(&self) -> std::result::Result<u16, ProgramError> {
            Ok(self.current_index)
        }

        fn stack_height(&self) -> usize {
            self.stack_height
        }
    }

    #[test]
    fn allows_top_level_metavault_instruction() {
        let loader = MockInstructionLoader::new(crate::ID, TRANSACTION_LEVEL_STACK_HEIGHT);

        assert!(check_cpi_call_with_loader(&loader).is_ok());
    }

    #[test]
    fn rejects_other_top_level_program() {
        let loader =
            MockInstructionLoader::new(Pubkey::new_unique(), TRANSACTION_LEVEL_STACK_HEIGHT);

        assert_eq!(
            check_cpi_call_with_loader(&loader),
            err!(KaminoVaultError::CpiDisabled)
        );
    }

    #[test]
    fn rejects_same_program_inner_cpi() {
        let loader = MockInstructionLoader::new(crate::ID, TRANSACTION_LEVEL_STACK_HEIGHT + 1);

        assert_eq!(
            check_cpi_call_with_loader(&loader),
            err!(KaminoVaultError::CpiDisabled)
        );
    }

    #[test]
    fn rejects_cpi_from_other_program() {
        let loader =
            MockInstructionLoader::new(Pubkey::new_unique(), TRANSACTION_LEVEL_STACK_HEIGHT + 1);

        assert_eq!(
            check_cpi_call_with_loader(&loader),
            err!(KaminoVaultError::CpiDisabled)
        );
    }

    #[test]
    fn propagates_instruction_sysvar_load_errors() {
        let loader = MockInstructionLoader {
            current_index: 1,
            instructions: vec![Instruction {
                program_id: crate::ID,
                accounts: vec![],
                data: vec![],
            }],
            stack_height: TRANSACTION_LEVEL_STACK_HEIGHT,
        };

        let err = check_cpi_call_with_loader(&loader).unwrap_err();
        assert!(matches!(
            err,
            anchor_lang::error::Error::ProgramError(program_error)
                if program_error.program_error == ProgramError::InvalidInstructionData
        ));
    }
}

use std::{
    fmt::{Debug, Display},
    marker::PhantomData,
    slice::SliceIndex,
};

use anchor_lang::prelude::*;
use borsh::BorshDeserialize;

use crate::KaminoVaultError;

pub struct ConfigItemUpdater<'h, H, T, S, G, V, R> {
    target: &'h mut H,
    name: String,
    setter: S,
    getter: G,
    validator: V,
    renderer: R,
    value_type_phantom: PhantomData<T>,
}

/// The `range` bytes of a config payload (a payload too short for its field is an error, not a
/// panic).
pub fn value_bytes<R: SliceIndex<[u8], Output = [u8]>>(value: &[u8], range: R) -> Result<&[u8]> {
    value
        .get(range)
        .ok_or_else(|| error!(KaminoVaultError::ConfigValueTooShort))
}

#[must_use]
pub fn for_field<T: Debug>(
    field: &mut T,
) -> ConfigItemUpdater<
    T,
    T,
    impl Setter<T, T>,
    impl Getter<T, T>,
    impl Validator<T>,
    impl Renderer<T>,
> {
    for_object(field).using_setter_and_getter(set_field_directly, get_field_directly)
}

macro_rules! for_named_field {
    ($expr:expr) => {
        $crate::utils::config_items::for_field($expr).named(stringify!($expr))
    };
}
pub(crate) use for_named_field;

#[must_use]
pub fn for_object<H>(target: &mut H) -> ConfigItemUpdater<H, (), (), (), (), ()> {
    ConfigItemUpdater {
        target,
        name: "<unnamed>".to_string(),
        getter: (),
        setter: (),
        validator: (),
        renderer: (),
        value_type_phantom: PhantomData,
    }
}

impl<'h, H, T, S: Setter<H, T>, G: Getter<H, T>, V: Validator<T>, R: Renderer<T>>
    ConfigItemUpdater<'h, H, T, S, G, V, R>
{
    #[must_use]
    pub fn named(mut self, name: impl Into<String>) -> Self {
        self.name = name.into();
        self
    }

    #[must_use]
    pub fn validating<NV: Validator<T>>(self, new: NV) -> ConfigItemUpdater<'h, H, T, S, G, NV, R> {
        let Self {
            target,
            name,
            value_type_phantom,
            getter,
            setter,
            validator: _replaced,
            renderer,
        } = self;
        ConfigItemUpdater {
            target,
            name,
            value_type_phantom,
            getter,
            setter,
            validator: new,
            renderer,
        }
    }

    pub fn set(self, source: &[u8]) -> Result<()>
    where
        T: BorshDeserialize,
    {
        let new_value = T::deserialize(&mut &source[..])?;
        let ConfigItemUpdater {
            target,
            name,
            getter,
            setter,
            validator,
            renderer,
            ..
        } = self;
        validator(&new_value)?;
        let prv = getter(target, &new_value);
        msg!("Prv value: {} = {}", name, RenderedOption(&renderer, prv));
        msg!("New value: {} = {}", name, Rendered(&renderer, &new_value));
        setter(target, new_value)?;
        Ok(())
    }
}

impl<'h, H> ConfigItemUpdater<'h, H, (), (), (), (), ()> {
    #[must_use]
    pub fn using_setter_and_getter<T: Debug, S: Setter<H, T>, G: Getter<H, T>>(
        self,
        setter: S,
        getter: G,
    ) -> ConfigItemUpdater<'h, H, T, S, G, impl Validator<T>, impl Renderer<T>> {
        ConfigItemUpdater {
            target: self.target,
            name: self.name,
            getter,
            setter,
            validator: accept_anything,
            renderer: write_debug,
            value_type_phantom: PhantomData,
        }
    }
}

pub trait Setter<H, T>: for<'a> Fn(&'a mut H, T) -> Result<()> {}
impl<F: for<'a> Fn(&'a mut H, T) -> Result<()>, H, T> Setter<H, T> for F {}

pub trait Getter<H, T>: for<'a> Fn(&'a H, &T) -> Result<Option<&'a T>> {}
impl<F: for<'a> Fn(&'a H, &T) -> Result<Option<&'a T>>, H, T> Getter<H, T> for F {}

pub trait Validator<T>: for<'a> Fn(&'a T) -> Result<()> {}
impl<F: for<'a> Fn(&'a T) -> Result<()>, T> Validator<T> for F {}

pub trait Renderer<T>:
    for<'a, 'b> Fn(&'a T, &mut std::fmt::Formatter<'b>) -> std::fmt::Result
{
}
impl<F: for<'a, 'b> Fn(&'a T, &mut std::fmt::Formatter<'b>) -> std::fmt::Result, T> Renderer<T>
    for F
{
}

struct Rendered<'a, R, T>(&'a R, &'a T);

impl<'a, R: Renderer<T>, T> Display for Rendered<'a, R, T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let &Rendered(renderer, value) = self;
        renderer(value, f)
    }
}

struct RenderedOption<'a, R, T>(&'a R, Result<Option<&'a T>>);

impl<'a, R: Renderer<T>, T> Display for RenderedOption<'a, R, T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let RenderedOption(renderer, value) = self;
        match value {
            Ok(Some(value)) => renderer(*value, f),
            Ok(None) => f.write_str("<not present>"),
            Err(error) => write!(f, "<unavailable: {:?}>", error),
        }
    }
}

fn accept_anything<T>(_value: &T) -> Result<()> {
    Ok(())
}

fn write_debug<T: Debug>(value: &T, f: &mut std::fmt::Formatter) -> std::fmt::Result {
    value.fmt(f)
}

fn set_field_directly<T>(field: &mut T, new_value: T) -> Result<()> {
    *field = new_value;
    Ok(())
}

fn get_field_directly<'t, T>(field: &'t T, _irrelevant_new_value: &T) -> Result<Option<&'t T>> {
    Ok(Some(field))
}

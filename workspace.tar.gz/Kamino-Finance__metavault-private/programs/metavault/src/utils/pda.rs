use anchor_lang::prelude::Pubkey;
use kamino_lending::utils::seeds::BASE_SEED_USER_METADATA;

use crate::utils::consts::{
    DEPOSIT_ORDER_SEED, GLOBAL_CONFIG_STATE_SEEDS, KRFQ_FILL_MARKER_SEED, VAULT_OBLIGATION_TAG,
    WITHDRAW_ORDER_SEED,
};

pub fn program_data() -> Pubkey {
    program_data_program_id(&crate::ID)
}

pub fn program_data_program_id(program_id: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[program_id.as_ref()],
        &solana_program::bpf_loader_upgradeable::ID,
    )
    .0
}

pub fn global_config() -> Pubkey {
    global_config_program_id(&crate::ID)
}

pub fn global_config_program_id(program_id: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[GLOBAL_CONFIG_STATE_SEEDS], program_id).0
}

/// Marker address for one krfq-gated `rebalance_swap`: this vault, paying
/// `token_in_mint` and receiving `token_out_mint`. The mint pair is ordered, so a
/// fill in the opposite direction is a different marker.
///
/// The single derivation shared by the program's own check, the bot, the CLI and
/// krfq — a second copy of these seeds anywhere is a way for the two sides to
/// disagree about which fill a co-signature covers.
pub fn krfq_fill_marker(
    vault_state: &Pubkey,
    token_in_mint: &Pubkey,
    token_out_mint: &Pubkey,
) -> Pubkey {
    krfq_fill_marker_program_id(vault_state, token_in_mint, token_out_mint, &crate::ID)
}

pub fn krfq_fill_marker_program_id(
    vault_state: &Pubkey,
    token_in_mint: &Pubkey,
    token_out_mint: &Pubkey,
    program_id: &Pubkey,
) -> Pubkey {
    Pubkey::find_program_address(
        &[
            KRFQ_FILL_MARKER_SEED,
            vault_state.as_ref(),
            token_in_mint.as_ref(),
            token_out_mint.as_ref(),
        ],
        program_id,
    )
    .0
}

/// A deposit order's address: this vault, this owner, this id.
pub fn deposit_order(vault_state: &Pubkey, owner: &Pubkey, id: u8) -> Pubkey {
    deposit_order_program_id(vault_state, owner, id, &crate::ID)
}

pub fn deposit_order_program_id(
    vault_state: &Pubkey,
    owner: &Pubkey,
    id: u8,
    program_id: &Pubkey,
) -> Pubkey {
    Pubkey::find_program_address(
        &[
            DEPOSIT_ORDER_SEED,
            vault_state.as_ref(),
            owner.as_ref(),
            &[id],
        ],
        program_id,
    )
    .0
}

pub fn withdraw_order(vault_state: &Pubkey, owner: &Pubkey, id: u8) -> Pubkey {
    withdraw_order_program_id(vault_state, owner, id, &crate::ID)
}

pub fn withdraw_order_program_id(
    vault_state: &Pubkey,
    owner: &Pubkey,
    id: u8,
    program_id: &Pubkey,
) -> Pubkey {
    Pubkey::find_program_address(
        &[
            WITHDRAW_ORDER_SEED,
            vault_state.as_ref(),
            owner.as_ref(),
            &[id],
        ],
        program_id,
    )
    .0
}

pub fn vault_user_metadata(base_vault_authority: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[BASE_SEED_USER_METADATA, base_vault_authority.as_ref()],
        &kamino_lending::ID,
    )
    .0
}

/// The vault's klend obligation in `lending_market` at storage slot `id`.
pub fn vault_obligation(lending_market: &Pubkey, base_vault_authority: &Pubkey, id: u8) -> Pubkey {
    Pubkey::find_program_address(
        &[
            &[VAULT_OBLIGATION_TAG],
            &[id],
            base_vault_authority.as_ref(),
            lending_market.as_ref(),
            Pubkey::default().as_ref(),
            Pubkey::default().as_ref(),
        ],
        &kamino_lending::ID,
    )
    .0
}

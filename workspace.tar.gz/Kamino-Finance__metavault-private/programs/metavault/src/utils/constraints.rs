use anchor_lang::prelude::*;

use crate::{KaminoVaultError, MetavaultState};

/// Fails with [`KaminoVaultError::VaultEmergencyMode`] when the vault is in
/// emergency mode.
///
/// Mirrors klend's `utils::constraints::emergency_mode_disabled`. Applied via
/// `#[access_control(...)]` to every fund- or state-moving instruction so the
/// emergency council's `emergency_mode` flag freezes them uniformly.
///
/// Exits included: while the flag is set, no holder can withdraw or sell and no order owner can
/// cancel or settle (a deliberate full stop; the council lifting the flag is the only way out).
pub fn emergency_mode_disabled(vault_state: &AccountLoader<MetavaultState>) -> Result<()> {
    require!(
        vault_state.load()?.emergency_mode == 0,
        KaminoVaultError::VaultEmergencyMode
    );
    Ok(())
}

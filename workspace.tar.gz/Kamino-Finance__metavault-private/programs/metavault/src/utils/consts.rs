use anchor_lang::prelude::Pubkey;

use crate::types::ratio::Ratio;
use crate::types::{Duration, TokenAmount};

pub const TOKEN_VAULT_SEED: &[u8; 11] = b"token_vault";
pub const SHARES_SEEDS: &[u8; 6] = b"shares";
pub const EVENT_AUTHORITY: &[u8] = b"__event_authority";
pub const GLOBAL_CONFIG_STATE_SEEDS: &[u8] = b"global_config";
pub const BASE_VAULT_AUTHORITY_SEED: &[u8; 9] = b"authority";
/// Seed of the marker account that encodes a krfq-gated fill's identity — the
/// vault plus the ordered mint pair — into a single address. krfq derives it from
/// the opportunity it ranked and requires it in the fill, which is how one gate
/// co-signature authorizes exactly that fill without krfq having to resolve and
/// inspect the instruction's own accounts.
pub const KRFQ_FILL_MARKER_SEED: &[u8] = b"krfq_fill";
pub const DEPOSIT_ORDER_SEED: &[u8] = b"deposit_order";
pub const WITHDRAW_ORDER_SEED: &[u8] = b"withdraw_order";

/// Positions of `rebalance_swap`'s four optional accounts in the instruction's account list: the
/// two krfq ones, and the deposit or withdraw order it fills instead of the vault.
///
/// A client targeting any deployment other than `declare_id!` overwrites these metas with the id it
/// calls (Anchor 0.29 encodes an absent optional account as the crate's compile-time id), and krfq
/// reads the marker at [`KRFQ_FILL_MARKER_ACCOUNT_INDEX`] straight from the message's inline keys.
// (Beside the seeds, so the program, the CLI, the bot and the auction server share them: a stale
// index silently overwrites a different account; a test pins them against the generated metas.)
pub const KRFQ_AUTHORITY_ACCOUNT_INDEX: usize = 12;
pub const KRFQ_FILL_MARKER_ACCOUNT_INDEX: usize = 14;
pub const DEPOSIT_ORDER_ACCOUNT_INDEX: usize = 15;
pub const WITHDRAW_ORDER_ACCOUNT_INDEX: usize = 16;

pub const VAULT_STATE_SIZE: usize = 31600;
pub const VAULT_TOKEN_STATE_SIZE: usize = 2304;
pub const VAULT_OBLIGATION_STATE_SIZE: usize = 128;
pub const GLOBAL_CONFIG_SIZE: usize = 1024;
pub const DEPOSIT_ORDER_SIZE: usize = 480;
pub const WITHDRAW_ORDER_SIZE: usize = 608;

// Sensible default for proportional deposit/withdraw; not a CU/memory constraint
pub const MAX_TOKENS_PER_VAULT: usize = 10;
pub const MAX_OBLIGATIONS_PER_VAULT: usize = 3;
/// Max value for management fee that a vault manager can set
pub const MAX_MGMT_FEE: Ratio<u64> = Ratio::from_bps(1000);
/// Max value for performance fee that a vault manager can set
pub const MAX_PERF_FEE: Ratio<u64> = Ratio::from_bps(5000);

pub const YEAR: Duration = Duration::from_secs(31556925);
pub const MIN_REBALANCE_DURATION: Duration = Duration::from_secs(600); // 10 minutes
pub const MAX_REBALANCE_DURATION: Duration = Duration::from_secs(604800); // 7 days
/// Upper bound on the interval length of a [crate::RollingCap]. Long intervals with small caps
/// effectively become permanent ceilings — keeping this short keeps the rate-limiter honest.
pub const MAX_ROLLING_CAP_INTERVAL_SECONDS: Duration = MAX_REBALANCE_DURATION;
/// Upper bound on the minimum period between consecutive rebalance starts.
pub const MAX_REBALANCE_COOLDOWN: Duration = Duration::from_secs(30 * 24 * 60 * 60); // 30 days

pub const MAX_MIN_WITHDRAW_AMOUNT: TokenAmount = TokenAmount::new(1000); // for the most expensive lamport (cbBTC) this can go up to 1$
pub const MAX_MIN_DEPOSIT_AMOUNT: TokenAmount = TokenAmount::new(1000); // same rationale as MAX_MIN_WITHDRAW_AMOUNT

/// The number to be used to for initial deposit [TokenAmount] and initial minted [ShareAmount].
///
/// Those shares are counted in `shares_issued` but never minted as tokens, so they stay dead and
/// any donation into the share price is spread over at least them. The only such donation is
/// repaying the vault's klend debt (tokens sent to a token vault are not counted: the vault keeps
/// its own balances).
pub const INITIAL_DEPOSIT_SIZE: u64 = 1000;

/// Max effective fee rate that can be charged in a single vault fee cycle (50%)
pub const MAX_CHARGED_RATE_FOR_VAULT_FEE: Ratio<u64> = Ratio::from_bps(5000);

pub const PERF_FEE_COOLDOWN_SECONDS: Duration = Duration::from_secs(86400); // 24 hours
/// A token within this much of its rebalance target counts as settled, and is refused as either
/// side of a fill.
pub const REBALANCE_SETTLED_TOLERANCE_LAMPORTS: TokenAmount =
    TokenAmount::new(REBALANCE_SETTLED_TOLERANCE);
const REBALANCE_SETTLED_TOLERANCE: u64 = 1_000;

/// Max deposit/withdraw fee rate (10%)
pub const MAX_FEE_RATE: Ratio<u64> = Ratio::from_bps(1000);
pub const MAX_FEE_LAMPORTS: TokenAmount = TokenAmount::new(10_000);

pub const MIN_DUTCH_AUCTION_SCALE_BPS: u64 = 5_000; // 0.5x oracle floor
pub const MAX_DUTCH_AUCTION_SCALE_BPS: u64 = 30_000; // 3.0x oracle ceiling
pub const DEFAULT_DUTCH_AUCTION_SCALE_BPS: u64 = 10_000; // 1.0x oracle (no adjustment)

// Have a sensible max age so that adding a new token (which would normally have age 0) doesn't DDoS the vault
// because price is always too old.
pub const DEFAULT_MAX_AGE_PRICE_SECONDS: Duration = Duration::from_secs(60); // 1 minute
pub const DEFAULT_MAX_AGE_TWAP_SECONDS: Duration = Duration::from_secs(60); // 1 minute
/// Bounds of a vault token's max price and TWAP ages (a zero age refuses every price, an
/// unbounded one accepts any stale price).
pub const MIN_MAX_AGE_SECONDS: Duration = Duration::from_secs(1);
pub const MAX_MAX_AGE_SECONDS: Duration = Duration::from_secs(86400); // 1 day
                                                                      // Also have a default for max twap divergence in case vault admin forgets to set it.
pub const DEFAULT_MAX_TWAP_DIVERGENCE_BPS: u64 = 100; // 1%

/// Minimum `amount_in` for `rebalance_swap` to prevent dust-spam griefing.
pub const MIN_REBALANCE_SWAP_AMOUNT_LAMPORTS: TokenAmount =
    TokenAmount::new(MIN_REBALANCE_SWAP_AMOUNT);
const MIN_REBALANCE_SWAP_AMOUNT: u64 = 1_000;

// The dust floor is enforced on the `amount_in` a solver *requests*, but the vault then clamps
// that to the `token_in` deficit, and it is the clamped amount that actually moves. The clamp
// cannot dip under the floor only because a token is refused as `token_in` at all unless its
// deficit exceeds the settled tolerance: with `tolerance >= floor`, every acceptable deficit is
// itself above the floor. Drop the tolerance below the floor and dust fills become reachable
// again, past a gate that still reports success — so the relation is asserted, not assumed.
static_assertions::const_assert!(REBALANCE_SETTLED_TOLERANCE >= MIN_REBALANCE_SWAP_AMOUNT);

/// The most orders an owner may have in one vault, per kind (few, so that a client lists them all
/// by deriving every address and fetching them in one `getMultipleAccounts`).
pub const MAX_ORDERS_PER_OWNER: u8 = 4;
pub const MIN_ORDER_AUCTION_DURATION: Duration = Duration::from_secs(300); // 5 minutes
pub const MAX_ORDER_AUCTION_DURATION: Duration = Duration::from_secs(86_400); // 1 day

/// The klend obligation tag of the vault's obligations (single-market, no asset-mint binding:
/// both seed accounts are `Pubkey::default()`).
pub const VAULT_OBLIGATION_TAG: u8 = 0;

/// The kFarms seed of a user's state in a farm (`[seed, farm_state, owner]`, klend's obligation
/// being the owner of its own).
pub const FARMS_USER_STATE_SEED: &[u8] = b"user";

/// The kFarms program klend forwards farm updates to (metavault never invokes it itself).
pub const FARMS_PROGRAM_ID: Pubkey =
    anchor_lang::solana_program::pubkey!("FarmsPZpWu9i7Kky8tPN37rs2TpmMrAZrC7S7vJa91Hr");

#[cfg(test)]
mod tests {
    use super::{
        DEPOSIT_ORDER_ACCOUNT_INDEX, KRFQ_AUTHORITY_ACCOUNT_INDEX, KRFQ_FILL_MARKER_ACCOUNT_INDEX,
        WITHDRAW_ORDER_ACCOUNT_INDEX,
    };
    use anchor_lang::prelude::Pubkey;
    use anchor_lang::ToAccountMetas;

    /// Derives the indices from the generated account metas instead of
    /// restating them, so inserting a field anywhere at or before the marker
    /// fails here — at the definition — rather than in whichever client
    /// happens to have a test.
    #[test]
    fn rebalance_swap_optional_account_indices_match_the_struct() {
        let unique = Pubkey::new_unique;
        let krfq_authority = unique();
        let krfq_fill_marker = unique();
        let deposit_order = unique();
        let withdraw_order = unique();
        let metas = crate::accounts::RebalanceSwap {
            user: unique(),
            vault_state: unique(),
            base_vault_authority: unique(),
            token_in_mint: unique(),
            token_in_vault: unique(),
            user_token_in_ata: unique(),
            token_out_mint: unique(),
            token_out_vault: unique(),
            user_token_out_ata: unique(),
            token_in_program: unique(),
            token_out_program: unique(),
            instruction_sysvar_account: unique(),
            krfq_authority: Some(krfq_authority),
            global_config: unique(),
            krfq_fill_marker: Some(krfq_fill_marker),
            deposit_order: Some(deposit_order),
            withdraw_order: Some(withdraw_order),
            event_authority: unique(),
            program: unique(),
        }
        .to_account_metas(None);

        assert_eq!(
            metas[KRFQ_AUTHORITY_ACCOUNT_INDEX].pubkey, krfq_authority,
            "KRFQ_AUTHORITY_ACCOUNT_INDEX no longer points at krfq_authority"
        );
        assert_eq!(
            metas[KRFQ_FILL_MARKER_ACCOUNT_INDEX].pubkey, krfq_fill_marker,
            "KRFQ_FILL_MARKER_ACCOUNT_INDEX no longer points at krfq_fill_marker; \
             krfq reads the marker at this index and will refuse every bid"
        );
        assert_eq!(
            metas[DEPOSIT_ORDER_ACCOUNT_INDEX].pubkey, deposit_order,
            "DEPOSIT_ORDER_ACCOUNT_INDEX no longer points at deposit_order"
        );
        assert_eq!(
            metas[WITHDRAW_ORDER_ACCOUNT_INDEX].pubkey, withdraw_order,
            "WITHDRAW_ORDER_ACCOUNT_INDEX no longer points at withdraw_order"
        );
    }
}

#![allow(clippy::result_large_err)]

use anchor_lang::prelude::*;

pub mod events;
mod handlers;
pub mod operations;
pub mod order;
pub mod state;
pub mod types;
pub mod utils;

pub use crate::handlers::handler_aum::AumResult;
pub use crate::handlers::handler_exchange_rate::{ExchangeRateResult, ExchangeRateWithDecimals};
use crate::handlers::*;
pub use crate::state::*;
use crate::utils::constraints::emergency_mode_disabled;
pub use crate::utils::vault_config::VaultConfigField;

#[cfg(feature = "staging")]
declare_id!("SKMjNveD9w7mCVN2m3bQu99shKu2vZRD6Q37wdqGxFg");

#[cfg(not(feature = "staging"))]
declare_id!("MeVaiz8VbU5n33rFnRsopxBAtiaxQeZf9Qct1kskFZk");

#[cfg(not(feature = "no-entrypoint"))]
solana_security_txt::security_txt! {
    name: "Kamino Meta Vault",
    project_url: "https://kamino.finance/",
    contacts: "email:security@kamino.finance",
    policy: "https://github.com/Kamino-Finance/audits/blob/master/docs/SECURITY.md",

    // Optional Fields
    preferred_languages: "en",
    auditors: "OtterSec, Certora"
}

#[program]
pub mod metavault {

    use super::*;

    pub fn init_vault(
        ctx: Context<InitVault>,
        scope_configuration: kamino_lending::ScopeConfiguration,
        user_lookup_table: Pubkey,
        gating_program: Option<Pubkey>,
    ) -> Result<()> {
        handler_init_vault::process(ctx, scope_configuration, user_lookup_table, gating_program)
    }

    /// Buy shares in the vault by depositing tokens.
    /// `max_amount` is the maximum number of tokens the user is willing to deposit.
    /// The actual deposited amount may be less due to rounding in share calculation
    /// (shares are floored, then tokens are recomputed from shares with ceiling).
    /// `min_shares_out` is the minimum shares the user expects to receive (slippage protection).
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn buy<'info>(
        ctx: Context<'_, '_, 'info, 'info, Deposit<'info>>,
        max_amount: u64,
        min_shares_out: u64,
    ) -> Result<()> {
        handler_deposit::process(ctx, max_amount, min_shares_out)
    }

    /// Sell shares to withdraw tokens from the vault.
    /// `shares_amount` is the number of shares to burn.
    /// `min_tokens_out` is the minimum tokens the user expects to receive (slippage protection).
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn sell<'info>(
        ctx: Context<'_, '_, 'info, 'info, Withdraw<'info>>,
        shares_amount: u64,
        min_tokens_out: u64,
    ) -> Result<()> {
        handler_withdraw::withdraw(ctx, shares_amount, min_tokens_out)
    }

    /// Return current positive net AUM as `DollarValue` fixed-point bits.
    pub fn aum<'info>(ctx: Context<'_, '_, 'info, 'info, Aum<'info>>) -> Result<AumResult> {
        handler_aum::process(ctx)
    }

    /// Return the net withdraw token-per-share exchange rate (Fraction bits) plus the token mint
    /// decimals, computed for a canonical one-whole-share redemption. See
    /// [`ExchangeRateWithDecimals`](handler_exchange_rate::ExchangeRateWithDecimals).
    pub fn exchange_rate<'info>(
        ctx: Context<'_, '_, 'info, 'info, ExchangeRate<'info>>,
        mint: Pubkey,
    ) -> Result<ExchangeRateResult> {
        handler_exchange_rate::process(ctx, mint)
    }

    /// Refresh vault accounting using current Scope prices and fresh obligation values.
    ///
    /// This accrues management/performance fees, snapshots non-negative net AUM into `prev_aum`,
    /// and ends a rebalance in progress once its window has elapsed or no fill can make progress
    /// at the current prices.
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn refresh_vault<'info>(
        ctx: Context<'_, '_, 'info, 'info, RefreshVault<'info>>,
    ) -> Result<()> {
        handler_refresh_vault::process(ctx)
    }

    pub fn add_vault_token(
        ctx: Context<AddVaultToken>,
        scope_configuration: kamino_lending::ScopeConfiguration,
    ) -> Result<()> {
        handler_add_vault_token::process(ctx, scope_configuration)
    }

    pub fn update_vault_config<'info>(
        ctx: Context<'_, '_, 'info, 'info, UpdateVaultConfig<'info>>,
        entry: VaultConfigField,
        data: Vec<u8>,
    ) -> Result<()> {
        handler_update_vault_config::process(ctx, entry, &data)
    }

    pub fn withdraw_pending_fees<'info>(
        ctx: Context<'_, '_, 'info, 'info, WithdrawPendingFees<'info>>,
    ) -> Result<()> {
        handler_withdraw_pending_fees::process(ctx)
    }

    pub fn apply_pending_admin<'info>(
        ctx: Context<'_, '_, '_, 'info, ApplyPendingAdmin<'info>>,
    ) -> Result<()> {
        handler_apply_pending_admin::process(ctx)
    }

    pub fn give_up_pending_fees<'info>(
        ctx: Context<'_, '_, 'info, 'info, GiveUpPendingFees<'info>>,
        max_amount_to_give_up: u64,
    ) -> Result<()> {
        handler_give_up_pending_fees::process(ctx, max_amount_to_give_up)
    }

    pub fn initialize_shares_metadata(
        ctx: Context<InitializeSharesMetadata>,
        name: String,
        symbol: String,
        uri: String,
    ) -> Result<()> {
        handler_initialize_shares_metadata::process(ctx, name, symbol, uri)
    }

    pub fn update_shares_metadata(
        ctx: Context<UpdateSharesMetadata>,
        name: String,
        symbol: String,
        uri: String,
    ) -> Result<()> {
        handler_update_shares_metadata::process(ctx, name, symbol, uri)
    }

    pub fn thaw_shares_account(ctx: Context<ThawSharesAccount>) -> Result<()> {
        handler_thaw_shares_account::process(ctx)
    }

    pub fn freeze_shares_account(ctx: Context<FreezeSharesAccount>) -> Result<()> {
        handler_freeze_shares_account::process(ctx)
    }

    pub fn set_shares_gating_program(
        ctx: Context<SetSharesGatingProgram>,
        new_gating_program: Pubkey,
    ) -> Result<()> {
        handler_set_shares_gating_program::process(ctx, new_gating_program)
    }

    pub fn toggle_shares_permissionless(
        ctx: Context<ToggleSharesPermissionless>,
        freeze_enabled: bool,
        thaw_enabled: bool,
    ) -> Result<()> {
        handler_toggle_shares_permissionless::process(ctx, freeze_enabled, thaw_enabled)
    }

    pub fn delete_shares_config(ctx: Context<DeleteSharesConfig>) -> Result<()> {
        handler_delete_shares_config::process(ctx)
    }

    pub fn init_global_config(ctx: Context<InitGlobalConfig>) -> Result<()> {
        handler_initialize_global_config::process(ctx)
    }

    pub fn update_global_config(
        ctx: Context<UpdateGlobalConfig>,
        mode: utils::global_config::UpdateGlobalConfigMode,
        value: Vec<u8>,
    ) -> Result<()> {
        handler_update_global_config::process(ctx, mode, value)
    }

    pub fn update_global_config_admin(ctx: Context<ApplyGlobalConfigAdmin>) -> Result<()> {
        handler_update_global_config_admin::process(ctx)
    }

    pub fn start_rebalance<'info>(
        ctx: Context<'_, '_, 'info, 'info, StartRebalance<'info>>,
        rebalance_duration: u64,
    ) -> Result<()> {
        handler_start_rebalance::process(ctx, rebalance_duration)
    }

    pub fn stop_rebalance<'info>(
        ctx: Context<'_, '_, 'info, 'info, StopRebalance<'info>>,
    ) -> Result<()> {
        handler_stop_rebalance::process(ctx)
    }

    /// Fill part of the rebalance in progress, the vault's own or an order's (of either kind)
    /// when one is passed. The solver pays `amount_in` of `token_in` (clamped to the basket's
    /// remaining deficit) and receives exactly `requested_out_amount` of `token_out` (provided the
    /// dutch-auction allows it).
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn rebalance_swap<'info>(
        ctx: Context<'_, '_, 'info, 'info, RebalanceSwap<'info>>,
        amount_in: u64,
        requested_out_amount: u64,
    ) -> Result<()> {
        handler_rebalance_swap::process(ctx, amount_in, requested_out_amount)
    }

    /// Opens a deposit order: locks `amounts` (one per enabled token, in token order) in the vault
    /// and auctions them into its target weights for `duration_seconds`, losing at most
    /// `max_fill_slippage_bps` per fill and `max_loss_bps` overall (`FULL_BPS` for no limit).
    /// Absorbs nothing itself (see `settle_deposit_order`, which respects `min_shares_out`, `0` for
    /// none).
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn open_deposit_order<'info>(
        ctx: Context<'_, '_, 'info, 'info, OpenDepositOrder<'info>>,
        id: u8,
        amounts: Vec<u64>,
        duration_seconds: u64,
        min_shares_out: u64,
        max_fill_slippage_bps: u64,
        max_loss_bps: u64,
    ) -> Result<()> {
        handler_open_deposit_order::process(
            ctx,
            id,
            amounts,
            duration_seconds,
            min_shares_out,
            max_fill_slippage_bps,
            max_loss_bps,
        )
    }

    /// Absorbs what the vault admits of a deposit order, mints shares for it to the owner, refunds
    /// the rest and deletes the order. Anyone may send it once the auction is over.
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn settle_deposit_order<'info>(
        ctx: Context<'_, '_, 'info, 'info, SettleDepositOrder<'info>>,
    ) -> Result<()> {
        handler_settle_deposit_order::process(ctx)
    }

    /// Refunds everything a deposit order holds to its owner and deletes it, cancelling its
    /// auction. Only the owner may do this, at any time outside emergency mode.
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn cancel_deposit_order<'info>(
        ctx: Context<'_, '_, 'info, 'info, CancelDepositOrder<'info>>,
    ) -> Result<()> {
        handler_cancel_deposit_order::process(ctx)
    }

    /// Opens a withdraw order: burns `shares_amount` for a pro-rata slice of every liquid vault
    /// token (kept in the vault's token accounts, owned by the order) and auctions it into
    /// `weights` (one per enabled token, in token order) for `duration_seconds`, losing at most
    /// `max_fill_slippage_bps` per fill and `max_loss_bps` overall (`FULL_BPS` for no limit). Moves
    /// no token.
    ///
    /// `min_tokens_out` is the least of each token (one per enabled token, in token order, `0` for
    /// no limit) the order must receive, net of fees, as for the plain withdraw.
    #[allow(clippy::too_many_arguments)]
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn open_withdraw_order<'info>(
        ctx: Context<'_, '_, 'info, 'info, OpenWithdrawOrder<'info>>,
        id: u8,
        shares_amount: u64,
        weights: Vec<u64>,
        duration_seconds: u64,
        min_tokens_out: Vec<u64>,
        max_fill_slippage_bps: u64,
        max_loss_bps: u64,
    ) -> Result<()> {
        handler_open_withdraw_order::process(
            ctx,
            id,
            shares_amount,
            weights,
            duration_seconds,
            min_tokens_out,
            max_fill_slippage_bps,
            max_loss_bps,
        )
    }

    /// Pays out everything a withdraw order holds to its owner and deletes it. Outside emergency
    /// mode, the owner may do this at any time; anyone may once the auction is over, passing the
    /// scope prices that show it (past the window, or with no fill able to improve the basket any
    /// more).
    #[access_control(emergency_mode_disabled(&ctx.accounts.vault_state))]
    pub fn settle_withdraw_order<'info>(
        ctx: Context<'_, '_, 'info, 'info, SettleWithdrawOrder<'info>>,
    ) -> Result<()> {
        handler_settle_withdraw_order::process(ctx)
    }

    pub fn init_obligation(ctx: Context<InitObligation>) -> Result<()> {
        handler_init_obligation::process(ctx)
    }

    pub fn deposit_obligation_collateral<'info>(
        ctx: Context<'_, '_, 'info, 'info, DepositObligationCollateral<'info>>,
        amount: u64,
    ) -> Result<()> {
        handler_deposit_obligation_collateral::process(ctx, amount)
    }

    pub fn withdraw_obligation_collateral<'info>(
        ctx: Context<'_, '_, 'info, 'info, WithdrawObligationCollateral<'info>>,
        collateral_amount: u64,
    ) -> Result<()> {
        handler_withdraw_obligation_collateral::process(ctx, collateral_amount)
    }

    pub fn borrow_obligation_liquidity<'info>(
        ctx: Context<'_, '_, 'info, 'info, BorrowObligationLiquidity<'info>>,
        liquidity_amount: u64,
    ) -> Result<()> {
        handler_borrow_obligation_liquidity::process(ctx, liquidity_amount)
    }

    pub fn repay_obligation_liquidity<'info>(
        ctx: Context<'_, '_, 'info, 'info, RepayObligationLiquidity<'info>>,
        liquidity_amount: u64,
    ) -> Result<()> {
        handler_repay_obligation_liquidity::process(ctx, liquidity_amount)
    }

    pub fn request_elevation_group<'info>(
        ctx: Context<'_, '_, 'info, 'info, RequestElevationGroup<'info>>,
        new_elevation_group: u8,
    ) -> Result<()> {
        handler_request_elevation_group::process(ctx, new_elevation_group)
    }
}

#[error_code]
#[derive(PartialEq, Eq, strum::EnumString)]
#[cfg_attr(test, derive(num_enum::TryFromPrimitive))]
pub enum KaminoVaultError {
    #[msg("Cannot deposit zero tokens")]
    DepositAmountsZero = 1000,

    #[msg("Post check failed on share issued")]
    SharesIssuedAmountDoesNotMatch,

    #[msg("Withdrawn amount is below minimum")]
    WithdrawAmountBelowMinimum,

    #[msg("ReserveAlreadyExists")]
    VaultTokenAlreadyExists,

    #[msg("TokenNotEnabledInVault")]
    TokenNotEnabledInVault,

    #[msg("AdminAuthorityIncorrect")]
    AdminAuthorityIncorrect,

    #[msg("BaseVaultAuthorityIncorrect")]
    BaseVaultAuthorityIncorrect,

    #[msg("SharesMintDecimalsIncorrect")]
    SharesMintDecimalsIncorrect,

    #[msg("SharesMintIncorrect")]
    SharesMintIncorrect,

    #[msg("InitialAccountingIncorrect")]
    InitialAccountingIncorrect,

    #[msg("BPS value is greater than 10000")]
    BPSValueTooBig,

    #[msg("Deposited amount is below minimum")]
    DepositAmountBelowMinimum,

    #[msg("Vault have no space for new reserves")]
    VaultTokensSpaceExhausted,

    #[msg("TokensDepositedAmountDoesNotMatch")]
    TokensDepositedAmountDoesNotMatch,

    #[msg("User received amount does not match")]
    UserReceivedAmountDoesNotMatch,

    #[msg("Shares burned amount does not match")]
    SharesBurnedAmountDoesNotMatch,

    #[msg("Withdraw amount results in 0 shares")]
    WithdrawResultsInZeroShares,

    #[msg("Cannot withdraw zero shares")]
    CannotWithdrawZeroShares,

    #[msg("Management fee is greater than maximum allowed")]
    ManagementFeeGreaterThanMaxAllowed,

    #[msg("Vault assets under management are empty")]
    VaultAUMZero,

    #[msg("Vault real shares issued are zero")]
    VaultSharesZero,

    #[msg("Min withdraw amount is too big")]
    MinWithdrawAmountTooBig,

    #[msg("Deposit amount is greater than requested amount")]
    DepositAmountGreaterThanRequestedAmount,

    #[msg("Withdraw amount is less than withdrawal fee")]
    WithdrawAmountLessThanWithdrawalFee,

    #[msg("Deposit amount is less than deposit fee")]
    DepositAmountLessThanDepositFee,

    #[msg("Cannot withdraw 0 lamports")]
    CannotWithdrawZeroLamports,

    #[msg("Cannot initialize global config because there is no upgrade authority to the program")]
    NoUpgradeAuthority,

    #[msg("BPS fee is greater than maximum allowed")]
    BPSFeeGreaterThanMaxAllowed,

    #[msg("Lamports fee is greater than maximum allowed")]
    LamportsFeeGreaterThanMaxAllowed,

    #[msg("Could not get scope price from the account passed")]
    InvalidScopePriceAccount,

    #[msg("Scope price was validated and fails at twap, age or confidence")]
    InvalidScopePrice,

    #[msg("Input oracle config is invalid")]
    InvalidOracleConfig,

    #[msg("Invalid Twap configuration: Twap is enabled but one of the enabled price doesn't have a twap")]
    InvalidTwapConfig,

    #[msg("Vault balance does not match expected amount")]
    VaultBalanceDoesNotMatch,

    #[msg("Token weights must sum to a non-zero value that fits u64")]
    InvalidWeightsSum,

    #[msg("Per-token array length does not match enabled tokens count")]
    TokenArrayLengthMismatch,

    #[msg("Rebalance is in progress")]
    RebalanceInProgress,

    #[msg("Cannot update weights while a rebalance is in progress")]
    CannotUpdateWeightsDuringRebalance,

    #[msg("Invalid rebalance duration")]
    InvalidRebalanceDuration,

    #[msg("Vault is already rebalanced")]
    VaultAlreadyRebalanced,

    #[msg("No rebalance is in progress")]
    RebalanceNotInProgress,

    #[msg("The vault will not swap this pair of tokens")]
    InvalidSwapPair,

    #[msg("Requested output exceeds the vault's excess of that token")]
    RequestedOutExceedsExcess,

    #[msg("Withdraw aum exceed total in vault")]
    WithdrawAumExceedTotal,

    #[msg("Withdraw shares exceed total shares issued")]
    WithdrawSharesExceedIssued,

    #[msg("Slippage tolerance exceeded")]
    SlippageExceeded,

    #[msg("Min deposit amount is too big")]
    MinDepositAmountTooBig,

    #[msg("Performance fee is greater than maximum allowed")]
    PerformanceFeeGreaterThanMaxAllowed,

    #[msg("Cannot give up zero fees")]
    CannotGiveUpZeroFees,

    #[msg("Unix timestamp conversion to u64 failed")]
    TimestampConversionFailed,

    #[msg("Invalid Dutch auction bounds configuration")]
    InvalidDutchAuctionBounds,

    #[msg("Shares supply does not match expected accounting")]
    SharesSupplyInconsistent,

    #[msg("Swap quote rounds to zero output tokens")]
    SwapQuoteRoundsToZero,

    #[msg("Vault has no space for new obligations")]
    ObligationsSpaceExhausted,

    #[msg("Obligation not found in vault")]
    ObligationSlotNotFound,

    #[msg("Obligation already registered in vault")]
    ObligationAlreadyExists,

    #[msg("Missing or invalid obligation account in remaining accounts")]
    ObligationAccountMissing,

    #[msg("Obligation is stale; caller must prepend klend refresh_obligation in the current slot")]
    ObligationStale,

    #[msg("Reserve is stale; caller must prepend klend refresh_reserve in the current slot")]
    ReserveStale,

    #[msg("Rebalance swap amount_in below minimum threshold")]
    RebalanceSwapAmountBelowMinimum,

    #[msg("Deposit or withdraw would breach target weight deviation bound")]
    TargetBoundExceeded,

    #[msg("Unexpected non-zero referrer fee on an obligation that has no referrer")]
    UnexpectedReferrerFee,

    #[msg("Obligation's total deposited value is zero")]
    ObligationDepositsZero,

    #[msg("Obligation's maximum withdrawable value is zero")]
    MaximumWithdrawValueZero,

    #[msg("Observed token delta does not match the predicted obligation CPI effect")]
    BalanceAfterObligationCpiMismatch,

    #[msg("Reserve scope_configuration must match the matching vault token's scope_configuration")]
    ReserveScopeMismatch,

    #[msg("Deposit would push vault AUM above the configured cap")]
    DepositAumCapExceeded,

    #[msg("Deposit exceeds the rolling deposit cap for this interval")]
    RollingDepositCapExceeded,

    #[msg("Withdraw exceeds the rolling withdraw cap for this interval")]
    RollingWithdrawCapExceeded,

    #[msg("Rolling-cap interval exceeds the maximum allowed length")]
    RollingCapIntervalTooLong,

    #[msg("Vault is in emergency mode")]
    VaultEmergencyMode,

    #[msg("Vault deposits are blocked")]
    VaultDepositsBlocked,

    #[msg("Vault withdrawals are blocked")]
    VaultWithdrawsBlocked,

    #[msg("Flag value must be 0 or 1")]
    InvalidFlagValue,

    #[msg("CPI disabled for this instruction")]
    CpiDisabled,

    #[msg("Swap authority incorrect")]
    SwapAuthorityIncorrect,

    #[msg("Rebalance swap costs the basket more than its max allowed loss")]
    RebalanceSwapExceedsMaxLoss,

    #[msg("User shares account is frozen; it must be thawed through the vault's gate before use")]
    SharesAccountFrozen,

    #[msg("Shares gating program is invalid or its accounts are missing")]
    SharesGatingProgramInvalid,

    #[msg("Token ACL program account does not match the expected program id")]
    TokenAclProgramIncorrect,

    #[msg("Token ACL mint config account is incorrect or its setup invariants do not hold")]
    MintConfigIncorrect,

    #[msg("Vault shares are not permissioned")]
    SharesNotPermissioned,

    #[msg("Allocation authority incorrect")]
    AllocationAuthorityIncorrect,

    #[msg("Vault deposits must be blocked before giving up pending fees")]
    VaultDepositsNotBlocked,

    #[msg("Obligation LTV ceiling exceeded")]
    ObligationLtvCeilingExceeded,

    #[msg("Rebalance cooldown exceeds the maximum allowed")]
    RebalanceCooldownTooLong,
    #[msg("Rebalance cooldown has not elapsed since the last rebalance start")]
    RebalanceCooldownNotElapsed,

    #[msg("Obligation inventory cannot change while a rebalance is in progress")]
    ObligationOperationDuringRebalance,

    #[msg("Reserve cached price diverges from the vault's scope price beyond the configured tolerance")]
    ReservePriceMismatch,

    #[msg("Vault requires krfq-gated fills but the krfq authority signer was not provided")]
    KrfqAuthorityMissing,
    #[msg("krfq authority signer does not match the global config's krfq swap authority")]
    KrfqAuthorityIncorrect,
    #[msg("krfq swap authority is not set in the global config")]
    KrfqSwapAuthorityNotSet,
    #[msg("krfq-co-signed fill did not provide the krfq fill marker account")]
    KrfqFillMarkerMissing,
    #[msg("krfq fill marker does not derive from this fill's vault and mint pair")]
    KrfqFillMarkerIncorrect,
    #[msg("Vault weights other tokens but not this one, so it takes no deposits of it")]
    TokenWeightZeroed,

    #[msg("Rebalance fills exceed the basket's loss ceiling for this rebalance")]
    RebalanceLossCeilingExceeded,

    #[msg(
        "Shares account must carry the Token-2022 ImmutableOwner extension on a permissioned vault"
    )]
    SharesAccountOwnerMutable,

    #[msg("Opening deposit orders is not enabled on this vault")]
    DepositOrderCreationDisabled,
    #[msg("Filling deposit orders is not enabled on this vault")]
    DepositOrderFillDisabled,
    #[msg("Settling deposit orders is not enabled on this vault")]
    DepositOrderSettleDisabled,
    #[msg("Order id must be below the per-owner maximum")]
    InvalidOrderId,
    #[msg("Order auction duration is out of range")]
    InvalidOrderAuctionDuration,
    #[msg("Order basket is worth less than the vault's minimum")]
    OrderBelowMinValue,
    #[msg("The order's auction is still running")]
    OrderAuctionStillRunning,
    #[msg("Every token the order moves must be covered by the accounts passed")]
    OrderTokensNotCovered,
    #[msg("Token vault balance is below the vault's available plus locked amounts")]
    TokenVaultBalanceBelowLocked,
    #[msg("Account does not match the order")]
    OrderAccountMismatch,
    #[msg("Remaining account is not the one expected at its position")]
    RemainingAccountKeyMismatch,
    #[msg("More remaining accounts were passed than the instruction reads")]
    UnexpectedRemainingAccounts,
    #[msg(
        "A settle by someone else than the owner pays out to the owner's associated accounts only"
    )]
    PayoutNotToAssociatedAccount,
    #[msg("Opening withdraw orders is not enabled on this vault")]
    WithdrawOrderCreationDisabled,
    #[msg("Filling withdraw orders is not enabled on this vault")]
    WithdrawOrderFillDisabled,
    #[msg("The order accounts passed are inconsistent: a fill names at most one order")]
    InconsistentOrderAccounts,
    #[msg("Account does not match the reserve")]
    ReserveAccountMismatch,
    #[msg("Lending market does not match the obligation or the reserve")]
    LendingMarketMismatch,
    #[msg("Farm account does not match the reserve's farm or the obligation's user state in it")]
    FarmAccountMismatch,
    #[msg("Obligation is not the vault's klend obligation for this lending market and slot")]
    ObligationAddressMismatch,
    #[msg("The vault's own shares mint cannot be one of its tokens")]
    VaultTokenIsSharesMint,
    #[msg("Config value is too short for its field")]
    ConfigValueTooShort,
    #[msg("Max price age must be between 1 second and 1 day")]
    MaxPriceAgeOutOfRange,
}

#[cfg(feature = "program-test")]
pub mod program_test;

use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_2022::Token2022;

use crate::{
    utils::{token22_metadata, token_acl},
    KaminoVaultError, MetavaultState,
};

pub fn process(
    ctx: Context<InitializeSharesMetadata>,
    name: String,
    symbol: String,
    uri: String,
) -> Result<()> {
    // Gate discovery for permissioned vaults: the gating program is read from the
    // token-acl MintConfig (its canonical source — never mirrored in vault state) and
    // advertised under the `token_acl` metadata key.
    let permissioned = ctx.accounts.vault_state.load()?.shares_permissioned();
    let token_acl_gate = if permissioned {
        let mint_config = ctx
            .accounts
            .shares_mint_config
            .as_ref()
            .ok_or(KaminoVaultError::SharesGatingProgramInvalid)?;
        let (expected_mint_config, _) = token_acl::mint_config_pda(ctx.accounts.shares_mint.key);
        require!(
            mint_config.key() == expected_mint_config
                && *mint_config.owner == token_acl::TOKEN_ACL_PROGRAM_ID,
            KaminoVaultError::MintConfigIncorrect
        );
        let config = token_acl::MintConfig::unpack(&mint_config.data.borrow())
            .ok_or(KaminoVaultError::MintConfigIncorrect)?;
        Some(config.gating_program)
    } else {
        require!(
            ctx.accounts.shares_mint_config.is_none(),
            KaminoVaultError::MintConfigIncorrect
        );
        None
    };

    let vault_state_key = ctx.accounts.vault_state.key();
    let accounts = token22_metadata::SharesMetadataAccounts {
        shares_mint: &ctx.accounts.shares_mint,
        base_vault_authority: &ctx.accounts.base_vault_authority,
        shares_token_program: &ctx.accounts.shares_token_program.to_account_info(),
        vault_state_key,
        base_vault_authority_bump: ctx.accounts.vault_state.load()?.base_vault_authority_bump,
    };
    token22_metadata::cpi_initialize(
        &accounts,
        &ctx.accounts.vault_admin_authority.to_account_info(),
        &ctx.accounts.system_program.to_account_info(),
        name,
        symbol,
        uri,
        token_acl_gate,
    )
}

#[derive(Accounts)]
pub struct InitializeSharesMetadata<'info> {
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(
        has_one = vault_admin_authority,
        has_one = shares_mint,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Pinned by `has_one` on `vault_state`; holds its own TokenMetadata.
    #[account(mut)]
    pub shares_mint: AccountInfo<'info>,

    /// CHECK: Pinned by `has_one` on `vault_state`; mint + metadata update authority.
    pub base_vault_authority: AccountInfo<'info>,

    pub shares_token_program: Program<'info, Token2022>,
    pub system_program: Program<'info, System>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,

    /// CHECK: Required on permissioned vaults only; validated in the handler against the
    /// token-acl MintConfig PDA of the shares mint.
    pub shares_mint_config: Option<AccountInfo<'info>>,
}

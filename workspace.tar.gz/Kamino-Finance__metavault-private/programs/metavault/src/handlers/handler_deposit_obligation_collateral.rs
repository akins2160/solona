use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
    Accounts,
};
use anchor_spl::{
    token::Token,
    token_interface::{Mint, TokenAccount, TokenInterface},
};
use kamino_lending::{
    utils::seeds::LENDING_MARKET_AUTH,
    utils::token_2022::check_only_supported_liquidity_token_extensions, LendingMarket, Obligation,
    Reserve,
};
use std::ops::Deref;

use crate::{
    events::{ObligationCollateralDepositEvent, RebalanceEndWatch},
    operations::{
        obligation_operations,
        vault_checks::{
            check_reserve_price_basis, find_enabled_token_and_price, has_matching_scope_config,
            post_deposit_obligation_collateral_checks, DepositObligationCollateralBalances,
        },
    },
    types::{Timestamp, TokenAmount},
    utils::{
        consts::{BASE_VAULT_AUTHORITY_SEED, FARMS_PROGRAM_ID, TOKEN_VAULT_SEED},
        obligation_cpi::{
            cpi_deposit_reserve_liquidity_and_obligation_collateral,
            split_trailing_target_farm_accounts,
        },
        obligations::load_scope_prices_and_obligations_aum_from,
        remaining_accounts::RemainingAccounts,
    },
    KaminoVaultError, MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, DepositObligationCollateral<'info>>,
    amount: u64,
) -> Result<()> {
    let amount = TokenAmount::from(amount);

    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.reserve_liquidity_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;

    let mut vault = ctx.accounts.vault_state.load_mut()?;
    let base_vault_authority_bump = vault.base_vault_authority_bump;

    let vault_obligation_id = vault.get_obligation_id_by_address(&ctx.accounts.obligation.key())?;

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let rebalance_watch =
        RebalanceEndWatch::open(ctx.accounts.vault_state.key(), &vault, current_timestamp);
    let target_farm = ctx.accounts.reserve.load()?.farm_collateral;
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum_from(
        &vault,
        &mut remaining,
        clock.slot,
        current_timestamp,
    )?;
    let (_, farm_accounts) = split_trailing_target_farm_accounts(
        remaining.rest(),
        0,
        target_farm,
        ctx.accounts.obligation.key(),
    )?;

    let liquidity_mint = ctx.accounts.reserve_liquidity_mint.key();
    let effects = {
        let reserve = ctx.accounts.reserve.load()?;
        // The gate is keyed off the reserve's own recorded mint (as the leg sweep does), not the
        // caller-supplied mint account.
        let (vault_token, token_price) = find_enabled_token_and_price(
            &vault,
            &vault_scope_prices,
            &reserve.liquidity.mint_pubkey,
        )?;
        check_reserve_price_basis(vault_token, token_price, &reserve)?;
        obligation_operations::deposit_obligation_collateral(
            &mut vault,
            &vault_scope_prices,
            obligations_aum,
            &reserve,
            &liquidity_mint,
            amount,
            clock.slot,
            current_timestamp,
        )?
    };

    let pre_balances = capture_balances(ctx.accounts)?;

    cpi_deposit_reserve_liquidity_and_obligation_collateral(
        ctx.accounts,
        farm_accounts,
        base_vault_authority_bump,
        amount,
    )?;

    let post_balances = capture_balances(ctx.accounts)?;

    emit_cpi!(ObligationCollateralDepositEvent {
        storage_index: vault_obligation_id.storage_index as u8,
        reserve: ctx.accounts.reserve.key(),
        amount: effects.liquidity_to_deposit.into(),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(&vault) {
        emit_cpi!(ended_event);
    }

    post_deposit_obligation_collateral_checks(&pre_balances, &post_balances, &effects)?;

    Ok(())
}

fn capture_balances(
    accounts: &DepositObligationCollateral,
) -> Result<DepositObligationCollateralBalances> {
    Ok(DepositObligationCollateralBalances {
        vault_token_balance: TokenAmount::of_account(&accounts.token_vault.to_account_info())?,
        reserve_liquidity_supply: TokenAmount::of_account(&accounts.reserve_liquidity_supply)?,
        reserve_destination_deposit_collateral: TokenAmount::of_account(
            &accounts.reserve_destination_deposit_collateral,
        )?,
    })
}

#[event_cpi]
#[derive(Accounts)]
pub struct DepositObligationCollateral<'info> {
    pub authority: Signer<'info>,

    #[account(mut,
        constraint = vault_state.load()?.is_allocation_authority(authority.key())
            @ KaminoVaultError::AllocationAuthorityIncorrect,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: PDA — signs the klend CPI as the obligation owner. Declared `mut` because klend's
    /// inner `deposit_reserve_liquidity_and_obligation_collateral` marks the obligation owner
    /// `mut` (for potential rent refunds).
    #[account(mut, seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    /// One of the obligations registered in `vault_state` (checked by the handler).
    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub obligation: AccountLoader<'info, Obligation>,

    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// CHECK: the lending market's authority PDA (derived here, with klend's seeds).
    #[account(
        seeds = [LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
        seeds::program = kamino_lending::ID,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub reserve: AccountLoader<'info, Reserve>,

    #[account(
        address = reserve.load()?.liquidity.mint_pubkey
            @ KaminoVaultError::ReserveAccountMismatch,
        constraint = has_matching_scope_config(
            vault_state.load()?.deref(),
            &reserve_liquidity_mint.key(),
            reserve.load()?.deref(),
        )? @ KaminoVaultError::ReserveScopeMismatch,
    )]
    pub reserve_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// CHECK: the reserve's liquidity supply (address-pinned to the reserve).
    #[account(mut,
        address = reserve.load()?.liquidity.supply_vault @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_liquidity_supply: AccountInfo<'info>,

    /// CHECK: the reserve's collateral mint (address-pinned to the reserve).
    #[account(mut,
        address = reserve.load()?.collateral.mint_pubkey @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_collateral_mint: AccountInfo<'info>,

    /// CHECK: the reserve's collateral supply (address-pinned to the reserve).
    #[account(mut,
        address = reserve.load()?.collateral.supply_vault
            @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_destination_deposit_collateral: AccountInfo<'info>,

    /// The vault's own token vault for the liquidity mint — funds flow from here into the klend
    /// reserve.
    #[account(mut,
        seeds = [
            TOKEN_VAULT_SEED,
            reserve_liquidity_mint.key().as_ref(),
            vault_state.key().as_ref(),
        ],
        bump,
        token::mint = reserve_liquidity_mint,
        token::authority = base_vault_authority,
        token::token_program = liquidity_token_program,
    )]
    pub token_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    pub collateral_token_program: Program<'info, Token>,

    pub liquidity_token_program: Interface<'info, TokenInterface>,

    /// CHECK: Address-pinned, and no longer read — allocation instructions do not reject CPI
    /// (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,

    /// CHECK: the kFarms program (address-pinned).
    #[account(address = FARMS_PROGRAM_ID)]
    pub farms_program: AccountInfo<'info>,

    /// CHECK: the klend program (address-pinned).
    #[account(address = kamino_lending::ID)]
    pub lending_program: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum_from`, followed by
    // optional debt-farm accounts.
}

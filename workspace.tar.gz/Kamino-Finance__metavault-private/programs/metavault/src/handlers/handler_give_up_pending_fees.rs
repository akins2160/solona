use anchor_lang::prelude::*;

use crate::{
    operations::vault_operations,
    types::{ShareAmount, Timestamp},
    utils::obligations::load_scope_prices_and_obligations_aum,
    MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, GiveUpPendingFees<'info>>,
    max_amount_to_give_up: u64,
) -> Result<()> {
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;

    vault_operations::give_up_pending_fee(
        vault_state,
        &vault_scope_prices,
        obligations_aum,
        current_timestamp,
        ShareAmount::from(max_amount_to_give_up),
    )?;

    Ok(())
}

#[derive(Accounts)]
pub struct GiveUpPendingFees<'info> {
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(mut,
        has_one = vault_admin_authority
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

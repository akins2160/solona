use anchor_lang::prelude::*;
use borsh::BorshDeserialize;

use crate::{
    operations::vault_operations,
    types::Timestamp,
    utils::{obligations::load_scope_prices_and_obligations_aum, vault_config::VaultConfigField},
    KaminoVaultError, MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, UpdateVaultConfig<'info>>,
    entry: VaultConfigField,
    data: &[u8],
) -> Result<()> {
    let vault = &mut ctx.accounts.vault_state.load_mut()?;
    validate_update_authority(vault, ctx.accounts.vault_admin_authority.key(), entry, data)?;

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    // If we update perf or mgmt fee then we should charge fees first
    if matches!(
        entry,
        VaultConfigField::PerformanceFeeBps | VaultConfigField::ManagementFeeBps
    ) {
        let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
            vault,
            ctx.remaining_accounts,
            clock.slot,
            current_timestamp,
        )?;
        // charge fees because after this the fee structure can be different
        vault_operations::charge_fees(
            vault,
            &vault_scope_prices,
            obligations_aum,
            current_timestamp,
        )?;
        // A mid-cooldown charge leaves the checkpoint at the open window's start, so without a
        // rebase the next eligible charge would apply the NEW rate to the whole window,
        // including appreciation earned under the old rate. Raise the checkpoint to the current
        // price so the new rate sees only post-change performance (management fees are
        // time-based and need no rebase). Raise-only: a rate change while the vault is below
        // its high-water mark must not re-arm the fee on the recovery.
        if matches!(entry, VaultConfigField::PerformanceFeeBps) {
            vault_operations::raise_perf_fee_checkpoint(
                vault,
                &vault_scope_prices,
                obligations_aum,
            );
        }
    }

    msg!("Updating vault config field {:?}", entry);
    // Configuration changes wait only for a rebalance that can still be filled: the guards
    // inside compare the clock against the window, so an expired rebalance that nobody has
    // closed yet blocks nothing and needs no housekeeping here.
    vault.update_config(entry, data, current_timestamp)?;

    // A change to a token's Scope config shifts the price basis that `prev_aum` is measured
    // against. Without re-baselining, the next `charge_fees` books the pure valuation delta
    // (new-feed price - old-feed price) as vault performance — over-charging the performance fee
    // on an upward shift, or ratcheting the fee baseline down on a downward shift. Re-baseline
    // `prev_aum` to the AUM recomputed under the NEW config so only genuine post-change yield is
    // ever charged. The caller must therefore pass the scope-price + obligation accounts matching
    // the new config (same set `charge_fees` already requires).
    //
    // Only `VaultTokenScope` changes the *value* a price resolves to; the max-age and
    // twap-divergence fields change price *validation*, not the resolved value, so they need no
    // re-baseline.
    if matches!(entry, VaultConfigField::VaultTokenScope) {
        let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
            vault,
            ctx.remaining_accounts,
            clock.slot,
            current_timestamp,
        )?;
        vault_operations::update_prev_aum_if_not_negative(
            vault,
            &vault_scope_prices,
            obligations_aum,
        );
        // A Scope source change is an explicit valuation rebase, not vault performance. Reset the
        // performance price checkpoint as well so the feed change cannot create a fee windfall
        // beyond the checkpoint's price-quantization dust (the floored per-share price loses up
        // to ~shares_issued 2^-60 quanta when `charge_fees` reconstructs its dollar value).
        vault_operations::reanchor_perf_fee_checkpoint(vault, &vault_scope_prices, obligations_aum);
    }

    Ok(())
}

fn validate_update_authority(
    vault: &MetavaultState,
    authority: Pubkey,
    entry: VaultConfigField,
    data: &[u8],
) -> Result<()> {
    if authority == vault.vault_admin_authority {
        return Ok(());
    }

    let is_allocation_admin = vault.allocation_admin_authority != Pubkey::default()
        && authority == vault.allocation_admin_authority;
    if is_allocation_admin && matches!(entry, VaultConfigField::TokenWeights) {
        return Ok(());
    }

    let is_emergency_council =
        vault.emergency_council != Pubkey::default() && authority == vault.emergency_council;
    let is_unfreeze_authority =
        vault.unfreeze_authority != Pubkey::default() && authority == vault.unfreeze_authority;

    if is_emergency_council || is_unfreeze_authority {
        let is_emergency_flag = matches!(
            entry,
            VaultConfigField::EmergencyMode
                | VaultConfigField::BlockDeposits
                | VaultConfigField::BlockWithdraws
        );
        require!(is_emergency_flag, KaminoVaultError::AdminAuthorityIncorrect);

        let mut data = data;
        let value = u8::deserialize(&mut data)?;
        let emergency_council_can_freeze = is_emergency_council && value == 1;
        let unfreeze_authority_can_unfreeze = is_unfreeze_authority && value == 0;
        require!(
            emergency_council_can_freeze || unfreeze_authority_can_unfreeze,
            KaminoVaultError::AdminAuthorityIncorrect
        );
        return Ok(());
    }

    err!(KaminoVaultError::AdminAuthorityIncorrect)
}

#[derive(Accounts)]
pub struct UpdateVaultConfig<'info> {
    pub vault_admin_authority: Signer<'info>,

    #[account(mut)]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts (only read for the fee and scope fields): see
    // `load_scope_prices_and_obligations_aum`.
}

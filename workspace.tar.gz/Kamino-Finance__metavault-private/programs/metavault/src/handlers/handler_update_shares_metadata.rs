use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_2022::Token2022;
use spl_token_metadata_interface::state::Field;

use crate::{utils::token22_metadata, MetavaultState};

pub fn process(
    ctx: Context<UpdateSharesMetadata>,
    name: String,
    symbol: String,
    uri: String,
) -> Result<()> {
    let vault_state_key = ctx.accounts.vault_state.key();
    let accounts = token22_metadata::SharesMetadataAccounts {
        shares_mint: &ctx.accounts.shares_mint,
        base_vault_authority: &ctx.accounts.base_vault_authority,
        shares_token_program: &ctx.accounts.shares_token_program.to_account_info(),
        vault_state_key,
        base_vault_authority_bump: ctx.accounts.vault_state.load()?.base_vault_authority_bump,
    };
    token22_metadata::cpi_update_fields(
        &accounts,
        &ctx.accounts.vault_admin_authority.to_account_info(),
        &ctx.accounts.system_program.to_account_info(),
        vec![
            (Field::Name, name),
            (Field::Symbol, symbol),
            (Field::Uri, uri),
        ],
    )
}

#[derive(Accounts)]
pub struct UpdateSharesMetadata<'info> {
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(
        has_one = vault_admin_authority,
        has_one = shares_mint,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Pinned by `has_one` on `vault_state`; holds its own TokenMetadata.
    #[account(mut)]
    pub shares_mint: AccountInfo<'info>,

    /// CHECK: Pinned by `has_one` on `vault_state`; metadata update authority.
    pub base_vault_authority: AccountInfo<'info>,

    pub shares_token_program: Program<'info, Token2022>,
    pub system_program: Program<'info, System>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

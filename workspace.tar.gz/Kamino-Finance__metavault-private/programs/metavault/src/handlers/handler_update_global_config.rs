use anchor_lang::prelude::*;

use crate::{
    utils::{consts::GLOBAL_CONFIG_STATE_SEEDS, global_config::UpdateGlobalConfigMode},
    GlobalConfig,
};

pub fn process(
    ctx: Context<UpdateGlobalConfig>,
    mode: UpdateGlobalConfigMode,
    value: Vec<u8>,
) -> Result<()> {
    let global_config = &mut ctx.accounts.global_config.load_mut()?;

    global_config.update_value(mode, &value)?;

    Ok(())
}

#[derive(Accounts)]
pub struct UpdateGlobalConfig<'info> {
    pub global_admin: Signer<'info>,

    #[account(
        mut,
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
        has_one = global_admin)]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};
use anchor_spl::{
    token_2022::Token2022,
    token_interface::{Mint, TokenAccount},
};

use crate::{
    events::{RebalanceEndWatch, WithdrawOrderOpenedEvent},
    operations::{
        effects::OpenWithdrawOrderEffects, vault_checks::check_shares_burned,
        withdraw_order_operations::open_withdraw_order,
    },
    order::WithdrawOrder,
    types::{Duration, RebalanceLimits, ShareAmount, Timestamp, TokenAmount, Weight},
    utils::{
        consts::{
            GLOBAL_CONFIG_STATE_SEEDS, MAX_ORDERS_PER_OWNER, WITHDRAW_ORDER_SEED,
            WITHDRAW_ORDER_SIZE,
        },
        obligations::load_scope_prices_and_obligations_aum,
        token_acl::require_immutable_owner_if_permissioned,
        token_ops::shares,
    },
    GlobalConfig, KaminoVaultError, MetavaultState,
};

/// Burns the owner's shares for a pro-rata slice of the vault's liquid tokens, released into a new
/// order (physically staying in the vault's TAs), and starts its auction toward the owner's
/// weights. Moves no token, so needs no token accounts.
#[allow(clippy::too_many_arguments)]
pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, OpenWithdrawOrder<'info>>,
    id: u8,
    shares_amount: u64,
    weights: Vec<u64>,
    duration_seconds: u64,
    min_tokens_out: Vec<u64>,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<()> {
    crate::check_cpi!(ctx);

    require!(
        !ctx.accounts.owner_shares_ata.is_frozen(),
        KaminoVaultError::SharesAccountFrozen
    );

    // Parse/validate args:
    require!(id < MAX_ORDERS_PER_OWNER, KaminoVaultError::InvalidOrderId);
    let limits = RebalanceLimits::new(max_fill_slippage_bps, max_loss_bps)?;
    let duration = Duration::from(duration_seconds);
    let weights = weights.into_iter().map(Weight::from).collect::<Vec<_>>();
    let min_tokens_out = min_tokens_out
        .into_iter()
        .map(TokenAmount::from)
        .collect::<Vec<_>>();

    // Regular accounts:
    let vault_state_key = ctx.accounts.vault_state.key();
    let order_key = ctx.accounts.withdraw_order.key();
    let owner_key = ctx.accounts.owner.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    require_immutable_owner_if_permissioned(
        vault_state,
        &ctx.accounts.owner_shares_ata.to_account_info(),
    )?;
    let global_config = &ctx.accounts.global_config.load()?;
    let clock = &Clock::get()?;
    let current_timestamp = Timestamp::capture(clock)?;
    let mut order = ctx.accounts.withdraw_order.load_init()?;
    *order = WithdrawOrder::new(vault_state_key, owner_key, id);

    // Remaining accounts: (prices and obligations)
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;

    // Capture values for the post-checks:
    let user_shares_before =
        ShareAmount::of_account(&ctx.accounts.owner_shares_ata.to_account_info())?;
    let shares_issued_before = vault_state.shares_issued_amount();
    let shares = ShareAmount::from(shares_amount).min(user_shares_before); // clamped, as the plain withdraw does

    // The accounting update:
    let rebalance_watch = RebalanceEndWatch::open(vault_state_key, vault_state, current_timestamp);
    let OpenWithdrawOrderEffects {
        shares_to_burn,
        fee_shares_to_mint,
        released,
    } = open_withdraw_order(
        &mut order,
        vault_state,
        &vault_scope_prices,
        obligations_aum,
        global_config,
        shares,
        &weights,
        duration,
        limits,
        &min_tokens_out,
        current_timestamp,
    )?;

    // Effects: burn the shares (the released tokens stay where they are, now owned by the order):
    shares::burn(
        ctx.accounts.shares_mint.to_account_info(),
        ctx.accounts.owner_shares_ata.to_account_info(),
        ctx.accounts.owner.to_account_info(),
        ctx.accounts.shares_token_program.to_account_info(),
        shares_to_burn,
    )?;

    // Post-checks (no token moved, so the shares are all there is to reconcile):
    check_shares_burned(
        user_shares_before,
        ShareAmount::of_account(&ctx.accounts.owner_shares_ata.to_account_info())?,
        shares_issued_before,
        vault_state.shares_issued_amount(),
        shares_to_burn,
        fee_shares_to_mint,
    )?;

    // Events:
    emit_cpi!(WithdrawOrderOpenedEvent {
        vault_state: vault_state_key,
        order: order_key,
        owner: owner_key,
        shares_burned: shares_to_burn.into(),
        released: released.map(u64::from),
        timestamp: current_timestamp.into(),
        rebalance_end_timestamp: order
            .base
            .rebalance
            .window()
            .map_or(0, |window| window.end.into()),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(vault_state) {
        emit_cpi!(ended_event);
    }

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
#[instruction(id: u8)]
pub struct OpenWithdrawOrder<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(mut,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    #[account(
        init,
        payer = owner,
        space = 8 + WITHDRAW_ORDER_SIZE,
        seeds = [WITHDRAW_ORDER_SEED, vault_state.key().as_ref(), owner.key().as_ref(), &[id]],
        bump,
    )]
    pub withdraw_order: AccountLoader<'info, WithdrawOrder>,

    #[account(mut,
        mint::token_program = shares_token_program
    )]
    pub shares_mint: Box<InterfaceAccount<'info, Mint>>,

    /// Where the shares are burned from.
    #[account(mut,
        token::mint = shares_mint,
        token::authority = owner,
        token::token_program = shares_token_program,
    )]
    pub owner_shares_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    pub shares_token_program: Program<'info, Token2022>,

    pub system_program: Program<'info, System>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

use anchor_lang::prelude::*;

use crate::{
    events::{RebalanceEndWatch, VaultRefreshedEvent},
    operations::{effects::RefreshVaultEffects, vault_operations},
    types::Timestamp,
    utils::obligations::load_scope_prices_and_obligations_aum,
    MetavaultState,
};

pub fn process<'info>(ctx: Context<'_, '_, 'info, 'info, RefreshVault<'info>>) -> Result<()> {
    crate::check_cpi!(ctx);

    let vault_state_key = ctx.accounts.vault_state.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;

    let rebalance_watch = RebalanceEndWatch::open(vault_state_key, vault_state, current_timestamp);
    let RefreshVaultEffects { fee_shares_to_mint } = vault_operations::refresh_vault(
        vault_state,
        &vault_scope_prices,
        obligations_aum,
        current_timestamp,
    )?;

    emit_cpi!(VaultRefreshedEvent {
        vault_state: vault_state_key,
        timestamp: current_timestamp.into(),
        fee_shares_to_mint: fee_shares_to_mint.into(),
        prev_aum_sf: vault_state.prev_aum().to_bits(),
        pending_fees_sf: vault_state.pending_fees().to_bits(),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(vault_state) {
        emit_cpi!(ended_event);
    }

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct RefreshVault<'info> {
    #[account(mut)]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

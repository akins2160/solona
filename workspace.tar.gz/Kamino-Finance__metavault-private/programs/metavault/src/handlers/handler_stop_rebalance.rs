use anchor_lang::prelude::*;

use crate::{
    events::RebalanceEndWatch, operations::rebalance_operations, state::MetavaultState,
    types::Timestamp, KaminoVaultError,
};

pub fn process<'info>(ctx: Context<'_, '_, 'info, 'info, StopRebalance<'info>>) -> Result<()> {
    let vault_state_key = ctx.accounts.vault_state.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;

    let rebalance_watch = RebalanceEndWatch::open(vault_state_key, vault_state, current_timestamp);
    rebalance_operations::stop_rebalance(vault_state)?;

    emit_cpi!(rebalance_watch.on_admin_stop());

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct StopRebalance<'info> {
    pub authority: Signer<'info>,

    #[account(mut,
        constraint = vault_state.load()?.is_allocation_authority(authority.key())
            @ KaminoVaultError::AllocationAuthorityIncorrect,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

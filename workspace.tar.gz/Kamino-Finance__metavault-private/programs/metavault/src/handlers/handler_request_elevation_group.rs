use anchor_lang::{prelude::*, Accounts};
use kamino_lending::{LendingMarket, Obligation};

use crate::{
    events::ObligationElevationGroupChangedEvent,
    operations::vault_checks::check_elevation_group_ltv_ceiling,
    utils::{
        consts::BASE_VAULT_AUTHORITY_SEED,
        obligation_cpi::{
            active_borrow_reserves, active_deposit_reserves, check_forwarded_reserves,
            cpi_request_elevation_group,
        },
    },
    KaminoVaultError, MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, RequestElevationGroup<'info>>,
    new_elevation_group: u8,
) -> Result<()> {
    let vault = ctx.accounts.vault_state.load()?;
    let base_vault_authority_bump = vault.base_vault_authority_bump;

    let obligation_pk = ctx.accounts.obligation.key();
    let vault_obligation_id = vault.get_obligation_id_by_address(&obligation_pk)?;
    // Copied out (VaultObligation is `Copy`) so the LTV check below doesn't need to hold a
    // borrow of `vault` across the CPI.
    let vault_obligation = vault.obligations[vault_obligation_id.storage_index];

    // The elevation-group change does not move vault liquidity, and the inputs metavault reads
    // for AUM (per-leg ctoken/borrowed amounts and the reserves' collateral exchange rates,
    // valued at the vault's own scope prices) are invariant under LTV-envelope changes. Skip
    // the full obligation-op dance; the LTV envelope itself is re-checked below.
    {
        let obligation = ctx.accounts.obligation.load()?;
        check_forwarded_reserves(
            ctx.remaining_accounts,
            active_deposit_reserves(&obligation).chain(active_borrow_reserves(&obligation)),
        )?;
    }
    cpi_request_elevation_group(
        ctx.accounts,
        ctx.remaining_accounts,
        base_vault_authority_bump,
        new_elevation_group,
    )?;

    // Post-CPI LTV ceiling check: the switch changes the borrow factors and liquidation
    // thresholds the ceiling measures, and klend only enforces the destination group's own
    // max-LTV allowance. The leading remaining accounts are the deposit reserves (checked
    // against the active deposits above).
    {
        let obligation = ctx.accounts.obligation.load()?;
        let lending_market = ctx.accounts.lending_market.load()?;
        let deposit_reserves = ctx
            .remaining_accounts
            .get(..obligation.active_deposits_count())
            .ok_or_else(|| error!(KaminoVaultError::ObligationAccountMissing))?;
        check_elevation_group_ltv_ceiling(
            &vault_obligation,
            &lending_market,
            &obligation,
            deposit_reserves,
        )?;
    }

    emit_cpi!(ObligationElevationGroupChangedEvent {
        storage_index: vault_obligation_id.storage_index as u8,
        obligation: obligation_pk,
        new_elevation_group,
    });

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct RequestElevationGroup<'info> {
    pub authority: Signer<'info>,

    #[account(
        constraint = vault_state.load()?.is_allocation_authority(authority.key())
            @ KaminoVaultError::AllocationAuthorityIncorrect,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: PDA — signs the klend CPI as the obligation owner.
    #[account(seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    /// One of the vault's registered obligations (looked up in the handler); loaded post-CPI for
    /// the LTV ceiling check.
    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub obligation: AccountLoader<'info, Obligation>,

    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// CHECK: the klend program (address-pinned).
    #[account(address = kamino_lending::ID)]
    pub lending_program: AccountInfo<'info>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: forwarded verbatim to klend's `request_elevation_group` —
    // `[deposit_reserves...][borrow_reserves...]`, the obligation's active positions in its own
    // order (the referrer segment is empty: metavault never sets a referrer on its obligations).
    // Klend mutates the reserve elevation-group debt trackers, so all are passed as writable.
}

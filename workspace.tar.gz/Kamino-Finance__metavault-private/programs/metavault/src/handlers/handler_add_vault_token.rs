use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_interface::{Mint, TokenInterface};
use kamino_lending::utils::{
    account_ops::initialize_pda_token_account,
    constraints::token_2022::check_only_supported_liquidity_token_extensions,
};
use kamino_lending::ScopeConfiguration;

use crate::{
    types::Timestamp,
    utils::consts::{BASE_VAULT_AUTHORITY_SEED, TOKEN_VAULT_SEED},
    KaminoVaultError, MetavaultState,
};

pub fn process(ctx: Context<AddVaultToken>, scope_configuration: ScopeConfiguration) -> Result<()> {
    let token_mint_key = ctx.accounts.token_mint.key();
    let vault_state_key = ctx.accounts.vault_state.to_account_info().key();
    let token_vault_signer_seeds: &[&[u8]] = &[
        TOKEN_VAULT_SEED,
        token_mint_key.as_ref(),
        vault_state_key.as_ref(),
        &[ctx.bumps.token_vault],
    ];

    initialize_pda_token_account(
        &ctx.accounts.vault_admin_authority.to_account_info(),
        &ctx.accounts.token_vault,
        &ctx.accounts.token_mint,
        &ctx.accounts.base_vault_authority,
        &ctx.accounts.token_program,
        &ctx.accounts.system_program.to_account_info(),
        &[token_vault_signer_seeds],
    )?;

    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.token_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;

    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    vault_state.add_vault_token_if_not_present(
        ctx.accounts.token_mint.key(),
        ctx.accounts.token_vault.key(),
        ctx.accounts.token_program.key(),
        ctx.accounts.token_mint.decimals,
        scope_configuration,
        Timestamp::capture(&Clock::get()?)?,
    )?;

    Ok(())
}

#[derive(Accounts)]
pub struct AddVaultToken<'info> {
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(mut,
        has_one = vault_admin_authority,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: PDA owned by the program
    #[account(seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Initialized manually via initialize_pda_token_account
    #[account(mut,
        seeds = [TOKEN_VAULT_SEED, token_mint.key().as_ref(), vault_state.key().as_ref()],
        bump,
    )]
    pub token_vault: AccountInfo<'info>,

    #[account(
        constraint = token_mint.key() != vault_state.load()?.shares_mint
            @ KaminoVaultError::VaultTokenIsSharesMint,
        mint::token_program = token_program
    )]
    pub token_mint: Box<InterfaceAccount<'info, Mint>>,

    pub token_program: Interface<'info, TokenInterface>,
    pub system_program: Program<'info, System>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

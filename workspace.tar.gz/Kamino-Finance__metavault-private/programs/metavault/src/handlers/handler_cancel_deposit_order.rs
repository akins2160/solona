use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};

use crate::{
    events::{DepositOrderClosedEvent, DepositOrderEndReason},
    operations::{deposit_order_operations::cancel_deposit_order, effects::OrderPayoutEffects},
    order::DepositOrder,
    types::Timestamp,
    utils::{order_accounts::PayoutAccounts, remaining_accounts::RemainingAccounts, token_ops},
    KaminoVaultError, MetavaultState,
};

/// Refunds everything the order holds to its owner and deletes it, cancelling a running auction.
/// Only the owner may do this, at any time. Needs no prices.
pub fn process<'info>(ctx: Context<'_, '_, 'info, 'info, CancelDepositOrder<'info>>) -> Result<()> {
    crate::check_cpi!(ctx);

    // Regular accounts:
    let vault_state_key = ctx.accounts.vault_state.key();
    let order_key = ctx.accounts.deposit_order.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let mut order = ctx.accounts.deposit_order.load_mut()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;

    // Remaining accounts: (one payout set per token the order holds, parsed before it is emptied)
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let payout_accounts = PayoutAccounts::parse(&*order, vault_state, true, &mut remaining)?;
    remaining.check_none_remaining()?;

    // The accounting update:
    let OrderPayoutEffects {
        payouts,
        mid_auction,
    } = cancel_deposit_order(&mut order, vault_state, current_timestamp);

    // Effects: send each refunded token back to the owner's TA:
    token_ops::composites::transfer_all_payouts(
        &payout_accounts.per_token,
        &payouts,
        vault_state.base_vault_authority_bump,
        &ctx.accounts.vault_state.to_account_info(),
        &ctx.accounts.base_vault_authority.to_account_info(),
    )?;

    // Post-checks:
    payout_accounts.check_vault_balances_cover_locked(vault_state)?;

    // Events:
    emit_cpi!(DepositOrderClosedEvent {
        vault_state: vault_state_key,
        order: order_key,
        shares_minted: 0,
        refunds: payouts.map(u64::from),
        reason: if mid_auction {
            DepositOrderEndReason::CancelledMidAuction
        } else {
            DepositOrderEndReason::Cancelled
        },
        timestamp: current_timestamp.into(),
    });

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct CancelDepositOrder<'info> {
    /// Receives the rent and owns the refund TAs.
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(mut,
        constraint = deposit_order.load()?.base.vault_state == vault_state.key()
            @ KaminoVaultError::OrderAccountMismatch,
        constraint = deposit_order.load()?.base.owner == owner.key()
            @ KaminoVaultError::OrderAccountMismatch,
        close = owner,
    )]
    pub deposit_order: AccountLoader<'info, DepositOrder>,

    /// CHECK: vault_state has_one check
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: the payout accounts per token held, see `PayoutAccounts::parse`.
}

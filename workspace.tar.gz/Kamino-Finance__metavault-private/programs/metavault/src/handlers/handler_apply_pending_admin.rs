use anchor_lang::prelude::*;

use crate::MetavaultState;

pub fn process(ctx: Context<ApplyPendingAdmin>) -> Result<()> {
    let vault = &mut ctx.accounts.vault_state.load_mut()?;

    msg!(
        "Update admin from {} to {}",
        vault.vault_admin_authority,
        vault.pending_admin
    );
    vault.vault_admin_authority = vault.pending_admin;
    vault.pending_admin = Pubkey::default();
    vault.allocation_admin_authority = Pubkey::default();

    Ok(())
}

#[derive(Accounts)]
pub struct ApplyPendingAdmin<'info> {
    #[account(mut)]
    pub pending_admin: Signer<'info>,

    #[account(mut,
        has_one = pending_admin,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};
use anchor_spl::{
    token_2022::Token2022,
    token_interface::{Mint, TokenAccount, TokenInterface},
};
use kamino_lending::utils::token_2022::check_only_supported_liquidity_token_extensions;

use crate::{
    events::{RebalanceEndWatch, SharesToWithdrawEvent, WithdrawResultEvent},
    operations::{
        effects::WithdrawEffects,
        vault_checks::{
            check_vault_balance_covers_locked, post_transfer_withdraw_checks,
            VaultOperationBalances,
        },
        vault_operations,
    },
    types::{ShareAmount, Timestamp, TokenAmount},
    utils::{
        consts::{GLOBAL_CONFIG_STATE_SEEDS, TOKEN_VAULT_SEED},
        obligations::load_scope_prices_and_obligations_aum,
        token_acl::require_immutable_owner_if_permissioned,
        token_ops::{self, shares},
    },
    GlobalConfig, KaminoVaultError, MetavaultState,
};

pub fn withdraw<'info>(
    ctx: Context<'_, '_, 'info, 'info, Withdraw<'info>>,
    shares_amount: u64,
    min_tokens_out: u64,
) -> Result<()> {
    crate::check_cpi!(ctx);

    // The burn's source; frozen on a permissioned vault until thawed through its gate.
    require!(
        !ctx.accounts.user_shares_ata.is_frozen(),
        KaminoVaultError::SharesAccountFrozen
    );
    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.token_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    require!(
        vault_state.block_withdraws == 0,
        KaminoVaultError::VaultWithdrawsBlocked
    );
    // (The leg that matters most: an account handed to an address the gate would reject must not
    // redeem here.)
    require_immutable_owner_if_permissioned(
        vault_state,
        &ctx.accounts.user_shares_ata.to_account_info(),
    )?;

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;
    let global_config = &ctx.accounts.global_config.load()?;

    let min_tokens_out = TokenAmount::from(min_tokens_out);

    // Cache some values for withdraw from available
    let token_vault_before = TokenAmount::of_account(&ctx.accounts.token_vault.to_account_info())?;
    let user_ata_before = TokenAmount::of_account(&ctx.accounts.user_token_ata.to_account_info())?;
    let user_shares_before =
        ShareAmount::of_account(&ctx.accounts.user_shares_ata.to_account_info())?;
    let initial_vault_shares_issued = vault_state.shares_issued_amount();

    // if the user asks to withdraw more shares than they have, withdraw all the shares they have
    let shares_amount = ShareAmount::from(shares_amount).min(user_shares_before);
    let shares_to_withdraw_event = SharesToWithdrawEvent {
        shares_amount: shares_amount.into(),
        user_shares_before: user_shares_before.into(),
    };

    let rebalance_watch = RebalanceEndWatch::open(
        ctx.accounts.vault_state.key(),
        vault_state,
        current_timestamp,
    );
    let WithdrawEffects {
        shares_to_burn,
        available_to_send_to_user,
        fee_shares_to_mint,
    } = vault_operations::withdraw(
        vault_state,
        &vault_scope_prices,
        obligations_aum,
        global_config,
        ctx.accounts.token_mint.key(),
        current_timestamp,
        shares_amount,
    )?;

    require_gte!(
        available_to_send_to_user,
        min_tokens_out,
        KaminoVaultError::SlippageExceeded
    );

    let withdraw_result_event = WithdrawResultEvent {
        shares_to_burn: shares_to_burn.into(),
        available_to_send_to_user: available_to_send_to_user.into(),
    };

    // 1. Burn shares
    shares::burn(
        ctx.accounts.shares_mint.to_account_info(),
        ctx.accounts.user_shares_ata.to_account_info(),
        ctx.accounts.user.to_account_info(),
        ctx.accounts.shares_token_program.to_account_info(),
        shares_to_burn,
    )?;

    // 2. Send all the owed tokens to user
    token_ops::tokens::transfer_to_token_account(
        &token_ops::tokens::VaultTransferAccounts {
            token_program: ctx.accounts.token_program.to_account_info(),
            token_vault: ctx.accounts.token_vault.to_account_info(),
            token_ata: ctx.accounts.user_token_ata.to_account_info(),
            token_mint: ctx.accounts.token_mint.to_account_info(),
            base_vault_authority: ctx.accounts.base_vault_authority.to_account_info(),
            vault_state: ctx.accounts.vault_state.to_account_info(),
        },
        vault_state.base_vault_authority_bump,
        available_to_send_to_user,
        ctx.accounts.token_mint.decimals,
    )?;

    let token_vault_after = TokenAmount::of_account(&ctx.accounts.token_vault.to_account_info())?;
    let user_ata_after = TokenAmount::of_account(&ctx.accounts.user_token_ata.to_account_info())?;
    let user_shares_after =
        ShareAmount::of_account(&ctx.accounts.user_shares_ata.to_account_info())?;

    // Post checks
    post_transfer_withdraw_checks(
        &VaultOperationBalances {
            user_shares_balance_before: user_shares_before,
            user_shares_balance_after: user_shares_after,
            user_token_balances_before: vec![user_ata_before],
            user_token_balances_after: vec![user_ata_after],
            vault_shares_issued_before: initial_vault_shares_issued,
            vault_shares_issued_after: vault_state.shares_issued_amount(),
            vault_token_balances_before: vec![token_vault_before],
            vault_token_balances_after: vec![token_vault_after],
        },
        shares_to_burn,
        &[available_to_send_to_user],
        fee_shares_to_mint,
    )?;
    check_vault_balance_covers_locked(
        token_vault_after,
        vault_state.get_vault_token_by_mint(&ctx.accounts.token_mint.key())?,
    )?;

    emit_cpi!(shares_to_withdraw_event);
    emit_cpi!(withdraw_result_event);
    if let Some(ended_event) = rebalance_watch.on_balances_changed(vault_state) {
        emit_cpi!(ended_event);
    }

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    #[account(mut,
        seeds=[TOKEN_VAULT_SEED, token_mint.key().as_ref(), vault_state.key().as_ref()],
        bump,
    )]
    pub token_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: has_one check in vault_state
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: vault_state checks the token mint and the token program
    #[account(mut,
        token::mint = token_mint.key(),
        token::authority = user,
        token::token_program = token_program,
    )]
    pub user_token_ata: InterfaceAccount<'info, TokenAccount>,

    /// CHECK: Validated via token_vault PDA seed derivation and get_vault_token_id_by_mint
    #[account(
        mint::token_program = token_program
    )]
    pub token_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(mut,
        token::mint = shares_mint,
        token::authority = user,
        token::token_program = shares_token_program,
    )]
    pub user_shares_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(mut,
        mint::token_program = shares_token_program
    )]
    pub shares_mint: Box<InterfaceAccount<'info, Mint>>,

    pub token_program: Interface<'info, TokenInterface>,
    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

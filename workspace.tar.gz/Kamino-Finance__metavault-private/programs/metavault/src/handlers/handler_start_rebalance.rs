use anchor_lang::prelude::*;

use crate::{
    events::{RebalanceEndWatch, RebalanceStartedEvent},
    operations::rebalance_operations,
    state::MetavaultState,
    types::{Duration, StartRebalanceAuthority, Timestamp},
    utils::obligations::load_scope_prices_and_obligations_aum,
    KaminoVaultError,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, StartRebalance<'info>>,
    rebalance_duration: u64,
) -> Result<()> {
    let vault_state_key = ctx.accounts.vault_state.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;

    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;

    let authority_kind = if ctx.accounts.authority.key() == vault_state.vault_admin_authority {
        StartRebalanceAuthority::VaultAdmin
    } else {
        StartRebalanceAuthority::AllocationDelegate
    };

    // A start first ends a rebalance that is over, and a new one is in progress by the time the
    // event is decided, so the watch answers from what it captured rather than from the vault.
    let rebalance_watch = RebalanceEndWatch::open(vault_state_key, vault_state, current_timestamp);
    rebalance_operations::start_rebalance(
        vault_state,
        Duration::from(rebalance_duration),
        &vault_scope_prices,
        obligations_aum,
        current_timestamp,
        authority_kind,
    )?;

    if let Some(ended_event) = rebalance_watch.on_new_rebalance_start() {
        emit_cpi!(ended_event);
    }

    emit_cpi!(RebalanceStartedEvent {
        vault_state: vault_state_key,
        duration: rebalance_duration,
        start_timestamp: current_timestamp.into(),
    });

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct StartRebalance<'info> {
    pub authority: Signer<'info>,

    #[account(mut,
        constraint = vault_state.load()?.is_allocation_authority(authority.key())
            @ KaminoVaultError::AllocationAuthorityIncorrect,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

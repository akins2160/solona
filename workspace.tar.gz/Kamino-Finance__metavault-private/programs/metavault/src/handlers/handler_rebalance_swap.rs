use anchor_lang::prelude::*;
use anchor_spl::token_interface::{Mint, TokenAccount, TokenInterface};
use kamino_lending::utils::token_2022::check_only_supported_liquidity_token_extensions;

use crate::{
    events::{OrderFillEvent, RebalanceEndReason, RebalanceEndedEvent, RebalanceSwapEvent},
    operations::{
        effects::RebalanceFillEffects,
        order_basket::{self, Order},
        rebalance_operations::{self, FillRequest},
        vault_checks::{
            check_vault_balance_covers_locked, post_transfer_swap_checks, SwapBalances,
        },
    },
    order::{DepositOrder, WithdrawOrder},
    state::MetavaultState,
    types::{Timestamp, TokenAmount},
    utils::{
        consts::{GLOBAL_CONFIG_STATE_SEEDS, TOKEN_VAULT_SEED},
        obligations::load_scope_prices_and_obligations_aum,
        pda,
        remaining_accounts::RemainingAccounts,
        scope::VaultScopePrices,
        token_ops::{
            self,
            tokens::{UserTransferAccounts, VaultTransferAccounts},
        },
    },
    GlobalConfig, KaminoVaultError,
};

/// One fill, against the vault or (when one of the two order accounts is present) against an order.
pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, RebalanceSwap<'info>>,
    amount_in: u64,
    requested_out_amount: u64,
) -> Result<()> {
    let accounts = &ctx.accounts;
    crate::check_cpi!(ctx);

    // Both arms move this same pair of TAs (an order's tokens sit in the vault's own TAs).
    check_only_supported_liquidity_token_extensions(
        &accounts.token_in_mint.to_account_info(),
        &accounts.token_in_vault.to_account_info(),
    )?;
    check_only_supported_liquidity_token_extensions(
        &accounts.token_out_mint.to_account_info(),
        &accounts.token_out_vault.to_account_info(),
    )?;
    require_gt!(amount_in, 0, KaminoVaultError::DepositAmountsZero);

    // Input accounts and args parsing/validation:
    let vault_state_key = accounts.vault_state.key();
    let order_key = accounts
        .deposit_order
        .as_ref()
        .map(Key::key)
        .or_else(|| accounts.withdraw_order.as_ref().map(Key::key));
    let token_in_mint_key = accounts.token_in_mint.key();
    let token_out_mint_key = accounts.token_out_mint.key();
    let vault_state = &mut accounts.vault_state.load_mut()?;
    let global_config = &accounts.global_config.load()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;

    vault_state.validate_swap_authority(accounts.user.key())?;
    validate_krfq_gate(
        vault_state,
        global_config,
        accounts.krfq_authority.as_ref(),
        &KrfqFillIdentity {
            basket: order_key.unwrap_or(vault_state_key),
            token_in_mint: token_in_mint_key,
            token_out_mint: token_out_mint_key,
        },
        accounts.krfq_fill_marker.as_ref(),
    )?;

    let request = FillRequest {
        token_in_mint: token_in_mint_key,
        token_out_mint: token_out_mint_key,
        amount_in: TokenAmount::from(amount_in),
        requested_out_amount: TokenAmount::from(requested_out_amount),
        now: current_timestamp,
    };

    // Capture values for the post-checks:
    let balances_before = SwapBalances::capture(accounts)?;

    // The accounting updates: (depending on whether we do the vault's rebalance, or the deposit/withdraw order's)
    let RebalanceFillEffects {
        amount_in,
        rebalance_ended,
    } = match (&accounts.deposit_order, &accounts.withdraw_order) {
        (None, None) => {
            let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
                vault_state,
                ctx.remaining_accounts,
                clock.slot,
                current_timestamp,
            )?;
            rebalance_operations::calculate_rebalance_swap(
                vault_state,
                &vault_scope_prices,
                obligations_aum,
                request,
            )?
        }
        // Note: the 2 cases below are actually NOT same, cannot deduplicate (different generic type argument):
        (Some(order), _) => load_prices_and_fill_order(
            &mut *order.load_mut()?,
            vault_state,
            ctx.remaining_accounts,
            current_timestamp,
            request,
        )?,
        (_, Some(order)) => load_prices_and_fill_order(
            &mut *order.load_mut()?,
            vault_state,
            ctx.remaining_accounts,
            current_timestamp,
            request,
        )?,
    };

    // Effects: (the transfers)
    token_ops::tokens::transfer_to_vault(
        &UserTransferAccounts {
            token_program: accounts.token_in_program.to_account_info(),
            user_authority: accounts.user.to_account_info(),
            token_ata: accounts.user_token_in_ata.to_account_info(),
            token_vault: accounts.token_in_vault.to_account_info(),
            token_mint: accounts.token_in_mint.to_account_info(),
        },
        amount_in,
        accounts.token_in_mint.decimals,
    )?;
    token_ops::tokens::transfer_to_token_account(
        &VaultTransferAccounts {
            token_program: accounts.token_out_program.to_account_info(),
            token_vault: accounts.token_out_vault.to_account_info(),
            token_ata: accounts.user_token_out_ata.to_account_info(),
            token_mint: accounts.token_out_mint.to_account_info(),
            base_vault_authority: accounts.base_vault_authority.to_account_info(),
            vault_state: accounts.vault_state.to_account_info(),
        },
        vault_state.base_vault_authority_bump,
        request.requested_out_amount,
        accounts.token_out_mint.decimals,
    )?;

    // Post-checks:
    let balances_after = SwapBalances::capture(accounts)?;
    post_transfer_swap_checks(
        &balances_before,
        &balances_after,
        amount_in,
        request.requested_out_amount,
    )?;
    check_vault_balance_covers_locked(
        balances_after.vault_token_in,
        vault_state.get_vault_token_by_mint(&token_in_mint_key)?,
    )?;
    check_vault_balance_covers_locked(
        balances_after.vault_token_out,
        vault_state.get_vault_token_by_mint(&token_out_mint_key)?,
    )?;

    // Events:
    match order_key {
        None => {
            emit_cpi!(RebalanceSwapEvent {
                vault_state: vault_state_key,
                token_in_mint: token_in_mint_key,
                token_out_mint: token_out_mint_key,
                amount_in: amount_in.into(),
                amount_out: request.requested_out_amount.into(),
                timestamp: current_timestamp.into(),
            });
            // (The fill itself reports whether it ended the rebalance.)
            if rebalance_ended {
                emit_cpi!(RebalanceEndedEvent {
                    vault_state: vault_state_key,
                    timestamp: current_timestamp.into(),
                    reason: RebalanceEndReason::Settled,
                });
            }
        }
        Some(order) => {
            emit_cpi!(OrderFillEvent {
                vault_state: vault_state_key,
                order,
                token_in_mint: token_in_mint_key,
                token_out_mint: token_out_mint_key,
                amount_in: amount_in.into(),
                amount_out: request.requested_out_amount.into(),
                auction_ended: rebalance_ended,
                timestamp: current_timestamp.into(),
            });
        }
    }
    Ok(())
}

impl SwapBalances {
    /// The swap's four balances as they are now.
    fn capture(accounts: &RebalanceSwap) -> Result<Self> {
        Ok(Self {
            user_token_in: TokenAmount::of_account(&accounts.user_token_in_ata.to_account_info())?,
            user_token_out: TokenAmount::of_account(
                &accounts.user_token_out_ata.to_account_info(),
            )?,
            vault_token_in: TokenAmount::of_account(&accounts.token_in_vault.to_account_info())?,
            vault_token_out: TokenAmount::of_account(&accounts.token_out_vault.to_account_info())?,
        })
    }
}

/// What the fill marker's address encodes: the basket filled and its ordered mint pair.
/// Ordered, so a fill in the opposite direction derives a different marker.
struct KrfqFillIdentity {
    /// The account krfq keys the opportunity on (the vault, or the order being filled).
    basket: Pubkey,

    token_in_mint: Pubkey,

    token_out_mint: Pubkey,
}

impl KrfqFillIdentity {
    /// The only address krfq's co-signature authorizes for this fill.
    fn marker(&self) -> Pubkey {
        pda::krfq_fill_marker(&self.basket, &self.token_in_mint, &self.token_out_mint)
    }
}

/// Enforces the vault's krfq exclusivity gate: when `krfq_enabled` is set, the fill
/// transaction must be co-signed by the krfq auction server, which proves the fill was
/// ingested, ranked and submitted through the auction. The server key lives in the global
/// config so one server-key rotation needs one metavault-side update, not one per vault.
/// An unset key fails closed: a gated vault must never fall back to permissionless fills.
///
/// The marker check is what makes krfq's own check meaningful. krfq compares the
/// marker against the opportunity it ranked; without the derivation enforced here, a
/// maker could carry the correct marker for that opportunity while naming a different
/// `vault_state` and mint pair in the instruction — krfq would co-sign, and a fill it
/// never authorized would execute. Deriving from the accounts actually used is what
/// ties the two halves together.
///
/// The marker half runs whenever a marker is supplied, **not** only when the vault is
/// gated. Restricting it to gated vaults left the forgery open one step to the side: a
/// maker bids into gated vault A's auction with a fill on an *ungated* vault B carrying
/// A's marker, the unconstrained slot passes, and krfq settles A's auction — retiring
/// its keeper's request — on a fill that never touched A. What the marker protects is
/// not vault B, which would indeed have accepted that fill permissionlessly; it is
/// krfq's record of which fill it co-signed. Refusing a marker that does not match the
/// accounts in front of it costs an ungated caller nothing, since such a caller has no
/// reason to pass one.
fn validate_krfq_gate(
    vault_state: &MetavaultState,
    global_config: &GlobalConfig,
    krfq_authority: Option<&Signer<'_>>,
    identity: &KrfqFillIdentity,
    krfq_fill_marker: Option<&AccountInfo<'_>>,
) -> Result<()> {
    // Keyed on the marker being present, not on `krfq_authority`: krfq binds a
    // bid on the marker slot whatever sits in the authority slot, so a check
    // conditioned on the authority would still let the forgery through.
    if let Some(marker) = krfq_fill_marker {
        require_keys_eq!(
            *marker.key,
            identity.marker(),
            KaminoVaultError::KrfqFillMarkerIncorrect
        );
    }

    if !vault_state.is_krfq_enabled() {
        return Ok(());
    }
    require_keys_neq!(
        global_config.krfq_swap_authority,
        Pubkey::default(),
        KaminoVaultError::KrfqSwapAuthorityNotSet
    );
    let krfq_authority = krfq_authority.ok_or(KaminoVaultError::KrfqAuthorityMissing)?;
    require_keys_eq!(
        krfq_authority.key(),
        global_config.krfq_swap_authority,
        KaminoVaultError::KrfqAuthorityIncorrect
    );
    // A gated vault additionally requires the marker to be there at all; the
    // derivation itself was already enforced above.
    krfq_fill_marker.ok_or(KaminoVaultError::KrfqFillMarkerMissing)?;
    Ok(())
}

fn load_prices_and_fill_order<'info, O: Order>(
    order: &mut O,
    vault_state: &mut MetavaultState,
    remaining_accounts: &'info [AccountInfo<'info>],
    current_timestamp: Timestamp,
    request: FillRequest,
) -> Result<RebalanceFillEffects> {
    let mut remaining_accounts = RemainingAccounts::new(remaining_accounts);
    let prices = VaultScopePrices::load_and_validate_from_remaining_accounts(
        vault_state,
        &mut remaining_accounts,
        current_timestamp,
    )?;
    remaining_accounts.check_none_remaining()?;

    order_basket::fill_order(order, vault_state, &prices, request)
}

#[event_cpi]
#[derive(Accounts)]
pub struct RebalanceSwap<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: vault_state has_one check
    pub base_vault_authority: AccountInfo<'info>,

    // Token IN (user provides)
    #[account(
        mint::token_program = token_in_program
    )]
    pub token_in_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(mut,
        seeds=[TOKEN_VAULT_SEED, token_in_mint.key().as_ref(), vault_state.key().as_ref()],
        bump,
    )]
    pub token_in_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(mut,
        token::mint = token_in_mint,
        token::authority = user,
        token::token_program = token_in_program,
    )]
    pub user_token_in_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    // Token OUT (vault provides)
    #[account(
        mint::token_program = token_out_program
    )]
    pub token_out_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(mut,
        seeds=[TOKEN_VAULT_SEED, token_out_mint.key().as_ref(), vault_state.key().as_ref()],
        bump,
    )]
    pub token_out_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(mut,
        token::mint = token_out_mint,
        token::authority = user,
        token::token_program = token_out_program,
    )]
    pub user_token_out_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    pub token_in_program: Interface<'info, TokenInterface>,
    pub token_out_program: Interface<'info, TokenInterface>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,

    /// The krfq auction server's gate co-signature. Required iff the vault has
    /// `krfq_enabled` set; must match `global_config.krfq_swap_authority`. The server
    /// signs purely as a gatekeeper: it owns no token account in this instruction and
    /// the token flows stay between `user` and the vault.
    pub krfq_authority: Option<Signer<'info>>,

    /// Holds the expected krfq co-signer key. Required iff the vault has `krfq_enabled` set.
    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    /// Address-only marker binding this fill to one vault and one mint pair, so
    /// krfq's gate co-signature cannot reach a different fill. Required iff the
    /// vault is gated; optional otherwise, but never ignored — whenever it is
    /// supplied its derivation is enforced, on the permissionless path too.
    ///
    /// Derivation is the entire contract and is checked in `validate_krfq_gate`
    /// rather than by a `seeds` constraint, so the two halves of the gate sit
    /// together. Never initialized, owned or read.
    ///
    /// CHECK: validated by PDA derivation in `validate_krfq_gate`.
    pub krfq_fill_marker: Option<AccountInfo<'info>>,

    /// The deposit order to fill instead of the vault (with both order accounts absent, the vault
    /// itself is filled).
    #[account(mut,
        constraint = deposit_order.load()?.base.vault_state == vault_state.key()
            @ KaminoVaultError::OrderAccountMismatch,
    )]
    pub deposit_order: Option<AccountLoader<'info, DepositOrder>>,

    /// The withdraw order to fill instead of the vault (never together with `deposit_order`).
    #[account(mut,
        constraint = withdraw_order.load()?.base.vault_state == vault_state.key()
            @ KaminoVaultError::OrderAccountMismatch,
        constraint = deposit_order.is_none() @ KaminoVaultError::InconsistentOrderAccounts,
    )]
    pub withdraw_order: Option<AccountLoader<'info, WithdrawOrder>>,
    // remaining_accounts: the whole AUM layout (vault fill), or just the scope prices (order fill).
}

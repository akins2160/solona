use anchor_lang::{prelude::*, Accounts};

use crate::{utils::token_acl, KaminoVaultError, MetavaultState};

pub fn process(
    ctx: Context<ToggleSharesPermissionless>,
    freeze_enabled: bool,
    thaw_enabled: bool,
) -> Result<()> {
    let vault = ctx.accounts.vault_state.load()?;
    token_acl::validate_permissioned_vault_accounts(
        &vault,
        ctx.accounts.shares_mint.key,
        &ctx.accounts.shares_mint_config,
    )?;

    let vault_state_key = ctx.accounts.vault_state.key();
    token_acl::cpi_toggle_permissionless(
        &token_acl::TokenAclCpiAccounts {
            token_acl_program: &ctx.accounts.token_acl_program,
            mint_config: &ctx.accounts.shares_mint_config,
            shares_mint: &ctx.accounts.shares_mint,
            base_vault_authority: &ctx.accounts.base_vault_authority,
            vault_state_key: &vault_state_key,
            base_vault_authority_bump: vault.base_vault_authority_bump,
        },
        freeze_enabled,
        thaw_enabled,
    )
}

#[derive(Accounts)]
pub struct ToggleSharesPermissionless<'info> {
    pub vault_admin_authority: Signer<'info>,

    #[account(
        has_one = vault_admin_authority,
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Pinned by `has_one` on `vault_state`; the token-acl config admin.
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Pinned by `has_one` on `vault_state`.
    pub shares_mint: AccountInfo<'info>,

    /// CHECK: Validated in the handler against the MintConfig PDA of the shares mint.
    #[account(mut)]
    pub shares_mint_config: AccountInfo<'info>,

    /// CHECK: Pinned program id.
    #[account(address = token_acl::TOKEN_ACL_PROGRAM_ID @ KaminoVaultError::TokenAclProgramIncorrect)]
    pub token_acl_program: AccountInfo<'info>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

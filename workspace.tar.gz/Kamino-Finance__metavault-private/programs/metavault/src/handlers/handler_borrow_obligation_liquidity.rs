use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
    Accounts,
};
use anchor_spl::token_interface::{Mint, TokenAccount, TokenInterface};
use kamino_lending::{
    utils::seeds::LENDING_MARKET_AUTH,
    utils::token_2022::check_only_supported_liquidity_token_extensions, LendingMarket, Obligation,
    Reserve,
};
use std::ops::Deref;

use crate::{
    events::{ObligationLiquidityBorrowEvent, RebalanceEndWatch},
    operations::{
        obligation_operations,
        vault_checks::{
            check_borrow_ltv_ceiling, check_reserve_price_basis, find_enabled_token_and_price,
            has_matching_scope_config, post_borrow_obligation_liquidity_checks,
            BorrowObligationLiquidityBalances,
        },
    },
    types::{Timestamp, TokenAmount},
    utils::{
        consts::{BASE_VAULT_AUTHORITY_SEED, FARMS_PROGRAM_ID, TOKEN_VAULT_SEED},
        obligation_cpi::{
            active_deposit_reserves, active_deposit_reserves_count, check_forwarded_reserves,
            cpi_borrow_obligation_liquidity,
            split_optional_leading_accounts_and_target_farm_accounts,
            split_trailing_target_farm_accounts,
        },
        obligations::load_scope_prices_and_obligations_aum_from,
        remaining_accounts::RemainingAccounts,
    },
    KaminoVaultError, MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, BorrowObligationLiquidity<'info>>,
    liquidity_amount: u64,
) -> Result<()> {
    let liquidity_amount = TokenAmount::from(liquidity_amount);

    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.borrow_reserve_liquidity_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;

    let mut vault = ctx.accounts.vault_state.load_mut()?;
    let base_vault_authority_bump = vault.base_vault_authority_bump;

    let vault_obligation_id = vault.get_obligation_id_by_address(&ctx.accounts.obligation.key())?;
    // Copied out (VaultObligation is `Copy`) so the LTV check below doesn't need to hold a
    // borrow of `vault` across the CPI.
    let vault_obligation = vault.obligations[vault_obligation_id.storage_index];

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let rebalance_watch =
        RebalanceEndWatch::open(ctx.accounts.vault_state.key(), &vault, current_timestamp);
    // The leading slots of `remaining_accounts` are the scope-price + obligation + leg-reserve
    // accounts (consumed by the AUM load). The trailing slots are optional deposit
    // reserves followed by optional debt-farm accounts. Klend only consumes the deposit
    // reserves when the obligation is in an elevation group, but the old client layout is
    // still accepted outside elevation groups. (Corner: with deposit legs and no borrow legs,
    // a pre-leg-segment caller's trailing deposit reserves are byte-identical to the
    // leg-reserve segment and parse as it — harmless, since every leg account is key-pinned
    // and klend doesn't need the forwarded reserves outside elevation groups, but such callers
    // break as soon as a borrow leg exists.)
    let target_farm = ctx.accounts.borrow_reserve.load()?.farm_debt;
    let (deposit_reserves_count, is_elevation_group_obligation) = {
        let obligation = ctx.accounts.obligation.load()?;
        (
            active_deposit_reserves_count(&obligation),
            obligation.elevation_group != 0,
        )
    };
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum_from(
        &vault,
        &mut remaining,
        clock.slot,
        current_timestamp,
    )?;
    let (deposit_reserves, farm_accounts) = if is_elevation_group_obligation {
        split_trailing_target_farm_accounts(
            remaining.rest(),
            deposit_reserves_count,
            target_farm,
            ctx.accounts.obligation.key(),
        )?
    } else {
        split_optional_leading_accounts_and_target_farm_accounts(
            remaining.rest(),
            deposit_reserves_count,
            target_farm,
            ctx.accounts.obligation.key(),
        )?
    };
    if !deposit_reserves.is_empty() {
        let obligation = ctx.accounts.obligation.load()?;
        check_forwarded_reserves(deposit_reserves, active_deposit_reserves(&obligation))?;
    }

    let liquidity_mint = ctx.accounts.borrow_reserve_liquidity_mint.key();
    let effects = {
        let reserve = ctx.accounts.borrow_reserve.load()?;
        let lending_market = ctx.accounts.lending_market.load()?;
        let obligation = ctx.accounts.obligation.load()?;
        // The gate is keyed off the reserve's own recorded mint (as the leg sweep does), not the
        // caller-supplied mint account.
        let (vault_token, token_price) = find_enabled_token_and_price(
            &vault,
            &vault_scope_prices,
            &reserve.liquidity.mint_pubkey,
        )?;
        check_reserve_price_basis(vault_token, token_price, &reserve)?;
        obligation_operations::borrow_obligation_liquidity(
            &mut vault,
            &vault_scope_prices,
            obligations_aum,
            &reserve,
            &lending_market,
            &obligation,
            &liquidity_mint,
            liquidity_amount,
            clock.slot,
            current_timestamp,
        )?
    };

    let pre_balances = capture_balances(ctx.accounts)?;

    cpi_borrow_obligation_liquidity(
        ctx.accounts,
        deposit_reserves,
        farm_accounts,
        base_vault_authority_bump,
        liquidity_amount,
    )?;

    let post_balances = capture_balances(ctx.accounts)?;

    emit_cpi!(ObligationLiquidityBorrowEvent {
        storage_index: vault_obligation_id.storage_index as u8,
        reserve: ctx.accounts.borrow_reserve.key(),
        amount: effects.liquidity_to_receive.into(),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(&vault) {
        emit_cpi!(ended_event);
    }

    post_borrow_obligation_liquidity_checks(&pre_balances, &post_balances, &effects)?;

    // Post-CPI LTV ceiling check. The obligation's aggregate values are refresh-time only —
    // klend's borrow mutates per-position amounts and marks the obligation stale, so the
    // aggregates reloaded here still carry the same-slot pre-op refresh: exactly the anchor
    // the delta needs. `effects.debt_increase` is klend's own `borrow_amount_f`, recomputed from
    // the same reserve state klend used: its integer part (`liquidity_to_receive +
    // origination_fee`) was just verified against the actual SPL movements by the balance
    // checks above, while its sub-lamport remainder is unobservable in any token balance by
    // construction.
    {
        let obligation = ctx.accounts.obligation.load()?;
        let reserve = ctx.accounts.borrow_reserve.load()?;
        check_borrow_ltv_ceiling(
            &vault_obligation,
            &reserve,
            &obligation,
            effects.debt_increase,
        )?;
    }

    Ok(())
}

fn capture_balances(
    accounts: &BorrowObligationLiquidity,
) -> Result<BorrowObligationLiquidityBalances> {
    Ok(BorrowObligationLiquidityBalances {
        vault_token_balance: TokenAmount::of_account(&accounts.token_vault.to_account_info())?,
        reserve_source_liquidity: TokenAmount::of_account(&accounts.reserve_source_liquidity)?,
        reserve_liquidity_fee_receiver: TokenAmount::of_account(
            &accounts.borrow_reserve_liquidity_fee_receiver,
        )?,
    })
}

#[event_cpi]
#[derive(Accounts)]
pub struct BorrowObligationLiquidity<'info> {
    pub authority: Signer<'info>,

    #[account(mut,
        constraint = vault_state.load()?.is_allocation_authority(authority.key())
            @ KaminoVaultError::AllocationAuthorityIncorrect,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: PDA — signs the klend CPI as the obligation owner.
    #[account(seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub obligation: AccountLoader<'info, Obligation>,

    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// CHECK: the lending market's authority PDA (derived here, with klend's seeds).
    #[account(
        seeds = [LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
        seeds::program = kamino_lending::ID,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub borrow_reserve: AccountLoader<'info, Reserve>,

    #[account(
        address = borrow_reserve.load()?.liquidity.mint_pubkey
            @ KaminoVaultError::ReserveAccountMismatch,
        constraint = has_matching_scope_config(
            vault_state.load()?.deref(),
            &borrow_reserve_liquidity_mint.key(),
            borrow_reserve.load()?.deref(),
        )? @ KaminoVaultError::ReserveScopeMismatch,
    )]
    pub borrow_reserve_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// CHECK: the reserve's liquidity supply (address-pinned to the reserve).
    #[account(mut,
        address = borrow_reserve.load()?.liquidity.supply_vault
            @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_source_liquidity: AccountInfo<'info>,

    /// CHECK: the reserve's liquidity fee vault (address-pinned to the reserve).
    #[account(mut,
        address = borrow_reserve.load()?.liquidity.fee_vault
            @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub borrow_reserve_liquidity_fee_receiver: AccountInfo<'info>,

    /// The vault's own token vault for the borrowed liquidity mint.
    #[account(mut,
        seeds = [
            TOKEN_VAULT_SEED,
            borrow_reserve_liquidity_mint.key().as_ref(),
            vault_state.key().as_ref(),
        ],
        bump,
        token::mint = borrow_reserve_liquidity_mint,
        token::authority = base_vault_authority,
        token::token_program = token_program,
    )]
    pub token_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    pub token_program: Interface<'info, TokenInterface>,

    /// CHECK: Address-pinned, and no longer read — allocation instructions do not reject CPI
    /// (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,

    /// CHECK: the kFarms program (address-pinned).
    #[account(address = FARMS_PROGRAM_ID)]
    pub farms_program: AccountInfo<'info>,

    /// CHECK: the klend program (address-pinned).
    #[account(address = kamino_lending::ID)]
    pub lending_program: AccountInfo<'info>,
    // remaining_accounts: scope-price + obligation + leg-reserve accounts (per
    // `load_scope_prices_and_obligations_aum_from`), followed by the obligation's active deposit
    // reserves in its own order (optional outside an elevation group; forwarded to klend's borrow
    // CPI for its elevation-group debt-tracker update), then the reserve's debt-farm accounts.
}

use anchor_lang::{prelude::*, Accounts};
use kamino_lending::{utils::seeds::BASE_SEED_USER_METADATA, InitObligationArgs, LendingMarket};

use crate::{
    events::ObligationInitializedEvent,
    types::Timestamp,
    utils::{
        consts::{BASE_VAULT_AUTHORITY_SEED, VAULT_OBLIGATION_TAG},
        obligation_cpi::cpi_init_obligation,
        pda,
    },
    KaminoVaultError, MetavaultState,
};

/// Opens one of the vault's klend obligations in a lending market the admin picks: any klend
/// market is accepted, so the vault is exposed to that market's reserves and their config (the
/// reserves' price sources must still match the vault's own on every obligation operation).
pub fn process(ctx: Context<InitObligation>) -> Result<()> {
    let mut vault = ctx.accounts.vault_state.load_mut()?;
    // Registering an obligation grows the remaining-accounts layout every AUM-computing
    // instruction is sized against, so doing it mid-auction reverts in-flight solver fills.
    let current_timestamp = Timestamp::capture(&Clock::get()?)?;
    require!(
        !vault.rebalance.is_within(current_timestamp),
        KaminoVaultError::ObligationOperationDuringRebalance
    );

    let base_vault_authority_bump = vault.base_vault_authority_bump;
    let vault_obligation_id = vault.add_obligation_if_not_present(ctx.accounts.obligation.key())?;
    let id = vault_obligation_id.storage_index as u8;
    require_keys_eq!(
        ctx.accounts.obligation.key(),
        pda::vault_obligation(
            &ctx.accounts.lending_market.key(),
            &ctx.accounts.base_vault_authority.key(),
            id,
        ),
        KaminoVaultError::ObligationAddressMismatch
    );

    cpi_init_obligation(
        ctx.accounts,
        base_vault_authority_bump,
        InitObligationArgs {
            tag: VAULT_OBLIGATION_TAG,
            id,
        },
    )?;

    emit_cpi!(ObligationInitializedEvent {
        storage_index: vault_obligation_id.storage_index as u8,
        obligation: ctx.accounts.obligation.key(),
        lending_market: ctx.accounts.lending_market.key(),
    });

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct InitObligation<'info> {
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(mut,
        has_one = vault_admin_authority,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: PDA owned by the program (the obligation_owner signed by CPI).
    #[account(seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: the vault's klend obligation PDA for this lending market and the slot it is
    /// registered at (derived in the handler); klend creates it.
    #[account(mut)]
    pub obligation: AccountInfo<'info>,

    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// CHECK: the first seed account of an untagged obligation (address-pinned to the default).
    #[account(address = Pubkey::default())]
    pub seed1_account: AccountInfo<'info>,

    /// CHECK: the second seed account of an untagged obligation (address-pinned to the default).
    #[account(address = Pubkey::default())]
    pub seed2_account: AccountInfo<'info>,

    /// CHECK: klend's UserMetadata PDA of `base_vault_authority` (derived here, with klend's
    /// seeds; created at vault init).
    #[account(
        seeds = [BASE_SEED_USER_METADATA, base_vault_authority.key().as_ref()],
        bump,
        seeds::program = kamino_lending::ID,
    )]
    pub owner_user_metadata: AccountInfo<'info>,

    /// CHECK: the klend program (address-pinned).
    #[account(address = kamino_lending::ID)]
    pub lending_program: AccountInfo<'info>,

    pub rent: Sysvar<'info, Rent>,
    pub system_program: Program<'info, System>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
    Accounts,
};
use anchor_spl::{
    token::Token,
    token_interface::{Mint, TokenAccount, TokenInterface},
};
use kamino_lending::{
    utils::seeds::LENDING_MARKET_AUTH,
    utils::token_2022::check_only_supported_liquidity_token_extensions, LendingMarket, Obligation,
    Reserve,
};
use std::ops::Deref;

use crate::{
    events::{ObligationCollateralWithdrawEvent, ObligationRemovedEvent, RebalanceEndWatch},
    operations::{
        obligation_operations,
        vault_checks::{
            check_reserve_price_basis, check_withdraw_ltv_ceiling, find_enabled_token_and_price,
            has_matching_scope_config, post_withdraw_obligation_collateral_checks,
            WithdrawObligationCollateralBalances,
        },
    },
    types::{amounts::AllAvailableOr, FractionalTokenAmount, Timestamp, TokenAmount},
    utils::{
        consts::{BASE_VAULT_AUTHORITY_SEED, FARMS_PROGRAM_ID, TOKEN_VAULT_SEED},
        obligation_cpi::{
            cpi_withdraw_obligation_collateral_and_redeem_reserve_collateral,
            split_trailing_target_farm_accounts,
        },
        obligations::load_scope_prices_and_obligations_aum_from,
        remaining_accounts::RemainingAccounts,
    },
    KaminoVaultError, MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, WithdrawObligationCollateral<'info>>,
    collateral_amount: u64,
) -> Result<()> {
    let collateral_amount = AllAvailableOr::resolve(collateral_amount);

    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.reserve_liquidity_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;

    let mut vault = ctx.accounts.vault_state.load_mut()?;
    let base_vault_authority_bump = vault.base_vault_authority_bump;

    let obligation_pk = ctx.accounts.obligation.key();
    let vault_obligation_id = vault.get_obligation_id_by_address(&obligation_pk)?;
    // Copied out (VaultObligation is `Copy`) so the LTV check below doesn't need to hold a
    // borrow of `vault` across the CPI.
    let vault_obligation = vault.obligations[vault_obligation_id.storage_index];

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let rebalance_watch =
        RebalanceEndWatch::open(ctx.accounts.vault_state.key(), &vault, current_timestamp);
    let target_farm = ctx.accounts.withdraw_reserve.load()?.farm_collateral;
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum_from(
        &vault,
        &mut remaining,
        clock.slot,
        current_timestamp,
    )?;
    let (_, farm_accounts) = split_trailing_target_farm_accounts(
        remaining.rest(),
        0,
        target_farm,
        ctx.accounts.obligation.key(),
    )?;

    let liquidity_mint = ctx.accounts.reserve_liquidity_mint.key();
    let withdraw_reserve_pk = ctx.accounts.withdraw_reserve.key();
    let effects = {
        let reserve = ctx.accounts.withdraw_reserve.load()?;
        let lending_market = ctx.accounts.lending_market.load()?;
        let obligation = ctx.accounts.obligation.load()?;
        // The gate is keyed off the reserve's own recorded mint (as the leg sweep does), not the
        // caller-supplied mint account.
        let (vault_token, token_price) = find_enabled_token_and_price(
            &vault,
            &vault_scope_prices,
            &reserve.liquidity.mint_pubkey,
        )?;
        check_reserve_price_basis(vault_token, token_price, &reserve)?;
        obligation_operations::withdraw_obligation_collateral(
            &mut vault,
            &vault_scope_prices,
            obligations_aum,
            &reserve,
            &lending_market,
            &obligation,
            &withdraw_reserve_pk,
            &liquidity_mint,
            collateral_amount,
            clock.slot,
            current_timestamp,
        )?
    };

    let pre_balances = capture_balances(ctx.accounts)?;

    cpi_withdraw_obligation_collateral_and_redeem_reserve_collateral(
        ctx.accounts,
        farm_accounts,
        base_vault_authority_bump,
        collateral_amount,
    )?;

    let post_balances = capture_balances(ctx.accounts)?;
    post_withdraw_obligation_collateral_checks(&pre_balances, &post_balances, &effects)?;

    // Post-CPI LTV ceiling check. The obligation's aggregate values are refresh-time only —
    // klend's withdraw mutates per-position amounts and marks the obligation stale, so the
    // aggregates reloaded here still carry the same-slot pre-op refresh: exactly the anchor
    // the delta needs. `effects.ctokens_to_redeem` is trustworthy here: the balance checks
    // above just verified it against the actual collateral burn. Converting it at full
    // precision through the post-CPI exchange rate (the state klend's next refresh values
    // deposit legs with) instead of using the floor'd `liquidity_to_receive` keeps the ceiling
    // at least as strict as klend's own post-state.
    //
    // Skipped when klend has closed the obligation account (data reallocated to 0 bytes): klend
    // only closes an obligation once both its deposits and borrows are empty, so a closed
    // obligation carries zero debt — the ceiling is trivially satisfied and there is nothing left
    // to reload (`AccountLoader::load()` would hard-fail with `AccountDiscriminatorNotFound` on
    // the zeroed data).
    if !ctx.accounts.obligation.to_account_info().data_is_empty() {
        let obligation = ctx.accounts.obligation.load()?;
        let reserve = ctx.accounts.withdraw_reserve.load()?;
        let lending_market = ctx.accounts.lending_market.load()?;
        let withdrawn_liquidity = FractionalTokenAmount::from(
            reserve
                .collateral_exchange_rate()
                .fraction_collateral_to_liquidity(effects.ctokens_to_redeem.as_fraction()),
        );
        check_withdraw_ltv_ceiling(
            &vault_obligation,
            &reserve,
            &lending_market,
            &obligation,
            withdrawn_liquidity,
        )?;
    }

    // Klend closes the obligation account when this withdraw empties deposits:
    if ctx.accounts.obligation.to_account_info().data_is_empty() {
        vault.remove_obligation(vault_obligation_id)?;
        emit_cpi!(ObligationRemovedEvent {
            storage_index: vault_obligation_id.storage_index as u8,
            obligation: obligation_pk,
        });
    }

    emit_cpi!(ObligationCollateralWithdrawEvent {
        storage_index: vault_obligation_id.storage_index as u8,
        reserve: withdraw_reserve_pk,
        amount: effects.liquidity_to_receive.into(),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(&vault) {
        emit_cpi!(ended_event);
    }

    Ok(())
}

fn capture_balances(
    accounts: &WithdrawObligationCollateral,
) -> Result<WithdrawObligationCollateralBalances> {
    Ok(WithdrawObligationCollateralBalances {
        vault_token_balance: TokenAmount::of_account(&accounts.token_vault.to_account_info())?,
        reserve_liquidity_supply: TokenAmount::of_account(&accounts.reserve_liquidity_supply)?,
        reserve_source_collateral: TokenAmount::of_account(&accounts.reserve_source_collateral)?,
    })
}

#[event_cpi]
#[derive(Accounts)]
pub struct WithdrawObligationCollateral<'info> {
    pub authority: Signer<'info>,

    #[account(mut,
        constraint = vault_state.load()?.is_allocation_authority(authority.key())
            @ KaminoVaultError::AllocationAuthorityIncorrect,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: PDA — signs the klend CPI as the obligation owner.
    #[account(mut, seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub obligation: AccountLoader<'info, Obligation>,

    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// CHECK: the lending market's authority PDA (derived here, with klend's seeds).
    #[account(
        seeds = [LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
        seeds::program = kamino_lending::ID,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    #[account(mut, has_one = lending_market @ KaminoVaultError::LendingMarketMismatch)]
    pub withdraw_reserve: AccountLoader<'info, Reserve>,

    #[account(
        address = withdraw_reserve.load()?.liquidity.mint_pubkey
            @ KaminoVaultError::ReserveAccountMismatch,
        constraint = has_matching_scope_config(
            vault_state.load()?.deref(),
            &reserve_liquidity_mint.key(),
            withdraw_reserve.load()?.deref(),
        )? @ KaminoVaultError::ReserveScopeMismatch,
    )]
    pub reserve_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// CHECK: the reserve's collateral supply (address-pinned to the reserve).
    #[account(mut,
        address = withdraw_reserve.load()?.collateral.supply_vault
            @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_source_collateral: AccountInfo<'info>,

    /// CHECK: the reserve's collateral mint (address-pinned to the reserve).
    #[account(mut,
        address = withdraw_reserve.load()?.collateral.mint_pubkey
            @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_collateral_mint: AccountInfo<'info>,

    /// CHECK: the reserve's liquidity supply (address-pinned to the reserve).
    #[account(mut,
        address = withdraw_reserve.load()?.liquidity.supply_vault
            @ KaminoVaultError::ReserveAccountMismatch,
    )]
    pub reserve_liquidity_supply: AccountInfo<'info>,

    /// The vault's own token vault for the liquidity mint — funds flow from klend back into
    /// here.
    #[account(mut,
        seeds = [
            TOKEN_VAULT_SEED,
            reserve_liquidity_mint.key().as_ref(),
            vault_state.key().as_ref(),
        ],
        bump,
        token::mint = reserve_liquidity_mint,
        token::authority = base_vault_authority,
        token::token_program = liquidity_token_program,
    )]
    pub token_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    pub collateral_token_program: Program<'info, Token>,

    pub liquidity_token_program: Interface<'info, TokenInterface>,

    /// CHECK: Address-pinned, and no longer read — allocation instructions do not reject CPI
    /// (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,

    /// CHECK: the kFarms program (address-pinned).
    #[account(address = FARMS_PROGRAM_ID)]
    pub farms_program: AccountInfo<'info>,

    /// CHECK: the klend program (address-pinned).
    #[account(address = kamino_lending::ID)]
    pub lending_program: AccountInfo<'info>,
    // remaining_accounts: scope-price + obligation + leg-reserve accounts (per
    // `load_scope_prices_and_obligations_aum_from`), followed by optional debt-farm accounts.
    // No trailing deposit-reserve segment — klend's withdraw uses a single `&mut Reserve` (the
    // one already in `withdraw_reserve`) for its elevation-group debt-tracker update.
}

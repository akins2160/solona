use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_2022::{spl_token_2022, Token2022};
use spl_token_2022::{
    extension::{BaseStateWithExtensions, StateWithExtensions},
    state::AccountState,
};
use spl_token_metadata_interface::state::TokenMetadata;

use crate::{
    utils::{token22_metadata, token_acl},
    KaminoVaultError, MetavaultState,
};

/// Re-opens a permissioned vault atomically: DeleteConfig hands the freeze authority
/// back to `base_vault_authority` (config rent to the admin), the mint's
/// DefaultAccountState flips to `Initialized` in the same instruction — a config-less
/// mint with DAS still `Frozen` would mint frozen accounts with no thaw path — and the
/// vault's permissioned flag clears. The freeze authority stays parked on
/// `base_vault_authority`, so re-permissioning later is not blocked.
///
/// Share accounts frozen at that point stay frozen: thawing goes through the config just deleted,
/// and only `init_vault` creates one.
pub fn process(ctx: Context<DeleteSharesConfig>) -> Result<()> {
    let mut vault = ctx.accounts.vault_state.load_mut()?;
    token_acl::validate_permissioned_vault_accounts(
        &vault,
        ctx.accounts.shares_mint.key,
        &ctx.accounts.shares_mint_config,
    )?;

    let vault_state_key = ctx.accounts.vault_state.key();
    let cpi_accounts = token_acl::TokenAclCpiAccounts {
        token_acl_program: &ctx.accounts.token_acl_program,
        mint_config: &ctx.accounts.shares_mint_config,
        shares_mint: &ctx.accounts.shares_mint,
        base_vault_authority: &ctx.accounts.base_vault_authority,
        vault_state_key: &vault_state_key,
        base_vault_authority_bump: vault.base_vault_authority_bump,
    };

    let has_metadata = {
        let mint_data = ctx.accounts.shares_mint.data.borrow();
        StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&mint_data)?
            .get_variable_len_extension::<TokenMetadata>()
            .is_ok()
    };
    if has_metadata {
        token22_metadata::cpi_remove_key(
            &token22_metadata::SharesMetadataAccounts {
                shares_mint: &ctx.accounts.shares_mint,
                base_vault_authority: &ctx.accounts.base_vault_authority,
                shares_token_program: &ctx.accounts.shares_token_program.to_account_info(),
                vault_state_key,
                base_vault_authority_bump: vault.base_vault_authority_bump,
            },
            token22_metadata::TOKEN_ACL_METADATA_KEY.to_string(),
            true,
        )?;
    }

    token_acl::cpi_delete_config(
        &cpi_accounts,
        &ctx.accounts.shares_token_program.to_account_info(),
        &ctx.accounts.vault_admin_authority.to_account_info(),
    )?;
    token_acl::cpi_update_default_account_state(
        &cpi_accounts,
        &ctx.accounts.shares_token_program.to_account_info(),
        AccountState::Initialized,
    )?;

    vault.shares_permissioned = 0;
    Ok(())
}

#[derive(Accounts)]
pub struct DeleteSharesConfig<'info> {
    /// Receives the closed MintConfig's rent.
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(
        mut,
        has_one = vault_admin_authority,
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Pinned by `has_one` on `vault_state`; the token-acl config admin and the
    /// freeze authority after deletion.
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Pinned by `has_one` on `vault_state`; freeze authority and DAS change.
    #[account(mut)]
    pub shares_mint: AccountInfo<'info>,

    /// CHECK: Validated in the handler against the MintConfig PDA of the shares mint.
    #[account(mut)]
    pub shares_mint_config: AccountInfo<'info>,

    /// CHECK: Pinned program id.
    #[account(address = token_acl::TOKEN_ACL_PROGRAM_ID @ KaminoVaultError::TokenAclProgramIncorrect)]
    pub token_acl_program: AccountInfo<'info>,

    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_2022::{spl_token_2022, Token2022};
use spl_token_2022::extension::{BaseStateWithExtensions, StateWithExtensions};
use spl_token_metadata_interface::state::{Field, TokenMetadata};

use crate::{
    utils::{token22_metadata, token_acl},
    KaminoVaultError, MetavaultState,
};

/// Rotates a permissioned vault's gate so an invalid or unavailable gate cannot
/// permanently strand the vault in its frozen-at-birth state.
pub fn process(ctx: Context<SetSharesGatingProgram>, new_gating_program: Pubkey) -> Result<()> {
    require!(
        new_gating_program != Pubkey::default(),
        KaminoVaultError::SharesGatingProgramInvalid
    );
    let vault = ctx.accounts.vault_state.load()?;
    token_acl::validate_permissioned_vault_accounts(
        &vault,
        ctx.accounts.shares_mint.key,
        &ctx.accounts.shares_mint_config,
    )?;

    let vault_state_key = ctx.accounts.vault_state.key();
    let cpi_accounts = token_acl::TokenAclCpiAccounts {
        token_acl_program: &ctx.accounts.token_acl_program,
        mint_config: &ctx.accounts.shares_mint_config,
        shares_mint: &ctx.accounts.shares_mint,
        base_vault_authority: &ctx.accounts.base_vault_authority,
        vault_state_key: &vault_state_key,
        base_vault_authority_bump: vault.base_vault_authority_bump,
    };
    token_acl::cpi_set_gating_program(&cpi_accounts, &new_gating_program)?;

    // Keep the `token_acl` gate-discovery metadata key in sync — when the shares
    // metadata has been initialized (it is optional and admin-driven).
    let has_metadata = {
        let mint_data = ctx.accounts.shares_mint.data.borrow();
        StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&mint_data)?
            .get_variable_len_extension::<TokenMetadata>()
            .is_ok()
    };
    if has_metadata {
        token22_metadata::cpi_update_fields(
            &token22_metadata::SharesMetadataAccounts {
                shares_mint: &ctx.accounts.shares_mint,
                base_vault_authority: &ctx.accounts.base_vault_authority,
                shares_token_program: &ctx.accounts.shares_token_program.to_account_info(),
                vault_state_key,
                base_vault_authority_bump: vault.base_vault_authority_bump,
            },
            &ctx.accounts.vault_admin_authority.to_account_info(),
            &ctx.accounts.system_program.to_account_info(),
            vec![(
                Field::Key(token22_metadata::TOKEN_ACL_METADATA_KEY.to_string()),
                new_gating_program.to_string(),
            )],
        )?;
    }
    Ok(())
}

#[derive(Accounts)]
pub struct SetSharesGatingProgram<'info> {
    /// Also pays the metadata rent top-up when the gate-discovery key is synced.
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(
        has_one = vault_admin_authority,
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Pinned by `has_one` on `vault_state`; the token-acl config admin.
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Pinned by `has_one` on `vault_state`; written when the metadata key syncs.
    #[account(mut)]
    pub shares_mint: AccountInfo<'info>,

    /// CHECK: Validated in the handler against the MintConfig PDA of the shares mint.
    #[account(mut)]
    pub shares_mint_config: AccountInfo<'info>,

    /// CHECK: Pinned program id.
    #[account(address = token_acl::TOKEN_ACL_PROGRAM_ID @ KaminoVaultError::TokenAclProgramIncorrect)]
    pub token_acl_program: AccountInfo<'info>,

    pub shares_token_program: Program<'info, Token2022>,
    pub system_program: Program<'info, System>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

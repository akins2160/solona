use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};
use anchor_spl::{
    token_2022::Token2022,
    token_interface::{Mint, TokenAccount},
};

use crate::{
    events::{DepositOrderClosedEvent, DepositOrderEndReason, RebalanceEndWatch},
    operations::{
        deposit_order_operations::settle_deposit_order, effects::SettleDepositOrderEffects,
    },
    order::DepositOrder,
    types::Timestamp,
    utils::{
        consts::GLOBAL_CONFIG_STATE_SEEDS,
        obligations::load_scope_prices_and_obligations_aum_from,
        order_accounts::PayoutAccounts,
        remaining_accounts::RemainingAccounts,
        token_acl::require_immutable_owner_if_permissioned,
        token_ops::{self, shares},
    },
    GlobalConfig, KaminoVaultError, MetavaultState,
};

/// Ends a deposit order: the vault absorbs what it admits and mints shares for it, refunds the rest
/// and deletes the account. Anyone may send it, once the auction is over.
pub fn process<'info>(ctx: Context<'_, '_, 'info, 'info, SettleDepositOrder<'info>>) -> Result<()> {
    crate::check_cpi!(ctx);

    require!(
        !ctx.accounts.owner_shares_ata.is_frozen(),
        KaminoVaultError::SharesAccountFrozen
    );

    // Regular accounts:
    let vault_state_key = ctx.accounts.vault_state.key();
    let order_key = ctx.accounts.deposit_order.key();
    let by_owner = ctx.accounts.signer.key() == ctx.accounts.owner.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    require_immutable_owner_if_permissioned(
        vault_state,
        &ctx.accounts.owner_shares_ata.to_account_info(),
    )?;
    let mut order = ctx.accounts.deposit_order.load_mut()?;
    let global_config = &ctx.accounts.global_config.load()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;

    // Remaining accounts: (prices, obligations, then the payout accounts)
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum_from(
        vault_state,
        &mut remaining,
        clock.slot,
        current_timestamp,
    )?;

    // Parsed before the absorb empties the order (so one payout set per token held now).
    let payout_accounts = PayoutAccounts::parse(&*order, vault_state, by_owner, &mut remaining)?;
    remaining.check_none_remaining()?;

    // The accounting update:
    let rebalance_watch = RebalanceEndWatch::open(vault_state_key, vault_state, current_timestamp);
    let SettleDepositOrderEffects {
        shares_minted,
        refunds,
    } = settle_deposit_order(
        &mut order,
        vault_state,
        &vault_scope_prices,
        obligations_aum,
        global_config,
        current_timestamp,
    )?;

    // Effects: mint the shares the absorb earned, then refund what it did not take:
    shares::mint(
        ctx.accounts.shares_token_program.to_account_info(),
        ctx.accounts.shares_mint.to_account_info(),
        ctx.accounts.vault_state.to_account_info(),
        ctx.accounts.base_vault_authority.to_account_info(),
        ctx.accounts.owner_shares_ata.to_account_info(),
        vault_state.base_vault_authority_bump,
        shares_minted,
    )?;

    token_ops::composites::transfer_all_payouts(
        &payout_accounts.per_token,
        &refunds,
        vault_state.base_vault_authority_bump,
        &ctx.accounts.vault_state.to_account_info(),
        &ctx.accounts.base_vault_authority.to_account_info(),
    )?;

    // Post-checks:
    payout_accounts.check_vault_balances_cover_locked(vault_state)?;

    // Events:
    emit_cpi!(DepositOrderClosedEvent {
        vault_state: vault_state_key,
        order: order_key,
        shares_minted: shares_minted.into(),
        refunds: refunds.map(u64::from),
        reason: DepositOrderEndReason::Settled,
        timestamp: current_timestamp.into(),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(vault_state) {
        emit_cpi!(ended_event);
    }

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct SettleDepositOrder<'info> {
    /// Anyone (a settle can only move the order toward the deposit its owner asked for).
    pub signer: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    #[account(mut,
        constraint = deposit_order.load()?.base.vault_state == vault_state.key()
            @ KaminoVaultError::OrderAccountMismatch,
        constraint = deposit_order.load()?.base.owner == owner.key()
            @ KaminoVaultError::OrderAccountMismatch,
        close = owner,
    )]
    pub deposit_order: AccountLoader<'info, DepositOrder>,

    /// CHECK: `deposit_order`'s owner; receives the shares/refunds/rent
    #[account(mut)]
    pub owner: AccountInfo<'info>,

    /// CHECK: vault_state has_one check
    pub base_vault_authority: AccountInfo<'info>,

    #[account(mut,
        mint::token_program = shares_token_program
    )]
    pub shares_mint: Box<InterfaceAccount<'info, Mint>>,

    /// Where the shares go (any TA of the order's owner).
    #[account(mut,
        token::mint = shares_mint,
        token::authority = owner,
        token::token_program = shares_token_program,
    )]
    pub owner_shares_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: scope prices, `AumAccounts::parse`'s segments, `PayoutAccounts::parse`'s.
}

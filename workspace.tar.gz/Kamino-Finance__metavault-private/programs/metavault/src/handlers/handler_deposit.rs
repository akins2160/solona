use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
    Accounts,
};
use anchor_spl::{
    token_2022::Token2022,
    token_interface::{Mint, TokenAccount, TokenInterface},
};
use kamino_lending::utils::token_2022::check_only_supported_liquidity_token_extensions;

use crate::{
    events::{DepositResultEvent, DepositUserAtaBalanceEvent, RebalanceEndWatch},
    operations::{
        effects::DepositEffects,
        vault_checks::{post_transfer_deposit_checks, VaultOperationBalances},
        vault_operations,
    },
    types::{ShareAmount, Timestamp, TokenAmount},
    utils::{
        consts::{GLOBAL_CONFIG_STATE_SEEDS, TOKEN_VAULT_SEED},
        obligations::load_scope_prices_and_obligations_aum,
        token_acl::require_immutable_owner_if_permissioned,
        token_ops::{self, shares, tokens::UserTransferAccounts},
    },
    GlobalConfig, KaminoVaultError, MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, Deposit<'info>>,
    max_amount: u64,
    min_shares_out: u64,
) -> Result<()> {
    crate::check_cpi!(ctx);

    // CHECKS
    let max_amount = TokenAmount::from(max_amount);
    require!(!max_amount.is_zero(), KaminoVaultError::DepositAmountsZero);
    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.token_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;
    // Actionable error instead of Token-2022's raw AccountFrozen from inside the mint
    // CPI: on permissioned vaults a fresh shares ATA is born frozen and must be thawed
    // through the vault's gate first.
    require!(
        !ctx.accounts.user_shares_ata.is_frozen(),
        KaminoVaultError::SharesAccountFrozen
    );
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    require!(
        vault_state.block_deposits == 0,
        KaminoVaultError::VaultDepositsBlocked
    );
    require_immutable_owner_if_permissioned(
        vault_state,
        &ctx.accounts.user_shares_ata.to_account_info(),
    )?;

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;
    let global_config = &ctx.accounts.global_config.load()?;
    let min_shares_out = ShareAmount::from(min_shares_out);

    let user_initial_shares_balance =
        ShareAmount::of_account(&ctx.accounts.user_shares_ata.to_account_info())?;
    let user_initial_ata_balance =
        TokenAmount::of_account(&ctx.accounts.user_token_ata.to_account_info())?;
    let vault_token_balance_before =
        TokenAmount::of_account(&ctx.accounts.token_vault.to_account_info())?;
    let initial_vault_shares_issued = vault_state.shares_issued_amount();
    emit_cpi!(DepositUserAtaBalanceEvent {
        user_ata_balance: user_initial_ata_balance.into(),
    });

    let rebalance_watch = RebalanceEndWatch::open(
        ctx.accounts.vault_state.key(),
        vault_state,
        current_timestamp,
    );
    let DepositEffects {
        shares_to_mint,
        token_to_deposit,
        fee_shares_to_mint,
    } = vault_operations::deposit(
        vault_state,
        &vault_scope_prices,
        obligations_aum,
        global_config,
        ctx.accounts.token_mint.key(),
        max_amount,
        current_timestamp,
    )?;

    require_gte!(
        shares_to_mint,
        min_shares_out,
        KaminoVaultError::SlippageExceeded
    );

    emit_cpi!(DepositResultEvent {
        shares_to_mint: shares_to_mint.into(),
        token_to_deposit: token_to_deposit.into(),
    });
    if let Some(ended_event) = rebalance_watch.on_balances_changed(vault_state) {
        emit_cpi!(ended_event);
    }

    // Deposit from user token
    token_ops::tokens::transfer_to_vault(
        &UserTransferAccounts {
            token_program: ctx.accounts.token_program.to_account_info(),
            user_authority: ctx.accounts.user.to_account_info(),
            token_ata: ctx.accounts.user_token_ata.to_account_info(),
            token_vault: ctx.accounts.token_vault.to_account_info(),
            token_mint: ctx.accounts.token_mint.to_account_info(),
        },
        token_to_deposit,
        ctx.accounts.token_mint.decimals,
    )?;

    // Mint shares
    shares::mint(
        ctx.accounts.shares_token_program.to_account_info(),
        ctx.accounts.shares_mint.to_account_info(),
        ctx.accounts.vault_state.to_account_info(),
        ctx.accounts.base_vault_authority.to_account_info(),
        ctx.accounts.user_shares_ata.to_account_info(),
        vault_state.base_vault_authority_bump,
        shares_to_mint,
    )?;

    // Post checks
    let user_ata_balance_after =
        TokenAmount::of_account(&ctx.accounts.user_token_ata.to_account_info())?;
    let user_shares_balance_after =
        ShareAmount::of_account(&ctx.accounts.user_shares_ata.to_account_info())?;
    let vault_token_balance_after =
        TokenAmount::of_account(&ctx.accounts.token_vault.to_account_info())?;

    post_transfer_deposit_checks(
        &VaultOperationBalances {
            user_shares_balance_before: user_initial_shares_balance,
            user_shares_balance_after,
            user_token_balances_before: vec![user_initial_ata_balance],
            user_token_balances_after: vec![user_ata_balance_after],
            vault_shares_issued_before: initial_vault_shares_issued,
            vault_shares_issued_after: vault_state.shares_issued_amount(),
            vault_token_balances_before: vec![vault_token_balance_before],
            vault_token_balances_after: vec![vault_token_balance_after],
        },
        &[max_amount],
        &[token_to_deposit],
        fee_shares_to_mint,
    )?;

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct Deposit<'info> {
    #[account(mut)]
    pub user: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    #[account(mut,
        seeds=[TOKEN_VAULT_SEED, token_mint.key().as_ref(), vault_state.key().as_ref()],
        bump,
    )]
    pub token_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    // The token being deposited into the vault
    #[account(
        mint::token_program = token_program
    )]
    pub token_mint: Box<InterfaceAccount<'info, Mint>>,

    /// CHECK: vault_state has_one check
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: vault_state has_one check
    #[account(mut,
        mint::token_program = shares_token_program
    )]
    pub shares_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(mut,
        token::mint = token_mint,
        token::authority = user,
        token::token_program = token_program,
    )]
    pub user_token_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    #[account(mut,
        token::mint = shares_mint,
        token::authority = user,
        token::token_program = shares_token_program,
    )]
    pub user_shares_ata: Box<InterfaceAccount<'info, TokenAccount>>,

    pub token_program: Interface<'info, TokenInterface>,
    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

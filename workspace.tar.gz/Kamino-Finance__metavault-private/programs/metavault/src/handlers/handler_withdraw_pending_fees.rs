use anchor_lang::prelude::*;
use anchor_spl::{
    token_2022::Token2022,
    token_interface::{Mint, TokenAccount},
};

use crate::{
    operations::{effects::WithdrawPendingFeesEffects, vault_checks, vault_operations},
    types::{ShareAmount, Timestamp},
    utils::{
        obligations::load_scope_prices_and_obligations_aum,
        token_acl::require_immutable_owner_if_permissioned, token_ops::shares,
    },
    MetavaultState,
};

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, WithdrawPendingFees<'info>>,
) -> Result<()> {
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    require_immutable_owner_if_permissioned(
        vault_state,
        &ctx.accounts.admin_shares_ata.to_account_info(),
    )?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;
    let withdraw_pending_fees_effects = {
        vault_operations::withdraw_pending_fees(
            vault_state,
            &vault_scope_prices,
            obligations_aum,
            current_timestamp,
        )?
    };

    let WithdrawPendingFeesEffects {
        available_to_send_to_user: shares_to_mint,
    } = withdraw_pending_fees_effects;

    msg!(
        "WithdrawPendingFeesEffects: shares_to_mint={}",
        shares_to_mint,
    );

    // Send all the owed tokens to the admin
    shares::mint(
        ctx.accounts.shares_token_program.to_account_info(),
        ctx.accounts.shares_mint.to_account_info(),
        ctx.accounts.vault_state.to_account_info(),
        ctx.accounts.base_vault_authority.to_account_info(),
        ctx.accounts.admin_shares_ata.to_account_info(),
        vault_state.base_vault_authority_bump,
        shares_to_mint,
    )?;

    ctx.accounts.shares_mint.reload()?;
    vault_checks::post_withdraw_pending_fees_check(
        vault_state,
        ShareAmount::from(ctx.accounts.shares_mint.supply),
    )?;

    Ok(())
}

#[derive(Accounts)]
pub struct WithdrawPendingFees<'info> {
    #[account(mut)]
    pub vault_admin_authority: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
        has_one = vault_admin_authority,
        has_one = shares_mint
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: This authority is stored in the vault state
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: the fields of the token account are stored in the vault state
    #[account(mut,
        token::mint = shares_mint,
        token::authority = vault_admin_authority,
        token::token_program = shares_token_program,
    )]
    pub admin_shares_ata: InterfaceAccount<'info, TokenAccount>,

    /// CHECK: vault_state has_one check
    #[account(mut,
        mint::token_program = shares_token_program
    )]
    pub shares_mint: Box<InterfaceAccount<'info, Mint>>,

    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

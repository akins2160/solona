use anchor_lang::prelude::*;

use crate::{
    types::{RoundingMethod, Timestamp},
    utils::obligations::load_scope_prices_and_obligations_aum,
    MetavaultState,
};

pub fn process<'info>(ctx: Context<'_, '_, 'info, 'info, Aum<'info>>) -> Result<AumResult> {
    Ok(AumResult::from(
        process_inner(ctx).map_err(|err| format!("{err:?}")),
    ))
}

fn process_inner<'info>(ctx: Context<'_, '_, 'info, 'info, Aum<'info>>) -> Result<u128> {
    let vault_state = ctx.accounts.vault_state.load()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        &vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;
    let net_aum = vault_state
        .compute_net_aum(&vault_scope_prices, obligations_aum, RoundingMethod::Floor)
        .check_positive()?;
    Ok(net_aum.to_bits())
}

#[derive(Accounts)]
pub struct Aum<'info> {
    pub vault_state: AccountLoader<'info, MetavaultState>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

/// Return-data wrapper for readonly AUM quotes.
///
/// Keep `Err` before `Ok`: Borsh serializes `std::result::Result` as `0 = Err`, `1 = Ok`, and
/// CPI callers already decode this instruction's return data as `Result<u128, String>`.
#[derive(AnchorSerialize, AnchorDeserialize, Debug, Clone, PartialEq, Eq)]
pub enum AumResult {
    Err(String),
    Ok(u128),
}

impl From<std::result::Result<u128, String>> for AumResult {
    fn from(result: std::result::Result<u128, String>) -> Self {
        match result {
            std::result::Result::Err(error) => Self::Err(error),
            std::result::Result::Ok(value) => Self::Ok(value),
        }
    }
}

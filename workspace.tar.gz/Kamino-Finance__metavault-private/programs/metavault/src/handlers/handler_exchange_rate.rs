use anchor_lang::prelude::*;
use kamino_lending::fraction::Fraction;

use crate::{
    operations::vault_operations,
    types::{RoundingMethod, Timestamp},
    utils::{
        consts::GLOBAL_CONFIG_STATE_SEEDS, obligations::load_scope_prices_and_obligations_aum,
    },
    GlobalConfig, MetavaultState,
};

/// Net withdraw exchange rate for a vault token, returned as CPI return data.
///
/// `exchange_rate_sf` is `Fraction` (U68F60) bits of net withdrawable token *lamports* per one
/// *whole* share (`10^shares_mint_decimals` share lamports), after the withdrawal fee. As with
/// klend's `calculate_ctoken_exchange_rate`, the share-side decimals are folded into the unit, so a
/// consumer needs only the returned token decimals to normalize:
///
/// ```text
/// whole_tokens_per_whole_share = exchange_rate_sf / 2^60 / 10^token_mint_decimals
/// ```
///
/// `token_mint_decimals` is returned here so consumers do not have to load the token mint.
#[derive(AnchorSerialize, AnchorDeserialize, Debug, Clone, PartialEq, Eq)]
pub struct ExchangeRateWithDecimals {
    pub exchange_rate_sf: u128,
    pub token_mint_decimals: u8,
}

pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, ExchangeRate<'info>>,
    mint: Pubkey,
) -> Result<ExchangeRateResult> {
    Ok(ExchangeRateResult::from(
        process_inner(ctx, mint).map_err(|err| format!("{err:?}")),
    ))
}

fn process_inner<'info>(
    ctx: Context<'_, '_, 'info, 'info, ExchangeRate<'info>>,
    mint: Pubkey,
) -> Result<ExchangeRateWithDecimals> {
    let vault_state = ctx.accounts.vault_state.load()?;
    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    let (vault_scope_prices, obligations_aum) = load_scope_prices_and_obligations_aum(
        &vault_state,
        ctx.remaining_accounts,
        clock.slot,
        current_timestamp,
    )?;
    let global_config = ctx.accounts.global_config.load()?;
    let quote = vault_operations::quote_withdraw_exchange_rate(
        &vault_state,
        &vault_scope_prices,
        obligations_aum,
        &global_config,
        mint,
    )?;
    // `quote.rate` is per share lamport; scale to one whole share so the share decimals are folded
    // into the unit (consumers normalize with the token decimals alone).
    let one_whole_share = vault_state.one_whole_share();
    Ok(ExchangeRateWithDecimals {
        exchange_rate_sf: quote
            .rate
            .full_mul(Fraction::from(one_whole_share), RoundingMethod::Floor)
            .to_bits(),
        token_mint_decimals: quote.token_mint_decimals,
    })
}

#[derive(Accounts)]
pub struct ExchangeRate<'info> {
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,
    // remaining_accounts: see `load_scope_prices_and_obligations_aum`.
}

/// Return-data wrapper for readonly exchange-rate quotes.
///
/// Keep `Err` before `Ok`: Borsh serializes `std::result::Result` as `0 = Err`, `1 = Ok`, and
/// CPI callers already decode this instruction's return data as
/// `Result<ExchangeRateWithDecimals, String>`.
#[derive(AnchorSerialize, AnchorDeserialize, Debug, Clone, PartialEq, Eq)]
pub enum ExchangeRateResult {
    Err(String),
    Ok(ExchangeRateWithDecimals),
}

impl From<std::result::Result<ExchangeRateWithDecimals, String>> for ExchangeRateResult {
    fn from(result: std::result::Result<ExchangeRateWithDecimals, String>) -> Self {
        match result {
            std::result::Result::Err(error) => Self::Err(error),
            std::result::Result::Ok(value) => Self::Ok(value),
        }
    }
}

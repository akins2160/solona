use anchor_lang::{prelude::*, Accounts};
use anchor_spl::{
    token_2022::{spl_token_2022, Token2022},
    token_interface::{Mint, TokenAccount, TokenInterface},
};
use kamino_lending::utils::{
    account_ops::initialize_pda_token_account,
    constraints::token_2022::check_only_supported_liquidity_token_extensions,
};
use kamino_lending::{utils::seeds::BASE_SEED_USER_METADATA, ScopeConfiguration};
use spl_token_2022::{extension::BaseStateWithExtensions, state::AccountState};

use crate::{
    operations::{effects::DepositEffects, vault_operations},
    types::Timestamp,
    utils::{
        consts::*,
        obligation_cpi::cpi_init_user_metadata,
        scope::VaultScopePrices,
        token_acl,
        token_ops::{self, tokens::UserTransferAccounts},
    },
    GlobalConfig, KaminoVaultError, MetavaultState,
};

pub fn process(
    ctx: Context<InitVault>,
    scope_configuration: ScopeConfiguration,
    user_lookup_table: Pubkey,
    gating_program: Option<Pubkey>,
) -> Result<()> {
    // Permissioned vaults require the token-acl accounts; validate everything about the
    // gate up front; the resulting setup invariants are re-checked after the CPIs below.
    if let Some(gate) = gating_program.as_ref() {
        require!(
            *gate != Pubkey::default(),
            KaminoVaultError::SharesGatingProgramInvalid
        );
        let token_acl_program = ctx
            .accounts
            .token_acl_program
            .as_ref()
            .ok_or(KaminoVaultError::SharesGatingProgramInvalid)?;
        require!(
            token_acl_program.key() == token_acl::TOKEN_ACL_PROGRAM_ID,
            KaminoVaultError::TokenAclProgramIncorrect
        );
        let mint_config = ctx
            .accounts
            .shares_mint_config
            .as_ref()
            .ok_or(KaminoVaultError::SharesGatingProgramInvalid)?;
        let (expected_mint_config, _) = token_acl::mint_config_pda(ctx.accounts.shares_mint.key);
        require!(
            mint_config.key() == expected_mint_config,
            KaminoVaultError::MintConfigIncorrect
        );
    }

    let token_mint_key = ctx.accounts.token_mint.key();
    let vault_state_key = ctx.accounts.vault_state.to_account_info().key();
    let token_vault_signer_seeds: &[&[u8]] = &[
        TOKEN_VAULT_SEED,
        token_mint_key.as_ref(),
        vault_state_key.as_ref(),
        &[ctx.bumps.token_vault],
    ];

    initialize_pda_token_account(
        &ctx.accounts.admin_authority.to_account_info(),
        &ctx.accounts.token_vault,
        &ctx.accounts.token_mint,
        &ctx.accounts.base_vault_authority,
        &ctx.accounts.token_program,
        &ctx.accounts.system_program.to_account_info(),
        &[token_vault_signer_seeds],
    )?;

    check_only_supported_liquidity_token_extensions(
        &ctx.accounts.token_mint.to_account_info(),
        &ctx.accounts.token_vault.to_account_info(),
    )?;

    let shares_default_state = if gating_program.is_some() {
        AccountState::Frozen
    } else {
        AccountState::Initialized
    };
    token_ops::shares::create_mint(
        ctx.accounts.admin_authority.to_account_info(),
        ctx.accounts.shares_mint.to_account_info(),
        ctx.accounts.vault_state.to_account_info(),
        ctx.accounts.base_vault_authority.to_account_info(),
        ctx.accounts.shares_token_program.to_account_info(),
        ctx.accounts.system_program.to_account_info(),
        ctx.bumps.shares_mint,
        ctx.accounts.token_mint.decimals,
        shares_default_state,
    )?;

    // Permissioned path: hand the freeze authority to the token-acl MintConfig PDA
    // (config admin = base_vault_authority) and enable permissionless thaw so
    // gate-approved holders can activate their own accounts. Permissionless freeze stays
    // off: freezing is a deliberate, authorized action, never something the crowd can do.
    if let Some(gate) = gating_program.as_ref() {
        let vault_state_key = ctx.accounts.vault_state.key();
        let cpi_accounts = token_acl::TokenAclCpiAccounts {
            token_acl_program: ctx.accounts.token_acl_program.as_ref().unwrap(),
            mint_config: ctx.accounts.shares_mint_config.as_ref().unwrap(),
            shares_mint: &ctx.accounts.shares_mint,
            base_vault_authority: &ctx.accounts.base_vault_authority,
            vault_state_key: &vault_state_key,
            base_vault_authority_bump: ctx.bumps.base_vault_authority,
        };
        token_acl::cpi_create_config(
            &cpi_accounts,
            &ctx.accounts.admin_authority.to_account_info(),
            &ctx.accounts.system_program.to_account_info(),
            &ctx.accounts.shares_token_program.to_account_info(),
            gate,
        )?;
        token_acl::cpi_toggle_permissionless(&cpi_accounts, false, true)?;

        // Setup invariants, re-read from the accounts the CPIs just wrote: the
        // MintConfig PDA must hold the freeze authority, base_vault_authority must be the
        // config admin, the gate must be recorded, and the toggles must match policy.
        let mint_config_account = ctx.accounts.shares_mint_config.as_ref().unwrap();
        let mint_config = token_acl::MintConfig::unpack(&mint_config_account.data.borrow())
            .ok_or(KaminoVaultError::MintConfigIncorrect)?;
        require!(
            mint_config.mint == *ctx.accounts.shares_mint.key
                && mint_config.config_admin == ctx.accounts.base_vault_authority.key()
                && mint_config.gating_program == *gate
                && mint_config.permissionless_thaw_enabled
                && !mint_config.permissionless_freeze_enabled,
            KaminoVaultError::MintConfigIncorrect
        );
        let mint_data = ctx.accounts.shares_mint.data.borrow();
        let mint_state = spl_token_2022::extension::StateWithExtensions::<
            spl_token_2022::state::Mint,
        >::unpack(&mint_data)?;
        let das = mint_state
            .get_extension::<spl_token_2022::extension::default_account_state::DefaultAccountState>(
            )
            .map_err(|_| KaminoVaultError::MintConfigIncorrect)?;
        require!(
            das.state == u8::from(AccountState::Frozen)
                && Option::<Pubkey>::from(mint_state.base.freeze_authority)
                    == Some(*mint_config_account.key),
            KaminoVaultError::MintConfigIncorrect
        );
    }

    let vault = &mut ctx.accounts.vault_state.load_init()?;
    vault.shares_permissioned = u8::from(gating_program.is_some());

    let clock = Clock::get()?;
    let current_timestamp = Timestamp::capture(&clock)?;
    vault_operations::initialize(
        vault,
        ctx.accounts.admin_authority.key(),
        ctx.accounts.base_vault_authority.key(),
        ctx.accounts.shares_mint.key(),
        ctx.bumps.base_vault_authority,
        ctx.accounts.token_mint.decimals,
        current_timestamp,
    )?;

    vault
        .add_vault_token_if_not_present(
            ctx.accounts.token_mint.key(),
            ctx.accounts.token_vault.key(),
            ctx.accounts.token_program.key(),
            ctx.accounts.token_mint.decimals,
            scope_configuration,
            current_timestamp,
        )
        .map_err(|e| {
            msg!(
                "On vault initialization adding token should not fail: {:?}",
                e
            );
            e
        })?;

    let vault_scope_prices =
        VaultScopePrices::mock_scope_prices_for_vault_init(ctx.accounts.token_mint.decimals);

    // deposit INITIAL_DEPOSIT_SIZE to set the share price and avoid price inflation of initial shares
    let DepositEffects {
        shares_to_mint,
        token_to_deposit,
        ..
    } = vault_operations::perform_initial_deposit(
        vault,
        &vault_scope_prices,
        ctx.accounts.token_mint.key(),
        current_timestamp,
    )?;

    msg!(
        "shares_on_init={} token_to_deposit={}",
        shares_to_mint,
        token_to_deposit,
    );

    // Deposit from admin token
    token_ops::tokens::transfer_to_vault(
        &UserTransferAccounts {
            token_program: ctx.accounts.token_program.to_account_info(),
            user_authority: ctx.accounts.admin_authority.to_account_info(),
            token_ata: ctx.accounts.admin_token_account.to_account_info(),
            token_vault: ctx.accounts.token_vault.to_account_info(),
            token_mint: ctx.accounts.token_mint.to_account_info(),
        },
        token_to_deposit,
        ctx.accounts.token_mint.decimals,
    )?;

    // Create the klend UserMetadata PDA for `base_vault_authority` — klend requires it to exist
    // before any `init_obligation` against this owner.
    cpi_init_user_metadata(
        ctx.accounts,
        ctx.bumps.base_vault_authority,
        user_lookup_table,
    )?;

    Ok(())
}

#[derive(Accounts)]
pub struct InitVault<'info> {
    #[account(mut)]
    pub admin_authority: Signer<'info>,

    #[account(zero)]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
    )]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    /// CHECK: PDA owned by the program
    #[account(seeds = [BASE_VAULT_AUTHORITY_SEED, vault_state.key().as_ref()], bump)]
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Initialized manually via initialize_pda_token_account
    #[account(mut,
        seeds = [TOKEN_VAULT_SEED, token_mint.key().as_ref(), vault_state.key().as_ref()],
        bump,
    )]
    pub token_vault: AccountInfo<'info>,

    // The first token of the vault
    #[account(
        mint::token_program = token_program,
    )]
    pub token_mint: Box<InterfaceAccount<'info, Mint>>,

    /// CHECK: Initialized manually as a Token-2022 mint with the DefaultAccountState and
    /// MetadataPointer extensions via `token_ops::shares::create_mint` (Anchor 0.29
    /// `init` cannot initialize extensions).
    #[account(mut,
        seeds = [SHARES_SEEDS, vault_state.key().as_ref()],
        bump,
    )]
    pub shares_mint: AccountInfo<'info>,

    #[account(mut,
        token::mint = token_mint,
        token::authority = admin_authority,
        token::token_program = token_program
    )]
    pub admin_token_account: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: klend's UserMetadata PDA of `base_vault_authority` (derived here, with klend's
    /// seeds); klend creates it.
    #[account(mut,
        seeds = [BASE_SEED_USER_METADATA, base_vault_authority.key().as_ref()],
        bump,
        seeds::program = kamino_lending::ID,
    )]
    pub user_metadata: AccountInfo<'info>,

    /// CHECK: the klend program (address-pinned).
    #[account(address = kamino_lending::ID)]
    pub lending_program: AccountInfo<'info>,

    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
    pub token_program: Interface<'info, TokenInterface>,
    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,

    /// CHECK: Only used on the permissioned path; validated in the handler against the
    /// token-acl MintConfig PDA of the shares mint.
    #[account(mut)]
    pub shares_mint_config: Option<AccountInfo<'info>>,

    /// CHECK: Only used on the permissioned path; validated in the handler against the
    /// pinned Token ACL program id.
    pub token_acl_program: Option<AccountInfo<'info>>,
}

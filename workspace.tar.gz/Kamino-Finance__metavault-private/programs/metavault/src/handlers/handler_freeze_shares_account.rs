use anchor_lang::{prelude::*, Accounts};
use anchor_spl::{token_2022::Token2022, token_interface::TokenAccount};

use crate::{utils::token_acl, KaminoVaultError, MetavaultState};

pub fn process(ctx: Context<FreezeSharesAccount>) -> Result<()> {
    let vault = ctx.accounts.vault_state.load()?;
    vault.validate_shares_freeze_authority(ctx.accounts.authority.key())?;
    token_acl::validate_permissioned_vault_accounts(
        &vault,
        ctx.accounts.shares_mint.key,
        &ctx.accounts.shares_mint_config,
    )?;

    let vault_state_key = ctx.accounts.vault_state.key();
    token_acl::cpi_freeze(
        &token_acl::TokenAclCpiAccounts {
            token_acl_program: &ctx.accounts.token_acl_program,
            mint_config: &ctx.accounts.shares_mint_config,
            shares_mint: &ctx.accounts.shares_mint,
            base_vault_authority: &ctx.accounts.base_vault_authority,
            vault_state_key: &vault_state_key,
            base_vault_authority_bump: vault.base_vault_authority_bump,
        },
        &ctx.accounts.shares_token_program.to_account_info(),
        &ctx.accounts.user_shares_account.to_account_info(),
    )
}

#[derive(Accounts)]
pub struct FreezeSharesAccount<'info> {
    /// Validated in the handler: the vault admin or the emergency council (defensive
    /// action; the council cannot thaw).
    pub authority: Signer<'info>,

    #[account(
        has_one = base_vault_authority,
        has_one = shares_mint,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    /// CHECK: Pinned by `has_one` on `vault_state`; the token-acl config admin.
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Pinned by `has_one` on `vault_state`.
    pub shares_mint: AccountInfo<'info>,

    /// CHECK: Validated in the handler against the MintConfig PDA of the shares mint.
    pub shares_mint_config: AccountInfo<'info>,

    /// The shares token account to freeze.
    #[account(mut,
        token::mint = shares_mint,
        token::token_program = shares_token_program,
    )]
    pub user_shares_account: Box<InterfaceAccount<'info, TokenAccount>>,

    /// CHECK: Pinned program id.
    #[account(address = token_acl::TOKEN_ACL_PROGRAM_ID @ KaminoVaultError::TokenAclProgramIncorrect)]
    pub token_acl_program: AccountInfo<'info>,

    pub shares_token_program: Program<'info, Token2022>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};

use crate::{
    events::{WithdrawOrderClosedEvent, WithdrawOrderEndReason},
    operations::{
        effects::OrderPayoutEffects,
        withdraw_order_operations::{settle_withdraw_order, SettleMode},
    },
    order::WithdrawOrder,
    types::Timestamp,
    utils::{
        order_accounts::PayoutAccounts, remaining_accounts::RemainingAccounts,
        scope::VaultScopePrices, token_ops,
    },
    KaminoVaultError, MetavaultState,
};

/// Pays out everything a withdraw order holds to its owner and deletes it: the owner may settle at
/// any time (cutting a running auction short), anyone else once the auction is over.
pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, SettleWithdrawOrder<'info>>,
) -> Result<()> {
    crate::check_cpi!(ctx);

    // Regular accounts:
    let vault_state_key = ctx.accounts.vault_state.key();
    let order_key = ctx.accounts.withdraw_order.key();
    let by_owner = ctx.accounts.signer.key() == ctx.accounts.owner.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let mut order = ctx.accounts.withdraw_order.load_mut()?;
    let current_timestamp = Timestamp::capture(&Clock::get()?)?;

    // Remaining accounts: (the prices needed only for non-owners, and the payout accounts)
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let mode = if by_owner {
        SettleMode::ByOwner
    } else {
        SettleMode::Permissionless(VaultScopePrices::load_and_validate_from_remaining_accounts(
            vault_state,
            &mut remaining,
            current_timestamp,
        )?)
    };
    let payout_accounts = PayoutAccounts::parse(&*order, vault_state, by_owner, &mut remaining)?;
    remaining.check_none_remaining()?;

    // The accounting update:
    let OrderPayoutEffects {
        payouts,
        mid_auction,
    } = settle_withdraw_order(&mut order, vault_state, &mode, current_timestamp)?;

    // Effects: send everything the order held to the owner's TAs:
    token_ops::composites::transfer_all_payouts(
        &payout_accounts.per_token,
        &payouts,
        vault_state.base_vault_authority_bump,
        &ctx.accounts.vault_state.to_account_info(),
        &ctx.accounts.base_vault_authority.to_account_info(),
    )?;

    // Post-checks:
    payout_accounts.check_vault_balances_cover_locked(vault_state)?;

    // Events:
    emit_cpi!(WithdrawOrderClosedEvent {
        vault_state: vault_state_key,
        order: order_key,
        payouts: payouts.map(u64::from),
        reason: if mid_auction {
            WithdrawOrderEndReason::SettledMidAuction
        } else {
            WithdrawOrderEndReason::Settled
        },
        timestamp: current_timestamp.into(),
    });

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct SettleWithdrawOrder<'info> {
    /// The owner at any time, or anyone once the auction is over.
    pub signer: Signer<'info>,

    #[account(mut,
        has_one = base_vault_authority,
    )]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(mut,
        constraint = withdraw_order.load()?.base.vault_state == vault_state.key()
            @ KaminoVaultError::OrderAccountMismatch,
        constraint = withdraw_order.load()?.base.owner == owner.key()
            @ KaminoVaultError::OrderAccountMismatch,
        close = owner,
    )]
    pub withdraw_order: AccountLoader<'info, WithdrawOrder>,

    /// CHECK: `withdraw_order`'s owner; receives the payouts/rent
    #[account(mut)]
    pub owner: AccountInfo<'info>,

    /// CHECK: vault_state has_one check
    pub base_vault_authority: AccountInfo<'info>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: the scope prices (unless the owner settles), then the payout accounts per
    // token held, see `PayoutAccounts::parse`.
}

use anchor_lang::prelude::*;

use crate::{utils::consts::GLOBAL_CONFIG_STATE_SEEDS, GlobalConfig};

pub fn process(ctx: Context<ApplyGlobalConfigAdmin>) -> Result<()> {
    let global_config = &mut ctx.accounts.global_config.load_mut()?;

    global_config.apply_pending_admin()?;

    Ok(())
}

#[derive(Accounts)]
pub struct ApplyGlobalConfigAdmin<'info> {
    pub pending_admin: Signer<'info>,

    #[account(mut,
        seeds = [GLOBAL_CONFIG_STATE_SEEDS],
        bump,
        has_one = pending_admin)]
    pub global_config: AccountLoader<'info, GlobalConfig>,

    /// CHECK: Address-pinned, and no longer read — administrative instructions do not reject
    /// CPI (see `check_cpi!`). Kept in the layout so existing clients and the IDL stay valid.
    #[account(address = anchor_lang::solana_program::sysvar::instructions::ID)]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

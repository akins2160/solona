use crate::{
    events::DepositOrderOpenedEvent,
    operations::{
        deposit_order_operations::open_deposit_order,
        vault_checks::check_vault_balance_covers_locked,
    },
    order::DepositOrder,
    types::{Duration, RebalanceLimits, ShareAmount, Timestamp, TokenAmount},
    utils::{
        consts::{DEPOSIT_ORDER_SEED, DEPOSIT_ORDER_SIZE, MAX_ORDERS_PER_OWNER},
        order_accounts::OrderTokenAccounts,
        remaining_accounts::RemainingAccounts,
        scope::VaultScopePrices,
        token_ops::{self, tokens::UserTransferAccounts},
    },
    KaminoVaultError, MetavaultState,
};
use anchor_lang::{
    prelude::*,
    solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};

/// Locks the owner's basket in the vault's TAs and starts its auction. Mints nothing and touches
/// none of the vault's own value (so needs no shares or obligations).
pub fn process<'info>(
    ctx: Context<'_, '_, 'info, 'info, OpenDepositOrder<'info>>,
    id: u8,
    amounts: Vec<u64>,
    duration_seconds: u64,
    min_shares_out: u64,
    max_fill_slippage_bps: u64,
    max_loss_bps: u64,
) -> Result<()> {
    crate::check_cpi!(ctx);

    // Parse/validate args:
    require!(id < MAX_ORDERS_PER_OWNER, KaminoVaultError::InvalidOrderId);
    let limits = RebalanceLimits::new(max_fill_slippage_bps, max_loss_bps)?;
    let duration = Duration::from(duration_seconds);
    let amounts = amounts
        .into_iter()
        .map(TokenAmount::from)
        .collect::<Vec<_>>();

    // Regular accounts:
    let vault_state_key = ctx.accounts.vault_state.key();
    let order_key = ctx.accounts.deposit_order.key();
    let owner_key = ctx.accounts.owner.key();
    let vault_state = &mut ctx.accounts.vault_state.load_mut()?;
    let current_timestamp = Timestamp::capture(&Clock::get()?)?;
    let mut order = ctx.accounts.deposit_order.load_init()?;
    *order = DepositOrder::new(vault_state_key, owner_key, id);

    // Remaining accounts: (each non-zero amount's token accounts in dense order, then scope prices)
    let mut remaining = RemainingAccounts::new(ctx.remaining_accounts);
    let inputs = vault_state
        .enumerate_enabled_tokens()
        .zip(&amounts)
        .filter(|(_, amount)| !amount.is_zero())
        .map(|((id, token), amount)| {
            let accounts = OrderTokenAccounts::pinned(id, token, &owner_key, true, &mut remaining)?;
            Ok((accounts, *amount))
        })
        .collect::<Result<Vec<_>>>()?;
    let vault_scope_prices = VaultScopePrices::load_and_validate_from_remaining_accounts(
        vault_state,
        &mut remaining, // one scope price account per enabled token, in token order
        current_timestamp,
    )?;
    remaining.check_none_remaining()?;

    // The accounting update (no effects returned: the inputs already are all of them):
    open_deposit_order(
        &mut order,
        vault_state,
        &vault_scope_prices,
        &amounts,
        duration,
        limits,
        ShareAmount::from(min_shares_out),
        current_timestamp,
    )?;

    // Effects: move the inputs into the vault's TAs:
    for (accounts, amount) in &inputs {
        token_ops::tokens::transfer_to_vault(
            &UserTransferAccounts {
                token_program: accounts.token_program.to_account_info(),
                user_authority: ctx.accounts.owner.to_account_info(),
                token_ata: accounts.owner_ata.to_account_info(),
                token_vault: accounts.token_vault.to_account_info(),
                token_mint: accounts.mint.to_account_info(),
            },
            *amount,
            accounts.mint.decimals,
        )?;
    }

    // Post-checks:
    for (accounts, _) in &inputs {
        check_vault_balance_covers_locked(
            TokenAmount::of_account(&accounts.token_vault.to_account_info())?,
            vault_state.get_vault_token_by_id(accounts.id),
        )?;
    }

    // Events:
    emit_cpi!(DepositOrderOpenedEvent {
        vault_state: vault_state_key,
        order: order_key,
        owner: owner_key,
        timestamp: current_timestamp.into(),
        rebalance_end_timestamp: order
            .base
            .rebalance
            .window()
            .map_or(0, |window| window.end.into()),
    });

    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
#[instruction(id: u8)]
pub struct OpenDepositOrder<'info> {
    #[account(mut)]
    pub owner: Signer<'info>,

    #[account(mut)]
    pub vault_state: AccountLoader<'info, MetavaultState>,

    #[account(
        init,
        payer = owner,
        space = 8 + DEPOSIT_ORDER_SIZE,
        seeds = [DEPOSIT_ORDER_SEED, vault_state.key().as_ref(), owner.key().as_ref(), &[id]],
        bump,
    )]
    pub deposit_order: AccountLoader<'info, DepositOrder>,

    pub system_program: Program<'info, System>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
    // remaining_accounts: `[mint, token_vault, owner_ata, token_program]` per non-zero amount,
    // then the scope prices.
}

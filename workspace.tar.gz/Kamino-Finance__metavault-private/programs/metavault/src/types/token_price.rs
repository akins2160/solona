use crate::types::dollar_value::DollarValue;
use crate::types::ratio::RatioSide;
use crate::types::{Ratio, RoundingMethod};
use crate::utils::fraction::full_mul_fraction;
use kamino_lending::fraction::Fraction;
use kamino_lending::utils::ten_pow;

#[derive(Clone, Default, Debug)]
pub struct TokenPrice {
    price: Fraction,
    decimals: u8,
}

impl TokenPrice {
    pub fn new(price: Fraction, decimals: u8) -> Self {
        Self { price, decimals }
    }

    /// $1.00 price for a token with the given decimals
    pub fn one_dollar(decimals: u8) -> Self {
        Self {
            price: Fraction::from_num(1.0),
            decimals,
        }
    }

    pub fn price(&self) -> Fraction {
        self.price
    }

    pub fn decimals(&self) -> u8 {
        self.decimals
    }

    pub fn decimals_factor(&self) -> Fraction {
        Fraction::from(ten_pow(self.decimals().into()))
    }

    pub fn apply_ratio(&self, ratio: Ratio<impl RatioSide>, rounding: RoundingMethod) -> Self {
        let multiplied_price = ratio.full_mul(self.price, rounding);
        Self::new(multiplied_price, self.decimals)
    }

    /// Values a fractional token amount in dollars at this price.
    pub fn fraction_to_aum(&self, amount: Fraction, rounding: RoundingMethod) -> DollarValue {
        full_mul_fraction(amount, self.price(), self.decimals_factor(), rounding).into()
    }
}

use std::ops::{Add, Sub};

use anchor_lang::prelude::*;
use kamino_lending::fraction::FractionExtra;

use crate::types::amounts::{ShareAmount, TokenAmount};
use crate::types::macros::{define_newtype_fraction, impl_lerp, impl_self_add, impl_self_sub};
use crate::types::ratio::{Ratio, RatioSide};
use crate::types::token_price::TokenPrice;
use crate::types::RoundingMethod;
use crate::utils::fraction::{full_mul_fraction, full_mul_int, try_full_mul_fraction_floor};
use crate::KaminoVaultError;

define_newtype_fraction!(pub DollarValue);
impl_self_add!(DollarValue);
impl_self_sub!(DollarValue);
impl_lerp!(DollarValue);

impl DollarValue {
    pub fn to_tokens(self, price: &TokenPrice, rounding: RoundingMethod) -> TokenAmount {
        let tokens_f = full_mul_fraction(self.0, price.decimals_factor(), price.price(), rounding);
        TokenAmount::from_fraction(tokens_f, rounding)
    }

    /// Same as [`Self::to_tokens`] with [`RoundingMethod::Floor`], but saturates at
    /// [`TokenAmount::MAX`] instead of panicking when the value does not fit a `u64` raw amount.
    ///
    /// Only use this where the result is an upper clamp on a `u64` token amount: no token account
    /// can hold more than `u64::MAX` lamports anyway, so a clamp above that range carries the same
    /// meaning as `TokenAmount::MAX` and nothing is lost. Using it as an actual transfer amount
    /// would silently move `u64::MAX` instead of failing.
    ///
    /// Both narrowing steps saturate, not just the last one: a cheap, high-decimal token converts
    /// dollars to lamports at a large enough factor that the *intermediate* [`Fraction`] overflows
    /// too, and that step panics inside klend rather than returning. Catching only the `u64` step
    /// would leave the saturation working across a ~16x band (`u64::MAX` to `Fraction::MAX`) and
    /// panicking above it.
    pub fn to_tokens_clamp_saturating(self, price: &TokenPrice) -> TokenAmount {
        let Some(tokens_f) =
            try_full_mul_fraction_floor(self.0, price.decimals_factor(), price.price())
        else {
            return TokenAmount::MAX;
        };
        tokens_f
            .try_to_floor::<u64>()
            .map_or(TokenAmount::MAX, TokenAmount::from)
    }

    pub fn apply_ratio(self, ratio: Ratio<impl RatioSide>, rounding: RoundingMethod) -> Self {
        ratio.full_mul(self.0, rounding).into()
    }
}

impl RatioSide for DollarValue {
    fn into_u128(self) -> u128 {
        self.0.to_bits()
    }
}

define_newtype_fraction!(
    /// Net dollar value of one issued share; the unit of the performance-fee checkpoint.
    pub SharePrice
);

impl SharePrice {
    /// The value of one share out of `shares` backed by `aum`. Panics if `shares` is zero.
    pub fn of(aum: DollarValue, shares: ShareAmount, rounding: RoundingMethod) -> Self {
        Self(full_mul_int(aum.into(), 1_u64, u64::from(shares), rounding))
    }

    /// The value of one share out of `shares` backed by `aum`, or [None] for zero shares.
    pub fn try_of(aum: DollarValue, shares: ShareAmount, rounding: RoundingMethod) -> Option<Self> {
        if shares.is_zero() {
            return None;
        }
        Some(Self::of(aum, shares, rounding))
    }

    /// The dollar value of `shares` at this price.
    pub fn value_of(self, shares: ShareAmount, rounding: RoundingMethod) -> DollarValue {
        DollarValue::from(full_mul_int(self.0, u64::from(shares), 1_u64, rounding))
    }
}

impl std::iter::Sum for DollarValue {
    fn sum<I: Iterator<Item = Self>>(iter: I) -> Self {
        iter.fold(Self::ZERO, |acc, v| acc + v)
    }
}

/// A positive or negative [DollarValue].
///
/// Used to express the net market value of the vault, including obligations whose debt may
/// exceed their collateral.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct NetAum {
    pub abs_value: DollarValue,
    pub negative: bool,
}

impl NetAum {
    pub const ZERO: Self = Self {
        abs_value: DollarValue::ZERO,
        negative: false,
    };

    /// Constructs `positive - negative` as a signed `NetAum`.
    pub fn net_from_diff(positive: DollarValue, negative: DollarValue) -> Self {
        if positive >= negative {
            Self {
                abs_value: positive - negative,
                negative: false,
            }
        } else {
            Self {
                abs_value: negative - positive,
                negative: true,
            }
        }
    }

    /// Returns the absolute value if non-negative, or `None` otherwise.
    pub fn try_non_negative(self) -> Option<DollarValue> {
        if self.negative {
            return None;
        }
        Some(self.abs_value)
    }

    /// Returns the absolute value when strictly positive, or errors out otherwise.
    ///
    /// Deposits and withdrawals price shares through this, so a vault with negative AUM (its
    /// obligations' debt worth more than all it holds) refuses exits too: there is nothing left to
    /// pay out per share until the admin restores the AUM.
    pub fn check_positive(self) -> Result<DollarValue> {
        if self.negative || self.abs_value.is_zero() {
            // Technically this could be named "vault AUM zero or negative", but the distinction is not important from the outside perspective
            return Err(error!(KaminoVaultError::VaultAUMZero));
        }
        Ok(self.abs_value)
    }
}

impl From<DollarValue> for NetAum {
    fn from(value: DollarValue) -> Self {
        Self {
            abs_value: value,
            negative: false,
        }
    }
}

// Both directions of `NetAum + DollarValue` are used: `state::compute_net_aum` writes
// `compute_free_aum(...) + obligations_aum` (DollarValue on the left, NetAum on the right),
// while the obligation ops write `obligations_aum + delta` (NetAum on the left). One direction
// is the primitive; the other delegates.
impl Add<DollarValue> for NetAum {
    type Output = NetAum;

    fn add(self, rhs: DollarValue) -> NetAum {
        if self.negative {
            NetAum::net_from_diff(rhs, self.abs_value)
        } else {
            NetAum::from(rhs + self.abs_value)
        }
    }
}

impl Add<NetAum> for DollarValue {
    type Output = NetAum;

    fn add(self, rhs: NetAum) -> NetAum {
        rhs + self
    }
}

// The `+` in the negative branch is correct: subtracting a positive `rhs` from an already-negative
// value drives it further negative, i.e. its absolute value grows. Clippy's
// `suspicious_arithmetic_impl` can't reason about the sign bit.
#[allow(clippy::suspicious_arithmetic_impl)]
impl Sub<DollarValue> for NetAum {
    type Output = NetAum;

    fn sub(self, rhs: DollarValue) -> NetAum {
        if self.negative {
            NetAum {
                abs_value: self.abs_value + rhs,
                negative: true,
            }
        } else {
            NetAum::net_from_diff(self.abs_value, rhs)
        }
    }
}

// As above: subtracting a negative `rhs` adds its absolute value.
#[allow(clippy::suspicious_arithmetic_impl)]
impl Sub for NetAum {
    type Output = NetAum;

    fn sub(self, rhs: NetAum) -> NetAum {
        if rhs.negative {
            self + rhs.abs_value
        } else {
            self - rhs.abs_value
        }
    }
}

use std::ops::{Add, Sub};

use crate::types::macros::{define_newtype_u64, impl_self_add, impl_self_sub};
use anchor_lang::prelude::*;

define_newtype_u64!(
    /// Unix timestamp in seconds
    pub Timestamp
);

/// Timestamp - Timestamp = Duration (not Timestamp)
impl Sub for Timestamp {
    type Output = Duration;
    fn sub(self, rhs: Timestamp) -> Duration {
        Duration::from(u64::from(self).saturating_sub(u64::from(rhs)))
    }
}

/// Timestamp + Duration = Timestamp
impl Add<Duration> for Timestamp {
    type Output = Timestamp;
    fn add(self, rhs: Duration) -> Timestamp {
        Timestamp::from(u64::from(self).saturating_add(u64::from(rhs)))
    }
}

impl Timestamp {
    /// Safely extract timestamp from Anchor Clock sysvar
    pub fn capture(clock: &Clock) -> std::result::Result<Self, Error> {
        let ts = u64::try_from(clock.unix_timestamp)
            .map_err(|_| error!(crate::KaminoVaultError::TimestampConversionFailed))?;
        Ok(Self(ts))
    }
}

define_newtype_u64!(
    /// Time interval in seconds
    pub Duration
);
impl_self_add!(Duration);
impl_self_sub!(Duration);

impl Duration {
    pub const fn from_secs(seconds: u64) -> Duration {
        Duration::new(seconds)
    }
}

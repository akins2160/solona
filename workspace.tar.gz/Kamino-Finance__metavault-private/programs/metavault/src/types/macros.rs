/// Base newtype wrapper around u64.
/// Does NOT generate Add/Sub — use `impl_self_add!` / `impl_self_sub!` explicitly.
macro_rules! define_newtype_u64 {
    ($(#[$meta:meta])* $vis:vis $name:ident) => {
        $(#[$meta])*
        #[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Default)]
        $vis struct $name(u64);

        impl $name {
            pub const ZERO: Self = Self(0);
            pub const ONE: Self = Self(1);
            pub const MAX: Self = Self(u64::MAX);

            /// Const constructor — use `From<u64>` in non-const context.
            pub const fn new(v: u64) -> Self { Self(v) }

            pub fn is_zero(self) -> bool { self.0 == 0 }

            pub fn checked_add(self, rhs: Self) -> Option<Self> {
                self.0.checked_add(rhs.0).map(Self)
            }

            pub fn checked_sub(self, rhs: Self) -> Option<Self> {
                self.0.checked_sub(rhs.0).map(Self)
            }

            pub fn saturating_sub(self, rhs: Self) -> Self {
                Self(self.0.saturating_sub(rhs.0))
            }

            pub fn as_fraction(self) -> kamino_lending::fraction::Fraction {
                kamino_lending::fraction::Fraction::from(self.0)
            }

            pub fn from_fraction(
                f: kamino_lending::fraction::Fraction,
                rounding: $crate::types::RoundingMethod,
            ) -> Self {
                use kamino_lending::utils::FractionExtra as _;
                match rounding {
                    $crate::types::RoundingMethod::Floor => Self(f.to_floor::<u64>()),
                    $crate::types::RoundingMethod::Ceil => Self(f.to_ceil::<u64>()),
                }
            }
        }

        impl From<$name> for kamino_lending::fraction::Fraction {
            fn from(val: $name) -> kamino_lending::fraction::Fraction {
                kamino_lending::fraction::Fraction::from(val.0)
            }
        }


        impl From<$name> for u64 {
            fn from(val: $name) -> u64 { val.0 }
        }

        impl From<u64> for $name {
            fn from(val: u64) -> Self { Self(val) }
        }

        impl From<$name> for i128 {
            fn from(val: $name) -> i128 { i128::from(val.0) }
        }

        impl std::fmt::Display for $name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "{}", self.0)
            }
        }

        impl $crate::types::ratio::RatioSide for $name {
            fn into_u128(self) -> u128 {
                u128::from(self.0)
            }
        }

        impl $name {
            pub fn apply_ratio(
                self,
                ratio: $crate::types::ratio::Ratio<impl $crate::types::ratio::RatioSide>,
                rounding: $crate::types::RoundingMethod,
            ) -> Self {
                let fractional_amount = ratio.full_mul(self.as_fraction(), rounding);
                Self::from_fraction(fractional_amount, rounding)
            }
        }
    };
}

/// Opt-in: generate `Add<Self>` + `AddAssign<Self>`.
macro_rules! impl_self_add {
    ($name:ident) => {
        impl std::ops::Add for $name {
            type Output = Self;
            #[inline(always)]
            fn add(self, rhs: Self) -> Self {
                Self(self.0 + rhs.0)
            }
        }

        impl std::ops::AddAssign for $name {
            #[inline(always)]
            fn add_assign(&mut self, rhs: Self) {
                self.0 = self.0 + rhs.0;
            }
        }
    };
}

/// Opt-in: generate `Sub<Self>` + `SubAssign<Self>`.
macro_rules! impl_self_sub {
    ($name:ident) => {
        impl std::ops::Sub for $name {
            type Output = Self;
            #[inline(always)]
            fn sub(self, rhs: Self) -> Self {
                Self(self.0 - rhs.0)
            }
        }

        impl std::ops::SubAssign for $name {
            #[inline(always)]
            fn sub_assign(&mut self, rhs: Self) {
                self.0 = self.0 - rhs.0;
            }
        }
    };
}

/// Base newtype wrapper around `Fraction`.
/// Does NOT generate Add/Sub — use `impl_self_add!` / `impl_self_sub!`.
macro_rules! define_newtype_fraction {
    ($(#[$meta:meta])* $vis:vis $name:ident) => {
        $(#[$meta])*
        #[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
        $vis struct $name(kamino_lending::fraction::Fraction);

        impl $name {
            pub const ZERO: Self =
                Self(kamino_lending::fraction::Fraction::ZERO);

            pub fn from_bits(bits: u128) -> Self {
                Self(kamino_lending::fraction::Fraction::from_bits(bits))
            }

            pub fn to_bits(self) -> u128 {
                self.0.to_bits()
            }

            pub fn is_zero(self) -> bool {
                self.0 == kamino_lending::fraction::Fraction::ZERO
            }

            pub fn saturating_add(self, other: Self) -> Self {
                #[allow(unused_imports)]
                use kamino_lending::utils::FractionExtra as _;
                Self(self.0.saturating_add(other.0))
            }

            pub fn saturating_sub(self, other: Self) -> Self {
                #[allow(unused_imports)]
                use kamino_lending::utils::FractionExtra as _;
                Self(self.0.saturating_sub(other.0))
            }
        }

        impl From<kamino_lending::fraction::Fraction> for $name {
            fn from(f: kamino_lending::fraction::Fraction) -> Self {
                Self(f)
            }
        }

        impl From<$name> for kamino_lending::fraction::Fraction {
            fn from(val: $name) -> kamino_lending::fraction::Fraction {
                val.0
            }
        }

        impl std::fmt::Debug for $name {
            fn fmt(
                &self,
                f: &mut std::fmt::Formatter<'_>,
            ) -> std::fmt::Result {
                write!(f, "{}(bits={})", stringify!($name), self.0.to_bits())
            }
        }

        impl std::fmt::Display for $name {
            fn fmt(
                &self,
                f: &mut std::fmt::Formatter<'_>,
            ) -> std::fmt::Result {
                write!(f, "{}", self.0.to_bits())
            }
        }

        impl Default for $name {
            fn default() -> Self {
                Self::ZERO
            }
        }
    };
}

/// Opt-in: linear interpolation, for a newtype with `saturating_add`, `saturating_sub`,
/// `apply_ratio` and `Ord`.
macro_rules! impl_lerp {
    ($name:ident) => {
        impl $name {
            /// The value `progress` of the way from `self` towards `to`, in either direction; a
            /// `progress` above one overshoots `to`. `rounding` applies to the distance covered,
            /// so `Floor` lands nearer `self`.
            pub fn lerp(
                self,
                to: Self,
                progress: $crate::types::ratio::Ratio<impl $crate::types::ratio::RatioSide>,
                rounding: $crate::types::RoundingMethod,
            ) -> Self {
                if to >= self {
                    self.saturating_add(to.saturating_sub(self).apply_ratio(progress, rounding))
                } else {
                    self.saturating_sub(self.saturating_sub(to).apply_ratio(progress, rounding))
                }
            }
        }
    };
}

pub(crate) use define_newtype_fraction;
pub(crate) use define_newtype_u64;
pub(crate) use impl_lerp;
pub(crate) use impl_self_add;
pub(crate) use impl_self_sub;

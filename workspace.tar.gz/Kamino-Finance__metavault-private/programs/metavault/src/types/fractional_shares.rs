use kamino_lending::utils::FractionExtra;

use crate::types::amounts::ShareAmount;
use crate::types::macros::{define_newtype_fraction, impl_self_add, impl_self_sub};
use crate::types::ratio::RatioSide;
use crate::types::{Ratio, RoundingMethod};

define_newtype_fraction!(
    /// Fractional share count used for fee accounting.
    ///
    /// Unlike `ShareAmount` (integer), this preserves sub-lamport precision
    /// so that fractional fees accumulate correctly across charge cycles.
    pub FractionalShares
);
impl_self_add!(FractionalShares);
impl_self_sub!(FractionalShares);

impl FractionalShares {
    /// Largest whole-share amount that fits inside.
    pub fn floor_shares(self) -> ShareAmount {
        ShareAmount::from(self.0.to_floor::<u64>())
    }

    /// Sub-integer remainder after flooring.
    pub fn fractional_part(self) -> Self {
        Self::from(self.0 - self.0.floor())
    }

    /// Subtract a whole `ShareAmount` (e.g. after withdrawal).
    pub fn sub_shares(self, shares: ShareAmount) -> Self {
        Self::from(self.0 - shares.as_fraction())
    }

    pub fn apply_ratio(self, ratio: Ratio<impl RatioSide>, rounding: RoundingMethod) -> Self {
        Self::from(ratio.full_mul(self.0, rounding))
    }
}

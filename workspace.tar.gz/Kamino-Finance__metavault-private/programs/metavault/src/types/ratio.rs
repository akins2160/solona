use crate::types::RoundingMethod;
use crate::utils::fraction::full_mul_int;
use kamino_lending::fraction::Fraction;
use kamino_lending::utils::{FULL_BPS, U256};
use std::cmp::Ordering;
use std::fmt;
use std::fmt::Display;
use std::marker::PhantomData;
use std::ops::{Add, Mul, Sub};

pub trait RatioSide: Copy {
    fn into_u128(self) -> u128;
}

/// A `numerator / denominator` ratio carrying the unit of each side in the type system.
///
/// The denominator side defaults to the numerator side (`Ratio<N>` == `Ratio<N, N>`), which is the
/// common case. Mixed-unit ratios (`N != D`, e.g. `Ratio<TokenAmount, ShareAmount>`) can only be
/// *constructed* ([`of`](Ratio::of)) and *converted to fixed-point* ([`full_mul`](Ratio::full_mul),
/// [`to_fraction_bits`](Ratio::to_fraction_bits)): the arithmetic and ordering impls below are
/// deliberately restricted to same-unit ratios (`Ratio<N>`), so combining ratios of incompatible
/// units (e.g. multiplying tokens-per-share by a fee rate) is a compile error rather than a
/// silently meaningless value.
#[derive(Debug, Clone, Copy)]
pub struct Ratio<N: RatioSide, D: RatioSide = N> {
    numerator: u128,
    denominator: u128,
    phantom_data: PhantomData<(N, D)>,
}

impl<N: RatioSide, D: RatioSide> Ratio<N, D> {
    /// Panics if `denominator` is zero (callers rule a zero denominator out first; one that misses
    /// it aborts the instruction rather than computing a wrong value).
    pub fn of(numerator: N, denominator: D) -> Self {
        Self::raw(numerator.into_u128(), denominator.into_u128())
    }

    /// A `bps / FULL_BPS` ratio; the unit tags `N`/`D` are inferred from the usage site.
    pub const fn from_bps(bps: u64) -> Self {
        Self::raw(bps as u128, FULL_BPS as u128)
    }

    pub const fn zero() -> Self {
        Self::raw(0, 1)
    }

    pub const fn one() -> Self {
        Self {
            numerator: 1,
            denominator: 1,
            phantom_data: PhantomData,
        }
    }

    pub fn is_zero(&self) -> bool {
        self.numerator == 0
    }

    pub fn full_mul(self, fraction: Fraction, rounding: RoundingMethod) -> Fraction {
        full_mul_int(fraction, self.numerator, self.denominator, rounding)
    }

    pub fn to_fraction_bits(self, rounding: RoundingMethod) -> u128 {
        self.full_mul(Fraction::ONE, rounding).to_bits()
    }

    const fn raw(numerator: u128, denominator: u128) -> Self {
        if denominator == 0 {
            panic!("Cannot create a ratio with zero denominator");
        }
        if numerator == denominator {
            return Self::one();
        }
        Self {
            numerator,
            denominator,
            phantom_data: PhantomData,
        }
    }
}

impl<N: RatioSide> Ratio<N> {
    /// The relative difference `|value - reference| / reference` — a same-unit ratio, so it can
    /// be compared directly against a bound like [Self::from_bps]. Panics if `reference` is
    /// zero.
    pub fn rel_diff(value: N, reference: N) -> Self {
        let reference = reference.into_u128();
        Self::raw(value.into_u128().abs_diff(reference), reference)
    }

    pub fn limit_at_most(self, other: Ratio<impl RatioSide>) -> Self {
        if cmp_ratios(self, other) == Ordering::Less {
            self
        } else {
            Self::raw(other.numerator, other.denominator)
        }
    }

    /// Returns `1.0 - self`, or [None] if this ratio is not a proper fraction.
    pub fn complement(self) -> Option<Self> {
        Some(Self::raw(
            self.denominator.checked_sub(self.numerator)?,
            self.denominator,
        ))
    }

    /// Returns `self / (1.0 - self)`, or [None] if this ratio is not a proper fraction.
    pub fn reverse(self) -> Option<Self> {
        Some(Self::raw(
            self.numerator,
            self.denominator.checked_sub(self.numerator)?,
        ))
    }

    /// Returns `1.0 / self`, or [None] if this ratio is zero.
    pub fn reciprocal(self) -> Option<Self> {
        if self.is_zero() {
            return None;
        }
        Some(Self::raw(self.denominator, self.numerator))
    }
}

impl<N: RatioSide> Eq for Ratio<N> {}

impl<N: RatioSide> PartialEq for Ratio<N> {
    fn eq(&self, other: &Self) -> bool {
        self.cmp(other) == Ordering::Equal
    }
}

impl<N: RatioSide> PartialOrd for Ratio<N> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl<N: RatioSide> Ord for Ratio<N> {
    fn cmp(&self, other: &Self) -> Ordering {
        cmp_ratios(*self, *other)
    }
}

fn cmp_ratios(lhs: Ratio<impl RatioSide>, rhs: Ratio<impl RatioSide>) -> Ordering {
    let left = U256::from(lhs.numerator) * U256::from(rhs.denominator);
    let right = U256::from(rhs.numerator) * U256::from(lhs.denominator);
    left.cmp(&right)
}

impl<N: RatioSide> Display for Ratio<N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}/{}", self.numerator, self.denominator)
    }
}

// Note: callers should only use u64-based input ratios - if we ever have use-cases of u128 ratio
// muls, we need to implement a precision-reducing mul == explicitly choose rounding direction.
impl<N: RatioSide, M: RatioSide> Mul<Ratio<M>> for Ratio<N> {
    type Output = Self;

    fn mul(self, rhs: Ratio<M>) -> Self::Output {
        Self::raw(
            self.numerator * rhs.numerator,
            self.denominator * rhs.denominator,
        )
    }
}

impl<N: RatioSide> Add<Self> for Ratio<N> {
    type Output = Self;

    fn add(self, rhs: Self) -> Self::Output {
        if self.denominator == rhs.denominator {
            // Full-precision path: (all our use-cases actually use only this)
            return Self::raw(self.numerator + rhs.numerator, self.denominator);
        }
        Self::raw(
            self.numerator * rhs.denominator + rhs.numerator * self.denominator,
            self.denominator * rhs.denominator,
        )
    }
}

impl<N: RatioSide> Sub<Self> for Ratio<N> {
    type Output = Self;

    fn sub(self, rhs: Self) -> Self::Output {
        if self.denominator == rhs.denominator {
            // Full-precision path: (all our use-cases actually use only this)
            return Self::raw(self.numerator - rhs.numerator, self.denominator);
        }
        Self::raw(
            self.numerator * rhs.denominator - rhs.numerator * self.denominator,
            self.denominator * rhs.denominator,
        )
    }
}

impl RatioSide for u64 {
    fn into_u128(self) -> u128 {
        u128::from(self)
    }
}

/// A ratio of two fixed-point values: the `2^60` scale cancels between numerator and
/// denominator, so cross-multiplied comparisons stay exact.
impl RatioSide for Fraction {
    fn into_u128(self) -> u128 {
        self.to_bits()
    }
}

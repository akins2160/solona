use super::{FractionalShares, RoundingMethod};
use crate::types::dollar_value::DollarValue;
use crate::types::macros::{
    define_newtype_fraction, define_newtype_u64, impl_self_add, impl_self_sub,
};
use crate::types::token_price::TokenPrice;
use anchor_lang::prelude::*;
use anchor_spl::token_interface::accessor::amount;

define_newtype_u64!(
    /// Count of vault share tokens (minted, burned, issued)
    pub ShareAmount
);
impl_self_add!(ShareAmount);
impl_self_sub!(ShareAmount);

define_newtype_u64!(
    /// Token quantity in smallest unit (lamports)
    pub TokenAmount
);
impl_self_add!(TokenAmount);
impl_self_sub!(TokenAmount);

define_newtype_fraction!(
    /// Token quantity in smallest units, with sub-unit precision.
    ///
    /// Unlike `TokenAmount` (integer), this represents klend's fractional bookkeeping exactly —
    /// e.g. an obligation's interest-bearing debt, or all-available borrow sizing.
    pub FractionalTokenAmount
);

define_newtype_u64!(
    /// Token weight in vault for rebalance allocation
    pub Weight
);
impl_self_add!(Weight);
impl_self_sub!(Weight);

impl ShareAmount {
    /// Read the token balance from an SPL account and wrap it.
    pub fn of_account(info: &AccountInfo) -> Result<Self> {
        Ok(Self::from(amount(info)?))
    }

    pub fn as_fractional(&self) -> FractionalShares {
        FractionalShares::from(self.as_fraction())
    }
}

impl TokenAmount {
    /// Read the token balance from an SPL account and wrap it.
    pub fn of_account(info: &AccountInfo) -> Result<Self> {
        Ok(Self::from(amount(info)?))
    }

    /// Convert token amount to dollar value using the given price
    pub fn to_aum(self, price: &TokenPrice, rounding: RoundingMethod) -> DollarValue {
        price.fraction_to_aum(self.as_fraction(), rounding)
    }

    pub fn token_diff(self, other: TokenAmount) -> i128 {
        i128::from(self) - i128::from(other)
    }
}

impl FractionalTokenAmount {
    /// Convert fractional token amount to dollar value using the given price
    pub fn to_aum(self, price: &TokenPrice, rounding: RoundingMethod) -> DollarValue {
        price.fraction_to_aum(self.0, rounding)
    }
}

impl From<TokenAmount> for FractionalTokenAmount {
    fn from(amount: TokenAmount) -> Self {
        Self(amount.as_fraction())
    }
}

impl std::iter::Sum for Weight {
    fn sum<I: Iterator<Item = Self>>(iter: I) -> Self {
        iter.fold(Weight::ZERO, |a, b| a + b)
    }
}

/// A wrapper (for arbitrary "amount" types) that can additionally represent "all available".
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AllAvailableOr<T> {
    AllAvailable,
    Exactly(T),
}

impl<T: From<u64>> AllAvailableOr<T> {
    /// Treats [u64::MAX] as denoting "all available".
    pub fn resolve(amount: u64) -> Self {
        if amount == u64::MAX {
            Self::AllAvailable
        } else {
            Self::Exactly(T::from(amount))
        }
    }
}

impl<T: Into<u64>> From<AllAvailableOr<T>> for u64 {
    /// The inverse of [AllAvailableOr::resolve]: maps [AllAvailableOr::AllAvailable] back to
    /// [u64::MAX].
    fn from(value: AllAvailableOr<T>) -> u64 {
        match value {
            AllAvailableOr::AllAvailable => u64::MAX,
            AllAvailableOr::Exactly(t) => t.into(),
        }
    }
}

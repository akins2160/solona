/// A resolved ID of a [VaultToken].
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct VaultTokenId {
    /// An index within [MetavaultState::vault_tokens].
    pub storage_index: usize,

    /// An index of an associated account, within "remaining accounts".
    ///
    /// This can also be interpreted as a "dense index" of the token, i.e. its position within the
    /// [MetavaultState::iter_enabled_tokens()].
    pub input_account_index: usize,
}

/// A resolved ID of a [VaultObligation].
#[derive(Clone, Copy, Debug)]
pub struct VaultObligationId {
    /// An index within [MetavaultState::obligations].
    pub storage_index: usize,
}

use crate::types::amounts::TokenAmount;
use crate::types::ratio::Ratio;
use crate::types::RoundingMethod;
use std::cmp::max;

/// A fee specification that guarantees some minimum fee ([Self::min_amount]) if the theoretical
/// pro-rata fee ([Self::proportional_rate]) is lower.
#[derive(Clone, Debug)]
pub struct MinFeeSpec {
    proportional_rate: Ratio<u64>, // Note: we store this as Ratio in order to preserve the original precision of integer "bps" on-chain specification
    min_amount: TokenAmount,
}

impl MinFeeSpec {
    pub fn new(proportional_rate: Ratio<u64>, min_amount: TokenAmount) -> Self {
        Self {
            proportional_rate,
            min_amount,
        }
    }

    /// Returns an instance comprising the maximums of each fee mode.
    pub fn combine_max(self, other: Self) -> Self {
        MinFeeSpec::new(
            max(self.proportional_rate, other.proportional_rate),
            max(self.min_amount, other.min_amount),
        )
    }

    pub fn calculate_fee_from(&self, amount: TokenAmount) -> TokenAmount {
        max(
            self.min_amount,
            amount.apply_ratio(self.proportional_rate, RoundingMethod::Ceil),
        )
    }
}

use std::cmp::min;
use std::ops::Range;

use anchor_lang::prelude::*;
use borsh::{BorshDeserialize, BorshSerialize};
use kamino_lending::utils::FULL_BPS;

use crate::types::ratio::Ratio;
use crate::types::{
    DollarValue, Duration, RoundingMethod, Timestamp, TokenAmount, TokenPrice, VaultTokenId, Weight,
};
use crate::utils::consts::{
    DEFAULT_DUTCH_AUCTION_SCALE_BPS, MAX_DUTCH_AUCTION_SCALE_BPS, MAX_TOKENS_PER_VAULT,
    MIN_DUTCH_AUCTION_SCALE_BPS, REBALANCE_SETTLED_TOLERANCE_LAMPORTS,
};
use crate::utils::scope::VaultScopePrices;
use crate::KaminoVaultError;

/// Classification of the `start_rebalance` signer: the exact vault admin key is exempt from the
/// rebalance cooldown; any other allocation authority (the allocation delegate) is bound by it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StartRebalanceAuthority {
    /// The exact vault admin key — exempt from the rebalance cooldown.
    VaultAdmin,
    /// Any other allocation authority — bound by the rebalance cooldown.
    AllocationDelegate,
}

#[derive(Clone, Debug)]
pub struct RebalanceBounds {
    pub start_price_rate: Ratio<u64>, // Note: we store these as Ratio in order to preserve the original precision of integer "bps" on-chain specification
    pub end_price_rate: Ratio<u64>,
}

impl RebalanceBounds {
    /// Applies the time-adjusted price rate to `price`, rounding per `rounding`.
    ///
    /// The rounding direction should be chosen by the caller based on which side of the swap
    /// the price represents:
    /// - `Floor` for the buy-side adjusted price (the one fed into `to_aum`): underestimates
    ///   the AUM credit given to the solver, i.e., vault-favorable.
    /// - `Ceil` for the sell-side adjusted price (the one fed into `to_tokens`): overestimates
    ///   the sell price, i.e., fewer tokens sent out by the vault -> vault-favorable.
    pub fn adjust_price_after(
        &self,
        price: &TokenPrice,
        elapsed_time_ratio: Ratio<Duration>,
        rounding: RoundingMethod,
    ) -> TokenPrice {
        let price_rate = self.price_rate_after(elapsed_time_ratio);
        price.apply_ratio(price_rate, rounding)
    }

    fn price_rate_after(&self, elapsed: Ratio<Duration>) -> Ratio<u64> {
        let Some(remaining) = elapsed.complement() else {
            return self.end_price_rate; // end time reached/exceeded -> we stay at the end price
        };
        self.start_price_rate * remaining + self.end_price_rate * elapsed
        // the "stable lerp" formula
    }
}

/// The limits a rebalance runs under, fixed when it starts (a reconfiguration affects the next).
#[derive(BorshDeserialize, BorshSerialize, Debug, Default, PartialEq, Eq)]
#[zero_copy]
pub struct RebalanceLimits {
    /// The highest loss allowed on each fill, in bps of the fill's input value (`0` for no loss at
    /// all, `FULL_BPS` for no limit).
    pub max_fill_slippage_bps: u64,

    /// The highest loss allowed over the whole rebalance, in bps of the basket's value (`0` for no
    /// loss at all, `FULL_BPS` for no limit).
    pub max_loss_bps: u64,
}

impl RebalanceLimits {
    /// Both limits, each within `FULL_BPS`.
    pub fn new(max_fill_slippage_bps: u64, max_loss_bps: u64) -> Result<Self> {
        for bps in [max_fill_slippage_bps, max_loss_bps] {
            require_gte!(u64::from(FULL_BPS), bps, KaminoVaultError::BPSValueTooBig);
        }
        Ok(Self {
            max_fill_slippage_bps,
            max_loss_bps,
        })
    }

    /// The highest loss allowed on each fill, as a ratio of the fill's input value.
    pub fn max_fill_slippage(&self) -> Ratio<DollarValue> {
        Ratio::from_bps(self.max_fill_slippage_bps)
    }

    /// The highest loss allowed over the whole rebalance, as a ratio of the basket's value.
    pub fn max_loss(&self) -> Ratio<DollarValue> {
        Ratio::from_bps(self.max_loss_bps)
    }
}

/// One rebalance of any basket (the vault's own rebalance, a deposit order, a withdraw order): its
/// window, its limits, and what its fills lost so far.
#[derive(BorshDeserialize, BorshSerialize, Debug, Default, PartialEq, Eq)]
#[zero_copy]
pub struct RebalanceState {
    /// Start of the most recent rebalance (kept once it ends, for the vault's cooldown), or `0` if
    /// none ever happened.
    pub start_timestamp: u64,

    /// End of the rebalance in progress (exclusive: the window is `[start, end)`), or `0` when none
    /// is.
    pub end_timestamp: u64,

    /// The limits it runs under.
    pub limits: RebalanceLimits,

    /// What the rebalance's fills lost so far.
    pub lost_usd_sf: u128,

    /// The loss ceiling set at the start (`limits.max_loss_bps` of the basket's value then).
    pub ceiling_at_start_usd_sf: u128,
}

impl RebalanceState {
    /// A rebalance starting at `now`, running for `duration` under `limits`, the basket being worth
    /// `value` at the start.
    pub fn started(
        now: Timestamp,
        duration: Duration,
        value: DollarValue,
        limits: RebalanceLimits,
    ) -> Self {
        Self {
            start_timestamp: now.into(),
            end_timestamp: (now + duration).into(),
            limits,
            lost_usd_sf: 0,
            ceiling_at_start_usd_sf: value
                .apply_ratio(limits.max_loss(), RoundingMethod::Floor)
                .to_bits(),
        }
    }

    /// The window, or [None] once finished or never started (regardless of whether it can still
    /// progress).
    pub fn window(&self) -> Option<Range<Timestamp>> {
        (self.end_timestamp != 0)
            .then(|| Timestamp::from(self.start_timestamp)..Timestamp::from(self.end_timestamp))
    }

    /// Whether the rebalance was started and not finished yet (regardless of the clock).
    pub fn is_unfinished(&self) -> bool {
        self.window().is_some()
    }

    /// Whether `now` is inside the window (regardless of targets being reached).
    pub fn is_within(&self, now: Timestamp) -> bool {
        self.window()
            .filter(|window| window.contains(&now))
            .is_some()
    }

    /// How far the auction has run: `0.0` at start, `1.0` at end, [None] when outside the window.
    pub fn progress(&self, now: Timestamp) -> Option<Ratio<Duration>> {
        self.window() // is the auction even started?
            .filter(|window| window.contains(&now)) // are we currently inside the time-range?
            .map(|window| Ratio::of(now - window.start, window.end - window.start))
        // always proper fraction thanks to the check above
    }

    /// Whether nothing can be filled any more: the window elapsed, or no fill can make progress
    /// with the basket's `tokens` at these prices.
    pub fn is_over(
        &self,
        tokens: &BasketTokens,
        prices: &VaultScopePrices,
        now: Timestamp,
    ) -> bool {
        !self.is_within(now) || !tokens.is_progress_possible(prices)
    }

    /// The start of the most recent rebalance, or [None] if none ever happened (outlives the
    /// rebalance itself: [Self::finish] leaves it).
    pub fn most_recent_start(&self) -> Option<Timestamp> {
        (self.start_timestamp != 0).then(|| Timestamp::from(self.start_timestamp))
    }

    /// Clears the rebalance (no-op when already finished).
    pub fn finish(&mut self) {
        self.end_timestamp = 0;
    }

    /// Records a fill that took `value_in` in and moved the basket's value from `value_before`
    /// to `value_after`, refusing it if its loss exceeds the per-fill limit or takes the
    /// rebalance's total past the loss ceiling.
    pub fn record_fill(
        &mut self,
        value_in: DollarValue,
        value_before: DollarValue,
        value_after: DollarValue,
    ) -> Result<()> {
        // Guard against this particular fill's loss limit:
        let loss = value_before.saturating_sub(value_after);
        require_gte!(
            value_in.apply_ratio(self.limits.max_fill_slippage(), RoundingMethod::Floor),
            loss,
            KaminoVaultError::RebalanceSwapExceedsMaxLoss
        );

        // The losses must not shrink their own allowance, so the current ceiling adds them back:
        let losses_before = self.lost();
        let value_with_losses_before = value_before + losses_before;
        let current_ceiling =
            value_with_losses_before.apply_ratio(self.limits.max_loss(), RoundingMethod::Floor);

        // Guard against rebalance's total loss limit:
        let losses_after = losses_before + loss;
        require_gte!(
            min(self.ceiling_at_start(), current_ceiling), // an inflow cannot raise the ceiling we started with
            losses_after,
            KaminoVaultError::RebalanceLossCeilingExceeded
        );

        self.lost_usd_sf = losses_after.to_bits();
        Ok(())
    }

    /// What the rebalance's fills lost so far.
    pub fn lost(&self) -> DollarValue {
        DollarValue::from_bits(self.lost_usd_sf)
    }

    /// The loss ceiling set at the start.
    pub fn ceiling_at_start(&self) -> DollarValue {
        DollarValue::from_bits(self.ceiling_at_start_usd_sf)
    }
}

/// One token's dutch-auction scales, as stored on chain. A scale is a bps multiplier on the
/// oracle price: selling starts high and ends low, buying starts low and ends high, so every
/// auction opens on the vault's own favorable side and walks toward the counterparty's.
#[derive(BorshDeserialize, BorshSerialize, Debug, PartialEq, Eq)]
#[zero_copy]
pub struct DutchAuctionScales {
    pub start_scale_bps_when_selling: u64,
    pub end_scale_bps_when_selling: u64,
    pub start_scale_bps_when_buying: u64,
    pub end_scale_bps_when_buying: u64,
}

impl Default for DutchAuctionScales {
    /// No adjustment: every scale is 1.0x the oracle price.
    fn default() -> Self {
        Self {
            start_scale_bps_when_selling: DEFAULT_DUTCH_AUCTION_SCALE_BPS,
            end_scale_bps_when_selling: DEFAULT_DUTCH_AUCTION_SCALE_BPS,
            start_scale_bps_when_buying: DEFAULT_DUTCH_AUCTION_SCALE_BPS,
            end_scale_bps_when_buying: DEFAULT_DUTCH_AUCTION_SCALE_BPS,
        }
    }
}

impl DutchAuctionScales {
    /// Every scale within the configurable range, selling non-increasing and buying
    /// non-decreasing over the auction.
    pub fn validate(&self) -> Result<()> {
        let valid_range = MIN_DUTCH_AUCTION_SCALE_BPS..=MAX_DUTCH_AUCTION_SCALE_BPS;
        for scale_bps in [
            self.start_scale_bps_when_selling,
            self.end_scale_bps_when_selling,
            self.start_scale_bps_when_buying,
            self.end_scale_bps_when_buying,
        ] {
            require!(
                valid_range.contains(&scale_bps),
                KaminoVaultError::InvalidDutchAuctionBounds
            );
        }
        require_gte!(
            self.start_scale_bps_when_selling,
            self.end_scale_bps_when_selling,
            KaminoVaultError::InvalidDutchAuctionBounds
        );
        require_gte!(
            self.end_scale_bps_when_buying,
            self.start_scale_bps_when_buying,
            KaminoVaultError::InvalidDutchAuctionBounds
        );
        Ok(())
    }

    pub fn selling_bounds(&self) -> RebalanceBounds {
        RebalanceBounds {
            start_price_rate: Ratio::from_bps(self.start_scale_bps_when_selling),
            end_price_rate: Ratio::from_bps(self.end_scale_bps_when_selling),
        }
    }

    pub fn buying_bounds(&self) -> RebalanceBounds {
        RebalanceBounds {
            start_price_rate: Ratio::from_bps(self.start_scale_bps_when_buying),
            end_price_rate: Ratio::from_bps(self.end_scale_bps_when_buying),
        }
    }
}

/// The dutch-auction bounds of one fill: the curve the basket buys `token_in` along and the
/// curve it sells `token_out` along.
#[derive(Clone, Debug)]
pub struct DutchAuctionBounds {
    pub buying: RebalanceBounds,
    pub selling: RebalanceBounds,
}

impl DutchAuctionBounds {
    /// Buys `token_in` along its curve, sells `token_out` along its own.
    pub fn of_fill(token_in: &BasketToken, token_out: &BasketToken) -> Self {
        Self {
            buying: token_in.scales.buying_bounds(),
            selling: token_out.scales.selling_bounds(),
        }
    }
}

/// Every basket token's rebalance target in token lamports: its weight's share of the basket's
/// value at the given prices. Computed where it is read, never stored: a stored target goes stale
/// with every balance move and price tick.
///
/// Indexed by a token's dense position, i.e. its index among the enabled tokens and among the
/// scope-price accounts ([VaultTokenId::input_account_index]).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RebalanceTargets {
    targets: [TokenAmount; MAX_TOKENS_PER_VAULT],
    count: usize,
}

impl FromIterator<TokenAmount> for RebalanceTargets {
    /// Targets in dense token order. Panics past [MAX_TOKENS_PER_VAULT] targets, which no caller
    /// can reach: they all map a basket's tokens, bounded by the vault's token array.
    fn from_iter<I: IntoIterator<Item = TokenAmount>>(targets: I) -> Self {
        let mut this = Self {
            targets: [TokenAmount::ZERO; MAX_TOKENS_PER_VAULT],
            count: 0,
        };
        for target in targets {
            this.targets[this.count] = target;
            this.count += 1;
        }
        this
    }
}

impl RebalanceTargets {
    pub fn of(&self, id: VaultTokenId) -> TokenAmount {
        self.targets[..self.count][id.input_account_index]
    }

    /// The targets in dense token order, aligned with `iter_enabled_tokens()`.
    pub fn iter(&self) -> impl Iterator<Item = TokenAmount> + '_ {
        self.targets[..self.count].iter().copied()
    }
}

/// One token of a basket, as the rebalance logic sees it (a snapshot, not a handle).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct BasketToken {
    pub id: VaultTokenId,

    pub mint: Pubkey,

    /// The amount the basket holds (the vault's available, or the order's locked amount).
    pub available: TokenAmount,

    /// The target weight (relative to the basket's total weight).
    pub weight: Weight,

    /// The vault's current dutch-auction scales for this token (every basket prices at these).
    pub scales: DutchAuctionScales,
}

impl BasketToken {
    /// Within [REBALANCE_SETTLED_TOLERANCE_LAMPORTS] of `target` (can be neither side of a fill).
    pub fn is_settled(&self, target: TokenAmount) -> bool {
        !self.is_in_deficit(target) && !self.is_in_excess(target)
    }

    /// Below `target` by over [REBALANCE_SETTLED_TOLERANCE_LAMPORTS] (can be a fill's `token_in`).
    pub fn is_in_deficit(&self, target: TokenAmount) -> bool {
        self.deficit(target) > REBALANCE_SETTLED_TOLERANCE_LAMPORTS
    }

    /// Above `target` by over [REBALANCE_SETTLED_TOLERANCE_LAMPORTS] (can be a fill's `token_out`).
    ///
    /// A zero target has no tolerance: any balance at all is excess (the tolerance exists to stop
    /// chasing unreachable dust, and zero is reachable).
    pub fn is_in_excess(&self, target: TokenAmount) -> bool {
        if target.is_zero() {
            return !self.available.is_zero();
        }
        self.excess(target) > REBALANCE_SETTLED_TOLERANCE_LAMPORTS
    }

    /// How much of this token the basket is short of `target`.
    pub fn deficit(&self, target: TokenAmount) -> TokenAmount {
        target.saturating_sub(self.available)
    }

    /// How much of this token the basket holds above `target`.
    pub fn excess(&self, target: TokenAmount) -> TokenAmount {
        self.available.saturating_sub(target)
    }
}

/// A basket's tokens, enumerated once (small enough to pass by value: at most
/// [MAX_TOKENS_PER_VAULT] snapshots of 96 bytes).
#[derive(Clone, Copy, Debug, Default)]
pub struct BasketTokens {
    tokens: [BasketToken; MAX_TOKENS_PER_VAULT],
    len: usize,
}

impl FromIterator<BasketToken> for BasketTokens {
    /// Panics past [MAX_TOKENS_PER_VAULT] tokens (which no basket can hold).
    fn from_iter<I: IntoIterator<Item = BasketToken>>(tokens: I) -> Self {
        let mut this = Self::default();
        for token in tokens {
            this.tokens[this.len] = token;
            this.len += 1;
        }
        this
    }
}

impl<'a> IntoIterator for &'a BasketTokens {
    type Item = BasketToken;
    type IntoIter = std::iter::Copied<std::slice::Iter<'a, BasketToken>>;

    fn into_iter(self) -> Self::IntoIter {
        self.tokens[..self.len].iter().copied()
    }
}

impl BasketTokens {
    pub fn by_mint(&self, mint: &Pubkey) -> Result<BasketToken> {
        self.into_iter()
            .find(|token| token.mint == *mint)
            .ok_or_else(|| error!(KaminoVaultError::TokenNotEnabledInVault))
    }

    pub fn total_weight(&self) -> Weight {
        self.into_iter().map(|token| token.weight).sum()
    }

    /// The total value of the basket at these prices.
    pub fn value(&self, prices: &VaultScopePrices, rounding: RoundingMethod) -> DollarValue {
        self.into_iter()
            .map(|token| token.available.to_aum(prices.by_id(token.id), rounding))
            .sum()
    }

    /// Every token's target amount at these prices (the basket's value split by weight).
    pub fn targets(&self, prices: &VaultScopePrices) -> RebalanceTargets {
        let total_weight = self.total_weight();
        if total_weight.is_zero() {
            // Nothing is weighted, so nothing is targeted (and there is no share to take).
            return self.into_iter().map(|_| TokenAmount::ZERO).collect();
        }
        let total_value = self.value(prices, RoundingMethod::Ceil);
        self.into_iter()
            .map(|token| {
                total_value
                    .apply_ratio(Ratio::of(token.weight, total_weight), RoundingMethod::Floor)
                    .to_tokens_clamp_saturating(prices.by_id(token.id)) // saturate: u64::MAX means "as much as possible"
            })
            .collect()
    }

    /// Whether some fill can still make progress at these prices, regardless of the clock.
    pub fn is_progress_possible(&self, prices: &VaultScopePrices) -> bool {
        self.is_progress_possible_toward(&self.targets(prices))
    }

    /// Whether some fill can still make progress toward `targets` (some token in deficit, some in
    /// excess).
    pub fn is_progress_possible_toward(&self, targets: &RebalanceTargets) -> bool {
        let has_deficit = self
            .into_iter()
            .any(|token| token.is_in_deficit(targets.of(token.id)));
        let has_excess = self
            .into_iter()
            .any(|token| token.is_in_excess(targets.of(token.id)));
        has_deficit && has_excess
    }
}

# Release 1.0.0

## What's Changed


**Full Changelog**: 

## Staging Commands

* [ ] check Solana version (1.17.18)
* [ ] check Anchor version (0.29.0)
* [ ] build: `anchor build -p metavault -- --features=staging`
* [ ] check Solana version (1.18.x)
* [ ] deploy `solana program deploy target/deploy/metavault.so -u <rpc> -k ../kamino-lending/keys/staging/owner.json --program-id ./keys/staging/metavault.json --with-compute-unit-price 2000 --max-sign-attempts 1000 --use-rpc`
* [N/A] QA ui `mint`, `burn`
* [ ] Update IDL `anchor idl upgrade --provider.cluster <rpc> --provider.wallet ../scope/keys/staging/owner.json --filepath target/idl/metavault.json SkmjBqY7J6jemkXeTNkiWhcYRLo4JHFsQ6zzjxvz8YC`

## Mainnet Commands

* [ ] check Solana version (1.17.18)
* [ ] check Anchor version (0.29.0)
* [ ] Change version in `Cargo.toml`
* [ ] Prepare public release `./scripts/publish.py <path to public repo>`. Create a release branch and pull request.
* [ ] Install solana-verify if not already installed `cargo install solana-verify`
* [ ] run `solana-verify build` to get the verifiable build
* [ ] compute the hash of the `.so`: `solana-verify get-executable-hash target/deploy/metavault.so`
* [ ] check Solana version (1.18.x)
* [ ] Write buffer `solana program write-buffer target/deploy/metavault.so -u <rpc> -k <payer> --use-rpc --max-sign-attempts 1000 --with-compute-unit-price 10000`
* [ ] dump the buffer and check its hash matches the hash of the `.so`: `solana program dump -u <rpc> <buffer> buffer.so`
* [ ] Set buffer authority `solana program set-buffer-authority --new-buffer-authority Cyjb5r4P1j1YPEyUemWxMZKbTpBiyNQML1S1YpPvi9xE <buffer> -u m -k <payer>`
* [ ] Create multisig proposal
* [ ] Merge the release PR in the public repo
* [ ] Build the verifiable tag ` solana-verify export-pda-tx https://github.com/Kamino-Finance/metavault --program-id KMVDpdAL8Ric1GfxJPqnQN5w7Mojex1rnSoEMq8QBZG --uploader Cyjb5r4P1j1YPEyUemWxMZKbTpBiyNQML1S1YpPvi9xE --encoding base58 --compute-unit-price 0`
* [ ] Multisig vote
* [ ] Send job request to verify build `solana-verify remote submit-job --program-id KMVDpdAL8Ric1GfxJPqnQN5w7Mojex1rnSoEMq8QBZG --uploader Cyjb5r4P1j1YPEyUemWxMZKbTpBiyNQML1S1YpPvi9xE`
* [N/A] QA ui `mint`, `burn`
* [ ] Update IDL `../anchor-fork/target/release/anchor idl upgrade --provider.cluster <url> --provider.wallet ../scope/keys/staging/owner.json --filepath target/idl/metavault.json KMVDpdAL8Ric1GfxJPqnQN5w7Mojex1rnSoEMq8QBZG`
* [ ] Update IDL in klend SDK `cp target/idl/metavault.json ../klend-sdk-private/src/idl_metavault.json`
* [ ] Update codegen in klend SDK `cd ../klend-sdk-private && yarn codegen-metavault`
* [ ] Make PR in klend SDK with the idl and codegen changes
* [ ] Complete and finalize the public release. Attach `target/deploy/metavault.so` to the release artifacts
* [ ] Create a release on the private repository. Attach `target/deploy/metavault.so` to the release artifacts

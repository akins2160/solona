#!/usr/bin/env python3
"""
This script is used to generate the public version of the smart contract codebase:
   - Reset the target folder (remove all files but .git folder, README.md, LICENSE, NOTICE)
   - Copies to the provided folder the smart contract code (from `programs/metavault`)
   - Removes all the tests files and tests tools.
"""

import os
import sys
import shutil
from typing import Generator
from enum import Enum
import re


def ask_confirmation(operation: str):
    """
    Ask the user for confirmation before performing the provided operation
    """
    print("Do you want to {}? [y/n]".format(operation))
    answer = input()
    if answer.lower() != "y":
        raise Exception("Operation aborted by user")


def check_target_folder(target_path):
    """
    Check if the target folder exists and contains the required files:
        - README.md
        - LICENSE
        - NOTICE
        - .git folder
        - Cargo.lock
        - programs/metavault folder
    """
    if not os.path.exists(target_path):
        raise Exception("Target folder does not exist: {}".format(target_path))

    if not os.path.exists(os.path.join(target_path, "README.md")):
        raise Exception(
            "Missing README.md file in target folder: {}".format(target_path)
        )

    if not os.path.exists(os.path.join(target_path, "LICENSE")):
        raise Exception("Missing LICENSE file in target folder: {}".format(target_path))

    if not os.path.exists(os.path.join(target_path, "NOTICE")):
        raise Exception("Missing NOTICE file in target folder: {}".format(target_path))

    if not os.path.exists(os.path.join(target_path, ".git")):
        raise Exception("Missing .git folder in target folder: {}".format(target_path))

    if not os.path.exists(os.path.join(target_path, "Cargo.lock")):
        raise Exception(
            "Missing Cargo.lock file in target folder: {}".format(target_path)
        )

    if not os.path.exists(os.path.join(target_path, "programs/metavault")):
        raise Exception(
            "Missing programs/metavault folder in target folder: {}".format(target_path)
        )


def reset_target_folder(target_path):
    """
    Reset the target folder (remove all files in programs/metavault folder)
    """
    print("Resetting target folder: {}".format(target_path))
    for f in os.listdir(target_path):
        if f not in [".gitignore"]:
            file_path = os.path.join(target_path, f)
            if os.path.isfile(file_path):
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
            else:
                raise Exception("Unexpected file type: {}".format(file_path))


def remove_all_but_src_cargo(target_path):
    """
    Remove everything at the root except:
        - Cargo.toml
        - src/
    """
    for f in os.listdir(target_path):
        if f not in [
            "Cargo.toml",
            "src",
            ".git",
            "README.md",
            "LICENSE",
            "NOTICE",
            ".gitignore",
        ]:
            file_path = os.path.join(target_path, f)
            if os.path.isfile(file_path):
                os.remove(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
            else:
                raise Exception("Unexpected file type: {}".format(file_path))


def delete_all_non_rust_files(target_path):
    for root, dirs, files in os.walk(target_path):
        for file in files:
            if not file.endswith(".rs"):
                os.remove(os.path.join(root, file))


def find_rust_files(directory) -> Generator[str, None, None]:
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".rs"):
                yield os.path.join(root, file)


def remove_test_files(target_path: str):
    """
    Remove all the test files
    """
    target_path = os.path.join(target_path, "src")
    for file_path in find_rust_files(target_path):
        if "test" in file_path:
            if os.path.isfile(file_path):
                print("Removing test file: {}".format(file_path))
                os.remove(file_path)
            elif os.path.isdir(file_path):
                print("Removing test folder: {}".format(file_path))
                shutil.rmtree(file_path)
            else:
                raise Exception("Unexpected file type: {}".format(file_path))
    # Remove files that contains `#![cfg(test)]` or `#![cfg(feature="program-test")]` at the beginning
    for file_path in find_rust_files(target_path):
        with open(file_path, "r") as f:
            first_line = f.readline()
            if first_line.startswith("#![cfg(test)]") or first_line.startswith(
                '#![cfg(feature = "program-test")]'
            ):
                print(
                    'Removing test file including top level cfg(test) or cfg(feature="program-test"): {}'.format(
                        file_path
                    )
                )
                os.remove(file_path)


class EraseMode(Enum):
    PENDING = 0
    ONE_LINE = 1
    BLOCK = 2


def remove_tests_blocks(file_path):
    """
    Remove all the tests blocks in the code (all code block preceded by `#[cfg(test)]`)
    Remove all the comments in the code

    Args:
        target_path (str): Path to the target file
    """
    with open(file_path, "r") as file:
        lines = file.readlines()

    new_lines = []
    erase_mode: EraseMode = EraseMode.PENDING
    brace_depth = 0

    for line in lines:

        # Remove all tests blocks
        if (
            line.strip() == "#[cfg(test)]"
            or line.strip() == '#[cfg(feature = "program-test")]'
            or line.strip().startswith("#[cfg(any(test")
        ):
            erase_mode = EraseMode.ONE_LINE
        elif line.strip().startswith("#[cfg_attr(test") or line.strip().startswith(
            '#[cfg_attr(feature = "program-test"'
        ):
            erase_mode = EraseMode.PENDING
            # Replace attr attributes with a placeholder comment line
            new_lines.append("// ..\n")
        else:
            match erase_mode:
                case EraseMode.PENDING:
                    new_lines.append(line)
                case EraseMode.ONE_LINE:
                    if line.strip().endswith("{"):
                        # Count number of spaces before the first non-space character
                        space_count = 0
                        for c in line:
                            if c == " ":
                                space_count += 1
                            else:
                                break
                        brace_depth = space_count
                        erase_mode = EraseMode.BLOCK
                    elif line.strip().endswith(";"):
                        erase_mode = EraseMode.PENDING
                    elif line.strip().endswith(r"{}"):
                        erase_mode = EraseMode.PENDING
                case EraseMode.BLOCK:
                    if line.strip().endswith("}"):
                        space_count = len(line) - len(line.lstrip(" "))
                        if space_count == brace_depth:
                            erase_mode = EraseMode.PENDING

    with open(file_path, "w") as file:
        file.writelines(new_lines)


def clean_cargo_toml(file_path: str):
    """
    Replace the private repository in Cargo.toml with a public one
    Remove all dev dependencies

    Args:
        file_path (str): Path to the target Cargo.toml file
    """

    with open(file_path, "r") as f:
        content = f.read()
        # Replace private repository in Cargo.toml with a public one
        content = content.replace(
            "ssh://git@github.com/Kamino-Finance/metavault-private.git",
            "https://github.com/Kamino-Finance/metavault.git",
        )
        # Remove the program_test feature (multiple lines until ']' close)
        # program-test = [ .. ]
        # Remove the program_test feature (multiple lines until ']' close)
        content = re.sub(r"program-test\s*=\s*\[.*?\]\n", "", content, flags=re.DOTALL)
        # Remove all dev dependencies
        # truncate at # Test dependencies
        content = content.split("# Test dependencies")[0]
    with open(file_path, "w") as f:
        f.write(content)


def main():
    """
    Main function
    """
    # check target folder
    try:
        # get target folder as first argument
        target_path = os.path.abspath(
            os.path.expanduser(os.path.expandvars(sys.argv[1]))
        )
        check_target_folder(target_path)
    except Exception as e:
        print(e)
        # Print usage
        help = """
         This script is used to generate the public version of the smart contract codebase:
            - Reset the target folder (remove all files but .git folder, README.md, LICENSE, NOTICE)
            - Copies to the provided folder the smart contract code (from `programs/metavault`)
            - Removes all the tests files and tests tools.
        """
        print(help)
        print("Usage: {} <target_folder>".format(sys.argv[0]))
        sys.exit(1)

    # ask confirmation
    ask_confirmation(f"reset target folder {target_path}")

    metavault_folder = os.path.join(target_path, "programs/metavault")

    # reset target folder
    reset_target_folder(metavault_folder)

    # Move to the parent of the script directory
    os.chdir(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

    # copy smart contract code
    print("Copying smart contract code")
    shutil.copytree(
        os.path.join(os.getcwd(), "programs/metavault"),
        metavault_folder,
        dirs_exist_ok=True,
    )

    # remove all but src/ and Cargo.toml
    print("Removing all but functional code")
    remove_all_but_src_cargo(metavault_folder)

    # delete all non rust files in src/
    print("Removing all non rust files in src/")
    delete_all_non_rust_files(os.path.join(metavault_folder, "src"))

    # remove test files
    print("Removing test files")
    remove_test_files(metavault_folder)

    # remove tests blocks
    print("Removing tests blocks and comments")
    for f in find_rust_files(os.path.join(metavault_folder, "src")):
        print("Removing tests blocks in file: {}".format(f))
        remove_tests_blocks(f)

    # clean Cargo.toml
    print("Cleaning Cargo.toml")
    clean_cargo_toml(os.path.join(metavault_folder, "Cargo.toml"))

    # Run cargo check and cargo fmt
    # print("Running cargo check and cargo fmt")
    # os.system("cargo fmt")
    # os.system("cargo check")
    os.chdir(target_path)
    os.system("solana-verify build")
    os.system("sha1sum target/deploy/metavault.so")

    print("Done")


if __name__ == "__main__":
    main()

# Kamino MetaVault
This is a **Kamino MetaVault** system for managing multi-token vault deposits and withdrawals with fee structures.

## Core Components

**Program Structure:**
- `programs/metavault/src/lib.rs` - Main program entry point with instruction handlers
- `programs/metavault/src/state.rs` - Core state structures (VaultState, GlobalConfig, VaultToken)
- `programs/metavault/src/handlers/` - Instruction handlers for all vault operations
- `programs/metavault/src/operations/` - Core business logic and calculations
- `programs/metavault/src/utils/` - Utility functions for PDA, metadata, token operations

**Key State Structures:**
- `VaultState` - Main vault state containing tokens, fees, AUM tracking, and configuration
- `GlobalConfig` - Global configuration for withdrawal fees and admin management  
- `VaultToken` - Individual token configuration within a vault (up to MAX_TOKENS_PER_VAULT)

**Main Instructions:**
- `init_vault` - Initialize a new vault with scope configuration
- `buy/sell` - Core deposit/withdrawal operations with share minting/burning
- `add_vault_token` - Add new tokens to an existing vault
- `update_vault_config` - Update vault parameters
- Fee management: `withdraw_pending_fees`, `withdraw_token_pending_fees`, `give_up_pending_fees`
- Admin operations: `update_admin`, `update_global_config`, metadata management

## Key Features
- Multi-token vaults with configurable scope price feeds
- Performance and management fee structures
- Pending fee accumulation and withdrawal
- Share-based tokenization of vault positions
- Oracle price validation with TWAP support
- Token-specific deposit/withdrawal limits and fees

## Dependencies
- **Anchor 0.29.0** - Solana program framework
- **Solana 1.17.18** - Solana runtime and SDK
- **kamino_lending** - External dependency (klend-private/programs/klend)
- **scope** - Price feed integration

## Test Structure
- Integration tests in `tests/` directory covering all major operations
- Security tests in `tests/tests_security/` for access control validation  
- Unit tests in `src/operations/tests/` for calculation logic
- Property-based testing with proptest for mathematical operations
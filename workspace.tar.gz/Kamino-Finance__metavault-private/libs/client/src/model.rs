use strum::{Display, EnumString};

#[derive(Display, Debug, PartialEq, Eq, Clone, Copy, EnumString)]
pub enum TxEncoding {
    Base58,
    Base64,
}

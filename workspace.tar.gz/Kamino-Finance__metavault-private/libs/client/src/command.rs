use std::collections::HashMap;

use anchor_client::solana_sdk::{pubkey::Pubkey, signature::Signer};
use anyhow::Result;
use colored::Colorize;
use kamino_lending::{Obligation, PriceStatusFlags, Reserve, ScopeConfiguration};
use metavault::{MetavaultState, VaultConfigField, VaultToken};
use scope::{OraclePrices, Price};

use crate::metavault_client::{self, MetavaultClient};

type ScopePriceKey = (Pubkey, [u16; 4]);

// ── Global Config ───────────────────────────────────────────────────

pub async fn init_global_config<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
) -> Result<()> {
    client.init_global_config().await?;
    eprintln!("{}", "Global config initialized".green());
    Ok(())
}

pub async fn update_global_config<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    mode: metavault::utils::global_config::UpdateGlobalConfigMode,
    value: Vec<u8>,
) -> Result<()> {
    client.update_global_config(mode, value).await?;
    eprintln!("{}", "Global config updated".green());
    Ok(())
}

pub async fn update_global_config_admin<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
) -> Result<()> {
    client.update_global_config_admin().await?;
    eprintln!("{}", "Global config admin updated".green());
    Ok(())
}

// ── Vault Lifecycle ─────────────────────────────────────────────────

pub async fn init_vault<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    token_mint: Pubkey,
    token_program: Pubkey,
    scope_configuration: ScopeConfiguration,
) -> Result<()> {
    let vault_keypair = anchor_client::solana_sdk::signature::Keypair::new();
    eprintln!("Vault state pubkey: {}", vault_keypair.pubkey());
    client
        .init_vault(
            &vault_keypair,
            token_mint,
            token_program,
            scope_configuration,
        )
        .await?;
    eprintln!("{}", "Vault initialized".green());
    Ok(())
}

pub async fn add_vault_token<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    token_mint: Pubkey,
    token_program: Pubkey,
    scope_configuration: ScopeConfiguration,
) -> Result<()> {
    client
        .add_vault_token(vault, token_mint, token_program, scope_configuration)
        .await?;
    eprintln!("{}", "Vault token added".green());
    Ok(())
}

pub async fn update_vault_config<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    entry: VaultConfigField,
    data: Vec<u8>,
) -> Result<()> {
    client.update_vault_config(vault, entry, data).await?;
    eprintln!("{}", "Vault config updated".green());
    Ok(())
}

pub async fn update_admin<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
) -> Result<()> {
    client.update_admin(vault).await?;
    eprintln!("{}", "Admin updated".green());
    Ok(())
}

// ── User Operations ─────────────────────────────────────────────────

pub async fn buy<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    token_mint: Pubkey,
    max_amount: u64,
    min_shares_out: u64,
) -> Result<()> {
    client
        .buy(vault, token_mint, max_amount, min_shares_out)
        .await?;
    eprintln!("{}", "Buy successful".green());
    Ok(())
}

pub async fn sell<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    token_mint: Pubkey,
    shares_amount: u64,
    min_tokens_out: u64,
) -> Result<()> {
    client
        .sell(vault, token_mint, shares_amount, min_tokens_out)
        .await?;
    eprintln!("{}", "Sell successful".green());
    Ok(())
}

// ── Fee Management ──────────────────────────────────────────────────

pub async fn withdraw_pending_fees<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
) -> Result<()> {
    client.withdraw_pending_fees(vault).await?;
    eprintln!("{}", "Pending fees withdrawn".green());
    Ok(())
}

pub async fn give_up_pending_fees<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    max_amount: u64,
) -> Result<()> {
    client.give_up_pending_fees(vault, max_amount).await?;
    eprintln!("{}", "Pending fees given up".green());
    Ok(())
}

// ── Rebalance ───────────────────────────────────────────────────────

pub async fn start_rebalance<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    duration: u64,
) -> Result<()> {
    client.start_rebalance(vault, duration).await?;
    eprintln!("{}", "Rebalance started".green());
    Ok(())
}

pub async fn stop_rebalance<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
) -> Result<()> {
    client.stop_rebalance(vault).await?;
    eprintln!("{}", "Rebalance stopped".green());
    Ok(())
}

pub async fn rebalance_swap<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    token_in_mint: Pubkey,
    token_out_mint: Pubkey,
    amount_in: u64,
    requested_out_amount: Option<u64>,
) -> Result<()> {
    client
        .rebalance_swap(
            vault,
            token_in_mint,
            token_out_mint,
            amount_in,
            requested_out_amount,
        )
        .await?;
    eprintln!("{}", "Rebalance swap executed".green());
    Ok(())
}

// ── Obligation Admin ────────────────────────────────────────────────

pub async fn init_obligation<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    lending_market: Pubkey,
) -> Result<()> {
    let obligation = client.init_obligation(vault, lending_market).await?;
    eprintln!("Obligation pubkey: {obligation}");
    eprintln!("{}", "Obligation initialized".green());
    Ok(())
}

pub async fn deposit_obligation_collateral<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    obligation: Pubkey,
    reserve: Pubkey,
    amount: u64,
) -> Result<()> {
    client
        .deposit_obligation_collateral(vault, obligation, reserve, amount)
        .await?;
    eprintln!("{}", "Obligation collateral deposited".green());
    Ok(())
}

pub async fn withdraw_obligation_collateral<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    obligation: Pubkey,
    reserve: Pubkey,
    amount: u64,
) -> Result<()> {
    client
        .withdraw_obligation_collateral(vault, obligation, reserve, amount)
        .await?;
    eprintln!("{}", "Obligation collateral withdrawn".green());
    Ok(())
}

pub async fn borrow_obligation_liquidity<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    obligation: Pubkey,
    reserve: Pubkey,
    amount: u64,
) -> Result<()> {
    client
        .borrow_obligation_liquidity(vault, obligation, reserve, amount)
        .await?;
    eprintln!("{}", "Obligation liquidity borrowed".green());
    Ok(())
}

pub async fn repay_obligation_liquidity<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    obligation: Pubkey,
    reserve: Pubkey,
    amount: u64,
) -> Result<()> {
    client
        .repay_obligation_liquidity(vault, obligation, reserve, amount)
        .await?;
    eprintln!("{}", "Obligation liquidity repaid".green());
    Ok(())
}

pub async fn request_elevation_group<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
    obligation: Pubkey,
    new_elevation_group: u8,
) -> Result<()> {
    client
        .request_elevation_group(vault, obligation, new_elevation_group)
        .await?;
    eprintln!("{}", "Elevation group requested".green());
    Ok(())
}

// ── Read-Only ───────────────────────────────────────────────────────

pub async fn print_vault<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault: Pubkey,
) -> Result<()> {
    let vault_state = client.get_vault_state(&vault).await?;
    let enabled = metavault_client::get_enabled_vault_tokens(&vault_state);
    let prices = fetch_token_prices(client, &enabled).await;
    let obligation_reports = fetch_obligation_reports(client, &vault_state).await;
    let current_slot = client.get_rpc().get_slot().await.ok();
    print_vault_state(
        &vault,
        &vault_state,
        &enabled,
        &prices,
        &obligation_reports,
        current_slot,
    );
    Ok(())
}

pub async fn list_vaults<S: Signer + Send + Sync>(client: &MetavaultClient<S>) -> Result<()> {
    let vaults = client.get_all_vaults().await?;
    if vaults.is_empty() {
        println!("No vaults found.");
        return Ok(());
    }

    // Collect all unique scope feeds across all vaults
    let mut feed_data: HashMap<Pubkey, Option<Vec<u8>>> = HashMap::new();
    for (_, state) in &vaults {
        for token in state.iter_enabled_tokens() {
            let feed = token.scope_configuration.price_feed;
            if feed_data.contains_key(&feed) || feed == Pubkey::default() {
                continue;
            }
            let data = client.get_rpc().get_account_data(&feed).await.ok();
            feed_data.insert(feed, data);
        }
    }

    // Compute AUM for each vault
    let mut vault_rows: Vec<VaultListRow> = Vec::new();
    for (pk, state) in &vaults {
        let name = extract_vault_name(state);
        let token_count = state.get_tokens_count();
        let obligation_count = state.get_obligations_count();
        let mut total_aum: f64 = 0.0;
        let mut all_ok = true;
        for token in state.iter_enabled_tokens() {
            let feed = token.scope_configuration.price_feed;
            let price = feed_data
                .get(&feed)
                .and_then(|d| d.as_ref())
                .and_then(|d| extract_scope_price_chain(d, &token.scope_configuration.price_chain));
            if let Some(p) = price {
                total_aum += compute_token_aum(token, p);
            } else {
                all_ok = false;
            }
        }
        let free_aum = all_ok.then_some(total_aum);
        let obligation_aum = fetch_obligations_net_aum(client, state).await;
        let total_aum = match (free_aum, obligation_aum) {
            (Some(free_aum), Some(obligation_aum)) => Some(free_aum + obligation_aum),
            _ => None,
        };
        vault_rows.push(VaultListRow {
            pk: *pk,
            name,
            free_aum,
            obligation_aum,
            total_aum,
            token_count,
            obligation_count,
        });
    }

    // Sort descending by AUM (unknowns last)
    vault_rows.sort_by(|a, b| {
        option_f64_sort_value(b.total_aum)
            .partial_cmp(&option_f64_sort_value(a.total_aum))
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    println!(
        "{:<46} {:<22} {:>14} {:>16} {:>14} {:>12} {:>8}",
        "Vault", "Name", "Free AUM", "Obligation AUM", "Total AUM", "Obligations", "Tokens"
    );
    println!("{}", "-".repeat(132));
    for row in &vault_rows {
        println!(
            "{:<46} {:<22} {:>14} {:>16} {:>14} {:>12} {:>8}",
            row.pk,
            row.name,
            format_currency_or_na(row.free_aum, 2),
            format_currency_or_na(row.obligation_aum, 2),
            format_currency_or_na(row.total_aum, 2),
            row.obligation_count,
            row.token_count
        );
    }

    Ok(())
}

pub async fn print_global_config<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
) -> Result<()> {
    let config = client.get_global_config().await?;
    println!("{}", "=== Global Config ===".bold());
    println!("  Global admin:          {}", config.global_admin);
    println!("  Pending admin:         {}", config.pending_admin);
    println!("  Deposit fee lamports:  {}", config.deposit_fee_lamports);
    println!("  Deposit fee bps:       {}", config.deposit_fee_bps);
    println!(
        "  Withdrawal fee lamports: {}",
        config.withdrawal_fee_lamports
    );
    println!("  Withdrawal fee bps:    {}", config.withdrawal_fee_bps);
    Ok(())
}

struct VaultListRow {
    pk: Pubkey,
    name: String,
    free_aum: Option<f64>,
    obligation_aum: Option<f64>,
    total_aum: Option<f64>,
    token_count: usize,
    obligation_count: usize,
}

struct ObligationReport {
    pubkey: Pubkey,
    obligation: Option<Obligation>,
    reserves: HashMap<Pubkey, Option<Reserve>>,
    reserve_prices: HashMap<Pubkey, Option<f64>>,
}

async fn fetch_obligation_reports<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault_state: &MetavaultState,
) -> Vec<ObligationReport> {
    let mut reports = Vec::new();
    for vault_obligation in vault_state.iter_enabled_obligations() {
        let pubkey = vault_obligation.obligation;
        let Ok(obligation) = client.get_obligation(&pubkey).await else {
            reports.push(ObligationReport {
                pubkey,
                obligation: None,
                reserves: HashMap::new(),
                reserve_prices: HashMap::new(),
            });
            continue;
        };

        let active_reserves = metavault_client::active_obligation_reserves(&obligation);
        let mut reserves = HashMap::new();
        for reserve_pk in active_reserves
            .deposit_reserves
            .iter()
            .chain(active_reserves.borrow_reserves.iter())
        {
            if reserves.contains_key(reserve_pk) {
                continue;
            }
            reserves.insert(*reserve_pk, client.get_reserve(reserve_pk).await.ok());
        }

        let mut reserve_prices = HashMap::new();
        for (reserve_pk, reserve) in &reserves {
            let price = match reserve.as_ref() {
                Some(reserve) => fetch_reserve_scope_price(client, reserve).await,
                None => None,
            };
            reserve_prices.insert(*reserve_pk, price);
        }

        reports.push(ObligationReport {
            pubkey,
            obligation: Some(obligation),
            reserves,
            reserve_prices,
        });
    }
    reports
}

async fn fetch_obligations_net_aum<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    vault_state: &MetavaultState,
) -> Option<f64> {
    let reports = fetch_obligation_reports(client, vault_state).await;
    obligations_net_aum(&reports)
}

/// Fetch scope oracle prices for each unique price feed/chain in the
/// enabled tokens. Returns a map of (price_feed, price_chain) -> f64.
async fn fetch_token_prices<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    enabled: &[(usize, &VaultToken)],
) -> HashMap<ScopePriceKey, f64> {
    let mut prices = HashMap::new();
    let mut fetched_feeds: HashMap<Pubkey, Option<Vec<u8>>> = HashMap::new();

    for (_, token) in enabled {
        let Some(key @ (feed, price_chain)) = scope_price_key(&token.scope_configuration) else {
            continue;
        };
        if prices.contains_key(&key) {
            continue;
        }

        let data = match fetched_feeds.entry(feed) {
            std::collections::hash_map::Entry::Occupied(e) => e.get().clone(),
            std::collections::hash_map::Entry::Vacant(e) => {
                let result = client.get_rpc().get_account_data(&feed).await.ok();
                e.insert(result.clone());
                result
            }
        };

        if let Some(data) = data {
            if let Some(price) = extract_scope_price_chain(&data, &price_chain) {
                prices.insert(key, price);
            }
        }
    }
    prices
}

async fn fetch_reserve_scope_price<S: Signer + Send + Sync>(
    client: &MetavaultClient<S>,
    reserve: &Reserve,
) -> Option<f64> {
    let (feed, price_chain) = scope_price_key(&reserve.config.token_info.scope_configuration)?;
    let data = client.get_rpc().get_account_data(&feed).await.ok()?;
    extract_scope_price_chain(&data, &price_chain)
}

fn scope_price_key(scope_configuration: &ScopeConfiguration) -> Option<ScopePriceKey> {
    if scope_configuration.price_feed == Pubkey::default()
        || scope_configuration.price_chain[0] == u16::MAX
    {
        return None;
    }
    Some((
        scope_configuration.price_feed,
        scope_configuration.price_chain,
    ))
}

fn format_scope_price_chain(price_chain: &[u16; 4]) -> String {
    let chain: Vec<String> = price_chain
        .iter()
        .take_while(|&&index| index != u16::MAX)
        .map(|index| index.to_string())
        .collect();
    if chain.is_empty() {
        "N/A".to_string()
    } else {
        chain.join(",")
    }
}

fn extract_scope_price_chain(data: &[u8], price_chain: &[u16; 4]) -> Option<f64> {
    let mut price = 1.0;
    let mut any = false;
    for &chain_index in price_chain.iter().take_while(|&&index| index != u16::MAX) {
        price *= extract_scope_price(data, chain_index)?;
        any = true;
    }
    any.then_some(price)
}

/// Extract a price from raw scope `OraclePrices` account data.
/// Returns the price as f64 or None on failure.
fn extract_scope_price(data: &[u8], chain_index: u16) -> Option<f64> {
    // OraclePrices is zero-copy: 8 byte discriminator + 32 byte
    // oracle_mappings pubkey + array of DatedPrice
    let idx = chain_index as usize;
    if idx >= scope::MAX_ENTRIES {
        return None;
    }
    // Skip 8-byte anchor discriminator, then cast the rest
    let expected_len = 8 + std::mem::size_of::<OraclePrices>();
    if data.len() < expected_len {
        return None;
    }
    let oracle_prices: &OraclePrices =
        bytemuck::try_from_bytes(&data[8..8 + std::mem::size_of::<OraclePrices>()]).ok()?;
    let dated_price = &oracle_prices.prices[idx];
    scope_price_to_f64(&dated_price.price)
}

fn scope_price_to_f64(price: &Price) -> Option<f64> {
    if price.value == 0 {
        return None;
    }
    let exp = price.exp;
    let divisor = 10_f64.powi(exp as i32);
    Some(price.value as f64 / divisor)
}

fn extract_vault_name(state: &MetavaultState) -> String {
    let bytes: Vec<u8> = state.name.iter().copied().take_while(|&b| b != 0).collect();
    String::from_utf8(bytes).unwrap_or_default()
}

fn compute_token_aum(token: &VaultToken, price: f64) -> f64 {
    let divisor = 10_f64.powi(token.decimals as i32);
    token.token_available as f64 / divisor * price
}

fn compute_free_aum(
    enabled: &[(usize, &VaultToken)],
    prices: &HashMap<ScopePriceKey, f64>,
) -> (Vec<Option<f64>>, Option<f64>) {
    let mut token_aums = Vec::new();
    let mut total_aum = 0.0;
    for (_, token) in enabled {
        if let Some(&price) =
            scope_price_key(&token.scope_configuration).and_then(|key| prices.get(&key))
        {
            let aum = compute_token_aum(token, price);
            total_aum += aum;
            token_aums.push(Some(aum));
        } else {
            token_aums.push(None);
        }
    }

    if token_aums.iter().all(Option::is_some) {
        (token_aums, Some(total_aum))
    } else {
        (token_aums, None)
    }
}

const SCALED_FRACTION_DIVISOR: f64 = 1_152_921_504_606_846_976.0;

fn scaled_fraction_to_f64(bits: u128) -> f64 {
    bits as f64 / SCALED_FRACTION_DIVISOR
}

struct LiveObligationValuation {
    deposited_value: Option<f64>,
    borrowed_value: Option<f64>,
    net_aum: Option<f64>,
}

fn obligations_net_aum(obligation_reports: &[ObligationReport]) -> Option<f64> {
    obligation_reports.iter().try_fold(0.0, |acc, report| {
        live_obligation_valuation(report)
            .net_aum
            .map(|net_aum| acc + net_aum)
    })
}

fn live_obligation_valuation(report: &ObligationReport) -> LiveObligationValuation {
    let Some(obligation) = report.obligation.as_ref() else {
        return LiveObligationValuation {
            deposited_value: None,
            borrowed_value: None,
            net_aum: None,
        };
    };

    let deposited_value = obligation.active_deposits().try_fold(0.0, |acc, deposit| {
        let reserve = report
            .reserves
            .get(&deposit.deposit_reserve)
            .and_then(|reserve| reserve.as_ref())?;
        let price = report
            .reserve_prices
            .get(&deposit.deposit_reserve)
            .copied()??;
        live_deposit_market_value(deposit.deposited_amount, reserve, price).map(|v| acc + v)
    });

    let borrowed_value = obligation.active_borrows().try_fold(0.0, |acc, borrow| {
        let reserve = report
            .reserves
            .get(&borrow.borrow_reserve)
            .and_then(|reserve| reserve.as_ref())?;
        let price = report
            .reserve_prices
            .get(&borrow.borrow_reserve)
            .copied()??;
        Some(acc + live_borrow_market_value(borrow.borrowed_amount_sf, reserve, price))
    });

    LiveObligationValuation {
        deposited_value,
        borrowed_value,
        net_aum: deposited_value.zip(borrowed_value).map(|(d, b)| d - b),
    }
}

fn live_deposit_market_value(
    deposited_ctoken_amount: u64,
    reserve: &Reserve,
    price: f64,
) -> Option<f64> {
    let ctoken_exchange_rate = reserve_ctoken_exchange_rate(reserve)?;
    let liquidity_amount = deposited_ctoken_amount as f64 * ctoken_exchange_rate;
    Some(liquidity_market_value(liquidity_amount, reserve, price))
}

fn live_borrow_market_value(borrowed_amount_sf: u128, reserve: &Reserve, price: f64) -> f64 {
    liquidity_market_value(scaled_fraction_to_f64(borrowed_amount_sf), reserve, price)
}

fn live_borrow_factor_adjusted_market_value(
    borrowed_amount_sf: u128,
    reserve: &Reserve,
    price: f64,
    obligation: &Obligation,
) -> f64 {
    let is_in_elevation_group = obligation.elevation_group != 0;
    let borrow_factor =
        scaled_fraction_to_f64(reserve.borrow_factor_f(is_in_elevation_group).to_bits());
    live_borrow_market_value(borrowed_amount_sf, reserve, price) * borrow_factor
}

fn reserve_ctoken_exchange_rate(reserve: &Reserve) -> Option<f64> {
    let total_liquidity = scaled_fraction_to_f64(reserve.liquidity.total_supply().to_bits());
    let collateral_supply = reserve.collateral.mint_total_supply;
    if collateral_supply == 0 || total_liquidity == 0.0 {
        return Some(1.0);
    }
    Some(total_liquidity / collateral_supply as f64)
}

fn live_liquidity_amount_from_ctokens(
    deposited_ctoken_amount: u64,
    reserve: &Reserve,
) -> Option<f64> {
    reserve_ctoken_exchange_rate(reserve).map(|rate| deposited_ctoken_amount as f64 * rate)
}

fn live_liquidity_token_amount_from_ctokens(
    deposited_ctoken_amount: u64,
    reserve: &Reserve,
) -> Option<f64> {
    live_liquidity_amount_from_ctokens(deposited_ctoken_amount, reserve)
        .map(|amount| amount / reserve.liquidity.mint_factor() as f64)
}

fn liquidity_market_value(liquidity_amount: f64, reserve: &Reserve, price: f64) -> f64 {
    let divisor = 10_f64.powi(reserve.liquidity.mint_decimals as i32);
    liquidity_amount / divisor * price
}

fn obligation_ltv_percent(
    deposited_value: Option<f64>,
    borrowed_value: Option<f64>,
) -> Option<f64> {
    let deposited_value = deposited_value?;
    if deposited_value == 0.0 {
        return None;
    }
    Some(borrowed_value? / deposited_value * 100.0)
}

fn format_currency(value: f64, decimals: usize) -> String {
    if value.is_sign_negative() {
        format!("-${:.*}", decimals, value.abs())
    } else {
        format!("${:.*}", decimals, value)
    }
}

fn format_currency_or_na(value: Option<f64>, decimals: usize) -> String {
    value
        .map(|value| format_currency(value, decimals))
        .unwrap_or_else(|| "N/A".to_string())
}

#[cfg(test)]
fn format_sf_currency(bits: u128) -> String {
    format_currency(scaled_fraction_to_f64(bits), 6)
}

fn format_sf_amount(bits: u128) -> String {
    format!("{:.6}", scaled_fraction_to_f64(bits))
}

fn format_amount_or_na(value: Option<f64>, decimals: usize) -> String {
    value
        .map(|value| format!("{value:.decimals$}"))
        .unwrap_or_else(|| "N/A".to_string())
}

fn format_ltv_or_na(deposited_value: Option<f64>, borrowed_value: Option<f64>) -> String {
    obligation_ltv_percent(deposited_value, borrowed_value)
        .map(|ltv| format!("{ltv:.2}%"))
        .unwrap_or_else(|| "N/A".to_string())
}

fn option_f64_sort_value(value: Option<f64>) -> f64 {
    value.unwrap_or(f64::NEG_INFINITY)
}

fn reserve_liquidity_mint_or_na(reserve: Option<&Reserve>) -> String {
    reserve
        .map(|reserve| reserve.liquidity.mint_pubkey.to_string())
        .unwrap_or_else(|| "N/A".to_string())
}

fn reserve_price(report: &ObligationReport, reserve_pk: &Pubkey) -> Option<f64> {
    report.reserve_prices.get(reserve_pk).copied().flatten()
}

fn obligation_stale_or_na(obligation: &Obligation, current_slot: Option<u64>) -> String {
    current_slot
        .and_then(|slot| {
            obligation
                .last_update
                .is_stale(slot, PriceStatusFlags::ALL_CHECKS)
                .ok()
        })
        .map(|stale| stale.to_string())
        .unwrap_or_else(|| "N/A".to_string())
}

fn print_obligation_reports(obligation_reports: &[ObligationReport], current_slot: Option<u64>) {
    println!();
    println!(
        "{}",
        format!("--- Obligations ({}) ---", obligation_reports.len()).bold()
    );

    if obligation_reports.is_empty() {
        println!("  None");
        return;
    }

    for (idx, report) in obligation_reports.iter().enumerate() {
        println!();
        println!("  Obligation [{idx}]:");
        println!("    Pubkey:              {}", report.pubkey);

        let Some(obligation) = report.obligation.as_ref() else {
            println!("    Lending market:      N/A");
            println!("    Elevation group:     N/A");
            println!("    Deposited value:     N/A");
            println!("    Borrowed value:      N/A");
            println!("    Net AUM:             N/A");
            println!("    LTV:                 N/A");
            println!("    Last update slot:    N/A");
            println!("    Stale:               N/A");
            continue;
        };

        let live = live_obligation_valuation(report);
        println!("    Lending market:      {}", obligation.lending_market);
        println!("    Elevation group:     {}", obligation.elevation_group);
        println!(
            "    Deposited value:     {}",
            format_currency_or_na(live.deposited_value, 6)
        );
        println!(
            "    Borrowed value:      {}",
            format_currency_or_na(live.borrowed_value, 6)
        );
        println!(
            "    Net AUM:             {}",
            format_currency_or_na(live.net_aum, 6)
        );
        println!(
            "    LTV:                 {}",
            format_ltv_or_na(live.deposited_value, live.borrowed_value)
        );
        println!(
            "    Last update slot:    {}",
            obligation.last_update.get_slot()
        );
        println!(
            "    Price status bits:   0x{:02x}",
            obligation.last_update.get_price_status().bits()
        );
        println!(
            "    Stale:               {}",
            obligation_stale_or_na(obligation, current_slot)
        );

        println!("    Active deposits:");
        let mut any_deposits = false;
        for deposit in obligation.active_deposits() {
            any_deposits = true;
            let reserve = report
                .reserves
                .get(&deposit.deposit_reserve)
                .and_then(|reserve| reserve.as_ref());
            let price = reserve_price(report, &deposit.deposit_reserve);
            let liquidity_amount = reserve.and_then(|reserve| {
                live_liquidity_token_amount_from_ctokens(deposit.deposited_amount, reserve)
            });
            let value = reserve.zip(price).and_then(|(reserve, price)| {
                live_deposit_market_value(deposit.deposited_amount, reserve, price)
            });
            println!(
                "      Reserve: {} | Liquidity mint: {} | CToken amount: {} | Liquidity amount: {} | Deposited value: {}",
                deposit.deposit_reserve,
                reserve_liquidity_mint_or_na(reserve),
                deposit.deposited_amount,
                format_amount_or_na(liquidity_amount, 6),
                format_currency_or_na(value, 6)
            );
        }
        if !any_deposits {
            println!("      None");
        }

        println!("    Active borrows:");
        let mut any_borrows = false;
        for borrow in obligation.active_borrows() {
            any_borrows = true;
            let reserve = report
                .reserves
                .get(&borrow.borrow_reserve)
                .and_then(|reserve| reserve.as_ref());
            let price = reserve_price(report, &borrow.borrow_reserve);
            let borrow_value = reserve.zip(price).map(|(reserve, price)| {
                live_borrow_market_value(borrow.borrowed_amount_sf, reserve, price)
            });
            let bf_value = reserve.zip(price).map(|(reserve, price)| {
                live_borrow_factor_adjusted_market_value(
                    borrow.borrowed_amount_sf,
                    reserve,
                    price,
                    obligation,
                )
            });
            println!(
                "      Reserve: {} | Liquidity mint: {} | Borrowed amount: {} | Borrowed value: {} | BF adjusted value: {}",
                borrow.borrow_reserve,
                reserve_liquidity_mint_or_na(reserve),
                format_sf_amount(borrow.borrowed_amount_sf),
                format_currency_or_na(borrow_value, 6),
                format_currency_or_na(bf_value, 6)
            );
        }
        if !any_borrows {
            println!("      None");
        }
    }
}

fn print_vault_state(
    vault_pk: &Pubkey,
    vault_state: &MetavaultState,
    enabled: &[(usize, &VaultToken)],
    prices: &HashMap<ScopePriceKey, f64>,
    obligation_reports: &[ObligationReport],
    current_slot: Option<u64>,
) {
    println!("{}", "=== Vault State ===".bold());
    println!("  Vault pubkey:          {vault_pk}");
    println!(
        "  Admin:                 {}",
        vault_state.vault_admin_authority
    );
    println!(
        "  Allocation admin:      {}",
        vault_state.allocation_admin_authority
    );
    println!("  Pending admin:         {}", vault_state.pending_admin);
    println!("  Emergency council:     {}", vault_state.emergency_council);
    println!(
        "  Unfreeze authority:    {}",
        vault_state.unfreeze_authority
    );
    println!("  Emergency mode:        {}", vault_state.emergency_mode);
    println!("  Block deposits:        {}", vault_state.block_deposits);
    println!("  Block withdraws:       {}", vault_state.block_withdraws);
    println!(
        "  Base vault authority:  {}",
        vault_state.base_vault_authority
    );
    println!("  Shares mint:           {}", vault_state.shares_mint);
    println!("  Shares issued:         {}", vault_state.shares_issued);
    println!(
        "  Shares decimals:       {}",
        vault_state.shares_mint_decimals
    );
    println!(
        "  Management fee bps:    {}",
        vault_state.management_fee_bps
    );
    println!(
        "  Rebalance swap slippage bps: {}",
        vault_state.rebalance_limits.max_fill_slippage_bps
    );
    println!(
        "  Performance fee bps:   {}",
        vault_state.performance_fee_bps
    );
    println!(
        "  Vault lookup table:    {}",
        vault_state.vault_lookup_table
    );
    println!(
        "  Creation timestamp:    {}",
        vault_state.creation_timestamp
    );

    let name_bytes: Vec<u8> = vault_state
        .name
        .iter()
        .copied()
        .take_while(|&b| b != 0)
        .collect();
    if let Ok(name) = String::from_utf8(name_bytes) {
        println!("  Name:                  {name}");
    }

    let (token_aums, free_aum) = compute_free_aum(enabled, prices);
    let obligation_aum = obligations_net_aum(obligation_reports);
    let total_aum = match (free_aum, obligation_aum) {
        (Some(free_aum), Some(obligation_aum)) => Some(free_aum + obligation_aum),
        _ => None,
    };

    // Print total AUM
    println!();
    println!("{}", "--- AUM ---".bold());
    println!(
        "  Free AUM:              {}",
        format_currency_or_na(free_aum, 6)
    );
    println!(
        "  Obligation AUM:        {}",
        format_currency_or_na(obligation_aum, 6)
    );
    println!(
        "  Total AUM:             {}",
        format_currency_or_na(total_aum, 6)
    );
    println!(
        "  Obligations:           {}",
        vault_state.get_obligations_count()
    );
    if vault_state.get_obligations_count() > 0 {
        println!(
            "  Obligation pricing:    Live recompute from fetched reserves and reserve Scope prices"
        );
    }

    // Rebalance state
    println!();
    println!("{}", "--- Rebalance ---".bold());
    // A statement about the vault's books, not about liveness: the window printed below may
    // already have elapsed with nobody having closed the rebalance yet.
    match vault_state.rebalance.window() {
        Some(window) => {
            println!("  State:                 UNFINISHED");
            println!("  Start timestamp:       {}", u64::from(window.start));
            println!("  End timestamp (excl.): {}", u64::from(window.end));
        }
        None => println!("  State:                 NONE"),
    }

    print_obligation_reports(obligation_reports, current_slot);

    // Tokens
    println!();
    println!(
        "{}",
        format!("--- Vault Tokens ({}) ---", enabled.len()).bold()
    );
    let total_weight: u64 = enabled.iter().map(|(_, t)| t.weight).sum();
    for (i, (idx, token)) in enabled.iter().enumerate() {
        println!();
        println!("  Token [{}]:", idx);
        println!("    Mint:                {}", token.mint);
        println!("    Vault:               {}", token.vault);
        println!("    Token program:       {}", token.token_program);
        println!("    Available:           {}", token.token_available);
        println!("    Decimals:            {}", token.decimals);
        let target_pct = if total_weight > 0 {
            token.weight as f64 / total_weight as f64 * 100.0
        } else {
            0.0
        };
        println!("    Target weight:       {target_pct:.2}%");

        // Token AUM and ratio
        if let Some(Some(aum)) = token_aums.get(i) {
            println!("    Token AUM:           {}", format_currency(*aum, 6));
            if let Some(free_aum) = free_aum.filter(|free_aum| *free_aum > 0.0) {
                let ratio = aum / free_aum * 100.0;
                println!("    AUM ratio:           {ratio:.2}%");
            }
        } else {
            println!("    Token AUM:           N/A");
        }

        println!(
            "    Scope price feed:    {}",
            token.scope_configuration.price_feed
        );
        println!(
            "    Scope price chain:   {}",
            format_scope_price_chain(&token.scope_configuration.price_chain)
        );
        println!("    Max TWAP div bps:    {}", token.max_twap_divergence_bps);
        println!("    Max age price:       {}s", token.max_age_price_seconds);
        println!("    Max age twap:        {}s", token.max_age_twap_seconds);
        println!("    Min deposit:         {}", token.min_deposit_amount);
        println!("    Min withdraw:        {}", token.min_withdraw_amount);
        println!("    Deposit fee bps:     {}", token.deposit_fee_bps);
        println!("    Deposit fee lamports: {}", token.deposit_fee_lamports);
        println!("    Withdraw fee bps:    {}", token.withdraw_fee_bps);
        println!("    Withdraw fee lamports: {}", token.withdraw_fee_lamports);
        println!(
            "    Dutch start sell bps: {}",
            token.dutch_auction_scales.start_scale_bps_when_selling
        );
        println!(
            "    Dutch end sell bps:   {}",
            token.dutch_auction_scales.end_scale_bps_when_selling
        );
        println!(
            "    Dutch start buy bps:  {}",
            token.dutch_auction_scales.start_scale_bps_when_buying
        );
        println!(
            "    Dutch end buy bps:    {}",
            token.dutch_auction_scales.end_scale_bps_when_buying
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ONE_SF: u128 = 1u128 << 60;

    #[test]
    fn currency_formatting_handles_negative_aum() {
        assert_eq!(format_currency(12.3456, 2), "$12.35");
        assert_eq!(format_currency(-12.3456, 2), "-$12.35");
        assert_eq!(format_currency_or_na(None, 2), "N/A");
    }

    #[test]
    fn scaled_fraction_currency_formats_fixed_point_values() {
        assert_eq!(format_sf_currency(ONE_SF), "$1.000000");
        assert_eq!(format_sf_currency(ONE_SF + ONE_SF / 2), "$1.500000");
    }

    #[test]
    fn ltv_uses_unadjusted_borrowed_value_over_deposited_value() {
        let ltv = obligation_ltv_percent(Some(4.0), Some(1.0)).unwrap();
        assert!((ltv - 25.0).abs() < f64::EPSILON);
        assert!(obligation_ltv_percent(Some(0.0), Some(1.0)).is_none());
        assert!(obligation_ltv_percent(None, Some(1.0)).is_none());
    }
}

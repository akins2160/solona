use std::collections::HashSet;

use anchor_client::anchor_lang::prelude::{Rent, System};

use anchor_client::anchor_lang::{
    AccountDeserialize, AnchorDeserialize, Discriminator, Id, InstructionData, ToAccountMetas,
};
use anchor_client::solana_client::{
    nonblocking::rpc_client::RpcClient,
    rpc_config::{RpcAccountInfoConfig, RpcProgramAccountsConfig},
    rpc_filter::{Memcmp, RpcFilterType},
};
use anchor_client::solana_sdk::account::from_account;
use anchor_client::solana_sdk::account_info::IntoAccountInfo;
use anchor_client::solana_sdk::clock::Clock;
use anchor_client::solana_sdk::sysvar::{
    clock as sysvar_clock, instructions as sysvar_instructions, SysvarId,
};
use anchor_client::solana_sdk::{
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    signature::{Keypair, Signer},
    transaction::VersionedTransaction,
};
use anchor_spl::{
    associated_token::get_associated_token_address_with_program_id, token::ID as TOKEN_PROGRAM_ID,
    token_2022::ID as TOKEN_2022_PROGRAM_ID,
};
use anyhow::{anyhow, bail, Result};
use kamino_lending::{Obligation, Reserve, ScopeConfiguration};
use metavault::operations::rebalance_basket::RebalanceBasket;
use metavault::operations::rebalance_operations;
use metavault::types::{Timestamp, TokenAmount};
use metavault::utils::consts::{
    DEPOSIT_ORDER_ACCOUNT_INDEX, KRFQ_AUTHORITY_ACCOUNT_INDEX, KRFQ_FILL_MARKER_ACCOUNT_INDEX,
    WITHDRAW_ORDER_ACCOUNT_INDEX,
};
use metavault::utils::remaining_accounts::RemainingAccounts;
use metavault::utils::scope::VaultScopePrices;
use metavault::{GlobalConfig, MetavaultState, VaultConfigField, VaultToken};
use orbit_link::async_client::dry_run::DryRunAsyncClient;
use orbit_link::async_client::AsyncClient;
use orbit_link::OrbitLink;
use spl_associated_token_account::instruction::create_associated_token_account_idempotent;
use tracing::info;

use crate::pda::vault_user_metadata_pda;
use crate::{model::TxEncoding, pda};

pub type DryRunRpcClient = DryRunAsyncClient<RpcClient>;

pub struct MetavaultClient<S: Signer + Send + Sync> {
    pub client: OrbitLink<DryRunRpcClient, S>,
    pub config: Config,
}

#[derive(PartialEq, Eq, Clone, Debug)]
pub struct Config {
    pub program_id: Pubkey,
    pub tx_encoding: TxEncoding,
    pub multisig: bool,
}

pub const FARMS_PROGRAM_ID_STR: &str = "FarmsPZpWu9i7Kky8tPN37rs2TpmMrAZrC7S7vJa91Hr";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ActiveObligationReserves {
    pub deposit_reserves: Vec<Pubkey>,
    pub borrow_reserves: Vec<Pubkey>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            program_id: metavault::ID,
            tx_encoding: TxEncoding::Base58,
            multisig: false,
        }
    }
}

impl<S> MetavaultClient<S>
where
    S: Signer + Send + Sync,
{
    pub async fn new(client: OrbitLink<DryRunRpcClient, S>, config: Config) -> Result<Self> {
        Ok(Self { client, config })
    }

    pub fn get_rpc(&self) -> &RpcClient {
        self.client.client.get_rpc()
    }

    // ── Account fetching ────────────────────────────────────────────

    async fn fetch_and_deserialize<T: Discriminator + AnchorDeserialize>(
        &self,
        pubkey: &Pubkey,
    ) -> Result<T> {
        let account = self.get_rpc().get_account(pubkey).await?;
        let data: &[u8] = &account.data;
        if data.len() < 8 {
            bail!("Account data too short for discriminator");
        }
        if T::DISCRIMINATOR != data[..8] {
            bail!("Account discriminator mismatch");
        }
        let result = T::deserialize(&mut &data[8..])?;
        Ok(result)
    }

    async fn fetch_klend_account<T: AccountDeserialize>(&self, pubkey: &Pubkey) -> Result<T> {
        let account = self.get_rpc().get_account(pubkey).await?;
        if account.owner != kamino_lending::ID {
            bail!(
                "Account {pubkey} is owned by {}, expected {}",
                account.owner,
                kamino_lending::ID
            );
        }
        let mut data: &[u8] = &account.data;
        T::try_deserialize(&mut data)
            .map_err(|e| anyhow::anyhow!("Failed to decode Klend account {pubkey}: {e}"))
    }

    pub async fn get_vault_state(&self, vault: &Pubkey) -> Result<MetavaultState> {
        self.fetch_and_deserialize::<MetavaultState>(vault).await
    }

    pub async fn get_obligation(&self, obligation: &Pubkey) -> Result<Obligation> {
        self.fetch_klend_account::<Obligation>(obligation).await
    }

    pub async fn get_reserve(&self, reserve: &Pubkey) -> Result<Reserve> {
        self.fetch_klend_account::<Reserve>(reserve).await
    }

    pub async fn get_global_config(&self) -> Result<GlobalConfig> {
        let pk = pda::global_config(&self.config.program_id);
        self.fetch_and_deserialize(&pk).await
    }

    pub async fn get_all_vaults(&self) -> Result<Vec<(Pubkey, MetavaultState)>> {
        let config = RpcProgramAccountsConfig {
            filters: Some(vec![RpcFilterType::Memcmp(Memcmp::new_raw_bytes(
                0,
                MetavaultState::DISCRIMINATOR.to_vec(),
            ))]),
            account_config: RpcAccountInfoConfig {
                encoding: Some(solana_account_decoder::UiAccountEncoding::Base64),
                ..Default::default()
            },
            ..Default::default()
        };
        let accounts = self
            .get_rpc()
            .get_program_accounts_with_config(&self.config.program_id, config)
            .await?;
        let mut vaults = Vec::new();
        for (pk, account) in accounts {
            let data = &account.data;
            if data.len() < 8 || MetavaultState::DISCRIMINATOR != data[..8] {
                continue;
            }
            if let Ok(state) = MetavaultState::deserialize(&mut &data[8..]) {
                vaults.push((pk, state));
            }
        }
        Ok(vaults)
    }

    pub fn derive_next_obligation(
        &self,
        vault: &Pubkey,
        vault_state: &MetavaultState,
        lending_market: &Pubkey,
    ) -> Result<(Pubkey, u8)> {
        let obligation_id = next_obligation_id(vault_state)?;
        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, vault);
        let obligation =
            pda::klend_obligation(lending_market, &base_vault_authority, obligation_id);
        Ok((obligation, obligation_id))
    }

    // ── Transaction helpers ─────────────────────────────────────────

    async fn retry_and_send_transactions(&self, tx: VersionedTransaction) -> Result<()> {
        let result = self
            .client
            .send_retry_and_confirm_transaction(tx, None, false)
            .await
            .map_err(|e| anyhow::anyhow!("Failed to send transaction: {e:?}"))?;

        let (sig, maybe_result) = result.into_signature_and_result();
        match maybe_result {
            Some(Ok(_)) => {
                info!("Tx sig: {sig}");
            }
            Some(Err(err)) => {
                tracing::error!("Tx {sig} failed: {err:#?}");
                bail!("Transaction {sig} failed: {err:#?}");
            }
            None => {
                info!("Tx {sig} not confirmed (dry-run or timeout)");
            }
        }
        Ok(())
    }

    fn make_ix(&self, accounts: Vec<AccountMeta>, data: Vec<u8>) -> Instruction {
        Instruction {
            program_id: self.config.program_id,
            accounts,
            data,
        }
    }

    async fn build_and_send(
        &self,
        tx_builder: orbit_link::tx_builder::TxBuilder<'_, DryRunRpcClient, S>,
        extra_signers: &[&(dyn Signer + Send + Sync)],
    ) -> Result<()> {
        if self.config.multisig {
            let encoded = match self.config.tx_encoding {
                TxEncoding::Base58 => tx_builder.to_base58(),
                TxEncoding::Base64 => tx_builder.to_base64(),
            };
            println!("{encoded}");
        } else {
            let tx = tx_builder
                .build_with_auto_budget_and_fee(extra_signers, 1000, None)
                .await
                .map_err(|e| anyhow::anyhow!("Failed to build transaction: {e:?}"))?;
            self.retry_and_send_transactions(tx).await?;
        }
        Ok(())
    }

    async fn build_obligation_refresh_prelude(
        &self,
        target_reserve: Option<(Pubkey, &Reserve)>,
        obligation_pk: Pubkey,
        obligation: &Obligation,
    ) -> Result<Vec<Instruction>> {
        let active_reserves = active_obligation_reserves(obligation);
        let lending_market = obligation.lending_market;
        let mut seen = HashSet::new();
        let mut ixs = Vec::new();

        if let Some((reserve_pk, reserve)) = target_reserve {
            validate_reserve_lending_market(&reserve_pk, reserve, &lending_market)?;
            seen.insert(reserve_pk);
            ixs.push(build_klend_refresh_reserve_ix(reserve_pk, reserve));
        }

        for reserve_pk in active_reserves
            .deposit_reserves
            .iter()
            .chain(active_reserves.borrow_reserves.iter())
        {
            if !seen.insert(*reserve_pk) {
                continue;
            }
            let reserve = self.get_reserve(reserve_pk).await?;
            validate_reserve_lending_market(reserve_pk, &reserve, &lending_market)?;
            ixs.push(build_klend_refresh_reserve_ix(*reserve_pk, &reserve));
        }

        ixs.push(build_klend_refresh_obligation_ix(
            obligation_pk,
            lending_market,
            &active_reserves,
        ));
        Ok(ixs)
    }

    async fn build_registered_obligations_refresh_prelude(
        &self,
        vault_state: &MetavaultState,
        target_obligation: Option<Pubkey>,
        target_reserve: Option<(Pubkey, &Reserve)>,
    ) -> Result<Vec<Instruction>> {
        let mut ixs = Vec::new();
        for vault_obligation in vault_state.iter_enabled_obligations() {
            let obligation_pk = vault_obligation.obligation;
            let obligation = self.get_obligation(&obligation_pk).await?;
            let reserve = if Some(obligation_pk) == target_obligation {
                target_reserve
            } else {
                None
            };
            ixs.extend(
                self.build_obligation_refresh_prelude(reserve, obligation_pk, &obligation)
                    .await?,
            );
        }
        Ok(ixs)
    }

    async fn build_and_send_ixs(&self, ixs: Vec<Instruction>) -> Result<()> {
        let mut tx = self.client.tx_builder();
        for ix in ixs {
            tx = tx.add_ix(ix);
        }
        self.build_and_send(tx, &[]).await
    }

    // ── Global Config instructions ──────────────────────────────────

    pub async fn init_global_config(&self) -> Result<()> {
        let global_config_pk = pda::global_config(&self.config.program_id);
        let accounts = metavault::accounts::InitGlobalConfig {
            payer: self.client.payer_pubkey(),
            global_config: global_config_pk,
            program_data: pda::program_data(&self.config.program_id),
            system_program: System::id(),
            rent: Rent::id(),
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        let data = metavault::instruction::InitGlobalConfig {}.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn update_global_config(
        &self,
        mode: metavault::utils::global_config::UpdateGlobalConfigMode,
        value: Vec<u8>,
    ) -> Result<()> {
        let global_config_pk = pda::global_config(&self.config.program_id);
        let accounts = metavault::accounts::UpdateGlobalConfig {
            global_admin: self.client.payer_pubkey(),
            global_config: global_config_pk,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        let data = metavault::instruction::UpdateGlobalConfig { mode, value }.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn update_global_config_admin(&self) -> Result<()> {
        let global_config_pk = pda::global_config(&self.config.program_id);
        let accounts = metavault::accounts::ApplyGlobalConfigAdmin {
            pending_admin: self.client.payer_pubkey(),
            global_config: global_config_pk,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        let data = metavault::instruction::UpdateGlobalConfigAdmin {}.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    // ── Vault lifecycle instructions ────────────────────────────────

    pub async fn init_vault(
        &self,
        vault_keypair: &Keypair,
        token_mint: Pubkey,
        token_program: Pubkey,
        scope_configuration: ScopeConfiguration,
    ) -> Result<()> {
        let vault_pk = vault_keypair.pubkey();
        let global_config_pk = pda::global_config(&self.config.program_id);
        let (base_vault_authority, _) =
            pda::base_vault_authority(&self.config.program_id, &vault_pk);
        let shares_mint = pda::shares_mint(&self.config.program_id, &vault_pk);
        let token_vault = pda::token_vault(&self.config.program_id, &token_mint, &vault_pk);

        let admin_token_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &token_mint,
            &token_program,
        );

        let vault_state_size = std::mem::size_of::<MetavaultState>() + 8;
        let create_account_ix = self
            .client
            .create_account_ix(&vault_pk, vault_state_size, &self.config.program_id)
            .await?;
        let user_metadata = vault_user_metadata_pda(&base_vault_authority);

        let mut accounts = metavault::accounts::InitVault {
            admin_authority: self.client.payer_pubkey(),
            vault_state: vault_pk,
            global_config: global_config_pk,
            base_vault_authority,
            token_vault,
            token_mint,
            shares_mint,
            admin_token_account: admin_token_ata,
            system_program: System::id(),
            rent: Rent::id(),
            token_program,
            shares_token_program: TOKEN_2022_PROGRAM_ID,
            user_metadata,
            lending_program: kamino_lending::ID,
            instruction_sysvar_account: sysvar_instructions::ID,
            // Open vault; the permissioned creation flow ships with the CLI support PR.
            shares_mint_config: None,
            token_acl_program: None,
        }
        .to_account_metas(None);
        accounts.push(AccountMeta::new_readonly(
            scope_configuration.price_feed,
            false,
        ));

        let data = metavault::instruction::InitVault {
            scope_configuration,
            user_lookup_table: Pubkey::default(),
            gating_program: None,
        }
        .data();

        let ix = self.make_ix(accounts, data);
        let tx = self
            .client
            .tx_builder()
            .add_ix(create_account_ix)
            .add_ix(ix);

        self.build_and_send(tx, &[vault_keypair]).await
    }

    pub async fn add_vault_token(
        &self,
        vault: Pubkey,
        token_mint: Pubkey,
        token_program: Pubkey,
        scope_configuration: ScopeConfiguration,
    ) -> Result<()> {
        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let token_vault = pda::token_vault(&self.config.program_id, &token_mint, &vault);

        let accounts = metavault::accounts::AddVaultToken {
            vault_admin_authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            token_vault,
            token_mint,
            token_program,
            system_program: System::id(),
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        let data = metavault::instruction::AddVaultToken {
            scope_configuration,
        }
        .data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn update_vault_config(
        &self,
        vault: Pubkey,
        entry: VaultConfigField,
        field_data: Vec<u8>,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (aum_remaining_accounts, refresh_ixs) = if matches!(
            entry,
            VaultConfigField::PerformanceFeeBps | VaultConfigField::ManagementFeeBps
        ) {
            self.build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
                .await?
        } else {
            (Vec::new(), Vec::new())
        };

        let mut accounts = metavault::accounts::UpdateVaultConfig {
            vault_admin_authority: self.client.payer_pubkey(),
            vault_state: vault,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::UpdateVaultConfig {
            entry,
            data: field_data,
        }
        .data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ixs(refresh_ixs).add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn update_admin(&self, vault: Pubkey) -> Result<()> {
        let accounts = metavault::accounts::ApplyPendingAdmin {
            pending_admin: self.client.payer_pubkey(),
            vault_state: vault,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        let data = metavault::instruction::ApplyPendingAdmin {}.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    // ── User operations ─────────────────────────────────────────────

    pub async fn buy(
        &self,
        vault: Pubkey,
        token_mint: Pubkey,
        max_amount: u64,
        min_shares_out: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (aum_remaining_accounts, refresh_ixs) = self
            .build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
            .await?;
        let vault_token = vault_state.get_vault_token_by_mint(&token_mint)?;

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let shares_mint = pda::shares_mint(&self.config.program_id, &vault);
        let event_authority = pda::event_authority(&self.config.program_id);
        let global_config_pk = pda::global_config(&self.config.program_id);

        let user_token_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &token_mint,
            &vault_token.token_program,
        );
        let user_shares_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &shares_mint,
            &TOKEN_2022_PROGRAM_ID,
        );

        let mut accounts = metavault::accounts::Deposit {
            user: self.client.payer_pubkey(),
            vault_state: vault,
            global_config: global_config_pk,
            token_vault: vault_token.vault,
            token_mint,
            base_vault_authority,
            shares_mint,
            user_token_ata,
            user_shares_ata,
            token_program: vault_token.token_program,
            shares_token_program: TOKEN_2022_PROGRAM_ID,
            event_authority,
            program: self.config.program_id,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::Buy {
            max_amount,
            min_shares_out,
        }
        .data();
        let create_user_shares_ata_ix = create_associated_token_account_idempotent(
            &self.client.payer_pubkey(),
            &self.client.payer_pubkey(),
            &shares_mint,
            &TOKEN_2022_PROGRAM_ID,
        );
        let ix = self.make_ix(accounts, data);
        let tx = self
            .client
            .tx_builder()
            .add_ixs(refresh_ixs)
            .add_ix(create_user_shares_ata_ix)
            .add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn sell(
        &self,
        vault: Pubkey,
        token_mint: Pubkey,
        shares_amount: u64,
        min_tokens_out: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (aum_remaining_accounts, refresh_ixs) = self
            .build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
            .await?;
        let vault_token = vault_state.get_vault_token_by_mint(&token_mint)?;

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let shares_mint = pda::shares_mint(&self.config.program_id, &vault);
        let event_authority = pda::event_authority(&self.config.program_id);
        let global_config_pk = pda::global_config(&self.config.program_id);

        let user_token_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &token_mint,
            &vault_token.token_program,
        );
        let user_shares_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &shares_mint,
            &TOKEN_2022_PROGRAM_ID,
        );

        let mut accounts = metavault::accounts::Withdraw {
            user: self.client.payer_pubkey(),
            vault_state: vault,
            global_config: global_config_pk,
            token_vault: vault_token.vault,
            base_vault_authority,
            token_mint,
            user_token_ata,
            user_shares_ata,
            shares_mint,
            token_program: vault_token.token_program,
            shares_token_program: TOKEN_2022_PROGRAM_ID,
            event_authority,
            program: self.config.program_id,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::Sell {
            shares_amount,
            min_tokens_out,
        }
        .data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ixs(refresh_ixs).add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    // ── Obligation admin instructions ──────────────────────────────

    pub async fn init_obligation(&self, vault: Pubkey, lending_market: Pubkey) -> Result<Pubkey> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (obligation, _obligation_id) =
            self.derive_next_obligation(&vault, &vault_state, &lending_market)?;
        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let owner_user_metadata = vault_user_metadata_pda(&base_vault_authority);
        let event_authority = pda::event_authority(&self.config.program_id);

        let accounts = metavault::accounts::InitObligation {
            vault_admin_authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            obligation,
            lending_market,
            seed1_account: Pubkey::default(),
            seed2_account: Pubkey::default(),
            owner_user_metadata,
            lending_program: kamino_lending::ID,
            rent: Rent::id(),
            system_program: System::id(),
            instruction_sysvar_account: sysvar_instructions::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);

        let data = metavault::instruction::InitObligation {}.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await?;
        Ok(obligation)
    }

    pub async fn deposit_obligation_collateral(
        &self,
        vault: Pubkey,
        obligation_pk: Pubkey,
        reserve_pk: Pubkey,
        amount: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        require_registered_obligation(&vault_state, &obligation_pk)?;
        let obligation = self.get_obligation(&obligation_pk).await?;
        let reserve = self.get_reserve(&reserve_pk).await?;
        validate_reserve_lending_market(&reserve_pk, &reserve, &obligation.lending_market)?;

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let lending_market_authority =
            pda::klend_lending_market_authority(&obligation.lending_market);
        let event_authority = pda::event_authority(&self.config.program_id);
        let liquidity_mint = reserve.liquidity.mint_pubkey;
        let token_vault = pda::token_vault(&self.config.program_id, &liquidity_mint, &vault);

        let mut accounts = metavault::accounts::DepositObligationCollateral {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            obligation: obligation_pk,
            lending_market: obligation.lending_market,
            lending_market_authority,
            reserve: reserve_pk,
            reserve_liquidity_mint: liquidity_mint,
            reserve_liquidity_supply: reserve.liquidity.supply_vault,
            reserve_collateral_mint: reserve.collateral.mint_pubkey,
            reserve_destination_deposit_collateral: reserve.collateral.supply_vault,
            token_vault,
            collateral_token_program: TOKEN_PROGRAM_ID,
            liquidity_token_program: reserve.liquidity.token_program,
            instruction_sysvar_account: sysvar_instructions::ID,
            farms_program: farms_program_id(),
            lending_program: kamino_lending::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        accounts.extend(get_scope_and_obligation_remaining_accounts(&vault_state));

        let mut ixs = self
            .build_registered_obligations_refresh_prelude(
                &vault_state,
                Some(obligation_pk),
                Some((reserve_pk, &reserve)),
            )
            .await?;
        ixs.push(self.make_ix(
            accounts,
            metavault::instruction::DepositObligationCollateral { amount }.data(),
        ));
        self.build_and_send_ixs(ixs).await
    }

    pub async fn withdraw_obligation_collateral(
        &self,
        vault: Pubkey,
        obligation_pk: Pubkey,
        reserve_pk: Pubkey,
        amount: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        require_registered_obligation(&vault_state, &obligation_pk)?;
        let obligation = self.get_obligation(&obligation_pk).await?;
        let reserve = self.get_reserve(&reserve_pk).await?;
        validate_reserve_lending_market(&reserve_pk, &reserve, &obligation.lending_market)?;

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let lending_market_authority =
            pda::klend_lending_market_authority(&obligation.lending_market);
        let event_authority = pda::event_authority(&self.config.program_id);
        let liquidity_mint = reserve.liquidity.mint_pubkey;
        let token_vault = pda::token_vault(&self.config.program_id, &liquidity_mint, &vault);

        let mut accounts = metavault::accounts::WithdrawObligationCollateral {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            obligation: obligation_pk,
            lending_market: obligation.lending_market,
            lending_market_authority,
            withdraw_reserve: reserve_pk,
            reserve_liquidity_mint: liquidity_mint,
            reserve_source_collateral: reserve.collateral.supply_vault,
            reserve_collateral_mint: reserve.collateral.mint_pubkey,
            reserve_liquidity_supply: reserve.liquidity.supply_vault,
            token_vault,
            collateral_token_program: TOKEN_PROGRAM_ID,
            liquidity_token_program: reserve.liquidity.token_program,
            instruction_sysvar_account: sysvar_instructions::ID,
            farms_program: farms_program_id(),
            lending_program: kamino_lending::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        accounts.extend(get_scope_and_obligation_remaining_accounts(&vault_state));

        let mut ixs = self
            .build_registered_obligations_refresh_prelude(
                &vault_state,
                Some(obligation_pk),
                Some((reserve_pk, &reserve)),
            )
            .await?;
        ixs.push(
            self.make_ix(
                accounts,
                metavault::instruction::WithdrawObligationCollateral {
                    collateral_amount: amount,
                }
                .data(),
            ),
        );
        self.build_and_send_ixs(ixs).await
    }

    pub async fn borrow_obligation_liquidity(
        &self,
        vault: Pubkey,
        obligation_pk: Pubkey,
        reserve_pk: Pubkey,
        amount: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        require_registered_obligation(&vault_state, &obligation_pk)?;
        let obligation = self.get_obligation(&obligation_pk).await?;
        let reserve = self.get_reserve(&reserve_pk).await?;
        validate_reserve_lending_market(&reserve_pk, &reserve, &obligation.lending_market)?;

        let active_reserves = active_obligation_reserves(&obligation);
        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let lending_market_authority =
            pda::klend_lending_market_authority(&obligation.lending_market);
        let event_authority = pda::event_authority(&self.config.program_id);
        let liquidity_mint = reserve.liquidity.mint_pubkey;
        let token_vault = pda::token_vault(&self.config.program_id, &liquidity_mint, &vault);

        let mut accounts = metavault::accounts::BorrowObligationLiquidity {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            obligation: obligation_pk,
            lending_market: obligation.lending_market,
            lending_market_authority,
            borrow_reserve: reserve_pk,
            borrow_reserve_liquidity_mint: liquidity_mint,
            reserve_source_liquidity: reserve.liquidity.supply_vault,
            borrow_reserve_liquidity_fee_receiver: reserve.liquidity.fee_vault,
            token_vault,
            token_program: reserve.liquidity.token_program,
            instruction_sysvar_account: sysvar_instructions::ID,
            farms_program: farms_program_id(),
            lending_program: kamino_lending::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        accounts.extend(get_scope_and_obligation_remaining_accounts(&vault_state));
        accounts.extend(
            active_reserves
                .deposit_reserves
                .iter()
                .map(|reserve| AccountMeta::new(*reserve, false)),
        );

        let mut ixs = self
            .build_registered_obligations_refresh_prelude(
                &vault_state,
                Some(obligation_pk),
                Some((reserve_pk, &reserve)),
            )
            .await?;
        ixs.push(
            self.make_ix(
                accounts,
                metavault::instruction::BorrowObligationLiquidity {
                    liquidity_amount: amount,
                }
                .data(),
            ),
        );
        self.build_and_send_ixs(ixs).await
    }

    pub async fn repay_obligation_liquidity(
        &self,
        vault: Pubkey,
        obligation_pk: Pubkey,
        reserve_pk: Pubkey,
        amount: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        require_registered_obligation(&vault_state, &obligation_pk)?;
        let obligation = self.get_obligation(&obligation_pk).await?;
        let reserve = self.get_reserve(&reserve_pk).await?;
        validate_reserve_lending_market(&reserve_pk, &reserve, &obligation.lending_market)?;

        let active_reserves = active_obligation_reserves(&obligation);
        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let lending_market_authority =
            pda::klend_lending_market_authority(&obligation.lending_market);
        let event_authority = pda::event_authority(&self.config.program_id);
        let liquidity_mint = reserve.liquidity.mint_pubkey;
        let token_vault = pda::token_vault(&self.config.program_id, &liquidity_mint, &vault);

        let mut accounts = metavault::accounts::RepayObligationLiquidity {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            obligation: obligation_pk,
            lending_market: obligation.lending_market,
            lending_market_authority,
            repay_reserve: reserve_pk,
            reserve_liquidity_mint: liquidity_mint,
            reserve_destination_liquidity: reserve.liquidity.supply_vault,
            token_vault,
            token_program: reserve.liquidity.token_program,
            instruction_sysvar_account: sysvar_instructions::ID,
            farms_program: farms_program_id(),
            lending_program: kamino_lending::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        accounts.extend(get_scope_and_obligation_remaining_accounts(&vault_state));
        accounts.extend(
            active_reserves
                .deposit_reserves
                .iter()
                .map(|reserve| AccountMeta::new(*reserve, false)),
        );

        let mut ixs = self
            .build_registered_obligations_refresh_prelude(
                &vault_state,
                Some(obligation_pk),
                Some((reserve_pk, &reserve)),
            )
            .await?;
        ixs.push(
            self.make_ix(
                accounts,
                metavault::instruction::RepayObligationLiquidity {
                    liquidity_amount: amount,
                }
                .data(),
            ),
        );
        self.build_and_send_ixs(ixs).await
    }

    pub async fn request_elevation_group(
        &self,
        vault: Pubkey,
        obligation_pk: Pubkey,
        new_elevation_group: u8,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        require_registered_obligation(&vault_state, &obligation_pk)?;
        let obligation = self.get_obligation(&obligation_pk).await?;
        let active_reserves = active_obligation_reserves(&obligation);

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let event_authority = pda::event_authority(&self.config.program_id);

        let mut accounts = metavault::accounts::RequestElevationGroup {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            obligation: obligation_pk,
            lending_market: obligation.lending_market,
            lending_program: kamino_lending::ID,
            instruction_sysvar_account: sysvar_instructions::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        accounts.extend(
            active_reserves
                .deposit_reserves
                .iter()
                .chain(active_reserves.borrow_reserves.iter())
                .map(|reserve| AccountMeta::new(*reserve, false)),
        );

        let mut ixs = self
            .build_obligation_refresh_prelude(None, obligation_pk, &obligation)
            .await?;
        ixs.push(
            self.make_ix(
                accounts,
                metavault::instruction::RequestElevationGroup {
                    new_elevation_group,
                }
                .data(),
            ),
        );
        self.build_and_send_ixs(ixs).await
    }

    // ── Fee management ──────────────────────────────────────────────

    pub async fn withdraw_pending_fees(&self, vault: Pubkey) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (aum_remaining_accounts, refresh_ixs) = self
            .build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
            .await?;

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let shares_mint = pda::shares_mint(&self.config.program_id, &vault);

        let admin_shares_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &shares_mint,
            &TOKEN_2022_PROGRAM_ID,
        );

        let mut accounts = metavault::accounts::WithdrawPendingFees {
            vault_admin_authority: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            admin_shares_ata,
            shares_mint,
            shares_token_program: TOKEN_2022_PROGRAM_ID,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::WithdrawPendingFees {}.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ixs(refresh_ixs).add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn give_up_pending_fees(
        &self,
        vault: Pubkey,
        max_amount_to_give_up: u64,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (aum_remaining_accounts, refresh_ixs) = self
            .build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
            .await?;

        let mut accounts = metavault::accounts::GiveUpPendingFees {
            vault_admin_authority: self.client.payer_pubkey(),
            vault_state: vault,
            instruction_sysvar_account: sysvar_instructions::ID,
        }
        .to_account_metas(None);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::GiveUpPendingFees {
            max_amount_to_give_up,
        }
        .data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ixs(refresh_ixs).add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    async fn build_aum_remaining_accounts_and_refresh_prelude(
        &self,
        vault_state: &MetavaultState,
    ) -> Result<(Vec<AccountMeta>, Vec<Instruction>)> {
        let remaining_accounts = get_scope_and_obligation_remaining_accounts(vault_state);
        let refresh_ixs = self
            .build_registered_obligations_refresh_prelude(vault_state, None, None)
            .await?;
        Ok((remaining_accounts, refresh_ixs))
    }

    // ── Rebalance ───────────────────────────────────────────────────

    pub async fn start_rebalance(&self, vault: Pubkey, rebalance_duration: u64) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let (aum_remaining_accounts, refresh_ixs) = self
            .build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
            .await?;
        let event_authority = pda::event_authority(&self.config.program_id);

        let mut accounts = metavault::accounts::StartRebalance {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            instruction_sysvar_account: sysvar_instructions::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::StartRebalance { rebalance_duration }.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ixs(refresh_ixs).add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn stop_rebalance(&self, vault: Pubkey) -> Result<()> {
        let event_authority = pda::event_authority(&self.config.program_id);
        let accounts = metavault::accounts::StopRebalance {
            authority: self.client.payer_pubkey(),
            vault_state: vault,
            instruction_sysvar_account: sysvar_instructions::ID,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        let data = metavault::instruction::StopRebalance {}.data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    pub async fn rebalance_swap(
        &self,
        vault: Pubkey,
        token_in_mint: Pubkey,
        token_out_mint: Pubkey,
        amount_in: u64,
        requested_out_amount: Option<u64>,
    ) -> Result<()> {
        let vault_state = self.get_vault_state(&vault).await?;
        let requested_out_amount = match requested_out_amount {
            Some(amount) => amount,
            None => {
                self.quote_rebalance_swap_at_curve(
                    &vault_state,
                    token_in_mint,
                    token_out_mint,
                    amount_in,
                )
                .await?
            }
        };
        let (aum_remaining_accounts, refresh_ixs) = self
            .build_aum_remaining_accounts_and_refresh_prelude(&vault_state)
            .await?;
        let token_in = vault_state.get_vault_token_by_mint(&token_in_mint)?;
        let token_out = vault_state.get_vault_token_by_mint(&token_out_mint)?;

        let (base_vault_authority, _) = pda::base_vault_authority(&self.config.program_id, &vault);
        let event_authority = pda::event_authority(&self.config.program_id);

        let user_token_in_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &token_in_mint,
            &token_in.token_program,
        );
        let user_token_out_ata = get_associated_token_address_with_program_id(
            &self.client.payer_pubkey(),
            &token_out_mint,
            &token_out.token_program,
        );

        let mut accounts = metavault::accounts::RebalanceSwap {
            user: self.client.payer_pubkey(),
            vault_state: vault,
            base_vault_authority,
            token_in_mint,
            token_in_vault: token_in.vault,
            user_token_in_ata,
            token_out_mint,
            token_out_vault: token_out.vault,
            user_token_out_ata,
            token_in_program: token_in.token_program,
            token_out_program: token_out.token_program,
            instruction_sysvar_account: sysvar_instructions::ID,
            krfq_authority: None,
            global_config: pda::global_config(&self.config.program_id),
            // The CLI fills directly, never through the krfq auction, so it
            // carries neither the co-signature nor the marker that binds one.
            krfq_fill_marker: None,
            // The CLI fills the vault itself, never an order.
            deposit_order: None,
            withdraw_order: None,
            event_authority,
            program: self.config.program_id,
        }
        .to_account_metas(None);
        // Anchor 0.29 uses the crate's compile-time program ID for a `None` optional account: the
        // configured deployment ID makes custom and staging clients parse all four optionals as
        // absent (safe as an unconditional write only because all four are literal `None` above).
        accounts[KRFQ_AUTHORITY_ACCOUNT_INDEX] =
            AccountMeta::new_readonly(self.config.program_id, false);
        accounts[KRFQ_FILL_MARKER_ACCOUNT_INDEX] =
            AccountMeta::new_readonly(self.config.program_id, false);
        accounts[DEPOSIT_ORDER_ACCOUNT_INDEX] =
            AccountMeta::new_readonly(self.config.program_id, false);
        accounts[WITHDRAW_ORDER_ACCOUNT_INDEX] =
            AccountMeta::new_readonly(self.config.program_id, false);
        accounts.extend(aum_remaining_accounts);

        let data = metavault::instruction::RebalanceSwap {
            amount_in,
            requested_out_amount,
        }
        .data();
        let ix = self.make_ix(accounts, data);
        let tx = self.client.tx_builder().add_ixs(refresh_ixs).add_ix(ix);
        self.build_and_send(tx, &[]).await
    }

    /// The dutch-auction ceiling on `amount_in` at the current cluster clock, computed by the
    /// program's own read-only quoting path. Asking for exactly this reproduces a fill at the
    /// curve; a transaction landing later only meets a curve that has moved further in the
    /// solver's favour. The vault's excess of `token_out` is a second, independent ceiling, so
    /// a request clearing this one can still be refused.
    async fn quote_rebalance_swap_at_curve(
        &self,
        vault_state: &MetavaultState,
        token_in_mint: Pubkey,
        token_out_mint: Pubkey,
        amount_in: u64,
    ) -> Result<u64> {
        let mut scope_accounts = Vec::new();
        for token in vault_state.iter_enabled_tokens() {
            let key = token.scope_configuration.price_feed;
            let account = self.get_rpc().get_account(&key).await?;
            scope_accounts.push((key, account));
        }
        let scope_account_infos: Vec<_> = scope_accounts
            .iter_mut()
            .map(|(key, account)| (&*key, account).into_account_info())
            .collect();
        let clock_account = self.get_rpc().get_account(&sysvar_clock::ID).await?;
        let clock: Clock = from_account(&clock_account)
            .ok_or_else(|| anyhow!("cannot decode the clock sysvar"))?;
        let timestamp = Timestamp::capture(&clock).map_err(|e| anyhow!("{e}"))?;
        let mut remaining = RemainingAccounts::new(&scope_account_infos);
        let prices = VaultScopePrices::load_and_validate_from_remaining_accounts(
            vault_state,
            &mut remaining,
            timestamp,
        )
        .map_err(|e| anyhow!("{e}"))?;
        let quote = rebalance_operations::quote_rebalance_swap(
            &vault_state.tokens(),
            &vault_state.rebalance,
            &prices,
            &token_in_mint,
            &token_out_mint,
            TokenAmount::from(amount_in),
            timestamp,
        )
        .map_err(|e| anyhow!("{e}"))?;
        Ok(quote.max_out_from_curve.into())
    }
}

pub fn get_enabled_vault_tokens(vault_state: &MetavaultState) -> Vec<(usize, &VaultToken)> {
    vault_state
        .vault_tokens
        .iter()
        .enumerate()
        .filter(|(_, t)| t.mint != Pubkey::default())
        .collect()
}

pub fn get_scope_remaining_accounts(vault_state: &MetavaultState) -> Vec<AccountMeta> {
    get_enabled_vault_tokens(vault_state)
        .iter()
        .map(|(_, t)| AccountMeta::new_readonly(t.scope_configuration.price_feed, false))
        .collect()
}

pub fn get_scope_and_obligation_remaining_accounts(
    vault_state: &MetavaultState,
) -> Vec<AccountMeta> {
    get_scope_remaining_accounts(vault_state)
        .into_iter()
        .chain(
            vault_state
                .iter_enabled_obligations()
                .map(|obligation| AccountMeta::new_readonly(obligation.obligation, false)),
        )
        .collect()
}

pub fn active_obligation_reserves(obligation: &Obligation) -> ActiveObligationReserves {
    ActiveObligationReserves {
        deposit_reserves: obligation
            .active_deposits()
            .map(|deposit| deposit.deposit_reserve)
            .collect(),
        borrow_reserves: obligation
            .active_borrows()
            .map(|borrow| borrow.borrow_reserve)
            .collect(),
    }
}

pub fn next_obligation_id(vault_state: &MetavaultState) -> Result<u8> {
    let index = vault_state
        .obligations
        .iter()
        .position(|obligation| !obligation.is_set())
        .ok_or_else(|| anyhow::anyhow!("Vault has no space for a new obligation"))?;
    u8::try_from(index).map_err(|e| anyhow::anyhow!("Obligation index does not fit in u8: {e}"))
}

pub fn farms_program_id() -> Pubkey {
    FARMS_PROGRAM_ID_STR
        .parse()
        .expect("Farms program id constant must be valid")
}

pub fn build_klend_refresh_reserve_ix(reserve_pk: Pubkey, reserve: &Reserve) -> Instruction {
    Instruction {
        program_id: kamino_lending::ID,
        accounts: kamino_lending::accounts::RefreshReserve {
            reserve: reserve_pk,
            lending_market: reserve.lending_market,
            pyth_oracle: kamino_lending::utils::maybe_null_pk(
                reserve.config.token_info.pyth_configuration.price,
            ),
            switchboard_price_oracle: kamino_lending::utils::maybe_null_pk(
                reserve
                    .config
                    .token_info
                    .switchboard_configuration
                    .price_aggregator,
            ),
            switchboard_twap_oracle: kamino_lending::utils::maybe_null_pk(
                reserve
                    .config
                    .token_info
                    .switchboard_configuration
                    .twap_aggregator,
            ),
            scope_prices: kamino_lending::utils::maybe_null_pk(
                reserve.config.token_info.scope_configuration.price_feed,
            ),
        }
        .to_account_metas(None),
        data: kamino_lending::instruction::RefreshReserve {}.data(),
    }
}

pub fn build_klend_refresh_obligation_ix(
    obligation_pk: Pubkey,
    lending_market: Pubkey,
    active_reserves: &ActiveObligationReserves,
) -> Instruction {
    let mut accounts = kamino_lending::accounts::RefreshObligation {
        lending_market,
        obligation: obligation_pk,
    }
    .to_account_metas(None);

    accounts.extend(
        active_reserves
            .deposit_reserves
            .iter()
            .chain(active_reserves.borrow_reserves.iter())
            .map(|reserve| AccountMeta::new(*reserve, false)),
    );

    Instruction {
        program_id: kamino_lending::ID,
        accounts,
        data: kamino_lending::instruction::RefreshObligation {}.data(),
    }
}

fn validate_reserve_lending_market(
    reserve_pk: &Pubkey,
    reserve: &Reserve,
    lending_market: &Pubkey,
) -> Result<()> {
    if reserve.lending_market != *lending_market {
        bail!(
            "Reserve {reserve_pk} belongs to lending market {}, but obligation belongs to {lending_market}",
            reserve.lending_market
        );
    }
    Ok(())
}

fn require_registered_obligation(vault_state: &MetavaultState, obligation: &Pubkey) -> Result<()> {
    if vault_state
        .iter_enabled_obligations()
        .any(|registered| registered.obligation == *obligation)
    {
        Ok(())
    } else {
        bail!("Obligation {obligation} is not registered in the vault")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn pubkey(byte: u8) -> Pubkey {
        Pubkey::new_from_array([byte; 32])
    }

    #[test]
    fn active_obligation_reserves_preserve_deposit_then_borrow_order() {
        let deposit_a = pubkey(1);
        let deposit_b = pubkey(2);
        let borrow_a = pubkey(3);
        let borrow_b = pubkey(4);
        let mut obligation = Obligation::default();
        obligation.deposits[1].deposit_reserve = deposit_a;
        obligation.deposits[4].deposit_reserve = deposit_b;
        obligation.borrows[0].borrow_reserve = borrow_a;
        obligation.borrows[3].borrow_reserve = borrow_b;

        let active = active_obligation_reserves(&obligation);

        assert_eq!(active.deposit_reserves, vec![deposit_a, deposit_b]);
        assert_eq!(active.borrow_reserves, vec![borrow_a, borrow_b]);
    }

    #[test]
    fn refresh_obligation_accounts_use_deposits_before_borrows() {
        let obligation = pubkey(9);
        let lending_market = pubkey(10);
        let active = ActiveObligationReserves {
            deposit_reserves: vec![pubkey(1), pubkey(2)],
            borrow_reserves: vec![pubkey(3)],
        };

        let ix = build_klend_refresh_obligation_ix(obligation, lending_market, &active);
        let account_keys: Vec<Pubkey> = ix.accounts.iter().map(|meta| meta.pubkey).collect();

        assert_eq!(
            account_keys,
            vec![lending_market, obligation, pubkey(1), pubkey(2), pubkey(3)]
        );
    }
}

use anchor_client::{
    anchor_lang::solana_program::address_lookup_table::state::AddressLookupTable,
    solana_client::nonblocking::rpc_client::RpcClient,
    solana_sdk::{address_lookup_table::AddressLookupTableAccount, pubkey::Pubkey},
};
use anyhow::Result;

pub async fn get_lookup_tables_from_pks(
    rpc_client: &RpcClient,
    lut_pks: &[Pubkey],
) -> Result<Vec<AddressLookupTableAccount>> {
    let accounts = rpc_client.get_multiple_accounts(lut_pks).await?;

    let luts = accounts
        .into_iter()
        .zip(lut_pks.iter())
        .map(|(account_opt, pk)| {
            let account =
                account_opt.ok_or_else(|| anyhow::anyhow!("LUT account {pk} not found"))?;
            let address_lookup_table = AddressLookupTable::deserialize(&account.data)
                .map_err(|e| anyhow::anyhow!("Failed to deserialize LUT {pk}: {e}"))?;
            Ok(AddressLookupTableAccount {
                key: *pk,
                addresses: address_lookup_table.addresses.to_vec(),
            })
        })
        .collect::<Result<Vec<_>>>()?;

    Ok(luts)
}

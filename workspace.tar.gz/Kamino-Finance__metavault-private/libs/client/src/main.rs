use std::{path::PathBuf, str::FromStr, sync::Arc};

use anchor_client::{
    solana_client::nonblocking::rpc_client::RpcClient,
    solana_sdk::{
        address_lookup_table::AddressLookupTableAccount,
        commitment_config::CommitmentConfig,
        pubkey::Pubkey,
        signature::{read_keypair_file, Keypair, Signer},
    },
    Cluster,
};
use anyhow::Result;
use borsh::BorshSerialize;
use clap::{Parser, Subcommand};
use kamino_lending::ScopeConfiguration;
use metavault::VaultConfigField;
use metavault_client::{
    command,
    luts::get_lookup_tables_from_pks,
    metavault_client::{Config, MetavaultClient},
    model::TxEncoding,
};
use orbit_link::{priority_fees::TransactionPriority, OrbitLink};
use tracing::info;
use tracing_subscriber::EnvFilter;

static PROGRAM_ID: Pubkey = metavault::ID;

#[derive(Parser, Debug)]
#[clap(author, version, about = "MetaVault CLI client", long_about = None)]
pub struct Args {
    #[clap(subcommand)]
    action: Actions,

    /// Connect to solana validator
    #[clap(short, long, env, parse(try_from_str), default_value = "localnet")]
    url: Cluster,

    /// Program Id
    #[clap(short, long, env, default_value_t = PROGRAM_ID)]
    program: Pubkey,

    /// Account keypair to pay for the transactions
    #[clap(short, long, env, parse(from_os_str), group = "payer")]
    keypair: Option<PathBuf>,

    /// Send the transaction without actually executing it
    #[clap(long, env, takes_value = false)]
    dry_run: bool,

    /// Encode the transaction in base58 instead of base64 when printing for multisig
    #[clap(long, env, takes_value = false)]
    bs58: bool,

    /// Multisig authority - if set, prints encoded tx instead of signing
    #[clap(long, env, parse(try_from_str), group = "payer")]
    multisig: Option<Pubkey>,

    /// Lookup tables to use with the transactions
    #[clap(long, env, parse(try_from_str), value_delimiter = ',')]
    luts: Option<Vec<Pubkey>>,
}

#[derive(Subcommand, Debug)]
enum Actions {
    // === Global Config ===
    /// Initialize the global config
    InitGlobalConfig,

    /// Update the global config
    #[clap(arg_required_else_help = true)]
    UpdateGlobalConfig {
        #[clap(long)]
        mode: String,
        #[clap(long)]
        value: String,
    },

    /// Accept pending admin role for global config
    UpdateGlobalConfigAdmin,

    // === Vault Lifecycle ===
    /// Initialize a new vault
    #[clap(arg_required_else_help = true)]
    InitVault {
        #[clap(long)]
        token_mint: Pubkey,
        #[clap(long, default_value_t = spl_token::ID)]
        token_program: Pubkey,
        #[clap(long)]
        scope_price_feed: Pubkey,
        #[clap(long)]
        scope_price_chain: u16,
        #[clap(long)]
        scope_twap_chain: u16,
    },

    /// Add a token to an existing vault
    #[clap(arg_required_else_help = true)]
    AddVaultToken {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        token_mint: Pubkey,
        #[clap(long, default_value_t = spl_token::ID)]
        token_program: Pubkey,
        #[clap(long)]
        scope_price_feed: Pubkey,
        #[clap(long)]
        scope_price_chain: u16,
        #[clap(long)]
        scope_twap_chain: u16,
    },

    /// Update vault configuration
    #[clap(arg_required_else_help = true)]
    UpdateVaultConfig {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        field: String,
        /// Human-readable value (u64, pubkey, comma-separated u64s, or string depending on field)
        #[clap(long)]
        value: String,
        /// Token mint (required for VaultToken* fields)
        #[clap(long)]
        token_mint: Option<Pubkey>,
        /// Obligation pubkey (required for VaultObligationMaxUnhealthyLtvFractionBps)
        #[clap(long)]
        obligation: Option<Pubkey>,
    },

    /// Accept pending admin role for a vault
    #[clap(arg_required_else_help = true)]
    UpdateAdmin {
        #[clap(long)]
        vault: Pubkey,
    },

    // === User Operations ===
    /// Buy shares in a vault by depositing a single token
    #[clap(arg_required_else_help = true)]
    Buy {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        token_mint: Pubkey,
        #[clap(long)]
        amount: u64,
        #[clap(long, default_value = "0")]
        min_shares_out: u64,
    },

    /// Sell shares to withdraw a single token
    #[clap(arg_required_else_help = true)]
    Sell {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        token_mint: Pubkey,
        #[clap(long)]
        shares_amount: u64,
        #[clap(long, default_value = "0")]
        min_tokens_out: u64,
    },

    // === Fee Management ===
    /// Withdraw pending management/performance fees as shares
    #[clap(arg_required_else_help = true)]
    WithdrawPendingFees {
        #[clap(long)]
        vault: Pubkey,
    },

    /// Give up (burn) pending fees
    #[clap(arg_required_else_help = true)]
    GiveUpPendingFees {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        amount: u64,
    },

    // === Rebalance ===
    /// Start a rebalance period
    #[clap(arg_required_else_help = true)]
    StartRebalance {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        duration: u64,
    },

    /// Stop (cancel) an active rebalance
    #[clap(arg_required_else_help = true)]
    StopRebalance {
        #[clap(long)]
        vault: Pubkey,
    },

    /// Execute a swap during rebalance
    #[clap(arg_required_else_help = true)]
    RebalanceSwap {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        token_in_mint: Pubkey,
        #[clap(long)]
        token_out_mint: Pubkey,
        #[clap(long)]
        amount_in: u64,
        /// Exact amount of `token_out` to receive. Defaults to the dutch-auction quote at the
        /// current cluster clock, i.e. a fill at the curve.
        #[clap(long)]
        requested_out_amount: Option<u64>,
    },

    // === Obligation Admin ===
    /// Initialize the next vault-owned Klend obligation
    #[clap(arg_required_else_help = true)]
    InitObligation {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        lending_market: Pubkey,
    },

    /// Deposit vault liquidity into an obligation as collateral
    #[clap(arg_required_else_help = true)]
    DepositObligationCollateral {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        obligation: Pubkey,
        #[clap(long)]
        reserve: Pubkey,
        #[clap(long)]
        amount: u64,
    },

    /// Withdraw obligation collateral back into the vault
    #[clap(arg_required_else_help = true)]
    WithdrawObligationCollateral {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        obligation: Pubkey,
        #[clap(long)]
        reserve: Pubkey,
        #[clap(long)]
        amount: u64,
    },

    /// Borrow obligation liquidity into the vault
    #[clap(arg_required_else_help = true)]
    BorrowObligationLiquidity {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        obligation: Pubkey,
        #[clap(long)]
        reserve: Pubkey,
        #[clap(long)]
        amount: u64,
    },

    /// Repay obligation liquidity from the vault
    #[clap(arg_required_else_help = true)]
    RepayObligationLiquidity {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        obligation: Pubkey,
        #[clap(long)]
        reserve: Pubkey,
        #[clap(long)]
        amount: u64,
    },

    /// Request a Klend elevation group for a vault obligation
    #[clap(arg_required_else_help = true)]
    RequestElevationGroup {
        #[clap(long)]
        vault: Pubkey,
        #[clap(long)]
        obligation: Pubkey,
        #[clap(long)]
        new_elevation_group: u8,
    },

    // === Read-Only ===
    /// Print vault state
    #[clap(arg_required_else_help = true)]
    PrintVault {
        #[clap(long)]
        vault: Pubkey,
    },

    /// Print global config
    PrintGlobalConfig,

    /// List all vaults sorted by AUM
    ListVaults,
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env())
        .init();

    let args = Args::parse();

    let payer: Option<Keypair> = args.keypair.as_ref().map(|keypair_path| {
        read_keypair_file(keypair_path).expect("Keypair file not found or invalid")
    });

    let commitment = CommitmentConfig::confirmed();

    let payer_pubkey = if let Some(payer) = payer.as_ref() {
        payer.pubkey()
    } else if let Some(payer_pk) = args.multisig {
        payer_pk
    } else {
        anyhow::bail!("Either --keypair or --multisig must be provided");
    };

    let tx_encoding = if args.bs58 {
        TxEncoding::Base58
    } else {
        TxEncoding::Base64
    };

    let client = init_client(
        &args.url,
        args.program,
        WalletConfig {
            payer: payer.as_ref().map(|k| k.insecure_clone()),
            payer_pubkey,
            multisig: args.multisig.is_some(),
        },
        commitment,
        tx_encoding,
        args.dry_run,
        args.luts.as_deref(),
    )
    .await?;

    if args.dry_run {
        info!("Dry-run mode \x1b[32mENABLED\x1b[0m");
    }

    match args.action {
        // Global Config
        Actions::InitGlobalConfig => command::init_global_config(&client).await,
        Actions::UpdateGlobalConfig { mode, value } => {
            let (mode, value) = parse_global_config_update(&mode, &value)?;
            command::update_global_config(&client, mode, value).await
        }
        Actions::UpdateGlobalConfigAdmin => command::update_global_config_admin(&client).await,

        // Vault Lifecycle
        Actions::InitVault {
            token_mint,
            token_program,
            scope_price_feed,
            scope_price_chain,
            scope_twap_chain,
        } => {
            let scope_config =
                build_scope_configuration(scope_price_feed, scope_price_chain, scope_twap_chain);
            command::init_vault(&client, token_mint, token_program, scope_config).await
        }
        Actions::AddVaultToken {
            vault,
            token_mint,
            token_program,
            scope_price_feed,
            scope_price_chain,
            scope_twap_chain,
        } => {
            let scope_config =
                build_scope_configuration(scope_price_feed, scope_price_chain, scope_twap_chain);
            command::add_vault_token(&client, vault, token_mint, token_program, scope_config).await
        }
        Actions::UpdateVaultConfig {
            vault,
            field,
            value,
            token_mint,
            obligation,
        } => {
            let field = parse_vault_config_field(&field)?;
            let data = build_config_data(&field, &value, token_mint, obligation)?;
            command::update_vault_config(&client, vault, field, data).await
        }
        Actions::UpdateAdmin { vault } => command::update_admin(&client, vault).await,

        // User Operations
        Actions::Buy {
            vault,
            token_mint,
            amount,
            min_shares_out,
        } => command::buy(&client, vault, token_mint, amount, min_shares_out).await,
        Actions::Sell {
            vault,
            token_mint,
            shares_amount,
            min_tokens_out,
        } => command::sell(&client, vault, token_mint, shares_amount, min_tokens_out).await,
        // Fee Management
        Actions::WithdrawPendingFees { vault } => {
            command::withdraw_pending_fees(&client, vault).await
        }
        Actions::GiveUpPendingFees { vault, amount } => {
            command::give_up_pending_fees(&client, vault, amount).await
        }

        // Rebalance
        Actions::StartRebalance { vault, duration } => {
            command::start_rebalance(&client, vault, duration).await
        }
        Actions::StopRebalance { vault } => command::stop_rebalance(&client, vault).await,
        Actions::RebalanceSwap {
            vault,
            token_in_mint,
            token_out_mint,
            amount_in,
            requested_out_amount,
        } => {
            command::rebalance_swap(
                &client,
                vault,
                token_in_mint,
                token_out_mint,
                amount_in,
                requested_out_amount,
            )
            .await
        }

        // Obligation Admin
        Actions::InitObligation {
            vault,
            lending_market,
        } => command::init_obligation(&client, vault, lending_market).await,
        Actions::DepositObligationCollateral {
            vault,
            obligation,
            reserve,
            amount,
        } => {
            command::deposit_obligation_collateral(&client, vault, obligation, reserve, amount)
                .await
        }
        Actions::WithdrawObligationCollateral {
            vault,
            obligation,
            reserve,
            amount,
        } => {
            command::withdraw_obligation_collateral(&client, vault, obligation, reserve, amount)
                .await
        }
        Actions::BorrowObligationLiquidity {
            vault,
            obligation,
            reserve,
            amount,
        } => {
            command::borrow_obligation_liquidity(&client, vault, obligation, reserve, amount).await
        }
        Actions::RepayObligationLiquidity {
            vault,
            obligation,
            reserve,
            amount,
        } => command::repay_obligation_liquidity(&client, vault, obligation, reserve, amount).await,
        Actions::RequestElevationGroup {
            vault,
            obligation,
            new_elevation_group,
        } => {
            command::request_elevation_group(&client, vault, obligation, new_elevation_group).await
        }

        // Read-Only
        Actions::PrintVault { vault } => command::print_vault(&client, vault).await,
        Actions::PrintGlobalConfig => command::print_global_config(&client).await,
        Actions::ListVaults => command::list_vaults(&client).await,
    }
}

struct WalletConfig {
    payer: Option<Keypair>,
    payer_pubkey: Pubkey,
    multisig: bool,
}

async fn init_client(
    url: &Cluster,
    program_id: Pubkey,
    wallet_config: WalletConfig,
    commitment: CommitmentConfig,
    tx_encoding: TxEncoding,
    dry_run: bool,
    lookup_tables_pks: Option<&[Pubkey]>,
) -> Result<MetavaultClient<Keypair>> {
    let rpc_client = RpcClient::new_with_commitment(url.url().to_string(), commitment);

    let lookup_tables: Option<Vec<AddressLookupTableAccount>> =
        if let Some(lut_pks) = lookup_tables_pks {
            Some(get_lookup_tables_from_pks(&rpc_client, lut_pks).await?)
        } else {
            None
        };

    let dry_run_client =
        orbit_link::async_client::dry_run::DryRunAsyncClient::new(rpc_client, dry_run);

    let client = OrbitLink::new(
        dry_run_client,
        wallet_config.payer.map(Arc::new),
        lookup_tables,
        commitment,
        Some(wallet_config.payer_pubkey),
        TransactionPriority::Low,
    )
    .await?;

    let config = Config {
        program_id,
        tx_encoding,
        multisig: wallet_config.multisig,
    };

    MetavaultClient::new(client, config).await
}

fn build_scope_configuration(
    price_feed: Pubkey,
    price_chain: u16,
    twap_chain: u16,
) -> ScopeConfiguration {
    let mut price_chain_arr = [u16::MAX; 4];
    price_chain_arr[0] = price_chain;
    let mut twap_chain_arr = [u16::MAX; 4];
    twap_chain_arr[0] = twap_chain;
    ScopeConfiguration {
        price_feed,
        price_chain: price_chain_arr,
        twap_chain: twap_chain_arr,
    }
}

fn build_scope_configuration_from_arrays(
    price_feed: Pubkey,
    price_chain: [u16; 4],
    twap_chain: [u16; 4],
) -> ScopeConfiguration {
    ScopeConfiguration {
        price_feed,
        price_chain,
        twap_chain,
    }
}

fn parse_global_config_update(
    mode: &str,
    value: &str,
) -> Result<(
    metavault::utils::global_config::UpdateGlobalConfigMode,
    Vec<u8>,
)> {
    use anchor_client::anchor_lang::AnchorSerialize;
    use metavault::utils::global_config::UpdateGlobalConfigMode;

    match mode {
        "PendingAdmin" => {
            let pk: Pubkey = value.parse()?;
            Ok((UpdateGlobalConfigMode::PendingAdmin, pk.try_to_vec()?))
        }
        "MinWithdrawalFeeLamports" => {
            let v: u64 = value.parse()?;
            Ok((
                UpdateGlobalConfigMode::MinWithdrawalFeeLamports,
                v.try_to_vec()?,
            ))
        }
        "MinWithdrawalFeeBPS" => {
            let v: u64 = value.parse()?;
            Ok((UpdateGlobalConfigMode::MinWithdrawalFeeBPS, v.try_to_vec()?))
        }
        "MinDepositFeeLamports" => {
            let v: u64 = value.parse()?;
            Ok((
                UpdateGlobalConfigMode::MinDepositFeeLamports,
                v.try_to_vec()?,
            ))
        }
        "MinDepositFeeBPS" => {
            let v: u64 = value.parse()?;
            Ok((UpdateGlobalConfigMode::MinDepositFeeBPS, v.try_to_vec()?))
        }
        _ => anyhow::bail!(
            "Unknown mode: {mode}. Valid: PendingAdmin, MinWithdrawalFeeLamports, \
             MinWithdrawalFeeBPS, MinDepositFeeLamports, MinDepositFeeBPS"
        ),
    }
}

fn parse_vault_config_field(field: &str) -> Result<VaultConfigField> {
    match field {
        "PerformanceFeeBps" => Ok(VaultConfigField::PerformanceFeeBps),
        "ManagementFeeBps" => Ok(VaultConfigField::ManagementFeeBps),
        "PendingVaultAdmin" => Ok(VaultConfigField::PendingVaultAdmin),
        "Name" => Ok(VaultConfigField::Name),
        "LookupTable" => Ok(VaultConfigField::LookupTable),
        "Farm" => Ok(VaultConfigField::Farm),
        "VaultTokenScope" => Ok(VaultConfigField::VaultTokenScope),
        "VaultTokenMaxTwapDivergenceBps" => Ok(VaultConfigField::VaultTokenMaxTwapDivergenceBps),
        "VaultTokenMaxAgePriceSeconds" => Ok(VaultConfigField::VaultTokenMaxAgePriceSeconds),
        "VaultTokenMaxAgeTwapSeconds" => Ok(VaultConfigField::VaultTokenMaxAgeTwapSeconds),
        "VaultTokenMinDepositAmount" => Ok(VaultConfigField::VaultTokenMinDepositAmount),
        "VaultTokenMinWithdrawAmount" => Ok(VaultConfigField::VaultTokenMinWithdrawAmount),
        "VaultTokenDepositFeeBps" => Ok(VaultConfigField::VaultTokenDepositFeeBps),
        "VaultTokenDepositFeeLamports" => Ok(VaultConfigField::VaultTokenDepositFeeLamports),
        "VaultTokenWithdrawFeeBps" => Ok(VaultConfigField::VaultTokenWithdrawFeeBps),
        "VaultTokenWithdrawFeeLamports" => Ok(VaultConfigField::VaultTokenWithdrawFeeLamports),
        "TokenWeights" => Ok(VaultConfigField::TokenWeights),
        "VaultTokenDutchAuctionBounds" => Ok(VaultConfigField::VaultTokenDutchAuctionBounds),
        "DepositCapUsd" => Ok(VaultConfigField::DepositCapUsd),
        "RollingDepositCap" => Ok(VaultConfigField::RollingDepositCap),
        "RollingWithdrawCap" => Ok(VaultConfigField::RollingWithdrawCap),
        "EmergencyCouncil" => Ok(VaultConfigField::EmergencyCouncil),
        "UnfreezeAuthority" => Ok(VaultConfigField::UnfreezeAuthority),
        "SwapAuthority" => Ok(VaultConfigField::SwapAuthority),
        "AllocationAdminAuthority" => Ok(VaultConfigField::AllocationAdminAuthority),
        "EmergencyMode" => Ok(VaultConfigField::EmergencyMode),
        "BlockDeposits" => Ok(VaultConfigField::BlockDeposits),
        "BlockWithdraws" => Ok(VaultConfigField::BlockWithdraws),
        "MaxRebalanceSwapSlippageBps" => Ok(VaultConfigField::MaxRebalanceSwapSlippageBps),
        "MaxRebalanceLossBps" => Ok(VaultConfigField::MaxRebalanceLossBps),
        "VaultObligationMaxUnhealthyLtvFractionBps" => {
            Ok(VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps)
        }
        "RebalanceCooldownSeconds" => Ok(VaultConfigField::RebalanceCooldownSeconds),
        "VaultTokenMaxPriceDivergenceBps" => Ok(VaultConfigField::VaultTokenMaxPriceDivergenceBps),
        "KrfqEnabled" => Ok(VaultConfigField::KrfqEnabled),
        "DepositOrderCreationEnabled" => Ok(VaultConfigField::DepositOrderCreationEnabled),
        "DepositOrderFillEnabled" => Ok(VaultConfigField::DepositOrderFillEnabled),
        "DepositOrderSettleEnabled" => Ok(VaultConfigField::DepositOrderSettleEnabled),
        "WithdrawOrderCreationEnabled" => Ok(VaultConfigField::WithdrawOrderCreationEnabled),
        "WithdrawOrderFillEnabled" => Ok(VaultConfigField::WithdrawOrderFillEnabled),
        "OrderMinOpenUsd" => Ok(VaultConfigField::OrderMinOpenUsd),
        _ => anyhow::bail!(
            "Unknown field: {field}. Valid fields: PerformanceFeeBps, \
             ManagementFeeBps, PendingVaultAdmin, Name, LookupTable, \
             Farm, VaultTokenScope, \
             VaultTokenMaxTwapDivergenceBps, VaultTokenMaxAgePriceSeconds, \
             VaultTokenMaxAgeTwapSeconds, VaultTokenMinDepositAmount, \
             VaultTokenMinWithdrawAmount, VaultTokenDepositFeeBps, \
             VaultTokenDepositFeeLamports, VaultTokenWithdrawFeeBps, \
             VaultTokenWithdrawFeeLamports, TokenWeights, \
             VaultTokenDutchAuctionBounds, DepositCapUsd, RollingDepositCap, \
             RollingWithdrawCap, EmergencyCouncil, UnfreezeAuthority, SwapAuthority, \
             AllocationAdminAuthority, \
             EmergencyMode, BlockDeposits, BlockWithdraws, MaxRebalanceSwapSlippageBps, \
             VaultObligationMaxUnhealthyLtvFractionBps, RebalanceCooldownSeconds, \
             VaultTokenMaxPriceDivergenceBps, KrfqEnabled, MaxRebalanceLossBps, \
             DepositOrderCreationEnabled, DepositOrderFillEnabled, DepositOrderSettleEnabled, \
             OrderMinOpenUsd, WithdrawOrderCreationEnabled, WithdrawOrderFillEnabled"
        ),
    }
}

fn require_token_mint(token_mint: Option<Pubkey>, field: &str) -> Result<Pubkey> {
    token_mint.ok_or_else(|| anyhow::anyhow!("--token-mint is required for {field}"))
}

fn require_obligation(obligation: Option<Pubkey>, field: &str) -> Result<Pubkey> {
    obligation.ok_or_else(|| anyhow::anyhow!("--obligation is required for {field}"))
}

fn parse_u64(value: &str) -> Result<u64> {
    value
        .trim()
        .parse::<u64>()
        .map_err(|e| anyhow::anyhow!("Invalid u64 '{value}': {e}"))
}

fn parse_comma_separated_u64s(value: &str) -> Result<Vec<u64>> {
    value.split(',').map(|s| parse_u64(s.trim())).collect()
}

fn parse_bool_u8(value: &str) -> Result<u8> {
    match value.trim().to_ascii_lowercase().as_str() {
        "true" | "1" => Ok(1),
        "false" | "0" => Ok(0),
        _ => anyhow::bail!("Invalid boolean '{value}': expected true, false, 1, or 0"),
    }
}

fn build_config_data(
    field: &VaultConfigField,
    value: &str,
    token_mint: Option<Pubkey>,
    obligation: Option<Pubkey>,
) -> Result<Vec<u8>> {
    match field {
        // u64 fields
        VaultConfigField::PerformanceFeeBps
        | VaultConfigField::ManagementFeeBps
        | VaultConfigField::MaxRebalanceSwapSlippageBps
        | VaultConfigField::MaxRebalanceLossBps
        | VaultConfigField::RebalanceCooldownSeconds => {
            let v = parse_u64(value)?;
            Ok(v.to_le_bytes().to_vec())
        }

        // Pubkey fields
        VaultConfigField::PendingVaultAdmin
        | VaultConfigField::LookupTable
        | VaultConfigField::Farm
        | VaultConfigField::EmergencyCouncil
        | VaultConfigField::UnfreezeAuthority
        | VaultConfigField::SwapAuthority
        | VaultConfigField::AllocationAdminAuthority => {
            let pk = Pubkey::from_str(value.trim())
                .map_err(|e| anyhow::anyhow!("Invalid pubkey '{value}': {e}"))?;
            Ok(pk.to_bytes().to_vec())
        }

        // Name: raw UTF-8 bytes
        VaultConfigField::Name => Ok(value.as_bytes().to_vec()),

        // TokenWeights: comma-separated u64s
        VaultConfigField::TokenWeights => {
            let weights = parse_comma_separated_u64s(value)?;
            let mut data = Vec::with_capacity(weights.len() * 8);
            for w in weights {
                data.extend_from_slice(&w.to_le_bytes());
            }
            Ok(data)
        }

        // VaultToken* fields with single u64 value
        VaultConfigField::VaultTokenMaxAgePriceSeconds
        | VaultConfigField::VaultTokenMaxAgeTwapSeconds
        | VaultConfigField::VaultTokenMaxTwapDivergenceBps
        | VaultConfigField::VaultTokenMinDepositAmount
        | VaultConfigField::VaultTokenMinWithdrawAmount
        | VaultConfigField::VaultTokenDepositFeeBps
        | VaultConfigField::VaultTokenDepositFeeLamports
        | VaultConfigField::VaultTokenWithdrawFeeBps
        | VaultConfigField::VaultTokenWithdrawFeeLamports
        | VaultConfigField::VaultTokenMaxDeviationBps
        | VaultConfigField::VaultTokenMaxPriceDivergenceBps => {
            let mint = require_token_mint(token_mint, &format!("{field:?}"))?;
            let v = parse_u64(value)?;
            let mut data = Vec::with_capacity(32 + 8);
            data.extend_from_slice(&mint.to_bytes());
            data.extend_from_slice(&v.to_le_bytes());
            Ok(data)
        }

        // VaultTokenDutchAuctionBounds: 4 comma-separated u64s
        VaultConfigField::VaultTokenDutchAuctionBounds => {
            let mint = require_token_mint(token_mint, "VaultTokenDutchAuctionBounds")?;
            let values = parse_comma_separated_u64s(value)?;
            if values.len() != 4 {
                anyhow::bail!(
                    "VaultTokenDutchAuctionBounds requires exactly 4 values \
                     (upper_sell,lower_sell,lower_buy,upper_buy), got {}",
                    values.len()
                );
            }
            let mut data = Vec::with_capacity(32 + 32);
            data.extend_from_slice(&mint.to_bytes());
            for v in values {
                data.extend_from_slice(&v.to_le_bytes());
            }
            Ok(data)
        }

        // VaultTokenScope accepts either:
        // - "pubkey,price_chain,twap_chain"
        // - "pubkey,price0,price1,price2,price3,twap0,twap1,twap2,twap3"
        VaultConfigField::VaultTokenScope => {
            let mint = require_token_mint(token_mint, "VaultTokenScope")?;
            let parts: Vec<&str> = value.split(',').collect();
            let scope_pubkey = Pubkey::from_str(parts[0].trim())
                .map_err(|e| anyhow::anyhow!("Invalid scope pubkey: {e}"))?;
            let scope_config = match parts.len() {
                3 => {
                    let price_chain: u16 = parts[1]
                        .trim()
                        .parse()
                        .map_err(|e| anyhow::anyhow!("Invalid price_chain: {e}"))?;
                    let twap_chain: u16 = parts[2]
                        .trim()
                        .parse()
                        .map_err(|e| anyhow::anyhow!("Invalid twap_chain: {e}"))?;
                    build_scope_configuration(scope_pubkey, price_chain, twap_chain)
                }
                9 => {
                    let parse_chain = |index: usize, name: &str| -> Result<u16> {
                        parts[index]
                            .trim()
                            .parse()
                            .map_err(|e| anyhow::anyhow!("Invalid {name}: {e}"))
                    };
                    build_scope_configuration_from_arrays(
                        scope_pubkey,
                        [
                            parse_chain(1, "price0")?,
                            parse_chain(2, "price1")?,
                            parse_chain(3, "price2")?,
                            parse_chain(4, "price3")?,
                        ],
                        [
                            parse_chain(5, "twap0")?,
                            parse_chain(6, "twap1")?,
                            parse_chain(7, "twap2")?,
                            parse_chain(8, "twap3")?,
                        ],
                    )
                }
                _ => {
                    anyhow::bail!(
                        "VaultTokenScope requires either 'scope_pubkey,price_chain,twap_chain' \
                         or 'scope_pubkey,price0,price1,price2,price3,twap0,twap1,twap2,twap3', \
                         got {} parts",
                        parts.len()
                    );
                }
            };

            let mut data = Vec::with_capacity(32 + 48);
            data.extend_from_slice(&mint.to_bytes());
            data.extend(
                scope_config
                    .try_to_vec()
                    .map_err(|e| anyhow::anyhow!("Failed to serialize ScopeConfiguration: {e}"))?,
            );
            Ok(data)
        }

        // DepositCapUsd, OrderMinOpenUsd: single u128 (raw DollarValue bits)
        VaultConfigField::DepositCapUsd | VaultConfigField::OrderMinOpenUsd => {
            let v = parse_u128(value)?;
            Ok(v.to_le_bytes().to_vec())
        }

        // Rolling caps: "max_usd_sf,interval_seconds" — u128 followed by u64, both LE.
        VaultConfigField::RollingDepositCap | VaultConfigField::RollingWithdrawCap => {
            let parts: Vec<&str> = value.split(',').collect();
            if parts.len() != 2 {
                anyhow::bail!(
                    "{field:?} requires 'max_usd_sf,interval_seconds' (u128,u64), got {} parts",
                    parts.len()
                );
            }
            let max = parse_u128(parts[0])?;
            let interval = parse_u64(parts[1])?;
            let mut data = Vec::with_capacity(16 + 8);
            data.extend_from_slice(&max.to_le_bytes());
            data.extend_from_slice(&interval.to_le_bytes());
            Ok(data)
        }

        VaultConfigField::EmergencyMode
        | VaultConfigField::BlockDeposits
        | VaultConfigField::BlockWithdraws
        | VaultConfigField::KrfqEnabled
        | VaultConfigField::DepositOrderCreationEnabled
        | VaultConfigField::DepositOrderFillEnabled
        | VaultConfigField::DepositOrderSettleEnabled
        | VaultConfigField::WithdrawOrderCreationEnabled
        | VaultConfigField::WithdrawOrderFillEnabled => Ok(vec![parse_bool_u8(value)?]),

        // VaultObligationMaxUnhealthyLtvFractionBps: obligation pubkey ++ u64 LE bps
        VaultConfigField::VaultObligationMaxUnhealthyLtvFractionBps => {
            let obligation =
                require_obligation(obligation, "VaultObligationMaxUnhealthyLtvFractionBps")?;
            let bps = parse_u64(value)?;
            let mut data = Vec::with_capacity(32 + 8);
            data.extend_from_slice(&obligation.to_bytes());
            data.extend_from_slice(&bps.to_le_bytes());
            Ok(data)
        }
    }
}

fn parse_u128(value: &str) -> Result<u128> {
    value
        .trim()
        .parse::<u128>()
        .map_err(|e| anyhow::anyhow!("Invalid u128 '{value}': {e}"))
}

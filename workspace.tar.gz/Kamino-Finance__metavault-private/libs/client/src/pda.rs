use anchor_client::solana_sdk::pubkey::Pubkey;
use metavault::utils::consts::{
    BASE_VAULT_AUTHORITY_SEED, EVENT_AUTHORITY, GLOBAL_CONFIG_STATE_SEEDS, SHARES_SEEDS,
    TOKEN_VAULT_SEED,
};
pub use metavault::utils::pda::vault_user_metadata as vault_user_metadata_pda;

pub fn global_config(program_id: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[GLOBAL_CONFIG_STATE_SEEDS], program_id).0
}

pub fn program_data(program_id: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[program_id.as_ref()],
        &anchor_client::anchor_lang::solana_program::bpf_loader_upgradeable::ID,
    )
    .0
}

pub fn base_vault_authority(program_id: &Pubkey, vault_state: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[BASE_VAULT_AUTHORITY_SEED, vault_state.as_ref()],
        program_id,
    )
}

pub fn token_vault(program_id: &Pubkey, token_mint: &Pubkey, vault_state: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(
        &[TOKEN_VAULT_SEED, token_mint.as_ref(), vault_state.as_ref()],
        program_id,
    )
    .0
}

pub fn shares_mint(program_id: &Pubkey, vault_state: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[SHARES_SEEDS, vault_state.as_ref()], program_id).0
}

pub fn event_authority(program_id: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[EVENT_AUTHORITY], program_id).0
}

pub fn klend_lending_market_authority(lending_market: &Pubkey) -> Pubkey {
    Pubkey::find_program_address(&[b"lma", lending_market.as_ref()], &kamino_lending::ID).0
}

pub fn klend_obligation(
    lending_market: &Pubkey,
    base_vault_authority: &Pubkey,
    obligation_id: u8,
) -> Pubkey {
    Pubkey::find_program_address(
        &[
            &[0u8],
            &[obligation_id],
            base_vault_authority.as_ref(),
            lending_market.as_ref(),
            Pubkey::default().as_ref(),
            Pubkey::default().as_ref(),
        ],
        &kamino_lending::ID,
    )
    .0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn klend_obligation_pda_matches_seed_contract() {
        let lending_market = Pubkey::new_from_array([1; 32]);
        let base_vault_authority = Pubkey::new_from_array([2; 32]);
        let obligation_id = 7;

        let expected = Pubkey::find_program_address(
            &[
                &[0u8],
                &[obligation_id],
                base_vault_authority.as_ref(),
                lending_market.as_ref(),
                Pubkey::default().as_ref(),
                Pubkey::default().as_ref(),
            ],
            &kamino_lending::ID,
        )
        .0;

        assert_eq!(
            klend_obligation(&lending_market, &base_vault_authority, obligation_id),
            expected
        );
    }

    #[test]
    fn klend_lending_market_authority_matches_seed_contract() {
        let lending_market = Pubkey::new_from_array([3; 32]);
        let expected =
            Pubkey::find_program_address(&[b"lma", lending_market.as_ref()], &kamino_lending::ID).0;

        assert_eq!(klend_lending_market_authority(&lending_market), expected);
    }
}

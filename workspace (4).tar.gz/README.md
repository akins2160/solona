# Kamino MetaVault Security Engagement

This workspace contains the pinned MetaVault source snapshot and the engagement material needed to investigate and judge findings.

## Start Here

| Need | Authoritative starting point |
| --- | --- |
| Audited code | [`Kamino-Finance__metavault-private/`](Kamino-Finance__metavault-private/) |
| Exact file scope and revision | [`context/scope.json`](context/scope.json) |
| Context map and query examples | [`context/README.md`](context/README.md) |
| Validity and judging rules | [`context/judging-guidelines.md`](context/judging-guidelines.md) |
| Ordered severity definitions | [`context/severity-set.json`](context/severity-set.json) |
| Deduplication rules | [`context/deduplication-guidelines.md`](context/deduplication-guidelines.md) |
| Prior disclosures | [`known-issues/README.md`](known-issues/README.md) |
| Build and test source instructions | [`context/BUILD-INSTRUCTIONS.md`](context/BUILD-INSTRUCTIONS.md) |
| All source-referenced engagement entries | [`context/entries.json`](context/entries.json) |

## Engagement Window

The engagement runs from **October 5, 2026 at 14:00 UTC** through **October 24, 2026 at 14:00 UTC**. Apply the public-statement timing rule in the selected judging guidelines against that end time.

## Scope and Revision

- Repository: `Kamino-Finance__metavault-private/`
- Commit: `2fbe82b37c06282d86992a4ce17bc4ffa701f845`
- Branch recorded by the scope manifest: `jakub/be-2507-harden-metavault-account-validation-before-bug-bounty`
- Direct file scope: the **80 paths** in `context/scope.json`; directory-level descriptions in other documents do not add files to that list.
- The two dependency archives are supplied for reading and building. They do not add their files to direct scope. Apply the judging guideline separately when a library defect affects an in-scope contract.

The source snapshot has no Git metadata. Revision identity is therefore established by the pinned scope manifest, not by a local `git` checkout.

## Qualification Rules

Use [`context/entries.json`](context/entries.json) for the source-referenced inventory. In particular:

- Vault tokens are limited by the supplied protocol policy; unsupported token behavior and out-of-range decimals are excluded as described in the protocol documentation.
- The vault admin and global admin are trusted under the supplied trust model. Findings premised on a malicious or careless vault admin are excluded; the allocation delegate, fillers, order owners, and swap authority remain bounded as documented.
- Off-chain bots and `libs/client/` are not direct audit scope. Their stated reliability and liveness assumptions remain relevant context.
- The complete Sherlock guidelines govern validity, severity, and duplication where project context does not validly narrow engagement-specific scope or assumptions.
- Use the ordered definitions in `context/severity-set.json` together with the additional loss thresholds, denial-of-service conditions, and edge cases in the preserved judging guidelines.

## Prior Disclosures

Check [`known-issues/README.md`](known-issues/README.md) before treating a finding as new.

- All 30 findings in the September 2026 Certora draft report are disclosed as known, including fixed, partially fixed, pre-fixed, and acknowledged items. The compact status index is [`known-issues/certora-findings.md`](known-issues/certora-findings.md).
- Protocol documentation §6.1 declares listed behaviors to be intended and not valid findings; §6.2 declares two additional known issues. The compact index is [`known-issues/protocol-disclosures.md`](known-issues/protocol-disclosures.md).
- The Certora report reviewed commit `95760c4dc16f52031d9d6971be42a1d4f2e3505b`, not the current engagement revision. Its old scope and build context do not replace `context/scope.json`, but its disclosed issues remain prior disclosures.

## Building

The original instructions are preserved unchanged in [`context/BUILD-INSTRUCTIONS.md`](context/BUILD-INSTRUCTIONS.md). The required archive extractions are already preserved under:

- `context/klend-metavault-private.zip.unpacked/`
- `context/scope-metavault-private.zip.unpacked/`

See [`context/build-notes.md`](context/build-notes.md) for the path adjustment needed to use those required extraction locations without unpacking the archives again. The supplied build procedure modifies the root `Cargo.toml` and may rewrite `Cargo.lock`; preserve the audited snapshot when retaining evidence.

The audited manifests pin `kamino_lending` at `7f795c24d75cdb359900dd94b1477d38b832c9b8` and `orbit-link` at `36b01b2ce9850d2f66ab50c5f5c7f0ee7a06c9a4`. The supplied build archives identify different commits (`995697c…` and `0478d17…`) and the patch block substitutes them. Builds using the archives therefore exercise the supplied archive revisions; do not treat those results as proof that the private dependency revisions are byte-identical.

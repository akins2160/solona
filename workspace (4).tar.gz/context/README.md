# Engagement Context Map

The audited repository is [`../Kamino-Finance__metavault-private/`](../Kamino-Finance__metavault-private/). Begin with the exact scope, then apply the rule and disclosure indexes relevant to a candidate finding.

## Structured Files

| File | Purpose |
| --- | --- |
| [`scope.json`](scope.json) | Unchanged pinned scope manifest: repository, branch, commit, and 80 direct in-scope files. |
| [`entries.json`](entries.json) | Source-referenced inventory by validity (`tf`), scope, known status, and severity. |
| [`severity-set.json`](severity-set.json) | Complete ordered severity array selected for this engagement. |
| [`judging-guidelines.md`](judging-guidelines.md) | Complete selected Sherlock judging guidelines, preserved exactly. |
| [`deduplication-guidelines.md`](deduplication-guidelines.md) | Concise source-referenced rules for comparing findings. |

No `customer-instructions.md` is present because no customer instructions were supplied for this engagement.

## Evidence Sources

- [`protocol_docs.md`](protocol_docs.md): protocol model, trust assumptions, token constraints, intended behaviors, and known issues.
- [`BUILD-INSTRUCTIONS.md`](BUILD-INSTRUCTIONS.md): supplied dependency, toolchain, build, and test procedure.
- [`build-notes.md`](build-notes.md): workspace-path adaptation for the already-unpacked archives.
- [`Certora - Kamino - Metavault - Draft Report.md`](<Certora - Kamino - Metavault - Draft Report.md>): supplied parser conversion of the 63-page prior report.
- [`Certora - Kamino - Metavault - Draft Report.pdf`](<Certora - Kamino - Metavault - Draft Report.pdf>): unchanged prior report PDF.
- [`CERTORA-TRIAGE-2026-09-21.md`](CERTORA-TRIAGE-2026-09-21.md): customer status mapping for all 30 prior findings.
- [`severities.md`](severities.md): supplied human-readable severity source.
- [`klend-metavault-private.zip`](klend-metavault-private.zip) and [`scope-metavault-private.zip`](scope-metavault-private.zip): unchanged build dependency archives; extracted members are under matching `.zip.unpacked/` directories.

## Prior-Disclosure Indexes

- [`../known-issues/certora-findings.md`](../known-issues/certora-findings.md): all 30 Certora finding titles, prior severities, and triage statuses.
- [`../known-issues/protocol-disclosures.md`](../known-issues/protocol-disclosures.md): every explicit §6 intended behavior and known issue, plus qualification guardrails from the protocol documentation.

## Querying Entries

```sh
# Direct scope metadata
python -c 'import json; d=json.load(open("context/scope.json"))["codebases"][0]; print(json.dumps({k:d[k] for k in ("directory","branch","commit_sha","in_scope_files")}, indent=2))'

# All known-status material
python -c 'import json; d=json.load(open("context/entries.json")); print(json.dumps([e for e in d if "known" in e["dimensions"]], indent=2))'

# Rules affecting validity or scope
python -c 'import json; d=json.load(open("context/entries.json")); print(json.dumps([e for e in d if {"tf","scope"} & set(e["dimensions"])], indent=2))'

# Search prior disclosures by term
rg -n -i 'oracle|fee|rebalance|obligation|permission' known-issues context/CERTORA-TRIAGE-2026-09-21.md
```

Read each matching entry's `instruction`, then follow every cited `sources` location before applying it. Generated indexes reduce search cost but do not replace the unchanged source documents.

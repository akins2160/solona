# Building Kamino MetaVault with the two dependency zips

The MetaVault workspace depends on two private Kamino repositories that you
cannot reach. Kamino has supplied the needed code as two zip files, shipped in
the `context/` folder of your download:

| File | What it contains | Used by |
|---|---|---|
| `klend-metavault-private.zip` | The `kamino_lending` crate, version 1.22.0 (`programs/klend`), including its `program_test` helpers | The MetaVault program and its tests |
| `scope-metavault-private.zip` | The `orbit-link` crate, version 0.3.0 | Only the off-chain CLI in `libs/client` |

Both are provided so you can read the code and build. They do not change the
audit scope.

## 1. Extract the zips

Your download has this layout:

```
Kamino-Finance__metavault-private/    <- the repository
context/
  klend-metavault-private.zip
  scope-metavault-private.zip
```

Extract both zips inside `context/`. Each zip holds a single top-level folder:

```bash
cd context
unzip klend-metavault-private.zip
unzip scope-metavault-private.zip
```

You should now have `context/klend-metavault-private/programs/klend/Cargo.toml`
and `context/scope-metavault-private/off_chain/orbit-link/Cargo.toml`.

## 2. Point Cargo at the extracted code

Append this block to the end of the **root** manifest,
`Kamino-Finance__metavault-private/Cargo.toml` (not
`programs/metavault/Cargo.toml`):

```toml
[patch."ssh://git@github.com/Kamino-Finance/klend-private.git"]
kamino_lending = { path = "../context/klend-metavault-private/programs/klend" }

[patch."ssh://git@github.com/Kamino-Finance/scope-private.git"]
orbit-link = { path = "../context/scope-metavault-private/off_chain/orbit-link" }
```

The paths are relative to the root `Cargo.toml`. If you extracted the zips
somewhere else, change the two paths to match; absolute paths also work.

Do not edit any other dependency line, and do not run `cargo update`.

## 3. Toolchain

These are the versions Kamino's own CI uses:

| Tool | Version |
|---|---|
| Rust | 1.74.1 (pinned in `rust-toolchain.toml`; rustup installs it automatically) |
| Solana CLI | v1.17.34 |
| Anchor CLI | v0.29.0 |

## 4. Build and test

Run everything from `Kamino-Finance__metavault-private/`.

```bash
# Compile the whole workspace, tests included
cargo check --workspace --all-targets

# Unit tests
cargo test --profile ci --lib -p metavault

# One integration test (each file under programs/metavault/tests is a target)
cargo test --profile ci -p metavault --test tests_global_config -- --test-threads 1

# On-chain program binary
cargo build-sbf --manifest-path programs/metavault/Cargo.toml

# Integration tests against the built on-chain binary
cargo test-sbf --manifest-path programs/metavault/Cargo.toml --test tests_init_vault -- --test-threads 1
cargo test-sbf --manifest-path programs/metavault/Cargo.toml --test tests_vaults_instructions -- --test-threads 1
```

The integration tests load prebuilt program binaries (`kamino_lending.so`,
`farms.so` and others) that are already in `programs/metavault/tests/fixtures`,
so you do not need to build klend's binary yourself.

## 5. What to expect

- **`Cargo.lock` changes on the first build.** Cargo removes the two private
  sources and the packages only they needed (about 28 lines). This is expected.
  Commands run with `--locked` fail until that first build has rewritten the
  lockfile.
- **Apple Silicon Macs, `cargo check` and `cargo test`.** A native build fails
  in Kamino's public `farms` dependency with `attempt to compute
  0_usize - 1_usize, which would overflow` (a struct-size assertion). Build for
  an Intel target instead by adding `--target x86_64-apple-darwin` to the
  `cargo check` and `cargo test` commands above. This needs
  `rustup target add x86_64-apple-darwin` and Rosetta. Linux x86_64 builds
  natively.
- **Apple Silicon Macs, `cargo build-sbf`.** The build can fail in the `blake3`
  package with `fatal error: 'assert.h' file not found`. Point the bundled
  compiler at the macOS SDK and run it again:

  ```bash
  export SDKROOT="$(xcrun --sdk macosx --show-sdk-path)"
  cargo build-sbf --manifest-path programs/metavault/Cargo.toml
  ```

- **Apple Silicon Macs, `cargo test-sbf`.** The test half of this command
  builds for your Mac, so it hits the same `farms` assertion. Set the default
  target before running it (keep `SDKROOT` set as above):

  ```bash
  export CARGO_BUILD_TARGET=x86_64-apple-darwin
  cargo test-sbf --manifest-path programs/metavault/Cargo.toml --test tests_init_vault -- --test-threads 1
  ```

- **Slow "Updating crates.io index".** The Cargo bundled with Solana v1.17.34
  downloads the full crates.io index by default, which can take many minutes.
  Set `export CARGO_REGISTRIES_CRATES_IO_PROTOCOL=sparse` before
  `cargo build-sbf` to avoid it.
- **Newer Solana toolchains.** With Solana/Agave 2.x, `cargo build-sbf` fails
  in the `ahash` package with `error[E0635]: unknown feature 'stdsimd'`. Use
  Solana v1.17.34.

## 6. Troubleshooting

| Error | Cause |
|---|---|
| `Permission denied (publickey)` or `failed to load source for dependency 'kamino_lending'` | The patch block is missing, or it was added to the wrong `Cargo.toml` |
| `failed to read .../programs/klend/Cargo.toml` | A path in the patch block does not match where you extracted the zip |
| `patch for 'orbit-link' ... was not used in the crate graph` | Harmless if you removed `libs/client` from the workspace members |

## 7. What has been verified

Tested on the audit commit `2fbe82b37c06282d86992a4ce17bc4ffa701f845`, on an
Apple Silicon Mac with no access to Kamino's private repositories, following
the steps above exactly:

- Dependency resolution succeeds with the patch block above.
- `cargo check --workspace --all-targets` passes with no errors or warnings
  (Rust 1.74.1, `x86_64-apple-darwin` target). This covers the program, all 34
  integration test targets, the client library and the CLI.
- `cargo test --profile ci --lib -p metavault`: 462 unit tests passed, 0 failed.
- All 34 integration test files, each run with
  `cargo test --profile ci -p metavault --test <name> -- --test-threads 1`:
  452 tests passed, 0 failed.
- `cargo build-sbf --manifest-path programs/metavault/Cargo.toml` with Solana
  v1.17.34 succeeds and produces `target/deploy/metavault.so`.
- `cargo test-sbf` with Solana v1.17.34, for the two suites Kamino's CI runs
  this way: `tests_init_vault` (3 passed) and `tests_vaults_instructions`
  (16 passed), 0 failed.

Zip sources: `klend-metavault-private` at commit `995697c` and
`scope-metavault-private` at commit `0478d17`, as supplied by Kamino.

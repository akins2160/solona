use anchor_client::solana_sdk::pubkey::Pubkey;
use serde::Deserialize;
use serde_json::json;
use solana_client::{
    nonblocking::rpc_client::RpcClient, rpc_request::RpcRequest, rpc_response::RpcPrioritizationFee,
};
use strum::{EnumCount, IntoEnumIterator};
use tracing::{debug, trace};

use crate::Result;

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    PartialOrd,
    Ord,
    strum::Display,
    strum::EnumIter,
    strum::EnumCount,
    strum::EnumString,
    strum::VariantArray,
)]
#[repr(u8)]
pub enum TransactionPriority {
    /// 0th percentile
    Min,
    /// 25th percentile
    Low,
    /// 50th percentile
    Medium,
    /// 75th percentile
    High,
    /// 95th percentile
    VeryHigh,
}

impl TransactionPriority {
    pub const fn to_default_max_fee_pct(&self) -> u32 {
        match self {
            TransactionPriority::Min => 2,
            TransactionPriority::Low => 20,
            TransactionPriority::Medium => 50,
            TransactionPriority::High => 85,
            TransactionPriority::VeryHigh => 100,
        }
    }
}

/// Convert a maximum fee value into an array of fee values based on priority levels
pub fn max_fee_to_fee_array(max_fee: u64) -> [u64; TransactionPriority::COUNT] {
    let mut fee_array = [0; TransactionPriority::COUNT];
    for (fee, priority) in fee_array.iter_mut().zip(TransactionPriority::iter()) {
        *fee = max_fee * u64::from(priority.to_default_max_fee_pct()) / 100;
    }
    fee_array
}

#[derive(Debug, Clone, Copy, Deserialize)]
pub enum FeeProvider {
    #[serde(alias = "standard", alias = "STANDARD")]
    Standard,
    #[serde(alias = "triton", alias = "TRITON")]
    Triton,
    #[serde(alias = "helius", alias = "HELIUS")]
    Helius,
}

pub fn guess_fee_provider_from_url(url: &str) -> FeeProvider {
    if url.contains("triton") || url.contains("rpcpool") {
        FeeProvider::Triton
    } else if url.contains("helius") {
        FeeProvider::Helius
    } else {
        FeeProvider::Standard
    }
}

pub async fn get_recommended_micro_lamport_fee_for_accounts_by_provider(
    rpc: &RpcClient,
    accounts: &[Pubkey],
    priority: TransactionPriority,
    provider: FeeProvider,
) -> Result<u64> {
    match provider {
        FeeProvider::Standard => {
            standard::get_recommended_micro_lamport_fee_for_accounts(rpc, accounts, priority).await
        }
        FeeProvider::Triton => {
            triton::get_recommended_micro_lamport_fee_for_accounts(rpc, accounts, priority).await
        }
        FeeProvider::Helius => {
            helius::get_recommended_micro_lamport_fee_for_accounts(rpc, accounts, priority).await
        }
    }
}

pub mod standard {
    use super::*;

    #[tracing::instrument(skip(rpc))]
    pub async fn get_recommended_micro_lamport_fee_for_accounts(
        rpc: &RpcClient,
        accounts: &[Pubkey],
        priority: TransactionPriority, // normal solana RPC doesn't offer a way to exploit this directly
    ) -> Result<u64> {
        let fees = rpc.get_recent_prioritization_fees(accounts).await?;
        trace!("Recent fees: {:#?}", fees);

        let fee = fees
            .into_iter()
            .fold(0, |acc, x| u64::max(acc, x.prioritization_fee));

        // Just trying something here...
        let fee = match priority {
            TransactionPriority::Min => fee,
            TransactionPriority::Low => (fee * 110 / 100).max(crate::DEFAULT_MIN_FEE),
            TransactionPriority::Medium => fee.max(crate::DEFAULT_MIN_FEE) * 2,
            TransactionPriority::High => fee.max(crate::BASE_FEE) * 150 / 100,
            TransactionPriority::VeryHigh => fee.max(crate::BASE_FEE) * 2,
        };

        debug!("Selected fee: {}", fee);

        Ok(fee)
    }
}

pub mod triton {
    use super::*;

    impl TransactionPriority {
        pub const fn to_percentile_bps(&self) -> u32 {
            match self {
                TransactionPriority::Min => 0,
                TransactionPriority::Low => 2500,
                TransactionPriority::Medium => 5000,
                TransactionPriority::High => 7500,
                TransactionPriority::VeryHigh => 9500,
            }
        }
    }

    #[tracing::instrument(skip(rpc))]
    pub async fn get_recommended_micro_lamport_fee_for_accounts(
        rpc: &RpcClient,
        accounts: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64> {
        // implements https://docs.triton.one/chains/solana/improved-priority-fees-api
        let addresses: Vec<_> = accounts.iter().map(|address| address.to_string()).collect();
        let priority_percentile = priority.to_percentile_bps();
        let fees: Vec<RpcPrioritizationFee> = rpc
            .send(
                RpcRequest::GetRecentPrioritizationFees,
                json!([addresses, {"percentile": priority_percentile}]),
            )
            .await?;
        trace!("Recent fees: {:#?}", fees);

        let fee = crate::utils::median(
            fees.into_iter()
                .map(|x| x.prioritization_fee)
                // ignore 0 fees
                .filter(|fee| *fee != 0),
        );

        debug!("Selected fee: {}", fee);

        Ok(fee)
    }
}

/// implements https://docs.helius.dev/solana-apis/priority-fee-api
/// request example:
/// ```json
/// {
///     "jsonrpc": "2.0",
///     "id": "1",
///     "method": "getPriorityFeeEstimate",
///     "params": [{
///         "accountKeys": ["xxxxxx", "xxxxxx"],
///         "options": {
///             "priorityLevel": "Medium"
///         }
///     }]
/// }
/// ```
/// response example:
/// ```json
/// {
///   "priorityFeeEstimate": 1500
/// }
/// ```
pub mod helius {
    use super::*;

    #[derive(Debug, Copy, Clone, serde::Deserialize)]
    struct HeliusPriorityFeeEstimateResponse {
        #[serde(rename = "priorityFeeEstimate")]
        priority_fee_estimate: f64,
    }

    #[tracing::instrument(skip(rpc))]
    pub async fn get_recommended_micro_lamport_fee_for_accounts(
        rpc: &RpcClient,
        accounts: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64> {
        let account_keys: Vec<_> = accounts.iter().map(|address| address.to_string()).collect();
        let priority_str = priority.to_string();
        let params = if account_keys.is_empty() {
            json!([
                {
                    "options": {
                        "priorityLevel": priority_str
                    }
                }
            ])
        } else {
            json!([
                {
                    "accountKeys": account_keys,
                    "options": {
                        "priorityLevel": priority_str
                    }
                }
            ])
        };
        let fee: HeliusPriorityFeeEstimateResponse = rpc
            .send(
                RpcRequest::Custom {
                    method: "getPriorityFeeEstimate",
                },
                params,
            )
            .await?;
        let fee_res = fee.priority_fee_estimate as u64;
        debug!("Selected fee: {}", fee_res);

        Ok(fee_res)
    }
}

#![doc = include_str!("../Readme.md")]

use std::{
    sync::{atomic::AtomicU64, Arc},
    time::{Duration, Instant},
};

use anchor_client::{
    anchor_lang::{
        solana_program, AccountDeserialize, AccountSerialize, AnchorDeserialize, Discriminator,
        Owner,
        __private::bytemuck::{from_bytes, AnyBitPattern},
    },
    solana_sdk::{
        address_lookup_table_account::AddressLookupTableAccount,
        commitment_config::CommitmentConfig,
        instruction::Instruction,
        message::{v0, VersionedMessage},
        pubkey::Pubkey,
        signature::Signature,
        signer::{Signer, SignerError},
        system_instruction,
        transaction::VersionedTransaction,
    },
};
use errors::ErrorKind;
use futures::future::join_all;
use priority_fees::{max_fee_to_fee_array, TransactionPriority};
use solana_account_decoder::{UiAccountEncoding, UiDataSliceConfig};
use solana_address_lookup_table_program::state::AddressLookupTable;
use solana_client::{rpc_config::RpcAccountInfoConfig, rpc_filter::RpcFilterType};
use solana_sdk::{clock::Slot, program_pack::Pack};
pub use strum;
use strum::EnumCount;
use tracing::debug;

pub mod async_client;
pub mod consts;
pub mod errors;
pub mod priority_fees;
pub mod tx_builder;
pub mod utils;

use async_client::confirmation_utils;
pub use async_client::TransactionResult;
pub use consts::*;

pub type Result<T> = std::result::Result<T, errors::ErrorKind>;

const FEE_CACHE_TTL_S: u64 = 30;

const BLOCKHASH_CACHE_TTL: Duration = Duration::from_secs(5);

/// Min to 2000 lamports per 200_000 CU (default 1 ix transaction)
/// 2000 * 1M / 200_000 = 10000
pub const DEFAULT_MIN_FEE: u64 = 10_000;
/// Base fee is 5000 lamports per tx
/// In micro lamports per CU (200_000 CU per tx)
/// 5000 * 1M / 200_000 = 25_000
pub const BASE_FEE: u64 = 25_000;

/// Default max fee set to 10M micro lamports per CU
pub const DEFAULT_MAX_FEE: u64 = 10_000_000;

// Note: Atomic is not the best choice here for concurrency as we still can have a possible data
// race between the moment we check the delta_s and the moment we update everything.
// However, it is good enough for our use case where we just want to avoid calling the RPC too
// often and the refresh if needed is called manually sequentially before sending the transactions
// in a possibly concurrent way.
// TL;DR: Atomic is just here so we can keep OrbitLink immutable not to prevent concurrent access.
struct FeeCache {
    pub priority_fee: AtomicU64,
    pub creation: Instant,
    pub delta_s: AtomicU64,
}

impl Clone for FeeCache {
    fn clone(&self) -> Self {
        FeeCache {
            priority_fee: AtomicU64::new(
                self.priority_fee.load(std::sync::atomic::Ordering::Relaxed),
            ),
            creation: self.creation,
            delta_s: AtomicU64::new(self.delta_s.load(std::sync::atomic::Ordering::Relaxed)),
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct BlockhashCache {
    blockhash: solana_program::hash::Hash,
    creation: Instant,
    ttl: Duration,
}

impl BlockhashCache {
    pub fn new(blockhash: solana_program::hash::Hash, ttl: Duration) -> Self {
        Self {
            blockhash,
            creation: Instant::now(),
            ttl,
        }
    }

    pub fn update(&mut self, blockhash: solana_program::hash::Hash) {
        self.blockhash = blockhash;
        self.creation = Instant::now();
    }

    pub fn is_cache_valid(&self) -> bool {
        self.creation.elapsed() < self.ttl
    }

    pub fn get(&self) -> solana_program::hash::Hash {
        self.blockhash
    }
}

pub struct OrbitLink<T, S>
where
    T: async_client::AsyncClient + Sync,
    S: Signer + Send + Sync,
{
    pub client: T,
    payer: Option<Arc<S>>,
    payer_pubkey: Option<Pubkey>,
    lookup_tables: Vec<AddressLookupTableAccount>,
    commitment_config: CommitmentConfig,
    fee_cache: FeeCache,
    default_priority: TransactionPriority,
    min_fee: u64,
    max_fees: [u64; TransactionPriority::COUNT],
    latest_blockhash_cache: tokio::sync::Mutex<BlockhashCache>,
}

impl<T, S> OrbitLink<T, S>
where
    T: async_client::AsyncClient,
    S: Signer + Send + Sync,
{
    #[allow(clippy::result_large_err)]
    pub async fn new(
        client: T,
        payer: Option<Arc<S>>,
        lookup_tables: impl Into<Option<Vec<AddressLookupTableAccount>>>,
        commitment_config: CommitmentConfig,
        payer_pubkey: Option<Pubkey>,
        default_priority: TransactionPriority,
    ) -> Result<Self> {
        let lookup_tables: Option<Vec<AddressLookupTableAccount>> = lookup_tables.into();

        if payer.is_none() && payer_pubkey.is_none() {
            return Err(errors::ErrorKind::SignerError(SignerError::InvalidInput(
                "No payer nor payer_pubkey provided".to_string(),
            )));
        }

        let fee_cache = FeeCache {
            priority_fee: AtomicU64::new(DEFAULT_MIN_FEE),
            creation: Instant::now(),
            delta_s: AtomicU64::new(0),
        };

        let hash = client.get_latest_blockhash().await?;
        let latest_blockhash_cache =
            tokio::sync::Mutex::new(BlockhashCache::new(hash, BLOCKHASH_CACHE_TTL));

        Ok(OrbitLink {
            client,
            payer,
            payer_pubkey,
            lookup_tables: lookup_tables.unwrap_or_default(),
            commitment_config,
            fee_cache,
            min_fee: DEFAULT_MIN_FEE,
            max_fees: max_fee_to_fee_array(DEFAULT_MAX_FEE),
            default_priority,
            latest_blockhash_cache,
        })
    }

    pub fn with_min_fee(mut self, min_fee: u64) -> Self {
        self.min_fee = min_fee;
        self
    }

    pub fn with_max_fee(mut self, max_fee: u64) -> Self {
        self.max_fees = max_fee_to_fee_array(max_fee);
        self
    }

    pub fn with_max_fees(mut self, max_fees: [u64; TransactionPriority::COUNT]) -> Self {
        self.max_fees = max_fees;
        self
    }

    pub fn with_blockhash_cache_ttl(mut self, ttl: Duration) -> Self {
        self.latest_blockhash_cache.get_mut().ttl = ttl;
        self
    }

    pub fn get_default_priority(&self) -> TransactionPriority {
        self.default_priority
    }

    pub async fn get_latest_blockhash(&self) -> Result<solana_program::hash::Hash> {
        let mut cache = self.latest_blockhash_cache.lock().await;
        if cache.is_cache_valid() {
            Ok(cache.get())
        } else {
            let blockhash = self.client.get_latest_blockhash().await?;
            cache.update(blockhash);
            Ok(blockhash)
        }
    }

    pub async fn refresh_fee_cache(&self) -> Result<()> {
        let fee = self
            .client
            .get_recommended_micro_lamport_fee(self.default_priority)
            .await
            .unwrap_or(0);

        debug!(fee);
        self.fee_cache
            .priority_fee
            .store(fee, std::sync::atomic::Ordering::Relaxed);
        self.fee_cache.delta_s.store(
            self.fee_cache.creation.elapsed().as_secs(),
            std::sync::atomic::Ordering::Relaxed,
        );
        Ok(())
    }

    pub async fn refresh_fee_cache_if_needed(&self) -> Result<()> {
        let delta_ts_now = self.fee_cache.creation.elapsed().as_secs();

        let delta_ts_pre = self
            .fee_cache
            .delta_s
            .load(std::sync::atomic::Ordering::Relaxed);

        let delta_ts = delta_ts_now - delta_ts_pre;

        if delta_ts > FEE_CACHE_TTL_S {
            self.refresh_fee_cache().await?;
        }
        Ok(())
    }

    pub fn get_recommended_micro_lamport_fee(&self) -> u64 {
        self.fee_cache
            .priority_fee
            .load(std::sync::atomic::Ordering::Relaxed)
    }

    pub async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts_pk: &[Pubkey],
        priority: Option<TransactionPriority>,
    ) -> Result<u64> {
        self.client
            .get_recommended_micro_lamport_fee_for_accounts(
                accounts_pk,
                priority.unwrap_or(self.default_priority),
            )
            .await
    }

    pub fn get_max_fee_for_priority(
        &self,
        priority: impl Into<Option<TransactionPriority>>,
    ) -> u64 {
        let priority = priority.into();
        let priority = priority.unwrap_or(self.default_priority);
        self.max_fees[(priority as u8) as usize]
    }

    pub fn payer_pubkey(&self) -> Pubkey {
        match (&self.payer, self.payer_pubkey) {
            (Some(p), _) => p.pubkey(),
            (_, Some(p)) => p,
            _ => unreachable!("A payer or payer_pubkey should be provided"),
        }
    }

    #[allow(clippy::result_large_err)]
    pub fn payer(&self) -> Result<Arc<S>> {
        self.payer
            .clone()
            .ok_or(errors::ErrorKind::SignerError(SignerError::InvalidInput(
                "No payer provided".to_string(),
            )))
    }

    pub fn add_lookup_table(&mut self, table: AddressLookupTableAccount) {
        self.lookup_tables.push(table);
    }

    pub async fn get_anchor_account<AccDeser: AccountDeserialize>(
        &self,
        pubkey: &Pubkey,
    ) -> Result<AccDeser> {
        let account = self.client.get_account(pubkey).await?;
        let mut data: &[u8] = &account.data;
        Ok(AccDeser::try_deserialize(&mut data)?)
    }

    /// Get and parse an anchor account but skip sizes checks.
    pub async fn get_anchor_account_relaxed<AccDeser: Discriminator + AnchorDeserialize>(
        &self,
        pubkey: &Pubkey,
    ) -> Result<AccDeser> {
        let account = self.client.get_account(pubkey).await?;
        let data: &[u8] = &account.data;

        if AccDeser::DISCRIMINATOR != data[..8] {
            return Err(ErrorKind::DeserializationError(format!(
                "Discriminator mismatch: expected {:?}, got {:?}",
                AccDeser::DISCRIMINATOR,
                &data[..8]
            )));
        }
        let acc: AccDeser = AnchorDeserialize::deserialize(&mut &data[8..]).map_err(|e| {
            ErrorKind::DeserializationError(format!("Error while deserializing {pubkey}: {e:#?}"))
        })?;
        Ok(acc)
    }

    pub async fn get_anchor_accounts<AccDeser: AccountDeserialize>(
        &self,
        pubkey: &[Pubkey],
    ) -> Result<Vec<Option<AccDeser>>> {
        let accounts = self.client.get_multiple_accounts(pubkey).await?;
        accounts
            .into_iter()
            .map(|acc| {
                acc.map(|acc| {
                    let mut data: &[u8] = &acc.data;
                    AccDeser::try_deserialize(&mut data).map_err(ErrorKind::from)
                })
                .transpose()
            })
            .collect()
    }

    pub async fn get_all_anchor_accounts<Acc>(&self) -> Result<Vec<(Pubkey, Acc)>>
    where
        Acc: AccountDeserialize + AccountSerialize + Default + Owner + Discriminator,
    {
        let default_acc = Acc::default();
        let size = {
            let mut data = Vec::new();
            default_acc.try_serialize(&mut data)?;
            data.len()
        };
        let accounts = self
            .client
            .get_program_accounts_with_size_and_discriminator(
                &Acc::owner(),
                size as u64,
                async_client::ClientDiscriminator::Bytes(Acc::DISCRIMINATOR),
            )
            .await?;
        let parsed_accounts = accounts
            .into_iter()
            .map(|(pubkey, account)| {
                let mut data: &[u8] = &account.data;
                let acc = Acc::try_deserialize(&mut data)?;
                Ok((pubkey, acc))
            })
            .collect::<Result<Vec<_>>>()?;
        Ok(parsed_accounts)
    }

    pub async fn get_all_zero_copy_accounts<Acc>(&self) -> Result<Vec<(Pubkey, Acc)>>
    where
        Acc: AnyBitPattern + Owner + Discriminator,
    {
        let size = u64::try_from(std::mem::size_of::<Acc>() + 8).unwrap();
        let accounts = self
            .client
            .get_program_accounts_with_size_and_discriminator(
                &Acc::owner(),
                size,
                async_client::ClientDiscriminator::Byte(Acc::DISCRIMINATOR[0]),
            )
            .await?;
        let parsed_accounts = accounts
            .into_iter()
            .map(|(pubkey, account)| {
                let data: &[u8] = &account.data;
                let acc: &Acc = from_bytes(&data[8..]);
                Ok((pubkey, *acc))
            })
            .collect::<Result<Vec<_>>>()?;
        Ok(parsed_accounts)
    }

    pub async fn get_all_luts_pks_by_owner(&self, owner: &Pubkey) -> Result<Vec<Pubkey>> {
        let pks = self
            .client
            .get_program_accounts_with_config(
                &ADDRESS_LOOKUP_TABLE_PROGRAM_ID,
                solana_client::rpc_config::RpcProgramAccountsConfig {
                    filters: Some(vec![RpcFilterType::Memcmp(
                        solana_client::rpc_filter::Memcmp::new_raw_bytes(
                            22,
                            owner.to_bytes().to_vec(),
                        ),
                    )]),
                    account_config: RpcAccountInfoConfig {
                        data_slice: Some(UiDataSliceConfig {
                            offset: 0,
                            length: 0,
                        }),
                        encoding: Some(UiAccountEncoding::Base64),
                        ..Default::default()
                    },
                    ..Default::default()
                },
            )
            .await?
            .into_iter()
            .map(|(pk, _)| pk)
            .collect();
        Ok(pks)
    }

    pub async fn get_address_lookup_tables(
        &self,
        lookup_tables_pks: &[Pubkey],
    ) -> Result<Vec<Option<AddressLookupTableAccount>>> {
        let raw_accounts = self.client.get_multiple_accounts(lookup_tables_pks).await?;
        lookup_tables_pks
            .iter()
            .zip(raw_accounts)
            .map(
                |(pk, raw_account)| -> Result<Option<AddressLookupTableAccount>> {
                    Ok(if let Some(raw_account) = raw_account {
                        let address_lookup_table =
                            AddressLookupTable::deserialize(&raw_account.data).map_err(|e| {
                                ErrorKind::DeserializationError(format!(
                                    "AddressLookupTable {pk} deserialization failed: {e:#?}"
                                ))
                            })?;
                        Some(AddressLookupTableAccount {
                            key: *pk,
                            addresses: address_lookup_table.addresses.to_vec(),
                        })
                    } else {
                        None
                    })
                },
            )
            .collect()
    }

    pub async fn get_token_account_balance(&self, pk: &Pubkey) -> Result<u64> {
        let acc = self.client.get_account(pk).await?;
        let balance =
        // Note: works for both vanilla and 2022 tokens as the first 165 bytes have the same layout
            match spl_token::state::Account::unpack(&acc.data[..spl_token::state::Account::LEN]) {
                Ok(acc) => acc.amount,
                Err(e) => {
                    debug!("Error while deserializing token account: {:#?}", e);
                    0
                }
            };
        Ok(balance)
    }

    pub async fn get_token_accounts_balances(&self, pks: &[Pubkey]) -> Result<Vec<u64>> {
        let accounts = self.client.get_multiple_accounts(pks).await?;
        let balances = accounts
            .into_iter()
            .map(|account| {
                account
                    .map(|acc| {
                        match spl_token::state::Account::unpack(
                            &acc.data[..spl_token::state::Account::LEN],
                        ) {
                            Ok(acc) => acc.amount,
                            Err(e) => {
                                debug!("Error while deserializing token account: {:#?}", e);
                                0
                            }
                        }
                    })
                    .unwrap_or_default()
            })
            .collect();
        Ok(balances)
    }

    pub fn tx_builder(&self) -> tx_builder::TxBuilder<T, S> {
        tx_builder::TxBuilder::new(self)
    }

    pub async fn create_account_ix(
        &self,
        account_to_create: &Pubkey,
        space: usize,
        new_owner: &Pubkey,
    ) -> Result<Instruction> {
        Ok(system_instruction::create_account(
            &self.payer_pubkey(),
            account_to_create,
            self.client
                .get_minimum_balance_for_rent_exemption(space)
                .await?,
            space
                .try_into()
                .expect("usize representing size to allocate to u64 conversion failed"),
            new_owner,
        ))
    }

    pub async fn create_tx(
        &self,
        instructions: &[Instruction],
        extra_signers: &[&(dyn Signer + Send + Sync)],
    ) -> Result<VersionedTransaction> {
        let blockhash = self.get_latest_blockhash().await?;
        self.build_and_sign_transaction(instructions, extra_signers, blockhash)
    }

    /// Non-async part of `create_tx` so we can drop
    /// the `Send + Sync` bounds on the signers without compilation errors.
    /// This is required as `VersionedTransaction::try_new` requires `&dyn Signer` alone.
    fn build_and_sign_transaction(
        &self,
        instructions: &[Instruction],
        extra_signers: &[&(dyn Signer + Send + Sync)],
        blockhash: solana_program::hash::Hash,
    ) -> Result<VersionedTransaction> {
        let mut signers: Vec<&dyn Signer> = Vec::with_capacity(extra_signers.len() + 1);

        let payer = self.payer.as_ref().ok_or(errors::ErrorKind::SignerError(
            SignerError::InvalidInput("No payer provided".to_string()),
        ))?;

        signers.push(payer.as_ref());
        signers.extend(extra_signers.iter().map(|s| *s as &dyn Signer));

        Ok(VersionedTransaction::try_new(
            VersionedMessage::V0(v0::Message::try_compile(
                &payer.pubkey(),
                instructions,
                &self.lookup_tables,
                blockhash,
            )?),
            &signers,
        )?)
    }

    pub fn create_tx_for_simulation(
        &self,
        instructions: &[Instruction],
        extra_signers: &[&(dyn Signer + Send + Sync)],
    ) -> Result<VersionedTransaction> {
        let blockhash = solana_program::hash::Hash::default();
        self.build_and_sign_transaction(instructions, extra_signers, blockhash)
    }

    pub async fn create_tx_with_extra_lookup_tables(
        &self,
        instructions: &[Instruction],
        extra_signers: &[&(dyn Signer + Send + Sync)],
        lookup_tables_extra: &[AddressLookupTableAccount],
    ) -> Result<VersionedTransaction> {
        let blockhash = self.get_latest_blockhash().await?;
        self.build_and_sign_transaction_with_extra_lookup_tables(
            instructions,
            extra_signers,
            lookup_tables_extra,
            blockhash,
        )
    }

    /// Non-async part of `create_tx_with_extra_lookup_tables` so we can drop
    /// the `Send + Sync` bounds on the signers without compilation errors.
    /// This is required as `VersionedTransaction::try_new` requires `&dyn Signer` alone.
    fn build_and_sign_transaction_with_extra_lookup_tables(
        &self,
        instructions: &[Instruction],
        extra_signers: &[&(dyn Signer + Send + Sync)],
        lookup_tables_extra: &[AddressLookupTableAccount],
        blockhash: solana_program::hash::Hash,
    ) -> Result<VersionedTransaction> {
        let mut signers: Vec<&(dyn Signer)> = Vec::with_capacity(extra_signers.len() + 1);

        let payer = self.payer.as_ref().ok_or(errors::ErrorKind::SignerError(
            SignerError::InvalidInput("No payer provided".to_string()),
        ))?;

        signers.push(payer.as_ref());

        signers.extend(extra_signers.iter().map(|s| *s as &dyn Signer));

        let mut lookup_tables = self.lookup_tables.clone();
        lookup_tables.extend_from_slice(lookup_tables_extra);

        Ok(VersionedTransaction::try_new(
            VersionedMessage::V0(v0::Message::try_compile(
                &payer.pubkey(),
                instructions,
                &lookup_tables,
                blockhash,
            )?),
            &signers,
        )?)
    }

    pub fn create_tx_for_simulation_with_extra_lookup_tables(
        &self,
        instructions: &[Instruction],
        extra_signers: &[&(dyn Signer + Send + Sync)],
        lookup_tables_extra: &[AddressLookupTableAccount],
    ) -> Result<VersionedTransaction> {
        let blockhash = solana_program::hash::Hash::default();
        self.build_and_sign_transaction_with_extra_lookup_tables(
            instructions,
            extra_signers,
            lookup_tables_extra,
            blockhash,
        )
    }

    pub async fn send_transaction(
        &self,
        tx: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        self.client.send_transaction(tx, timeout).await
    }

    pub async fn send_transaction_no_preflight(
        &self,
        tx: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        self.client.send_transaction_no_preflight(tx, timeout).await
    }

    /// DEPRECATED: Use `send_retry_and_confirm_transactions` instead.
    /// This method uses the RPC retry queue which is not reliable.
    ///
    /// Send a group of transactions and wait for them to be confirmed.
    /// Transactions are not guaranteed to be processed in the same order as they are sent.
    ///
    /// Note: In case of early error while sending, it is possible to loose track of which transaction
    /// failed and which succeeded.
    ///
    /// Returns a vector of (signature, result) where result is None if the transaction is was not confirmed.
    #[deprecated(
        since = "0.2.0",
        note = "Use `send_retry_and_confirm_transactions` instead."
    )]
    pub async fn send_and_confirm_transactions(
        &self,
        transactions: &[VersionedTransaction],
    ) -> Result<Vec<ConfirmableTransaction>> {
        #[allow(deprecated)]
        let signatures = join_all(
            transactions
                .iter()
                .map(|tx| self.send_transaction(tx, None)),
        )
        .await
        .into_iter()
        .map(|result| result.map(|confirmable_transaction| confirmable_transaction.signature))
        .collect::<Result<Vec<Signature>>>()?;
        let mut tx_to_confirm: Vec<ConfirmableTransaction> = signatures
            .into_iter()
            .map(ConfirmableTransaction::unconfirmed)
            .collect();

        confirmation_utils::confirm_transactions(
            &self.client,
            &mut tx_to_confirm,
            self.commitment_config,
            commitment_to_retry_count(self.commitment_config),
        )
        .await?;

        Ok(tx_to_confirm)
    }

    /// Send a group of transactions and wait for them to be confirmed.
    /// Transactions are retried with a local retry loop until they are confirmed to the specified commitment level.
    /// Transactions are not guaranteed to be processed in the same order as they are sent.
    ///
    /// Note: In case of early error while sending, it is possible to loose track of which transaction
    /// failed and which succeeded.
    /// Note 2: for the implementation of this, see send_transactions_with_retry_and_confirm in RetryingAsyncClient
    ///
    /// ## Arguments
    ///
    /// * `transactions` - The transactions to send and confirm.
    /// * `timeout` - The maximum time to wait for a transaction to be confirmed.
    ///   If not provided, the default timeout [`MAX_TIMEOUT_TX_SEND_MS`] is used.
    /// * `skip_all_preflights` - Skip all preflights/simulations for all transactions.
    ///
    /// ## Returns
    ///
    /// Returns a vector of (signature, result) where result is `None` if the transaction was not confirmed.
    pub async fn send_retry_and_confirm_transactions(
        &self,
        transactions: &[VersionedTransaction],
        timeout: Option<Duration>,
        skip_all_preflights: bool,
    ) -> Result<Vec<ConfirmableTransaction>> {
        if skip_all_preflights {
            self.client
                .send_transactions_no_preflight(transactions, timeout)
                .await
        } else {
            self.client.send_transactions(transactions, timeout).await
        }
    }

    #[deprecated(
        since = "0.2.0",
        note = "Use `send_retry_and_confirm_transaction` instead."
    )]
    pub async fn send_and_confirm_transaction(
        &self,
        transaction: VersionedTransaction,
    ) -> Result<ConfirmableTransaction> {
        #[allow(deprecated)]
        let res = self.send_and_confirm_transactions(&[transaction]).await?;
        Ok(res
            .into_iter()
            .next()
            .expect("Sent and confirm one transaction, expect one result"))
    }

    pub async fn send_retry_and_confirm_transaction(
        &self,
        transaction: VersionedTransaction,
        timeout: Option<Duration>,
        skip_preflight: bool,
    ) -> Result<ConfirmableTransaction> {
        if skip_preflight {
            self.client
                .send_transaction_no_preflight(&transaction, timeout)
                .await
        } else {
            self.client.send_transaction(&transaction, timeout).await
        }
    }
}

/// A result of a specific transaction, confirmed at a known slot (according to the client's
/// preconfigured commitment level).
pub struct ConfirmableTransaction {
    pub signature: Signature,
    pub confirmation: Option<(Slot, TransactionResult)>,
}

impl ConfirmableTransaction {
    /// Constructs an instance which still awaits confirmation.
    pub fn unconfirmed(signature: Signature) -> Self {
        Self {
            signature,
            confirmation: None,
        }
    }

    /// The slot at which the transaction achieved the required commitment level, or [None] if not
    /// yet confirmed.
    pub fn confirmed_slot(&self) -> Option<Slot> {
        self.confirmation.as_ref().map(|(slot, _)| *slot)
    }

    /// Expresses this struct in a "legacy" tuple format, for easier client migration.
    ///
    /// Note: this means discarding the [Self::confirmed_slot()] information.
    pub fn into_signature_and_result(self) -> (Signature, Option<TransactionResult>) {
        let Self {
            signature,
            confirmation,
        } = self;
        (signature, confirmation.map(|(_slot, result)| result))
    }
}

use std::time::Duration;

use anchor_client::{
    solana_client::{
        nonblocking::rpc_client::RpcClient,
        rpc_client::SerializableTransaction,
        rpc_config::{RpcAccountInfoConfig, RpcProgramAccountsConfig},
        rpc_response::RpcSimulateTransactionResult,
    },
    solana_sdk::{
        account::Account, commitment_config::CommitmentConfig, signature::Signature,
        transaction::VersionedTransaction,
    },
};
use async_trait::async_trait;
use base64::engine::{general_purpose::URL_SAFE as URL_SAFE_BASE_64, Engine};
use solana_sdk::{clock::Slot, hash::Hash, pubkey::Pubkey};
use solana_transaction_status::TransactionStatus;
use tracing::info;

use crate::{
    async_client::AsyncClient, errors::ErrorKind, priority_fees::TransactionPriority,
    ConfirmableTransaction, Result,
};

/// A dry-run decorator for an [AsyncClient].
pub struct DryRunAsyncClient<AC> {
    underlying: AC,
    dry_run: bool,
}

impl<AC> DryRunAsyncClient<AC> {
    /// Wraps the given underlying client in an instance that will only log transaction execution
    /// attempts.
    pub fn new(underlying: AC, dry_run: bool) -> Self {
        Self {
            underlying,
            dry_run,
        }
    }
}

#[async_trait]
impl<AC: AsyncClient> AsyncClient for DryRunAsyncClient<AC> {
    fn get_rpc(&self) -> &RpcClient {
        self.underlying.get_rpc()
    }

    async fn simulate_transaction(
        &self,
        transaction: &VersionedTransaction,
    ) -> Result<RpcSimulateTransactionResult> {
        self.underlying.simulate_transaction(transaction).await
    }

    async fn send_transaction(
        &self,
        transaction: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        if self.dry_run {
            log_dry_run(transaction)
        } else {
            self.underlying.send_transaction(transaction, timeout).await
        }
    }

    async fn send_transaction_no_preflight(
        &self,
        transaction: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        if self.dry_run {
            log_dry_run(transaction)
        } else {
            self.underlying
                .send_transaction_no_preflight(transaction, timeout)
                .await
        }
    }

    async fn get_signature_statuses(
        &self,
        signatures: &[Signature],
    ) -> Result<Vec<Option<TransactionStatus>>> {
        self.underlying.get_signature_statuses(signatures).await
    }

    async fn get_latest_blockhash(&self) -> Result<Hash> {
        self.underlying.get_latest_blockhash().await
    }

    async fn is_blockhash_valid(&self, blockhash: &Hash) -> Result<bool> {
        self.underlying.is_blockhash_valid(blockhash).await
    }

    async fn get_minimum_balance_for_rent_exemption(&self, data_len: usize) -> Result<u64> {
        self.underlying
            .get_minimum_balance_for_rent_exemption(data_len)
            .await
    }

    async fn get_balance(&self, pubkey: &Pubkey) -> Result<u64> {
        self.underlying.get_balance(pubkey).await
    }

    async fn get_account(&self, pubkey: &Pubkey) -> Result<Account> {
        self.underlying.get_account(pubkey).await
    }

    async fn get_multiple_accounts(&self, pubkeys: &[Pubkey]) -> Result<Vec<Option<Account>>> {
        self.underlying.get_multiple_accounts(pubkeys).await
    }

    async fn get_multiple_accounts_with_config(
        &self,
        pubkeys: &[Pubkey],
        config: RpcAccountInfoConfig,
    ) -> Result<Vec<Option<Account>>> {
        self.underlying
            .get_multiple_accounts_with_config(pubkeys, config)
            .await
    }

    async fn get_program_accounts(&self, program_id: &Pubkey) -> Result<Vec<(Pubkey, Account)>> {
        self.underlying.get_program_accounts(program_id).await
    }

    async fn get_program_accounts_with_config(
        &self,
        program_id: &Pubkey,
        config: RpcProgramAccountsConfig,
    ) -> Result<Vec<(Pubkey, Account)>> {
        self.underlying
            .get_program_accounts_with_config(program_id, config)
            .await
    }

    async fn get_slot_with_commitment(&self, commitment: CommitmentConfig) -> Result<Slot> {
        self.underlying.get_slot_with_commitment(commitment).await
    }

    async fn get_recommended_micro_lamport_fee(
        &self,
        priority: TransactionPriority,
    ) -> Result<u64> {
        self.underlying
            .get_recommended_micro_lamport_fee(priority)
            .await
    }

    async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts_pk: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64> {
        self.underlying
            .get_recommended_micro_lamport_fee_for_accounts(accounts_pk, priority)
            .await
    }
}

fn log_dry_run(transaction: &VersionedTransaction) -> Result<ConfirmableTransaction> {
    info!(
        "Dry-running tx (NOT executed): https://explorer.solana.com/tx/inspector?message={}",
        base64_encode_tx(transaction)?
    );
    Ok(ConfirmableTransaction::unconfirmed(
        *transaction.get_signature(),
    ))
}

fn base64_encode_tx(tx: &VersionedTransaction) -> Result<String> {
    let serialized_tx =
        bincode::serialize(tx).map_err(|err| ErrorKind::SerializationError(err.to_string()))?;
    Ok(URL_SAFE_BASE_64.encode(serialized_tx))
}

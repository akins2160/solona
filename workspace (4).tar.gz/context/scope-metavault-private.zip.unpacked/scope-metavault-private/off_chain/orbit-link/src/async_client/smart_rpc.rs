use std::{
    sync::atomic::{AtomicUsize, Ordering},
    time::Duration,
};

use anchor_client::solana_sdk::commitment_config::CommitmentLevel;
use async_trait::async_trait;
use futures::future::join_all;
use serde::Deserialize;
use solana_client::{
    nonblocking::rpc_client::RpcClient, rpc_client::SerializableTransaction,
    rpc_config::RpcSendTransactionConfig,
};
use solana_rpc_client_api::client_error::{
    Error as ClientError, ErrorKind as ClientErrorKind, Result as ClientResult,
};
use tokio::sync::RwLock;
use tracing::{debug, error, trace, warn};

use super::{retrying_client::RetryingAsyncClient, *};
use crate::{
    priority_fees::{get_recommended_micro_lamport_fee_for_accounts_by_provider, FeeProvider},
    Result,
};

/// Configuration structure to provide the RPCs urls to the `SmartRpcClient`.
///
/// ## Example
///
/// ```json
/// {
///   "read_urls": [
///     "https://api.mainnet-beta.solana.com",
///     "https://mainnet.helius-rpc.com/"
///   ],
///   "send_urls": [
///     "https://api.mainnet-beta.solana.com",
///     "https://mainnet.helius-rpc.com/"
///   ],
///   "priority_fees_urls": [
///     {
///       "type": "Standard",
///        "url": "https://api.mainnet-beta.solana.com"
///     },
///     {
///       "type": "Helius",
///       "url": "https://mainnet.helius-rpc.com/"
///     },
///     {
///        "type": "Triton",
///        "url": "https://mainnet.triton-rpc.com/"
///     }
///   ]
/// }
/// ```
#[derive(Debug, Clone, Deserialize)]
pub struct RpcUrlCfg {
    pub read_urls: Vec<String>,
    pub send_urls: Vec<String>,
    pub priority_fees_urls: Vec<PriorityFeeRpcCfg>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct PriorityFeeRpcCfg {
    pub r#type: FeeProvider,
    pub url: String,
}

pub struct PriorityFeeRpc {
    pub provider_type: FeeProvider,
    pub rpc_client: RpcClient,
}

/// Smart RPC client aims to forward requests to multiple RPCs while maintaining a
/// status of which RPCs are working and which are not.
///
/// Reads and priority fee gets are handled in a sequential manner if the first RPC is reliable
/// the other ones might not be used.
/// Sends are broadcasted to all RPCs to increase the chances of transaction landing.
///
/// While errors are logged, they are not propagated unless all RPCs fail.
///
/// To function properly, the `recover` method needs to be called periodically to reset the status
/// that might have been marked as erroring.
pub struct SmartRpcClient {
    // Rpcs
    read_rpcs: Vec<RpcClient>,
    send_rpcs: Vec<RpcClient>,
    priority_fee_rpcs: Vec<PriorityFeeRpc>,

    // Status
    active_read_rpc: AtomicUsize,
    send_rpcs_active: RwLock<Vec<bool>>,
    active_priority_fee_rpc: AtomicUsize,

    // Configuration
    timeout: Duration,
}

impl SmartRpcClient {
    pub fn new(
        read_urls: impl IntoIterator<Item = String>,
        send_urls: impl IntoIterator<Item = String>,
        priority_fees_urls: impl IntoIterator<Item = (FeeProvider, String)>,
        commitment_config: CommitmentConfig,
        timeout: Duration,
    ) -> Result<RetryingAsyncClient<Self>> {
        let client = Self::new_no_retry(
            read_urls,
            send_urls,
            priority_fees_urls,
            commitment_config,
            timeout,
        )?;
        Ok(RetryingAsyncClient::new(client, commitment_config))
    }

    pub fn new_no_retry(
        read_urls: impl IntoIterator<Item = String>,
        send_urls: impl IntoIterator<Item = String>,
        priority_fees_urls: impl IntoIterator<Item = (FeeProvider, String)>,
        commitment_config: CommitmentConfig,
        timeout: Duration,
    ) -> Result<Self> {
        let read_rpcs = read_urls
            .into_iter()
            .map(|url| RpcClient::new_with_commitment(url, commitment_config))
            .collect::<Vec<_>>();
        let send_rpcs = send_urls
            .into_iter()
            .map(|url| RpcClient::new_with_commitment(url, commitment_config))
            .collect::<Vec<_>>();
        let priority_fee_rpcs = priority_fees_urls
            .into_iter()
            .map(|(provider_type, url)| PriorityFeeRpc {
                provider_type,
                rpc_client: RpcClient::new_with_commitment(url, commitment_config),
            })
            .collect::<Vec<_>>();
        if read_rpcs.is_empty() {
            error!("No RPC URLs provided for read operations");
            return Err(crate::errors::ErrorKind::AsyncRpcClientCreationFailed);
        }

        if send_rpcs.is_empty() {
            error!("No RPC URLs provided for send operations");
            return Err(crate::errors::ErrorKind::AsyncRpcClientCreationFailed);
        }

        if priority_fee_rpcs.is_empty() {
            error!("No RPC URLs provided for priority fees");
            return Err(crate::errors::ErrorKind::AsyncRpcClientCreationFailed);
        }
        let send_rpcs_active = vec![true; send_rpcs.len()];
        Ok(Self {
            read_rpcs,
            send_rpcs,
            priority_fee_rpcs,
            active_read_rpc: AtomicUsize::new(0),
            active_priority_fee_rpc: AtomicUsize::new(0),
            send_rpcs_active: RwLock::new(send_rpcs_active),
            timeout,
        })
    }

    pub fn new_from_cfg(
        cfg: RpcUrlCfg,
        commitment_config: CommitmentConfig,
        timeout: Duration,
    ) -> Result<RetryingAsyncClient<Self>> {
        let RpcUrlCfg {
            read_urls,
            send_urls,
            priority_fees_urls,
        } = cfg;
        Self::new(
            read_urls,
            send_urls,
            priority_fees_urls.into_iter().map(|p| (p.r#type, p.url)),
            commitment_config,
            timeout,
        )
    }

    pub fn new_from_cfg_no_retry(
        cfg: RpcUrlCfg,
        commitment_config: CommitmentConfig,
        timeout: Duration,
    ) -> Result<Self> {
        let RpcUrlCfg {
            read_urls,
            send_urls,
            priority_fees_urls,
        } = cfg;
        Self::new_no_retry(
            read_urls,
            send_urls,
            priority_fees_urls.into_iter().map(|p| (p.r#type, p.url)),
            commitment_config,
            timeout,
        )
    }

    pub async fn recover(&self) {
        self.active_read_rpc.store(0, Ordering::Relaxed);
        let mut send_rpcs_active = self.send_rpcs_active.write().await;
        send_rpcs_active.fill(true);
    }

    fn is_rpc_error(err: &ClientErrorKind) -> bool {
        matches!(
            err,
            ClientErrorKind::Io(_)
                | ClientErrorKind::Reqwest(_)
                | ClientErrorKind::SerdeJson(_)
                | ClientErrorKind::RpcError(_) // TODO: it seems that some errors of this kind are not RPC faults
        )
    }

    /// Perform a sequential operation on a slice of objects and active index (atomic usize).
    /// The return type of the operation must reflect an RPC request result.
    /// The operation is retried on the next object if the current one fails on an RPC error or timeout.
    /// Transaction errors and other errors related to solana itself are not retried.
    async fn seq_operation<'a, 'r, F, Fut, T, Ret>(
        active_index_src: &'a AtomicUsize,
        rpcs: &'r [T],
        timeout: Duration,
        f: F,
    ) -> Result<Ret>
    where
        F: Fn(&'r T) -> Fut,
        Fut: std::future::Future<Output = Result<Ret>> + 'r,
        'a: 'r,
    {
        let mut active_index = active_index_src.load(Ordering::Relaxed);
        let mut last_err = None;
        for _ in 0..rpcs.len() {
            let rpc = &rpcs[active_index];
            match tokio::time::timeout(timeout, f(rpc)).await {
                Ok(Ok(res)) => {
                    if last_err.is_some() {
                        // We had an error but succeeded in the end, update the active RPC index
                        active_index_src.store(active_index, Ordering::Relaxed);
                    }
                    return Ok(res);
                }
                // If the error kind is one of Io, Reqwest, SerdeJson, RpcError then retry
                Ok(Err(crate::ErrorKind::SolanaRpcError(err))) if Self::is_rpc_error(&err.kind) => {
                    warn!(
                        "Trying next RPC after error for RPC index {active_index}: {:?}",
                        err
                    );
                    last_err = Some(err);
                    active_index = (active_index + 1) % rpcs.len();
                }
                Err(_) => {
                    warn!("Trying next RPC after timeout for RPC index {active_index}");
                    active_index = (active_index + 1) % rpcs.len();
                }
                Ok(final_err) => {
                    return final_err;
                }
            }
        }
        Err(crate::ErrorKind::SolanaRpcError(last_err.unwrap_or(
            ClientError {
                request: None,
                kind: ClientErrorKind::Custom("No working RPC available".to_string()),
            },
        )))
    }

    /// Perform a read operation on the RPCs.
    #[tracing::instrument(skip_all)]
    async fn read_operation<'s, 'r, F, Fut, T>(&'s self, f: F) -> Result<T>
    where
        F: Fn(&'r RpcClient) -> Fut,
        Fut: std::future::Future<Output = Result<T>> + 'r,
        's: 'r,
    {
        Self::seq_operation(&self.active_read_rpc, &self.read_rpcs, self.timeout, f).await
    }

    /// Perform a send transaction to the RPCs.
    /// The send is broadcasted to all send RPCs.
    /// If at least one RPC succeeds, the function returns Ok
    /// If all RPCs fail, the function returns the first RPC error.
    /// The outside behavior mimics the `send_transaction_with_config` function from the `RpcClient`.
    /// Warning: Because of the broadcast, it is recommended to only use this function
    /// with no retries and a skip preflight set to true.
    async fn send_transaction_with_config(
        &self,
        transaction: &impl SerializableTransaction,
        config: RpcSendTransactionConfig,
    ) -> ClientResult<Signature> {
        let signature = transaction.get_signature();

        let (send_rpcs_active, all_rpcs_were_forced_active) = {
            let rpcs_active = self.send_rpcs_active.read().await;
            if rpcs_active.iter().all(|active| !*active) {
                warn!("All RPCs are disabled for send transaction, attempt to use all");
                (vec![true; rpcs_active.len()], true)
            } else {
                (rpcs_active.clone(), false)
            }
        };

        let futures: Vec<_> = self
            .send_rpcs
            .iter()
            .zip(send_rpcs_active.iter())
            .enumerate()
            .filter(|(_, (_, active))| **active)
            .map(|(i, (rpc, _))| async move {
                let res = rpc.send_transaction_with_config(transaction, config).await;
                (i, res)
            })
            .collect();
        if futures.is_empty() {
            return Err(ClientError {
                request: None,
                kind: ClientErrorKind::Custom(
                    "No working RPC available for send transaction".to_string(),
                ),
            });
        }
        let indexed_results = join_all(futures).await;

        // If any of the RPC fail with an RPC error, disable it
        // Note: prefer double iteration to avoid holding the write lock
        if indexed_results.iter().any(|(_, res)| {
            if let Err(err) = res {
                Self::is_rpc_error(&err.kind)
            } else {
                false
            }
        }) {
            let mut send_rpcs_active = self.send_rpcs_active.write().await;
            for (i, res) in indexed_results.iter() {
                if let Err(err) = res {
                    // Note: don't print rpc url as it might contain sensitive information
                    if Self::is_rpc_error(&err.kind) {
                        warn!("Disabling RPC {} because of error: {:?}", i, err);
                        send_rpcs_active[*i] = false;
                    } else {
                        warn!("RPC {} failed with error: {:?}", i, err);
                        send_rpcs_active[*i] = true;
                    }
                } else {
                    send_rpcs_active[*i] = true;
                }
            }
        } else if all_rpcs_were_forced_active {
            let mut send_rpcs_active = self.send_rpcs_active.write().await;
            send_rpcs_active.fill(true);
        }

        // If any of the RPCs succeed, return the signature
        if indexed_results.iter().any(|(_, res)| res.is_ok()) {
            Ok(*signature)
        } else {
            // If all RPCs fail, return the first error
            indexed_results.into_iter().next().unwrap().1
        }
    }
}

#[async_trait]
impl AsyncClient for SmartRpcClient {
    fn get_rpc(&self) -> &RpcClient {
        &self.read_rpcs[self.active_read_rpc.load(Ordering::Relaxed)]
    }

    async fn simulate_transaction(
        &self,
        transaction: &VersionedTransaction,
    ) -> Result<RpcSimulateTransactionResult> {
        self.read_operation(|rpc| AsyncClient::simulate_transaction(rpc, transaction))
            .await
    }

    async fn send_transaction(
        &self,
        transaction: &VersionedTransaction,
        _timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let sim_res = self.simulate_transaction(transaction).await?;
        if let Some(ref err) = sim_res.err {
            debug!("Transaction simulation failed: {:#?}", sim_res);
            return Err(solana_client::client_error::ClientError::from(
                solana_client::client_error::ClientErrorKind::TransactionError(err.clone()),
            )
            .into());
        }
        let sig = self
            .send_transaction_with_config(
                transaction,
                RpcSendTransactionConfig {
                    skip_preflight: true,
                    preflight_commitment: Some(CommitmentLevel::Finalized),
                    max_retries: Some(0),
                    ..RpcSendTransactionConfig::default()
                },
            )
            .await?;
        trace!("Sent transaction no retry: {:?}", sig);
        Ok(ConfirmableTransaction::unconfirmed(sig))
    }

    async fn send_transaction_no_preflight(
        &self,
        transaction: &VersionedTransaction,
        _timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let sig = self
            .send_transaction_with_config(
                transaction,
                RpcSendTransactionConfig {
                    skip_preflight: true,
                    preflight_commitment: Some(CommitmentLevel::Finalized),
                    max_retries: Some(0),
                    ..RpcSendTransactionConfig::default()
                },
            )
            .await?;
        trace!("Sent transaction no retry: {:?}", sig);
        Ok(ConfirmableTransaction::unconfirmed(sig))
    }

    async fn get_minimum_balance_for_rent_exemption(&self, data_len: usize) -> Result<u64> {
        self.read_operation(|rpc| {
            AsyncClient::get_minimum_balance_for_rent_exemption(rpc, data_len)
        })
        .await
    }

    async fn get_signature_statuses(
        &self,
        signatures: &[Signature],
    ) -> Result<Vec<Option<TransactionStatus>>> {
        self.read_operation(|rpc| AsyncClient::get_signature_statuses(rpc, signatures))
            .await
    }

    async fn get_latest_blockhash(&self) -> Result<Hash> {
        self.read_operation(AsyncClient::get_latest_blockhash).await
    }

    async fn is_blockhash_valid(&self, blockhash: &Hash) -> Result<bool> {
        self.read_operation(|rpc| AsyncClient::is_blockhash_valid(rpc, blockhash))
            .await
    }

    async fn get_balance(&self, pubkey: &Pubkey) -> Result<u64> {
        self.read_operation(|rpc| AsyncClient::get_balance(rpc, pubkey))
            .await
    }

    async fn get_account(&self, pubkey: &Pubkey) -> Result<Account> {
        self.read_operation(|rpc| AsyncClient::get_account(rpc, pubkey))
            .await
    }

    async fn get_multiple_accounts(&self, pubkeys: &[Pubkey]) -> Result<Vec<Option<Account>>> {
        self.read_operation(|rpc| AsyncClient::get_multiple_accounts(rpc, pubkeys))
            .await
    }

    async fn get_multiple_accounts_with_config(
        &self,
        pubkeys: &[Pubkey],
        config: RpcAccountInfoConfig,
    ) -> Result<Vec<Option<Account>>> {
        self.read_operation(|rpc| {
            AsyncClient::get_multiple_accounts_with_config(rpc, pubkeys, config.clone())
        })
        .await
    }

    async fn get_program_accounts(&self, program_id: &Pubkey) -> Result<Vec<(Pubkey, Account)>> {
        self.read_operation(|rpc| AsyncClient::get_program_accounts(rpc, program_id))
            .await
    }

    async fn get_program_accounts_with_config(
        &self,
        program_id: &Pubkey,
        config: RpcProgramAccountsConfig,
    ) -> Result<Vec<(Pubkey, Account)>> {
        self.read_operation(|rpc| {
            AsyncClient::get_program_accounts_with_config(rpc, program_id, config.clone())
        })
        .await
    }

    async fn get_slot_with_commitment(&self, commitment: CommitmentConfig) -> Result<Slot> {
        self.read_operation(|rpc| AsyncClient::get_slot_with_commitment(rpc, commitment))
            .await
    }

    async fn get_recent_slot_duration_ms(&self) -> Result<u64> {
        self.read_operation(AsyncClient::get_recent_slot_duration_ms)
            .await
    }

    async fn get_recommended_micro_lamport_fee(
        &self,
        priority: TransactionPriority,
    ) -> Result<u64> {
        self.get_recommended_micro_lamport_fee_for_accounts(&[], priority)
            .await
    }

    #[tracing::instrument(skip_all)]
    async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64> {
        Self::seq_operation(
            &self.active_priority_fee_rpc,
            &self.priority_fee_rpcs,
            self.timeout,
            |rpc_and_type| {
                let PriorityFeeRpc {
                    provider_type,
                    rpc_client,
                } = rpc_and_type;

                get_recommended_micro_lamport_fee_for_accounts_by_provider(
                    rpc_client,
                    accounts,
                    priority,
                    *provider_type,
                )
            },
        )
        .await
    }
}

use std::{
    iter,
    time::{Duration, Instant},
};

use anchor_client::solana_sdk::{
    commitment_config::CommitmentConfig, signature::Signature, transaction::VersionedTransaction,
};
use async_trait::async_trait;
use futures::future::join_all;
use itertools::izip;
use solana_client::rpc_client::SerializableTransaction;
use tracing::warn;

use super::{confirmation_utils::confirm_transactions, AsyncClient, TransactionResult};
use crate::{
    consts::{timeout_to_retry_count, DELAY_MS_BETWEEN_TX_SEND_RETRY, MAX_TIMEOUT_TX_SEND_MS},
    ConfirmableTransaction, Result,
};

pub struct RetryingAsyncClient<T> {
    inner_client: T,
    commitment_config: CommitmentConfig,
}

struct TransactionAndStatus<'a> {
    tx: &'a VersionedTransaction,
    sig: Signature,
    result: Option<TransactionResult>,
}

impl<T> RetryingAsyncClient<T>
where
    T: AsyncClient,
{
    pub fn new(inner_client: T, commitment_config: CommitmentConfig) -> Self {
        Self {
            inner_client,
            commitment_config,
        }
    }

    pub fn get_inner_client(&self) -> &T {
        &self.inner_client
    }

    fn get_remaining_signatures_and_tx_to_confirm<'a, 'b>(
        tx_to_confirm: &'a mut [TransactionAndStatus<'b>],
    ) -> (Vec<Signature>, Vec<&'a mut TransactionAndStatus<'b>>) {
        let remaining_to_confirm: Vec<_> = tx_to_confirm
            .iter_mut()
            .filter(|TransactionAndStatus { result, .. }| result.is_none())
            .collect();
        let remaining_signatures: Vec<_> = remaining_to_confirm
            .iter()
            .map(|TransactionAndStatus { sig, .. }| *sig)
            .collect();
        (remaining_signatures, remaining_to_confirm)
    }

    /// Send a group of transactions and wait for them to be confirmed.
    /// Transactions are retried with a local retry loop until they are confirmed to the specified commitment level.
    /// Transactions are not guaranteed to be processed in the same order as they are sent.
    ///
    /// Note: In case of early error while sending, it is possible to loose track of which transaction
    /// failed and which succeeded.
    async fn send_transactions_with_retry_and_confirm(
        &self,
        transactions: &[VersionedTransaction],
        timeout: Option<Duration>,
        skip_all_preflights: bool,
    ) -> Result<Vec<ConfirmableTransaction>> {
        let start = Instant::now();

        // Assume all transactions are sent at the same blockhash
        let blockhash = transactions
            .get(0)
            .ok_or(crate::errors::ErrorKind::NoTransactions)?
            .get_recent_blockhash();

        // Send all transactions once with no retry and simulation if needed
        let signatures = if skip_all_preflights {
            join_all(
                transactions
                    .iter()
                    .map(|tx| self.inner_client.send_transaction_no_preflight(tx, None)),
            )
            .await
            .into_iter()
            .map(|result| result.map(|confirmable_tx| confirmable_tx.signature))
            .collect::<Result<Vec<Signature>>>()?
        } else {
            join_all(
                transactions
                    .iter()
                    .map(|tx| self.inner_client.send_transaction(tx, None)),
            )
            .await
            .into_iter()
            .map(|result| result.map(|confirmable_tx| confirmable_tx.signature))
            .collect::<Result<Vec<Signature>>>()?
        };

        // Prepare the monitoring of the transactions
        let mut tx_to_confirm: Vec<TransactionAndStatus> = izip!(
            transactions.iter(),
            signatures.into_iter(),
            iter::repeat(None),
        )
        .map(|(tx, sig, result)| TransactionAndStatus { tx, sig, result })
        .collect();

        // Step 1: confirm processed and retry all that are not at least processed
        let timeout = timeout.unwrap_or(Duration::from_millis(MAX_TIMEOUT_TX_SEND_MS));
        while start.elapsed() < timeout {
            // Early stop if the blockhash is not valid anymore we can't retry to send the txs anymore
            if !self.inner_client.is_blockhash_valid(blockhash).await? {
                warn!("Blockhash is not valid anymore, stopping retry send loop");
                break;
            }
            // Get list of signatures to confirm and the corresponding results to update
            let (remaining_signatures, mut remaining_tx_to_confirm) =
                Self::get_remaining_signatures_and_tx_to_confirm(&mut tx_to_confirm);
            // Get the status of all unconfirmed transactions at processed level
            let statuses = self
                .inner_client
                .get_signature_statuses(&remaining_signatures)
                .await?;

            // Update the results with the new statuses
            for (to_set, status) in remaining_tx_to_confirm.iter_mut().zip(statuses).filter_map(
                |(TransactionAndStatus { result: to_set, .. }, status)| status.map(|s| (to_set, s)),
            ) {
                if let Some(err) = status.err {
                    *to_set = Some(Err(err));
                } else if status.satisfies_commitment(CommitmentConfig::processed()) {
                    *to_set = Some(Ok(()));
                }
            }

            // Resend all transactions that are not confirmed at processed level yet.
            let txs_to_retry = remaining_tx_to_confirm
                .iter()
                // Keep not confirmed transactions
                .filter(|TransactionAndStatus { result, .. }| result.is_none())
                .map(|TransactionAndStatus { tx, .. }| tx);

            if txs_to_retry.clone().count() == 0 {
                // All txs has been sent successfully
                break;
            }

            // Note: signatures cannot change here as we keep the same blockhash as previously.
            // so we can ignore the result safely.
            let _ = join_all(
                txs_to_retry.map(|tx| self.inner_client.send_transaction_no_preflight(tx, None)),
            )
            .await;

            // Sleep a bit to avoid spamming the RPC before next confirmation check
            tokio::time::sleep(Duration::from_millis(DELAY_MS_BETWEEN_TX_SEND_RETRY)).await;
        }

        // Step 2: confirm all transactions at the configured commitment level up to the provided timeout

        // Reset the results to None to force fetching new results with the expected confirmation level.
        let mut tx_to_confirm: Vec<ConfirmableTransaction> = tx_to_confirm
            .into_iter()
            .map(|TransactionAndStatus { sig, .. }| ConfirmableTransaction::unconfirmed(sig))
            .collect();

        let remaining_timeout_ms: u64 = timeout
            .saturating_sub(start.elapsed())
            .as_millis()
            .try_into()
            .unwrap();
        let nb_attempts = timeout_to_retry_count(remaining_timeout_ms).max(1);
        confirm_transactions(
            &self.inner_client,
            &mut tx_to_confirm,
            self.commitment_config,
            nb_attempts,
        )
        .await?;

        Ok(tx_to_confirm)
    }
}

#[async_trait]
impl<T> AsyncClient for RetryingAsyncClient<T>
where
    T: AsyncClient,
{
    fn get_rpc(&self) -> &anchor_client::solana_client::nonblocking::rpc_client::RpcClient {
        self.inner_client.get_rpc()
    }

    async fn simulate_transaction(
        &self,
        transaction: &VersionedTransaction,
    ) -> Result<anchor_client::solana_client::rpc_response::RpcSimulateTransactionResult> {
        self.inner_client.simulate_transaction(transaction).await
    }

    async fn send_transaction(
        &self,
        transaction: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let res = self
            .send_transactions(&[transaction.clone()], timeout)
            .await?;
        Ok(res
            .into_iter()
            .next()
            .expect("Sent one transaction, expect one result"))
    }

    async fn send_transaction_no_preflight(
        &self,
        transaction: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let res = self
            .send_transactions_no_preflight(&[transaction.clone()], timeout)
            .await?;
        Ok(res
            .into_iter()
            .next()
            .expect("Sent one transaction, expect one result"))
    }

    async fn send_transactions(
        &self,
        transactions: &[VersionedTransaction],
        timeout: Option<Duration>,
    ) -> Result<Vec<ConfirmableTransaction>> {
        self.send_transactions_with_retry_and_confirm(transactions, timeout, false)
            .await
    }

    async fn send_transactions_no_preflight(
        &self,
        transactions: &[VersionedTransaction],
        timeout: Option<Duration>,
    ) -> Result<Vec<ConfirmableTransaction>> {
        self.send_transactions_with_retry_and_confirm(transactions, timeout, true)
            .await
    }

    async fn get_signature_statuses(
        &self,
        signatures: &[Signature],
    ) -> Result<Vec<Option<solana_transaction_status::TransactionStatus>>> {
        self.inner_client.get_signature_statuses(signatures).await
    }

    async fn get_latest_blockhash(&self) -> Result<anchor_client::solana_sdk::hash::Hash> {
        self.inner_client.get_latest_blockhash().await
    }

    async fn is_blockhash_valid(
        &self,
        blockhash: &anchor_client::solana_sdk::hash::Hash,
    ) -> Result<bool> {
        self.inner_client.is_blockhash_valid(blockhash).await
    }

    async fn get_minimum_balance_for_rent_exemption(&self, data_len: usize) -> Result<u64> {
        self.inner_client
            .get_minimum_balance_for_rent_exemption(data_len)
            .await
    }

    async fn get_balance(&self, pubkey: &anchor_client::solana_sdk::pubkey::Pubkey) -> Result<u64> {
        self.inner_client.get_balance(pubkey).await
    }

    async fn get_account(
        &self,
        pubkey: &anchor_client::solana_sdk::pubkey::Pubkey,
    ) -> Result<anchor_client::solana_sdk::account::Account> {
        self.inner_client.get_account(pubkey).await
    }

    async fn get_multiple_accounts(
        &self,
        pubkeys: &[anchor_client::solana_sdk::pubkey::Pubkey],
    ) -> Result<Vec<Option<anchor_client::solana_sdk::account::Account>>> {
        self.inner_client.get_multiple_accounts(pubkeys).await
    }

    async fn get_multiple_accounts_with_config(
        &self,
        pubkeys: &[anchor_client::solana_sdk::pubkey::Pubkey],
        config: anchor_client::solana_client::rpc_config::RpcAccountInfoConfig,
    ) -> Result<Vec<Option<anchor_client::solana_sdk::account::Account>>> {
        self.inner_client
            .get_multiple_accounts_with_config(pubkeys, config)
            .await
    }

    async fn get_program_accounts(
        &self,
        program_id: &anchor_client::solana_sdk::pubkey::Pubkey,
    ) -> Result<
        Vec<(
            anchor_client::solana_sdk::pubkey::Pubkey,
            anchor_client::solana_sdk::account::Account,
        )>,
    > {
        self.inner_client.get_program_accounts(program_id).await
    }

    async fn get_program_accounts_with_config(
        &self,
        program_id: &anchor_client::solana_sdk::pubkey::Pubkey,
        config: anchor_client::solana_client::rpc_config::RpcProgramAccountsConfig,
    ) -> Result<
        Vec<(
            anchor_client::solana_sdk::pubkey::Pubkey,
            anchor_client::solana_sdk::account::Account,
        )>,
    > {
        self.inner_client
            .get_program_accounts_with_config(program_id, config)
            .await
    }

    async fn get_slot_with_commitment(
        &self,
        commitment: CommitmentConfig,
    ) -> Result<anchor_client::solana_sdk::clock::Slot> {
        self.inner_client.get_slot_with_commitment(commitment).await
    }

    async fn get_recommended_micro_lamport_fee(
        &self,
        priority: crate::priority_fees::TransactionPriority,
    ) -> Result<u64> {
        self.inner_client
            .get_recommended_micro_lamport_fee(priority)
            .await
    }

    async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts_pk: &[anchor_client::solana_sdk::pubkey::Pubkey],
        priority: crate::priority_fees::TransactionPriority,
    ) -> Result<u64> {
        self.inner_client
            .get_recommended_micro_lamport_fee_for_accounts(accounts_pk, priority)
            .await
    }
}

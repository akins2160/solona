use std::time::Duration;

use anchor_client::solana_sdk::{commitment_config::CommitmentConfig, signature::Signature};
use tokio::time::sleep;

use super::AsyncClient;
use crate::{consts::DEFAULT_STATUS_FETCH_DELAY_MS, ConfirmableTransaction, Result};

pub fn get_remaining_signatures_to_confirm(
    tx_to_confirm: &mut [ConfirmableTransaction],
) -> (Vec<Signature>, Vec<&mut ConfirmableTransaction>) {
    let remaining_to_confirm: Vec<_> = tx_to_confirm
        .iter_mut()
        .filter(|confirmable_tx| confirmable_tx.confirmation.is_none())
        .collect();
    let remaining_signatures: Vec<_> = remaining_to_confirm
        .iter()
        .map(|confirmable_tx| confirmable_tx.signature)
        .collect();
    (remaining_signatures, remaining_to_confirm)
}

pub async fn confirm_transactions<T: AsyncClient>(
    client: &T,
    tx_to_confirm: &mut [ConfirmableTransaction],
    confirmation_level: CommitmentConfig,
    nb_attempts: usize,
) -> Result<()> {
    for _retry in 0..nb_attempts {
        let (remaining_signatures, mut remaining_tx_to_confirm) =
            get_remaining_signatures_to_confirm(tx_to_confirm);
        if remaining_signatures.is_empty() {
            return Ok(());
        } else {
            sleep(Duration::from_millis(DEFAULT_STATUS_FETCH_DELAY_MS)).await;
        }
        let statuses = client.get_signature_statuses(&remaining_signatures).await?;
        for (confirmable_tx, status) in remaining_tx_to_confirm
            .iter_mut()
            .zip(statuses)
            .filter_map(|(confirmable_tx, status)| status.map(|s| (confirmable_tx, s)))
        {
            let transaction_result = if let Some(err) = status.err {
                Some(Err(err))
            } else if status.satisfies_commitment(confirmation_level) {
                Some(Ok(()))
            } else {
                None
            };
            confirmable_tx.confirmation = transaction_result.map(|result| (status.slot, result));
        }
    }
    Ok(())
}

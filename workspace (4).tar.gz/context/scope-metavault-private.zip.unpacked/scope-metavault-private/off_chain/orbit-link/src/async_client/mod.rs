#[cfg(feature = "rpc-client")]
pub mod composite_rpc_client;
pub mod confirmation_utils;
pub mod retrying_client;
#[cfg(feature = "rpc-client")]
pub mod rpc_client;
#[cfg(feature = "rpc-client")]
pub use rpc_client::RpcClientExt;
pub mod dry_run;
#[cfg(feature = "rpc-client")]
pub mod smart_rpc;

use std::time::Duration;

use anchor_client::{
    solana_client::{
        rpc_config::{RpcAccountInfoConfig, RpcProgramAccountsConfig},
        rpc_filter::{Memcmp, MemcmpEncodedBytes, RpcFilterType},
        rpc_response::RpcSimulateTransactionResult,
    },
    solana_sdk::{
        account::Account,
        clock::{Slot, DEFAULT_MS_PER_SLOT},
        commitment_config::CommitmentConfig,
        hash::Hash,
        pubkey::Pubkey,
        signature::Signature,
        transaction::{TransactionError, VersionedTransaction},
    },
};
use async_trait::async_trait;
use futures::future::join_all;
use solana_account_decoder::UiAccountEncoding;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_transaction_status::TransactionStatus;

use crate::{priority_fees::TransactionPriority, ConfirmableTransaction, Result};

/// Transaction result. `Ok` if the transaction was successful, `Err` from the transaction otherwise.
pub type TransactionResult = std::result::Result<(), TransactionError>;

pub enum ClientDiscriminator {
    Byte(u8),
    Bytes([u8; 8]),
}

impl ClientDiscriminator {
    pub fn to_vec(&self) -> Vec<u8> {
        match self {
            ClientDiscriminator::Byte(b) => vec![*b],
            ClientDiscriminator::Bytes(b) => b.to_vec(),
        }
    }
}

#[async_trait]
pub trait AsyncClient: Sync + Send {
    fn get_rpc(&self) -> &RpcClient;

    async fn simulate_transaction(
        &self,
        transaction: &VersionedTransaction,
    ) -> Result<RpcSimulateTransactionResult>;

    async fn send_transaction(
        &self,
        transaction: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction>;

    async fn send_transaction_no_preflight(
        &self,
        transaction: &VersionedTransaction,
        timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction>;

    async fn send_transactions(
        &self,
        transactions: &[VersionedTransaction],
        timeout: Option<Duration>,
    ) -> Result<Vec<ConfirmableTransaction>> {
        let results = join_all(
            transactions
                .iter()
                .map(|tx| self.send_transaction(tx, timeout)),
        )
        .await
        .into_iter()
        .collect::<Result<Vec<ConfirmableTransaction>>>()?;

        Ok(results)
    }

    async fn send_transactions_no_preflight(
        &self,
        transactions: &[VersionedTransaction],
        timeout: Option<Duration>,
    ) -> Result<Vec<ConfirmableTransaction>> {
        let results = join_all(
            transactions
                .iter()
                .map(|tx| self.send_transaction_no_preflight(tx, timeout)),
        )
        .await
        .into_iter()
        .collect::<Result<Vec<ConfirmableTransaction>>>()?;

        Ok(results)
    }

    async fn get_signature_statuses(
        &self,
        signatures: &[Signature],
    ) -> Result<Vec<Option<TransactionStatus>>>;

    async fn get_latest_blockhash(&self) -> Result<Hash>;

    async fn is_blockhash_valid(&self, blockhash: &Hash) -> Result<bool>;

    async fn get_minimum_balance_for_rent_exemption(&self, data_len: usize) -> Result<u64>;

    async fn get_balance(&self, pubkey: &Pubkey) -> Result<u64>;

    async fn get_account(&self, pubkey: &Pubkey) -> Result<Account>;

    async fn get_multiple_accounts(&self, pubkeys: &[Pubkey]) -> Result<Vec<Option<Account>>>;

    async fn get_multiple_accounts_with_config(
        &self,
        pubkeys: &[Pubkey],
        config: RpcAccountInfoConfig,
    ) -> Result<Vec<Option<Account>>>;

    async fn get_program_accounts(&self, program_id: &Pubkey) -> Result<Vec<(Pubkey, Account)>>;

    async fn get_program_accounts_with_config(
        &self,
        program_id: &Pubkey,
        config: RpcProgramAccountsConfig,
    ) -> Result<Vec<(Pubkey, Account)>>;

    async fn get_program_accounts_with_size_and_discriminator(
        &self,
        program_id: &Pubkey,
        size: u64,
        discriminator: ClientDiscriminator,
    ) -> Result<Vec<(Pubkey, Account)>> {
        let memcmp = RpcFilterType::Memcmp(Memcmp::new(
            0,
            MemcmpEncodedBytes::Bytes(discriminator.to_vec()),
        ));
        let config = RpcProgramAccountsConfig {
            filters: Some(vec![RpcFilterType::DataSize(size), memcmp]),
            account_config: RpcAccountInfoConfig {
                encoding: Some(UiAccountEncoding::Base64Zstd),
                ..RpcAccountInfoConfig::default()
            },
            ..RpcProgramAccountsConfig::default()
        };

        self.get_program_accounts_with_config(program_id, config)
            .await
    }

    async fn get_program_accounts_with_discriminator(
        &self,
        program_id: &Pubkey,
        discriminator: ClientDiscriminator,
    ) -> Result<Vec<(Pubkey, Account)>> {
        let memcmp = RpcFilterType::Memcmp(Memcmp::new(
            0,
            MemcmpEncodedBytes::Bytes(discriminator.to_vec()),
        ));
        let config = RpcProgramAccountsConfig {
            filters: Some(vec![memcmp]),
            account_config: RpcAccountInfoConfig {
                encoding: Some(UiAccountEncoding::Base64Zstd),
                ..RpcAccountInfoConfig::default()
            },
            ..RpcProgramAccountsConfig::default()
        };

        self.get_program_accounts_with_config(program_id, config)
            .await
    }

    async fn get_program_accounts_with_discriminator_and_filters(
        &self,
        program_id: &Pubkey,
        discriminator: ClientDiscriminator,
        mut filters: Vec<RpcFilterType>,
    ) -> Result<Vec<(Pubkey, Account)>> {
        filters.push(RpcFilterType::Memcmp(Memcmp::new(
            0,
            MemcmpEncodedBytes::Bytes(discriminator.to_vec()),
        )));
        let config = RpcProgramAccountsConfig {
            filters: Some(filters),
            account_config: RpcAccountInfoConfig {
                encoding: Some(UiAccountEncoding::Base64Zstd),
                ..RpcAccountInfoConfig::default()
            },
            ..RpcProgramAccountsConfig::default()
        };

        self.get_program_accounts_with_config(program_id, config)
            .await
    }

    async fn get_slot_with_commitment(&self, commitment: CommitmentConfig) -> Result<Slot>;

    async fn get_recommended_micro_lamport_fee(&self, priority: TransactionPriority)
        -> Result<u64>;

    async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts_pk: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64>;

    /// Get average slot duration in ms over the last minute.
    async fn get_recent_slot_duration_ms(&self) -> Result<u64> {
        Ok(DEFAULT_MS_PER_SLOT)
    }
}

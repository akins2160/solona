use std::time::Duration;

use anchor_client::solana_sdk::commitment_config::CommitmentLevel;
use async_trait::async_trait;
use futures::future::try_join_all;
use solana_client::{
    nonblocking::rpc_client::RpcClient,
    rpc_config::{
        RpcAccountInfoConfig, RpcProgramAccountsConfig, RpcSendTransactionConfig,
        RpcSimulateTransactionConfig,
    },
};
use tracing::debug;

use super::{retrying_client::RetryingAsyncClient, *};
use crate::Result;

pub trait RpcClientExt {
    fn new_with_commitment_and_retry(
        url: String,
        commitment: CommitmentConfig,
    ) -> RetryingAsyncClient<RpcClient>;
}

impl RpcClientExt for RpcClient {
    fn new_with_commitment_and_retry(
        url: String,
        commitment: CommitmentConfig,
    ) -> RetryingAsyncClient<RpcClient> {
        let client = RpcClient::new_with_commitment(url, commitment);
        RetryingAsyncClient::new(client, commitment)
    }
}

#[async_trait]
impl AsyncClient for RpcClient {
    fn get_rpc(&self) -> &RpcClient {
        self
    }

    async fn simulate_transaction(
        &self,
        transaction: &VersionedTransaction,
    ) -> Result<RpcSimulateTransactionResult> {
        <RpcClient>::simulate_transaction_with_config(
            self,
            transaction,
            RpcSimulateTransactionConfig {
                commitment: Some(CommitmentConfig::processed()),
                replace_recent_blockhash: true,
                ..RpcSimulateTransactionConfig::default()
            },
        )
        .await
        .map_err(Into::into)
        .map(|response| response.value)
    }

    async fn send_transaction(
        &self,
        transaction: &VersionedTransaction,
        _timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let sim_res = <RpcClient>::simulate_transaction_with_config(
            self,
            transaction,
            RpcSimulateTransactionConfig {
                commitment: Some(CommitmentConfig::processed()),
                replace_recent_blockhash: true,
                ..RpcSimulateTransactionConfig::default()
            },
        )
        .await?;
        if let Some(ref err) = sim_res.value.err {
            debug!("Transaction simulation failed: {:#?}", sim_res);
            return Err(solana_client::client_error::ClientError::from(
                solana_client::client_error::ClientErrorKind::TransactionError(err.clone()),
            )
            .into());
        }
        <RpcClient>::send_transaction_with_config(
            self,
            transaction,
            RpcSendTransactionConfig {
                skip_preflight: true,
                preflight_commitment: Some(CommitmentLevel::Finalized),
                max_retries: Some(0),
                ..RpcSendTransactionConfig::default()
            },
        )
        .await
        .map(ConfirmableTransaction::unconfirmed)
        .map_err(Into::into)
    }

    async fn send_transaction_no_preflight(
        &self,
        transaction: &VersionedTransaction,
        _timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        <RpcClient>::send_transaction_with_config(
            self,
            transaction,
            RpcSendTransactionConfig {
                skip_preflight: true,
                preflight_commitment: None,
                max_retries: Some(0),
                ..RpcSendTransactionConfig::default()
            },
        )
        .await
        .map(ConfirmableTransaction::unconfirmed)
        .map_err(Into::into)
    }

    async fn get_minimum_balance_for_rent_exemption(&self, data_len: usize) -> Result<u64> {
        <RpcClient>::get_minimum_balance_for_rent_exemption(self, data_len)
            .await
            .map_err(Into::into)
    }

    async fn get_signature_statuses(
        &self,
        signatures: &[Signature],
    ) -> Result<Vec<Option<TransactionStatus>>> {
        <RpcClient>::get_signature_statuses(self, signatures)
            .await
            .map(|response| response.value)
            .map_err(Into::into)
    }

    async fn get_latest_blockhash(&self) -> Result<Hash> {
        <RpcClient>::get_latest_blockhash_with_commitment(self, CommitmentConfig::finalized())
            .await
            .map(|r| r.0)
            .map_err(Into::into)
    }

    async fn is_blockhash_valid(&self, blockhash: &Hash) -> Result<bool> {
        <RpcClient>::is_blockhash_valid(self, blockhash, CommitmentConfig::processed())
            .await
            .map_err(Into::into)
    }

    async fn get_balance(&self, pubkey: &Pubkey) -> Result<u64> {
        <RpcClient>::get_balance(self, pubkey)
            .await
            .map_err(Into::into)
    }

    async fn get_account(&self, pubkey: &Pubkey) -> Result<Account> {
        Ok(
            <RpcClient>::get_account_with_commitment(self, pubkey, CommitmentConfig::processed())
                .await?
                .value
                .ok_or_else(|| {
                    solana_client::client_error::ClientError::from(
                        solana_client::client_error::ClientErrorKind::Custom(format!(
                            "AccountNotFound: pubkey={pubkey}"
                        )),
                    )
                })?,
        )
    }

    async fn get_multiple_accounts(&self, pubkeys: &[Pubkey]) -> Result<Vec<Option<Account>>> {
        Ok(try_join_all(
            pubkeys
                .chunks(100)
                .map(|chunk| <RpcClient>::get_multiple_accounts(self, chunk)),
        )
        .await?
        .into_iter()
        .flatten()
        .collect())
    }

    async fn get_multiple_accounts_with_config(
        &self,
        pubkeys: &[Pubkey],
        config: RpcAccountInfoConfig,
    ) -> Result<Vec<Option<Account>>> {
        Ok(try_join_all(pubkeys.chunks(100).map(|chunk| {
            <RpcClient>::get_multiple_accounts_with_config(self, chunk, config.clone())
        }))
        .await?
        .into_iter()
        .flat_map(|r| r.value)
        .collect())
    }

    async fn get_program_accounts(&self, program_id: &Pubkey) -> Result<Vec<(Pubkey, Account)>> {
        <RpcClient>::get_program_accounts(self, program_id)
            .await
            .map_err(Into::into)
    }

    async fn get_program_accounts_with_config(
        &self,
        program_id: &Pubkey,
        config: RpcProgramAccountsConfig,
    ) -> Result<Vec<(Pubkey, Account)>> {
        <RpcClient>::get_program_accounts_with_config(self, program_id, config)
            .await
            .map_err(Into::into)
    }

    async fn get_slot_with_commitment(&self, commitment: CommitmentConfig) -> Result<Slot> {
        <RpcClient>::get_slot_with_commitment(self, commitment)
            .await
            .map_err(Into::into)
    }

    async fn get_recommended_micro_lamport_fee(
        &self,
        priority: TransactionPriority,
    ) -> Result<u64> {
        self.get_recommended_micro_lamport_fee_for_accounts(&[], priority)
            .await
    }

    async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64> {
        crate::priority_fees::standard::get_recommended_micro_lamport_fee_for_accounts(
            self, accounts, priority,
        )
        .await
    }

    async fn get_recent_slot_duration_ms(&self) -> Result<u64> {
        let samples = <RpcClient>::get_recent_performance_samples(self, Some(1)).await?;
        let sample = samples
            .into_iter()
            .next()
            .ok_or(crate::ErrorKind::NoRecentPerformanceData)?;
        let average_slot_duration = u64::from(sample.sample_period_secs) * 1000 / sample.num_slots;
        Ok(average_slot_duration)
    }
}

use std::time::Duration;

use anchor_client::solana_sdk::commitment_config::CommitmentLevel;
use async_trait::async_trait;
use solana_client::{nonblocking::rpc_client::RpcClient, rpc_config::RpcSendTransactionConfig};
use tracing::{debug, trace};

use super::{retrying_client::RetryingAsyncClient, *};
use crate::{ConfirmableTransaction, Result};

pub struct CompositeRpcClient {
    pub rpc_client: RpcClient,
    pub sender_client: RpcClient,
}

impl CompositeRpcClient {
    pub fn new(
        rpc_client_url: String,
        sender_client_url: String,
        commitment_config: CommitmentConfig,
    ) -> RetryingAsyncClient<Self> {
        let client = Self::new_no_retry(rpc_client_url, sender_client_url, commitment_config);
        RetryingAsyncClient::new(client, commitment_config)
    }

    pub fn new_no_retry(
        rpc_client_url: String,
        sender_client_url: String,
        commitment_config: CommitmentConfig,
    ) -> Self {
        let rpc_client = RpcClient::new_with_commitment(rpc_client_url.clone(), commitment_config);
        let sender_client =
            RpcClient::new_with_commitment(sender_client_url.clone(), commitment_config);
        Self {
            rpc_client,
            sender_client,
        }
    }
}

#[async_trait]
impl AsyncClient for CompositeRpcClient {
    fn get_rpc(&self) -> &RpcClient {
        &self.rpc_client
    }

    async fn simulate_transaction(
        &self,
        transaction: &VersionedTransaction,
    ) -> Result<RpcSimulateTransactionResult> {
        AsyncClient::simulate_transaction(&self.rpc_client, transaction).await
    }

    async fn send_transaction(
        &self,
        transaction: &VersionedTransaction,
        _timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let sim_res = <RpcClient>::simulate_transaction(&self.rpc_client, transaction).await?;
        if let Some(ref err) = sim_res.value.err {
            debug!("Transaction simulation failed: {:#?}", sim_res);
            return Err(solana_client::client_error::ClientError::from(
                solana_client::client_error::ClientErrorKind::TransactionError(err.clone()),
            )
            .into());
        }
        let sig = <RpcClient>::send_transaction_with_config(
            &self.sender_client,
            transaction,
            RpcSendTransactionConfig {
                skip_preflight: true,
                preflight_commitment: Some(CommitmentLevel::Finalized),
                max_retries: Some(0),
                ..RpcSendTransactionConfig::default()
            },
        )
        .await?;
        trace!("Sent transaction no retry: {:?}", sig);
        Ok(ConfirmableTransaction::unconfirmed(sig))
    }

    async fn send_transaction_no_preflight(
        &self,
        transaction: &VersionedTransaction,
        _timeout: Option<Duration>,
    ) -> Result<ConfirmableTransaction> {
        let sig = <RpcClient>::send_transaction_with_config(
            &self.sender_client,
            transaction,
            RpcSendTransactionConfig {
                skip_preflight: true,
                preflight_commitment: Some(CommitmentLevel::Finalized),
                max_retries: Some(0),
                ..RpcSendTransactionConfig::default()
            },
        )
        .await?;
        trace!("Sent transaction no retry: {:?}", sig);
        Ok(ConfirmableTransaction::unconfirmed(sig))
    }

    async fn get_minimum_balance_for_rent_exemption(&self, data_len: usize) -> Result<u64> {
        AsyncClient::get_minimum_balance_for_rent_exemption(&self.rpc_client, data_len).await
    }

    async fn get_signature_statuses(
        &self,
        signatures: &[Signature],
    ) -> Result<Vec<Option<TransactionStatus>>> {
        AsyncClient::get_signature_statuses(&self.rpc_client, signatures).await
    }

    async fn get_latest_blockhash(&self) -> Result<Hash> {
        AsyncClient::get_latest_blockhash(&self.rpc_client).await
    }

    async fn is_blockhash_valid(&self, blockhash: &Hash) -> Result<bool> {
        AsyncClient::is_blockhash_valid(&self.rpc_client, blockhash).await
    }

    async fn get_balance(&self, pubkey: &Pubkey) -> Result<u64> {
        AsyncClient::get_balance(&self.rpc_client, pubkey).await
    }

    async fn get_account(&self, pubkey: &Pubkey) -> Result<Account> {
        AsyncClient::get_account(&self.rpc_client, pubkey).await
    }

    async fn get_multiple_accounts(&self, pubkeys: &[Pubkey]) -> Result<Vec<Option<Account>>> {
        AsyncClient::get_multiple_accounts(&self.rpc_client, pubkeys).await
    }

    async fn get_multiple_accounts_with_config(
        &self,
        pubkeys: &[Pubkey],
        config: RpcAccountInfoConfig,
    ) -> Result<Vec<Option<Account>>> {
        AsyncClient::get_multiple_accounts_with_config(&self.rpc_client, pubkeys, config).await
    }

    async fn get_program_accounts(&self, program_id: &Pubkey) -> Result<Vec<(Pubkey, Account)>> {
        AsyncClient::get_program_accounts(&self.rpc_client, program_id).await
    }

    async fn get_program_accounts_with_config(
        &self,
        program_id: &Pubkey,
        config: RpcProgramAccountsConfig,
    ) -> Result<Vec<(Pubkey, Account)>> {
        AsyncClient::get_program_accounts_with_config(&self.rpc_client, program_id, config).await
    }

    async fn get_slot_with_commitment(&self, commitment: CommitmentConfig) -> Result<Slot> {
        AsyncClient::get_slot_with_commitment(&self.rpc_client, commitment).await
    }

    async fn get_recommended_micro_lamport_fee(
        &self,
        priority: TransactionPriority,
    ) -> Result<u64> {
        self.get_recommended_micro_lamport_fee_for_accounts(&[], priority)
            .await
    }

    async fn get_recommended_micro_lamport_fee_for_accounts(
        &self,
        accounts: &[Pubkey],
        priority: TransactionPriority,
    ) -> Result<u64> {
        // Composite RPC assume a triton RPC
        crate::priority_fees::triton::get_recommended_micro_lamport_fee_for_accounts(
            &self.rpc_client,
            accounts,
            priority,
        )
        .await
    }

    async fn get_recent_slot_duration_ms(&self) -> Result<u64> {
        AsyncClient::get_recent_slot_duration_ms(&self.rpc_client).await
    }
}

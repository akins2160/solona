/// Average a list of u64 values.
///
/// # Arguments
///
/// * `values` - An iterator of u64 values.
///
/// # Returns
///
/// The average of the values. 0 if the iterator is empty.
///
/// # Panics
///
/// Could panic if more than `u64::MAX` values are provided and the average overflows.
pub fn avg(values: impl Iterator<Item = u64>) -> u64 {
    let mut count = 0_u128;
    let mut sum = 0_u128;
    for value in values {
        if let Some(new_sum) = sum.checked_add(u128::from(value)) {
            count += 1;
            sum = new_sum;
        } else {
            break;
        }
    }

    if count > 0 {
        u64::try_from(sum / count).expect("Sum / count should not overflow on u64")
    } else {
        0
    }
}

/// Median a list of u64 values.
///
/// # Arguments
///
/// * `values` - An iterator of u64 values.
///
/// # Returns
///
/// The median of the values. 0 if the iterator is empty.
pub fn median(values: impl Iterator<Item = u64>) -> u64 {
    let mut values: Vec<u64> = values.collect();
    let len = values.len();
    if len == 0 {
        return 0;
    }
    values.sort_unstable();
    if len % 2 == 0 {
        // Avoid all risk of overflow by using u128
        ((u128::from(values[len / 2 - 1]) + u128::from(values[len / 2])) / 2) as u64
    } else {
        values[len / 2]
    }
}

# Deduplication Guidelines

Apply the selected Sherlock rules in [`judging-guidelines.md`](judging-guidelines.md#xii-duplication-guidelines). They have the highest authority for duplication; engagement context may help compare reports but does not replace these requirements.

## Required Test

A potential duplicate of a target issue must do all three:

1. Identify the root cause.
2. Identify at least Low impact.
3. Identify a valid attack path or vulnerability path.

Only a report meeting all three requirements is duplicated with the target. Reports that fail any requirement are not duplicates of that target, but may still be judged independently, duplicated with another report, or judged at another validity or severity outcome. All reports in a duplicate group receive the highest severity identified among the duplicates. Apply the ordered definitions in [`severity-set.json`](severity-set.json).  
Source: [`judging-guidelines.md`, §XII, lines 170–180](judging-guidelines.md#xii-duplication-guidelines).

## Root-Cause Grouping

- The same logic mistake or the same conceptual mistake may be one root cause even when it appears in multiple places or contracts.
- Slippage protection, reentrancy, access control, and front-run/sandwich issues may be grouped by root cause.
- Different underlying implementations, impacts, or fixes may justify separate treatment.
- Reentrancy is divided into same-function, cross-function, cross-contract, read-only, and cross-chain types. Different scenarios of the same type within the codebase should be treated as the same root cause.
- Front-running, sandwich, and slippage reports are grouped according to whether the common fix is slippage protection or a commit-reveal mechanism.

Source: [`judging-guidelines.md`, §XII “Root cause groupings,” lines 182–214](judging-guidelines.md#root-cause-groupings).

## Engagement Context

- Known status and duplicate status are separate judge dimensions in the selected guidelines. Do not infer an additional duplicate-of-known rule or an Issues Ratio consequence that the sources do not state. Source: [`judging-guidelines.md`, §II, lines 47–58](judging-guidelines.md#ii-audit-engine-mechanics).
- The prior Certora report describes L-12 as the mirror image of L-11 with the “same root cause, opposite direction.” That statement is comparison context; the three required Sherlock criteria still govern an actual merge. See [`known-issues/certora-findings.md`](../known-issues/certora-findings.md) and the detailed L-11/L-12 sections in the [supplied report](<Certora - Kamino - Metavault - Draft Report.md>).
- Project documentation does not supply any other engagement-specific merge threshold or exception.

# Build Paths in This Workspace

The supplied [`BUILD-INSTRUCTIONS.md`](BUILD-INSTRUCTIONS.md) assumes each archive is manually extracted directly under `context/`. The preparation contract instead preserves archive members under `<archive>.unpacked/`; both unchanged archives and every extracted member are present.

To use the existing extractions, apply the original instructions with these path substitutions in the root `Cargo.toml` patch block:

```toml
[patch."ssh://git@github.com/Kamino-Finance/klend-private.git"]
kamino_lending = { path = "../context/klend-metavault-private.zip.unpacked/klend-metavault-private/programs/klend" }

[patch."ssh://git@github.com/Kamino-Finance/scope-private.git"]
orbit-link = { path = "../context/scope-metavault-private.zip.unpacked/scope-metavault-private/off_chain/orbit-link" }
```

All toolchain versions, commands, expected lockfile behavior, platform-specific workarounds, and verified test counts remain exactly as stated in [`BUILD-INSTRUCTIONS.md`](BUILD-INSTRUCTIONS.md). The dependency archives are build context and do not expand the direct file scope in [`scope.json`](scope.json).

## Dependency Revision Caveat

The audited source snapshot records these private Git revisions:

- `kamino_lending`: `7f795c24d75cdb359900dd94b1477d38b832c9b8` in `Cargo.lock`; protocol documentation models klend behavior at `7f795c2`.
- `orbit-link`: `36b01b2ce9850d2f66ab50c5f5c7f0ee7a06c9a4` in `Cargo.lock` and `libs/client/Cargo.toml`.

The supplied archive comments identify `klend-metavault-private` at `995697ce2a506bd8710f0bc914331ccd4c1fcf4d` and `scope-metavault-private` at `0478d171f0b7085029373405e12b2a516fa821a1`. The build patch replaces the private Git sources with those archive paths, and the supplied instructions state that the first build rewrites `Cargo.lock`.

Accordingly, the audited manifests and protocol model establish the declared dependency revisions, while the archive commits establish the code exercised by the offline build procedure. The supplied material does not establish that each pair is byte-identical. Keep this distinction when interpreting PoCs and test results. `orbit-link` is used only by the out-of-scope off-chain client.

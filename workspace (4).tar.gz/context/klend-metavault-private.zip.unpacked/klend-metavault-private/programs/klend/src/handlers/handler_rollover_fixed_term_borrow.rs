use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_interface::{self, Mint, TokenAccount, TokenInterface};

use crate::{
    fraction::Fraction,
    gen_signer_seeds,
    handlers::handler_refresh_obligation_farms_for_reserve::*,
    lending_market::{lending_checks, lending_operations},
    refresh_farms,
    state::{obligation::Obligation, LendingMarket, Reserve},
    utils::{seeds, token_transfer},
    FixedTermRolloverResult, LendingError, ReserveFarmKind,
};

pub fn process<'info>(
    ctx: Context<'_, '_, '_, 'info, RolloverFixedTermBorrow<'info>>,
) -> Result<()> {
    let needs_farms_refresh = process_impl(&ctx.accounts.rollover_accounts)?;
    if needs_farms_refresh {
        refresh_farms!(
            ctx.accounts.rollover_accounts,
            [
                (
                    ctx.accounts.rollover_accounts.source_borrow_reserve,
                    ctx.accounts.source_farms_accounts,
                    Debt,
                ),
                (
                    ctx.accounts.rollover_accounts.target_borrow_reserve,
                    ctx.accounts.target_farms_accounts,
                    Debt,
                )
            ],
        );
    }
    Ok(())
}

fn process_impl(accounts: &RolloverAccounts) -> Result<bool> {
    lending_checks::rollover_fixed_term_borrow_checks(accounts)?;

    // Load the accounts:
    let market_address = accounts.lending_market.key();
    let market = &accounts.lending_market.load()?;
    let obligation = &mut accounts.obligation.load_mut()?;
    let source_borrow_reserve_address = accounts.source_borrow_reserve.key();
    let target_borrow_reserve_address = accounts.target_borrow_reserve.key();
    let source_borrow_reserve = &mut accounts.source_borrow_reserve.load_mut()?;
    let clock = &Clock::get()?;

    // Capture the "before" state: (for the latter post-checks)
    let source_reserve_before = capture_reserve_accounting_and_balance(
        source_borrow_reserve,
        &accounts.source_borrow_reserve_liquidity,
    )?;
    let obligation_before = capture_obligation_borrows_accounting(
        obligation,
        source_borrow_reserve_address,
        target_borrow_reserve_address,
    )?;

    if source_borrow_reserve_address == target_borrow_reserve_address {
        // Handle the simple case of "same reserve" rollover accounting:
        lending_operations::rollover_borrow_into_same_reserve(
            market,
            source_borrow_reserve_address,
            source_borrow_reserve,
            obligation,
            clock,
        )?;

        // No effects to apply in this case...

        // Capture the "after" state: (for the latter post-checks)
        let source_reserve_after = capture_reserve_accounting_and_balance(
            source_borrow_reserve,
            &accounts.source_borrow_reserve_liquidity,
        )?;
        let obligation_after = capture_obligation_borrows_accounting(
            obligation,
            source_borrow_reserve_address,
            target_borrow_reserve_address,
        )?;

        // Post-checks: (please note how the actually-rollover'd amount is not even relevant here, in the "same reserve" case)
        lending_checks::rollover_fixed_term_borrow_into_same_reserve_post_checks(
            source_reserve_before,
            obligation_before,
            source_reserve_after,
            obligation_after,
        )?;

        return Ok(false); // ... also, no need to refresh farms (no amounts have changed)
    }

    // Only in the "different reserve" case we are actually allowed to borrow the target reserve:
    let target_borrow_reserve = &mut accounts.target_borrow_reserve.load_mut()?;

    // Capture the "before" state of the target reserve too:
    let target_reserve_before = capture_reserve_accounting_and_balance(
        target_borrow_reserve,
        &accounts.target_borrow_reserve_liquidity,
    )?;

    // Perform the accounting:
    let rollover_result = lending_operations::rollover_borrow_into_different_reserve(
        market,
        source_borrow_reserve_address,
        source_borrow_reserve,
        target_borrow_reserve_address,
        target_borrow_reserve,
        obligation,
        clock,
    )?;

    // Extract whatever is needed, but preserve the result itself for the post-checks:
    let FixedTermRolloverResult {
        repaid_amount: _,   // only needed by the post-checks
        borrowed_amount: _, // only needed by the post-checks
        tokens_to_transfer_over,
    } = &rollover_result;

    // The effect here is "transfer between 2 reserves", and we can re-use the borrow's transfer helper for this:
    let authority_signer_seeds = gen_signer_seeds!(market_address.as_ref(), market.bump_seed as u8);
    token_transfer::borrow_obligation_liquidity_transfer(
        accounts.token_program.to_account_info(),
        accounts.liquidity_mint.to_account_info(),
        accounts.target_borrow_reserve_liquidity.to_account_info(), // we transfer the liquidity FROM target...
        accounts.source_borrow_reserve_liquidity.to_account_info(), // ... TO source reserve...
        accounts.lending_market_authority.to_account_info(),
        authority_signer_seeds,
        *tokens_to_transfer_over, // ... because we are repaying the source using the target reserve.
        accounts.liquidity_mint.decimals,
    )?;

    // Capture the "after" state: (for the latter post-checks)
    let source_reserve_after = capture_reserve_accounting_and_balance(
        source_borrow_reserve,
        &accounts.source_borrow_reserve_liquidity,
    )?;
    let target_reserve_after = capture_reserve_accounting_and_balance(
        target_borrow_reserve,
        &accounts.target_borrow_reserve_liquidity,
    )?;
    let obligation_after = capture_obligation_borrows_accounting(
        obligation,
        source_borrow_reserve_address,
        target_borrow_reserve_address,
    )?;

    // Post-checks:
    lending_checks::rollover_fixed_term_borrow_into_different_reserve_post_checks(
        lending_checks::RolloverAccountingAndBalances {
            source_reserve: source_reserve_before,
            target_reserve: target_reserve_before,
            obligation: obligation_before,
        },
        lending_checks::RolloverAccountingAndBalances {
            source_reserve: source_reserve_after,
            target_reserve: target_reserve_after,
            obligation: obligation_after,
        },
        rollover_result,
    )?;

    Ok(true) // we moved the funds between reserves, so their farms have to be notified about it
}

fn capture_reserve_accounting_and_balance(
    reserve: &Reserve,
    reserve_liquidity_vault: &InterfaceAccount<TokenAccount>,
) -> Result<lending_checks::ReserveAccountingAndBalance> {
    Ok(lending_checks::ReserveAccountingAndBalance {
        total_available_liquidity_amount: reserve.total_available_liquidity_amount(),
        borrowed_amount: reserve.liquidity.total_borrow(),
        vault_balance: token_interface::accessor::amount(
            &reserve_liquidity_vault.to_account_info(),
        )?,
    })
}

fn capture_obligation_borrows_accounting(
    obligation: &Obligation,
    source_reserve_address: Pubkey,
    target_reserve_address: Pubkey,
) -> Result<lending_checks::ObligationRolloverAccounting> {
    Ok(lending_checks::ObligationRolloverAccounting {
        source_reserve_borrowed_amount: capture_borrowed_amount(obligation, source_reserve_address),
        target_reserve_borrowed_amount: capture_borrowed_amount(obligation, target_reserve_address),
    })
}

fn capture_borrowed_amount(obligation: &Obligation, borrow_reserve_address: Pubkey) -> Fraction {
    obligation
        .find_liquidity_in_borrows(borrow_reserve_address)
        .ok() // it may not exist yet (especially for the target reserve)
        .map(|(borrow, _index)| borrow.borrowed_amount())
        .unwrap_or_default()
}

#[derive(Accounts, Clone)]
pub struct RolloverAccounts<'info> {
    pub payer: Signer<'info>,

    /// The obligation with a borrow to be rolled over (or migrated).
    #[account(mut,
        has_one = lending_market,
    )]
    pub obligation: AccountLoader<'info, Obligation>,

    /// The [Self::obligation]'s market, needed for validations against the market-wide
    /// configuration.
    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// The [Self::lending_market]'s authority, needed to transfer the newly-borrowed funds out of
    /// the [Self::reserve_source_liquidity].
    #[account(
        seeds = [seeds::LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    /// The reserve used by the existing [Self::obligation]'s borrow that needs to rollover from.
    #[account(mut,
        has_one = lending_market,
    )]
    pub source_borrow_reserve: AccountLoader<'info, Reserve>,

    /// The reserve to rollover the borrow into - possibly (but not necessarily) the same as
    /// [Self::source_borrow_reserve]'s (but definitely of the same liquidity mint).
    #[account(mut,
        has_one = lending_market,
        constraint = target_borrow_reserve.load()?.liquidity.mint_pubkey == source_borrow_reserve.load()?.liquidity.mint_pubkey @ LendingError::BorrowRolloverLiquidityMintMismatch,
    )]
    pub target_borrow_reserve: AccountLoader<'info, Reserve>,

    /// The mint of [Self::source_borrow_reserve] and [Self::target_borrow_reserve], needed to
    /// transfer funds between them.
    #[account(
        address = source_borrow_reserve.load()?.liquidity.mint_pubkey,
        mint::token_program = token_program,
    )]
    pub liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// The vault of [Self::source_borrow_reserve], from which the funds are transferred.
    #[account(mut,
        address = source_borrow_reserve.load()?.liquidity.supply_vault,
    )]
    pub source_borrow_reserve_liquidity: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The vault of [Self::target_borrow_reserve], from which the funds are transferred.
    #[account(mut,
        address = target_borrow_reserve.load()?.liquidity.supply_vault,
    )]
    pub target_borrow_reserve_liquidity: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The token program of [Self::liquidity_mint] - needed to execute the transfer.
    pub token_program: Interface<'info, TokenInterface>,
}

#[derive(Accounts)]
pub struct RolloverFixedTermBorrow<'info> {
    pub rollover_accounts: RolloverAccounts<'info>,
    pub source_farms_accounts: OptionalObligationFarmsAccounts<'info>,
    pub target_farms_accounts: OptionalObligationFarmsAccounts<'info>,
    pub farms_program: Program<'info, farms::program::Farms>,
}

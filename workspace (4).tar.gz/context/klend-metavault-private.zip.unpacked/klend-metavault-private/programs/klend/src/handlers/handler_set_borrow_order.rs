use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_interface::{Mint, TokenAccount};
use solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId};

use crate::{
    borrow_order_operations, lending_market::lending_checks, utils::ctx_event_emitter,
    BorrowOrderConfig, LendingError, LendingMarket, Obligation, Reserve,
};

pub fn process(
    ctx: Context<SetBorrowOrder>,
    order_config: BorrowOrderConfigArgs,
    min_expected_current_remaining_debt_amount: u64, // used only to prevent overwriting of a just-filled order (under race conditions)
) -> Result<()> {
    let order_config = order_config.with_accounts(ctx.accounts);
    let lending_market = &ctx.accounts.lending_market.load()?;
    let reserve = &ctx.accounts.reserve.load()?;
    lending_checks::check_reserve_emergency_mode(reserve)?;
    let obligation = &mut ctx.accounts.obligation.load_mut()?;
    let clock = Clock::get()?;

    // Note: this handler, similarly to BO execution and Withdraw Ticket issuance / redemption,
    // performs a "min-value" soft check (which needs a market price, but not necessarily a fresh
    // one). Typically, in such cases we require fresh reserve (or delegate to the refresh_reserve()
    // with `price = None` ourselves). However, when setting a borrow order, we do NOT need fresh
    // collateral exchange rate (nor fresh accrued interest, nor any of the refresh effects), so we
    // can skip this step entirely.

    require_gte!(
        obligation.borrow_order.remaining_debt_amount,
        min_expected_current_remaining_debt_amount,
        LendingError::ExpectationNotMet,
    );

    borrow_order_operations::set_borrow_order(
        lending_market,
        reserve,
        &mut obligation.borrow_order,
        order_config,
        &clock,
        ctx_event_emitter!(ctx),
    )?;
    Ok(())
}

#[event_cpi]
#[derive(Accounts)]
pub struct SetBorrowOrder<'info> {
    /// The [Self::obligation]'s owner.
    pub owner: Signer<'info>,

    /// The obligation to set the [BorrowOrder] on.
    #[account(mut, has_one = lending_market, has_one = owner)]
    pub obligation: AccountLoader<'info, Obligation>,

    /// The [Self::obligation]'s market - needed to validate feature flags and minimum order value.
    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// The reserve matching the [Self::debt_liquidity_mint] - needed for the minimum order value
    /// check. On cancellation, this account is ignored (but still must belong to the same market).
    #[account(has_one = lending_market)]
    pub reserve: AccountLoader<'info, Reserve>,

    /// The [BorrowOrder::filled_debt_destination] to set on order creation. Not editable on order
    /// updates.
    /// Ignored when cancelling the order.
    // Implementation note: this account could technically be an `Option<...>`, since it is not
    // required when cancelling an order. However, anchor constraints for `Option<...>` are much
    // harder to express and read (would require custom logic - please note that it references the
    // sibling `debt_liquidity_mint` which is "optional" in the same sense). For this reason,
    // both these accounts are always required, but will be ignored when cancelling the borrow order
    // (they must still be valid, though).
    #[account(
        token::mint = debt_liquidity_mint,
        token::authority = owner,
        token::token_program = reserve.load()?.liquidity.token_program,
    )]
    pub filled_debt_destination: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The [BorrowOrder::debt_liquidity_mint] to set on order creation. Not editable on order
    /// updates.
    /// Ignored when cancelling the order.
    // See the note on `filled_debt_destination` about the "optionality" of this account.
    #[account(
        address = reserve.load()?.liquidity.mint_pubkey,
        mint::token_program = reserve.load()?.liquidity.token_program,
    )]
    pub debt_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

/// A subset of [BorrowOrderConfig] excluding the accounts passed via [SetBorrowOrder].
#[derive(AnchorDeserialize, AnchorSerialize, Clone, Debug, Default, PartialEq, Eq)]
pub struct BorrowOrderConfigArgs {
    pub remaining_debt_amount: u64,
    pub max_borrow_rate_bps: u32,
    pub min_debt_term_seconds: u64,
    pub fillable_until_timestamp: u64,
    pub enable_auto_rollover_on_filled_borrows: bool,
}

impl BorrowOrderConfigArgs {
    /// Turns this partial config into a complete [BorrowOrderConfig], including the given accounts.
    pub fn with_accounts(self, accounts: &SetBorrowOrder) -> Option<BorrowOrderConfig> {
        if self == Default::default() {
            // A zeroed input means "cancel"; we also ignore the passed accounts then:
            return None;
        }
        let Self {
            remaining_debt_amount,
            max_borrow_rate_bps,
            min_debt_term_seconds,
            fillable_until_timestamp,
            enable_auto_rollover_on_filled_borrows,
        } = self;
        Some(BorrowOrderConfig {
            debt_liquidity_mint: accounts.debt_liquidity_mint.key(),
            remaining_debt_amount,
            filled_debt_destination: accounts.filled_debt_destination.key(),
            max_borrow_rate_bps,
            min_debt_term_seconds,
            fillable_until_timestamp,
            enable_auto_rollover_on_filled_borrows: u8::from(
                enable_auto_rollover_on_filled_borrows,
            ),
        })
    }
}

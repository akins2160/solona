use anchor_lang::{prelude::*, solana_program::program_option::COption, Accounts};
use anchor_spl::{
    token::Token,
    token_interface::{self, Mint, TokenAccount},
};
use solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId};

use crate::{
    lending_market::{lending_checks, lending_operations},
    utils::{
        accounts::{default_array, has_ata_address},
        seeds::{self, pda},
        token_transfer, CORRESPONDING_KAMINO_VAULT_PROGRAM_ID, VAULT_STATE_DISCRIMINATOR,
        WITHDRAW_TICKET_SIZE,
    },
    withdraw_ticket::{ProgressCallbackType, WithdrawTicket},
    LendingAction, LendingError, LendingMarket, Reserve,
};

pub fn process(
    ctx: Context<EnqueueToWithdraw>,
    collateral_amount: u64,
    progress_callback_type: ProgressCallbackType,
) -> Result<()> {
    lending_checks::enqueue_to_withdraw_checks(ctx.accounts)?;

    let lending_market = &ctx.accounts.lending_market.load()?;
    let reserve = &mut ctx.accounts.reserve.load_mut()?;
    let mut withdraw_ticket = ctx.accounts.withdraw_ticket.load_init()?;
    let clock = &Clock::get()?;

    require!(
        lending_market.is_withdraw_ticket_issuance_enabled(),
        LendingError::WithdrawTicketIssuanceDisabled,
    );

    // Refresh the reserve only to update the exchange rate. We do not check price freshness here:
    // the min-value is a "soft check" and can use whatever price is currently stored.
    lending_operations::refresh_reserve(
        reserve,
        clock,
        None,
        lending_market.referral_fee_bps,
        lending_market.reserve_rewards_max_apr_bps,
    )?;

    let initial_owner_queued_collateral_vault_balance =
        ctx.accounts.owner_queued_collateral_vault.amount;
    let initial_queued_collateral_amount = reserve.withdraw_queue.queued_collateral_amount;

    let sequence_number =
        lending_operations::enqueue_to_withdraw(lending_market, reserve, collateral_amount)?;

    msg!(
        "enqueued withdraw ticket with sequence number {sequence_number} for {collateral_amount} ctokens",
    );

    let progress_callback_custom_accounts =
        extract_progress_callback_custom_accounts(progress_callback_type, ctx.accounts)?;

    *withdraw_ticket = WithdrawTicket {
        sequence_number,
        owner: ctx.accounts.owner.key(),
        reserve: ctx.accounts.reserve.key(),
        user_destination_liquidity_ta: ctx.accounts.user_destination_liquidity_ta.key(),
        queued_collateral_amount: collateral_amount,
        created_at_timestamp: clock.unix_timestamp.try_into().expect("negative timestamp"),
        invalid: 0,
        progress_callback_type: u8::from(progress_callback_type),
        progress_callback_custom_accounts,
        alignment_padding: default_array(),
        end_padding: default_array(),
    };

    token_transfer::enqueue_collateral_transfer(
        ctx.accounts.user_source_collateral_ta.to_account_info(),
        ctx.accounts.owner_queued_collateral_vault.to_account_info(),
        ctx.accounts.owner.to_account_info(),
        ctx.accounts.reserve_collateral_mint.to_account_info(),
        ctx.accounts.collateral_token_program.to_account_info(),
        collateral_amount,
        ctx.accounts.reserve_collateral_mint.decimals,
    )?;

    // If the ticket owner uses an ATA as his liquidity destination, then we have to be ready to
    // re-create the ATA for him (because ATAs tend to get closed). In such case, we take the
    // "prepaid" ATA rent right away (i.e. lock the lamports within the newly-initialized ticket
    // account). This way, the entire amount will be returned to the ticket owner when the ticket
    // is redeemed - regardless if we need to use it for ATA creation or not.
    if has_ata_address(
        ctx.accounts.user_destination_liquidity_ta.as_ref(),
        ctx.accounts.owner.key,
        &reserve.liquidity.mint_pubkey,
        &reserve.liquidity.token_program,
    ) {
        drop(withdraw_ticket); // otherwise, the transfer below would effectively double-borrow from the RefMut
        token_transfer::destination_ata_rent_prepayment_transfer(
            ctx.accounts.owner.to_account_info(),
            ctx.accounts.withdraw_ticket.to_account_info(),
            ctx.accounts.system_program.to_account_info(),
        )?;
    }

    lending_checks::post_transfer_owner_queued_collateral_vault_balance_checks(
        token_interface::accessor::amount(
            &ctx.accounts.owner_queued_collateral_vault.to_account_info(),
        )?,
        reserve.withdraw_queue.queued_collateral_amount,
        initial_owner_queued_collateral_vault_balance,
        initial_queued_collateral_amount,
        LendingAction::Additive(collateral_amount),
    )?;

    Ok(())
}

fn extract_progress_callback_custom_accounts(
    progress_callback_type: ProgressCallbackType,
    accounts: &EnqueueToWithdraw,
) -> Result<[Pubkey; 2]> {
    Ok(match progress_callback_type {
        ProgressCallbackType::None => default_array(), // no custom accounts needed
        ProgressCallbackType::KlendQueueAccountingHandlerOnKvault => [
            extract_vault_address_from_kvault_signed_accounts(accounts)?,
            Pubkey::default(), // second custom account not needed by this callback type
        ],
    })
}

fn extract_vault_address_from_kvault_signed_accounts(
    accounts: &EnqueueToWithdraw,
) -> Result<Pubkey> {
    // This callback type requires just one custom accounts:
    let Some(vault_account) = &accounts.progress_callback_custom_account_0 else {
        msg!("The used progress callback requires the VaultState as a custom account");
        return err!(LendingError::InvalidWithdrawTicketProgressCallbackConfig);
    };

    // Check that it is a valid `VaultState`: (this is more of a sanity check; we cannot validate the entire state, and we trust the signed Kvault program anyway)
    if vault_account.owner != &CORRESPONDING_KAMINO_VAULT_PROGRAM_ID {
        msg!(
            "The VaultState account must belong to {}, but got {}",
            CORRESPONDING_KAMINO_VAULT_PROGRAM_ID,
            vault_account.owner
        );
        return err!(LendingError::InvalidWithdrawTicketProgressCallbackConfig);
    }
    let vault_data = vault_account.try_borrow_data()?;
    let vault_discriminator = &vault_data[..VAULT_STATE_DISCRIMINATOR.len().min(vault_data.len())];
    if vault_discriminator != VAULT_STATE_DISCRIMINATOR {
        msg!(
            "VaultState account should have discriminator {:?}, but got {:?}",
            VAULT_STATE_DISCRIMINATOR,
            vault_discriminator
        );
        return err!(LendingError::InvalidWithdrawTicketProgressCallbackConfig);
    }

    // Check that the signer of the transaction is Kvault's authority associated with the declared vault:
    let expected_authority_address = pda::kvault::base_authority(vault_account.key());
    if accounts.owner.key != &expected_authority_address {
        msg!(
            "The signer must be a base authority of vault {}",
            vault_account.key()
        );
        return err!(LendingError::InvalidWithdrawTicketProgressCallbackConfig);
    }

    Ok(vault_account.key())
}

#[derive(Accounts)]
pub struct EnqueueToWithdraw<'info> {
    /// The depositor holding ctokens.
    // Note: `mut` is only needed for `init` of the [Self::withdraw_ticket].
    #[account(mut)]
    pub owner: Signer<'info>,

    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// The market's authority, needed to initialize the [Self::owner_queued_collateral_vault].
    #[account(
        seeds = [seeds::LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    #[account(mut,
        has_one = lending_market
    )]
    pub reserve: AccountLoader<'info, Reserve>,

    /// The source of collateral to be enqueued.
    #[account(mut,
        token::mint = reserve_collateral_mint,
        token::authority = owner,
        token::token_program = collateral_token_program,
    )]
    pub user_source_collateral_ta: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The account to which the liquidity should be finally transferred later (to be recorded in
    /// the ticket).
    // Note on account input usage: technically, this ix does not transfer anything to this account, and we could just accept its address as an argument, but we prefer to pass it via accounts and this way leverage anchor validations and potentially LUTs.
    // Note on the banned "delegate" constraint: the delegate feature is almost exclusively used in hacks, so we will refuse to transfer the queued liquidity to a TA that has any delegate configured. Here we just check it preemptively.
    // Note on the banned "frozen" state: withdrawing to such account would fail (i.e. would mark the ticket as invalid). Here we just check it preemptively.
    #[account(
        token::mint = reserve_liquidity_mint,
        token::authority = owner,
        token::token_program = reserve.load()?.liquidity.token_program,
        constraint = user_destination_liquidity_ta.delegate == COption::None @ LendingError::InvalidTokenAccountState,
        constraint = !user_destination_liquidity_ta.is_frozen() @ LendingError::InvalidTokenAccountState,
    )]
    pub user_destination_liquidity_ta: Box<InterfaceAccount<'info, TokenAccount>>,

    // Note: only needed for validation of supported token extensions (just to fail-fast; the same check will be performed again during the ticketed withdraw).
    #[account(
        address = reserve.load()?.liquidity.mint_pubkey,
        mint::token_program = reserve.load()?.liquidity.token_program,
    )]
    pub reserve_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    #[account(
        address = reserve.load()?.collateral.mint_pubkey,
    )]
    pub reserve_collateral_mint: Box<InterfaceAccount<'info, Mint>>,

    /// The collateral's program - needed for invoking the transfer to the vault *and* (implicitly)
    /// for handling the `init_if_needed`.
    pub collateral_token_program: Program<'info, Token>,

    /// The new account to be initialized with the issued ticket's data.
    #[account(init,
        seeds = [seeds::WITHDRAW_TICKET, reserve.key().as_ref(), &reserve.load()?.withdraw_queue.next_issued_ticket_sequence_number.to_le_bytes()],
        bump,
        payer = owner,
        space = WITHDRAW_TICKET_SIZE + 8,
    )]
    pub withdraw_ticket: AccountLoader<'info, WithdrawTicket>,

    /// The per-owner "this reserve's queued collateral" vault (in which the collateral will be
    /// locked).
    #[account(init_if_needed,
        seeds = [seeds::OWNER_QUEUED_COLLATERAL_VAULT, reserve.key().as_ref(), owner.key().as_ref()],
        bump,
        payer = owner,
        token::mint = reserve_collateral_mint,
        token::authority = lending_market_authority,
        token::token_program = collateral_token_program,
    )]
    pub owner_queued_collateral_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The System program - needed only for `init` / `init_if_needed` of the accounts above.
    pub system_program: Program<'info, System>,

    /// The first one out of maximum 2 custom accounts that may be required if the optional "ticket
    /// progress callback" is configured for this ticket.
    ///
    /// The expected custom accounts are validated based on the `progress_callback_type` instruction
    /// argument. The currently supported ones are:
    /// - for [ProgressCallbackType::None] no custom accounts are expected (this is the default
    ///   behavior, when the instruction data is zeroed or absent).
    /// - for [ProgressCallbackType::KlendQueueAccountingHandlerOnKvault], only the `_0` custom
    ///   account is required:
    ///   - the `_0` custom account must represent the `VaultState` which disinvests from the
    ///     reserve (readonly; needed to be later passed as an input to the Kvault's handler);
    ///   - the `_1` custom account is ignored;
    ///   - the `owner` account (i.e. the signer) must be a Kvault-owned PDA base authority
    ///     associated with the vault indicated by `_0` (needed to prove that Kvault is CPI'ing this
    ///     handler).
    pub progress_callback_custom_account_0: Option<AccountInfo<'info>>,

    /// The second possible account (see the `progress_callback_custom_account_0` above).
    // Note: The explicit `_0/_1` was chosen (over `remaining_accounts`) only for easier backward
    // compatibility in future development.
    pub progress_callback_custom_account_1: Option<AccountInfo<'info>>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

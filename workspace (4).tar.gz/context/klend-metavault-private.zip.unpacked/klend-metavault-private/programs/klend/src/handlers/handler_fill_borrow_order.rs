use std::ops::{Deref, DerefMut};

use anchor_lang::{prelude::*, Accounts};
use anchor_spl::token_interface::{Mint, TokenAccount, TokenInterface};
use solana_program::sysvar::{instructions::Instructions as SysInstructions, SysvarId};

use super::handler_refresh_obligation_farms_for_reserve::*;
use crate::{
    borrow_order_operations,
    handlers::{borrow_obligation_liquidity_process_impl, BorrowObligationLiquidity},
    refresh_farms,
    state::{obligation::Obligation, LendingMarket, Reserve},
    utils::{ctx_event_emitter, seeds},
    BorrowSize, LendingError, ReferrerTokenState, ReserveFarmKind,
};

pub fn process<'info>(ctx: Context<'_, '_, '_, 'info, FillBorrowOrder<'info>>) -> Result<()> {
    process_impl(&ctx)?;
    refresh_farms!(
        ctx.accounts.borrow_accounts,
        [(
            ctx.accounts.borrow_accounts.borrow_reserve,
            ctx.accounts.farms_accounts,
            Debt,
        )],
    );
    Ok(())
}

fn process_impl<'info>(ctx: &Context<'_, '_, '_, 'info, FillBorrowOrder<'info>>) -> Result<()> {
    // No `lending_checks::...()` call here: this handler delegates to `borrow_obligation_liquidity`
    // which performs all the necessary checks on the adapted `accounts` struct.

    let accounts = &ctx.accounts.borrow_accounts;
    let remaining_accounts = ctx.remaining_accounts;

    // Borrow Obligation immutably, for a moment, just to find out the amount we want to borrow:
    let obligation = accounts.obligation.load()?;
    let order_remaining_amount = obligation.borrow_order.remaining_debt_amount;

    // Need to capture this information (for rollover config propagation decision) before delegating to `handler_borrow_obligation_liquidity` below:
    let already_borrowed_from_same_reserve = obligation
        .find_liquidity_index_in_borrows(accounts.borrow_reserve.key())
        .is_some();

    drop(obligation);

    // Fully re-use the logic of `handler_borrow_obligation_liquidity`:
    let fill_amount = borrow_obligation_liquidity_process_impl(
        &BorrowObligationLiquidity::from(accounts.clone()),
        remaining_accounts,
        BorrowSize::AtMost(order_remaining_amount),
    )?;

    // Note on freshness: we do NOT call `refresh_reserve()` nor check the price here, because
    // `borrow_obligation_liquidity` already does both. The remaining `fill_borrow_order()` logic
    // only performs the min-value "soft check" anyway.

    // Borrow all needed accounts again, this time including mutable Obligation...
    let borrow_reserve = accounts.borrow_reserve.load()?;
    let lending_market = accounts.lending_market.load()?;
    let mut obligation = accounts.obligation.load_mut()?;
    let clock = &Clock::get()?;

    // ... so that we can update its borrow order tracking:
    let borrow_order = &mut obligation.borrow_order;
    let borrow_order_rollover_config = borrow_order.get_rollover_config_for_filled_borrow(); // we have to capture this before the fill logic (which may clear the order if fully filled!)
    borrow_order_operations::fill_borrow_order(
        lending_market.deref(),
        &borrow_reserve,
        &mut obligation.borrow_order,
        clock,
        fill_amount, // Note: this deliberately only includes the actually-received debt amount (even though we borrow more, to cover e.g. origination fee, the non-received funds are not considered to "fill" the borrow order)
        ctx_event_emitter!(ctx),
    )?;

    // We now can honor the user's wish regarding the future auto-rollovers of the resulting borrow:
    if let Some(borrow_order_rollover_config) = borrow_order_rollover_config {
        borrow_order_operations::propagate_rollover_config_to_borrow(
            lending_market.deref(),
            obligation.deref_mut(),
            accounts.borrow_reserve.key(),
            borrow_order_rollover_config,
            already_borrowed_from_same_reserve,
        )?;
    }

    Ok(())
}

impl<'info> From<FillBorrowOrderAccounts<'info>> for BorrowObligationLiquidity<'info> {
    fn from(accounts: FillBorrowOrderAccounts<'info>) -> Self {
        let FillBorrowOrderAccounts {
            payer,
            obligation,
            lending_market,
            lending_market_authority,
            borrow_reserve,
            borrow_reserve_liquidity_mint,
            reserve_source_liquidity,
            borrow_reserve_liquidity_fee_receiver,
            user_destination_liquidity,
            referrer_token_state,
            token_program,
            instruction_sysvar_account,
        } = accounts;

        // Note: the owner (of the Obligation under which we borrow) is definitely NOT the same as
        // payer (executing the borrow order). However, this field is never read by the borrow
        // handler's logic - it is only present in the Accounts struct because it is needed for the
        // Anchor constraint (on the `obligation` field). The constraint will of course not be
        // evaluated on a manually-constructed instance, so we can put any dummy value here.
        // However, constructing a dummy `Signer<'info>` instance is not easy, due to its lifetime
        // requirement - hence we reuse the input `payer`.
        let owner = payer.clone();

        // Note: Anchor has no way of checking the field-annotated constraints on such a
        // manually-constructed `BorrowObligationLiquidity`. This is aligned with our use-case,
        // because some of those constraints do not apply when filling an order (e.g. about the
        // Obligation owner being the signer). Instead, we define our own constraints on the
        // `FillBorrowOrderAccounts` struct - some of them just happen to be the same as on borrow,
        // and some other differ accordingly.
        Self {
            owner,
            obligation,
            lending_market,
            lending_market_authority,
            borrow_reserve,
            borrow_reserve_liquidity_mint,
            reserve_source_liquidity,
            borrow_reserve_liquidity_fee_receiver,
            user_destination_liquidity,
            referrer_token_state,
            token_program,
            instruction_sysvar_account,
        }
    }
}

#[derive(Accounts, Clone)]
pub struct FillBorrowOrderAccounts<'info> {
    pub payer: Signer<'info>,

    /// The obligation with a [BorrowOrder].
    #[account(mut,
        has_one = lending_market,
    )]
    pub obligation: AccountLoader<'info, Obligation>,

    /// The [Self::obligation]'s market - needed for borrowing-related configuration.
    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// The [Self::lending_market]'s authority, needed to transfer the newly-borrowed funds out of
    /// the [Self::reserve_source_liquidity].
    #[account(
        seeds = [seeds::LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    /// The reserve to borrow from.
    ///
    /// Its mint must match the asset requested by the [BorrowOrder::debt_liquidity_mint].
    #[account(mut,
        has_one = lending_market,
        constraint = borrow_reserve.load()?.liquidity.mint_pubkey == obligation.load()?.borrow_order.debt_liquidity_mint @ LendingError::BorrowOrderDebtLiquidityMintMismatch,
    )]
    pub borrow_reserve: AccountLoader<'info, Reserve>,

    /// The mint of [Self::borrow_reserve] - needed to execute the transfer.
    #[account(
        address = borrow_reserve.load()?.liquidity.mint_pubkey,
        mint::token_program = token_program,
    )]
    pub borrow_reserve_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// The vault of [Self::borrow_reserve], from which the funds are transferred.
    #[account(mut,
        address = borrow_reserve.load()?.liquidity.supply_vault,
    )]
    pub reserve_source_liquidity: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The fee vault of [Self::borrow_reserve], to which the fees are transferred.
    #[account(mut,
        address = borrow_reserve.load()?.liquidity.fee_vault,
    )]
    pub borrow_reserve_liquidity_fee_receiver: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The destination token account that should receive the newly borrowed funds.
    ///
    /// It must match [BorrowOrder::filled_debt_destination], owner and mint.
    ///
    /// **Warning:** An altered destination account will prevent an order from being filled.
    #[account(mut,
        address = obligation.load()?.borrow_order.filled_debt_destination,
        token::mint = reserve_source_liquidity.mint,
        token::authority = obligation.load()?.owner,
    )]
    pub user_destination_liquidity: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The referrer's account, for accumulating fees - needed if the [Obligation::has_referrer].
    #[account(mut)]
    pub referrer_token_state: Option<AccountLoader<'info, ReferrerTokenState>>,

    /// The token program of [Self::borrow_reserve] - needed to execute the transfer.
    pub token_program: Interface<'info, TokenInterface>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

#[event_cpi]
#[derive(Accounts)]
pub struct FillBorrowOrder<'info> {
    pub borrow_accounts: FillBorrowOrderAccounts<'info>,
    pub farms_accounts: OptionalObligationFarmsAccounts<'info>,
    pub farms_program: Program<'info, farms::program::Farms>,
}

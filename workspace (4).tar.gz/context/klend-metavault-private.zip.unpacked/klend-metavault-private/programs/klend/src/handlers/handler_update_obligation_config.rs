use std::fmt::Debug;

use anchor_lang::{prelude::*, Accounts};

use crate::{
    lending_market::lending_operations, state::LendingMarket, Obligation,
    ObligationConfigUpdateSubject, Reserve, UpdateObligationConfigMode,
};

pub fn process(
    ctx: Context<UpdateObligationConfig>,
    mode: UpdateObligationConfigMode,
    value: &[u8],
) -> Result<()> {
    let mut obligation = ctx.accounts.obligation.load_mut()?;
    let market = ctx.accounts.lending_market.load()?;
    lending_operations::update_obligation_config(
        &mut obligation,
        &market,
        ObligationConfigUpdateSubject::resolve(
            ctx.accounts
                .deposit_reserve
                .as_ref()
                .map(|loader| loader.key()),
            ctx.accounts
                .borrow_reserve
                .as_ref()
                .map(|loader| loader.key()),
        )?,
        mode,
        value,
    )?;
    Ok(())
}

#[derive(Accounts)]
pub struct UpdateObligationConfig<'info> {
    /// Obligation's owner (signer - only the owner can modify the obligation's configuration).
    pub owner: Signer<'info>,

    /// The obligation to update.
    #[account(mut, has_one = lending_market, has_one = owner)]
    pub obligation: AccountLoader<'info, Obligation>,

    /// The reserve of a selected one among the [Obligation::borrows].
    ///
    /// Required only if the config update affects a single borrow (for validating its new config).
    #[account(has_one = lending_market)]
    pub borrow_reserve: Option<AccountLoader<'info, Reserve>>,

    /// The reserve of a selected one among the [Obligation::deposits].
    ///
    /// Required only if the config update affects a single deposit (for validating its new config).
    #[account(has_one = lending_market)]
    pub deposit_reserve: Option<AccountLoader<'info, Reserve>>,

    /// The lending market (for validating the obligation's new config).
    pub lending_market: AccountLoader<'info, LendingMarket>,
}

use anchor_lang::{prelude::*, Accounts};
use anchor_spl::{
    associated_token::AssociatedToken,
    token::Token,
    token_interface::{self, Mint, TokenAccount, TokenInterface},
};
use solana_program::{
    system_program,
    sysvar::{instructions::Instructions as SysInstructions, SysvarId},
};

use crate::{
    gen_signer_seeds,
    lending_market::{kvault_ixs, lending_checks, lending_operations},
    state::{LendingMarket, Reserve},
    utils::{
        accounts::{create_ata, has_ata_address},
        constraints, seeds, token_transfer,
    },
    withdraw_ticket::{ProgressCallbackType, WithdrawTicket},
    LendingAction, LendingError, TicketedWithdrawResult,
};

pub fn process(ctx: Context<WithdrawQueuedLiquidity>) -> Result<bool> {
    lending_checks::withdraw_queued_liquidity_checks(ctx.accounts)?;

    let lending_market = ctx.accounts.lending_market.load()?;
    let mut reserve = ctx.accounts.reserve.load_mut()?;

    require!(
        lending_market.is_withdraw_ticket_redemption_enabled(),
        LendingError::WithdrawTicketRedemptionDisabled,
    );

    let withdraw_ticket = ctx.accounts.withdraw_ticket.load()?; // initially borrow just for reading

    // Since users can cancel their tickets, we need to handle potential tombstones:
    if withdraw_ticket.queued_collateral_amount == 0 {
        // Note: in theory, the happy-path could handle the "0 ctokens ticket" just fine (i.e. do
        // some no-op accounting and then close the ticket). However, we prefer to avoid weird
        // interactions with unneeded validations (e.g. `destination_ta_validity` below does not
        // matter in the case of tombstones), and hence we handle this explicitly.
        msg!("Progressing over a cancelled ticket; closing the ticket account");
        reserve.withdraw_queue.dequeue(0, true);
        drop(withdraw_ticket); // otherwise, the `close()` below would effectively double-borrow from the RefMut
        ctx.accounts
            .withdraw_ticket
            .close(ctx.accounts.withdraw_ticket_owner.to_account_info())?;
        return Ok(true);
    }

    let destination_ta_validity = DestinationTokenAccountValidity::resolve(
        &ctx.accounts.user_destination_liquidity,
        &withdraw_ticket.owner,
        &ctx.accounts.reserve_liquidity_mint.to_account_info(),
        &reserve.liquidity.token_program,
    );
    drop(withdraw_ticket); // both cases below need it mutable (and would be double-borrowing if we didn't drop here)

    let require_closing_ticket = match destination_ta_validity {
        DestinationTokenAccountValidity::AtaToBeCreated => {
            msg!("User's destination liquidity ATA does not exist; creating it");
            // Funding the ATA's rent directly from a non-signer PDA is not supported by the token
            // program; hence, we let the payer create the owner's ATA...
            create_ata(
                ctx.accounts.user_destination_liquidity.to_account_info(),
                ctx.accounts.withdraw_ticket_owner.to_account_info(),
                ctx.accounts.reserve_liquidity_mint.to_account_info(),
                ctx.accounts.liquidity_token_program.to_account_info(),
                ctx.accounts.associated_token_program.to_account_info(),
                ctx.accounts.system_program.to_account_info(),
                ctx.accounts.payer.to_account_info(),
                &[], // Note: thanks to the order of the operations here, we do not need the "extra accounts to workaround the SVM's lamport-tracking bug"
            )?;
            // ... and then we reimburse him (after we learn the actual cost, including token
            // extensions). Any excess of the prepaid rent will make its way back to the ticket's
            // owner, when the ticket gets closed.
            token_transfer::destination_ata_rent_refund_transfer(
                ctx.accounts.withdraw_ticket.to_account_info(),
                ctx.accounts.payer.to_account_info(),
                ctx.accounts.user_destination_liquidity.data_len(),
            )?;
            true // now we have to require that this is the last withdraw of this ticket (we would not have funds to cover another rent if the ATA got closed again)
        }
        DestinationTokenAccountValidity::Invalid => {
            msg!("User's destination liquidity account became incompatible; marking ticket as invalid and skipping over it");
            let mut withdraw_ticket = ctx.accounts.withdraw_ticket.load_mut()?;
            withdraw_ticket.invalid = 1;
            reserve
                .withdraw_queue
                .dequeue(withdraw_ticket.queued_collateral_amount, true);
            return Ok(false);
        }
        DestinationTokenAccountValidity::Valid => {
            false // simply progress with the happy-path below, without requiring that the ticket gets closed
        }
    };

    let clock = Clock::get()?;

    // Refresh the reserve only to update the exchange rate. We do not check price freshness here:
    // the min-value is a "soft check" and can use whatever price is currently stored.
    lending_operations::refresh_reserve(
        &mut reserve,
        &clock,
        None,
        lending_market.referral_fee_bps,
        lending_market.reserve_rewards_max_apr_bps,
    )?;

    // Snapshot AFTER `refresh_reserve` so any reward distribution is accounted.
    let initial_reserve_token_balance = ctx.accounts.reserve_liquidity_supply.amount;
    let initial_reserve_available_liquidity = reserve.total_available_liquidity_amount();
    let initial_owner_queued_collateral_vault_balance =
        ctx.accounts.owner_queued_collateral_vault.amount;
    let initial_queued_collateral_amount = reserve.withdraw_queue.queued_collateral_amount;

    let mut withdraw_ticket = ctx.accounts.withdraw_ticket.load_mut()?; // we start the mut borrow for the happy-path (updating the ticket's accounting)
    let ticketed_withdraw_result = lending_operations::withdraw_queued_liquidity(
        &lending_market,
        &mut reserve,
        &mut withdraw_ticket,
        &clock,
    )?;

    // From this point on, we will not be modifying the withdraw ticket nor the reserve, so it is
    // safer to re-open them for read-only (especially since they become inputs to the potential
    // callback CPI):
    drop(withdraw_ticket);
    drop(reserve);
    let withdraw_ticket = ctx.accounts.withdraw_ticket.load()?;
    let reserve = ctx.accounts.reserve.load()?;

    let TicketedWithdrawResult {
        collateral_amount_to_burn,
        liquidity_amount_to_withdraw,
    } = ticketed_withdraw_result;
    msg!(
        "pnl: withdrawing queued liquidity {} and burning collateral {}",
        liquidity_amount_to_withdraw,
        collateral_amount_to_burn
    );

    token_transfer::withdraw_and_redeem_reserve_collateral_transfer(
        ctx.accounts.collateral_token_program.to_account_info(),
        ctx.accounts.liquidity_token_program.to_account_info(),
        ctx.accounts.reserve_liquidity_mint.to_account_info(),
        ctx.accounts.reserve_collateral_mint.to_account_info(),
        ctx.accounts.owner_queued_collateral_vault.to_account_info(),
        ctx.accounts.reserve_liquidity_supply.to_account_info(),
        ctx.accounts.user_destination_liquidity.clone(),
        ctx.accounts.lending_market_authority.clone(),
        gen_signer_seeds!(
            ctx.accounts.lending_market.key(),
            lending_market.bump_seed as u8
        ),
        collateral_amount_to_burn,
        liquidity_amount_to_withdraw,
        ctx.accounts.reserve_liquidity_mint.decimals,
    )?;

    match withdraw_ticket.progress_callback_type() {
        ProgressCallbackType::None => {}
        ProgressCallbackType::KlendQueueAccountingHandlerOnKvault => {
            kvault_ixs::cpi_update_klend_queue_accounting(
                &ctx,
                withdraw_ticket.sequence_number,
                ticketed_withdraw_result,
            )?;
        }
    }

    lending_checks::post_transfer_vault_balance_liquidity_reserve_checks(
        token_interface::accessor::amount(
            &ctx.accounts.reserve_liquidity_supply.to_account_info(),
        )?,
        reserve.total_available_liquidity_amount(),
        initial_reserve_token_balance,
        initial_reserve_available_liquidity,
        LendingAction::Subtractive(liquidity_amount_to_withdraw),
    )?;
    lending_checks::post_transfer_owner_queued_collateral_vault_balance_checks(
        token_interface::accessor::amount(
            &ctx.accounts.owner_queued_collateral_vault.to_account_info(),
        )?,
        reserve.withdraw_queue.queued_collateral_amount,
        initial_owner_queued_collateral_vault_balance,
        initial_queued_collateral_amount,
        LendingAction::Subtractive(collateral_amount_to_burn),
    )?;

    if withdraw_ticket.queued_collateral_amount == 0 {
        msg!("Redeemed entire ticket collateral; closing the ticket account");
        drop(withdraw_ticket); // otherwise, the `close()` below would effectively double-borrow from the RefMut
        ctx.accounts
            .withdraw_ticket
            .close(ctx.accounts.withdraw_ticket_owner.to_account_info())?;
    } else {
        msg!(
            "Ticket's remaining queued collateral: {}",
            withdraw_ticket.queued_collateral_amount
        );
        if require_closing_ticket {
            msg!("Cannot spend the ticket's prepaid rent for destination ATA without closing the ticket itself");
            return err!(LendingError::WithdrawTicketRequiresFullRedemption);
        }
    }

    Ok(true)
}

enum DestinationTokenAccountValidity {
    Valid,
    Invalid,
    AtaToBeCreated,
}

impl DestinationTokenAccountValidity {
    pub fn resolve(
        account: &AccountInfo,
        owner: &Pubkey,
        mint: &AccountInfo,
        token_program: &Pubkey,
    ) -> Self {
        let is_system_owned = account.owner == &system_program::ID;
        let is_token_program_owned = account.owner == token_program;

        if !is_system_owned && !is_token_program_owned {
            return Self::Invalid; // if an account does not belong to system (i.e. uninitialized / closed) or to the right program (i.e. not a token account), then it has no way to be valid or permissionlessly created
        }

        // We allow the token account to not exist (i.e. the `AtaToBeCreated` case), so we first check the extensions on the mint alone:
        if constraints::token_2022::check_only_supported_extensions_on_liquidity_mint(mint).is_err()
        {
            return Self::Invalid; // in most handlers, this is a pre-check which can fail a tx; however, here it would break the liveness of the queue, so we must only mark the ticket as invalid instead
        }

        if account.data_is_empty() {
            // Account does not exist...
            return if has_ata_address(account, owner, mint.key, token_program) {
                // ...and can be created permissionlessly...

                if constraints::token_2022::check_default_account_state_initialized(mint).is_err() {
                    return Self::Invalid; // ... but here we cannot allow the newly-created ATAs to be e.g. frozen (even though we do support this extension in general)
                }

                Self::AtaToBeCreated // ... otherwise, we can just create that ATA
            } else {
                Self::Invalid // ...and can only be created by the owner
            };
        }

        if is_system_owned {
            return Self::Invalid; // at this point we know that it is some other, actually-existing system account
        }

        let Ok(token_account) = TokenAccount::try_deserialize(&mut account.data.borrow().as_ref())
        else {
            return Self::Invalid; // not a token account
        };

        if &token_account.owner != owner || &token_account.mint != mint.key {
            return Self::Invalid; // the owner and mint must match the expected (stored) values
        }

        // We also need to repeat the Anchor constraints regarding the accounts properties (i.e.
        // delegate and frozen state) enforced on enqueue - see the rationale in the comment there.
        if token_account.delegate.is_some() || token_account.is_frozen() {
            return Self::Invalid;
        }

        // The extensions on the mint were already checked above; here we know that token account itself exists too, so we check it:
        if constraints::token_2022::check_only_supported_extensions_on_liquidity_ta(account)
            .is_err()
        {
            return Self::Invalid; // in most handlers, this is a pre-check which can fail a tx; however, here it would break the liveness of the queue, so we must only mark the ticket as invalid instead
        }

        Self::Valid
    }
}

#[derive(Accounts)]
pub struct WithdrawQueuedLiquidity<'info> {
    /// The executor of the permissionless tx (not necessarily the ticket owner).
    // Note: `mut` is only needed for (potentially) closing the [Self::withdraw_ticket].
    #[account(mut)]
    pub payer: Signer<'info>,

    /// The lending market.
    pub lending_market: AccountLoader<'info, LendingMarket>,

    /// The market's authority, needed for burning the collateral (from
    /// [Self::owner_queued_collateral_vault]) and transferring the liquidity (from
    /// [Self::reserve_liquidity_supply]).
    #[account(
        seeds = [seeds::LENDING_MARKET_AUTH, lending_market.key().as_ref()],
        bump = lending_market.load()?.bump_seed as u8,
    )]
    pub lending_market_authority: AccountInfo<'info>,

    /// The reserve.
    #[account(mut,
        has_one = lending_market
    )]
    pub reserve: AccountLoader<'info, Reserve>,

    /// The liquidity mint, needed to invoke the transfer.
    #[account(
        address = reserve.load()?.liquidity.mint_pubkey,
        mint::token_program = liquidity_token_program,
    )]
    pub reserve_liquidity_mint: Box<InterfaceAccount<'info, Mint>>,

    /// The collateral mint, needed to burn (`mut`!) the queued collateral.
    #[account(mut,
        address = reserve.load()?.collateral.mint_pubkey,
        mint::token_program = collateral_token_program,
    )]
    pub reserve_collateral_mint: Box<InterfaceAccount<'info, Mint>>,

    /// The liquidity supply vault (to withdraw the liquidity from).
    #[account(mut,
        address = reserve.load()?.liquidity.supply_vault,
    )]
    pub reserve_liquidity_supply: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The per-owner "this reserve's queued collateral" vault (from which the collateral will be
    /// burnt).
    #[account(mut,
        seeds = [seeds::OWNER_QUEUED_COLLATERAL_VAULT, reserve.key().as_ref(), withdraw_ticket.load()?.owner.as_ref()],
        bump,
        token::mint = reserve_collateral_mint,
        token::authority = lending_market_authority,
    )]
    pub owner_queued_collateral_vault: Box<InterfaceAccount<'info, TokenAccount>>,

    /// The token account to which the liquidity should be transferred (the one recorded in the
    /// ticket).
    // Note: normally, we would use a `Box<InterfaceAccount<'info, TokenAccount>>` type here, with
    // additional TokenAccount-related anchor constraints:
    // - `token::mint = reserve_liquidity_mint`,
    // - `token::authority = withdraw_ticket.load()?.owner`.
    // However, we do *not* want to fail the tx in a situation where the user e.g. closes or
    // repurposes his TokenAccount - instead, we want to *successfully* mark the ticket as invalid
    // (we only fail the tx in case of a closed ATA, since this can be fixed permissionlessly).
    // Hence, we are deliberately using the generic `AccountInfo<'info>` type, and we implement
    // these checks manually (allowing them to drive the logic).
    #[account(mut,
        address = withdraw_ticket.load()?.user_destination_liquidity_ta,
    )]
    pub user_destination_liquidity: AccountInfo<'info>,

    /// The program of [Self::reserve_collateral_mint], needed for transfer.
    pub collateral_token_program: Program<'info, Token>,

    /// The program of [Self::reserve_liquidity_mint], needed for transfer.
    pub liquidity_token_program: Interface<'info, TokenInterface>,

    /// The ticket's data itself.
    ///
    /// Note: in case of complete withdrawal, this account will be closed. In case of partial
    /// withdrawal, its [WithdrawTicket::queued_collateral_amount] will simply be reduced, and the
    /// ticket will maintain its position in the queue.
    #[account(mut,
        seeds = [seeds::WITHDRAW_TICKET, reserve.key().as_ref(), &reserve.load()?.withdraw_queue.next_withdrawable_ticket_sequence_number.to_le_bytes()],
        bump,
        has_one = reserve,
        constraint = withdraw_ticket.load()?.is_valid() @ LendingError::WithdrawTicketInvalid, // Note: not occurring in practice (and not possible to see in integration tests: the seeds are checked first, and they won't match after the queue progresses over the ticket marked as invalid)
    )]
    pub withdraw_ticket: AccountLoader<'info, WithdrawTicket>,

    /// The owner of the [Self::withdraw_ticket]; needed only to return the rent of the
    /// [WithdrawTicket] account (if it is getting fully-consumed and closed here).
    #[account(mut,
        address = withdraw_ticket.load()?.owner,
    )]
    pub withdraw_ticket_owner: AccountInfo<'info>,

    /// The ATA program - needed for potential destination ATA creation.
    pub associated_token_program: Program<'info, AssociatedToken>,

    /// The System program - needed for potential destination ATA creation.
    pub system_program: Program<'info, System>,

    /// The progress callback program (if configured by the withdraw ticket).
    #[account(address = withdraw_ticket.load()?.progress_callback_type().program_address())]
    pub progress_callback_program: Option<AccountInfo<'info>>,

    /// The first one out of maximum 2 custom accounts that may be required if the withdraw ticket
    /// defines a callback.
    /// Please note that the constraints defined here do not mention `mut`, but a specific
    /// [WithdrawTicket::progress_callback_type] may require it.
    #[account(address = withdraw_ticket.load()?.progress_callback_custom_accounts[0])]
    pub progress_callback_custom_account_0: Option<AccountInfo<'info>>,

    /// The second possibly-required account (see the `progress_callback_custom_account_0` above).
    #[account(address = withdraw_ticket.load()?.progress_callback_custom_accounts[1])]
    pub progress_callback_custom_account_1: Option<AccountInfo<'info>>,

    /// CHECK: Sysvar Instruction allowing introspection, fixed address
    #[account(address = SysInstructions::id())]
    pub instruction_sysvar_account: AccountInfo<'info>,
}

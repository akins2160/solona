use anchor_lang::prelude::*;

use crate::utils::{prices::utils::ten_pow, Fraction, U256};

/// `Price` is a representation of a price in integer + exponent format.
///
/// ## Example of price representation:
///
/// - as integer: 6462236900000, exponent: 8
/// - as float:   64622.36900000
#[derive(Clone, Copy, Debug, AnchorDeserialize, AnchorSerialize, Default)]
pub(crate) struct Price<T>
where
    T: Into<U256>,
{
    /// Scaled integer by 10^exp
    pub value: T,

    // Exponent represents the number of decimals of the price
    pub exp: u32,
}

impl<T> Price<T>
where
    T: Into<U256> + Copy + TryFrom<U256>,
{
    /// Adjust exponent to the given target to a new variable.
    ///
    /// Returns a new `Price` with the same value but with the given exponent.
    /// Returns `None` if the operation would overflow.
    /// If `target_exp < exp`, this is a lossy operation.
    pub fn to_adjusted_exp(self, target_exp: u32) -> Option<Price<T>> {
        if target_exp == self.exp {
            return Some(self);
        }
        let value: U256 = self.value.into();
        let exp = self.exp;

        let value_256 = if exp > target_exp {
            // Can't overflow/underflow thanks to the check above
            let diff = exp - target_exp;
            let factor = ten_pow(diff).into();
            value.checked_div(factor)
        } else {
            // Can't overflow/underflow thanks to the check above
            let diff = target_exp - exp;
            let factor = ten_pow(diff).into();
            value.checked_mul(factor)
        };

        value_256.and_then(|value| {
            Some(Price {
                value: T::try_from(value).ok()?,
                exp: target_exp,
            })
        })
    }

    /// Reduce the number exponent to the given target.
    /// Does nothing if the current exponent is already lower than the target.
    ///
    /// Returns `None` if the operation would overflow.
    pub fn reduce_exp_lossy(self, target_exp: u32) -> Option<Price<T>> {
        if self.exp <= target_exp {
            return Some(self);
        }
        self.to_adjusted_exp(target_exp)
    }
}

impl<T> Price<T>
where
    T: Into<U256> + Copy,
{
    pub fn size_up<U>(self) -> Price<U>
    where
        U: From<T> + Into<U256>,
    {
        let Price { value, exp } = self;
        Price {
            value: U::from(value),
            exp,
        }
    }
}

pub struct TimestampedPrice {
    pub price_load: Box<dyn FnOnce() -> Result<Fraction>>,
    pub timestamp: u64,
}

pub struct TimestampedPriceWithTwap {
    pub price: TimestampedPrice,
    pub twap: Option<TimestampedPrice>,
}

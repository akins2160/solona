use anchor_lang::{prelude::error, require, require_eq, Key, Result, ToAccountInfo};
use anchor_spl::associated_token::get_associated_token_address_with_program_id;
use solana_program::{
    account_info::AccountInfo, instruction::AccountMeta, program, pubkey::Pubkey,
    system_instruction,
};
use spl_associated_token_account::instruction::create_associated_token_account;

use crate::LendingError;

#[allow(clippy::derivable_impls)] // This type is created by Anchor macros and it can't derive default
impl Default for crate::accounts::OptionalObligationFarmsAccounts {
    fn default() -> Self {
        Self {
            obligation_farm_user_state: None,
            reserve_farm_state: None,
        }
    }
}

impl Clone for crate::accounts::OptionalObligationFarmsAccounts {
    fn clone(&self) -> Self {
        *self
    }
}

impl Copy for crate::accounts::OptionalObligationFarmsAccounts {}

pub fn default_array<T: Default + Copy, const N: usize>() -> [T; N] {
    [T::default(); N]
}

pub fn filled_array<T: Copy, const N: usize>(fill: T) -> [T; N] {
    [fill; N]
}

/// Returns whether the `array == default_array()`.
///
/// Note: this function exists, because the syntax above does not actually compile without awkwardly
/// specifying the type parameters. It also is more performant (at least in theory: avoids
/// allocation).
pub fn is_default_array<T: Default + PartialEq>(array: &[T]) -> bool {
    let default_value = T::default();
    array.iter().all(|element| *element == default_value)
}

/// Returns whether the given account has an address matching the ATA of the given properties.
pub fn has_ata_address(
    account: &impl Key,
    owner: &Pubkey,
    mint: &Pubkey,
    token_program: &Pubkey,
) -> bool {
    account.key() == get_associated_token_address_with_program_id(owner, mint, token_program)
}

/// Creates an ATA according to the specification.
#[allow(clippy::too_many_arguments)]
pub fn create_ata<'a>(
    account: AccountInfo<'a>,
    owner: AccountInfo<'a>,
    mint: AccountInfo<'a>,
    token_program: AccountInfo<'a>,
    associated_token_program: AccountInfo<'a>,
    system_program: AccountInfo<'a>,
    payer: AccountInfo<'a>,
    remaining_accounts: &[AccountInfo<'a>],
) -> Result<()> {
    // Anchor note: we need to manually build the ix here, since Anchor provides the
    // `associated_token::create()` helper, but it silently ignores (!) the passed
    // `remaining_accounts`.
    // SVM note: The `remaining_accounts` mentioned above are needed to workaround the SVM's bug
    // manifesting as `panic!("sum of account balances before and after instruction do not match")`.
    // The array needs to include all other accounts which changed their lamports balance during
    // previous CPIs within the ix.
    let mut ix = create_associated_token_account(payer.key, owner.key, mint.key, token_program.key);
    ix.accounts.extend(
        remaining_accounts
            .iter()
            .map(|account| AccountMeta::new_readonly(account.key(), false)),
    );
    let mut account_infos = vec![
        payer,
        account,
        associated_token_program,
        owner,
        mint,
        system_program,
        token_program,
    ];
    account_infos.extend_from_slice(remaining_accounts);
    solana_program::program::invoke(&ix, &account_infos)?;
    Ok(())
}

pub fn create_pda_account<'info>(
    system_program: AccountInfo<'info>,
    payer: AccountInfo<'info>,
    account: AccountInfo<'info>,
    program_id: &Pubkey,
    minimum_lamports: u64,
    space: u64,
    signers_seeds: &[&[&[u8]]],
) -> Result<()> {
    require!(
        account.owner == &system_program.key(),
        LendingError::InvalidAccountOwner
    );

    let current_lamports = account.lamports();

    if current_lamports > 0 {
        // If there is already a balance, `create_account` fails.
        // We can either do `transfer`, `assign` and `allocate` manually
        // or just clear out the account before proceeding.
        program::invoke_signed(
            &system_instruction::transfer(account.key, payer.key, current_lamports),
            &[account.clone(), payer.clone()],
            signers_seeds,
        )?;
    }

    let lamports_post_transfer = account.lamports();

    require_eq!(lamports_post_transfer, 0);

    // If there was already a balance, we want to send the minimum lamports. If there
    // was no balance (or below minimum_lamports), we just want the lamports to be minimum_lamports.

    // create account
    program::invoke_signed(
        &system_instruction::create_account(
            payer.key,        // Payer (funds the account)
            account.key,      // PDA to create
            minimum_lamports, // Lamports for rent exemption
            space,            // Space to allocate
            program_id,       // Owner (program)
        ),
        &[payer.to_account_info(), account],
        signers_seeds,
    )
    .map_err(Into::into)
}

pub mod account_loader_trait;
pub mod account_ops;
pub mod accounts;
pub mod borrow_rate_curve;
pub mod constraints;
pub mod consts;
pub mod emit_cpi_support;
pub mod fraction;
pub mod macros;
pub mod permissioning;
pub mod prices;
pub mod refresh_ix_utils;
pub mod secs;
pub mod seeds;
pub mod spltoken;
pub mod token_transfer;
pub mod validation;

use std::sync::Arc;

pub use account_loader_trait::*;
pub use account_ops::*;
use anchor_lang::prelude::Pubkey;
pub use constraints::*;
pub use consts::*;
pub use emit_cpi_support::*;
pub use fraction::*;
pub use prices::*;
pub use refresh_ix_utils::*;
pub use spltoken::*;
pub use token_transfer::*;
pub use validation::*;

pub fn maybe_null_pk(pubkey: Pubkey) -> Option<Pubkey> {
    if pubkey == Pubkey::default() || pubkey == NULL_PUBKEY {
        None
    } else {
        Some(pubkey)
    }
}

/// Anything capable of returning a reference to some owned/borrowed/referred/locked value.
///
/// This trait is an answer to deficiencies of the standard `AsRef/Deref/Borrow` traits. Feel free
/// to implement it for whatever general "containers" you wish.
///
/// The intended usage in function signatures looks like this:
/// `fn do_something(subject: impl JustRef<MyStruct>)`
///
/// (and now, you can call it with `MyStruct, &MyStruct, Arc<MyStruct>, &Arc<MyStruct>, ...`)
pub trait JustRef<T> {
    /// Returns the reference to the contained value.
    fn just_ref(&self) -> &T;
}

impl<T> JustRef<T> for T {
    fn just_ref(&self) -> &T {
        self
    }
}

impl<T> JustRef<T> for &T {
    fn just_ref(&self) -> &T {
        self
    }
}

impl<T> JustRef<T> for Arc<T> {
    fn just_ref(&self) -> &T {
        self
    }
}

impl<T> JustRef<T> for &Arc<T> {
    fn just_ref(&self) -> &T {
        self
    }
}

pub fn borsh_deserialize<T: borsh::BorshDeserialize>(mut data: &[u8]) -> T {
    T::deserialize(&mut data).expect("Borsh deserialization failed")
}

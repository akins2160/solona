#[macro_export]
macro_rules! gen_signer_seeds {
    (
    $key: expr, $bump: expr
) => {
        &[
            $crate::utils::seeds::LENDING_MARKET_AUTH as &[u8],
            $key.as_ref(),
            &[$bump],
        ]
    };
}

#[macro_export]
macro_rules! gen_reserve_token_account_signer_seeds {
    ($seeds_tag: expr, $reserve_key: expr, $bump: expr) => {
        &[$seeds_tag.as_ref(), $reserve_key.as_ref(), &[$bump]]
    };
}

#[macro_export]
macro_rules! try_block {
    ($($expr:expr)*) => {
        match $($expr)* {
            Ok(val) => val,
            Err(err) => {
                use $crate::LendingError;
                use ::anchor_lang::error;
                return $($expr)*.map_err(|_| error!(LendingError::MathOverflow));
            }
        }
    };
}

#[macro_export]
macro_rules! check_cpi {
    ($ctx:expr) => {{
        $crate::utils::check_cpi_call(&$ctx.accounts.instruction_sysvar_account)?;
    }};
}

#[macro_export]
macro_rules! check_refresh_ixs {
    ($ctx_accounts:expr, $reserve:expr, $mode:expr $(,)?) => {{
        let _reserve = $reserve.load()?;
        $crate::utils::check_refresh(
            &$ctx_accounts.instruction_sysvar_account,
            &[($reserve.key(), &_reserve)],
            &$ctx_accounts.obligation.to_account_info().key(),
            &[$mode],
        )?;
    }};
    ($ctx_accounts:expr, $reserve_one:expr, $reserve_two:expr, $mode_one:expr, $mode_two:expr $(,)?) => {{
        let _reserve_one = $reserve_one.load()?;
        let _reserve_two = $reserve_two.load()?;

        if $reserve_one.key() == $reserve_two.key() {
            $crate::utils::check_refresh(
                &$ctx_accounts.instruction_sysvar_account,
                &[
                    ($reserve_one.key(), &_reserve_one),
                    ($reserve_one.key(), &_reserve_one),
                ],
                &$ctx_accounts.obligation.to_account_info().key(),
                &[$mode_one, $mode_two],
            )?;
        } else {
            $crate::utils::check_refresh(
                &$ctx_accounts.instruction_sysvar_account,
                &[
                    ($reserve_one.key(), &_reserve_one),
                    ($reserve_two.key(), &_reserve_two),
                ],
                &$ctx_accounts.obligation.to_account_info().key(),
                &[$mode_one, $mode_two],
            )?;
        }
    }};
}

#[macro_export]
macro_rules! refresh_farms {
    ($ctx_accounts:expr, [$(,)?]$(,)?) => {};
    ($ctx_accounts:expr, $lending_market_authority:expr, [$(,)?]$(,)?) => {};
    ($ctx_accounts:expr, [$($tail:tt)*]$(,)?) => {
        refresh_farms!($ctx_accounts, $ctx_accounts.lending_market_authority, [$($tail)*]);
    };
    ($ctx_accounts:expr, $lending_market_authority:expr, [$(,)?($reserve:expr, $farm_accounts:expr, $mode:ident$(,)?) $($tail:tt)*]$(,)?) => {{
        $crate::utils::cpi_refresh_farms::refresh_obligation_farms_for_reserve(
            $crate::utils::cpi_refresh_farms::RefreshFarmsParams {
                reserve: &$reserve,
                farms_accounts: &$farm_accounts,
                farm_kind: ReserveFarmKind::$mode,
            },
            &$ctx_accounts.obligation,
            &$lending_market_authority,
            &$ctx_accounts.lending_market,
        )?;
        refresh_farms!($ctx_accounts, $lending_market_authority, [$($tail)*]);
    }};
}

#[cfg(target_arch = "bpf")]
#[macro_export]
macro_rules! dbg_msg {
    // NOTE: We cannot use `concat!` to make a static string as a format argument
    // of `eprintln!` because `file!` could contain a `{` or
    // `$val` expression could be a block (`{ .. }`), in which case the `msg!`
    // will be malformed.
    () => {
        msg!("[{}:{}]", file!(), line!())
    };
    ($val:expr $(,)?) => {
        // Use of `match` here is intentional because it affects the lifetimes
        // of temporaries - https://stackoverflow.com/a/48732525/1063961
        match $val {
            tmp => {
                msg!("[{}:{}] {} = {:#?}",
                    file!(), line!(), stringify!($val), &tmp);
                tmp
            }
        }
    };
    ($($val:expr),+ $(,)?) => {
        ($($crate::dbg_msg!($val)),+,)
    };
}

#[cfg(not(target_arch = "bpf"))]
#[macro_export]
macro_rules! dbg_msg {
    // NOTE: We cannot use `concat!` to make a static string as a format argument
    // of `eprintln!` because `file!` could contain a `{` or
    // `$val` expression could be a block (`{ .. }`), in which case the `msg!`
    // will be malformed.
    () => {
        println!("[{}:{}]", file!(), line!())
    };
    ($val:expr $(,)?) => {
        // Use of `match` here is intentional because it affects the lifetimes
        // of temporaries - https://stackoverflow.com/a/48732525/1063961
        match $val {
            tmp => {
                println!("[{}:{}] {} = {:#?}",
                    file!(), line!(), stringify!($val), &tmp);
                tmp
            }
        }
    };
    ($($val:expr),+ $(,)?) => {
        ($($crate::dbg_msg!($val)),+,)
    };
}

#[cfg(target_arch = "bpf")]
#[macro_export]
macro_rules! xmsg {
    ($($arg:tt)*) => (::anchor_lang::prelude::msg!($($arg)*));
}

#[cfg(all(not(target_arch = "bpf"), not(feature = "tracing")))]
#[macro_export]
macro_rules! xmsg {
    ($($arg:tt)*) => (println!($($arg)*));
}

#[cfg(all(not(target_arch = "bpf"), feature = "tracing"))]
#[macro_export]
macro_rules! xmsg {
    ($($arg:tt)*) => (tracing::info!($($arg)*));
}

#[cfg(not(target_arch = "bpf"))]
#[macro_export]
macro_rules! cu_log {
    () => {};
}

#[cfg(target_arch = "bpf")]
#[macro_export]
macro_rules! cu_log {
    () => {
        ::anchor_lang::solana_program::log::sol_log(concat!("CU at: ", file!(), ":", line!()));
        ::anchor_lang::solana_program::log::sol_log_compute_units();
    };
}

#[macro_export]
macro_rules! assert_fuzzy_eq_f {
    ($actual:expr, $expected:expr, $epsilon:expr) => {
        let eps = $epsilon as Fraction;
        let act = $actual as Fraction;
        let exp = $expected as Fraction;
        let diff = if act > exp { act - exp } else { exp - act };
        if diff > eps {
            panic!(
                "Actual {} Expected {} diff {} Epsilon {}",
                $actual, $expected, diff, eps
            );
        }
    };
}

#[macro_export]
macro_rules! assert_fuzzy_eq {
    ($actual:expr, $expected:expr, $epsilon:expr) => {
        let eps = $epsilon as i128;
        let act = $actual as i128;
        let exp = $expected as i128;
        let diff = (act - exp).abs();
        if diff > eps {
            panic!(
                "Actual {} Expected {} diff {} Epsilon {}",
                $actual, $expected, diff, eps
            );
        }
    };

    ($actual:expr, $expected:expr, $epsilon:expr, $type:ty) => {
        let eps = $epsilon as $type;
        let act = $actual as $type;
        let exp = $expected as $type;
        let diff = if act > exp { act - exp } else { exp - act };
        if diff > eps {
            panic!(
                "Actual {} Expected {} diff {} Epsilon {}",
                $actual, $expected, diff, eps
            );
        }
    };
}

#[macro_export]
macro_rules! assert_gt {
    ($left:expr, $right:expr) => {
        // Check if the left expression is greater than the right expression
        if !($left > $right) {
            // Panic with a message showing both values
            panic!(
                "Assertion failed: {:?} is not greater than {:?}",
                $left, $right
            );
        }
    };
}

#[macro_export]
macro_rules! assert_gte {
    ($left:expr, $right:expr) => {
        // Check if the left expression is greater than the right expression
        if !($left >= $right) {
            // Panic with a message showing both values
            panic!(
                "Assertion failed: {:?} is not greater than {:?}",
                $left, $right
            );
        }
    };
}

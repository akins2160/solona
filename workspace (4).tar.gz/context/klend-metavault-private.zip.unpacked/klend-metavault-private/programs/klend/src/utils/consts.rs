use anchor_lang::solana_program;
use solana_program::{pubkey, pubkey::Pubkey};

use crate::{
    utils::fraction::{fraction, Fraction},
    CollateralExchangeRate,
};

/// Number of slots per second
pub const SLOTS_PER_SECOND: u64 = 2;
/// Number of slots per hour
// 2 (slots per second) * 60 = 120
pub const SLOTS_PER_MINUTE: u64 = SLOTS_PER_SECOND * 60;
/// Number of slots per hour
// 2 (slots per second) * 60 * 60 = 7200
pub const SLOTS_PER_HOUR: u64 = SLOTS_PER_MINUTE * 60;
/// Number of slots per hour
// 2 (slots per second) * 60 * 60 * 24 = 172800
pub const SLOTS_PER_DAY: u64 = SLOTS_PER_HOUR * 24;
/// Number of slots per year
// 2 (slots per second) * 60 * 60 * 24 * 365 = 63072000
pub const SLOTS_PER_YEAR: u64 = SLOTS_PER_DAY * 365;

pub const SECONDS_PER_MINUTE: u64 = 60;
pub const SECONDS_PER_HOUR: u64 = SECONDS_PER_MINUTE * 60;
pub const SECONDS_PER_DAY: u64 = SECONDS_PER_HOUR * 24;

/// Current version of the program and all new accounts created
pub const PROGRAM_VERSION: u8 = 1;

/// 10 000 bps (100%) on `u16`
pub const FULL_BPS: u16 = 10_000;

/// Accounts are created with data zeroed out, so uninitialized state instances
/// will have the version set to 0.
pub const UNINITIALIZED_VERSION: u8 = 0;

// TODO: Look into this
/// Collateral tokens are initially valued at a ratio of 5:1 (collateral:liquidity)
// @FIXME: restore to 5
pub const INITIAL_COLLATERAL_RATIO: u64 = 1;
pub const INITIAL_COLLATERAL_RATE: CollateralExchangeRate = CollateralExchangeRate::ONE;

/// Percentage of an obligation that can be repaid during each liquidation call
pub const LIQUIDATION_CLOSE_FACTOR: u8 = 20;

/// Obligation borrow value that is small enough to close out
pub const LIQUIDATION_CLOSE_VALUE: u64 = 2;

/// Maximum quote currency value that can be liquidated in 1 liquidate_obligation call
pub const MAX_LIQUIDATABLE_VALUE_AT_ONCE: u64 = 500_000;

/// The default minimum value that can be withdrawn in a single `withdraw_queued_liquidity()` call.
pub const MIN_WITHDRAW_QUEUED_LIQUIDITY_VALUE: u64 = 2;

/// The default minimum value that can be filled in a single `fill_borrow_order()` call.
pub const MIN_BORROW_ORDER_FILL_VALUE: u64 = 2;

/// A marker value for `autodeleverage_target_ltv_pct` to be used for unmarking of an obligation.
pub const NO_DELEVERAGING_MARKER: u8 = u8::MAX;

/// Max number of collateral and liquidity reserve accounts combined for an obligation
pub const MAX_OBLIGATION_RESERVES: u64 = 20;

/// Min. user LTV where close factor becomes 100% and liquidator can liquidate the entire loan
pub const CLOSE_TO_INSOLVENCY_RISKY_LTV: u8 = 95;

/// Absolute minimum deposit amount at creation of a reserve (cannot be set lower in market config)
pub const MIN_INITIAL_DEPOSIT_AMOUNT: u64 = 1000;

/// Default minimum deposit amount at creation of a reserve
pub const DEFAULT_MIN_DEPOSIT_AMOUNT: u64 = 100_000;

/// Canonical null pubkey. Prints out as "nu11111111111111111111111111111111111111111"
pub const NULL_PUBKEY: solana_program::pubkey::Pubkey =
    solana_program::pubkey::Pubkey::new_from_array([
        11, 193, 238, 216, 208, 116, 241, 195, 55, 212, 76, 22, 75, 202, 40, 216, 76, 206, 27, 169,
        138, 64, 177, 28, 19, 90, 156, 0, 0, 0, 0, 0,
    ]);

// Accounts size
pub const LENDING_MARKET_SIZE: usize = 4656;
pub const RESERVE_SIZE: usize = 8616;
pub const OBLIGATION_SIZE: usize = 3336;
pub const RESERVE_CONFIG_SIZE: usize = 944;
pub const REFERRER_TOKEN_STATE_SIZE: usize = 352;
pub const USER_METADATA_SIZE: usize = 1024;
pub const REFERRER_STATE_SIZE: usize = 64;
pub const SHORT_URL_SIZE: usize = 68; // 32 + 4 + string_length (32 max)
pub const TOKEN_INFO_SIZE: usize = 384;
pub const GLOBAL_CONFIG_SIZE: usize = 1024;
pub const WITHDRAW_TICKET_SIZE: usize = 512;

/// A maximum size of a [TokenAccount] (considering token-2022 extensions) that we want to be ready for.
///
/// Calculation details:
/// A naive sum of sizes of all currently-existing extensions applicable at token account level is: 165 (Base)
/// + 383 (Confidential) + 72 (Group) + 12 (Fee) + 5 (CPI) + 5 (Memo) + 4 (Immutable) + 4 (NonTransferable) = 650 bytes
/// (in practice, some of the extensions are mutually-exclusive, and the maximum valid subset's size seems to be 629
/// bytes). We should also have some buffer for potential future extensions (or for mistakes in this research).
pub const MAX_TOKEN_ACCOUNT_DATA_LEN: usize = 1000;

/// Global allowed borrow value max for an obligation, market wide
pub const GLOBAL_ALLOWED_BORROW_VALUE: u64 = 45_000_000;

/// Borrow factor default value in percentage
pub const DEFAULT_BORROW_FACTOR_PCT: u64 = 100;

// The default elevation group for all reserves (nulled out for all values)
pub const ELEVATION_GROUP_NONE: u8 = 0;

// Max number of elevation groups in the lending market
pub const MAX_NUM_ELEVATION_GROUPS: u8 = 32;

/// Decimals of the value of the quote currency (USD)
pub const USD_DECIMALS: u32 = 6;

/// Obligation min deposited/borrowed value accepted after an action
/// 0.000001 usd
pub const MIN_NET_VALUE_IN_OBLIGATION: Fraction = fraction!(0.000001);

// 1 lamport dust threshold
pub const DUST_LAMPORT_THRESHOLD: u64 = 1;

/// Maximum number of decimals supported in a price on U256 bits
pub const MAX_PRICE_DECIMALS_U256: u32 = 36;

/// Target number of decimals for a price in a scope chain
pub const TARGET_PRICE_DECIMALS: u32 = MAX_PRICE_DECIMALS_U256 / 2;

pub fn ten_pow(x: usize) -> u64 {
    // Precomputed values of 10^x for x in [0, 10]
    const POWERS_OF_TEN: [u64; 20] = [
        1,
        10,
        100,
        1_000,
        10_000,
        100_000,
        1_000_000,
        10_000_000,
        100_000_000,
        1_000_000_000,
        10_000_000_000,
        100_000_000_000,
        1_000_000_000_000,
        10_000_000_000_000,
        100_000_000_000_000,
        1_000_000_000_000_000,
        10_000_000_000_000_000,
        100_000_000_000_000_000,
        1_000_000_000_000_000_000,
        10_000_000_000_000_000_000,
    ];

    // Validate that x is in the range [0, 19]
    if x > 19 {
        panic!("The exponent must be between 0 and 19.");
    }

    // Simply return the precomputed value
    POWERS_OF_TEN[x]
}

pub const SQUADS_PROGRAM_ID_V3_MAINNET_PROD: Pubkey =
    pubkey!("SMPLecH534NA9acpos4G6x7uf3LWbCAwZQE9e8ZekMu");

pub const SQUADS_PROGRAM_ID_V3_MAINNET_DEV: Pubkey =
    pubkey!("84Ue9gKQUsStFJQCNQpsqvbceo7fKYSSCCMXxMZ5PkiW");

pub const SQUADS_PROGRAM_ID_V4_MAINNET_PROD: Pubkey =
    pubkey!("SQDS4ep65T869zMMBKyuUq6aD6EgTu8psMjkvj52pCf");

pub const SQUADS_PROGRAM_ID_V4_MAINNET_DEV: Pubkey =
    pubkey!("STAG3xkFMyVK3sRtQhipsKuLpRGbgospDpVdNyJqDpS");

pub const FLEX_LEND_ID_MAINNET_PROD: Pubkey =
    pubkey!("FL3X2pRsQ9zHENpZSKDRREtccwJuei8yg9fwDu9UN69Q");

pub const KAMINO_VAULT_STAGING: Pubkey = pubkey!("STkvh7ostar39Fwr4uZKASs1RNNuYMFMTsE77FiRsL2");

pub const KAMINO_VAULT_MAINNET: Pubkey = pubkey!("KvauGMspG5k6rtzrqqn7WNn3oZdyKqLKwK2XWQ8FLjd");

#[cfg(feature = "staging")]
pub const CORRESPONDING_KAMINO_VAULT_PROGRAM_ID: Pubkey = KAMINO_VAULT_STAGING;

#[cfg(not(feature = "staging"))]
pub const CORRESPONDING_KAMINO_VAULT_PROGRAM_ID: Pubkey = KAMINO_VAULT_MAINNET;

/// A captured value of the kvault's `VaultState::DISCRIMINATOR`.
pub const VAULT_STATE_DISCRIMINATOR: &[u8] = &[228, 196, 82, 165, 98, 210, 235, 152];

/// A captured value of the kvault's `UpdateKlendQueueAccounting::DISCRIMINATOR`.
pub const UPDATE_KLEND_QUEUE_ACCOUNTING_DISCRIMINATOR: [u8; 8] =
    [45, 84, 96, 103, 171, 196, 40, 129];

pub const DEFI_CARROT_ID_MAINNET: Pubkey = pubkey!("CarrotwivhMpDnm27EHmRLeQ683Z1PufuqEmBZvD282s");

pub const METEORA_DYNAMIC_POOL_ID_MAINNET: Pubkey =
    pubkey!("24Uqj9JCLxUeoC3hGfh5W3s9FM9uCHDS2SG3LYwBpyTi");

pub const SANDGLASS_ID_MAINNET: Pubkey = pubkey!("SANDsy8SBzwUE8Zio2mrYZYqL52Phr2WQb9DDKuXMVK");

pub const BESTLEND_ID_MAINNET: Pubkey = pubkey!("bestdGyQeo7mgaSRNgEYdtjhsryNbP8jgg1Y9qoFbk7");

pub const DIVVY_ID_MAINNET: Pubkey = pubkey!("dvyFwAPniptQNb1ey4eM12L8iLHrzdiDsPPDndd6xAR");

pub const EXPONENT_INTEGRATION_ID_MAINNET: Pubkey =
    pubkey!("XPK1ndTK1xrgRg99ifvdPP1exrx8D1mRXTuxBkkroCx");

pub const EXPONENT_CORE_ID_MAINNET: Pubkey =
    pubkey!("ExponentnaRg3CQbW6dqQNZKXp7gtZ9DGMp1cwC4HAS7");

pub const AGRO_ID_MAINNET: Pubkey = pubkey!("AgroFiE3bX7j4Tvfa7YAoFLqjjb35Bw6eed5BuYukPEn");
pub const AGRO_STAGING_ID_MAINNET: Pubkey = pubkey!("E7jPY6J5s2uAxAjJQX5tqoASkmFr6TYxVoMm97hPLNZ1");

pub const CPI_WHITELISTED_ACCOUNTS: [CpiWhitelistedAccount; 16] = [
    CpiWhitelistedAccount::new(FLEX_LEND_ID_MAINNET_PROD, 1),
    CpiWhitelistedAccount::new(SQUADS_PROGRAM_ID_V3_MAINNET_PROD, 1),
    CpiWhitelistedAccount::new(SQUADS_PROGRAM_ID_V3_MAINNET_DEV, 1),
    CpiWhitelistedAccount::new(SQUADS_PROGRAM_ID_V4_MAINNET_PROD, 1),
    CpiWhitelistedAccount::new(SQUADS_PROGRAM_ID_V4_MAINNET_DEV, 1),
    CpiWhitelistedAccount::new(METEORA_DYNAMIC_POOL_ID_MAINNET, 1),
    CpiWhitelistedAccount::new(DEFI_CARROT_ID_MAINNET, 1),
    CpiWhitelistedAccount::new(SANDGLASS_ID_MAINNET, 1),
    CpiWhitelistedAccount::new(BESTLEND_ID_MAINNET, 1),
    CpiWhitelistedAccount::new(KAMINO_VAULT_STAGING, 1),
    CpiWhitelistedAccount::new(KAMINO_VAULT_MAINNET, 1),
    CpiWhitelistedAccount::new(DIVVY_ID_MAINNET, 1),
    CpiWhitelistedAccount::new(EXPONENT_INTEGRATION_ID_MAINNET, 2),
    CpiWhitelistedAccount::new(EXPONENT_CORE_ID_MAINNET, 3),
    CpiWhitelistedAccount::new(AGRO_ID_MAINNET, 1),
    CpiWhitelistedAccount::new(AGRO_STAGING_ID_MAINNET, 1),
];

pub struct CpiWhitelistedAccount {
    pub program_id: Pubkey,
    // How many levels deep of CPI can the program call our instructions.
    // 1 - direct CPI to our program
    // 2 - indirect CPI to our program
    pub whitelist_level: usize,
}

impl CpiWhitelistedAccount {
    pub const fn new(program_id: Pubkey, whitelist_level: usize) -> CpiWhitelistedAccount {
        CpiWhitelistedAccount {
            program_id,
            whitelist_level,
        }
    }
}

pub const RESTRICTED_PROGRAMS: [Pubkey; 1] =
    [pubkey!("jupr81YtYssSyPt8jbnGuiWon5f6x9TcDEFxYe3Bdzi")];

pub const COMPUTE_BUDGET_PROGRAM_ID: Pubkey =
    pubkey!("ComputeBudget111111111111111111111111111111");

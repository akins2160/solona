use anchor_lang::{prelude::*, AccountsClose, Owner, Result, ToAccountInfo, ZeroCopy};
use anchor_spl::{
    token_2022::spl_token_2022::extension::ExtensionType,
    token_interface::{Mint, TokenInterface},
};
use solana_program::msg;

use super::{accounts, spltoken};

pub fn close_account_loader<'info, T: ZeroCopy + Owner>(
    close_account: bool,
    owner: &Signer<'info>,
    account_to_be_closed: &AccountLoader<'info, T>,
) -> Result<()> {
    if close_account {
        msg!("Closing account");
        account_to_be_closed.close(owner.to_account_info().clone())?;
    }

    Ok(())
}

// Inspiration from: https://github.com/orca-so/whirlpools/blob/99363f9f01b97fdf31ecbd47d2066df6818f1960/programs/whirlpool/src/util/token_2022.rs#L468
// Works for both Token and Token2022 programs
pub fn initialize_pda_token_account<'info>(
    payer: &AccountInfo<'info>,
    token_account: &AccountInfo<'info>,
    token_mint: &InterfaceAccount<'info, Mint>,
    token_account_authority: &AccountInfo<'info>,
    token_program: &Interface<'info, TokenInterface>,
    system_program: &AccountInfo<'info>,
    seeds: &[&[&[u8]]],
) -> Result<()> {
    let is_token_2022 = token_program.key() == anchor_spl::token_2022::spl_token_2022::ID;

    // The size required for extensions that are mandatory on the TokenAccount side
    // based on the TokenExtensions enabled on the Mint
    // is automatically accounted for. For non-mandatory extensions, however, they must be explicitly added,
    // so we specify ImmutableOwner explicitly.
    let space = if is_token_2022 {
        anchor_spl::token_2022::get_account_data_size(
            CpiContext::new(
                token_program.to_account_info(),
                anchor_spl::token_2022::GetAccountDataSize {
                    mint: token_mint.to_account_info(),
                },
            ),
            // The program will never attempt to change the owner of the reserve token account.
            // However, since the ImmutableOwner extension only increases the account size by 4 bytes, the overhead of always including it is negligible.
            // On the other hand, it makes it easier to comply with cases where ImmutableOwner is required, and it adds a layer of safety from a security standpoint.
            // Therefore, we'll include it by default going forward. (Reserves initialized after this change will have the ImmutableOwner extension.)
            &[ExtensionType::ImmutableOwner],
        )?
    } else {
        anchor_spl::token::TokenAccount::LEN as u64
    };

    let lamports = Rent::get()?.minimum_balance(space.try_into().unwrap());

    // create reserve token account with system program
    accounts::create_pda_account(
        system_program.to_account_info(),
        payer.to_account_info(),
        token_account.to_account_info(),
        &token_program.key(),
        lamports,
        space,
        seeds,
    )?;

    if is_token_2022 {
        spltoken::initialize_immutable_owner(
            token_program.to_account_info(),
            token_account.to_account_info(),
        )?;
    }

    spltoken::initialize_token_account(
        token_program.to_account_info(),
        token_mint.to_account_info(),
        token_account.to_account_info(),
        token_account_authority.to_account_info(),
    )
    .map_err(Into::into)
}

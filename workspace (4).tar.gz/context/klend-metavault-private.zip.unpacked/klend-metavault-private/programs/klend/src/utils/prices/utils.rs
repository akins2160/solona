use crate::{
    fraction::BigFraction,
    utils::{prices::types::Price, Fraction, U128, U256},
};

/// Lossy conversion from `Price` to `Fraction`
///
/// Price is stored with n decimals
/// If Price has more than 18 decimals the extra precision is lost.
pub(crate) fn price_to_fraction<T>(price: Price<T>) -> Fraction
where
    T: Into<U256> + Copy,
{
    let Price { value, exp } = price;
    let value: U256 = value.into();
    let decimal = ten_pow(exp);

    let value_bf = BigFraction::from_num(value);
    let price_bf = value_bf / decimal;
    // Note: The integer part of a Fraction is 68 bits which allow for 1 token to have a value of
    // more than 3*10^6 times the total $ value of all FIAT in the world.
    // This is more than enough and should never overflow.
    price_bf
        .try_into()
        .expect("Failed to convert Price stored on BigFraction to Fraction")
}

pub(super) fn ten_pow(exponent: u32) -> U128 {
    let value: u128 = match exponent {
        36 => 1_000_000_000_000_000_000_000_000_000_000_000_000,
        35 => 100_000_000_000_000_000_000_000_000_000_000_000,
        34 => 10_000_000_000_000_000_000_000_000_000_000_000,
        33 => 1_000_000_000_000_000_000_000_000_000_000_000,
        32 => 100_000_000_000_000_000_000_000_000_000_000,
        31 => 10_000_000_000_000_000_000_000_000_000_000,
        30 => 1_000_000_000_000_000_000_000_000_000_000,
        29 => 100_000_000_000_000_000_000_000_000_000,
        28 => 10_000_000_000_000_000_000_000_000_000,
        27 => 1_000_000_000_000_000_000_000_000_000,
        26 => 100_000_000_000_000_000_000_000_000,
        25 => 10_000_000_000_000_000_000_000_000,
        24 => 1_000_000_000_000_000_000_000_000,
        23 => 100_000_000_000_000_000_000_000,
        22 => 10_000_000_000_000_000_000_000,
        21 => 1_000_000_000_000_000_000_000,
        20 => 100_000_000_000_000_000_000,
        19 => 10_000_000_000_000_000_000,
        18 => 1_000_000_000_000_000_000,
        17 => 100_000_000_000_000_000,
        16 => 10_000_000_000_000_000,
        15 => 1_000_000_000_000_000,
        14 => 100_000_000_000_000,
        13 => 10_000_000_000_000,
        12 => 1_000_000_000_000,
        11 => 100_000_000_000,
        10 => 10_000_000_000,
        9 => 1_000_000_000,
        8 => 100_000_000,
        7 => 10_000_000,
        6 => 1_000_000,
        5 => 100_000,
        4 => 10_000,
        3 => 1_000,
        2 => 100,
        1 => 10,
        0 => 1,
        _ => panic!("no support for exponent: {exponent}"),
    };

    U128::from(value)
}

use anchor_lang::{prelude::*, solana_program::clock};

use crate::{
    utils::{
        prices::{
            types::TimestampedPriceWithTwap, utils::price_to_fraction, GetPriceResult, Price,
        },
        Fraction, FULL_BPS,
    },
    xmsg, LendingError, PriceHeuristic, PriceStatusFlags, TokenInfo,
};

/// Validate the price confidence, twap and age
/// Return the price and timestamp
pub(super) fn get_validated_price(
    price_and_twap: TimestampedPriceWithTwap,
    token_info: &TokenInfo,
    unix_timestamp: clock::UnixTimestamp,
) -> Option<GetPriceResult> {
    let price_label = token_info.symbol();
    let mut price_result = get_validated_price_with_args(
        price_and_twap,
        token_info.max_age_price_seconds,
        token_info.max_age_twap_seconds,
        token_info.max_twap_divergence_bps,
        token_info.is_twap_enabled(),
        price_label,
        unix_timestamp,
    )?;

    // Check heuristics
    match check_price_heuristics(price_result.price, &token_info.heuristic) {
        Ok(()) => price_result
            .status
            .set(PriceStatusFlags::HEURISTIC_CHECKED, true),
        Err(e) => msg!("Price heuristic check failed token=[{price_label}]: {e:?}",),
    }

    if token_info.block_price_usage == 0 {
        price_result
            .status
            .set(PriceStatusFlags::PRICE_USAGE_ALLOWED, true);
    }

    Some(price_result)
}

/// Validate the price confidence, twap and age
/// This function DOES NOT check price heuristic and if price usage is blocked, use `get_validated_price` fn instead
/// Return the price and timestamp
pub fn get_validated_price_with_args(
    price_and_twap: TimestampedPriceWithTwap,
    max_age_price_seconds: u64,
    max_age_twap_seconds: u64,
    max_twap_divergence_bps: u64,
    is_twap_enabled: bool,
    price_label: &str,
    unix_timestamp: clock::UnixTimestamp,
) -> Option<GetPriceResult> {
    // Can't fail: the timestamp is not in the past.
    let unix_timestamp = u64::try_from(unix_timestamp).unwrap();

    let TimestampedPriceWithTwap { price, twap } = price_and_twap;

    let mut price_status = PriceStatusFlags::empty();

    let price_dec = match (price.price_load)() {
        Ok(price_dec) => {
            price_status.set(PriceStatusFlags::PRICE_LOADED, true);
            price_dec
        }
        Err(e) => {
            msg!("Price is not available token=[{price_label}], {e:?}",);
            return None;
        }
    };

    // Check age
    match check_price_age(price.timestamp, max_age_price_seconds, unix_timestamp) {
        Ok(()) => price_status.set(PriceStatusFlags::PRICE_AGE_CHECKED, true),
        Err(e) => {
            xmsg!("Price is too old token=[{price_label}], {e:?}",);
        }
    }

    // Check twap if enabled
    if is_twap_enabled {
        if let Some(twap) = twap {
            // 1- Check age
            match check_price_age(twap.timestamp, max_age_twap_seconds, unix_timestamp) {
                Ok(()) => price_status.set(PriceStatusFlags::TWAP_AGE_CHECKED, true),
                Err(e) => {
                    msg!("Price twap is too old token=[{price_label}], {e:?}",);
                }
            }

            // 2- Load and check twap price
            match (twap.price_load)().and_then(|twap_dec| {
                check_twap_in_tolerance(price_dec, twap_dec, max_twap_divergence_bps, price_label)
            }) {
                Ok(()) => {
                    price_status.set(PriceStatusFlags::TWAP_CHECKED, true);
                }
                Err(e) => {
                    msg!("Price twap check failed token=[{price_label}]: {e:?}",);
                }
            }
        } else {
            msg!("Price twap is not available but required, token=[{price_label}]",);
            // Keep twap flags unset
        }
    } else {
        // If twap is disabled, assume it's ok
        price_status.set(PriceStatusFlags::TWAP_CHECKED, true);
        price_status.set(PriceStatusFlags::TWAP_AGE_CHECKED, true);
    }

    Some(GetPriceResult {
        price: price_dec,
        timestamp: price.timestamp,
        status: price_status,
    })
}

fn check_price_age(
    price_timestamp: u64,
    max_age_seconds: u64,
    current_timestamp: u64,
) -> Result<()> {
    // Saturating sub to avoid simulation glitches
    let age_seconds = current_timestamp.saturating_sub(price_timestamp);
    if age_seconds > max_age_seconds {
        xmsg!("Price is too old age={age_seconds} max_age={max_age_seconds}",);
        err!(LendingError::PriceTooOld)
    } else {
        Ok(())
    }
}

fn is_within_tolerance(px: Fraction, twap: Fraction, acceptable_tolerance_bps: u64) -> bool {
    // We want abs(px-twap)*10000/px < acceptable_tolerance_bps
    // <=> abs(px-twap)*10000 < acceptable_tolerance_bps * px

    let abs_diff = Fraction::abs_diff(px, twap);

    let diff_bps_scaled = abs_diff * u128::from(FULL_BPS);
    let tolerance_scaled = px * u128::from(acceptable_tolerance_bps);
    diff_bps_scaled < tolerance_scaled
}

fn check_twap_in_tolerance(
    price: Fraction,
    twap: Fraction,
    acceptable_twap_tolerance_bps: u64,
    token_span: &str,
) -> Result<()> {
    if !is_within_tolerance(price, twap, acceptable_twap_tolerance_bps) {
        msg!(
            "Price is too far from TWAP \
              token={token_span} \
              price={price} \
              twap={twap} \
              tolerance_bps={acceptable_twap_tolerance_bps}",
        );
        return Err(LendingError::PriceTooDivergentFromTwap.into());
    }
    Ok(())
}

fn check_price_heuristics(token_price: Fraction, heuristic: &PriceHeuristic) -> Result<()> {
    if heuristic.lower > 0 {
        let lower_heuristic = Price {
            value: heuristic.lower,
            exp: heuristic.exp.try_into().unwrap(),
        };

        let lower_heuristic = price_to_fraction(lower_heuristic);

        if token_price < lower_heuristic {
            return err!(LendingError::PriceIsLowerThanHeuristic);
        }
    }

    if heuristic.upper > 0 {
        let upper_heuristic = Price {
            value: heuristic.upper,
            exp: heuristic.exp.try_into().unwrap(),
        };

        let upper_heuristic = price_to_fraction(upper_heuristic);

        if upper_heuristic < token_price {
            return err!(LendingError::PriceIsBiggerThanHeuristic);
        }
    }

    Ok(())
}

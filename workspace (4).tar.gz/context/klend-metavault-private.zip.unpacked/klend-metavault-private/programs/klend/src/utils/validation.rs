/// A syntactic-sugar allowing for easier calls to the iterator-related functions defined below.
pub trait IterExt: Iterator + Sized {
    /// Performs [zip_exact()] on this instance (being "left") and the given "right" one.
    fn zip_exact<R: Iterator>(
        self,
        rights: impl IntoIterator<Item = R::Item, IntoIter = R>,
    ) -> LengthCheckingZipIterator<Self, R> {
        zip_exact(self, rights)
    }

    /// Performs [only_element()] on this instance.
    fn only_element(self) -> Option<Self::Item> {
        only_element(self)
    }
}
impl<T: Iterator> IterExt for T {}

/// Returns the only element held by the given iterator, or [None] if it had 0 or >1 elements.
pub fn only_element<T>(iter: impl IntoIterator<Item = T>) -> Option<T> {
    let mut the_only = None;
    for element in iter.into_iter() {
        if the_only.is_some() {
            return None;
        }
        the_only = Some(element);
    }
    the_only
}

/// Returns an iterator of tuples composed of matching consecutive elements of the input iterators,
/// checking that they have the same length.
///
/// This is a counterpart of the standard [iter::zip] function, which does not end itself when one
/// of the input iterators ends earlier than the other - instead, it will return the given error
/// (and then end itself).
///
/// Of course, for input iterators of the same length, the behavior here is equivalent to the
/// [iter::zip], with the only difference of the tuples being wrapped in successful [Result]s.
pub fn zip_exact<L: Iterator, R: Iterator>(
    lefts: impl IntoIterator<Item = L::Item, IntoIter = L>,
    rights: impl IntoIterator<Item = R::Item, IntoIter = R>,
) -> LengthCheckingZipIterator<L, R> {
    LengthCheckingZipIterator {
        lefts: lefts.into_iter(),
        rights: rights.into_iter(),
        errored: false,
    }
}

/// An error indicating that [zip_exact()] has detected mismatching iterator
/// lengths when producing next element.
#[derive(Debug, Eq, PartialEq)]
pub struct LengthMismatchError;

/// An element of the [zip_exact()] iterator.
pub type LengthCheckedResult<L, R> = Result<(L, R), LengthMismatchError>;

pub struct LengthCheckingZipIterator<L, R> {
    lefts: L,
    rights: R,
    errored: bool,
}

impl<L: Iterator, R: Iterator> Iterator for LengthCheckingZipIterator<L, R> {
    type Item = LengthCheckedResult<L::Item, R::Item>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.errored {
            return None;
        }
        match (self.lefts.next(), self.rights.next()) {
            (None, None) => None,
            (Some(left), Some(right)) => Some(Ok((left, right))),
            _different => {
                self.errored = true;
                Some(Err(LengthMismatchError))
            }
        }
    }
}

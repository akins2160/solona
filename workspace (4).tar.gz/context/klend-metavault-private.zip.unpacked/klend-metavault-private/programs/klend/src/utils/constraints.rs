use anchor_lang::{
    err,
    prelude::{AccountLoader, Context},
    Bumps, Result,
};

use crate::{state::LendingMarket, LendingError};

pub fn emergency_mode_disabled(lending_market: &AccountLoader<LendingMarket>) -> Result<()> {
    if lending_market.load()?.emergency_mode > 0 {
        return err!(LendingError::GlobalEmergencyMode);
    }
    Ok(())
}

pub fn check_remaining_accounts<T>(ctx: &Context<T>) -> Result<()>
where
    T: Bumps,
{
    //make sure there are no extra accounts
    if !ctx.remaining_accounts.is_empty() {
        return err!(LendingError::InvalidAccountInput);
    }

    Ok(())
}

pub mod token_2022 {
    use anchor_spl::{
        token::spl_token,
        token_2022::spl_token_2022::{self, state::AccountState as DefaultAccountState},
        token_interface::spl_token_2022::extension::{
            BaseStateWithExtensions, ExtensionType, StateWithExtensions,
        },
    };
    use solana_program::{account_info::AccountInfo, pubkey::Pubkey};

    use super::*;
    use crate::{xmsg, LendingError};

    /// Token account extension that we support on liquidity *mints*.
    const SUPPORTED_LIQUIDITY_MINT_TOKEN_EXTENSIONS: &[ExtensionType] = &[
        ExtensionType::ConfidentialTransferFeeConfig,
        ExtensionType::ConfidentialTransferMint,
        ExtensionType::MintCloseAuthority,
        ExtensionType::MetadataPointer,
        ExtensionType::PermanentDelegate,
        ExtensionType::TransferFeeConfig,
        ExtensionType::TokenMetadata,
        ExtensionType::TransferHook,
        ExtensionType::DefaultAccountState,
        ExtensionType::ScaledUiAmount,
        ExtensionType::Pausable,
    ];

    /// Token account extension that we support on liquidity *token accounts*.
    ///
    /// These should be implied by [SUPPORTED_LIQUIDITY_MINT_TOKEN_EXTENSIONS].
    const SUPPORTED_LIQUIDITY_ACCOUNT_TOKEN_EXTENSIONS: &[ExtensionType] = &[
        ExtensionType::ConfidentialTransferFeeAmount, // from the mint's ConfidentialTransferFeeConfig
        ExtensionType::ConfidentialTransferAccount,   // from the mint's ConfidentialTransferMint
        ExtensionType::TransferFeeAmount,             // from the mint's TransferFeeConfig
        ExtensionType::TransferHookAccount,           // from the mint's TransferHook
        ExtensionType::PausableAccount,               // from the mint's Pausable
        ExtensionType::ImmutableOwner,                // independently supported
    ];

    /// Checks that the provided liquidity mint and token account contain only Klend-supported
    /// extensions.
    ///
    /// Note: it is assumed that the token account matches the mint (i.e. should be checked by
    /// Anchor constraints before reaching this point).
    pub fn check_only_supported_liquidity_token_extensions(
        mint_acc_info: &AccountInfo,
        token_acc_info: &AccountInfo,
    ) -> Result<()> {
        check_only_supported_extensions_on_liquidity_mint(mint_acc_info)?;
        check_only_supported_extensions_on_liquidity_ta(token_acc_info)?;
        Ok(())
    }

    /// Checks that the provided liquidity *mint* contains only Klend-supported extensions.
    pub fn check_only_supported_extensions_on_liquidity_mint(
        mint_acc_info: &AccountInfo,
    ) -> Result<()> {
        if mint_acc_info.owner == &spl_token::id() {
            return Ok(()); // no extensions
        }

        let mint_data = mint_acc_info.data.borrow();
        let mint = StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&mint_data)?;

        for mint_ext in mint.get_extension_types()? {
            if !SUPPORTED_LIQUIDITY_MINT_TOKEN_EXTENSIONS.contains(&mint_ext) {
                xmsg!(
                    "Unsupported liquidity mint token (2022) extension: {:?}, supported extensions: {:?}",
                    mint_ext,
                    SUPPORTED_LIQUIDITY_MINT_TOKEN_EXTENSIONS
                );
                return err!(LendingError::UnsupportedTokenExtension);
            }
            match mint_ext {
                ExtensionType::TransferFeeConfig => {
                    let ext = mint
                        .get_extension::<spl_token_2022::extension::transfer_fee::TransferFeeConfig>()?;
                    if <u16>::from(ext.older_transfer_fee.transfer_fee_basis_points) != 0
                        || <u16>::from(ext.newer_transfer_fee.transfer_fee_basis_points) != 0
                    {
                        xmsg!(
                            "Transfer fee must be 0 for liquidity tokens, got: {:?}",
                            ext
                        );
                        return err!(LendingError::UnsupportedTokenExtension);
                    }
                }
                ExtensionType::TransferHook => {
                    let ext = mint
                        .get_extension::<spl_token_2022::extension::transfer_hook::TransferHook>(
                        )?;
                    let hook_program_id: Option<Pubkey> = ext.program_id.into();
                    if hook_program_id.is_some() {
                        xmsg!(
                            "Transfer hook program id must not be set for liquidity tokens, got {:?}",
                            ext
                        );
                        return err!(LendingError::UnsupportedTokenExtension);
                    }
                }
                ExtensionType::ConfidentialTransferMint => {
                    let ext = mint.get_extension::<spl_token_2022::extension::confidential_transfer::ConfidentialTransferMint>()?;
                    if bool::from(ext.auto_approve_new_accounts) {
                        xmsg!(
                            "Auto approve new accounts must be false for liquidity tokens, got {:?}",
                            ext
                        );
                        return err!(LendingError::UnsupportedTokenExtension);
                    }
                }
                ExtensionType::DefaultAccountState => {
                    let ext = mint.get_extension::<spl_token_2022::extension::default_account_state::DefaultAccountState>()?;
                    if !(ext.state == DefaultAccountState::Initialized as u8
                        || ext.state == DefaultAccountState::Frozen as u8)
                    {
                        xmsg!(
                            "Default account state extension only supports \"Initialized\" or \"Frozen\" states"
                        );
                        return err!(LendingError::UnsupportedTokenExtension);
                    }
                }
                ExtensionType::Pausable => {
                    let ext = mint
                        .get_extension::<spl_token_2022::extension::pausable::PausableConfig>()?;
                    if ext.paused.into() {
                        xmsg!("Pausable extension must not be paused for liquidity tokens");
                        return err!(LendingError::UnsupportedTokenExtension);
                    }
                }
                _ => {}
            }
        }
        Ok(())
    }

    /// Checks that the provided liquidity *token account* contains only Klend-supported extensions.
    pub fn check_only_supported_extensions_on_liquidity_ta(
        token_acc_info: &AccountInfo,
    ) -> Result<()> {
        if token_acc_info.owner == &spl_token::id() {
            return Ok(()); // no extensions
        }

        let token_acc_data = token_acc_info.data.borrow();
        let token_acc =
            StateWithExtensions::<spl_token_2022::state::Account>::unpack(&token_acc_data)?;

        for token_ext in token_acc.get_extension_types()? {
            if !SUPPORTED_LIQUIDITY_ACCOUNT_TOKEN_EXTENSIONS.contains(&token_ext) {
                xmsg!(
                    "Unsupported liquidity account token (2022) extension: {:?}, supported extensions: {:?}",
                    token_ext,
                    SUPPORTED_LIQUIDITY_ACCOUNT_TOKEN_EXTENSIONS
                );
                return err!(LendingError::UnsupportedTokenExtension);
            }
            if token_ext == ExtensionType::ConfidentialTransferAccount {
                let token_acc_ext = token_acc.get_extension::<spl_token_2022::extension::confidential_transfer::ConfidentialTransferAccount>()?;
                if bool::from(token_acc_ext.allow_confidential_credits) {
                    xmsg!(
                        "Allow confidential credits must be false for token accounts, got {:?}",
                        token_acc_ext
                    );
                    return err!(LendingError::UnsupportedTokenExtension);
                }
                if !bool::from(token_acc_ext.allow_non_confidential_credits) {
                    xmsg!(
                        "Allow non-confidential credits must be true for token accounts, got {:?}",
                        token_acc_ext
                    );
                    return err!(LendingError::UnsupportedTokenExtension);
                }
                if token_acc_ext.closable().is_err() {
                    // the "closeable" state means that the confidential transfer feature is not in active use
                    xmsg!(
                        "Pending and available balance must be zero for token accounts, got {:?}",
                        token_acc_ext
                    );
                    return err!(LendingError::UnsupportedTokenExtension);
                }
            }
        }
        Ok(())
    }

    /// Checks that any newly-created token accounts of the given mint will be initialized.
    ///
    /// This can only be false when explicitly reconfigured by [ExtensionType::DefaultAccountState].
    pub fn check_default_account_state_initialized(mint_acc_info: &AccountInfo) -> Result<()> {
        if mint_acc_info.owner == &spl_token::id() {
            return Ok(()); // no extensions at all
        }

        let mint_data = mint_acc_info.data.borrow();
        let mint = StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&mint_data)?;
        if !mint
            .get_extension_types()?
            .contains(&ExtensionType::DefaultAccountState)
        {
            return Ok(()); // no default account state extension
        }

        let ext = mint
            .get_extension::<spl_token_2022::extension::default_account_state::DefaultAccountState>(
            )?;
        if ext.state == DefaultAccountState::Initialized as u8 {
            return Ok(()); // extension configured, but not really changing the default behavior
        }

        xmsg!("Default account state must be initialized; got: {:?}", ext);
        err!(LendingError::UnsupportedTokenExtension)
    }
}

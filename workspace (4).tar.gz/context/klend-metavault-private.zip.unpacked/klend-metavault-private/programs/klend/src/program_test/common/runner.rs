#![allow(dead_code)]
use std::{collections::HashMap, iter, sync::Arc, time::Duration};

use anchor_lang::{
    __private::bytemuck,
    prelude::{Clock, Pubkey},
    Discriminator, Owner, ZeroCopy,
};
use anchor_spl::token::spl_token::{self, state::Mint};
use arrayref::array_ref;
use borsh::BorshSerialize;
use farms::state::UserState as FarmUserState;
use solana_program_test::BanksClientError;
use solana_sdk::{
    account::{Account, AccountSharedData},
    commitment_config::CommitmentLevel,
    compute_budget::ComputeBudgetInstruction,
    hash::Hash,
    instruction::{AccountMeta, Instruction},
    program_error::ProgramError,
    program_pack::Pack,
    signature::Keypair,
    signer::Signer,
    system_instruction, system_program, sysvar,
    transaction::{Transaction, VersionedTransaction},
};
use strum::IntoEnumIterator;

use crate::{
    accounts::OptionalObligationFarmsAccounts,
    handlers::ReserveConfigCustomizationArgs,
    maybe_v2_ix,
    program_test::{
        common::{
            instructions::{
                self, repay_and_withdraw_and_redeem_ix, InstructionBlocks, ProgressCallbackConfig,
            },
            setup::{
                get_referrer_token_state_key, get_user_metadata_key, kp, update_pyth_price,
                update_switchboard_price_and_slot, KP,
            },
            token_operations::{
                self, create_ata_if_not_exists, create_mint, create_token_account,
                get_token_program,
            },
            types::{
                BorrowerAccounts, DepositorAccounts, FarmAccounts, InitObligationArgs,
                LendingMarketAccounts, ObligationBorrower, ReserveAccounts, TestContext, TestError,
            },
        },
        farms::operations::get_farms_user_state_account,
    },
    send_transaction,
    state::{
        LendingMarket, Obligation, ReferrerTokenState, Reserve, ReserveConfig, UpdateConfigMode,
        UpdateLendingMarketMode, UserMetadata,
    },
    utils::{seeds::pda, JustRef, SLOTS_PER_SECOND},
    withdraw_ticket::WithdrawTicket,
    BorrowOrderConfig, BorrowOrderConfigArgs, FixedTermBorrowRolloverConfig,
    ObligationConfigUpdateSubject, ObligationOrder, ReserveFarmKind, UpdateGlobalConfigMode,
    UpdateLendingMarketConfigValue, UpdateObligationConfigMode, UpdateReserveConfigValue,
};
// TODO: refactor this to be client.rs and ops.rs, not a god object

pub mod test {
    use solana_program_test::{anchor_processor, EbpfVm, InvokeContext, ProgramTest};

    use super::*;
    use crate::program_test::common::{context::ProgramTestContextWrapper, types::TestContext};

    pub fn program() -> ProgramTest {
        program_with_deps(vec![])
    }

    pub type BuiltinFunction<C> = fn(*mut EbpfVm<C>, u64, u64, u64, u64, u64);
    pub type ProgramDep = (
        &'static str,
        Pubkey,
        Option<BuiltinFunction<InvokeContext<'static>>>,
    );

    static DEFAULT_DEPS: &[ProgramDep] = &[
        ("kamino_lending", crate::ID, anchor_processor!(crate::entry)),
        ("farms", farms::ID, anchor_processor!(farms::entry)),
    ];

    pub fn program_with_deps(custom_deps: Vec<ProgramDep>) -> ProgramTest {
        let mut program_test = ProgramTest::default();

        // The custom deps want to override the default deps - let's do it explicitly beforehand,
        // since the overriding rules of `ProgramTest::add_program()` are not well-defined (in
        // particular, the behavior differs between native vs sbf tests):
        let deps_by_program_id = DEFAULT_DEPS
            .iter()
            .chain(custom_deps.iter())
            .map(|(name, program_id, entrypoint)| (program_id, (*name, entrypoint)))
            .collect::<HashMap<_, _>>();

        for (program_id, (name, entrypoint)) in deps_by_program_id {
            match entrypoint {
                Some(entrypoint) => {
                    program_test.add_program(&name, *program_id, Some(*entrypoint));
                }
                None => {
                    program_test.prefer_bpf(true);
                    program_test.add_program(&name, *program_id, None);
                    program_test.prefer_bpf(false);
                }
            }
        }

        program_test
    }

    pub async fn start(test: ProgramTest, initial_market_owner: &KP) -> TestContext {
        let use_instructions_v2 = std::env::var("USE_KLEND_INSTRUCTIONS_V2")
            .unwrap_or("false".to_string())
            .to_lowercase()
            .parse::<bool>()
            .unwrap_or(false);

        start_with_version(test, initial_market_owner, use_instructions_v2).await
    }

    pub async fn start_with_version(
        test: ProgramTest,
        initial_market_owner: &KP,
        use_instructions_v2: bool,
    ) -> TestContext {
        let mut context = test.start_with_context().await;
        let rent = context.banks_client.get_rent().await.unwrap();

        TestContext {
            context: ProgramTestContextWrapper::wrap(context),
            rent,
            initial_market_owner: initial_market_owner.clone(),
            use_instructions_v2,
            global_config: pda::global_config(),
            tx_counter: 0,
        }
    }
}

pub mod state {

    use anchor_lang::{AccountDeserialize, AccountSerialize, Discriminator};
    use solana_sdk::account::Account;

    use super::*;
    use crate::program_test::{
        common::types::TestError, farms::operations::get_farms_user_state_account,
    };

    pub async fn get<T: AccountDeserialize>(ctx: &mut TestContext, address: Pubkey) -> T {
        let acc = try_get::<T>(ctx, address).await;
        acc.unwrap()
    }
    pub async fn try_get<T: AccountDeserialize>(
        ctx: &mut TestContext,
        address: Pubkey,
    ) -> Result<T, TestError> {
        match ctx.get_account(address).await.map_err(|e| {
            println!("Error {:?}", e);
            TestError::UnknownError
        })? {
            Some(data) => deserialize::<T>(&data).map_err(|e| {
                println!("Error {:?}", e);
                TestError::CannotDeserialize
            }),
            None => Err(TestError::AccountNotFound),
        }
    }

    /// Get an account of a type implementing `Pack` (like most spl accounts, e.g. `Mint`)
    pub async fn get_packed<T: Pack>(
        ctx: &mut TestContext,
        address: Pubkey,
    ) -> Result<T, TestError> {
        let account = ctx
            .get_account(address)
            .await?
            .ok_or(TestError::AccountNotFound)?;
        T::unpack_unchecked(account.data.as_slice()).map_err(|_| TestError::CannotDeserialize)
    }

    pub async fn update<T: AccountSerialize + Discriminator>(
        ctx: &mut TestContext,
        address: Pubkey,
        data: &T,
    ) -> Result<(), TestError> {
        let mut account = ctx
            .get_account(address)
            .await?
            .ok_or(TestError::AccountNotFound)?;
        account.data = serialize(data);
        ctx.set_account(&address, account);
        Ok(())
    }

    pub fn deserialize_zero_copy<T: ZeroCopy>(account: &Account) -> Result<T, TestError> {
        let discriminator = &account.data[..8];
        if discriminator != T::discriminator() {
            println!(
                "Discriminator: {:?} does not match expected {:?}",
                discriminator,
                T::discriminator()
            );
            return Err(TestError::BadDiscriminator);
        }

        let data: &[u8] = &account.data[8..];
        let acc: &T = bytemuck::try_from_bytes(data).map_err(|_| TestError::CannotDeserialize)?;

        Ok(*acc)
    }

    pub fn serialize_zero_copy<T: ZeroCopy>(data: &T) -> Vec<u8> {
        let mut buf = Vec::with_capacity(8 + std::mem::size_of::<T>());
        buf.extend_from_slice(&T::discriminator());
        buf.extend_from_slice(bytemuck::bytes_of(data));
        buf
    }

    pub async fn get_zero_copy_account<T: ZeroCopy>(
        ctx: &mut TestContext,
        address: &Pubkey,
    ) -> Result<T, TestError> {
        let account = ctx
            .get_account(*address)
            .await?
            .ok_or(TestError::AccountNotFound)?;

        deserialize_zero_copy(&account)
    }

    pub async fn create_zero_copy<T: ZeroCopy + Owner>(
        env: &mut TestContext,
        address: Pubkey,
        data: &T,
    ) {
        create_zero_copy_custom_owner(env, address, data, T::owner()).await;
    }

    pub async fn create_zero_copy_custom_owner<T: ZeroCopy>(
        env: &mut TestContext,
        address: Pubkey,
        data: &T,
        owner: Pubkey,
    ) {
        env.context.set_account(
            address,
            AccountSharedData::from(Account {
                lamports: env.get_rent_zero_copy::<T>(),
                data: serialize_zero_copy(data),
                owner,
                executable: false,
                rent_epoch: u64::MAX,
            }),
        );
    }

    pub async fn update_zero_copy<T: ZeroCopy>(
        ctx: &mut TestContext,
        address: Pubkey,
        data: &T,
    ) -> Result<(), TestError> {
        let mut account = ctx
            .get_account(address)
            .await?
            .ok_or(TestError::AccountNotFound)?;
        account.data = serialize_zero_copy(data);
        ctx.set_account(&address, account);
        Ok(())
    }

    pub async fn update_packed<T: Pack>(ctx: &mut TestContext, address: Pubkey, data: &T) {
        ctx.set_account_data(&address, &serialize_packed(data))
            .await
    }

    pub fn deserialize<T: AccountDeserialize>(account: &Account) -> Result<T, TestError> {
        let mut data: &[u8] = &account.data;
        let user: T = T::try_deserialize(&mut data).map_err(|_| TestError::CannotDeserialize)?;

        Ok(user)
    }

    pub fn serialize<T: AccountSerialize>(data: &T) -> Vec<u8> {
        let mut buf = Vec::new();
        data.try_serialize(&mut buf).unwrap();
        buf
    }

    pub fn serialize_packed<T: Pack>(data: &T) -> Vec<u8> {
        let mut buf = vec![0; T::LEN];
        data.pack_into_slice(&mut buf);
        buf
    }

    pub async fn get_obligation_farm_state(
        ctx: &mut TestContext,
        reserve_accounts: &ReserveAccounts,
        obligation: Pubkey,
        farm_kind: ReserveFarmKind,
    ) -> FarmUserState {
        let reserve_farm_state = reserve_accounts.admin_farm_accounts[farm_kind as usize]
            .as_ref()
            .unwrap()
            .farm_state;

        let user_farm_state = get_farms_user_state_account(&reserve_farm_state, &obligation);

        state::get::<FarmUserState>(ctx, user_farm_state).await
    }
}

impl TestContext {
    pub async fn init_global_config(
        &mut self,
        upgrade_authority: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_global_config(self, upgrade_authority.clone()).await;

        send_transaction!(self, tx)
    }

    pub async fn init_lending_market(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        quote_currency: [u8; 32],
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_lending_market(
            self,
            market_accounts.owner.clone(),
            market_accounts,
            quote_currency,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn update_lending_market(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        mode: UpdateLendingMarketMode,
        value: UpdateLendingMarketConfigValue,
        payer: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let tx =
            instructions::update_lending_market(self, market_accounts, payer.clone(), mode, value)
                .await;

        send_transaction!(self, tx)
    }

    pub async fn update_lending_market_owner(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        payer: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let tx =
            instructions::update_lending_market_owner(self, market_accounts, payer.clone()).await;

        send_transaction!(self, tx)
    }

    pub async fn update_global_config(
        &mut self,
        mode: UpdateGlobalConfigMode,
        value: impl BorshSerialize,
        payer: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::update_global_config(
            self,
            payer.clone(),
            mode,
            &value.try_to_vec().unwrap(),
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn update_global_config_admin(
        &mut self,
        payer: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::update_global_config_admin(self, payer.clone()).await;

        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn init_reserve(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_reserve(
            self,
            market_accounts,
            reserve_accounts,
            market_accounts.owner.clone(),
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn seed_deposit_on_init_reserve(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        liquidity_ata: Pubkey,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::seed_deposit_on_init_reserve(
            self,
            market_accounts,
            reserve_accounts,
            liquidity_ata,
            market_accounts.owner.clone(),
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn topup_reserve_rewards(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        source_liquidity: Pubkey,
        signer: KP,
        amount: u64,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::topup_reserve_rewards(
            self,
            market_accounts,
            reserve_accounts,
            source_liquidity,
            signer,
            amount,
        )
        .await;

        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn clone_reserve_config(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        source_reserve_accounts: &ReserveAccounts,
        target_reserve_accounts: &ReserveAccounts,
        customizations: ReserveConfigCustomizationArgs,
        proposer_authority_to_use: Option<KP>,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::clone_reserve_config(
            self,
            market_accounts.market.pubkey(),
            source_reserve_accounts.pubkey(),
            target_reserve_accounts.pubkey(),
            customizations,
            proposer_authority_to_use.unwrap_or_else(|| market_accounts.owner.clone()),
        )
        .await;

        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn init_farms(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &mut ReserveAccounts,
        mint_amount: u64,
    ) -> Result<(), BanksClientError> {
        for farms_mode in ReserveFarmKind::iter() {
            let tx = instructions::init_farms(
                self,
                market_accounts,
                reserve_accounts,
                market_accounts.owner.clone(),
                farms_mode,
            )
            .await;

            println!("SendingTx: InitFarm");
            send_transaction!(self, tx)?;

            let reserve: Reserve =
                state::get::<Reserve>(self, reserve_accounts.address.pubkey()).await;
            Self::init_farm_reward_accounts(
                self,
                farms_mode,
                market_accounts,
                reserve_accounts,
                &reserve,
                mint_amount,
            )
            .await;
        }

        Ok(())
    }

    pub async fn init_obligation_farms_for_reserve(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        payer: &Arc<Keypair>,
        farm_kind: ReserveFarmKind,
    ) -> Result<(), BanksClientError> {
        let reserve: Reserve = self.get_reserve(reserve_accounts).await;
        let farm_collateral = reserve.get_farm(farm_kind);

        let init_obligation_farm_ix = instructions::init_obligation_farm_for_reserve_ix(
            reserve_accounts,
            &farm_collateral,
            &borrower.obligation,
            &borrower.owner,
            payer,
            ReserveFarmKind::Collateral,
        );

        let tx = self
            .create_transaction_with_payer([init_obligation_farm_ix.instruction], &borrower.owner)
            .await;

        send_transaction!(self, tx)
    }

    async fn init_farm_reward_accounts(
        ctx: &mut TestContext,
        farm_kind: ReserveFarmKind,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &mut ReserveAccounts,
        reserve: &Reserve,
        mint_amount: u64,
    ) {
        let reward_mint = kp();
        let reward_ata = kp();

        // 1. Create reward mint
        // 2. Create reward ata (and mint some)
        // 3. Initialize FarmsProgram reward (and vault)

        // 1.
        create_mint(
            ctx,
            &reward_mint,
            6,
            &ctx.initial_market_owner.pubkey(),
            &spl_token::id(),
            None,
        )
        .await;

        // 2.
        create_token_account(
            ctx,
            market_accounts.owner.clone(),
            &reward_ata,
            &reward_mint.pubkey(),
            &market_accounts.owner.clone().pubkey(),
        )
        .await
        .unwrap();

        token_operations::mint_to(
            ctx,
            &reward_mint.pubkey(),
            &reward_ata.pubkey(),
            mint_amount,
        )
        .await
        .unwrap();

        // 3.
        let (reward_vault, _reward_vault_bump) = Pubkey::find_program_address(
            &[
                farms::utils::consts::BASE_SEED_REWARD_VAULT,
                reserve.get_farm(farm_kind).as_ref(),
                reward_mint.pubkey().as_ref(),
            ],
            &farms::ID,
        );

        let (reward_treasury_vault, _) = Pubkey::find_program_address(
            &[
                farms::utils::consts::BASE_SEED_REWARD_TREASURY_VAULT,
                market_accounts.farms_global_config.pubkey().as_ref(),
                reward_mint.pubkey().as_ref(),
            ],
            &farms::ID,
        );

        let (farm_vault_authority, _) = Pubkey::find_program_address(
            &[
                farms::utils::consts::BASE_SEED_FARM_VAULTS_AUTHORITY,
                reserve.get_farm(farm_kind).as_ref(),
            ],
            &farms::ID,
        );

        let farm_accounts = FarmAccounts {
            farm_state: reserve.get_farm(farm_kind),
            admin_reward_ata: reward_ata.pubkey(),
            reward_mint,
            reward_vault,
            reward_treasury_vault,
            farm_vault_authority,
        };

        reserve_accounts.admin_farm_accounts[farm_kind as usize] = Some(farm_accounts);

        crate::program_test::farms::client::farms_initialize_reward(
            ctx,
            market_accounts,
            reserve_accounts,
            farm_kind,
        )
        .await
        .unwrap();
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn initialize_full_reserve(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        liquidity_supplier: Pubkey,
        collateral_receiver: &Arc<Keypair>,
        reserve_config: &ReserveConfig,
        liquidity_amount: u64,
    ) -> Result<(), BanksClientError> {
        self.init_reserve(market_accounts, reserve_accounts).await?;

        self.update_reserve_config_direct(reserve_accounts, reserve_config)
            .await;

        let collateral_ata =
            create_ata_if_not_exists(self, collateral_receiver, &reserve_accounts.collateral_mint)
                .await;

        if liquidity_amount > 0 {
            self.deposit_reserve_liquidity(
                market_accounts,
                reserve_accounts,
                &DepositorAccounts {
                    reserve: reserve_accounts.address.pubkey(),
                    liquidity: liquidity_supplier,
                    collateral: collateral_ata,
                    owner: market_accounts.owner.clone(),
                    referrer: Pubkey::default(),
                },
                liquidity_amount,
            )
            .await?;
        }

        Ok(())
    }

    pub async fn update_reserve_config_with_skip_config_integrity_validation(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        mode: UpdateConfigMode,
        value: UpdateReserveConfigValue,
        skip_config_integrity_validation: bool,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::update_reserve_config(
            self,
            reserve_accounts,
            market_accounts,
            market_accounts.owner.clone(),
            mode,
            value.clone(),
            skip_config_integrity_validation,
        )
        .await;

        send_transaction!(self, tx)
    }

    /// Update the reserve config directly without using any instruction
    pub async fn update_reserve_config_direct(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        config: &ReserveConfig,
    ) {
        let market = self
            .get_lending_market(reserve_accounts.lending_market)
            .await;
        crate::lending_market::lending_operations::utils::validate_reserve_config_integrity(
            config,
            &market,
            reserve_accounts.address.pubkey(),
        )
        .unwrap();
        let address = reserve_accounts.address.pubkey();
        let mut reserve: Reserve = state::get_zero_copy_account(self, &address).await.unwrap();
        reserve.config = *config;
        state::update_zero_copy(self, address, &reserve)
            .await
            .unwrap();
    }

    pub async fn update_reserve_config(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        mode: UpdateConfigMode,
        value: UpdateReserveConfigValue,
    ) -> Result<(), BanksClientError> {
        self.update_reserve_config_with_skip_config_integrity_validation(
            market_accounts,
            reserve_accounts,
            mode,
            value,
            false,
        )
        .await
    }

    pub async fn update_full_reserve_config(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        config: ReserveConfig,
    ) -> Result<(), BanksClientError> {
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdatePythPrice,
            UpdateReserveConfigValue::Pubkey(config.token_info.pyth_configuration.price),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoExpHeuristic,
            UpdateReserveConfigValue::U64(config.token_info.heuristic.exp),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateScopePriceFeed,
            UpdateReserveConfigValue::Pubkey(config.token_info.scope_configuration.price_feed),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoScopeChain,
            UpdateReserveConfigValue::ScopeChain(config.token_info.scope_configuration.price_chain),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoScopeTwap,
            UpdateReserveConfigValue::ScopeChain(config.token_info.scope_configuration.twap_chain),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateSwitchboardTwapFeed,
            UpdateReserveConfigValue::Pubkey(
                config.token_info.switchboard_configuration.twap_aggregator,
            ),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateSwitchboardFeed,
            UpdateReserveConfigValue::Pubkey(
                config.token_info.switchboard_configuration.price_aggregator,
            ),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoName,
            UpdateReserveConfigValue::Name(config.token_info.name),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoLowerHeuristic,
            UpdateReserveConfigValue::U64(config.token_info.heuristic.lower),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoUpperHeuristic,
            UpdateReserveConfigValue::U64(config.token_info.heuristic.upper),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoPriceMaxAge,
            UpdateReserveConfigValue::U64(config.token_info.max_age_price_seconds),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoTwapMaxAge,
            UpdateReserveConfigValue::U64(config.token_info.max_age_twap_seconds),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateTokenInfoTwapDivergence,
            UpdateReserveConfigValue::U64(config.token_info.max_twap_divergence_bps),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateLoanToValuePct,
            UpdateReserveConfigValue::U8(config.loan_to_value_pct),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateMinLiquidationBonusBps,
            UpdateReserveConfigValue::U16(config.min_liquidation_bonus_bps),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateMinDeleveragingBonusBps,
            UpdateReserveConfigValue::U16(config.min_deleveraging_bonus_bps),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateMaxLiquidationBonusBps,
            UpdateReserveConfigValue::U16(config.max_liquidation_bonus_bps),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateLiquidationThresholdPct,
            UpdateReserveConfigValue::U8(config.liquidation_threshold_pct),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateBorrowRateCurve,
            UpdateReserveConfigValue::BorrowRateCurve(config.borrow_rate_curve),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateProtocolLiquidationFee,
            UpdateReserveConfigValue::U8(config.protocol_liquidation_fee_pct),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateProtocolOrderExecutionFee,
            UpdateReserveConfigValue::U8(config.protocol_order_execution_fee_pct),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateProtocolTakeRate,
            UpdateReserveConfigValue::U8(config.protocol_take_rate_pct),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDepositLimit,
            UpdateReserveConfigValue::U64(config.deposit_limit),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateBorrowLimit,
            UpdateReserveConfigValue::U64(config.borrow_limit),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateFeesOriginationFee,
            UpdateReserveConfigValue::U64(config.fees.origination_fee_sf),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateFeesFlashLoanFee,
            UpdateReserveConfigValue::U64(config.fees.flash_loan_fee_sf),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDebtWithdrawalCap,
            UpdateReserveConfigValue::WithdrawalCap(
                config.debt_withdrawal_cap.config_capacity as u64,
                config.debt_withdrawal_cap.config_interval_length_seconds,
            ),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDepositWithdrawalCap,
            UpdateReserveConfigValue::WithdrawalCap(
                config.deposit_withdrawal_cap.config_capacity as u64,
                config.deposit_withdrawal_cap.config_interval_length_seconds,
            ),
        )
        .await
        .unwrap();
        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateBadDebtLiquidationBonusBps,
            UpdateReserveConfigValue::U16(config.bad_debt_liquidation_bonus_bps),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateAutodeleverageEnabled,
            UpdateReserveConfigValue::U8(config.autodeleverage_enabled),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDeleveragingMarginCallPeriod,
            UpdateReserveConfigValue::U64(config.deleveraging_margin_call_period_secs),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDeleveragingThresholdDecreaseBpsPerDay,
            UpdateReserveConfigValue::U64(config.deleveraging_threshold_decrease_bps_per_day),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDeleveragingBonusIncreaseBpsPerDay,
            UpdateReserveConfigValue::U64(config.deleveraging_bonus_increase_bps_per_day),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateBorrowFactor,
            UpdateReserveConfigValue::U64(config.borrow_factor_pct),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateBorrowLimitOutsideElevationGroup,
            UpdateReserveConfigValue::U64(config.borrow_limit_outside_elevation_group),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateBorrowLimitsInElevationGroupAgainstThisReserve,
            UpdateReserveConfigValue::ElevationGroupBorrowLimits(
                config.borrow_limit_against_this_collateral_in_elevation_group,
            ),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDebtMaturityTimestamp,
            UpdateReserveConfigValue::U64(config.debt_maturity_timestamp),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateDebtTermSeconds,
            UpdateReserveConfigValue::U64(config.debt_term_seconds),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateProposerAuthorityLock,
            UpdateReserveConfigValue::U8(config.proposer_authority_locked),
        )
        .await
        .unwrap();

        self.update_reserve_config(
            market_accounts,
            reserve_accounts,
            UpdateConfigMode::UpdateEarlyRepayRemainingInterestPct,
            UpdateReserveConfigValue::U8(config.early_repay_remaining_interest_pct),
        )
        .await
        .unwrap();

        Ok(())
    }

    pub async fn init_obligation(
        &mut self,
        market: &LendingMarketAccounts,
        borrower: &dyn ObligationBorrower,
        args: InitObligationArgs,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_obligation(self, market, borrower, args).await;

        send_transaction!(self, tx)
    }

    pub async fn deposit_reserve_liquidity(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        liquidity_amount: u64,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::deposit_reserve_liquidity(
            self,
            market_accounts,
            reserve_accounts,
            depositor,
            liquidity_amount,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn deposit_reserve_liquidity_permissioned(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        liquidity_amount: u64,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        let mut deposit_ix = instructions::deposit_reserve_liquidity_ix(
            market_accounts,
            reserve_accounts,
            depositor,
            liquidity_amount,
        );
        deposit_ix
            .instruction
            .accounts
            .push(AccountMeta::new_readonly(
                market_permissioner.pubkey(),
                true,
            ));

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                [deposit_ix.instruction],
                deposit_ix.signers[0].as_ref(),
                [market_permissioner.clone()],
            )
            .await;

        send_transaction!(self, tx)
    }

    pub async fn deposit_obligation_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        collateral_amount: u64,
    ) -> Result<(), BanksClientError> {
        self.execute_deposit_obligation_collateral(
            market_accounts,
            reserve_accounts,
            depositor,
            obligation,
            collateral_amount,
            None,
        )
        .await
    }

    pub async fn deposit_obligation_collateral_permissioned(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        collateral_amount: u64,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        self.execute_deposit_obligation_collateral(
            market_accounts,
            reserve_accounts,
            depositor,
            obligation,
            collateral_amount,
            Some(market_permissioner),
        )
        .await
    }

    pub async fn update_obligation_config(
        &mut self,
        market: &LendingMarketAccounts,
        borrower: &BorrowerAccounts,
        subject: ObligationConfigUpdateSubject,
        mode: UpdateObligationConfigMode,
        value: Vec<u8>,
    ) -> Result<(), BanksClientError> {
        let (specific_deposit_reserve, specific_borrow_reserve) = match subject {
            ObligationConfigUpdateSubject::Obligation => (None, None),
            ObligationConfigUpdateSubject::Deposit(reserve) => (Some(reserve), None),
            ObligationConfigUpdateSubject::Borrow(reserve) => (None, Some(reserve)),
        };
        let tx = instructions::update_obligation_config(
            self,
            market.market.pubkey(),
            &borrower.owner,
            borrower.obligation,
            specific_deposit_reserve,
            specific_borrow_reserve,
            mode,
            value,
        )
        .await;
        send_transaction!(self, tx)
    }

    pub async fn set_rollover_config(
        &mut self,
        market: &LendingMarketAccounts,
        borrower: &BorrowerAccounts,
        borrow_reserve: &ReserveAccounts,
        config: FixedTermBorrowRolloverConfig,
    ) -> Result<(), BanksClientError> {
        let FixedTermBorrowRolloverConfig {
            auto_rollover_enabled,
            open_term_allowed,
            migration_to_fixed_enabled,
            alignment_padding: _,
            max_borrow_rate_bps,
            min_debt_term_seconds,
        } = config;

        fn borsh_serialize(value: impl BorshSerialize) -> Vec<u8> {
            value.try_to_vec().unwrap()
        }

        let opt_in_updates = vec![
            (
                UpdateObligationConfigMode::FixedTermRolloverEnabled,
                borsh_serialize(auto_rollover_enabled),
            ),
            (
                UpdateObligationConfigMode::MigrationToFixedEnabled,
                borsh_serialize(migration_to_fixed_enabled),
            ),
        ];
        let criteria_updates = vec![
            (
                UpdateObligationConfigMode::FixedTermRolloverMaxBorrowRateBps,
                borsh_serialize(max_borrow_rate_bps),
            ),
            (
                UpdateObligationConfigMode::FixedTermRolloverMinDebtTermSeconds,
                borsh_serialize(min_debt_term_seconds),
            ),
            (
                UpdateObligationConfigMode::FixedTermRolloverOpenTermAllowed,
                borsh_serialize(open_term_allowed),
            ),
        ];

        // If we are enabling it, then the criteria need to be set first:
        let ordered_updates =
            if auto_rollover_enabled == true as u8 || migration_to_fixed_enabled == true as u8 {
                [criteria_updates, opt_in_updates].concat()
            } else {
                [opt_in_updates, criteria_updates].concat()
            };

        let ixs: Vec<_> = ordered_updates
            .into_iter()
            .map(|(mode, value)| {
                instructions::update_obligation_config_ix(
                    market.market.pubkey(),
                    borrower.owner.pubkey(),
                    borrower.obligation,
                    None,
                    Some(borrow_reserve.pubkey()),
                    mode,
                    value,
                )
            })
            .collect();

        let tx = self
            .create_transaction_with_payer(ixs, &borrower.owner)
            .await;
        send_transaction!(self, tx)
    }

    pub async fn get_obligation_single_farms_accounts(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        farm_kind: ReserveFarmKind,
        obligation_address: &Pubkey,
    ) -> OptionalObligationFarmsAccounts {
        let reserve: Reserve = self.get_reserve(reserve_accounts).await;
        let reserve_farm_state_pk = reserve.get_farm(farm_kind);
        if reserve_farm_state_pk != Pubkey::default() {
            let obligation_farm_user_state =
                get_farms_user_state_account(&reserve_farm_state_pk, obligation_address);
            OptionalObligationFarmsAccounts {
                obligation_farm_user_state: Some(obligation_farm_user_state),
                reserve_farm_state: Some(reserve_farm_state_pk),
            }
        } else {
            OptionalObligationFarmsAccounts {
                obligation_farm_user_state: None,
                reserve_farm_state: None,
            }
        }
    }

    pub async fn get_obligation_farms_accounts(
        &mut self,
        reserve_accounts_and_farm_kind: &[(&ReserveAccounts, ReserveFarmKind)],
        obligation_address: &Pubkey,
    ) -> Vec<OptionalObligationFarmsAccounts> {
        let mut result = Vec::with_capacity(reserve_accounts_and_farm_kind.len());
        for (reserve_accounts, farm_kind) in reserve_accounts_and_farm_kind {
            result.push(
                self.get_obligation_single_farms_accounts(
                    reserve_accounts,
                    *farm_kind,
                    obligation_address,
                )
                .await,
            );
        }
        result
    }

    pub async fn wrap_obligation_instruction_with_refreshes(
        &mut self,
        reserve_accts: &[&ReserveAccounts],
        farm_modes: &[ReserveFarmKind],
        obligation_address: &Pubkey,
        owner: &Arc<Keypair>,
        payer: &Arc<Keypair>,
    ) -> (Vec<InstructionBlocks>, Vec<InstructionBlocks>) {
        // If has farms, also do init farm obligations
        // Always do refresh_reserve
        // Always do refresh_obligation
        // If has farms and we don't use v2 instructions, also do refresh farms
        // Then this ix
        // If has farms, also do refresh farms

        let include_farms_refresh = !self.use_instructions_v2;

        let mut pre_instructions = vec![];
        let mut post_instructions = vec![];

        let obligation: Obligation = self.get_obligation(*obligation_address).await;
        let (deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let mut unique_reserves = deposit_reserves
            .iter()
            .chain(borrow_reserves.iter())
            .filter_map(|x| *x)
            .collect::<Vec<Pubkey>>();
        unique_reserves.sort();
        unique_reserves.dedup();

        // TODO: These could be duplicated if we have the instruction reserve already contained in the obligation
        let instruction_reserves = reserve_accts
            .iter()
            .map(|x| x.address.pubkey())
            .collect::<Vec<Pubkey>>();

        // 1. Build init_obligation_farm if necessary
        for reserve_accounts in reserve_accts {
            let reserve: Reserve = self.get_reserve(reserve_accounts).await;

            let farm_debt = reserve.get_farm(ReserveFarmKind::Debt);
            let farm_collateral = reserve.get_farm(ReserveFarmKind::Collateral);

            let obligation_farm_debt = get_farms_user_state_account(&farm_debt, obligation_address);
            let obligation_farm_coll =
                get_farms_user_state_account(&farm_collateral, obligation_address);

            if farm_debt != Pubkey::default()
                && self
                    .get_account(obligation_farm_debt)
                    .await
                    .unwrap()
                    .is_none()
            {
                let init_obligation_farm_ix = instructions::init_obligation_farm_for_reserve_ix(
                    reserve_accounts,
                    &farm_debt,
                    obligation_address,
                    owner,
                    payer,
                    ReserveFarmKind::Debt,
                );
                pre_instructions.push(init_obligation_farm_ix.clone());
            }

            if farm_collateral != Pubkey::default()
                && self
                    .get_account(obligation_farm_coll)
                    .await
                    .unwrap()
                    .is_none()
            {
                let init_obligation_farm_ix = instructions::init_obligation_farm_for_reserve_ix(
                    reserve_accounts,
                    &farm_collateral,
                    obligation_address,
                    owner,
                    payer,
                    ReserveFarmKind::Collateral,
                );
                pre_instructions.push(init_obligation_farm_ix.clone());
            }
        }

        // 2. Build Refresh Reserve (for the non-instruction reserves - i.e. deposit, borrow)
        for reserve_acc in unique_reserves {
            if instruction_reserves.contains(&reserve_acc) {
                continue;
            }
            let reserve: Reserve = state::get::<Reserve>(self, reserve_acc).await;
            let refresh_reserve_ix =
                instructions::refresh_reserve_ix(reserve, &reserve_acc, payer.clone());
            pre_instructions.push(refresh_reserve_ix);
        }

        // 3. Build Refresh Reserve (for the current instruction - i.e. deposit, borrow)
        for reserve_acc in instruction_reserves {
            let reserve: Reserve = state::get::<Reserve>(self, reserve_acc).await;
            let refresh_reserve_ix =
                instructions::refresh_reserve_ix(reserve, &reserve_acc, payer.clone());
            pre_instructions.push(refresh_reserve_ix);
        }

        // 4. Build Refresh Obligation
        let refresh_obligation_ix = instructions::refresh_obligation_ix(
            obligation.lending_market,
            *obligation_address,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            payer.clone(),
        );

        pre_instructions.push(refresh_obligation_ix);

        if include_farms_refresh {
            for (reserve_account, farm_mode) in reserve_accts.iter().zip(farm_modes.iter()) {
                let reserve: Reserve = self.get_reserve(reserve_account).await;

                let farm = reserve.get_farm(*farm_mode);

                // 5.1 Build Refresh Obligation Farms
                if farm != Pubkey::default() {
                    let refresh_farms_ix = instructions::refresh_obligation_farm_for_reserve_ix(
                        reserve_account,
                        farm,
                        *obligation_address,
                        payer,
                        *farm_mode,
                    );

                    println!("pre_ixs refresh_obligation_farms {:?}", farm);

                    pre_instructions.push(refresh_farms_ix.clone());
                    post_instructions.push(refresh_farms_ix);
                }
            }
        }
        (pre_instructions, post_instructions)
    }

    pub async fn deposit_reserve_liquidity_and_obligation_collateral(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
    ) -> Result<(), BanksClientError> {
        self.execute_deposit_reserve_liquidity_and_obligation_collateral(
            reserve_accounts,
            depositor,
            obligation,
            liquidity_amount,
            None,
        )
        .await
    }

    pub async fn deposit_reserve_liquidity_and_obligation_collateral_permissioned(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        self.execute_deposit_reserve_liquidity_and_obligation_collateral(
            reserve_accounts,
            depositor,
            obligation,
            liquidity_amount,
            Some(market_permissioner),
        )
        .await
    }

    pub async fn refresh_obligation_farms(&mut self, depositor: &BorrowerAccounts) {
        let obligation: Obligation = self.get_obligation(depositor.obligation).await;

        let (deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let refresh_ix = instructions::refresh_obligation_ix(
            obligation.lending_market,
            depositor.obligation,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            depositor.owner.clone(),
        );

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[],
                &[],
                &depositor.obligation,
                &depositor.owner.clone(),
                &depositor.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(refresh_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let tx = self
            .create_transaction_with_payer(instructions, &depositor.owner)
            .await;

        println!("SendingTx: RefreshObligation",);
        send_transaction!(self, tx).unwrap()
    }

    pub async fn withdraw_obligation_collateral(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        withdrawer: &DepositorAccounts,
        obligation: &Pubkey,
        collateral_amount: u64,
    ) -> Result<(), BanksClientError> {
        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Collateral,
                obligation,
            )
            .await;

        let withdraw_ix = maybe_v2_ix!(
            self,
            farms_accounts,
            withdraw_obligation_collateral(
                reserve_accounts,
                withdrawer,
                obligation,
                collateral_amount,
            )
        );

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Collateral],
                obligation,
                &withdrawer.owner.clone(),
                &withdrawer.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(withdraw_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let tx = self
            .create_transaction_with_payer(instructions, &withdrawer.owner)
            .await;

        println!(
            "SendingTx: WithdrawObligationCollateral amount: {}",
            collateral_amount
        );
        send_transaction!(self, tx)
    }

    pub async fn borrow_obligation_liquidity(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &DepositorAccounts,
        obligation_address: &Pubkey,
        liquidity_amount: u64,
    ) -> Result<(), BanksClientError> {
        self.execute_borrow_obligation_liquidity(
            market_accounts,
            reserve_accounts,
            borrower,
            obligation_address,
            liquidity_amount,
            None,
        )
        .await
    }

    pub async fn borrow_obligation_liquidity_permissioned(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &DepositorAccounts,
        obligation_address: &Pubkey,
        liquidity_amount: u64,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        self.execute_borrow_obligation_liquidity(
            market_accounts,
            reserve_accounts,
            borrower,
            obligation_address,
            liquidity_amount,
            Some(market_permissioner),
        )
        .await
    }

    pub async fn redeem_reserve_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        collateral_amount: u64,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::redeem_reserve_collateral(
            self,
            market_accounts,
            reserve_accounts,
            depositor,
            collateral_amount,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn repay_obligation_liquidity(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &DepositorAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
    ) -> Result<(), BanksClientError> {
        let obligation_acc: Obligation = self.get_obligation(*obligation).await;
        let (deposit_reserves, _, _) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation_acc)
            .await;

        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Debt,
                obligation,
            )
            .await;

        let repay_ix = maybe_v2_ix!(
            self,
            farms_accounts,
            repay_obligation_liquidity(
                market_accounts,
                reserve_accounts,
                borrower,
                obligation,
                liquidity_amount,
                &deposit_reserves,
            )
        );

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Debt],
                obligation,
                &borrower.owner.clone(),
                &borrower.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(repay_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let tx = self
            .create_transaction_with_payer(instructions, &borrower.owner)
            .await;

        println!(
            "SendingTx: RepayObligationLiquidity amount: {}",
            liquidity_amount
        );
        send_transaction!(self, tx)
    }

    pub async fn withdraw_obligation_collateral_and_redeem_reserve_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        collateral_amount: u64,
    ) -> Result<(), BanksClientError> {
        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Collateral,
                obligation,
            )
            .await;

        let withdraw_ix = maybe_v2_ix!(
            self,
            farms_accounts,
            withdraw_obligation_collateral_and_redeem_reserve_collateral(
                market_accounts,
                reserve_accounts,
                depositor,
                obligation,
                collateral_amount
            )
        );

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Collateral],
                obligation,
                &depositor.owner.clone(),
                &depositor.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(withdraw_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let tx = self
            .create_transaction_with_payer(instructions, &depositor.owner)
            .await;

        println!(
            "SendingTx: WithdrawObligationCollateralAndRedeemReserveCollateral amount: {}",
            collateral_amount
        );
        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn repay_and_withdraw_and_redeem_ixs(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        repay_reserve_accounts: &ReserveAccounts,
        withdraw_reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        obligation: &Pubkey,
        repay_amount: u64,
        withdraw_amount: u64,
    ) -> Result<Vec<Instruction>, BanksClientError> {
        let obligation_acc: Obligation = self.get_obligation(*obligation).await;
        let (deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation_acc)
            .await;

        let farms_accounts = self
            .get_obligation_farms_accounts(
                &[
                    (repay_reserve_accounts, ReserveFarmKind::Debt),
                    (withdraw_reserve_accounts, ReserveFarmKind::Collateral),
                ],
                obligation,
            )
            .await;

        let repay_and_withdraw_ix = repay_and_withdraw_and_redeem_ix(
            market_accounts,
            repay_reserve_accounts,
            withdraw_reserve_accounts,
            borrower,
            borrower,
            repay_amount,
            withdraw_amount,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            farms_accounts[0],
            farms_accounts[1],
        );

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[repay_reserve_accounts, withdraw_reserve_accounts],
                &[ReserveFarmKind::Debt, ReserveFarmKind::Collateral],
                obligation,
                &borrower.owner.clone(),
                &borrower.owner.clone(),
            )
            .await;

        let mut instructions = Vec::<Instruction>::new();
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(repay_and_withdraw_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }
        Ok(instructions)
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn repay_and_withdraw_and_redeem(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        repay_reserve_accounts: &ReserveAccounts,
        withdraw_reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        obligation: &Pubkey,
        repay_amount: u64,
        withdraw_amount: u64,
    ) -> Result<(), BanksClientError> {
        let instructions = self
            .repay_and_withdraw_and_redeem_ixs(
                market_accounts,
                repay_reserve_accounts,
                withdraw_reserve_accounts,
                borrower,
                obligation,
                repay_amount,
                withdraw_amount,
            )
            .await?;

        let tx = self
            .create_transaction_with_payer(instructions, &borrower.owner)
            .await;

        println!(
            "SendingTx: RepayAndWithdraw repay_amount: {}, withdraw_amount: {}",
            repay_amount, withdraw_amount
        );
        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn deposit_and_withdraw_and_redeem(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        deposit_reserve_accounts: &ReserveAccounts,
        withdraw_reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
        withdraw_amount: u64,
    ) -> Result<(), BanksClientError> {
        self.execute_deposit_and_withdraw_and_redeem(
            market_accounts,
            deposit_reserve_accounts,
            withdraw_reserve_accounts,
            borrower,
            obligation,
            liquidity_amount,
            withdraw_amount,
            None,
        )
        .await
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn deposit_and_withdraw_and_redeem_permissioned(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        deposit_reserve_accounts: &ReserveAccounts,
        withdraw_reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
        withdraw_amount: u64,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        self.execute_deposit_and_withdraw_and_redeem(
            market_accounts,
            deposit_reserve_accounts,
            withdraw_reserve_accounts,
            borrower,
            obligation,
            liquidity_amount,
            withdraw_amount,
            Some(market_permissioner),
        )
        .await
    }

    pub async fn enqueue_to_withdraw(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor_accounts: &DepositorAccounts,
        collateral_amount: u64,
    ) -> Result<WithdrawTicket, BanksClientError> {
        let ticket_sequence_number = self
            .get_reserve(reserve_accounts)
            .await
            .withdraw_queue
            .next_issued_ticket_sequence_number;
        let tx = instructions::enqueue_to_withdraw(
            self,
            market_accounts,
            reserve_accounts,
            &depositor_accounts.owner,
            ticket_sequence_number,
            depositor_accounts.collateral,
            depositor_accounts.liquidity,
            pda::owner_queued_collateral_vault(
                reserve_accounts.pubkey(),
                depositor_accounts.owner.pubkey(),
            ),
            collateral_amount,
            ProgressCallbackConfig::none(),
        )
        .await;
        send_transaction!(self, tx)?;
        Ok(self
            .get_withdraw_ticket(reserve_accounts, ticket_sequence_number)
            .await)
    }

    pub async fn withdraw_queued_liquidity(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        payer: &Keypair,
    ) -> Result<bool, BanksClientError> {
        let ticket_sequence_number = self
            .get_reserve(reserve_accounts)
            .await
            .withdraw_queue
            .next_withdrawable_ticket_sequence_number;
        let ticket_address =
            pda::withdraw_ticket(reserve_accounts.pubkey(), ticket_sequence_number);
        let ticket = state::get::<WithdrawTicket>(self, ticket_address).await;
        let tx = instructions::withdraw_queued_liquidity(
            self,
            market_accounts,
            reserve_accounts,
            payer,
            ticket_sequence_number,
            ticket.user_destination_liquidity_ta,
            ticket.owner,
            ProgressCallbackConfig::for_withdraw_queued_liquidity(&ticket),
        )
        .await;
        send_transaction!(self, tx)?;

        // In theory, the withdraw_queued_liquidity handler uses a return data to surface whether
        // the withdraw was successful OR the ticket got marked as invalid. However, there is no
        // guarantee that this ix is last in the tx, so here we have to discover it ourselves:
        let ticket = state::try_get::<WithdrawTicket>(self, ticket_address).await;
        let ticket_valid = match ticket {
            Ok(ticket) => ticket.invalid == 0, // ticket still exists, and we can inspect whether it was marked as invalid
            Err(err) => matches!(err, TestError::AccountNotFound), // ticket account got closed - this means it got fully redeemed, so must have been valid
        };
        Ok(ticket_valid)
    }

    pub async fn recover_invalid_ticket_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        owner: &DepositorAccounts,
        ticket_sequence_number: u64,
        payer: &Keypair,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::recover_invalid_ticket_collateral(
            self,
            market_accounts,
            reserve_accounts,
            payer,
            ticket_sequence_number,
            owner.collateral,
            owner.owner.pubkey(),
        )
        .await;
        send_transaction!(self, tx)
    }

    pub async fn cancel_withdraw_ticket(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor_accounts: &DepositorAccounts,
        ticket_sequence_number: u64,
        collateral_amount_to_cancel: u64,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::cancel_withdraw_ticket(
            self,
            market_accounts,
            reserve_accounts,
            &depositor_accounts.owner,
            ticket_sequence_number,
            depositor_accounts.collateral,
            collateral_amount_to_cancel,
        )
        .await;
        send_transaction!(self, tx)
    }

    pub async fn refresh_reserve(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        payer: Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let reserve = self.get_reserve(reserve_accounts).await;
        let tx = instructions::refresh_reserve(self, reserve, reserve_accounts, payer).await;

        send_transaction!(self, tx)
    }

    pub async fn refresh_reserves_batch(
        &mut self,
        reserves_accounts: impl Iterator<Item = &ReserveAccounts>,
        skip_price_updates: bool,
        payer: Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let mut reserves = Vec::new();
        for reserve_accounts in reserves_accounts {
            let reserve = self.get_reserve(reserve_accounts).await;
            reserves.push((reserve_accounts.address.pubkey(), reserve));
        }
        let tx =
            instructions::refresh_reserves_batch(self, reserves.iter(), skip_price_updates, payer)
                .await;

        send_transaction!(self, tx)
    }

    pub async fn get_obligation_reserves_and_referrer_token_states(
        &mut self,
        obligation: &Obligation,
    ) -> (
        Vec<Option<Pubkey>>,
        Vec<Option<Pubkey>>,
        Vec<Option<Pubkey>>,
    ) {
        let deposit_reserves: Vec<Option<Pubkey>> = obligation
            .active_deposits()
            .map(|x| Some(x.deposit_reserve))
            .collect();

        let borrow_reserves: Vec<Option<Pubkey>> = obligation
            .active_borrows()
            .map(|x| Some(x.borrow_reserve))
            .collect();

        let referrer_token_states: Vec<Option<Pubkey>> = if obligation.has_referrer() {
            let mut vec = Vec::with_capacity(borrow_reserves.len());

            for borrow_reserve in borrow_reserves.iter() {
                match borrow_reserve {
                    Some(borrow_reserve) => {
                        vec.push(Some(get_referrer_token_state_key(
                            &obligation.referrer,
                            borrow_reserve,
                        )));
                    }
                    None => {}
                }
            }
            vec
        } else {
            Vec::new()
        };

        (deposit_reserves, borrow_reserves, referrer_token_states)
    }

    pub async fn refresh_obligation(
        &mut self,
        market: Pubkey,
        obligation_address: Pubkey,
        payer: Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let mut ixns = vec![];
        let obligation: Obligation = self.get_obligation(obligation_address).await;

        let (deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let mut unique_reserves = deposit_reserves
            .iter()
            .chain(borrow_reserves.iter())
            .filter_map(|x| *x)
            .collect::<Vec<Pubkey>>();
        unique_reserves.sort();
        unique_reserves.dedup();

        for reserve_acc in unique_reserves {
            let reserve: Reserve = state::get::<Reserve>(self, reserve_acc).await;
            let refresh_reserve_ix =
                instructions::refresh_reserve_ix(reserve, &reserve_acc, payer.clone());
            ixns.push(refresh_reserve_ix.instruction);
        }

        let refresh_ix = instructions::refresh_obligation_ix(
            market,
            obligation_address,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            payer.clone(),
        );

        ixns.push(refresh_ix.instruction);

        let tx = self.create_transaction_with_payer(ixns, payer).await;

        send_transaction!(self, tx)
    }

    pub async fn request_elevation_group(
        &mut self,
        market: Pubkey,
        obligation_address: Pubkey,
        payer: &Arc<Keypair>,
        new_elevation_group: u8,
    ) -> Result<(), BanksClientError> {
        let mut ixns = vec![];
        let obligation: Obligation = self.get_obligation(obligation_address).await;
        let (deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let mut unique_reserves = deposit_reserves
            .iter()
            .chain(borrow_reserves.iter())
            .filter_map(|x| *x)
            .collect::<Vec<Pubkey>>();
        unique_reserves.sort();
        unique_reserves.dedup();

        for reserve_acc in unique_reserves {
            let reserve: Reserve = state::get::<Reserve>(self, reserve_acc).await;
            let refresh_reserve_ix =
                instructions::refresh_reserve_ix(reserve, &reserve_acc, payer.clone());
            ixns.push(refresh_reserve_ix.instruction);
        }

        let refresh_ix = instructions::refresh_obligation_ix(
            market,
            obligation_address,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            payer.clone(),
        );

        ixns.push(refresh_ix.instruction);

        let request_elevation_ix = instructions::request_elevation_group_ix(
            market,
            obligation_address,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            payer.clone(),
            new_elevation_group,
        );

        ixns.push(request_elevation_ix.instruction);

        let tx = self.create_transaction_with_payer(ixns, payer).await;

        send_transaction!(self, tx)
    }

    pub async fn refresh_state(
        &mut self,
        market: Pubkey,
        reserve_accounts: Vec<&ReserveAccounts>,
        obligation_address: Pubkey,
        payer: Arc<Keypair>,
    ) {
        for reserve_acc in reserve_accounts.iter() {
            let reserve = self.get_reserve(reserve_acc).await;
            let tx = instructions::refresh_reserve(self, reserve, reserve_acc, payer.clone()).await;

            self.process_transaction_with_commitment(
                tx,
                solana_sdk::commitment_config::CommitmentLevel::Processed,
            )
            .await
            .unwrap();
        }

        let obligation: Obligation = self.get_obligation(obligation_address).await;
        let (deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let tx = instructions::refresh_obligation(
            self,
            market,
            obligation_address,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            payer,
        )
        .await;

        self.process_transaction_with_commitment(tx, CommitmentLevel::Processed)
            .await
            .unwrap();
    }

    pub async fn set_obligation_order(
        &mut self,
        market: Pubkey,
        borrower: &dyn ObligationBorrower,
        index: usize,
        order: ObligationOrder,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::set_obligation_order(
            self,
            market,
            &borrower.get_owner(),
            borrower.get_obligation(),
            u8::try_from(index).unwrap(),
            order,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn set_borrow_order(
        &mut self,
        market: Pubkey,
        borrower: &dyn ObligationBorrower,
        reserve: Pubkey,
        order_config: BorrowOrderConfig,
    ) -> Result<(), BanksClientError> {
        let BorrowOrderConfig {
            debt_liquidity_mint,
            remaining_debt_amount,
            filled_debt_destination,
            max_borrow_rate_bps,
            min_debt_term_seconds,
            fillable_until_timestamp,
            enable_auto_rollover_on_filled_borrows,
        } = order_config;
        let tx = instructions::set_borrow_order(
            self,
            market,
            &borrower.get_owner(),
            borrower.get_obligation(),
            reserve,
            debt_liquidity_mint,
            filled_debt_destination,
            BorrowOrderConfigArgs {
                remaining_debt_amount,
                max_borrow_rate_bps,
                min_debt_term_seconds,
                fillable_until_timestamp,
                enable_auto_rollover_on_filled_borrows: enable_auto_rollover_on_filled_borrows != 0,
            },
            0,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn cancel_borrow_order(
        &mut self,
        market: Pubkey,
        borrower: &dyn ObligationBorrower,
        reserve: &ReserveAccounts,
    ) -> Result<(), BanksClientError> {
        // ATA must be valid even when cancelling (due to anchor's constraint reasons):
        let dummy_ata = create_ata_if_not_exists(
            self,
            &borrower.get_owner(),
            &reserve.liquidity_mint.pubkey(),
        )
        .await;

        let tx = instructions::set_borrow_order(
            self,
            market,
            &borrower.get_owner(),
            borrower.get_obligation(),
            reserve.pubkey(),
            reserve.liquidity_mint.pubkey(),
            dummy_ata,
            BorrowOrderConfigArgs::default(),
            0,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn fill_borrow_order(
        &mut self,
        lending_market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        payer: &Keypair,
    ) -> Result<(), BanksClientError> {
        self.execute_fill_borrow_order(
            lending_market_accounts,
            reserve_accounts,
            borrower,
            payer,
            None,
        )
        .await
    }

    pub async fn fill_borrow_order_permissioned(
        &mut self,
        lending_market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        payer: &Keypair,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        self.execute_fill_borrow_order(
            lending_market_accounts,
            reserve_accounts,
            borrower,
            payer,
            Some(market_permissioner),
        )
        .await
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn liquidate_obligation_and_redeem_reserve_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        collateral_reserve_accounts: &ReserveAccounts,
        debt_reserve_accounts: &ReserveAccounts,
        liquidator: &BorrowerAccounts,
        borrower: &dyn ObligationBorrower,
        liquidity_amount: u64,
        min_acceptable_received_liq_amount: u64,
    ) -> Result<(), BanksClientError> {
        self.execute_liquidate_obligation_and_redeem_reserve_collateral(
            market_accounts,
            collateral_reserve_accounts,
            debt_reserve_accounts,
            liquidator,
            borrower,
            liquidity_amount,
            min_acceptable_received_liq_amount,
            None,
        )
        .await
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn liquidate_obligation_and_redeem_reserve_collateral_permissioned(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        collateral_reserve_accounts: &ReserveAccounts,
        debt_reserve_accounts: &ReserveAccounts,
        liquidator: &BorrowerAccounts,
        borrower: &dyn ObligationBorrower,
        liquidity_amount: u64,
        min_acceptable_received_liq_amount: u64,
        market_permissioner: &KP,
    ) -> Result<(), BanksClientError> {
        self.execute_liquidate_obligation_and_redeem_reserve_collateral(
            market_accounts,
            collateral_reserve_accounts,
            debt_reserve_accounts,
            liquidator,
            borrower,
            liquidity_amount,
            min_acceptable_received_liq_amount,
            Some(market_permissioner),
        )
        .await
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn socialize_loss(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        emergency_council: Arc<Keypair>,
        borrower: &dyn ObligationBorrower,
        liquidity_amount: u64,
    ) -> Result<(), BanksClientError> {
        let obligation_address = borrower.get_obligation();
        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Debt,
                &obligation_address,
            )
            .await;

        let liquidate_ix = maybe_v2_ix!(
            self,
            farms_accounts,
            socialize_loss(
                market_accounts,
                reserve_accounts,
                obligation_address,
                liquidity_amount,
            )
        );

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Debt],
                &borrower.get_obligation(),
                &borrower.get_owner(),
                &emergency_council.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(liquidate_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let tx = self
            .create_transaction_with_payer(instructions, emergency_council)
            .await;

        println!(
            "SendingTx: SocializeLoss liquidity_amount: {}",
            liquidity_amount
        );
        send_transaction!(self, tx)
    }

    pub async fn mark_obligation_for_deleveraging(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        obligation: &Pubkey,
        autodeleverage_target_ltv_pct: u8,
    ) -> Result<(), BanksClientError> {
        let mark_ix = instructions::mark_obligation_for_deleveraging_ix(
            market_accounts,
            *obligation,
            autodeleverage_target_ltv_pct,
        );

        let tx = self.create_transaction_from_blocks(mark_ix).await;

        println!(
            "SendingTx: MarkObligationForDeleveraging autodeleverage_target_ltv_pct: {}",
            autodeleverage_target_ltv_pct
        );
        send_transaction!(self, tx)
    }

    pub async fn redeem_fees(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        payer: Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::redeem_fees(self, market_accounts, reserve_accounts, payer).await;

        send_transaction!(self, tx)
    }

    pub async fn withdraw_protocol_fees(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        amount: u64,
    ) -> Result<(), BanksClientError> {
        let tx =
            instructions::withdraw_protocol_fees(self, market_accounts, reserve_accounts, amount)
                .await;

        send_transaction!(self, tx)
    }

    pub async fn flash_loan(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &DepositorAccounts,
        amount: u64,
        borrow_ix_index: u8,
    ) -> Result<(), BanksClientError> {
        self.init_if_needed_referrer_token_state_for_reserve_mint(
            &borrower.owner,
            &market_accounts.market.pubkey(),
            &reserve_accounts.address.pubkey(),
            &borrower.referrer,
        )
        .await;
        let tx = instructions::flash_loan(
            self,
            market_accounts,
            reserve_accounts,
            borrower,
            amount,
            borrow_ix_index,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn init_user_metadata(
        &mut self,
        owner: &Arc<Keypair>,
        referrer: &Pubkey,
        user_lookup_table: &Pubkey,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_user_metadata(self, owner, referrer, user_lookup_table).await;

        send_transaction!(self, tx)
    }

    pub async fn init_referrer_token_state(
        &mut self,
        payer: &Arc<Keypair>,
        lending_market_address: &Pubkey,
        referrer: &Pubkey,
        reserve: &Pubkey,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_referrer_token_state(
            self,
            payer,
            lending_market_address,
            referrer,
            reserve,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn withdraw_referrer_fees(
        &mut self,
        lending_market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        referrer: &Arc<Keypair>,
        referrer_token_account: &Pubkey,
    ) -> Result<(), BanksClientError> {
        self.refresh_reserve(reserve_accounts, referrer.clone())
            .await
            .unwrap();

        let referrer_token_state =
            get_referrer_token_state_key(&referrer.pubkey(), &reserve_accounts.address.pubkey());

        let tx = instructions::withdraw_referrer_fees(
            self,
            lending_market_accounts,
            reserve_accounts,
            referrer,
            referrer_token_account,
            &referrer_token_state,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn init_referrer_state_and_short_url(
        &mut self,
        referrer: &Arc<Keypair>,
        short_url: &str,
        referrer_state: Pubkey,
        referrer_short_url: Pubkey,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::init_referrer_state_and_short_url(
            self,
            referrer,
            short_url,
            referrer_state,
            referrer_short_url,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn delete_referrer_state_and_short_url(
        &mut self,
        referrer: &Arc<Keypair>,
        referrer_state: Pubkey,
        referrer_short_url: Pubkey,
    ) -> Result<(), BanksClientError> {
        let tx = instructions::delete_referrer_state_and_short_url(
            self,
            referrer,
            referrer_state,
            referrer_short_url,
        )
        .await;

        send_transaction!(self, tx)
    }

    pub async fn init_if_needed_referrer_token_state_for_reserve_mint(
        &mut self,
        payer: &Arc<Keypair>,
        lending_market_address: &Pubkey,
        reserve: &Pubkey,
        referrer: &Pubkey,
    ) {
        let address = get_referrer_token_state_key(referrer, reserve);
        let referrer_token_state_result = state::try_get::<ReferrerTokenState>(self, address).await;

        match referrer_token_state_result {
            Ok(_) => {}
            Err(_) => {
                self.init_referrer_token_state(payer, lending_market_address, referrer, reserve)
                    .await
                    .unwrap();
            }
        }
    }

    pub async fn init_if_needed_user_metadata_for_user(
        &mut self,
        user: &Arc<Keypair>,
        referrer: &Pubkey,
    ) {
        let address = get_user_metadata_key(user.pubkey());
        let user_metadata_result = state::try_get::<UserMetadata>(self, address).await;

        match user_metadata_result {
            Ok(_) => {}
            Err(_) => {
                self.init_user_metadata(user, referrer, &Pubkey::default())
                    .await
                    .unwrap();
            }
        }
    }

    pub async fn get_lending_market(&mut self, market: Pubkey) -> LendingMarket {
        state::get::<LendingMarket>(self, market).await
    }

    pub async fn get_min_initial_deposit_amount(&mut self, market: &LendingMarketAccounts) -> u64 {
        let lending_market = self.get_lending_market(market.market.pubkey()).await;
        lending_market.min_initial_deposit_amount
    }

    pub async fn get_obligation(&mut self, obligation: Pubkey) -> Obligation {
        state::get::<Obligation>(self, obligation).await
    }

    pub async fn get_refreshed_obligation(
        &mut self,
        market: &LendingMarketAccounts,
        obligation_address: Pubkey,
        payer: Arc<Keypair>,
    ) -> Obligation {
        self.refresh_obligation(market.market.pubkey(), obligation_address, payer)
            .await
            .unwrap();
        state::get::<Obligation>(self, obligation_address).await
    }

    pub async fn get_reserve(&mut self, reserve: &ReserveAccounts) -> Reserve {
        state::get::<Reserve>(self, reserve.address.pubkey()).await
    }

    pub async fn get_withdraw_ticket(
        &mut self,
        reserve: &ReserveAccounts,
        sequence_number: u64,
    ) -> WithdrawTicket {
        state::get(
            self,
            pda::withdraw_ticket(reserve.pubkey(), sequence_number),
        )
        .await
    }

    pub async fn update_pyth_price(&mut self, pyth_price: &Pubkey, price: f64) {
        update_pyth_price(self, pyth_price, price).await;
    }

    pub async fn update_switchboard_price(&mut self, switchboard_price: &Pubkey, price: f64) {
        let clock = self.get_clock().await;
        update_switchboard_price_and_slot(self, switchboard_price, price, clock.slot).await;
    }

    pub async fn fast_forward_hours(&mut self, hours: u64) {
        self.fast_forward(Duration::from_secs(hours * 3600)).await
    }

    pub async fn fast_forward_minutes(&mut self, minutes: u64) {
        self.fast_forward(Duration::from_secs(minutes * 60)).await
    }

    pub async fn fast_forward_seconds(&mut self, seconds: u64) {
        self.fast_forward(Duration::from_secs(seconds)).await
    }

    pub async fn fast_forward_to(&mut self, timestamp: u64) {
        let timestamp = i64::try_from(timestamp).unwrap();
        let mut clock = self.get_clock().await;
        let difference_seconds = timestamp - clock.unix_timestamp;
        if difference_seconds < 0 {
            panic!("cannot go {} seconds back in time", difference_seconds);
        }
        clock.unix_timestamp = timestamp;
        clock.slot += difference_seconds as u64 * SLOTS_PER_SECOND;
        self.context.set_sysvar(&clock);
    }

    async fn fast_forward(&mut self, duration: Duration) {
        let mut clock = self.get_clock().await;
        clock.unix_timestamp += duration.as_secs() as i64;
        clock.slot += duration.as_secs() * SLOTS_PER_SECOND;
        self.context.set_sysvar(&clock);
    }

    pub async fn get_clock(&mut self) -> Clock {
        self.context.get_sysvar().await.unwrap()
    }
    pub async fn get_current_slot(&mut self) -> u64 {
        let clock: Clock = self.get_clock().await;
        clock.slot
    }

    pub async fn fast_forward_slots(&mut self, slots: u64) {
        let mut clock = self.get_clock().await;
        clock.unix_timestamp += (slots / SLOTS_PER_SECOND) as i64;
        clock.slot += slots;
        self.context.set_sysvar(&clock);
    }

    pub async fn advance_slot(&mut self) {
        println!("Advancing slot");
        let mut clock = self.get_clock().await;
        clock.slot += 1;
        self.context.set_sysvar(&clock);
    }

    pub async fn new_keypair(&mut self, min_lamports: u64) -> Arc<Keypair> {
        let account = Keypair::new();
        let payer = self.context.payer().insecure_clone();
        let transaction = self
            .create_transaction_with_payer_and_extra_signers(
                [system_instruction::create_account(
                    &payer.pubkey(),
                    &account.pubkey(),
                    min_lamports,
                    0,
                    &system_program::id(),
                )],
                payer,
                [&account],
            )
            .await;

        self.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
            .await
            .unwrap();

        Arc::new(account)
    }

    pub async fn mint_sol(&mut self, address: Pubkey, lamports: u64) {
        let account = self.get_account(address).await.unwrap().unwrap_or_default();
        let mut cloned_account = AccountSharedData::new(
            account.lamports + lamports,
            account.data.len(),
            &account.owner,
        );
        cloned_account.set_data(account.data);
        self.set_account(&address, cloned_account);
    }

    pub async fn set_account_data(&mut self, address: &Pubkey, data: &[u8]) {
        let account = self.get_account(*address).await.unwrap().unwrap();

        assert_eq!(
            account.data.len(),
            data.len(),
            "Account data length mismatch"
        );

        let mut new_account =
            AccountSharedData::new(account.lamports, account.data.len(), &account.owner);

        new_account.set_data(data.to_vec());

        self.set_account(address, new_account);
    }

    pub async fn clone_account(&mut self, previous_address: Pubkey, new_address: &Pubkey) {
        let account_to_clone = self.get_account(previous_address).await.unwrap().unwrap();
        let mut cloned_account = AccountSharedData::new(
            account_to_clone.lamports,
            account_to_clone.data.len(),
            &account_to_clone.owner,
        );
        cloned_account.set_data(account_to_clone.data);
        self.set_account(new_address, cloned_account);
    }

    pub async fn clone_account_data<T: ZeroCopy + Owner + Discriminator>(
        &mut self,
        account_to_clone: &T,
        new_address: &Pubkey,
    ) {
        let mut data_bytes = Vec::new();
        data_bytes.extend_from_slice(&T::discriminator());
        data_bytes.extend_from_slice(bytemuck::bytes_of(&account_to_clone.clone()));

        let mut cloned_account = AccountSharedData::new(u64::MAX, data_bytes.len(), &T::owner());
        cloned_account.set_data(data_bytes.to_vec());
        self.set_account(new_address, cloned_account);
    }

    /// Closes the given account idempotently and returns its previous value (or `None` if it did
    /// not exist).
    pub async fn close_account(
        &mut self,
        address: &Pubkey,
    ) -> Result<Option<Account>, BanksClientError> {
        let account = self.get_account(*address).await?;
        self.set_account(address, AccountSharedData::new(0, 0, &system_program::id()));
        Ok(account)
    }

    /// Directly sets an account.
    pub fn set_account(&mut self, address: &Pubkey, account: impl Into<AccountSharedData>) {
        self.context.set_account(*address, account.into())
    }

    pub async fn create_token_account(
        &mut self,
        account: &KP,
        mint: &Pubkey,
        owner: &Pubkey,
    ) -> Result<(), BanksClientError> {
        token_operations::create_token_account(
            self,
            self.initial_market_owner.clone(),
            account,
            mint,
            owner,
        )
        .await
    }

    pub async fn mint_info(&mut self, mint: &Pubkey) -> Mint {
        let account = self.get_account(*mint).await.unwrap().unwrap();
        Mint::unpack(&account.data).unwrap()
    }

    pub async fn get_balance(&mut self, token_account: &Pubkey) -> u64 {
        if let Some(acc) = self.get_account(*token_account).await.unwrap() {
            Self::get_token_balance(&acc.data)
        } else {
            0
        }
    }

    pub async fn get_sol_balance(&mut self, owner: Pubkey) -> u64 {
        self.context.get_balance(owner).await.unwrap()
    }

    pub async fn get_ata_balance(&mut self, user: &Pubkey, mint: &Pubkey) -> u64 {
        let token_program = get_token_program(self, mint).await;
        let ata = spl_associated_token_account::get_associated_token_address_with_program_id(
            user,
            mint,
            &token_program,
        );
        self.get_balance(&ata).await
    }

    fn check_data_len(data: &[u8], min_len: usize) -> Result<(), ProgramError> {
        if data.len() < min_len {
            Err(ProgramError::AccountDataTooSmall)
        } else {
            Ok(())
        }
    }

    pub async fn get_token_account_mint(&mut self, pk: Pubkey) -> Pubkey {
        let account = self.get_account(pk).await.unwrap().unwrap();

        Self::check_data_len(&account.data, spl_token::state::Account::get_packed_len()).unwrap();
        Pubkey::try_from(&account.data[..32]).unwrap()
    }

    pub async fn get_token_account_authority(&mut self, pk: Pubkey) -> Pubkey {
        let account = self.get_account(pk).await.unwrap().unwrap();

        Self::check_data_len(&account.data, spl_token::state::Account::get_packed_len()).unwrap();
        Pubkey::try_from(&account.data[32..64]).unwrap()
    }

    pub fn get_token_balance(data: &[u8]) -> u64 {
        Self::check_data_len(data, spl_token::state::Account::get_packed_len()).unwrap();
        let amount = array_ref![data, 64, 8];

        u64::from_le_bytes(*amount)
    }

    pub async fn get_account(&mut self, pk: Pubkey) -> Result<Option<Account>, BanksClientError> {
        self.context.get_account(pk).await
    }

    pub async fn get_program_accounts(
        &mut self,
        program_address: Pubkey,
    ) -> Result<Vec<(Pubkey, Account)>, BanksClientError> {
        self.context.get_program_accounts(program_address).await
    }

    /// Get a new latest blockhash, similar in spirit to RpcClient::get_latest_blockhash()
    pub async fn get_new_latest_blockhash(&mut self) -> Result<Hash, BanksClientError> {
        self.context.get_new_latest_blockhash().await
    }

    /// Calculates the minimum balance allowing for rent exemption of the given [ZeroCopy] account.
    pub fn get_rent_zero_copy<T: ZeroCopy>(&self) -> u64 {
        self.get_rent(std::mem::size_of::<T>() + 8)
    }

    /// Calculates the minimum balance allowing for rent exemption of an account of the given size.
    pub fn get_rent(&self, data_size: usize) -> u64 {
        self.rent.minimum_balance(data_size)
    }

    pub async fn create_transaction_from_blocks(
        &mut self,
        blocks: InstructionBlocks,
    ) -> Transaction {
        let InstructionBlocks {
            instruction,
            payer,
            signers,
        } = blocks;
        self.create_transaction_with_payer_and_signers([instruction], payer, signers)
            .await
    }

    pub async fn create_transaction_by_context_payer(
        &mut self,
        ixs: impl IntoIterator<Item = Instruction>,
    ) -> Transaction {
        self.create_transaction_with_payer(ixs, self.context.payer().insecure_clone())
            .await
    }

    pub async fn create_transaction_by_market_owner(
        &mut self,
        ixs: impl IntoIterator<Item = Instruction>,
    ) -> Transaction {
        self.create_transaction_with_payer(ixs, self.initial_market_owner.clone())
            .await
    }

    pub async fn create_transaction_with_payer(
        &mut self,
        ixs: impl IntoIterator<Item = Instruction>,
        payer: impl JustRef<Keypair>,
    ) -> Transaction {
        self.create_transaction_with_payer_and_extra_signers(ixs, payer, Vec::<Keypair>::new())
            .await
    }

    pub async fn create_transaction_with_payer_and_extra_signers(
        &mut self,
        ixs: impl IntoIterator<Item = Instruction>,
        payer: impl JustRef<Keypair>,
        extra_signers: impl IntoIterator<Item = impl JustRef<Keypair>>,
    ) -> Transaction {
        self.create_transaction_with_payer_and_signers(
            ixs,
            payer.just_ref().pubkey(),
            iter::once(payer.just_ref()).chain(
                Vec::from_iter(extra_signers)
                    .iter()
                    .map(|signer| signer.just_ref()),
            ),
        )
        .await
    }

    pub async fn create_transaction_with_payer_and_signers(
        &mut self,
        ixs: impl IntoIterator<Item = Instruction>,
        payer: Pubkey,
        signers: impl IntoIterator<Item = impl JustRef<Keypair>>,
    ) -> Transaction {
        // Append a makeshift "nonce" instruction (a ComputeBudget ix with a varying value), so that
        // we can execute multiple (potentially same) txs without waiting for next blockhash. We
        // choose the ComputeBudget program so that we are not blocked by "only budget ixs allowed
        // besides the business ix". And we choose the rare set_loaded_accounts_data_size_limit ix
        // so that we do not interfere with actually-used budgeting ixs.
        let mut ixs = Vec::from_iter(ixs);
        ixs.push(
            ComputeBudgetInstruction::set_loaded_accounts_data_size_limit(
                1_000000000 + self.tx_counter as u32, // we can easily get an ix-counter out of this (value must be high, because program sizes count too!)
            ),
        );
        self.tx_counter = self
            .tx_counter
            .checked_add(1)
            .expect("more than u16::MAX txs in a single test");
        Transaction::new_signed_with_payer(
            ixs.as_slice(),
            Some(&payer),
            &Vec::from_iter(signers)
                .iter()
                .map(|signer| signer.just_ref())
                .collect::<Vec<_>>(),
            self.get_new_latest_blockhash().await.unwrap(),
        )
    }

    pub async fn process_transaction(
        &mut self,
        transaction: impl Into<VersionedTransaction>,
    ) -> Result<(), BanksClientError> {
        self.context
            .process_transaction_with_commitment(transaction.into(), CommitmentLevel::default())
            .await
    }

    pub async fn process_transaction_with_commitment(
        &mut self,
        transaction: impl Into<VersionedTransaction>,
        commitment: CommitmentLevel,
    ) -> Result<(), BanksClientError> {
        self.context
            .process_transaction_with_commitment(transaction.into(), commitment)
            .await
    }

    async fn execute_borrow_obligation_liquidity(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &DepositorAccounts,
        obligation_address: &Pubkey,
        liquidity_amount: u64,
        market_permissioner: Option<&KP>,
    ) -> Result<(), BanksClientError> {
        let obligation: Obligation = self.get_obligation(*obligation_address).await;
        let (deposit_reserves, _, _) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Debt,
                obligation_address,
            )
            .await;

        let mut borrow_ix = if market_permissioner.is_some() || self.use_instructions_v2 {
            instructions::borrow_obligation_liquidity_v2_ix(
                market_accounts,
                reserve_accounts,
                borrower,
                obligation_address,
                &deposit_reserves,
                liquidity_amount,
                farms_accounts,
            )
            .instruction
        } else {
            maybe_v2_ix!(
                self,
                farms_accounts,
                borrow_obligation_liquidity(
                    market_accounts,
                    reserve_accounts,
                    borrower,
                    obligation_address,
                    &deposit_reserves,
                    liquidity_amount,
                )
            )
            .instruction
        };

        // Add the market permissioner if provided
        if let Some(permissioner) = market_permissioner {
            borrow_ix
                .accounts
                .push(AccountMeta::new_readonly(permissioner.pubkey(), true));
        }

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Debt],
                obligation_address,
                &borrower.owner.clone(),
                &borrower.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        instructions.extend(pre_instructions.into_iter().map(|ix| ix.instruction));
        instructions.push(borrow_ix);
        instructions.extend(post_instructions.into_iter().map(|ix| ix.instruction));

        let extra_signers: Vec<KP> = market_permissioner
            .map(|p| vec![p.clone()])
            .unwrap_or_default();

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                instructions,
                &borrower.owner,
                extra_signers,
            )
            .await;

        println!(
            "SendingTx: BorrowObligationLiquidity amount: {}",
            liquidity_amount
        );
        send_transaction!(self, tx)
    }

    async fn execute_deposit_reserve_liquidity_and_obligation_collateral(
        &mut self,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
        market_permissioner: Option<&KP>,
    ) -> Result<(), BanksClientError> {
        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Collateral,
                obligation,
            )
            .await;

        let mut deposit_ix = maybe_v2_ix!(
            self,
            farms_accounts,
            deposit_reserve_liquidity_and_obligation_collateral(
                reserve_accounts,
                depositor,
                obligation,
                liquidity_amount,
            )
        );

        // Add the market permissioner if provided
        if let Some(permissioner) = market_permissioner {
            deposit_ix
                .instruction
                .accounts
                .push(AccountMeta::new_readonly(permissioner.pubkey(), true));
        }

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Collateral],
                obligation,
                &depositor.owner.clone(),
                &depositor.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        instructions.extend(pre_instructions.into_iter().map(|ix| ix.instruction));
        instructions.push(deposit_ix.instruction);
        instructions.extend(post_instructions.into_iter().map(|ix| ix.instruction));

        let extra_signers: Vec<KP> = market_permissioner
            .map(|p| vec![p.clone()])
            .unwrap_or_default();

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                instructions,
                &depositor.owner,
                extra_signers,
            )
            .await;

        println!(
            "SendingTx: DepositReserveLiquidityAndObligationCollateral liquidity_amount: {}",
            liquidity_amount
        );
        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    async fn execute_deposit_and_withdraw_and_redeem(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        deposit_reserve_accounts: &ReserveAccounts,
        withdraw_reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        obligation: &Pubkey,
        liquidity_amount: u64,
        withdraw_amount: u64,
        market_permissioner: Option<&KP>,
    ) -> Result<(), BanksClientError> {
        let obligation_acc: Obligation = self.get_obligation(*obligation).await;
        let (mut deposit_reserves, borrow_reserves, referrer_token_states) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation_acc)
            .await;
        if !deposit_reserves.contains(&Some(deposit_reserve_accounts.address.pubkey())) {
            deposit_reserves.push(Some(deposit_reserve_accounts.address.pubkey()));
        }
        let farms_accounts = self
            .get_obligation_farms_accounts(
                &[
                    (deposit_reserve_accounts, ReserveFarmKind::Collateral),
                    (withdraw_reserve_accounts, ReserveFarmKind::Collateral),
                ],
                obligation,
            )
            .await;

        let mut deposit_and_withdraw_ix = instructions::deposit_and_withdraw_and_redeem_ix(
            market_accounts,
            market_accounts,
            deposit_reserve_accounts,
            withdraw_reserve_accounts,
            borrower,
            obligation,
            borrower,
            obligation,
            liquidity_amount,
            withdraw_amount,
            &deposit_reserves,
            &borrow_reserves,
            &referrer_token_states,
            &farms_accounts,
        );

        // Add the market permissioner if provided
        if let Some(permissioner) = market_permissioner {
            deposit_and_withdraw_ix
                .instruction
                .accounts
                .push(AccountMeta::new_readonly(permissioner.pubkey(), true));
        }

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[deposit_reserve_accounts, withdraw_reserve_accounts],
                &[ReserveFarmKind::Collateral, ReserveFarmKind::Collateral],
                obligation,
                &borrower.owner.clone(),
                &borrower.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        instructions.extend(pre_instructions.into_iter().map(|ix| ix.instruction));
        instructions.push(deposit_and_withdraw_ix.instruction);
        instructions.extend(post_instructions.into_iter().map(|ix| ix.instruction));

        let extra_signers: Vec<KP> = market_permissioner
            .map(|p| vec![p.clone()])
            .unwrap_or_default();

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                instructions,
                &borrower.owner,
                extra_signers,
            )
            .await;

        println!(
            "SendingTx: DepositAndWithdraw liquidity_amount: {}, withdraw_amount: {}",
            liquidity_amount, withdraw_amount
        );
        send_transaction!(self, tx)
    }

    async fn execute_fill_borrow_order(
        &mut self,
        lending_market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        borrower: &BorrowerAccounts,
        payer: &Keypair,
        market_permissioner: Option<&KP>,
    ) -> Result<(), BanksClientError> {
        let mut fill_ix = instructions::fill_borrow_order_ix(
            lending_market_accounts,
            reserve_accounts,
            &borrower.borrower_accounts,
            &borrower.obligation,
            &[Some(borrower.depositor_accounts.reserve)],
            None,
            payer,
        );

        // Add the market permissioner if provided
        if let Some(permissioner) = market_permissioner {
            fill_ix
                .instruction
                .accounts
                .push(AccountMeta::new_readonly(permissioner.pubkey(), true));
        }

        let extra_signers: Vec<KP> = market_permissioner
            .map(|p| vec![p.clone()])
            .unwrap_or_default();

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                [fill_ix.instruction],
                payer,
                extra_signers,
            )
            .await;

        send_transaction!(self, tx)
    }

    async fn execute_deposit_obligation_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        reserve_accounts: &ReserveAccounts,
        depositor: &DepositorAccounts,
        obligation: &Pubkey,
        collateral_amount: u64,
        market_permissioner: Option<&KP>,
    ) -> Result<(), BanksClientError> {
        let farms_accounts = self
            .get_obligation_single_farms_accounts(
                reserve_accounts,
                ReserveFarmKind::Collateral,
                obligation,
            )
            .await;

        let mut deposit_ix = maybe_v2_ix!(
            self,
            farms_accounts,
            deposit_obligation_collateral(
                market_accounts,
                reserve_accounts,
                depositor,
                obligation,
                collateral_amount,
            )
        );

        // Add the market permissioner if provided
        if let Some(permissioner) = market_permissioner {
            deposit_ix
                .instruction
                .accounts
                .push(AccountMeta::new_readonly(permissioner.pubkey(), true));
        }

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[reserve_accounts],
                &[ReserveFarmKind::Collateral],
                obligation,
                &depositor.owner.clone(),
                &depositor.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(deposit_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let extra_signers: Vec<KP> = market_permissioner
            .map(|p| vec![p.clone()])
            .unwrap_or_default();

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                instructions,
                &depositor.owner,
                extra_signers,
            )
            .await;

        println!(
            "SendingTx: DepositObligationCollateral collateral_amount: {}",
            collateral_amount
        );
        send_transaction!(self, tx)
    }

    #[allow(clippy::too_many_arguments)]
    async fn execute_liquidate_obligation_and_redeem_reserve_collateral(
        &mut self,
        market_accounts: &LendingMarketAccounts,
        collateral_reserve_accounts: &ReserveAccounts,
        debt_reserve_accounts: &ReserveAccounts,
        liquidator: &BorrowerAccounts,
        borrower: &dyn ObligationBorrower,
        liquidity_amount: u64,
        min_acceptable_received_liq_amount: u64,
        market_permissioner: Option<&KP>,
    ) -> Result<(), BanksClientError> {
        let obligation_address = borrower.get_obligation();
        let obligation: Obligation = self.get_obligation(obligation_address).await;
        let (deposit_reserves, _, _) = self
            .get_obligation_reserves_and_referrer_token_states(&obligation)
            .await;

        let farms_accounts = self
            .get_obligation_farms_accounts(
                &[
                    (debt_reserve_accounts, ReserveFarmKind::Debt),
                    (collateral_reserve_accounts, ReserveFarmKind::Collateral),
                ],
                &obligation_address,
            )
            .await;

        let mut liquidate_ix = maybe_v2_ix!(
            self,
            &farms_accounts,
            liquidate_obligation_and_redeem_reserve_collateral(
                market_accounts,
                debt_reserve_accounts,
                collateral_reserve_accounts,
                liquidator,
                obligation_address,
                liquidity_amount,
                min_acceptable_received_liq_amount,
                0,
                &deposit_reserves
            )
        );

        // Add the market permissioner if provided
        if let Some(permissioner) = market_permissioner {
            liquidate_ix
                .instruction
                .accounts
                .push(AccountMeta::new_readonly(permissioner.pubkey(), true));
        }

        let (pre_instructions, post_instructions) = self
            .wrap_obligation_instruction_with_refreshes(
                &[collateral_reserve_accounts, debt_reserve_accounts],
                &[ReserveFarmKind::Collateral, ReserveFarmKind::Debt],
                &borrower.get_obligation(),
                &borrower.get_owner(),
                &liquidator.owner.clone(),
            )
            .await;

        let mut instructions = vec![];
        for ix in pre_instructions {
            instructions.push(ix.instruction);
        }
        instructions.push(liquidate_ix.instruction);
        for ix in post_instructions {
            instructions.push(ix.instruction);
        }

        let extra_signers: Vec<KP> = market_permissioner
            .map(|p| vec![p.clone()])
            .unwrap_or_default();

        let tx = self
            .create_transaction_with_payer_and_extra_signers(
                instructions,
                &liquidator.owner,
                extra_signers,
            )
            .await;

        println!(
            "SendingTx: LiquidateObligationAndRedeemReserveCollateral liquidity_amount: {}",
            liquidity_amount
        );
        send_transaction!(self, tx)
    }

    pub async fn initiate_obligation_ownership_transfer(
        &mut self,
        obligation: Pubkey,
        owner: &Arc<Keypair>,
        new_owner: Pubkey,
    ) -> Result<(), BanksClientError> {
        self.initiate_obligation_ownership_transfer_with_accounts(
            obligation,
            owner,
            new_owner,
            sysvar::instructions::id(),
        )
        .await
    }

    pub async fn initiate_obligation_ownership_transfer_with_accounts(
        &mut self,
        obligation: Pubkey,
        owner: &Arc<Keypair>,
        new_owner: Pubkey,
        instruction_sysvar_account: Pubkey,
    ) -> Result<(), BanksClientError> {
        let accounts = crate::accounts::InitiateObligationOwnershipTransfer {
            owner: owner.pubkey(),
            obligation,
            instruction_sysvar_account,
        };

        let instruction = solana_program::instruction::Instruction {
            program_id: crate::id(),
            accounts: anchor_lang::ToAccountMetas::to_account_metas(&accounts, None),
            data: anchor_lang::InstructionData::data(
                &crate::instruction::InitiateObligationOwnershipTransfer { new_owner },
            ),
        };

        let tx = self
            .create_transaction_with_payer([instruction], owner)
            .await;

        send_transaction!(self, tx)
    }

    pub async fn approve_obligation_ownership_transfer(
        &mut self,
        obligation: Pubkey,
        global_admin: &Arc<Keypair>,
        pending_owner: Pubkey,
    ) -> Result<(), BanksClientError> {
        self.approve_obligation_ownership_transfer_with_accounts(
            global_admin,
            pda::global_config(),
            obligation,
            pending_owner,
        )
        .await
    }

    pub async fn approve_obligation_ownership_transfer_with_accounts(
        &mut self,
        global_admin: &Arc<Keypair>,
        global_config: Pubkey,
        obligation: Pubkey,
        pending_owner: Pubkey,
    ) -> Result<(), BanksClientError> {
        let accounts = crate::accounts::ApproveObligationOwnershipTransfer {
            global_admin: global_admin.pubkey(),
            global_config,
            obligation,
            pending_owner,
        };

        let instruction = solana_program::instruction::Instruction {
            program_id: crate::id(),
            accounts: anchor_lang::ToAccountMetas::to_account_metas(&accounts, None),
            data: anchor_lang::InstructionData::data(
                &crate::instruction::ApproveObligationOwnershipTransfer {},
            ),
        };

        let tx = self
            .create_transaction_with_payer([instruction], global_admin)
            .await;

        send_transaction!(self, tx)
    }

    pub async fn abort_obligation_ownership_transfer(
        &mut self,
        obligation: Pubkey,
        owner: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        self.abort_obligation_ownership_transfer_with_accounts(
            obligation,
            owner,
            sysvar::instructions::id(),
        )
        .await
    }

    pub async fn abort_obligation_ownership_transfer_with_accounts(
        &mut self,
        obligation: Pubkey,
        owner: &Arc<Keypair>,
        instruction_sysvar_account: Pubkey,
    ) -> Result<(), BanksClientError> {
        let accounts = crate::accounts::AbortObligationOwnershipTransfer {
            owner: owner.pubkey(),
            obligation,
            instruction_sysvar_account,
        };

        let instruction = solana_program::instruction::Instruction {
            program_id: crate::id(),
            accounts: anchor_lang::ToAccountMetas::to_account_metas(&accounts, None),
            data: anchor_lang::InstructionData::data(
                &crate::instruction::AbortObligationOwnershipTransfer {},
            ),
        };

        let tx = self
            .create_transaction_with_payer([instruction], owner)
            .await;

        send_transaction!(self, tx)
    }

    pub async fn accept_obligation_ownership(
        &mut self,
        obligation: Pubkey,
        pending_owner: &Arc<Keypair>,
    ) -> Result<(), BanksClientError> {
        self.accept_obligation_ownership_with_accounts(
            obligation,
            pending_owner,
            sysvar::instructions::id(),
        )
        .await
    }

    pub async fn accept_obligation_ownership_with_accounts(
        &mut self,
        obligation: Pubkey,
        pending_owner: &Arc<Keypair>,
        instruction_sysvar_account: Pubkey,
    ) -> Result<(), BanksClientError> {
        let accounts = crate::accounts::AcceptObligationOwnership {
            pending_owner: pending_owner.pubkey(),
            obligation,
            instruction_sysvar_account,
        };

        let instruction = solana_program::instruction::Instruction {
            program_id: crate::id(),
            accounts: anchor_lang::ToAccountMetas::to_account_metas(&accounts, None),
            data: anchor_lang::InstructionData::data(
                &crate::instruction::AcceptObligationOwnership {},
            ),
        };

        let tx = self
            .create_transaction_with_payer([instruction], pending_owner)
            .await;

        send_transaction!(self, tx)
    }
}

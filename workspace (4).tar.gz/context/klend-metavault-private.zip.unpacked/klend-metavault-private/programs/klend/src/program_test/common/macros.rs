#[macro_export]
macro_rules! readable {
    ($res:expr) => {
        ::anchor_lang::prelude::AccountMeta::new_readonly($res, false)
    };
}

#[macro_export]
macro_rules! signer {
    ($res:expr) => {
        ::anchor_lang::prelude::AccountMeta::new_readonly($res, true)
    };
}

#[macro_export]
macro_rules! writable {
    ($res:expr) => {
        ::anchor_lang::prelude::AccountMeta::new($res, false)
    };
}

#[macro_export]
macro_rules! writable_signer {
    ($res:expr) => {
        AccountMeta::new($res, true)
    };
}

#[macro_export]
macro_rules! send_transaction {
    ($ctx: expr, $transaction: expr) => {
        $ctx.process_transaction_with_commitment(
            $transaction,
            solana_sdk::commitment_config::CommitmentLevel::Processed,
        )
        .await
    };
}

#[macro_export]
macro_rules! anchor_error {
    ($err: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            0,
            solana_sdk::instruction::InstructionError::Custom($err as u32),
        )
    };
    ($err: expr, $index: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            $index,
            solana_sdk::instruction::InstructionError::Custom($err as u32),
        )
    };
}

#[macro_export]
macro_rules! klending_error {
    ($err: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            0,
            solana_sdk::instruction::InstructionError::Custom(6000 + $err as u32),
        )
    };

    ($err: expr, $index: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            $index,
            solana_sdk::instruction::InstructionError::Custom(6000 + $err as u32),
        )
    };
}

#[macro_export]
macro_rules! kvault_error {
    ($err: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            0,
            solana_sdk::instruction::InstructionError::Custom(6000 + $err as u32),
        )
    };

    ($err: expr, $index: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            $index,
            solana_sdk::instruction::InstructionError::Custom(6000 + $err as u32),
        )
    };
}

#[macro_export]
macro_rules! custom_error {
    ($err: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            0,
            solana_sdk::instruction::InstructionError::Custom($err as u32),
        )
    };

    ($err: expr, $index: expr) => {
        solana_sdk::transaction::TransactionError::InstructionError(
            $index,
            solana_sdk::instruction::InstructionError::Custom($err as u32),
        )
    };
}

#[macro_export]
macro_rules! contextualize_err {
    ($action: ident, $res: ident) => {
        if $res.is_err() {
            println!("action, {:#?} ", $action);
            $res.unwrap()
        } else {
            $res.unwrap()
        }
    };
}

#[macro_export]
macro_rules! assert_lte {
    ($left:expr, $right:expr $(,)?) => ({
        // The macro uses a block to encapsulate the logic, allowing the use of local variables
        // without affecting the caller's scope.
        let left = &$left;
        let right = &$right;
        // The actual assertion check. If the condition is false, it will panic with the specified message.
        if !(left <= right) {
            panic!("assertion failed: `(left <= right)`\n  left: `{:?}`\n right: `{:?}`", left, right);
        }
    });
}

#[macro_export]
/// If provided `TestContext` has `use_instructions_v2` field set to `true`, then the macro will
/// expand to the `process_v2` function, otherwise it will execute the regular `process` function.
macro_rules! maybe_v2_ix {
    ($ctx:ident, $farms_accounts:expr, $process:ident( $($args:expr),* $(,)*)) =>{
        paste::item! {
            if $ctx.use_instructions_v2 {
                // Call concated function name with _v2
                $crate::program_test::common::instructions::[< $process _v2_ix >]($($args),* , $farms_accounts)
            } else {
                $crate::program_test::common::instructions::[< $process _ix >]($($args),*)
            }
        }
    };
}

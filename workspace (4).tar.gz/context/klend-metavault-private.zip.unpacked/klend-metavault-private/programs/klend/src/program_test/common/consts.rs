use anchor_lang::prelude::Pubkey;
use solana_program::pubkey;

pub const QUOTE_CURRENCY: [u8; 32] =
    *b"USD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

/// Canonical null pubkey.
pub const NULL_PUBKEY: Pubkey = pubkey!("nu11111111111111111111111111111111111111111");

/// Test Pyth program id.
pub const PYTH_PROGRAM_ID: Pubkey = pubkey!("Pyth111111111111111111111111111111111111111");

/// Test Switchboard program id.
pub static SWITCHBOARD_PROGRAM_ID: Pubkey = sbod_itf::ID;

/// Test Scope program id.
pub static SCOPE_PROGRAM_ID: Pubkey = scope::ID;

/// Default referral_fee_bps used for tests - 20%
pub const DEFAULT_TEST_REFERRAL_FEE_BPS: u16 = 2000;

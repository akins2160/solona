use std::sync::Arc;

use anchor_lang::{
    prelude::{Pubkey, Rent},
    system_program::System,
    Id, InstructionData, ToAccountMetas,
};
use anchor_spl::{
    associated_token::{self, AssociatedToken},
    token::Token,
};
use solana_program::system_instruction;
use solana_sdk::{
    compute_budget::ComputeBudgetInstruction,
    instruction::{AccountMeta, Instruction},
    signature::Keypair,
    signer::Signer,
    sysvar::{self, SysvarId},
    transaction::Transaction,
};

// re-export these from private `handlers`, since the tests want to use them directly:
pub use crate::handlers::{BorrowOrderConfigArgs, ReserveConfigCustomizationArgs};
use crate::{
    accounts::{
        DepositReserveLiquidityAndObligationCollateral, OptionalObligationFarmsAccounts,
        RepayObligationLiquidity, WithdrawObligationCollateralAndRedeemReserveCollateral,
    },
    program_test::{
        common::{
            fixtures::maybe_account_meta,
            setup::{
                get_referrer_token_state_key, get_referrer_token_state_key_option,
                get_user_metadata_key,
            },
            types::{
                BorrowerAccounts, DepositorAccounts, InitObligationArgs, LendingMarketAccounts,
                ObligationBorrower, ReserveAccounts, TestContext,
            },
        },
        farms::operations::get_farms_user_state_account,
    },
    readable,
    state::{
        Reserve, UpdateConfigMode, UpdateLendingMarketConfigValue, UpdateLendingMarketMode,
        UpdateReserveConfigValue,
    },
    utils::{maybe_null_pk, seeds::pda, CORRESPONDING_KAMINO_VAULT_PROGRAM_ID},
    withdraw_ticket::{ProgressCallbackType, WithdrawTicket},
    writable, ObligationOrder, ReserveFarmKind, UpdateGlobalConfigMode, UpdateObligationConfigMode,
};

pub async fn init_global_config(ctx: &mut TestContext, payer: Arc<Keypair>) -> Transaction {
    let ix_data = crate::instruction::InitGlobalConfig {}.data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::InitGlobalConfig {
            payer: payer.pubkey(),
            global_config: pda::global_config(),
            program_data: pda::program_data(),
            system_program: System::id(),
            rent: Rent::id(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn init_lending_market<'a>(
    ctx: &mut TestContext,
    payer: Arc<Keypair>,
    lending_market_accs: &LendingMarketAccounts,
    quote_currency: [u8; 32],
) -> Transaction {
    let ix_data = crate::instruction::InitLendingMarket { quote_currency }.data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::InitLendingMarket {
            lending_market_owner: lending_market_accs.owner.pubkey(),
            lending_market_authority: lending_market_accs.authority,
            lending_market: lending_market_accs.market.pubkey(),
            system_program: System::id(),
            rent: Rent::id(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    let create_account_ix = system_instruction::create_account(
        &payer.pubkey(),
        &lending_market_accs.market.pubkey(),
        ctx.get_rent_zero_copy::<crate::LendingMarket>(),
        std::mem::size_of::<crate::LendingMarket>() as u64 + 8,
        &crate::id(),
    );

    ctx.create_transaction_with_payer_and_extra_signers(
        [create_account_ix, instruction],
        payer,
        [&lending_market_accs.market],
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_reserve<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    payer: Arc<Keypair>,
) -> Transaction {
    let ix_data = crate::instruction::InitReserve {}.data();

    let owner_ata = associated_token::get_associated_token_address_with_program_id(
        &lending_market_accounts.owner.pubkey(),
        &reserve_accounts.liquidity_mint.pubkey(),
        &reserve_accounts.liquidity_mint_token_program,
    );

    let accts = crate::accounts::InitReserve {
        signer: lending_market_accounts.owner.pubkey(),
        lending_market: reserve_accounts.lending_market,
        lending_market_authority: reserve_accounts.lending_market_authority,
        reserve: reserve_accounts.address.pubkey(),
        reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_liquidity_supply: reserve_accounts.liquidity_supply,
        fee_receiver: reserve_accounts.fee_receiver,
        reserve_collateral_mint: reserve_accounts.collateral_mint,
        reserve_collateral_supply: reserve_accounts.collateral_supply,
        initial_liquidity_source: owner_ata,
        rent: Rent::id(),
        collateral_token_program: Token::id(),
        liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
        system_program: System::id(),
    };
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: ix_data,
    };

    let create_account_ix = system_instruction::create_account(
        &payer.pubkey(),
        &reserve_accounts.address.pubkey(),
        ctx.get_rent_zero_copy::<crate::Reserve>(),
        std::mem::size_of::<crate::Reserve>() as u64 + 8,
        &crate::id(),
    );

    ctx.create_transaction_with_payer_and_extra_signers(
        [create_account_ix, instruction],
        payer,
        [reserve_accounts.address.clone()],
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub async fn seed_deposit_on_init_reserve<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    liquidity_ata: Pubkey,
    payer: Arc<Keypair>,
) -> Transaction {
    let ix_data = crate::instruction::SeedDepositOnInitReserve {}.data();

    let accts = crate::accounts::SeedDepositOnInitReserve {
        signer: lending_market_accounts.owner.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        reserve: reserve_accounts.address.pubkey(),
        reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_liquidity_supply: reserve_accounts.liquidity_supply,
        initial_liquidity_source: liquidity_ata,
        liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
    };
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn topup_reserve_rewards<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    source_liquidity: Pubkey,
    signer: Arc<Keypair>,
    amount: u64,
) -> Transaction {
    let ix_data = crate::instruction::TopupReserveRewards { amount }.data();

    let accts = crate::accounts::TopupReserveRewards {
        signer: signer.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        reserve: reserve_accounts.address.pubkey(),
        reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_liquidity_supply: reserve_accounts.liquidity_supply,
        source_liquidity,
        liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
    };
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], signer)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn clone_reserve_config(
    ctx: &mut TestContext,
    target_lending_market: Pubkey,
    source_reserve: Pubkey,
    target_reserve: Pubkey,
    customizations: ReserveConfigCustomizationArgs,
    signer: Arc<Keypair>,
) -> Transaction {
    let ix = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::CloneReserveConfig {
            signer: signer.pubkey(),
            target_lending_market,
            source_reserve,
            target_reserve,
        }
        .to_account_metas(None),
        data: crate::instruction::CloneReserveConfig { customizations }.data(),
    };

    ctx.create_transaction_with_payer([ix], signer).await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_user_metadata<'a>(
    ctx: &mut TestContext,
    owner: &Arc<Keypair>,
    referrer: &Pubkey,
    user_lookup_table: &Pubkey,
) -> Transaction {
    let ix_data = crate::instruction::InitUserMetadata {
        user_lookup_table: *user_lookup_table,
    }
    .data();

    let user_metadata_pk = get_user_metadata_key(owner.pubkey());
    let referrer_user_metadata_pk = if *referrer == Pubkey::default() {
        None
    } else {
        Some(get_user_metadata_key(*referrer))
    };

    let accts = crate::accounts::InitUserMetadata {
        fee_payer: owner.pubkey(),
        owner: owner.pubkey(),
        user_metadata: user_metadata_pk,
        referrer_user_metadata: referrer_user_metadata_pk,
        rent: Rent::id(),
        system_program: System::id(),
    };

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_referrer_token_state<'a>(
    ctx: &mut TestContext,
    payer: &Arc<Keypair>,
    lending_market_address: &Pubkey,
    referrer: &Pubkey,
    reserve: &Pubkey,
) -> Transaction {
    let ix_data = crate::instruction::InitReferrerTokenState.data();

    let referrer_token_state_pk = get_referrer_token_state_key(referrer, reserve);

    let accts = crate::accounts::InitReferrerTokenState {
        payer: payer.pubkey(),
        lending_market: *lending_market_address,
        referrer: *referrer,
        referrer_token_state: referrer_token_state_pk,
        reserve: *reserve,
        rent: Rent::id(),
        system_program: System::id(),
    };

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_farms<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    payer: Arc<Keypair>,
    mode: ReserveFarmKind,
) -> Transaction {
    let farm_state = Keypair::new();
    let ix_preallocate_farm_account = system_instruction::create_account(
        &payer.pubkey(),
        &farm_state.pubkey(),
        ctx.get_rent_zero_copy::<farms::state::FarmState>(),
        std::mem::size_of::<farms::state::FarmState>() as u64 + 8,
        &farms::id(),
    );

    let (farm_vault_authority, _) = Pubkey::find_program_address(
        &[
            farms::utils::consts::BASE_SEED_FARM_VAULTS_AUTHORITY,
            farm_state.pubkey().as_ref(),
        ],
        &farms::ID,
    );

    let accts = crate::accounts::InitFarmsForReserve {
        lending_market_owner: lending_market_accounts.owner.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        lending_market_authority: reserve_accounts.lending_market_authority,
        reserve: reserve_accounts.address.pubkey(),
        farm_state: farm_state.pubkey(),
        rent: Rent::id(),
        farms_program: farms::id(),
        farms_vault_authority: farm_vault_authority,
        farms_global_config: lending_market_accounts.farms_global_config.pubkey(),
        system_program: System::id(),
    };

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: crate::instruction::InitFarmsForReserve { mode: mode as u8 }.data(),
    };

    ctx.create_transaction_with_payer_and_extra_signers(
        [ix_preallocate_farm_account, instruction],
        payer,
        [Arc::new(farm_state)],
    )
    .await
}

#[allow(clippy::too_many_arguments)]
pub fn init_obligation_farm_for_reserve_ix(
    reserve_accounts: &ReserveAccounts,
    reserve_farm_state: &Pubkey,
    obligation: &Pubkey,
    owner: &Arc<Keypair>,
    payer: &Arc<Keypair>,
    mode: ReserveFarmKind,
) -> InstructionBlocks {
    let obligation_farm_state = get_farms_user_state_account(reserve_farm_state, obligation);

    let accts = crate::accounts::InitObligationFarmsForReserve {
        payer: payer.pubkey(),
        owner: owner.pubkey(),
        obligation: *obligation,
        lending_market: reserve_accounts.lending_market,
        lending_market_authority: reserve_accounts.lending_market_authority,
        reserve: reserve_accounts.address.pubkey(),
        obligation_farm: obligation_farm_state,
        reserve_farm_state: *reserve_farm_state,
        rent: Rent::id(),
        farms_program: farms::id(),
        system_program: System::id(),
    };

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: crate::instruction::InitObligationFarmsForReserve { mode: mode as u8 }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: payer.pubkey(),
        signers: vec![payer.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn init_obligation_farm_for_reserve<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    reserve_farm_state: &Pubkey,
    borrower: &dyn ObligationBorrower,
    payer: &Arc<Keypair>,
    mode: ReserveFarmKind,
) -> Transaction {
    let instruction = init_obligation_farm_for_reserve_ix(
        reserve_accounts,
        reserve_farm_state,
        &borrower.get_obligation(),
        &borrower.get_owner(),
        payer,
        mode,
    );
    ctx.create_transaction_from_blocks(instruction).await
}

pub fn refresh_obligation_farm_for_reserve_ix(
    reserve_accounts: &ReserveAccounts,
    reserve_farm_state: Pubkey,
    obligation: Pubkey,
    owner: &Arc<Keypair>,
    farms_mode: ReserveFarmKind,
) -> InstructionBlocks {
    let user_farm_state = get_farms_user_state_account(&reserve_farm_state, &obligation);

    let accts = crate::accounts::RefreshObligationFarmsForReserve {
        crank: owner.pubkey(),
        base_accounts: crate::accounts::RefreshObligationFarmsForReserveBase {
            obligation,
            lending_market: reserve_accounts.lending_market,
            lending_market_authority: reserve_accounts.lending_market_authority,
            reserve: reserve_accounts.address.pubkey(),
            obligation_farm_user_state: user_farm_state,
            reserve_farm_state,
        },
        farms_program: farms::id(),
        rent: Rent::id(),
        system_program: System::id(),
    };

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: accts.to_account_metas(None),
        data: crate::instruction::RefreshObligationFarmsForReserve {
            mode: farms_mode as u8,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: owner.pubkey(),
        signers: vec![owner.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn refresh_obligation_farm_for_reserve<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    reserve_farm_state: Pubkey,
    borrower: &dyn ObligationBorrower,
    farms_mode: ReserveFarmKind,
) -> Transaction {
    let instruction = refresh_obligation_farm_for_reserve_ix(
        reserve_accounts,
        reserve_farm_state,
        borrower.get_obligation(),
        &borrower.get_owner(),
        farms_mode,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub async fn update_reserve_config<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    lending_market_accounts: &LendingMarketAccounts,
    payer: Arc<Keypair>,
    mode: UpdateConfigMode,
    value: UpdateReserveConfigValue,
    skip_config_integrity_validation: bool,
) -> Transaction {
    let ix_data = crate::instruction::UpdateReserveConfig {
        mode,
        value: value.to_raw_bytes(),
        skip_config_integrity_validation,
    }
    .data();

    let cu_budget = ComputeBudgetInstruction::set_compute_unit_limit(300_000);

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::UpdateReserveConfig {
            global_config: pda::global_config(),
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: reserve_accounts.address.pubkey(),
            signer: lending_market_accounts.owner.pubkey(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([cu_budget, instruction], payer)
        .await
}

pub async fn update_lending_market<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    payer: Arc<Keypair>,
    mode: UpdateLendingMarketMode,
    value: UpdateLendingMarketConfigValue,
) -> Transaction {
    let ix_data = crate::instruction::UpdateLendingMarket {
        mode: mode as u64,
        value: value.to_bytes(),
    }
    .data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::UpdateLendingMarket {
            lending_market: lending_market_accounts.market.pubkey(),
            signer: payer.pubkey(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn update_lending_market_owner<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    payer: Arc<Keypair>,
) -> Transaction {
    let ix_data = crate::instruction::UpdateLendingMarketOwner {}.data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::UpdateLendingMarketOwner {
            lending_market: lending_market_accounts.market.pubkey(),
            lending_market_owner_cached: payer.pubkey(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn update_global_config<'a>(
    ctx: &mut TestContext,
    payer: Arc<Keypair>,
    mode: UpdateGlobalConfigMode,
    value: &[u8],
) -> Transaction {
    let ix_data = crate::instruction::UpdateGlobalConfig {
        mode,
        value: value.to_vec(),
    }
    .data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::UpdateGlobalConfig {
            global_config: pda::global_config(),
            global_admin: payer.pubkey(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn update_global_config_admin(ctx: &mut TestContext, payer: Arc<Keypair>) -> Transaction {
    let ix_data = crate::instruction::UpdateGlobalConfigAdmin {}.data();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::UpdateGlobalConfigAdmin {
            global_config: pda::global_config(),
            pending_admin: payer.pubkey(),
        }
        .to_account_metas(None),
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub fn init_obligation_ix(
    market: &LendingMarketAccounts,
    borrower: &dyn ObligationBorrower,
    args: InitObligationArgs,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::InitObligation {
            lending_market: market.market.pubkey(),
            obligation: borrower.get_obligation(),
            fee_payer: borrower.get_owner().pubkey(),
            obligation_owner: borrower.get_owner().pubkey(),
            seed1_account: args.seed1,
            seed2_account: args.seed2,
            owner_user_metadata: borrower.get_user_metadata(),
            system_program: System::id(),
            rent: Rent::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::InitObligation {
            args: crate::state::InitObligationArgs {
                id: args.id,
                tag: args.tag,
            },
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: borrower.get_owner().pubkey(),
        signers: vec![borrower.get_owner()],
    }
}

pub async fn init_obligation<'a>(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    borrower: &dyn ObligationBorrower,
    args: InitObligationArgs,
) -> Transaction {
    let init_instruction_ix = init_obligation_ix(market, borrower, args);

    ctx.create_transaction_from_blocks(init_instruction_ix)
        .await
}

pub fn deposit_reserve_liquidity_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    liquidity_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::DepositReserveLiquidity {
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_liquidity_supply: reserve_accounts.liquidity_supply,
            reserve_collateral_mint: reserve_accounts.collateral_mint,
            lending_market_authority: lending_market_accounts.authority,
            user_source_liquidity: depositor.liquidity,
            user_destination_collateral: depositor.collateral,
            owner: depositor.owner.pubkey(),
            instruction_sysvar_account: sysvar::instructions::ID,
            liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
            collateral_token_program: Token::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::DepositReserveLiquidity { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn deposit_reserve_liquidity<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    liquidity_amount: u64,
) -> Transaction {
    let instruction = deposit_reserve_liquidity_ix(
        lending_market_accounts,
        reserve_accounts,
        depositor,
        liquidity_amount,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn deposit_obligation_collateral_ix(
    market_accs: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::DepositObligationCollateral {
            user_source_collateral: depositor.collateral,
            reserve_destination_collateral: reserve_accounts.collateral_supply,
            deposit_reserve: reserve_accounts.address.pubkey(),
            obligation: *obligation,
            lending_market: market_accs.market.pubkey(),
            owner: depositor.owner.pubkey(),
            instruction_sysvar_account: sysvar::instructions::ID,
            token_program: Token::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::DepositObligationCollateral { collateral_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn deposit_obligation_collateral<'a>(
    ctx: &mut TestContext,
    market_accs: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
) -> Transaction {
    let instruction = deposit_obligation_collateral_ix(
        market_accs,
        reserve_accounts,
        depositor,
        obligation,
        collateral_amount,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn deposit_obligation_collateral_v2_ix(
    market_accs: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::DepositObligationCollateralV2 {
            deposit_accounts: crate::accounts::DepositObligationCollateral {
                user_source_collateral: depositor.collateral,
                reserve_destination_collateral: reserve_accounts.collateral_supply,
                deposit_reserve: reserve_accounts.address.pubkey(),
                obligation: *obligation,
                lending_market: market_accs.market.pubkey(),
                owner: depositor.owner.pubkey(),
                instruction_sysvar_account: sysvar::instructions::ID,
                token_program: Token::id(),
            },
            farms_accounts,
            farms_program: farms::id(),
            lending_market_authority: market_accs.authority,
        }
        .to_account_metas(None),
        data: crate::instruction::DepositObligationCollateral { collateral_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn deposit_obligation_collateral_v2<'a>(
    ctx: &mut TestContext,
    market_accs: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = deposit_obligation_collateral_v2_ix(
        market_accs,
        reserve_accounts,
        depositor,
        obligation,
        collateral_amount,
        farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

#[derive(Clone)]
pub struct InstructionBlocks {
    pub instruction: Instruction,
    pub payer: Pubkey,
    pub signers: Vec<Arc<Keypair>>,
}

pub fn deposit_reserve_liquidity_and_obligation_collateral_ix(
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::DepositReserveLiquidityAndObligationCollateral {
            lending_market: reserve_accounts.lending_market,
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_liquidity_supply: reserve_accounts.liquidity_supply,
            reserve_collateral_mint: reserve_accounts.collateral_mint,
            reserve_destination_deposit_collateral: reserve_accounts.collateral_supply,
            obligation: *obligation,
            owner: depositor.owner.pubkey(),
            lending_market_authority: reserve_accounts.lending_market_authority,
            user_source_liquidity: depositor.liquidity,
            instruction_sysvar_account: sysvar::instructions::ID,
            placeholder_user_destination_collateral: None,
            collateral_token_program: Token::id(),
            liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::DepositReserveLiquidityAndObligationCollateral {
            liquidity_amount,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub fn deposit_reserve_liquidity_and_obligation_collateral_v2_ix(
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::DepositReserveLiquidityAndObligationCollateralV2 {
            deposit_accounts: crate::accounts::DepositReserveLiquidityAndObligationCollateral {
                lending_market: reserve_accounts.lending_market,
                reserve: reserve_accounts.address.pubkey(),
                reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
                reserve_liquidity_supply: reserve_accounts.liquidity_supply,
                reserve_collateral_mint: reserve_accounts.collateral_mint,
                reserve_destination_deposit_collateral: reserve_accounts.collateral_supply,
                obligation: *obligation,
                owner: depositor.owner.pubkey(),
                lending_market_authority: reserve_accounts.lending_market_authority,
                user_source_liquidity: depositor.liquidity,
                instruction_sysvar_account: sysvar::instructions::ID,
                placeholder_user_destination_collateral: None,
                collateral_token_program: Token::id(),
                liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
            },
            farms_accounts,
            farms_program: farms::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::DepositReserveLiquidityAndObligationCollateralV2 {
            liquidity_amount,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn deposit_reserve_liquidity_and_obligation_collateral<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
) -> Transaction {
    let instruction = deposit_reserve_liquidity_and_obligation_collateral_ix(
        reserve_accounts,
        depositor,
        obligation,
        liquidity_amount,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub async fn deposit_reserve_liquidity_and_obligation_collateral_v2<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = deposit_reserve_liquidity_and_obligation_collateral_v2_ix(
        reserve_accounts,
        depositor,
        obligation,
        liquidity_amount,
        farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn redeem_reserve_collateral_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    collateral_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::RedeemReserveCollateral {
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_collateral_mint: reserve_accounts.collateral_mint,
            reserve_liquidity_supply: reserve_accounts.liquidity_supply,
            lending_market_authority: lending_market_accounts.authority,
            user_source_collateral: depositor.collateral,
            user_destination_liquidity: depositor.liquidity,
            owner: depositor.owner.pubkey(),
            instruction_sysvar_account: sysvar::instructions::ID,
            collateral_token_program: Token::id(),
            liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::RedeemReserveCollateral { collateral_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn redeem_reserve_collateral<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    collateral_amount: u64,
) -> Transaction {
    let instruction = redeem_reserve_collateral_ix(
        lending_market_accounts,
        reserve_accounts,
        depositor,
        collateral_amount,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn withdraw_obligation_collateral_ix(
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::WithdrawObligationCollateral {
            lending_market: reserve_accounts.lending_market,
            withdraw_reserve: reserve_accounts.address.pubkey(),
            lending_market_authority: reserve_accounts.lending_market_authority,
            obligation: *obligation,
            owner: depositor.owner.pubkey(),
            user_destination_collateral: depositor.collateral,
            reserve_source_collateral: reserve_accounts.collateral_supply,
            token_program: Token::id(),
            instruction_sysvar_account: sysvar::instructions::ID,
        }
        .to_account_metas(None),
        data: crate::instruction::WithdrawObligationCollateral { collateral_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn withdraw_obligation_collateral<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
) -> Transaction {
    let instruction = withdraw_obligation_collateral_ix(
        reserve_accounts,
        depositor,
        obligation,
        collateral_amount,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn withdraw_obligation_collateral_v2_ix(
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::WithdrawObligationCollateralV2 {
            withdraw_accounts: crate::accounts::WithdrawObligationCollateral {
                lending_market: reserve_accounts.lending_market,
                withdraw_reserve: reserve_accounts.address.pubkey(),
                lending_market_authority: reserve_accounts.lending_market_authority,
                obligation: *obligation,
                owner: depositor.owner.pubkey(),
                user_destination_collateral: depositor.collateral,
                reserve_source_collateral: reserve_accounts.collateral_supply,
                token_program: Token::id(),
                instruction_sysvar_account: sysvar::instructions::ID,
            },
            farms_accounts,
            farms_program: farms::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::WithdrawObligationCollateralV2 { collateral_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn withdraw_obligation_collateral_v2<'a>(
    ctx: &mut TestContext,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = withdraw_obligation_collateral_v2_ix(
        reserve_accounts,
        depositor,
        obligation,
        collateral_amount,
        farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn withdraw_obligation_collateral_and_redeem_reserve_collateral_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::WithdrawObligationCollateralAndRedeemReserveCollateral {
            lending_market: lending_market_accounts.market.pubkey(),
            withdraw_reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_collateral_mint: reserve_accounts.collateral_mint,
            reserve_liquidity_supply: reserve_accounts.liquidity_supply,
            lending_market_authority: lending_market_accounts.authority,
            obligation: *obligation,
            owner: depositor.owner.pubkey(),
            user_destination_liquidity: depositor.liquidity,
            reserve_source_collateral: reserve_accounts.collateral_supply,
            instruction_sysvar_account: sysvar::instructions::ID,
            placeholder_user_destination_collateral: None,
            collateral_token_program: Token::id(),
            liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::WithdrawObligationCollateralAndRedeemReserveCollateral {
            collateral_amount,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn withdraw_obligation_collateral_and_redeem_reserve_collateral<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
) -> Transaction {
    let instruction = withdraw_obligation_collateral_and_redeem_reserve_collateral_ix(
        lending_market_accounts,
        reserve_accounts,
        depositor,
        obligation,
        collateral_amount,
    );
    ctx.create_transaction_from_blocks(instruction).await
}

pub fn withdraw_obligation_collateral_and_redeem_reserve_collateral_v2_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::WithdrawObligationCollateralAndRedeemReserveCollateralV2 {
            withdraw_accounts:
                crate::accounts::WithdrawObligationCollateralAndRedeemReserveCollateral {
                    lending_market: lending_market_accounts.market.pubkey(),
                    withdraw_reserve: reserve_accounts.address.pubkey(),
                    reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
                    reserve_collateral_mint: reserve_accounts.collateral_mint,
                    reserve_liquidity_supply: reserve_accounts.liquidity_supply,
                    lending_market_authority: lending_market_accounts.authority,
                    obligation: *obligation,
                    owner: depositor.owner.pubkey(),
                    user_destination_liquidity: depositor.liquidity,
                    reserve_source_collateral: reserve_accounts.collateral_supply,
                    instruction_sysvar_account: sysvar::instructions::ID,
                    placeholder_user_destination_collateral: None,
                    collateral_token_program: Token::id(),
                    liquidity_token_program: reserve_accounts.liquidity_mint_token_program,
                },
            farms_accounts,
            farms_program: farms::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::WithdrawObligationCollateralAndRedeemReserveCollateralV2 {
            collateral_amount,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone()],
    }
}

pub async fn withdraw_obligation_collateral_and_redeem_reserve_collateral_v2<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    depositor: &DepositorAccounts,
    obligation: &Pubkey,
    collateral_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = withdraw_obligation_collateral_and_redeem_reserve_collateral_v2_ix(
        lending_market_accounts,
        reserve_accounts,
        depositor,
        obligation,
        collateral_amount,
        farms_accounts,
    );
    ctx.create_transaction_from_blocks(instruction).await
}

#[allow(clippy::too_many_arguments)]
pub async fn enqueue_to_withdraw<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    owner: &Arc<Keypair>,
    ticket_sequence_number: u64,
    user_source_collateral_ta: Pubkey,
    user_destination_liquidity_ta: Pubkey,
    owner_queued_collateral_vault: Pubkey,
    collateral_amount: u64,
    progress_callback: ProgressCallbackConfig,
) -> Transaction {
    let ix = enqueue_to_withdraw_ix(
        lending_market_accounts,
        reserve_accounts,
        owner.pubkey(),
        ticket_sequence_number,
        user_source_collateral_ta,
        user_destination_liquidity_ta,
        owner_queued_collateral_vault,
        collateral_amount,
        progress_callback,
    );

    ctx.create_transaction_with_payer([ix], owner).await
}

pub fn enqueue_to_withdraw_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    owner: Pubkey,
    ticket_sequence_number: u64,
    user_source_collateral_ta: Pubkey,
    user_destination_liquidity_ta: Pubkey,
    owner_queued_collateral_vault: Pubkey,
    collateral_amount: u64,
    progress_callback: ProgressCallbackConfig,
) -> Instruction {
    let mut account_metas = crate::accounts::EnqueueToWithdraw {
        lending_market: lending_market_accounts.market.pubkey(),
        lending_market_authority: lending_market_accounts.authority,
        owner_queued_collateral_vault,
        owner,
        user_source_collateral_ta,
        user_destination_liquidity_ta,
        reserve: reserve_accounts.pubkey(),
        reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_collateral_mint: reserve_accounts.collateral_mint,
        collateral_token_program: Token::id(),
        withdraw_ticket: pda::withdraw_ticket(reserve_accounts.pubkey(), ticket_sequence_number),
        system_program: System::id(),
        instruction_sysvar_account: sysvar::instructions::ID,
        progress_callback_custom_account_0: progress_callback.custom_account_address(0),
        progress_callback_custom_account_1: progress_callback.custom_account_address(1),
    }
    .to_account_metas(None);
    progress_callback.adjust(&mut account_metas);

    Instruction {
        program_id: crate::id(),
        accounts: account_metas,
        data: crate::instruction::EnqueueToWithdraw {
            collateral_amount,
            progress_callback_type: progress_callback.callback_type,
        }
        .data(),
    }
}

#[derive(Debug, Clone)]
pub struct ProgressCallbackConfig {
    pub callback_type: ProgressCallbackType,
    pub program_address: Pubkey,
    pub custom_accounts: Vec<AccountMeta>,
}

impl ProgressCallbackConfig {
    pub fn none() -> Self {
        Self {
            callback_type: ProgressCallbackType::None,
            program_address: Pubkey::default(),
            custom_accounts: vec![],
        }
    }

    pub fn for_enqueue_to_withdraw_kvault(vault_state: Pubkey) -> Self {
        Self {
            callback_type: ProgressCallbackType::KlendQueueAccountingHandlerOnKvault,
            program_address: CORRESPONDING_KAMINO_VAULT_PROGRAM_ID,
            custom_accounts: vec![readable!(vault_state)],
        }
    }

    pub fn for_withdraw_queued_liquidity(ticket: &WithdrawTicket) -> Self {
        match ticket.progress_callback_type() {
            ProgressCallbackType::None => Self::none(),
            ProgressCallbackType::KlendQueueAccountingHandlerOnKvault => Self {
                callback_type: ProgressCallbackType::KlendQueueAccountingHandlerOnKvault,
                program_address: CORRESPONDING_KAMINO_VAULT_PROGRAM_ID,
                custom_accounts: vec![writable!(ticket.progress_callback_custom_accounts[0])],
            },
        }
    }

    pub fn custom_account_address(&self, index: usize) -> Option<Pubkey> {
        self.custom_accounts.get(index).map(|meta| meta.pubkey)
    }

    pub fn adjust(&self, generated_account_metas: &mut Vec<AccountMeta>) {
        for generated_account_meta in generated_account_metas.iter_mut() {
            for custom_account in self.custom_accounts.iter() {
                if generated_account_meta.pubkey == custom_account.pubkey {
                    *generated_account_meta = custom_account.clone();
                }
            }
        }
    }
}

pub async fn withdraw_queued_liquidity<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    payer: &Keypair,
    ticket_sequence_number: u64,
    user_destination_liquidity: Pubkey,
    withdraw_ticket_owner: Pubkey,
    progress_callback: ProgressCallbackConfig,
) -> Transaction {
    let mut account_metas = crate::accounts::WithdrawQueuedLiquidity {
        payer: payer.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        lending_market_authority: lending_market_accounts.authority,
        owner_queued_collateral_vault: pda::owner_queued_collateral_vault(
            reserve_accounts.pubkey(),
            withdraw_ticket_owner,
        ),
        user_destination_liquidity,
        reserve: reserve_accounts.pubkey(),
        reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_liquidity_supply: reserve_accounts.liquidity_supply,
        reserve_collateral_mint: reserve_accounts.collateral_mint,
        withdraw_ticket: pda::withdraw_ticket(reserve_accounts.pubkey(), ticket_sequence_number),
        withdraw_ticket_owner,
        liquidity_token_program: Token::id(),
        collateral_token_program: Token::id(),
        associated_token_program: AssociatedToken::id(),
        system_program: System::id(),
        instruction_sysvar_account: sysvar::instructions::ID,
        progress_callback_program: Some(progress_callback.program_address),
        progress_callback_custom_account_0: progress_callback.custom_account_address(0),
        progress_callback_custom_account_1: progress_callback.custom_account_address(1),
    }
    .to_account_metas(None);
    progress_callback.adjust(&mut account_metas);

    let ix = Instruction {
        program_id: crate::id(),
        accounts: account_metas,
        data: crate::instruction::WithdrawQueuedLiquidity {}.data(),
    };

    ctx.create_transaction_with_payer([ix], payer).await
}

pub async fn recover_invalid_ticket_collateral<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    payer: &Keypair,
    ticket_sequence_number: u64,
    user_source_collateral: Pubkey,
    withdraw_ticket_owner: Pubkey,
) -> Transaction {
    let ix = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::RecoverInvalidTicketCollateral {
            payer: payer.pubkey(),
            lending_market: lending_market_accounts.market.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            owner_queued_collateral_vault: pda::owner_queued_collateral_vault(
                reserve_accounts.pubkey(),
                withdraw_ticket_owner,
            ),
            user_source_collateral,
            reserve: reserve_accounts.pubkey(),
            reserve_collateral_mint: reserve_accounts.collateral_mint,
            withdraw_ticket: pda::withdraw_ticket(
                reserve_accounts.pubkey(),
                ticket_sequence_number,
            ),
            collateral_token_program: Token::id(),
            withdraw_ticket_owner,
            instruction_sysvar_account: sysvar::instructions::ID,
        }
        .to_account_metas(None),
        data: crate::instruction::RecoverInvalidTicketCollateral {
            ticket_sequence_number,
        }
        .data(),
    };

    ctx.create_transaction_with_payer([ix], payer).await
}

pub async fn cancel_withdraw_ticket<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    owner: &Keypair,
    ticket_sequence_number: u64,
    user_destination_collateral: Pubkey,
    collateral_amount_to_cancel: u64,
) -> Transaction {
    let ix = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::CancelWithdrawTicket {
            owner: owner.pubkey(),
            lending_market: lending_market_accounts.market.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            reserve: reserve_accounts.pubkey(),
            reserve_collateral_mint: reserve_accounts.collateral_mint,
            owner_queued_collateral_vault: pda::owner_queued_collateral_vault(
                reserve_accounts.pubkey(),
                owner.pubkey(),
            ),
            user_destination_collateral,
            collateral_token_program: Token::id(),
            withdraw_ticket: pda::withdraw_ticket(
                reserve_accounts.pubkey(),
                ticket_sequence_number,
            ),
        }
        .to_account_metas(None),
        data: crate::instruction::CancelWithdrawTicket {
            ticket_sequence_number,
            collateral_amount_to_cancel,
        }
        .data(),
    };

    ctx.create_transaction_with_payer([ix], owner).await
}

pub fn borrow_obligation_liquidity_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    liquidity_amount: u64,
) -> InstructionBlocks {
    let accounts = borrow_obligation_liquidity_accounts(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        deposit_reserves,
        None,
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::BorrowObligationLiquidity { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: borrower.owner.pubkey(),
        signers: vec![borrower.owner.clone()],
    }
}

pub fn borrow_obligation_liquidity_v2_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    liquidity_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let accounts = borrow_obligation_liquidity_accounts(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        deposit_reserves,
        Some(farms_accounts),
    );
    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::BorrowObligationLiquidityV2 { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: borrower.owner.pubkey(),
        signers: vec![borrower.owner.clone()],
    }
}

fn borrow_obligation_liquidity_accounts(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    farms_accounts_opt: Option<OptionalObligationFarmsAccounts>,
) -> Vec<AccountMeta> {
    let referrer_token_state_address = if borrower.referrer == Pubkey::default() {
        None
    } else {
        Some(get_referrer_token_state_key(
            &borrower.referrer,
            &reserve_accounts.address.pubkey(),
        ))
    };

    let borrow_accounts = crate::accounts::BorrowObligationLiquidity {
        lending_market: lending_market_accounts.market.pubkey(),
        borrow_reserve: reserve_accounts.address.pubkey(),
        lending_market_authority: lending_market_accounts.authority,
        obligation: *obligation,
        owner: borrower.owner.pubkey(),
        user_destination_liquidity: borrower.liquidity,
        borrow_reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_source_liquidity: reserve_accounts.liquidity_supply,
        borrow_reserve_liquidity_fee_receiver: reserve_accounts.fee_receiver,
        referrer_token_state: referrer_token_state_address,
        instruction_sysvar_account: sysvar::instructions::ID,
        token_program: reserve_accounts.liquidity_mint_token_program,
    };

    let mut accounts = if let Some(farms_accounts) = farms_accounts_opt {
        crate::accounts::BorrowObligationLiquidityV2 {
            borrow_accounts,
            farms_accounts,
            farms_program: farms::id(),
        }
        .to_account_metas(None)
    } else {
        borrow_accounts.to_account_metas(None)
    };

    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|reserve| *reserve)
            .map(|reserve| writable!(reserve)),
    );

    accounts
}

pub async fn borrow_obligation_liquidity<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    liquidity_amount: u64,
) -> Transaction {
    let instruction = borrow_obligation_liquidity_ix(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        deposit_reserves,
        liquidity_amount,
    );
    ctx.create_transaction_from_blocks(instruction).await
}

#[allow(clippy::too_many_arguments)]
pub async fn borrow_obligation_liquidity_v2<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    liquidity_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = borrow_obligation_liquidity_v2_ix(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        deposit_reserves,
        liquidity_amount,
        farms_accounts,
    );
    ctx.create_transaction_from_blocks(instruction).await
}

pub fn repay_obligation_liquidity_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
) -> InstructionBlocks {
    let accounts = repay_obligation_liquidity_accounts(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        deposit_reserves,
        None,
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RepayObligationLiquidity { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: borrower.owner.pubkey(),
        signers: vec![borrower.owner.clone()],
    }
}

pub fn repay_obligation_liquidity_v2_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let accounts = repay_obligation_liquidity_accounts(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        deposit_reserves,
        Some(farms_accounts),
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RepayObligationLiquidityV2 { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: borrower.owner.pubkey(),
        signers: vec![borrower.owner.clone()],
    }
}

fn repay_obligation_liquidity_accounts(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    farms_accounts_opt: Option<OptionalObligationFarmsAccounts>,
) -> Vec<AccountMeta> {
    let repay_accounts = crate::accounts::RepayObligationLiquidity {
        lending_market: lending_market_accounts.market.pubkey(),
        repay_reserve: reserve_accounts.address.pubkey(),
        reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        obligation: *obligation,
        user_source_liquidity: borrower.liquidity,
        reserve_destination_liquidity: reserve_accounts.liquidity_supply,
        owner: borrower.owner.pubkey(),
        token_program: reserve_accounts.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar::instructions::ID,
    };

    let mut accounts = if let Some(farms_accounts) = farms_accounts_opt {
        crate::accounts::RepayObligationLiquidityV2 {
            repay_accounts,
            farms_accounts,
            farms_program: farms::id(),
            lending_market_authority: lending_market_accounts.authority,
        }
        .to_account_metas(None)
    } else {
        repay_accounts.to_account_metas(None)
    };

    // Add deposit reserves as extra accounts
    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    accounts
}

pub async fn repay_obligation_liquidity<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
) -> Transaction {
    let instruction = repay_obligation_liquidity_ix(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        liquidity_amount,
        deposit_reserves,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

#[allow(clippy::too_many_arguments)]
pub async fn repay_obligation_liquidity_v2<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    liquidity_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = repay_obligation_liquidity_v2_ix(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        obligation,
        liquidity_amount,
        deposit_reserves,
        farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

#[allow(clippy::too_many_arguments)]
pub fn repay_and_withdraw_and_redeem_ix(
    lending_market_accounts: &LendingMarketAccounts,
    repay_reserve_accounts: &ReserveAccounts,
    withdraw_reserve_accounts: &ReserveAccounts,
    repayer: &BorrowerAccounts,
    withdrawer: &BorrowerAccounts,
    repay_amount: u64,
    withdraw_collateral_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    debt_farms_accounts: OptionalObligationFarmsAccounts,
    collateral_farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let accounts = repay_and_withdraw_and_redeem_ix_accounts(
        lending_market_accounts,
        repay_reserve_accounts,
        withdraw_reserve_accounts,
        repayer,
        withdrawer,
        deposit_reserves,
        borrow_reserves,
        referrer_token_states,
        debt_farms_accounts,
        collateral_farms_accounts,
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RepayAndWithdrawAndRedeem {
            repay_amount,
            withdraw_collateral_amount,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: repayer.owner.pubkey(),
        signers: vec![repayer.owner.clone(), withdrawer.owner.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
fn repay_and_withdraw_and_redeem_ix_accounts(
    lending_market_accounts: &LendingMarketAccounts,
    repay_reserve_accounts: &ReserveAccounts,
    withdraw_reserve_accounts: &ReserveAccounts,
    repayer: &BorrowerAccounts,
    withdrawer: &BorrowerAccounts,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    debt_farms_accounts: OptionalObligationFarmsAccounts,
    collateral_farms_accounts: OptionalObligationFarmsAccounts,
) -> Vec<AccountMeta> {
    let mut accounts = crate::accounts::RepayAndWithdraw {
        repay_accounts: RepayObligationLiquidity {
            lending_market: repay_reserve_accounts.lending_market,
            repay_reserve: repay_reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: repay_reserve_accounts.liquidity_mint.pubkey(),
            obligation: repayer.obligation,
            user_source_liquidity: repayer.borrower_accounts.liquidity,
            reserve_destination_liquidity: repay_reserve_accounts.liquidity_supply,
            owner: repayer.owner.pubkey(),
            token_program: repay_reserve_accounts.liquidity_mint_token_program,
            instruction_sysvar_account: sysvar::instructions::ID,
        },
        withdraw_accounts: WithdrawObligationCollateralAndRedeemReserveCollateral {
            lending_market: withdraw_reserve_accounts.lending_market,
            withdraw_reserve: withdraw_reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: withdraw_reserve_accounts.liquidity_mint.pubkey(),
            reserve_collateral_mint: withdraw_reserve_accounts.collateral_mint,
            reserve_liquidity_supply: withdraw_reserve_accounts.liquidity_supply,
            lending_market_authority: lending_market_accounts.authority,
            obligation: withdrawer.obligation,
            owner: withdrawer.owner.pubkey(),
            user_destination_liquidity: withdrawer.depositor_accounts.liquidity,
            reserve_source_collateral: withdraw_reserve_accounts.collateral_supply,
            instruction_sysvar_account: sysvar::instructions::ID,
            placeholder_user_destination_collateral: None,
            collateral_token_program: Token::id(),
            liquidity_token_program: withdraw_reserve_accounts.liquidity_mint_token_program,
        },
        collateral_farms_accounts,
        debt_farms_accounts,
        farms_program: farms::id(),
    }
    .to_account_metas(None);

    // Add deposit reserves as extra accounts
    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    // Add borrow reserves as extra accounts
    accounts.extend(
        borrow_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    accounts.extend(
        referrer_token_states
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    accounts
}

#[allow(clippy::too_many_arguments)]
pub fn deposit_and_withdraw_and_redeem_ix(
    lending_market_accounts: &LendingMarketAccounts,
    lending_market_accounts_withdraw: &LendingMarketAccounts,
    deposit_reserve_accounts: &ReserveAccounts,
    withdraw_reserve_accounts: &ReserveAccounts,
    depositor: &BorrowerAccounts,
    obligation_deposit: &Pubkey,
    withdrawer: &BorrowerAccounts,
    obligation_withdraw: &Pubkey,
    liquidity_amount: u64,
    withdraw_collateral_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    colls_farms_accounts: &[OptionalObligationFarmsAccounts],
) -> InstructionBlocks {
    let mut accounts = crate::accounts::DepositAndWithdraw {
        deposit_accounts: DepositReserveLiquidityAndObligationCollateral {
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: deposit_reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: deposit_reserve_accounts.liquidity_mint.pubkey(),
            obligation: *obligation_deposit,
            user_source_liquidity: depositor.depositor_accounts.liquidity,
            owner: depositor.owner.pubkey(),
            instruction_sysvar_account: sysvar::instructions::ID,
            lending_market_authority: lending_market_accounts.authority,
            reserve_liquidity_supply: deposit_reserve_accounts.liquidity_supply,
            reserve_collateral_mint: deposit_reserve_accounts.collateral_mint,
            reserve_destination_deposit_collateral: deposit_reserve_accounts.collateral_supply,
            placeholder_user_destination_collateral: None,
            collateral_token_program: Token::id(),
            liquidity_token_program: deposit_reserve_accounts.liquidity_mint_token_program,
        },
        withdraw_accounts: WithdrawObligationCollateralAndRedeemReserveCollateral {
            lending_market: lending_market_accounts_withdraw.market.pubkey(),
            withdraw_reserve: withdraw_reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: withdraw_reserve_accounts.liquidity_mint.pubkey(),
            reserve_collateral_mint: withdraw_reserve_accounts.collateral_mint,
            reserve_liquidity_supply: withdraw_reserve_accounts.liquidity_supply,
            lending_market_authority: lending_market_accounts_withdraw.authority,
            obligation: *obligation_withdraw,
            owner: withdrawer.owner.pubkey(),
            user_destination_liquidity: withdrawer.borrower_accounts.liquidity,
            reserve_source_collateral: withdraw_reserve_accounts.collateral_supply,
            instruction_sysvar_account: sysvar::instructions::ID,
            placeholder_user_destination_collateral: None,
            collateral_token_program: Token::id(),
            liquidity_token_program: withdraw_reserve_accounts.liquidity_mint_token_program,
        },
        deposit_farms_accounts: colls_farms_accounts.get(0).copied().unwrap_or_default(),
        withdraw_farms_accounts: colls_farms_accounts.get(1).copied().unwrap_or_default(),
        farms_program: farms::id(),
    }
    .to_account_metas(None);

    // Add deposit reserves as extra accounts
    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    // Add borrow reserves as extra accounts
    accounts.extend(
        borrow_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    accounts.extend(
        referrer_token_states
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::DepositAndWithdraw {
            liquidity_amount,
            withdraw_collateral_amount,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: depositor.owner.pubkey(),
        signers: vec![depositor.owner.clone(), withdrawer.owner.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn repay_and_withdraw_and_redeem<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    repay_reserve_accounts: &ReserveAccounts,
    withdraw_reserve_accounts: &ReserveAccounts,
    borrower: &BorrowerAccounts,
    repay_amount: u64,
    withdraw_collateral_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    collateral_farms_accounts: OptionalObligationFarmsAccounts,
    debt_farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = repay_and_withdraw_and_redeem_ix(
        lending_market_accounts,
        repay_reserve_accounts,
        withdraw_reserve_accounts,
        borrower,
        borrower,
        repay_amount,
        withdraw_collateral_amount,
        deposit_reserves,
        borrow_reserves,
        referrer_token_states,
        collateral_farms_accounts,
        debt_farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn socialize_loss_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::SocializeLoss {
            lending_market_owner: lending_market_accounts.owner.pubkey(),
            obligation,
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: reserve.address.pubkey(),
            instruction_sysvar_account: sysvar::instructions::ID,
        }
        .to_account_metas(None),
        data: crate::instruction::SocializeLoss { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: lending_market_accounts.owner.pubkey(),
        signers: vec![lending_market_accounts.owner.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn socialize_loss<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
) -> Transaction {
    let instruction = socialize_loss_ix(
        lending_market_accounts,
        reserve_accounts,
        obligation,
        liquidity_amount,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn socialize_loss_v2_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::SocializeLossV2 {
            socialize_loss_accounts: crate::accounts::SocializeLoss {
                lending_market_owner: lending_market_accounts.owner.pubkey(),
                obligation,
                lending_market: lending_market_accounts.market.pubkey(),
                reserve: reserve.address.pubkey(),
                instruction_sysvar_account: sysvar::instructions::ID,
            },
            farms_accounts,
            farms_program: farms::id(),
            lending_market_authority: lending_market_accounts.authority,
        }
        .to_account_metas(None),
        data: crate::instruction::SocializeLossV2 { liquidity_amount }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: lending_market_accounts.owner.pubkey(),
        signers: vec![lending_market_accounts.owner.clone()],
    }
}

pub async fn socialize_loss_v2<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
    farms_accounts: OptionalObligationFarmsAccounts,
) -> Transaction {
    let instruction = socialize_loss_v2_ix(
        lending_market_accounts,
        reserve_accounts,
        obligation,
        liquidity_amount,
        farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn mark_obligation_for_deleveraging_ix(
    lending_market_accounts: &LendingMarketAccounts,
    obligation: Pubkey,
    autodeleverage_target_ltv_pct: u8,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::MarkObligationForDeleveraging {
            lending_market_owner: lending_market_accounts.owner.pubkey(),
            obligation,
            lending_market: lending_market_accounts.market.pubkey(),
        }
        .to_account_metas(None),
        data: crate::instruction::MarkObligationForDeleveraging {
            autodeleverage_target_ltv_pct,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: lending_market_accounts.owner.pubkey(),
        signers: vec![lending_market_accounts.owner.clone()],
    }
}

pub async fn set_obligation_order<'a>(
    ctx: &mut TestContext,
    lending_market: Pubkey,
    owner: &Arc<Keypair>,
    obligation: Pubkey,
    index: u8,
    order: ObligationOrder,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::SetObligationOrder {
            owner: owner.pubkey(),
            obligation,
            lending_market,
        }
        .to_account_metas(None),
        data: crate::instruction::SetObligationOrder { index, order }.data(),
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

pub fn update_obligation_config_ix(
    lending_market: Pubkey,
    owner_pubkey: Pubkey,
    obligation: Pubkey,
    specific_deposit_reserve: Option<Pubkey>,
    specific_borrow_reserve: Option<Pubkey>,
    mode: UpdateObligationConfigMode,
    value: Vec<u8>,
) -> Instruction {
    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::UpdateObligationConfig {
            owner: owner_pubkey,
            obligation,
            deposit_reserve: specific_deposit_reserve,
            borrow_reserve: specific_borrow_reserve,
            lending_market,
        }
        .to_account_metas(None),
        data: crate::instruction::UpdateObligationConfig { mode, value }.data(),
    }
}

pub async fn update_obligation_config<'a>(
    ctx: &mut TestContext,
    lending_market: Pubkey,
    owner: &Arc<Keypair>,
    obligation: Pubkey,
    specific_deposit_reserve: Option<Pubkey>,
    specific_borrow_reserve: Option<Pubkey>,
    mode: UpdateObligationConfigMode,
    value: Vec<u8>,
) -> Transaction {
    let instruction = update_obligation_config_ix(
        lending_market,
        owner.pubkey(),
        obligation,
        specific_deposit_reserve,
        specific_borrow_reserve,
        mode,
        value,
    );

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn set_borrow_order<'a>(
    ctx: &mut TestContext,
    lending_market: Pubkey,
    owner: &Arc<Keypair>,
    obligation: Pubkey,
    reserve: Pubkey,
    debt_liquidity_mint: Pubkey,
    filled_debt_destination: Pubkey,
    order_config: BorrowOrderConfigArgs,
    min_expected_current_remaining_debt_amount: u64,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::SetBorrowOrder {
            owner: owner.pubkey(),
            obligation,
            lending_market,
            reserve,
            debt_liquidity_mint,
            filled_debt_destination,
            event_authority: pda::event_authority(),
            program: crate::ID,
            instruction_sysvar_account: sysvar::instructions::ID,
        }
        .to_account_metas(None),
        data: crate::instruction::SetBorrowOrder {
            order_config,
            min_expected_current_remaining_debt_amount,
        }
        .data(),
    };

    ctx.create_transaction_with_payer([instruction], owner)
        .await
}

fn fill_borrow_order_accounts(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    farms_accounts_opt: Option<OptionalObligationFarmsAccounts>,
    payer: &Keypair,
) -> Vec<AccountMeta> {
    let referrer_token_state_address = if borrower.referrer == Pubkey::default() {
        None
    } else {
        Some(get_referrer_token_state_key(
            &borrower.referrer,
            &reserve_accounts.address.pubkey(),
        ))
    };

    let borrow_accounts = crate::accounts::FillBorrowOrderAccounts {
        payer: payer.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        borrow_reserve: reserve_accounts.address.pubkey(),
        lending_market_authority: lending_market_accounts.authority,
        obligation: *obligation,
        user_destination_liquidity: borrower.liquidity,
        borrow_reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
        reserve_source_liquidity: reserve_accounts.liquidity_supply,
        borrow_reserve_liquidity_fee_receiver: reserve_accounts.fee_receiver,
        referrer_token_state: referrer_token_state_address,
        token_program: reserve_accounts.liquidity_mint_token_program,
        instruction_sysvar_account: sysvar::instructions::ID,
    };

    let mut accounts = crate::accounts::FillBorrowOrder {
        borrow_accounts,
        farms_accounts: farms_accounts_opt.unwrap_or_default(),
        farms_program: farms::id(),
        event_authority: pda::event_authority(),
        program: crate::ID,
    }
    .to_account_metas(None);

    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|reserve| *reserve)
            .map(|reserve| writable!(reserve)),
    );

    accounts
}

pub fn fill_borrow_order_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    farms_accounts_opt: Option<OptionalObligationFarmsAccounts>,
    payer: &Keypair,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: fill_borrow_order_accounts(
            lending_market_accounts,
            reserve_accounts,
            borrower,
            obligation,
            deposit_reserves,
            farms_accounts_opt,
            payer,
        ),
        data: crate::instruction::FillBorrowOrder.data(),
    };

    InstructionBlocks {
        instruction,
        payer: payer.pubkey(),
        signers: vec![Arc::new(payer.insecure_clone())],
    }
}

pub async fn fill_borrow_order<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    obligation: &Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    payer: &Keypair,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: fill_borrow_order_accounts(
            lending_market_accounts,
            reserve_accounts,
            borrower,
            obligation,
            deposit_reserves,
            None,
            payer,
        ),
        data: crate::instruction::FillBorrowOrder.data(),
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn rollover_fixed_term_borrow<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    source_reserve_accounts: &ReserveAccounts,
    target_reserve_accounts: &ReserveAccounts,
    obligation: &Pubkey,
    payer: &Keypair,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::RolloverFixedTermBorrow {
            rollover_accounts: crate::accounts::RolloverAccounts {
                payer: payer.pubkey(),
                lending_market: lending_market_accounts.market.pubkey(),
                source_borrow_reserve: source_reserve_accounts.address.pubkey(),
                source_borrow_reserve_liquidity: source_reserve_accounts.liquidity_supply,
                target_borrow_reserve: target_reserve_accounts.address.pubkey(),
                target_borrow_reserve_liquidity: target_reserve_accounts.liquidity_supply,
                lending_market_authority: lending_market_accounts.authority,
                obligation: *obligation,
                liquidity_mint: source_reserve_accounts.liquidity_mint.pubkey(),
                token_program: source_reserve_accounts.liquidity_mint_token_program,
            },
            source_farms_accounts: OptionalObligationFarmsAccounts::default(),
            target_farms_accounts: OptionalObligationFarmsAccounts::default(),
            farms_program: farms::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::RolloverFixedTermBorrow.data(),
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

#[allow(clippy::too_many_arguments)]
pub fn liquidate_obligation_and_redeem_reserve_collateral_ix(
    lending_market_accounts: &LendingMarketAccounts,
    debt_reserve_accounts: &ReserveAccounts,
    collateral_reserve_accounts: &ReserveAccounts,
    liquidator: &BorrowerAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
    min_acceptable_received_liq_amount: u64,
    max_allowed_ltv_override_percent: u64,
    deposit_reserves: &[Option<Pubkey>],
) -> InstructionBlocks {
    let mut accounts = crate::accounts::LiquidateObligationAndRedeemReserveCollateral {
        liquidator: liquidator.owner.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        repay_reserve: debt_reserve_accounts.address.pubkey(),
        repay_reserve_liquidity_mint: debt_reserve_accounts.liquidity_mint.pubkey(),
        repay_reserve_liquidity_supply: debt_reserve_accounts.liquidity_supply,
        withdraw_reserve: collateral_reserve_accounts.address.pubkey(),
        withdraw_reserve_liquidity_mint: collateral_reserve_accounts.liquidity_mint.pubkey(),
        withdraw_reserve_collateral_mint: collateral_reserve_accounts.collateral_mint,
        withdraw_reserve_collateral_supply: collateral_reserve_accounts.collateral_supply,
        withdraw_reserve_liquidity_supply: collateral_reserve_accounts.liquidity_supply,
        withdraw_reserve_liquidity_fee_receiver: collateral_reserve_accounts.fee_receiver,
        lending_market_authority: lending_market_accounts.authority,
        obligation,
        user_destination_collateral: liquidator.depositor_accounts.collateral,
        user_destination_liquidity: liquidator.depositor_accounts.liquidity,
        user_source_liquidity: liquidator.borrower_accounts.liquidity,
        instruction_sysvar_account: sysvar::instructions::ID,
        repay_liquidity_token_program: debt_reserve_accounts.liquidity_mint_token_program,
        withdraw_liquidity_token_program: collateral_reserve_accounts.liquidity_mint_token_program,
        collateral_token_program: Token::id(),
    }
    .to_account_metas(None);

    // Add deposit reserves as extra accounts
    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::LiquidateObligationAndRedeemReserveCollateral {
            liquidity_amount,
            min_acceptable_received_liquidity_amount: min_acceptable_received_liq_amount,
            max_allowed_ltv_override_percent,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: liquidator.owner.pubkey(),
        signers: vec![liquidator.owner.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub fn liquidate_obligation_and_redeem_reserve_collateral_v2_ix(
    lending_market_accounts: &LendingMarketAccounts,
    debt_reserve_accounts: &ReserveAccounts,
    collateral_reserve_accounts: &ReserveAccounts,
    liquidator: &BorrowerAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
    min_acceptable_received_liq_amount: u64,
    max_allowed_ltv_override_percent: u64,
    deposit_reserves: &[Option<Pubkey>],
    debt_and_collateral_farms_accounts: &[OptionalObligationFarmsAccounts],
) -> InstructionBlocks {
    let base_accounts = crate::accounts::LiquidateObligationAndRedeemReserveCollateral {
        liquidator: liquidator.owner.pubkey(),
        lending_market: lending_market_accounts.market.pubkey(),
        repay_reserve: debt_reserve_accounts.address.pubkey(),
        repay_reserve_liquidity_mint: debt_reserve_accounts.liquidity_mint.pubkey(),
        repay_reserve_liquidity_supply: debt_reserve_accounts.liquidity_supply,
        withdraw_reserve: collateral_reserve_accounts.address.pubkey(),
        withdraw_reserve_liquidity_mint: collateral_reserve_accounts.liquidity_mint.pubkey(),
        withdraw_reserve_collateral_mint: collateral_reserve_accounts.collateral_mint,
        withdraw_reserve_collateral_supply: collateral_reserve_accounts.collateral_supply,
        withdraw_reserve_liquidity_supply: collateral_reserve_accounts.liquidity_supply,
        withdraw_reserve_liquidity_fee_receiver: collateral_reserve_accounts.fee_receiver,
        lending_market_authority: lending_market_accounts.authority,
        obligation,
        user_destination_collateral: liquidator.depositor_accounts.collateral,
        user_destination_liquidity: liquidator.depositor_accounts.liquidity,
        user_source_liquidity: liquidator.borrower_accounts.liquidity,
        instruction_sysvar_account: sysvar::instructions::ID,
        repay_liquidity_token_program: debt_reserve_accounts.liquidity_mint_token_program,
        withdraw_liquidity_token_program: collateral_reserve_accounts.liquidity_mint_token_program,
        collateral_token_program: Token::id(),
    };

    let mut accounts = crate::accounts::LiquidateObligationAndRedeemReserveCollateralV2 {
        liquidation_accounts: base_accounts,
        debt_farms_accounts: debt_and_collateral_farms_accounts
            .get(0)
            .copied()
            .unwrap_or_default(),
        collateral_farms_accounts: debt_and_collateral_farms_accounts
            .get(1)
            .copied()
            .unwrap_or_default(),
        farms_program: farms::id(),
    }
    .to_account_metas(None);

    // Add deposit reserves as extra accounts
    accounts.extend(
        deposit_reserves
            .iter()
            .filter_map(|r| r.map(|a| writable!(a))),
    );

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::LiquidateObligationAndRedeemReserveCollateralV2 {
            liquidity_amount,
            min_acceptable_received_liquidity_amount: min_acceptable_received_liq_amount,
            max_allowed_ltv_override_percent,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: liquidator.owner.pubkey(),
        signers: vec![liquidator.owner.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn liquidate_obligation_and_redeem_reserve_collateral<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    repay_reserve_accounts: &ReserveAccounts,
    withdraw_reserve_accounts: &ReserveAccounts,
    liquidator: &BorrowerAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
    min_acceptable_received_liq_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
) -> Transaction {
    let instruction = liquidate_obligation_and_redeem_reserve_collateral_ix(
        lending_market_accounts,
        repay_reserve_accounts,
        withdraw_reserve_accounts,
        liquidator,
        obligation,
        liquidity_amount,
        min_acceptable_received_liq_amount,
        0,
        deposit_reserves,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

#[allow(clippy::too_many_arguments)]
pub async fn liquidate_obligation_and_redeem_reserve_collateral_v2<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    repay_reserve_accounts: &ReserveAccounts,
    withdraw_reserve_accounts: &ReserveAccounts,
    liquidator: &BorrowerAccounts,
    obligation: Pubkey,
    liquidity_amount: u64,
    min_acceptable_received_liq_amount: u64,
    deposit_reserves: &[Option<Pubkey>],
    debt_and_collateral_farms_accounts: &[OptionalObligationFarmsAccounts],
) -> Transaction {
    let instruction = liquidate_obligation_and_redeem_reserve_collateral_v2_ix(
        lending_market_accounts,
        repay_reserve_accounts,
        withdraw_reserve_accounts,
        liquidator,
        obligation,
        liquidity_amount,
        min_acceptable_received_liq_amount,
        0,
        deposit_reserves,
        debt_and_collateral_farms_accounts,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn refresh_obligation_ix(
    market: Pubkey,
    obligation: Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    payer: Arc<Keypair>,
) -> InstructionBlocks {
    let mut accounts = crate::accounts::RefreshObligation {
        obligation,
        lending_market: market,
    }
    .to_account_metas(None);

    deposit_reserves
        .iter()
        .filter(|reserve| reserve.is_some())
        .for_each(|reserve| {
            accounts.push(writable!(reserve.unwrap()));
        });

    borrow_reserves
        .iter()
        .filter(|reserve| reserve.is_some())
        .for_each(|reserve| {
            accounts.push(writable!(reserve.unwrap()));
        });

    referrer_token_states
        .iter()
        .filter(|referrer_token_state: &&Option<Pubkey>| referrer_token_state.is_some())
        .for_each(|referrer_token_state| {
            accounts.push(writable!(referrer_token_state.unwrap()));
        });

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RefreshObligation.data(),
    };

    InstructionBlocks {
        instruction,
        payer: payer.pubkey(),
        signers: vec![payer.clone()],
    }
}

pub fn request_elevation_group_ix(
    market: Pubkey,
    obligation: Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    payer: Arc<Keypair>,
    new_elevation_group: u8,
) -> InstructionBlocks {
    let mut accounts = crate::accounts::RequestElevationGroup {
        owner: payer.pubkey(),
        obligation,
        lending_market: market,
    }
    .to_account_metas(None);

    deposit_reserves
        .iter()
        .filter(|reserve| reserve.is_some())
        .for_each(|reserve| {
            accounts.push(writable!(reserve.unwrap()));
        });

    borrow_reserves
        .iter()
        .filter(|reserve| reserve.is_some())
        .for_each(|reserve| {
            accounts.push(writable!(reserve.unwrap()));
        });

    referrer_token_states
        .iter()
        .filter(|referrer_token_state: &&Option<Pubkey>| referrer_token_state.is_some())
        .for_each(|referrer_token_state| {
            accounts.push(writable!(referrer_token_state.unwrap()));
        });

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RequestElevationGroup {
            elevation_group: new_elevation_group,
        }
        .data(),
    };

    InstructionBlocks {
        instruction,
        payer: payer.pubkey(),
        signers: vec![payer.clone()],
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn request_elevation_group(
    ctx: &mut TestContext,
    market: Pubkey,
    obligation: Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    payer: Arc<Keypair>,
    new_elevation_group: u8,
) -> Transaction {
    let instruction = request_elevation_group_ix(
        market,
        obligation,
        deposit_reserves,
        borrow_reserves,
        referrer_token_states,
        payer,
        new_elevation_group,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub async fn refresh_obligation(
    ctx: &mut TestContext,
    market: Pubkey,
    obligation: Pubkey,
    deposit_reserves: &[Option<Pubkey>],
    borrow_reserves: &[Option<Pubkey>],
    referrer_token_states: &[Option<Pubkey>],
    payer: Arc<Keypair>,
) -> Transaction {
    let instruction = refresh_obligation_ix(
        market,
        obligation,
        deposit_reserves,
        borrow_reserves,
        referrer_token_states,
        payer,
    );

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn refresh_reserve_ix(
    reserve: Reserve,
    address: &Pubkey,
    payer: Arc<Keypair>,
) -> InstructionBlocks {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::RefreshReserve {
            lending_market: reserve.lending_market,
            reserve: *address,
            pyth_oracle: maybe_null_pk(reserve.config.token_info.pyth_configuration.price),
            switchboard_price_oracle: maybe_null_pk(
                reserve
                    .config
                    .token_info
                    .switchboard_configuration
                    .price_aggregator,
            ),
            switchboard_twap_oracle: maybe_null_pk(
                reserve
                    .config
                    .token_info
                    .switchboard_configuration
                    .twap_aggregator,
            ),
            scope_prices: maybe_null_pk(reserve.config.token_info.scope_configuration.price_feed),
        }
        .to_account_metas(None),
        data: crate::instruction::RefreshReserve.data(),
    };

    InstructionBlocks {
        instruction,
        payer: payer.pubkey(),
        signers: vec![payer.clone()],
    }
}

pub async fn refresh_reserve<'a>(
    ctx: &mut TestContext,
    reserve: Reserve,
    reserve_accounts: &ReserveAccounts,
    payer: Arc<Keypair>,
) -> Transaction {
    let instruction = refresh_reserve_ix(reserve, &reserve_accounts.address.pubkey(), payer);

    ctx.create_transaction_from_blocks(instruction).await
}

pub fn refresh_reserves_batch_ix<'a>(
    reserves_iter: impl Iterator<Item = &'a (Pubkey, Reserve)>,
    skip_price_updates: bool,
    payer: Arc<Keypair>,
) -> InstructionBlocks {
    let accounts = reserves_iter
        .flat_map(|(reserve_pk, reserve)| {
            let reserve_acc = writable!(*reserve_pk);
            let lending_market_acc = readable!(reserve.lending_market);
            if skip_price_updates {
                vec![reserve_acc, lending_market_acc].into_iter()
            } else {
                let pyth_oracle_acc =
                    maybe_account_meta(reserve.config.token_info.pyth_configuration.price);
                let switchboard_price_oracle_acc = maybe_account_meta(
                    reserve
                        .config
                        .token_info
                        .switchboard_configuration
                        .price_aggregator,
                );
                let switchboard_twap_oracle_acc = maybe_account_meta(
                    reserve
                        .config
                        .token_info
                        .switchboard_configuration
                        .twap_aggregator,
                );
                let scope_prices_acc =
                    maybe_account_meta(reserve.config.token_info.scope_configuration.price_feed);
                vec![
                    reserve_acc,
                    lending_market_acc,
                    pyth_oracle_acc,
                    switchboard_price_oracle_acc,
                    switchboard_twap_oracle_acc,
                    scope_prices_acc,
                ]
                .into_iter()
            }
        })
        .collect::<Vec<AccountMeta>>();

    let instruction = Instruction {
        program_id: crate::id(),
        accounts,
        data: crate::instruction::RefreshReservesBatch { skip_price_updates }.data(),
    };

    InstructionBlocks {
        instruction,
        payer: payer.pubkey(),
        signers: vec![payer.clone()],
    }
}

pub async fn refresh_reserves_batch<'a>(
    ctx: &mut TestContext,
    reserves_iter: impl Iterator<Item = &(Pubkey, Reserve)>,
    skip_price_updates: bool,
    payer: Arc<Keypair>,
) -> Transaction {
    let instruction = refresh_reserves_batch_ix(reserves_iter, skip_price_updates, payer);

    ctx.create_transaction_from_blocks(instruction).await
}

pub async fn redeem_fees<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    payer: Arc<Keypair>,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::RedeemFees {
            lending_market: lending_market_accounts.market.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_liquidity_fee_receiver: reserve_accounts.fee_receiver,
            reserve_supply_liquidity: reserve_accounts.liquidity_supply,
            token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::RedeemFees.data(),
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn withdraw_protocol_fees<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    amount: u64,
) -> Transaction {
    let payer = lending_market_accounts.owner.clone();
    let owner_ata = spl_associated_token_account::get_associated_token_address_with_program_id(
        &lending_market_accounts.owner.pubkey(),
        &reserve_accounts.liquidity_mint.pubkey(),
        &reserve_accounts.liquidity_mint_token_program,
    );
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::WithdrawProtocolFees {
            global_config: pda::global_config(),
            lending_market: lending_market_accounts.market.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            fee_vault: reserve_accounts.fee_receiver,
            fee_collector_ata: owner_ata,
            token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::WithdrawProtocolFee { amount }.data(),
    };

    ctx.create_transaction_with_payer([instruction], payer)
        .await
}

pub async fn flash_loan<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    liquidity_amount: u64,
    borrow_instruction_index: u8,
) -> Transaction {
    let ix_flash_borrow = flash_borrow_ix(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        liquidity_amount,
    );

    let ix_flash_repay = flash_repay_ix(
        lending_market_accounts,
        reserve_accounts,
        borrower,
        liquidity_amount,
        borrow_instruction_index,
    );

    ctx.create_transaction_with_payer([ix_flash_borrow, ix_flash_repay], &borrower.owner)
        .await
}

pub fn flash_borrow_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    liquidity_amount: u64,
) -> Instruction {
    let referrer_token_state_address =
        get_referrer_token_state_key_option(&borrower.referrer, &reserve_accounts.address.pubkey());

    let referrer_account = if borrower.referrer == Pubkey::default() {
        None
    } else {
        Some(borrower.referrer)
    };

    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::FlashBorrowReserveLiquidity {
            user_transfer_authority: borrower.owner.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_source_liquidity: reserve_accounts.liquidity_supply,
            user_destination_liquidity: borrower.liquidity,
            reserve_liquidity_fee_receiver: reserve_accounts.fee_receiver,
            referrer_token_state: referrer_token_state_address,
            referrer_account,
            sysvar_info: sysvar::instructions::id(),
            token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::FlashBorrowReserveLiquidity { liquidity_amount }.data(),
    }
}

pub fn flash_repay_ix(
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    borrower: &DepositorAccounts,
    liquidity_amount: u64,
    borrow_instruction_index: u8,
) -> Instruction {
    let referrer_token_state_address =
        get_referrer_token_state_key_option(&borrower.referrer, &reserve_accounts.address.pubkey());

    let referrer_account = if borrower.referrer == Pubkey::default() {
        None
    } else {
        Some(borrower.referrer)
    };

    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::FlashRepayReserveLiquidity {
            user_transfer_authority: borrower.owner.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            lending_market: lending_market_accounts.market.pubkey(),
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_destination_liquidity: reserve_accounts.liquidity_supply,
            user_source_liquidity: borrower.liquidity,
            reserve_liquidity_fee_receiver: reserve_accounts.fee_receiver,
            referrer_token_state: referrer_token_state_address,
            referrer_account,
            sysvar_info: sysvar::instructions::id(),
            token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::FlashRepayReserveLiquidity {
            liquidity_amount,
            borrow_instruction_index,
        }
        .data(),
    }
}

pub async fn withdraw_referrer_fees<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    referrer: &Arc<Keypair>,
    referrer_token_account: &Pubkey,
    referrer_token_state: &Pubkey,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::WithdrawReferrerFees {
            referrer: referrer.pubkey(),
            referrer_token_state: *referrer_token_state,
            referrer_token_account: *referrer_token_account,
            lending_market: lending_market_accounts.market.pubkey(),
            lending_market_authority: lending_market_accounts.authority,
            reserve: reserve_accounts.address.pubkey(),
            reserve_liquidity_mint: reserve_accounts.liquidity_mint.pubkey(),
            reserve_supply_liquidity: reserve_accounts.liquidity_supply,
            token_program: reserve_accounts.liquidity_mint_token_program,
        }
        .to_account_metas(None),
        data: crate::instruction::WithdrawReferrerFees.data(),
    };
    ctx.create_transaction_with_payer([instruction], referrer)
        .await
}

pub async fn init_referrer_state_and_short_url<'a>(
    ctx: &mut TestContext,
    referrer: &Arc<Keypair>,
    short_url: &str,
    referrer_state: Pubkey,
    referrer_short_url: Pubkey,
) -> Transaction {
    let referrer_user_metadata_pk = get_user_metadata_key(referrer.pubkey());
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::InitReferrerStateAndShortUrl {
            referrer: referrer.pubkey(),
            referrer_state,
            referrer_short_url,
            referrer_user_metadata: referrer_user_metadata_pk,
            rent: sysvar::rent::ID,
            system_program: System::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::InitReferrerStateAndShortUrl {
            short_url: short_url.to_owned(),
        }
        .data(),
    };

    ctx.create_transaction_with_payer([instruction], referrer)
        .await
}

pub async fn delete_referrer_state_and_short_url<'a>(
    ctx: &mut TestContext,
    referrer: &Arc<Keypair>,
    referrer_state: Pubkey,
    referrer_short_url: Pubkey,
) -> Transaction {
    let instruction = Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::DeleteReferrerStateAndShortUrl {
            referrer: referrer.pubkey(),
            referrer_state,
            short_url: referrer_short_url,
            rent: sysvar::rent::ID,
            system_program: System::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::DeleteReferrerStateAndShortUrl.data(),
    };

    ctx.create_transaction_with_payer([instruction], referrer)
        .await
}

// Obligation ownership transfer instructions

pub fn initiate_obligation_ownership_transfer_ix(
    owner: Pubkey,
    obligation: Pubkey,
    new_owner: Pubkey,
) -> Instruction {
    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::InitiateObligationOwnershipTransfer {
            owner,
            obligation,
            instruction_sysvar_account: sysvar::instructions::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::InitiateObligationOwnershipTransfer { new_owner }.data(),
    }
}

pub fn approve_obligation_ownership_transfer_ix(
    global_admin: Pubkey,
    obligation: Pubkey,
    pending_owner: Pubkey,
) -> Instruction {
    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::ApproveObligationOwnershipTransfer {
            global_admin,
            global_config: pda::global_config(),
            obligation,
            pending_owner,
        }
        .to_account_metas(None),
        data: crate::instruction::ApproveObligationOwnershipTransfer.data(),
    }
}

pub fn abort_obligation_ownership_transfer_ix(owner: Pubkey, obligation: Pubkey) -> Instruction {
    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::AbortObligationOwnershipTransfer {
            owner,
            obligation,
            instruction_sysvar_account: sysvar::instructions::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::AbortObligationOwnershipTransfer.data(),
    }
}

pub fn accept_obligation_ownership_ix(pending_owner: Pubkey, obligation: Pubkey) -> Instruction {
    Instruction {
        program_id: crate::id(),
        accounts: crate::accounts::AcceptObligationOwnership {
            pending_owner,
            obligation,
            instruction_sysvar_account: sysvar::instructions::id(),
        }
        .to_account_metas(None),
        data: crate::instruction::AcceptObligationOwnership.data(),
    }
}

use std::collections::HashSet;

use solana_program::{
    hash::Hash,
    pubkey::Pubkey,
    sysvar::{Sysvar, SysvarId},
};
use solana_program_test::{BanksClientError, ProgramTestContext};
use solana_sdk::{
    account::{Account, AccountSharedData},
    commitment_config::CommitmentLevel,
    signature::Keypair,
    transaction::VersionedTransaction,
};

pub struct ProgramTestContextWrapper {
    underlying: ProgramTestContext,
    existing_addresses: HashSet<Pubkey>,
}

impl ProgramTestContextWrapper {
    pub fn wrap(underlying: ProgramTestContext) -> Self {
        Self {
            underlying,
            existing_addresses: HashSet::new(),
        }
    }

    pub fn payer(&self) -> &Keypair {
        &self.underlying.payer
    }

    pub async fn get_new_latest_blockhash(&mut self) -> Result<Hash, BanksClientError> {
        self.underlying.banks_client.get_latest_blockhash().await
    }

    pub async fn get_balance(&mut self, address: Pubkey) -> Result<u64, BanksClientError> {
        self.underlying.banks_client.get_balance(address).await
    }

    pub async fn get_account(
        &mut self,
        address: Pubkey,
    ) -> Result<Option<Account>, BanksClientError> {
        self.underlying.banks_client.get_account(address).await
    }

    pub fn set_account(&mut self, address: Pubkey, account: AccountSharedData) {
        self.underlying.set_account(&address, &account);
    }

    pub async fn get_program_accounts(
        &mut self,
        program_address: Pubkey,
    ) -> Result<Vec<(Pubkey, Account)>, BanksClientError> {
        let mut program_accounts = Vec::new();
        for address in &self.existing_addresses {
            let Some(account) = self.underlying.banks_client.get_account(*address).await? else {
                continue; // must have been deleted, but we do not track it
            };
            if account.owner == program_address {
                program_accounts.push((*address, account));
            }
        }
        Ok(program_accounts)
    }

    pub async fn get_sysvar<T: Sysvar>(&mut self) -> Result<T, BanksClientError> {
        self.underlying.banks_client.get_sysvar().await
    }

    pub fn set_sysvar<T: SysvarId + Sysvar>(&mut self, sysvar: &T) {
        self.underlying.set_sysvar(sysvar);
    }

    pub async fn process_transaction_with_commitment(
        &mut self,
        transaction: VersionedTransaction,
        commitment: CommitmentLevel,
    ) -> Result<(), BanksClientError> {
        let previously_not_existing_addresses = self.get_not_existing_addresses(&transaction);
        self.underlying
            .banks_client
            .process_transaction_with_commitment(transaction, commitment)
            .await?;
        self.update_existing_addresses(previously_not_existing_addresses)
            .await;
        Ok(())
    }

    fn get_not_existing_addresses(&self, transaction: &VersionedTransaction) -> Vec<Pubkey> {
        transaction
            .message
            .static_account_keys()
            .iter()
            .filter(|address| !self.existing_addresses.contains(address))
            .cloned()
            .collect()
    }

    async fn update_existing_addresses(&mut self, potential_new_existing_addresses: Vec<Pubkey>) {
        for address in potential_new_existing_addresses {
            if self
                .underlying
                .banks_client
                .get_account(address)
                .await
                .unwrap()
                .is_some()
            {
                self.existing_addresses.insert(address);
            }
        }
    }
}

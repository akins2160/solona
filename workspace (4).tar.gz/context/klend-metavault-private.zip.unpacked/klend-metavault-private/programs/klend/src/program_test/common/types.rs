use std::{collections::HashMap, sync::Arc};

use anchor_lang::{
    prelude::{thiserror, Pubkey, Rent},
    Id,
};
use anchor_spl::{
    token::{spl_token, Token},
    token_2022::spl_token_2022,
    token_interface::Token2022,
};
use solana_sdk::signature::{Keypair, Signer};
use thiserror::Error;

use crate::{
    fraction::FractionExtra,
    program_test::common::{
        context::ProgramTestContextWrapper, runner::state, token_operations::TokenExtension,
    },
    utils::Fraction,
    Obligation, Reserve, ReserveConfig,
};
// --- GENERIC TYPES ---

pub struct TestContext {
    pub initial_market_owner: Arc<Keypair>,
    pub context: ProgramTestContextWrapper,
    pub rent: Rent,
    pub use_instructions_v2: bool,
    pub global_config: Pubkey,
    pub tx_counter: u16,
}

#[derive(Error, Debug)]
pub enum TestError {
    #[error("Insufficient collateral to cover debt")]
    CannotDeserialize,
    #[error("Wrong discriminator")]
    BadDiscriminator,
    #[error("Account not found")]
    AccountNotFound,
    #[error("Unknown Error")]
    UnknownError,
    #[error("BanksClientError: {0:?}")]
    BanksClientError(Box<solana_program_test::BanksClientError>),
}

impl From<solana_program_test::BanksClientError> for TestError {
    fn from(e: solana_program_test::BanksClientError) -> Self {
        TestError::BanksClientError(Box::new(e))
    }
}

// ---- MARKET TYPES ----

#[derive(Debug, Clone)]
pub struct LendingMarketAccounts {
    pub market: Arc<Keypair>,
    pub owner: Arc<Keypair>,
    pub authority: Pubkey,
    pub farms_global_config: Arc<Keypair>,
    pub farms_treasury_vault_authority: Pubkey,
}

#[derive(Clone, Debug, PartialEq)]
pub struct FarmAccounts {
    pub farm_state: Pubkey,

    pub farm_vault_authority: Pubkey,
    pub reward_vault: Pubkey,
    pub admin_reward_ata: Pubkey,
    pub reward_treasury_vault: Pubkey,
    pub reward_mint: Arc<Keypair>,
}

#[derive(Debug, Clone)]
pub struct KaminoMarket {
    pub primary_market: LendingMarketAccounts,
    pub sol_reserve: ReserveAccounts,
    pub usdc_reserve: ReserveAccounts,
    pub oracles: OracleAccounts,
}

impl KaminoMarket {
    pub fn reserve(&self) -> Pubkey {
        self.usdc_reserve.address.pubkey()
    }

    pub fn sol_reserve(&self) -> Pubkey {
        self.sol_reserve.address.pubkey()
    }

    pub fn sol_reserve_accounts(&self) -> &ReserveAccounts {
        &self.sol_reserve
    }

    pub fn reserve_accounts(&self) -> &ReserveAccounts {
        &self.usdc_reserve
    }
}

#[derive(Debug, Clone)]
pub struct KaminoMarkets {
    pub mints: HashMap<String, MintAccounts>,
    pub markets: Vec<KaminoMarketGeneric>,
}

#[derive(Debug, Clone)]
pub struct KaminoMarketGeneric {
    pub primary_market: LendingMarketAccounts,
    pub reserves: HashMap<String, ReserveAccounts>,
    pub oracles: GenericOracleAccounts,
}

impl KaminoMarketGeneric {
    pub fn get_reserve(&self, name: &str) -> ReserveAccounts {
        self.reserves.get(name).unwrap().clone()
    }
}

#[derive(Debug, Clone)]
pub struct MintAccounts {
    pub mint: Pubkey,
    pub token_program: Pubkey,
}

impl MintAccounts {
    pub fn new(mint: Pubkey, token_program: Pubkey) -> Self {
        MintAccounts {
            mint,
            token_program,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ReserveAccounts {
    pub address: Arc<Keypair>,
    pub lending_market: Pubkey,
    pub lending_market_authority: Pubkey,
    pub liquidity_mint: Arc<Keypair>,
    pub liquidity_mint_token_program: Pubkey,
    pub liquidity_supply: Pubkey,
    pub collateral_mint: Pubkey,
    pub collateral_supply: Pubkey,
    pub fee_receiver: Pubkey,
    pub pyth_price: Pubkey,
    pub switchboard_feed: Pubkey,
    pub switchboard_twap_feed: Pubkey,
    pub scope_prices: Pubkey,
    pub admin_farm_accounts: [Option<FarmAccounts>; 2], // One for each mode of the rewards (debt, coll, liquidity)
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ReserveBalances {
    pub liquidity: u64,
    pub collateral: u64,
    pub fee_vault: u64,
    pub ctoken_supply: u64,
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ReserveAccounting {
    pub total_supply: Fraction,
    pub total_available_liquidity: u64,
    pub ctoken_supply_accounting: u64,
    pub protocol_interest_fees: Fraction,
    pub borrowed_amount: Fraction,
    pub pending_referral_fees: Fraction,
}

impl ReserveAccounts {
    pub async fn balances(&self, ctx: &mut TestContext) -> ReserveBalances {
        let liquidity_supply = ctx.get_balance(&self.liquidity_supply).await;
        let collateral_supply = ctx.get_balance(&self.collateral_supply).await;
        let fee_receiver = ctx.get_balance(&self.fee_receiver).await;

        let reserve = state::get::<Reserve>(ctx, self.address.pubkey()).await;

        let ctoken_mint = reserve.collateral.mint_pubkey;
        let ctoken_supply = ctx.mint_info(&ctoken_mint).await;

        ReserveBalances {
            liquidity: liquidity_supply,
            collateral: collateral_supply,
            fee_vault: fee_receiver,
            ctoken_supply: ctoken_supply.supply,
        }
    }

    pub async fn accounting(&self, ctx: &mut TestContext) -> ReserveAccounting {
        let reserve = state::get::<Reserve>(ctx, self.address.pubkey()).await;
        let ctoken_supply_accounting = reserve.collateral.mint_total_supply;
        let protocol_interest_fees =
            Fraction::from_sf(reserve.liquidity.accumulated_protocol_fees_sf);

        ReserveAccounting {
            total_supply: reserve.liquidity.total_supply(),
            total_available_liquidity: reserve.liquidity.total_available_amount,
            borrowed_amount: Fraction::from_bits(reserve.liquidity.borrowed_amount_sf),
            ctoken_supply_accounting,
            protocol_interest_fees,
            pending_referral_fees: Fraction::from_bits(reserve.liquidity.pending_referrer_fees_sf),
        }
    }

    pub async fn ctoken_exchange_rate_fraction(&self, ctx: &mut TestContext) -> Fraction {
        let reserve = state::get::<Reserve>(ctx, self.address.pubkey()).await;
        reserve.collateral_exchange_rate().into()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ReferrerAccounts {
    pub address: Pubkey,
    pub owner: Pubkey,
    pub reserve: Pubkey,
}

impl ReserveAccounts {
    pub fn pubkey(&self) -> Pubkey {
        self.address.pubkey()
    }
}

#[derive(Debug, Clone)]
pub struct MarketsSpec {
    pub mints: HashMap<String, MintSpec>,
    pub markets: Vec<MSpec>,
}

#[derive(Debug, Clone)]
pub struct MSpec {
    pub reserves: Vec<RSpec>,
}

impl MSpec {
    pub fn new(reserves: Vec<RSpec>) -> Self {
        MSpec { reserves }
    }
}

#[derive(Debug, Clone)]
pub struct RSpec {
    pub name: String,
    pub mint_name: String,
    pub initial_liquidity: u64,
    pub config: Option<ReserveConfig>,
}

impl RSpec {
    pub fn new(name: &str, initial_liquidity: u64) -> Self {
        RSpec {
            name: name.to_string(),
            mint_name: name.to_string(),
            initial_liquidity,
            config: None,
        }
    }
}

#[derive(Debug, Clone)]
pub struct MarketSpec {
    pub reserves: Vec<ReserveSpec>,
}

#[derive(Debug, Clone)]
pub struct MintSpec {
    pub decimals: u8,
    pub token_program: Pubkey,
    pub extensions: Vec<TokenExtension>,
    pub price: f64,
}

impl MintSpec {
    pub fn new(
        decimals: u8,
        token_program: Pubkey,
        extensions: Vec<TokenExtension>,
        price: f64,
    ) -> Self {
        MintSpec {
            decimals,
            token_program,
            extensions,
            price,
        }
    }

    pub fn spl(decimals: u8, price: f64) -> Self {
        MintSpec {
            decimals,
            token_program: Token::id(),
            extensions: Vec::new(),
            price,
        }
    }

    pub fn with_extensions(decimals: u8, price: f64, extensions: &[TokenExtension]) -> Self {
        MintSpec {
            decimals,
            token_program: Token2022::id(),
            extensions: extensions.to_vec(),
            price,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ReserveSpec {
    pub name: String,
    pub decimals: u8,
    pub initial_liquidity: u64,
    pub price: f64,
    pub liquidity_token_program: Pubkey,
    pub liquidity_token_extensions: Vec<TokenExtension>,
}

impl ReserveSpec {
    pub fn new(name: &str, decimals: u8, initial_liquidity: u64, price: f64) -> Self {
        ReserveSpec::new_with_token_program(
            name,
            decimals,
            initial_liquidity,
            price,
            spl_token::id(),
        )
    }

    pub fn new_with_token_program(
        name: &str,
        decimals: u8,
        initial_liquidity: u64,
        price: f64,
        liquidity_token_program: Pubkey,
    ) -> Self {
        ReserveSpec {
            name: name.to_string(),
            decimals,
            initial_liquidity,
            price,
            liquidity_token_program,
            liquidity_token_extensions: vec![],
        }
    }

    pub fn new_with_liquidity_extensions(
        name: &str,
        decimals: u8,
        initial_liquidity: u64,
        price: f64,
        extensions: &[TokenExtension],
    ) -> Self {
        ReserveSpec {
            name: name.to_string(),
            decimals,
            initial_liquidity,
            price,
            liquidity_token_program: spl_token_2022::id(),
            liquidity_token_extensions: extensions.to_vec(),
        }
    }
}

// ---- BORROWER TYPES ----

#[derive(Clone, Debug)]
pub struct DepositorAccounts {
    pub reserve: Pubkey,
    pub liquidity: Pubkey,
    pub collateral: Pubkey,
    pub owner: Arc<Keypair>,
    pub referrer: Pubkey,
}

#[derive(Clone, Debug)]
pub struct BorrowerAccounts {
    pub depositor_accounts: DepositorAccounts,
    pub borrower_accounts: DepositorAccounts,
    pub obligation: Pubkey,
    pub owner: Arc<Keypair>,
    pub user_metadata: Pubkey,
}

#[derive(Debug, Eq, PartialEq, Clone, Default)]
pub struct BorrowerBalances {
    pub coll_token_balance: u64,
    pub liquidity_deposited: u64,
    pub ctoken_deposited: u64,
    pub debt: Fraction,
    pub debt_ata: u64,
}

#[derive(Debug, Eq, PartialEq, Clone, Default)]
pub struct BorrowerBalancesExtended {
    pub debt: Fraction,
    pub coll_ctoken_balance: u64,
    pub debt_ctoken_balance: u64,
    pub coll_ctoken_deposited: u64,
    pub debt_ctoken_deposited: u64,
    pub coll_token_liquidity_deposited: u64,
    pub debt_token_liquidity_deposited: u64,
    pub coll_token_balance: u64,
    pub debt_token_balance: u64,
}

impl BorrowerAccounts {
    pub async fn refesh_obligation(&self, ctx: &mut TestContext, market: &KaminoMarket) {
        ctx.refresh_obligation(
            market.primary_market.market.pubkey(),
            self.obligation,
            self.owner.clone(),
        )
        .await
        .unwrap();
    }

    pub async fn borrow_usdc(&self, ctx: &mut TestContext, market: &KaminoMarket, amount: u64) {
        ctx.borrow_obligation_liquidity(
            &market.primary_market,
            &market.usdc_reserve,
            &self.borrower_accounts,
            &self.obligation,
            amount,
        )
        .await
        .unwrap();
    }

    pub async fn repay_usdc(&self, ctx: &mut TestContext, market: &KaminoMarket, amount: u64) {
        ctx.repay_obligation_liquidity(
            &market.primary_market,
            &market.usdc_reserve,
            &self.borrower_accounts,
            &self.obligation,
            amount,
        )
        .await
        .unwrap();
    }

    pub async fn deposit_sol(&self, ctx: &mut TestContext, market: &KaminoMarket, amount: u64) {
        ctx.deposit_reserve_liquidity_and_obligation_collateral(
            &market.sol_reserve,
            &self.depositor_accounts,
            &self.obligation,
            amount,
        )
        .await
        .unwrap();
    }

    pub async fn deposit_usdc(&self, ctx: &mut TestContext, market: &KaminoMarket, amount: u64) {
        ctx.deposit_reserve_liquidity_and_obligation_collateral(
            &market.usdc_reserve,
            &self.depositor_accounts,
            &self.obligation,
            amount,
        )
        .await
        .unwrap();
    }

    pub async fn withdraw_usdc(&self, ctx: &mut TestContext, market: &KaminoMarket, amount: u64) {
        ctx.withdraw_obligation_collateral_and_redeem_reserve_collateral(
            &market.primary_market,
            &market.usdc_reserve,
            &self.depositor_accounts,
            &self.obligation,
            amount,
        )
        .await
        .unwrap();
    }

    pub async fn balances(
        &self,
        ctx: &mut TestContext,
        market: &KaminoMarket,
        with_refresh: bool,
    ) -> BorrowerBalances {
        let balances_extended = self.balances_extended(ctx, market, with_refresh).await;
        BorrowerBalances {
            coll_token_balance: balances_extended.coll_token_balance,
            liquidity_deposited: balances_extended.coll_token_liquidity_deposited,
            ctoken_deposited: balances_extended.coll_ctoken_deposited,
            debt: balances_extended.debt,
            debt_ata: balances_extended.debt_token_balance,
        }
    }

    pub async fn balances_extended(
        &self,
        ctx: &mut TestContext,
        market: &KaminoMarket,
        with_refresh: bool,
    ) -> BorrowerBalancesExtended {
        use spl_associated_token_account::get_associated_token_address as ata;

        let obligation_address = self.obligation;
        let obligation_opt = state::try_get::<Obligation>(ctx, obligation_address).await;

        // cTokens
        let coll_reserve_address = self.depositor_accounts.reserve;
        let debt_reserve_address = self.borrower_accounts.reserve;
        let coll_reserve = state::get::<Reserve>(ctx, coll_reserve_address).await;
        let debt_reserve = state::get::<Reserve>(ctx, debt_reserve_address).await;
        let coll_ctoken_mint = coll_reserve.collateral.mint_pubkey;
        let debt_ctoken_mint = debt_reserve.collateral.mint_pubkey;
        let coll_ctoken_ata = ata(&self.depositor_accounts.owner.pubkey(), &coll_ctoken_mint);
        let debt_ctoken_ata = ata(&self.borrower_accounts.owner.pubkey(), &debt_ctoken_mint);
        let coll_ctoken_balance = ctx.get_balance(&coll_ctoken_ata).await;
        let debt_ctoken_balance = ctx.get_balance(&debt_ctoken_ata).await;

        let mut coll_ctoken_deposited = 0;
        let mut debt_ctoken_deposited = 0;

        let mut debt = Fraction::from_bits(0);

        if let Ok(obligation) = obligation_opt {
            if with_refresh {
                // Refresh the obligation
                self.refesh_obligation(ctx, market).await;
            }

            debt = obligation.borrows[0].borrowed_amount();

            coll_ctoken_deposited = obligation
                .deposits
                .iter()
                .find(|d| d.deposit_reserve == coll_reserve_address)
                .unwrap_or(&crate::ObligationCollateral::new(Pubkey::default()))
                .deposited_amount;

            debt_ctoken_deposited = obligation
                .deposits
                .iter()
                .find(|d| d.deposit_reserve == debt_reserve_address)
                .unwrap_or(&crate::ObligationCollateral::new(Pubkey::default()))
                .deposited_amount;
        }

        let coll_token_liquidity_deposited = coll_reserve
            .collateral_exchange_rate()
            .collateral_to_liquidity(coll_ctoken_deposited);

        let debt_token_liquidity_deposited = debt_reserve
            .collateral_exchange_rate()
            .collateral_to_liquidity(debt_ctoken_deposited);

        let coll_token_balance = ctx.get_balance(&self.depositor_accounts.liquidity).await;
        let debt_token_balance = ctx.get_balance(&self.borrower_accounts.liquidity).await;

        BorrowerBalancesExtended {
            debt,
            coll_ctoken_balance,
            debt_ctoken_balance,
            coll_token_liquidity_deposited,
            debt_token_liquidity_deposited,
            coll_ctoken_deposited,
            debt_ctoken_deposited,
            debt_token_balance,
            coll_token_balance,
        }
    }
}

#[derive(Debug, Clone)]
pub struct BorrowerGenericReservesAccounts {
    pub reserve_accounts: HashMap<String, DepositorAccounts>,
    pub obligation: Pubkey,
    pub owner: Arc<Keypair>,
    pub user_metadata: Pubkey,
    pub reserves_entered_deposited: Vec<(String, u64)>,
    pub reserves_entered_borrowed: Vec<(String, u64)>,
    pub last_slot_updated: u64,
}

#[derive(Debug, Clone)]
pub struct BorrowerGenericBalances {
    pub coll_token_balance: u64,
    pub ctoken_deposited: u64,
    pub debt: Fraction,
}

impl BorrowerGenericReservesAccounts {
    pub fn get_borrower_accounts_from_reserves(
        &self,
        deposit_reserve: &str,
        borrow_reserve: &str,
    ) -> BorrowerAccounts {
        BorrowerAccounts {
            depositor_accounts: self.reserve_accounts[deposit_reserve].clone(),
            borrower_accounts: self.reserve_accounts[borrow_reserve].clone(),
            obligation: self.obligation,
            owner: self.owner.clone(),
            user_metadata: self.user_metadata,
        }
    }

    pub fn get_user_reserve_accounts(&self, reserve_name: &str) -> DepositorAccounts {
        self.reserve_accounts[reserve_name].clone()
    }

    pub fn get_borrower_accounts_same_reserve(&self, reserve_name: &str) -> BorrowerAccounts {
        BorrowerAccounts {
            depositor_accounts: self.reserve_accounts[reserve_name].clone(),
            borrower_accounts: self.reserve_accounts[reserve_name].clone(),
            obligation: self.obligation,
            owner: self.owner.clone(),
            user_metadata: self.user_metadata,
        }
    }

    pub async fn get_collateral_user_balance(
        &self,
        ctx: &mut TestContext,
        reserve_name: &str,
    ) -> u64 {
        let user_ctoken_account = &self.reserve_accounts.get(reserve_name).unwrap().collateral;
        ctx.get_balance(user_ctoken_account).await
    }

    pub async fn balances_for_reserve(
        &self,
        ctx: &mut TestContext,
        reserve_name: &str,
    ) -> BorrowerGenericBalances {
        let accounts = self.get_borrower_accounts_same_reserve(reserve_name);
        let coll_token_balance = ctx
            .get_balance(&accounts.depositor_accounts.liquidity)
            .await;

        let obligation_opt = state::try_get::<Obligation>(ctx, accounts.obligation).await;
        let mut ctoken_deposited = 0;
        let mut debt = Fraction::ZERO;
        if let Ok(obligation) = obligation_opt {
            debt = obligation
                .borrows
                .iter()
                .find(|borrow| borrow.borrow_reserve == accounts.borrower_accounts.reserve)
                .map(|borrow| borrow.borrowed_amount())
                .unwrap_or_default();
            ctoken_deposited = obligation
                .deposits
                .iter()
                .find(|d| d.deposit_reserve == accounts.depositor_accounts.reserve)
                .map(|d| d.deposited_amount)
                .unwrap_or_default();
        }
        BorrowerGenericBalances {
            coll_token_balance,
            ctoken_deposited,
            debt,
        }
    }
}

pub trait ObligationBorrower {
    fn get_obligation(&self) -> Pubkey;
    fn get_owner(&self) -> Arc<Keypair>;
    fn get_user_metadata(&self) -> Pubkey;
}

impl ObligationBorrower for BorrowerAccounts {
    fn get_obligation(&self) -> Pubkey {
        self.obligation
    }

    fn get_owner(&self) -> Arc<Keypair> {
        self.owner.clone()
    }

    fn get_user_metadata(&self) -> Pubkey {
        self.user_metadata
    }
}

impl ObligationBorrower for BorrowerGenericReservesAccounts {
    fn get_obligation(&self) -> Pubkey {
        self.obligation
    }

    fn get_owner(&self) -> Arc<Keypair> {
        self.owner.clone()
    }

    fn get_user_metadata(&self) -> Pubkey {
        self.user_metadata
    }
}

// ---- ORACLE TYPES ----

#[derive(Debug, Clone)]
pub struct GenericOracleAccounts {
    pub scope_prices_info: Pubkey,
    // Note this works only if no price chains
    pub scope_price_ids: HashMap<String, u16>,
    pub scope_twap_ids: HashMap<String, u16>,
    pub pyth_price_info: HashMap<String, Pubkey>,
    pub switchboard_feed: HashMap<String, Pubkey>,
    pub switchboard_twap_feed: HashMap<String, Pubkey>,
}

#[derive(Clone, Debug)]
pub struct OracleAccounts {
    pub sol_pyth_price_info: Pubkey,
    pub usdc_pyth_price_info: Pubkey,
    pub sol_switchboard_feed: Pubkey,
    pub usdc_switchboard_feed: Pubkey,
    pub sol_switchboard_twap_feed: Pubkey,
    pub usdc_switchboard_twap_feed: Pubkey,
    pub scope_prices: Pubkey,
    pub sol_scope_price_chain: [u16; 4],
    pub sol_scope_twap_chain: [u16; 4],
    pub usdc_scope_price_chain: [u16; 4],
    pub usdc_scope_twap_chain: [u16; 4],
}

#[derive(
    Eq,
    PartialEq,
    Debug,
    Clone,
    Copy,
    strum::EnumIter,
    num_enum::IntoPrimitive,
    num_enum::TryFromPrimitive,
)]
#[repr(u16)]
//#[cfg_attr(feature = "fuzz", derive(arbitrary::Arbitrary, Hash))]
#[allow(non_camel_case_types)]
#[allow(clippy::upper_case_acronyms)]
pub enum ScopePriceIdTest {
    SOL = 0,
    ETH = 1,
    BTC = 2,
    SRM = 3,
    RAY = 4,
    FTT = 5,
    MSOL = 6,
    scnSOL_SOL = 7,
    BNB = 8,
    AVAX = 9,
    DaoSOL_SOL = 10,
    SaberMSOL_SOL = 11,
    USDH = 12,
    StSOL = 13,
    CSOL_SOL = 14,
    CETH_ETH = 15,
    CBTC_BTC = 16,
    CMSOL_SOL = 17,
    wstETH = 18,
    LDO = 19,
    USDC = 20,
    CUSDC_USDC = 21,
    USDT = 22,
    ORCA = 23,
    MNDE = 24,
    HBB = 25,
    CORCA_ORCA = 26,
    CSLND_SLND = 27,
    CSRM_SRM = 28,
    CRAY_RAY = 29,
    CFTT_FTT = 30,
    CSTSOL_STSOL = 31,
    SLND = 32,
    DAI = 33,
    JSOL_SOL = 34,
    USH = 35,
    UXD = 36,
    USDH_TWAP = 37,
    USH_TWAP = 38,
    UXD_TWAP = 39,
    HDG = 40,
    DUST = 41,
    USDR = 46,
    USDR_TWAP = 47,
    RATIO = 48,
    UXP = 49,
    KUXDUSDCORCA = 50,
    JITOSOL_SOL = 51,
    SOL_EMA = 52,
    ETH_EMA = 53,
    BTC_EMA = 54,
    SRM_EMA = 55,
    RAY_EMA = 56,
    FTT_EMA = 57,
    MSOL_EMA = 58,
    BNB_EMA = 59,
    AVAX_EMA = 60,
    STSOL_EMA = 61,
    USDC_EMA = 62,
    USDT_EMA = 63,
    SLND_EMA = 64,
    DAI_EMA = 65,
    wstETH_TWAP = 66,
    DUST_TWAP = 67,
    BONK = 68,
    BONK_TWAP = 69,
    SAMO = 70,
    SAMO_TWAP = 71,
    BSOL = 72,
    LaineSOL = 73,
}

#[derive(
    Debug, PartialEq, Eq, num_enum::IntoPrimitive, num_enum::TryFromPrimitive, Clone, Copy,
)]
#[repr(u8)]
pub enum ObligationType {
    Vanilla = 0,
    Multiply = 1,
    Lending = 2,
    Leverage = 3,
}

#[derive(Debug)]
pub struct InitObligationArgs {
    pub tag: u8,
    pub id: u8,
    pub seed1: Pubkey,
    pub seed2: Pubkey,
}

pub fn get_obligation_args_vanilla() -> InitObligationArgs {
    get_obligation_args(
        ObligationType::Vanilla,
        Pubkey::default(),
        Pubkey::default(),
    )
}

pub fn get_obligation_args(
    obligation_type: ObligationType,
    coll_reserve_mint: Pubkey,
    borrow_reserve_mint: Pubkey,
) -> InitObligationArgs {
    let (seed1, seed2) = match obligation_type {
        ObligationType::Vanilla => (Pubkey::default(), Pubkey::default()),
        ObligationType::Multiply => (coll_reserve_mint, borrow_reserve_mint),
        ObligationType::Lending => (coll_reserve_mint, coll_reserve_mint),
        ObligationType::Leverage => (coll_reserve_mint, borrow_reserve_mint),
    };
    InitObligationArgs {
        tag: obligation_type as u8,
        id: 0,
        seed1,
        seed2,
    }
}

pub fn get_obligation_args_lending(mint: Pubkey) -> InitObligationArgs {
    get_obligation_args(ObligationType::Lending, mint, mint)
}

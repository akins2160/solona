use std::sync::Arc;

use anchor_lang::prelude::{borsh::BorshSerialize, Pubkey};
use farms::state::FarmConfigOption;
use solana_program_test::BanksClientError;
use solana_sdk::{signature::Keypair, signer::Signer};

use crate::{
    program_test::{
        common::{
            token_operations::create_ata_if_not_exists,
            types::{LendingMarketAccounts, ReserveAccounts, TestContext},
        },
        farms::operations::get_farms_user_state_account,
    },
    send_transaction, ReserveFarmKind,
};

#[allow(clippy::too_many_arguments)]
pub async fn init_global_config(
    ctx: &mut TestContext,
    market_accounts: &LendingMarketAccounts,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::farms::instructions::init_global_config(
        ctx,
        market_accounts,
        market_accounts.owner.clone(),
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn add_rewards_to_farm(
    ctx: &mut TestContext,
    market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    kind: ReserveFarmKind,
    amount: u64,
) -> Result<(), BanksClientError> {
    let tx = crate::program_test::farms::instructions::add_rewards(
        ctx,
        market_accounts,
        reserve_accounts.admin_farm_accounts[kind as usize]
            .as_ref()
            .unwrap(),
        amount,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn farms_update_farm_config(
    ctx: &mut TestContext,
    market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    mode: ReserveFarmKind,
    key: FarmConfigOption,
    value: impl BorshSerialize,
) -> Result<(), BanksClientError> {
    let farm_accounts = reserve_accounts.admin_farm_accounts[mode as usize]
        .as_ref()
        .unwrap();

    let tx = crate::program_test::farms::instructions::update_farm_config(
        ctx,
        market_accounts,
        farm_accounts,
        key,
        value,
    )
    .await;

    send_transaction!(ctx, tx)
}

pub async fn farms_initialize_reward(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    mode: ReserveFarmKind,
) -> Result<(), BanksClientError> {
    let farm_accounts = reserve.admin_farm_accounts[mode as usize].as_ref().unwrap();
    let tx =
        crate::program_test::farms::instructions::initialize_reward(ctx, market, farm_accounts)
            .await;

    send_transaction!(ctx, tx)
}

#[allow(clippy::too_many_arguments)]
pub async fn harvest_reward(
    ctx: &mut TestContext,
    market_accounts: &LendingMarketAccounts,
    reserve_accounts: &ReserveAccounts,
    obligation: &Pubkey,
    user: &Arc<Keypair>,
    kind: ReserveFarmKind,
) -> Result<(), BanksClientError> {
    let farms_account = reserve_accounts.admin_farm_accounts[kind as usize]
        .as_ref()
        .unwrap();
    let reward_mint = farms_account.reward_mint.clone();
    let reserve_farm_state = farms_account.farm_state;
    let user_ata = create_ata_if_not_exists(ctx, user, &reward_mint.pubkey()).await;
    let obligation_farm_state = get_farms_user_state_account(&reserve_farm_state, obligation);

    let tx = crate::program_test::farms::instructions::harvest_reward(
        ctx,
        market_accounts,
        farms_account,
        user,
        &user_ata,
        &obligation_farm_state,
    )
    .await;

    send_transaction!(ctx, tx)
}

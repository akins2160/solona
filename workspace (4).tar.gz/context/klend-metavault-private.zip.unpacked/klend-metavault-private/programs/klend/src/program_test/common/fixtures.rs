#![allow(dead_code)]
use std::{collections::HashMap, sync::Arc};

use anchor_lang::prelude::Pubkey;
use anchor_spl::{token::spl_token, token_2022::spl_token_2022};
use solana_program_test::BanksClientError;
use solana_sdk::{
    instruction::AccountMeta, native_token::sol_to_lamports, signature::Keypair, signer::Signer,
};

use crate::{
    program_test::common::{
        consts::QUOTE_CURRENCY,
        math::{sol_decimal_to_u64, usdc_decimal_to_u64},
        runner::{
            state,
            test::{self, ProgramDep},
        },
        setup::{self, create_program_data_account, funded_kp, kp, KP},
        token_operations::{self, create_ata_if_not_exists, TokenExtension},
        types::{
            GenericOracleAccounts, KaminoMarket, KaminoMarketGeneric, KaminoMarkets,
            LendingMarketAccounts, MSpec, MarketSpec, MarketsSpec, MintAccounts, MintSpec,
            OracleAccounts, RSpec, ReserveAccounts, ReserveSpec, TestContext,
        },
    },
    state::{ElevationGroup, ReserveConfig, ReserveFees},
    utils::{
        borrow_rate_curve::BorrowRateCurve,
        fraction::{to_sf, BigFraction, Fraction, FractionExtra},
        maybe_null_pk, secs,
    },
    TokenInfo, UpdateLendingMarketConfigValue, UpdateLendingMarketMode, UpdateReserveConfigValue,
};

pub enum ProgramDependency {}

pub struct SetupMarketArgs {
    pub reserve_config: Option<ReserveConfig>,
    pub sol_reserve_initial_liq: f64,
    pub usdc_reserve_initial_liq: f64,
    pub sol_price: f64,
    pub compute_max_units: Option<u64>,
    pub referral_fee: Option<u16>,
}

impl Default for SetupMarketArgs {
    fn default() -> Self {
        Self {
            reserve_config: None,
            sol_reserve_initial_liq: 100.0,
            usdc_reserve_initial_liq: 100.0,
            sol_price: 5.2,
            compute_max_units: None,
            referral_fee: None,
        }
    }
}

pub async fn setup_markets_and_reserves_with_deps(
    program_deps: Vec<ProgramDep>,
    num_markets: usize,
    reserve_cfg: Option<ReserveConfig>,
) -> (TestContext, KP, Vec<KaminoMarket>) {
    let (mut ctx, primary_market) =
        setup_market_and_reserves_with_deps(program_deps, reserve_cfg).await;

    let owner = primary_market.primary_market.owner.clone();
    let mut markets = vec![primary_market];
    for _ in 1..num_markets {
        markets.push(clone_market(&mut ctx, &markets[0]).await);
    }

    (ctx, owner, markets)
}

pub async fn setup_market_and_reserves_with_deps(
    program_deps: Vec<ProgramDep>,
    reserve_cfg: Option<ReserveConfig>,
) -> (TestContext, KaminoMarket) {
    let setup_market_args = SetupMarketArgs::default();
    setup_market_and_reserves_with_dependencies(
        reserve_cfg,
        sol_decimal_to_u64(setup_market_args.sol_reserve_initial_liq),
        usdc_decimal_to_u64(setup_market_args.usdc_reserve_initial_liq),
        setup_market_args.sol_price,
        setup_market_args.compute_max_units,
        program_deps,
        setup_market_args.referral_fee,
    )
    .await
}

pub async fn setup_market_and_reserves() -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_compute_budget(SetupMarketArgs::default()).await
}

pub async fn setup_market_and_reserves_compute_budget(
    setup_market_args: SetupMarketArgs,
) -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_with_dependencies(
        setup_market_args.reserve_config,
        sol_decimal_to_u64(setup_market_args.sol_reserve_initial_liq),
        usdc_decimal_to_u64(setup_market_args.usdc_reserve_initial_liq),
        setup_market_args.sol_price,
        setup_market_args.compute_max_units,
        vec![],
        setup_market_args.referral_fee,
    )
    .await
}

pub async fn setup_market_and_reserves_with_config(
    reserve_config: ReserveConfig,
) -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_with_dependencies(
        Some(reserve_config),
        sol_decimal_to_u64(100.0),
        usdc_decimal_to_u64(100.0),
        5.2,
        None,
        vec![],
        None,
    )
    .await
}

pub async fn setup_market_and_reserves_with_config_and_prices(
    reserve_config: ReserveConfig,
    sol_price: f64,
) -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_with_dependencies(
        Some(reserve_config),
        sol_decimal_to_u64(100.0),
        usdc_decimal_to_u64(100.0),
        sol_price,
        None,
        vec![],
        None,
    )
    .await
}

pub async fn setup_market_and_reserves_with_prices(sol_price: f64) -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_with_dependencies(
        None,
        sol_decimal_to_u64(100.0),
        usdc_decimal_to_u64(100.0),
        sol_price,
        None,
        vec![],
        None,
    )
    .await
}

pub async fn setup_market_and_reserves_with_config_liquidity_and_prices(
    reserve_config: ReserveConfig,
    sol_reserve_initial_liq: u64,
    usdc_reserve_initial_liq: u64,
    sol_price: f64,
) -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_with_dependencies(
        Some(reserve_config),
        sol_reserve_initial_liq,
        usdc_reserve_initial_liq,
        sol_price,
        None,
        vec![],
        None,
    )
    .await
}

pub async fn clone_market(ctx: &mut TestContext, main_market: &KaminoMarket) -> KaminoMarket {
    let setup_market_args = SetupMarketArgs::default();
    setup_market_and_reserves_with_dependencies_and_existing_context(
        ctx,
        setup_market_args.reserve_config,
        sol_decimal_to_u64(setup_market_args.sol_reserve_initial_liq),
        usdc_decimal_to_u64(setup_market_args.usdc_reserve_initial_liq),
        main_market.oracles.clone(),
        &main_market.sol_reserve.liquidity_mint,
        &main_market.usdc_reserve.liquidity_mint,
    )
    .await
}

pub async fn setup_market_and_generic_reserves(
    reserves_list: &[(String, u8)],
    initial_liqs: HashMap<String, u64>,
    prices: &HashMap<String, f64>,
    compute_units: u64,
) -> (TestContext, KaminoMarketGeneric) {
    let reserve_specs = reserves_list
        .iter()
        .map(|(name, decimals)| {
            ReserveSpec::new(
                name.as_str(),
                *decimals,
                *initial_liqs.get(name).unwrap(),
                *prices.get(name).unwrap(),
            )
        })
        .collect();
    setup_market_and_generic_reserves_with_cu(
        None,
        &MarketSpec {
            reserves: reserve_specs,
        },
        Some(compute_units),
        None,
    )
    .await
}

pub async fn setup_markets(
    config: Option<ReserveConfig>,
    spec: &MarketsSpec,
    compute_max_units: Option<u64>,
    deps: Option<Vec<ProgramDep>>,
) -> (TestContext, KaminoMarkets) {
    let mut program = if let Some(deps) = deps {
        test::program_with_deps(deps)
    } else {
        test::program()
    };

    if let Some(compute_max_units) = compute_max_units {
        program.set_compute_max_units(compute_max_units);
    }

    let mut all_markets: Vec<(KaminoMarketGeneric, HashMap<String, ReserveConfig>)> = vec![];
    let lending_markets_owner = funded_kp(&mut program, sol_to_lamports(1000.0));

    create_program_data_account(&mut program, crate::ID, lending_markets_owner.pubkey());

    let reserve_config = config.unwrap_or_else(test_reserve_config);

    let mint_kps: HashMap<String, KP> = spec
        .mints
        .keys()
        .map(|name| {
            let mint = kp();
            (name.clone(), mint)
        })
        .collect();

    for market in &spec.markets {
        let market_mints: Vec<String> = market
            .reserves
            .iter()
            .map(|reserve| reserve.mint_name.clone())
            .collect();
        let oracles = GenericOracleAccounts::new(&market_mints);
        setup::add_scope_account(&mut program, &oracles.scope_prices_info, 0.0).await;

        let market_accs = LendingMarketAccounts::new(lending_markets_owner.clone());

        let mut reserves = HashMap::new();
        let mut reserve_configs = HashMap::new();

        market.reserves.iter().for_each(|reserve| {
            let mut conf = reserve.config.unwrap_or(reserve_config);
            set_generic_oracles_to_reserve_config(&mut conf, &oracles, &reserve.mint_name);

            let mint_spec = spec.mints.get(&reserve.mint_name).unwrap_or_else(|| {
                panic!(
                    "No mint spec found for reserve's {} mint {}. Available mints: {:?}",
                    reserve.name,
                    reserve.mint_name,
                    spec.mints.keys()
                )
            });
            let reserve_accs = ReserveAccounts::new(
                &market_accs,
                mint_kps.get(&reserve.mint_name).unwrap().clone(),
                oracles.pyth_price_info[reserve.mint_name.as_str()],
                oracles.switchboard_feed[reserve.mint_name.as_str()],
                oracles.switchboard_twap_feed[reserve.mint_name.as_str()],
                oracles.scope_prices_info,
                mint_spec.token_program,
            );
            reserves.insert(reserve.name.clone(), reserve_accs);
            reserve_configs.insert(reserve.name.clone(), conf);
        });

        let prices: HashMap<String, f64> = spec
            .mints
            .iter()
            .map(|(name, spec)| (name.clone(), spec.price))
            .collect();
        setup::add_generic_pyth_accounts(&mut program, &oracles, &prices).await;
        setup::add_generic_switchboard_accounts(&mut program, &oracles, &prices).await;

        all_markets.push((
            KaminoMarketGeneric {
                primary_market: market_accs,
                reserves,
                oracles,
            },
            reserve_configs,
        ));
    }

    let mut ctx = test::start(program, &lending_markets_owner).await;

    ctx.init_global_config(&lending_markets_owner)
        .await
        .unwrap();

    let mut mints = HashMap::new();
    for (mint_name, mint_spec) in &spec.mints {
        let mint_kp = &mint_kps.get(mint_name).unwrap();
        token_operations::create_mint(
            &mut ctx,
            mint_kp,
            mint_spec.decimals,
            &lending_markets_owner.pubkey(),
            &mint_spec.token_program,
            Some(mint_spec.extensions.clone()),
        )
        .await;
        mints.insert(
            mint_name.clone(),
            MintAccounts::new(mint_kp.pubkey(), mint_spec.token_program),
        );
    }

    for (i, (m, reserve_configs)) in all_markets.iter().enumerate() {
        initialize_market(&mut ctx, &m.primary_market)
            .await
            .unwrap();

        crate::program_test::farms::client::init_global_config(&mut ctx, &m.primary_market)
            .await
            .unwrap();

        for rspec in spec.markets[i].reserves.iter() {
            let reserve_accs = m.reserves.get(&rspec.name).unwrap();
            initialize_reserve(
                &mut ctx,
                reserve_accs,
                &m.primary_market,
                reserve_configs.get(&rspec.name).unwrap(),
                rspec.initial_liquidity,
            )
            .await
            .unwrap();
        }
    }

    let markets = all_markets.iter().map(|(m, _)| m.clone()).collect();
    (ctx, KaminoMarkets { markets, mints })
}

pub async fn setup_market_and_generic_reserves_with_cu(
    config: Option<ReserveConfig>,
    spec: &MarketSpec,
    compute_max_units: Option<u64>,
    deps: Option<Vec<ProgramDep>>,
) -> (TestContext, KaminoMarketGeneric) {
    let (ctx, markets) = setup_markets(
        config,
        &MarketsSpec {
            markets: vec![MSpec {
                reserves: spec
                    .reserves
                    .iter()
                    .map(|r| RSpec {
                        name: r.name.clone(),
                        mint_name: r.name.clone(),
                        initial_liquidity: r.initial_liquidity,
                        config: None,
                    })
                    .collect(),
            }],
            mints: spec
                .reserves
                .iter()
                .map(|r| {
                    (
                        r.name.clone(),
                        MintSpec::new(
                            r.decimals,
                            r.liquidity_token_program,
                            r.liquidity_token_extensions.clone(),
                            r.price,
                        ),
                    )
                })
                .collect(),
        },
        compute_max_units,
        deps,
    )
    .await;

    (ctx, markets.markets.into_iter().next().unwrap())
}

pub async fn setup_market_and_reserves_with_args(
    args: SetupMarketArgs,
) -> (TestContext, KaminoMarket) {
    setup_market_and_reserves_with_dependencies(
        args.reserve_config,
        sol_decimal_to_u64(args.sol_reserve_initial_liq),
        usdc_decimal_to_u64(args.usdc_reserve_initial_liq),
        args.sol_price,
        args.compute_max_units,
        vec![],
        args.referral_fee,
    )
    .await
}

pub async fn setup_market_and_generic_reserves_with_dependencies(
    config: Option<ReserveConfig>,
    spec: &MarketSpec,
    deps: Option<Vec<ProgramDep>>,
) -> (TestContext, KaminoMarketGeneric) {
    setup_market_and_generic_reserves_with_cu(config, spec, None, deps).await
}

pub async fn setup_market_and_generic_reserves_with_dependencies_and_cu(
    config: Option<ReserveConfig>,
    spec: &MarketSpec,
    deps: Option<Vec<ProgramDep>>,
    compute_units: Option<u64>,
) -> (TestContext, KaminoMarketGeneric) {
    setup_market_and_generic_reserves_with_cu(config, spec, compute_units, deps).await
}

pub async fn setup_market_and_reserves_with_dependencies(
    config: Option<ReserveConfig>,
    sol_reserve_initial_liq: u64,
    usdc_reserve_initial_liq: u64,
    sol_price: f64,
    compute_max_units: Option<u64>,
    program_deps: Vec<ProgramDep>,
    referral_fee: Option<u16>,
) -> (TestContext, KaminoMarket) {
    let (mut ctx, markets) = setup_markets(
        config,
        &MarketsSpec {
            markets: vec![MSpec {
                reserves: vec![
                    RSpec {
                        name: "SOL".to_string(),
                        mint_name: "SOL".to_string(),
                        initial_liquidity: sol_reserve_initial_liq,
                        config: None,
                    },
                    RSpec {
                        name: "USDC".to_string(),
                        mint_name: "USDC".to_string(),
                        initial_liquidity: usdc_reserve_initial_liq,
                        config: None,
                    },
                ],
            }],
            mints: HashMap::from_iter(
                [
                    ("SOL".to_string(), MintSpec::spl(9, sol_price)),
                    ("USDC".to_string(), MintSpec::spl(6, 1.0)),
                ]
                .into_iter(),
            ),
        },
        compute_max_units,
        Some(program_deps),
    )
    .await;

    let market = markets.markets[0].clone();

    if let Some(referral_fee) = referral_fee {
        ctx.update_lending_market(
            &market.primary_market,
            UpdateLendingMarketMode::UpdateReferralFeeBps,
            UpdateLendingMarketConfigValue::U16(referral_fee),
            &market.primary_market.owner,
        )
        .await
        .unwrap();
    }
    let sol_reserve_accs = market.reserves.get("SOL").unwrap().clone();
    let usdc_reserve_accs = market.reserves.get("USDC").unwrap().clone();

    let mut oracles = OracleAccounts::new();
    oracles.sol_pyth_price_info = sol_reserve_accs.pyth_price;
    oracles.usdc_pyth_price_info = usdc_reserve_accs.pyth_price;
    oracles.sol_switchboard_feed = sol_reserve_accs.switchboard_feed;
    oracles.usdc_switchboard_feed = usdc_reserve_accs.switchboard_feed;
    oracles.sol_switchboard_twap_feed = sol_reserve_accs.switchboard_twap_feed;
    oracles.usdc_switchboard_twap_feed = usdc_reserve_accs.switchboard_twap_feed;
    oracles.scope_prices = sol_reserve_accs.scope_prices;

    (
        ctx,
        KaminoMarket {
            primary_market: market.primary_market,
            sol_reserve: sol_reserve_accs,
            usdc_reserve: usdc_reserve_accs,
            oracles,
        },
    )
}

pub async fn setup_market_and_reserves_with_dependencies_and_existing_context(
    ctx: &mut TestContext,
    config: Option<ReserveConfig>,
    sol_reserve_initial_liq: u64,
    usdc_reserve_initial_liq: u64,
    oracles: OracleAccounts,
    sol_reserve_mint: &Arc<Keypair>,
    usdc_reserve_mint: &Arc<Keypair>,
) -> KaminoMarket {
    let market_accs = LendingMarketAccounts::new_with_existing_context(ctx).await;

    let sol_reserve_accs = ReserveAccounts::new(
        &market_accs,
        sol_reserve_mint.clone(),
        oracles.sol_pyth_price_info,
        oracles.sol_switchboard_feed,
        oracles.sol_switchboard_twap_feed,
        oracles.scope_prices,
        spl_token::id(),
    );

    let usdc_reserve_accs = ReserveAccounts::new(
        &market_accs,
        usdc_reserve_mint.clone(),
        oracles.usdc_pyth_price_info,
        oracles.usdc_switchboard_feed,
        oracles.usdc_switchboard_twap_feed,
        oracles.scope_prices,
        spl_token::id(),
    );
    let mut reserve_config = if let Some(config) = config {
        config
    } else {
        test_reserve_config()
    };

    ctx.init_lending_market(&market_accs, QUOTE_CURRENCY)
        .await
        .unwrap();

    crate::program_test::farms::client::init_global_config(ctx, &market_accs)
        .await
        .unwrap();

    set_sol_oracles_to_reserve_config(&mut reserve_config, &oracles);

    initialize_reserve(
        ctx,
        &sol_reserve_accs,
        &market_accs,
        &reserve_config,
        sol_reserve_initial_liq,
    )
    .await
    .unwrap();

    set_usdc_oracles_to_reserve_config(&mut reserve_config, &oracles);

    initialize_reserve(
        ctx,
        &usdc_reserve_accs,
        &market_accs,
        &reserve_config,
        usdc_reserve_initial_liq,
    )
    .await
    .unwrap();

    KaminoMarket {
        primary_market: market_accs,
        sol_reserve: sol_reserve_accs,
        usdc_reserve: usdc_reserve_accs,
        oracles,
    }
}

pub async fn setup_market_no_reserve() -> (TestContext, LendingMarketAccounts, OracleAccounts) {
    setup_market_no_reserve_with_dependencies(None).await
}

pub fn make_market_config_with_fees(
    origination_fee: f64,
    interest_rate_bps: u32,
    flash_loan_fee: f64,
) -> SetupMarketArgs {
    SetupMarketArgs {
        reserve_config: Some(ReserveConfig {
            fees: ReserveFees {
                origination_fee_sf: to_sf(origination_fee) as u64, // 1%
                flash_loan_fee_sf: to_sf(flash_loan_fee) as u64,
                ..ReserveFees::default()
            },
            // 10% flat curve
            borrow_rate_curve: BorrowRateCurve::new_flat(interest_rate_bps),
            loan_to_value_pct: 70,
            ..test_reserve_config()
        }),
        sol_reserve_initial_liq: 100.0,
        usdc_reserve_initial_liq: 100.0,
        sol_price: 100.0,
        compute_max_units: None,
        referral_fee: None,
    }
}

pub fn make_market_config_with_fees_initial_liquidity(
    origination_fee: f64,
    interest_rate_bps: u32,
    flash_loan_fee: f64,
    sol_initial_liquidity: f64,
    usdc_initial_liquidity: f64,
) -> SetupMarketArgs {
    SetupMarketArgs {
        reserve_config: Some(ReserveConfig {
            fees: ReserveFees {
                origination_fee_sf: to_sf(origination_fee) as u64, // 1%
                flash_loan_fee_sf: to_sf(flash_loan_fee) as u64,
                ..ReserveFees::default()
            },
            // 10% flat curve
            borrow_rate_curve: BorrowRateCurve::new_flat(interest_rate_bps),
            loan_to_value_pct: 70,
            ..test_reserve_config()
        }),
        sol_reserve_initial_liq: sol_initial_liquidity,
        usdc_reserve_initial_liq: usdc_initial_liquidity,
        sol_price: 100.0,
        compute_max_units: None,
        referral_fee: None,
    }
}

pub async fn setup_market_no_reserve_compute_budget(
    compute_max_units: u64,
) -> (TestContext, LendingMarketAccounts, OracleAccounts) {
    setup_market_no_reserve_with_dependencies(Some(compute_max_units)).await
}

pub async fn setup_market_no_reserve_with_dependencies(
    compute_max_units: Option<u64>,
) -> (TestContext, LendingMarketAccounts, OracleAccounts) {
    let mut program = test::program();

    if let Some(compute_max_units) = compute_max_units {
        program.set_compute_max_units(compute_max_units);
    }

    let oracles = OracleAccounts::new();
    let initial_market_owner = funded_kp(&mut program, sol_to_lamports(1000.0));

    create_program_data_account(&mut program, crate::ID, initial_market_owner.pubkey());

    let market_accs = LendingMarketAccounts::new(initial_market_owner.clone());

    setup::add_pyth_accounts(&mut program, &oracles, 5.2).await;
    setup::add_switchboard_accounts(&mut program, &oracles, 5.0).await;
    setup::add_scope_account(&mut program, &oracles.scope_prices, 5.0).await;

    let mut ctx = test::start(program, &market_accs.owner).await;

    ctx.init_global_config(&initial_market_owner).await.unwrap();

    initialize_market(&mut ctx, &market_accs).await.unwrap();

    (ctx, market_accs, oracles)
}

pub fn fixed_rspec(
    mint_name: impl Into<String>,
    borrow_rate_bps: u32,
    debt_term_seconds: u64,
    initial_liquidity: u64,
) -> RSpec {
    let mint_name = mint_name.into();
    RSpec {
        name: format!(
            "{}-{}bps-{}s",
            mint_name, borrow_rate_bps, debt_term_seconds
        ),
        mint_name,
        initial_liquidity,
        config: Some(ReserveConfig {
            borrow_rate_curve: BorrowRateCurve::new_flat(borrow_rate_bps),
            debt_term_seconds,
            ..test_reserve_config()
        }),
    }
}

pub async fn initialize_market(
    ctx: &mut TestContext,
    market_accs: &LendingMarketAccounts,
) -> Result<(), BanksClientError> {
    ctx.init_lending_market(market_accs, QUOTE_CURRENCY)
        .await
        .unwrap();

    ctx.update_lending_market(
        market_accs,
        UpdateLendingMarketMode::UpdateAutodeleverageEnabled,
        UpdateLendingMarketConfigValue::U8(1),
        &market_accs.owner,
    )
    .await
    .unwrap();
    // In tests, we use a default initial deposit amount of 1 to make
    // the expected test results easier to compute. Since this is below the minimum allowed onchain
    // Update the account manually.
    let mut market = ctx.get_lending_market(market_accs.market.pubkey()).await;
    market.min_initial_deposit_amount = 1;
    state::update_zero_copy(ctx, market_accs.market.pubkey(), &market)
        .await
        .unwrap();
    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub async fn initialize_reserve(
    ctx: &mut TestContext,
    reserve_accs: &ReserveAccounts,
    market_accs: &LendingMarketAccounts,
    reserve_config: &ReserveConfig,
    initial_reserve_liq: u64,
) -> Result<(), BanksClientError> {
    let liquidity_token_owner = create_ata_if_not_exists(
        ctx,
        &market_accs.owner,
        &reserve_accs.liquidity_mint.pubkey(),
    )
    .await;

    let market = ctx.get_lending_market(market_accs.market.pubkey()).await;

    let required_seed = initial_reserve_liq + market.min_initial_deposit_amount;
    if required_seed > 0 {
        let current_balance = ctx.get_balance(&liquidity_token_owner).await;
        if current_balance < required_seed {
            token_operations::mint_with_authority(
                ctx,
                &reserve_accs.liquidity_mint.pubkey(),
                &liquidity_token_owner,
                &ctx.initial_market_owner.to_owned(),
                required_seed - current_balance,
            )
            .await
            .unwrap();
        }
    }

    let collateral_token_owner = market_accs.owner.clone(); // kp();

    ctx.initialize_full_reserve(
        market_accs,
        reserve_accs,
        liquidity_token_owner,
        &collateral_token_owner,
        reserve_config,
        initial_reserve_liq,
    )
    .await
    .unwrap();

    Ok(())
}

pub async fn unfreeze_reserve_and_initial_depositor(
    ctx: &mut TestContext,
    market_accs: &LendingMarketAccounts,
    reserve_accs: &ReserveAccounts,
    initial_deposit_amount: u64,
) {
    let liquidity_token_ata = token_operations::create_ata_if_not_exists(
        ctx,
        &market_accs.owner.clone(),
        &reserve_accs.liquidity_mint.pubkey(),
    )
    .await;

    token_operations::thaw_account(
        ctx,
        &reserve_accs.liquidity_mint.pubkey(),
        &market_accs.owner.pubkey(),
        &reserve_accs.liquidity_supply,
        market_accs.owner.clone(),
    )
    .await
    .unwrap();

    token_operations::thaw_account(
        ctx,
        &reserve_accs.liquidity_mint.pubkey(),
        &market_accs.owner.pubkey(),
        &liquidity_token_ata,
        market_accs.owner.clone(),
    )
    .await
    .unwrap();

    token_operations::mint_to(
        ctx,
        &reserve_accs.liquidity_mint.pubkey(),
        &liquidity_token_ata,
        initial_deposit_amount,
    )
    .await
    .unwrap();
}

pub async fn setup_reserves_with_elevation_groups(
    ctx: &mut TestContext,
    market: &KaminoMarketGeneric,
    reserves_list: &[&str],
    elevation_groups: &[ElevationGroup],
) {
    for elevation_group in elevation_groups {
        ctx.update_lending_market(
            &market.primary_market,
            UpdateLendingMarketMode::UpdateElevationGroup,
            UpdateLendingMarketConfigValue::ElevationGroup(*elevation_group),
            &market.primary_market.owner,
        )
        .await
        .unwrap();
    }

    let mut elevation_group_update_list = [0; 20];

    elevation_groups
        .iter()
        .enumerate()
        .for_each(|(index, elevation_group)| {
            elevation_group_update_list[index] = elevation_group.id;
        });

    for reserve in reserves_list {
        ctx.update_reserve_config(
            &market.primary_market,
            &market.get_reserve(reserve),
            crate::state::UpdateConfigMode::UpdateElevationGroup,
            UpdateReserveConfigValue::ElevationGroups(elevation_group_update_list),
        )
        .await
        .unwrap();
    }
}

pub async fn update_reserve_borrow_rate(
    ctx: &mut TestContext,
    reserve_accs: &ReserveAccounts,
    new_rate: u8,
) {
    let mut reserve = ctx.get_reserve(reserve_accs).await;
    let borrow_rate_multiplier = Fraction::from_percent(new_rate + 100);
    reserve.liquidity.cumulative_borrow_rate_bsf = BigFraction::from(borrow_rate_multiplier).into();

    setup::update_reserve(ctx, &reserve, &reserve_accs.address.pubkey()).await;
}

pub fn test_reserve_config() -> ReserveConfig {
    let optimal_utilization_rate = 75;
    let min_borrow_rate = 1;
    let optimal_borrow_rate = 5;
    let max_borrow_rate = 50;
    let borrow_rate_curve = BorrowRateCurve::from_legacy_parameters(
        optimal_utilization_rate,
        min_borrow_rate,
        optimal_borrow_rate,
        max_borrow_rate,
    );
    ReserveConfig {
        loan_to_value_pct: 70,
        liquidation_threshold_pct: 80,
        borrow_rate_curve,
        fees: ReserveFees {
            origination_fee_sf: to_sf(0.0000001) as u64, // 0.00001%
            flash_loan_fee_sf: to_sf(0.003) as u64,
            ..ReserveFees::default()
        },
        deposit_limit: 1_000_000 * 10_u64.pow(9),
        borrow_limit: 600_000 * 10_u64.pow(6),
        protocol_liquidation_fee_pct: 30,
        protocol_order_execution_fee_pct: 0,
        protocol_take_rate_pct: 10,
        token_info: TokenInfo {
            max_age_price_seconds: u64::MAX / 2000,
            max_age_twap_seconds: u64::MAX / 2000,
            ..Default::default()
        },
        max_liquidation_bonus_bps: 500,
        bad_debt_liquidation_bonus_bps: 10,
        min_liquidation_bonus_bps: 200,
        borrow_factor_pct: 100,
        autodeleverage_enabled: 1,
        min_deleveraging_bonus_bps: 50,
        deleveraging_threshold_decrease_bps_per_day: 24,
        deleveraging_bonus_increase_bps_per_day: 100,
        deleveraging_margin_call_period_secs: secs::from_days(3),
        borrow_limit_outside_elevation_group: u64::MAX, // Default to no elevation group limit
        borrow_limit_against_this_collateral_in_elevation_group: [u64::MAX; 32],
        ..Default::default()
    }
}

pub fn set_oracles_to_reserve_config(
    config: &mut ReserveConfig,
    pyth_price: &Pubkey,
    switchboard_price_feed: &Pubkey,
    switchboard_twap_feed: &Pubkey,
    scope_prices: &Pubkey,
    scope_price_chain: [u16; 4],
    twap_price_chain: [u16; 4],
) {
    config.token_info.pyth_configuration.price = *pyth_price;
    config.token_info.switchboard_configuration.price_aggregator = *switchboard_price_feed;
    config.token_info.switchboard_configuration.twap_aggregator = *switchboard_twap_feed;
    config.token_info.scope_configuration.price_feed = *scope_prices;
    config.token_info.scope_configuration.price_chain = scope_price_chain;
    config.token_info.scope_configuration.twap_chain = twap_price_chain;
}

pub fn set_sol_oracles_to_reserve_config(config: &mut ReserveConfig, oracles: &OracleAccounts) {
    set_oracles_to_reserve_config(
        config,
        &oracles.sol_pyth_price_info,
        &oracles.sol_switchboard_feed,
        &oracles.sol_switchboard_twap_feed,
        &oracles.scope_prices,
        oracles.sol_scope_price_chain,
        oracles.sol_scope_twap_chain,
    );
}

pub async fn create_reserve_accounts_with_token_extensions(
    ctx: &mut TestContext,
    market_accs: &LendingMarketAccounts,
    config: &mut ReserveConfig,
    oracles: &OracleAccounts,
    token_extensions: Option<Vec<TokenExtension>>,
    decimals: u8,
    initial_deposit_amount: Option<u64>,
) -> (ReserveAccounts, Pubkey) {
    set_sol_oracles_to_reserve_config(config, oracles);

    let reserve_accs = ReserveAccounts::new(
        market_accs,
        kp().clone(),
        oracles.sol_pyth_price_info,
        oracles.sol_switchboard_feed,
        oracles.sol_switchboard_twap_feed,
        oracles.scope_prices,
        spl_token_2022::id(),
    );

    // Update lending market with initial deposit amount if provided
    if let Some(amount) = initial_deposit_amount {
        ctx.update_lending_market(
            market_accs,
            UpdateLendingMarketMode::UpdateInitialDepositAmount,
            UpdateLendingMarketConfigValue::U64(amount),
            &market_accs.owner,
        )
        .await
        .unwrap();
    }

    // Create mint with token extensions
    token_operations::create_mint(
        ctx,
        &reserve_accs.liquidity_mint,
        decimals,
        &market_accs.owner.pubkey(),
        &reserve_accs.liquidity_mint_token_program,
        token_extensions.clone(),
    )
    .await;

    // Create ATA for market owner
    let liquidity_token_ata = token_operations::create_ata(
        ctx,
        &market_accs.owner.clone(),
        &reserve_accs.liquidity_mint.pubkey(),
    )
    .await;

    let is_frozen = token_extensions.as_ref().map_or(false, |extensions| {
        extensions.contains(&TokenExtension::DefaultAccountState(
            spl_token_2022::state::AccountState::Frozen,
        ))
    });

    if let Some(amount) = initial_deposit_amount {
        if !is_frozen {
            token_operations::mint_to(
                ctx,
                &reserve_accs.liquidity_mint.pubkey(),
                &liquidity_token_ata,
                amount,
            )
            .await
            .unwrap();
        }
    }

    (reserve_accs, liquidity_token_ata)
}

pub fn set_usdc_oracles_to_reserve_config(config: &mut ReserveConfig, oracles: &OracleAccounts) {
    set_oracles_to_reserve_config(
        config,
        &oracles.usdc_pyth_price_info,
        &oracles.usdc_switchboard_feed,
        &oracles.usdc_switchboard_twap_feed,
        &oracles.scope_prices,
        oracles.usdc_scope_price_chain,
        oracles.usdc_scope_twap_chain,
    );
}

pub fn set_generic_oracles_to_reserve_config(
    config: &mut ReserveConfig,
    oracles: &GenericOracleAccounts,
    token: &str,
) {
    set_oracles_to_reserve_config(
        config,
        oracles.pyth_price_info.get(token).unwrap(),
        oracles.switchboard_feed.get(token).unwrap(),
        oracles.switchboard_twap_feed.get(token).unwrap(),
        &oracles.scope_prices_info,
        [
            *oracles.scope_price_ids.get(token).unwrap(),
            u16::MAX,
            u16::MAX,
            u16::MAX,
        ],
        [
            *oracles.scope_twap_ids.get(token).unwrap(),
            u16::MAX,
            u16::MAX,
            u16::MAX,
        ],
    );
}

pub struct Sol;
impl Sol {
    pub fn one() -> u64 {
        Self::from(1.0)
    }
    pub fn from(amt: f64) -> u64 {
        sol_to_lamports(amt)
    }
}

pub fn maybe_account_meta(account_pk: Pubkey) -> AccountMeta {
    maybe_null_pk(account_pk)
        .map(|pubkey| AccountMeta {
            pubkey,
            is_signer: false,
            is_writable: true,
        })
        .unwrap_or(AccountMeta {
            pubkey: crate::ID,
            is_signer: false,
            is_writable: false,
        })
}

#![allow(dead_code)]
use std::{collections::HashMap, ops::Deref, sync::Arc};

use anchor_lang::{
    __private::bytemuck, prelude::Pubkey, AccountDeserialize, Discriminator, Owner, ZeroCopy,
};
use anchor_spl::token_2022::spl_token_2022::state::AccountState;
use borsh::BorshSerialize;
use bytemuck::{Pod, Zeroable};
use derive_builder::Builder;
use pyth_solana_receiver_sdk::price_update::{PriceFeedMessage, PriceUpdateV2, VerificationLevel};
use rust_decimal::{prelude::FromPrimitive, Decimal};
use sbod_itf::accounts::*;
use scope::OraclePrices as ScopePrices;
use solana_program_test::{ProgramTest, ProgramTestContext};
use solana_sdk::{
    account::{Account, AccountSharedData},
    commitment_config::CommitmentLevel,
    signature::Keypair,
    signer::Signer,
    system_instruction, system_program,
};
use strum::IntoEnumIterator;

use crate::{
    program_test::common::{
        consts::{PYTH_PROGRAM_ID, SCOPE_PROGRAM_ID, SWITCHBOARD_PROGRAM_ID},
        fixtures::Sol,
        math::{sol_decimal_to_u64, token_decimal_to_u64},
        token_operations::{self, TokenExtension},
        types::{
            get_obligation_args, get_obligation_args_vanilla, BorrowerAccounts,
            BorrowerGenericReservesAccounts, DepositorAccounts, GenericOracleAccounts,
            KaminoMarket, KaminoMarketGeneric, LendingMarketAccounts, ObligationType,
            OracleAccounts, ReserveAccounts, ScopePriceIdTest, TestContext,
        },
    },
    state::Reserve,
    utils::seeds::{self, pda},
};

// ---------- PROGRAM UPGRADE UTILS ----------
pub fn create_program_data_account(
    test: &mut ProgramTest,
    program_id: Pubkey,
    upgrade_authority: Pubkey,
) {
    let program_data_address = pda::program_data_program_id(&program_id);
    let program_data =
        solana_program::bpf_loader_upgradeable::UpgradeableLoaderState::ProgramData {
            slot: 0,
            upgrade_authority_address: Some(upgrade_authority),
        };
    let account_data = bincode::serialize(&program_data).unwrap();
    let account = Account {
        lamports: u32::MAX.into(),
        data: account_data,
        owner: solana_program::bpf_loader_upgradeable::ID,
        executable: true,
        ..Account::default()
    };
    test.add_account(program_data_address, account);
}

// ---------- KEYPAIR UTILS ----------

pub type KP = Arc<Keypair>;
pub fn kp() -> KP {
    Arc::new(Keypair::new())
}

pub fn fund_kp(test: &mut ProgramTest, min_balance_lamports: u64, user: Arc<Keypair>) -> KP {
    test.add_account(
        user.pubkey(),
        Account {
            lamports: min_balance_lamports,
            ..Account::default()
        },
    );
    user
}

pub fn funded_kp(test: &mut ProgramTest, min_balance_lamports: u64) -> KP {
    fund_kp(test, min_balance_lamports, kp())
}

pub fn funded_new_kp(ctx: &mut TestContext, min_balance_lamports: u64) -> KP {
    fund_new_kp(ctx, min_balance_lamports, kp())
}

pub fn fund_new_kp(ctx: &mut TestContext, min_balance_lamports: u64, user: Arc<Keypair>) -> KP {
    let account = AccountSharedData::new(min_balance_lamports, 0, &system_program::ID);
    ctx.set_account(&user.pubkey(), account);
    user
}

pub fn funded_new_kps(ctx: &mut TestContext, min_balance_lamports: u64, num: usize) -> Vec<KP> {
    let mut kps: Vec<KP> = vec![];

    for _ in 0..num {
        let kp = funded_new_kp(ctx, min_balance_lamports);
        kps.push(kp);
    }

    kps
}

pub fn funded_kps<const NUM: usize>(
    test: &mut ProgramTest,
    min_balance_lamports: u64,
) -> [KP; NUM] {
    (0..NUM)
        .map(|_| funded_kp(test, min_balance_lamports))
        .collect::<Vec<KP>>()
        .try_into()
        .unwrap()
}

pub async fn new_keypair(ctx: &mut TestContext, min_lamports: u64) -> Arc<Keypair> {
    let account = Keypair::new();
    let payer = ctx.context.payer().insecure_clone();
    let transaction = ctx
        .create_transaction_with_payer_and_extra_signers(
            [system_instruction::create_account(
                &payer.pubkey(),
                &account.pubkey(),
                min_lamports,
                0,
                &system_program::id(),
            )],
            payer,
            [&account],
        )
        .await;

    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await
        .unwrap();

    Arc::new(account)
}

// ---------- USER ABSTRACTIONS ----------

pub async fn new_borrower_accounts(
    ctx: &mut TestContext,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq_deposit_amount: u64,
    initial_liq_borrow_amount: u64,
) -> BorrowerAccounts {
    new_user_for_reserves(
        ctx,
        deposit_reserve,
        borrow_reserve,
        referrer,
        initial_liq_deposit_amount,
        initial_liq_borrow_amount,
    )
    .await
}

pub async fn new_borrower_accounts_from_kp(
    ctx: &mut TestContext,
    user: Arc<Keypair>,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq_deposit_amount: u64,
    initial_liq_borrow_amount: u64,
) -> BorrowerAccounts {
    new_user_for_reserves_from_kp(
        ctx,
        user,
        deposit_reserve,
        borrow_reserve,
        referrer,
        initial_liq_deposit_amount,
        initial_liq_borrow_amount,
    )
    .await
}

pub async fn new_borrower_accounts_with_obligation(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq_deposit_amount: u64,
    initial_liq_borrow_amount: u64,
) -> BorrowerAccounts {
    let mut borrower_accounts = new_user_for_reserves(
        ctx,
        deposit_reserve,
        borrow_reserve,
        referrer,
        initial_liq_deposit_amount,
        initial_liq_borrow_amount,
    )
    .await;

    let obligation =
        get_obligation_pda_vanilla(&market.market.pubkey(), &borrower_accounts.owner.pubkey());
    borrower_accounts.obligation = obligation;

    ctx.init_obligation(market, &borrower_accounts, get_obligation_args_vanilla())
        .await
        .unwrap();

    borrower_accounts
}

pub async fn new_borrower_accounts_with_inital_deposit_from_kp(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    user: Arc<Keypair>,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    referrer: &Pubkey,
    deposit_amount: u64,
) -> BorrowerAccounts {
    let mut borrower_accounts = new_borrower_accounts_from_kp(
        ctx,
        user,
        deposit_reserve,
        borrow_reserve,
        referrer,
        deposit_amount,
        0,
    )
    .await;

    create_obligation_with_initial_deposit_from_borrower_accounts(
        ctx,
        market,
        deposit_reserve,
        &mut borrower_accounts,
        deposit_amount,
    )
    .await;

    borrower_accounts
}

pub async fn new_borrower_accounts_with_initial_deposit(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    referrer: &Pubkey,
    deposit_amount: u64,
) -> BorrowerAccounts {
    let mut borrower_accounts = new_borrower_accounts(
        ctx,
        deposit_reserve,
        borrow_reserve,
        referrer,
        deposit_amount,
        0,
    )
    .await;

    create_obligation_with_initial_deposit_from_borrower_accounts(
        ctx,
        market,
        deposit_reserve,
        &mut borrower_accounts,
        deposit_amount,
    )
    .await;

    borrower_accounts
}

pub async fn create_obligation_with_initial_deposit_from_borrower_accounts(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    deposit_reserve: &ReserveAccounts,
    borrower_accounts: &mut BorrowerAccounts,
    deposit_amount: u64,
) {
    let obligation =
        get_obligation_pda_vanilla(&market.market.pubkey(), &borrower_accounts.owner.pubkey());
    borrower_accounts.obligation = obligation;

    ctx.init_obligation(market, borrower_accounts, get_obligation_args_vanilla())
        .await
        .unwrap();

    ctx.deposit_reserve_liquidity_and_obligation_collateral(
        deposit_reserve,
        &borrower_accounts.depositor_accounts,
        &borrower_accounts.obligation,
        deposit_amount,
    )
    .await
    .unwrap();
}

pub async fn new_borrower_accounts_only_deposit_accounts(
    ctx: &mut TestContext,
    deposit_reserve: &ReserveAccounts,
    obligation_type: ObligationType,
    referrer: &Pubkey,
) -> BorrowerAccounts {
    let user_deposit_reserve =
        new_user_for_reserve(ctx, deposit_reserve, referrer, sol_decimal_to_u64(1000.0)).await;

    let obligation = get_obligation_pda_from_type(
        obligation_type,
        &deposit_reserve.lending_market,
        deposit_reserve,
        deposit_reserve,
        &user_deposit_reserve.owner.pubkey(),
    );

    let user_metadata_pk = get_user_metadata_key(user_deposit_reserve.owner.pubkey());

    BorrowerAccounts {
        owner: user_deposit_reserve.owner.clone(),
        obligation,
        borrower_accounts: DepositorAccounts {
            reserve: deposit_reserve.address.pubkey(),
            owner: user_deposit_reserve.owner.clone(),
            liquidity: Pubkey::new_unique(),
            collateral: Pubkey::new_unique(),
            referrer: *referrer,
        },
        depositor_accounts: user_deposit_reserve,
        user_metadata: user_metadata_pk,
    }
}

pub async fn new_user_for_reserve(
    ctx: &mut TestContext,
    reserve: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq: u64,
) -> DepositorAccounts {
    let user = new_keypair(ctx, Sol::one()).await;

    ctx.init_if_needed_user_metadata_for_user(&user, referrer)
        .await;

    if *referrer != Pubkey::default() {
        ctx.init_if_needed_referrer_token_state_for_reserve_mint(
            &user,
            &reserve.lending_market,
            &reserve.address.pubkey(),
            referrer,
        )
        .await;
    }

    let liquidity_token_owner =
        token_operations::create_ata(ctx, &user, &reserve.liquidity_mint.pubkey()).await;

    let collateral_token_owner =
        token_operations::create_ata(ctx, &user, &reserve.collateral_mint).await;

    if initial_liq > 0 {
        token_operations::mint_to(
            ctx,
            &reserve.liquidity_mint.pubkey(),
            &liquidity_token_owner,
            initial_liq,
        )
        .await
        .unwrap();
    }

    DepositorAccounts {
        owner: user,
        reserve: reserve.address.pubkey(),
        liquidity: liquidity_token_owner,
        collateral: collateral_token_owner,
        referrer: *referrer,
    }
}

pub async fn new_user_accounts_for_reserve(
    ctx: &mut TestContext,
    user: Arc<Keypair>,
    reserve: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq: u64,
    token_extension: Option<TokenExtension>,
) -> DepositorAccounts {
    let liquidity_token_ata =
        token_operations::create_ata_if_not_exists(ctx, &user, &reserve.liquidity_mint.pubkey())
            .await;

    let collateral_token_ata =
        token_operations::create_ata_if_not_exists(ctx, &user, &reserve.collateral_mint).await;

    if Some(TokenExtension::DefaultAccountState(AccountState::Frozen)) == token_extension {
        token_operations::thaw_account(
            ctx,
            &reserve.liquidity_mint.pubkey(),
            &ctx.initial_market_owner.pubkey(),
            &liquidity_token_ata,
            ctx.initial_market_owner.clone(),
        )
        .await
        .unwrap();
    }

    if initial_liq > 0 {
        token_operations::mint_to(
            ctx,
            &reserve.liquidity_mint.pubkey(),
            &liquidity_token_ata,
            initial_liq,
        )
        .await
        .unwrap();
    }

    DepositorAccounts {
        owner: user,
        liquidity: liquidity_token_ata,
        collateral: collateral_token_ata,
        referrer: *referrer,
        reserve: reserve.address.pubkey(),
    }
}

pub async fn new_user_for_reserves(
    ctx: &mut TestContext,
    reserve_a: &ReserveAccounts,
    reserve_b: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq_a: u64,
    initial_liq_b: u64,
) -> BorrowerAccounts {
    let user = new_keypair(ctx, Sol::one()).await;

    new_user_for_reserves_from_kp(
        ctx,
        user,
        reserve_a,
        reserve_b,
        referrer,
        initial_liq_a,
        initial_liq_b,
    )
    .await
}

pub async fn new_user_for_reserves_from_kp(
    ctx: &mut TestContext,
    user: Arc<Keypair>,
    reserve_a: &ReserveAccounts,
    reserve_b: &ReserveAccounts,
    referrer: &Pubkey,
    initial_liq_a: u64,
    initial_liq_b: u64,
) -> BorrowerAccounts {
    ctx.init_if_needed_user_metadata_for_user(&user, referrer)
        .await;

    if *referrer != Pubkey::default() {
        ctx.init_if_needed_referrer_token_state_for_reserve_mint(
            &user,
            &reserve_a.lending_market,
            &reserve_a.address.pubkey(),
            referrer,
        )
        .await;
        ctx.init_if_needed_referrer_token_state_for_reserve_mint(
            &user,
            &reserve_b.lending_market,
            &reserve_b.address.pubkey(),
            referrer,
        )
        .await;
    }

    let user_accs_reserve_a =
        new_user_accounts_for_reserve(ctx, user.clone(), reserve_a, referrer, initial_liq_a, None)
            .await;
    let user_accs_reserve_b =
        new_user_accounts_for_reserve(ctx, user.clone(), reserve_b, referrer, initial_liq_b, None)
            .await;

    let user_metadata_pk = get_user_metadata_key(user.pubkey());

    BorrowerAccounts {
        owner: user.clone(),
        obligation: Pubkey::default(),
        depositor_accounts: user_accs_reserve_a,
        borrower_accounts: user_accs_reserve_b,
        user_metadata: user_metadata_pk,
    }
}

pub async fn new_borrower_borrow_from_same_reserve(
    ctx: &mut TestContext,
    reserve: &ReserveAccounts,
    market: &LendingMarketAccounts,
    referrer: &Pubkey,
    deposit_amount: u64,
    borrow_amount: u64,
) -> BorrowerAccounts {
    let new_user = new_depositor_collateral(ctx, market, reserve, referrer, deposit_amount).await;

    ctx.borrow_obligation_liquidity(
        market,
        reserve,
        &new_user.depositor_accounts,
        &new_user.obligation,
        borrow_amount,
    )
    .await
    .unwrap();

    new_user
}

pub async fn new_borrower_borrow_from_diff_reserve(
    ctx: &mut TestContext,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    market: &LendingMarketAccounts,
    referrer: &Pubkey,
    deposit_amount: u64,
    borrow_amount: u64,
) -> BorrowerAccounts {
    let borrower = new_borrower_accounts_with_initial_deposit(
        ctx,
        market,
        deposit_reserve,
        borrow_reserve,
        referrer,
        deposit_amount,
    )
    .await;

    ctx.borrow_obligation_liquidity(
        market,
        borrow_reserve,
        &borrower.borrower_accounts,
        &borrower.obligation,
        borrow_amount,
    )
    .await
    .unwrap();

    borrower
}

pub async fn new_depositor_with_balance(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: &ReserveAccounts,
    referrer: &Pubkey,
    extra_liquidity_balance: u64,
) -> BorrowerAccounts {
    let depositor = NewDepositor {
        deposit_reserve: deposit_reserve.clone(),
        borrow_reserve: Some(borrow_reserve.clone()),
        deposit_amount: 0,
        obligation_type: Some(ObligationType::Vanilla),
        referrer: *referrer,
        extra_liquidity_balance,
    };

    depositor.create(ctx, market).await
}

pub async fn new_depositor_collateral(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    reserve: &ReserveAccounts,
    referrer: &Pubkey,
    deposit_amount: u64,
) -> BorrowerAccounts {
    let depositor = NewDepositor {
        deposit_reserve: reserve.clone(),
        borrow_reserve: None,
        deposit_amount,
        obligation_type: None,
        referrer: *referrer,
        extra_liquidity_balance: 0,
    };

    depositor.create(ctx, market).await
}

pub async fn new_depositor_collateral_with_borrow_reserve(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    deposit_reserve: &ReserveAccounts,
    borrow_reserve: Option<ReserveAccounts>,
    referrer: &Pubkey,
    deposit_amount: u64,
) -> BorrowerAccounts {
    let depositor = NewDepositor {
        deposit_reserve: deposit_reserve.clone(),
        borrow_reserve,
        deposit_amount,
        obligation_type: None,
        referrer: *referrer,
        extra_liquidity_balance: 0,
    };

    depositor.create(ctx, market).await
}

#[derive(Builder)]
pub struct NewDepositor {
    deposit_reserve: ReserveAccounts,
    #[builder(setter(into))]
    borrow_reserve: Option<ReserveAccounts>,
    #[builder(setter(into))]
    deposit_amount: u64,
    #[builder(setter(into))]
    obligation_type: Option<ObligationType>,
    #[builder(setter(skip))]
    referrer: Pubkey,
    #[builder(setter(into))]
    extra_liquidity_balance: u64,
}

impl NewDepositor {
    pub async fn create(
        self,
        ctx: &mut TestContext,
        market: &LendingMarketAccounts,
    ) -> BorrowerAccounts {
        let NewDepositor {
            deposit_amount,
            obligation_type,
            deposit_reserve,
            borrow_reserve,
            referrer,
            extra_liquidity_balance,
        } = self;

        let borrow_reserve = borrow_reserve.unwrap_or_else(|| deposit_reserve.clone());
        let mut user = new_user_for_reserves(
            ctx,
            &deposit_reserve,
            &borrow_reserve,
            &referrer,
            deposit_amount + extra_liquidity_balance,
            0,
        )
        .await;

        user.obligation = get_obligation_pda_from_type(
            obligation_type.unwrap_or(ObligationType::Vanilla),
            &deposit_reserve.lending_market,
            &deposit_reserve,
            &borrow_reserve,
            &user.owner.pubkey(),
        );

        ctx.init_obligation(
            market,
            &user,
            get_obligation_args(
                obligation_type.unwrap_or(ObligationType::Vanilla),
                deposit_reserve.liquidity_mint.pubkey(),
                borrow_reserve.liquidity_mint.pubkey(),
            ),
        )
        .await
        .unwrap();

        if deposit_amount > 0 {
            ctx.deposit_reserve_liquidity_and_obligation_collateral(
                &deposit_reserve,
                &user.depositor_accounts,
                &user.obligation,
                deposit_amount,
            )
            .await
            .unwrap();
        }

        user
    }
}

pub async fn new_depositor_liquidity(
    ctx: &mut TestContext,
    reserve: &ReserveAccounts,
    market: &LendingMarketAccounts,
    referrer: &Pubkey,
    liq_amount: u64,
) -> DepositorAccounts {
    let user = new_user_for_reserve(ctx, reserve, referrer, liq_amount * 10).await;

    ctx.deposit_reserve_liquidity(market, reserve, &user, liq_amount)
        .await
        .unwrap();

    user
}

pub async fn new_sol_depositor(
    ctx: &mut TestContext,
    mkt: &KaminoMarket,
    amount: u64,
    referrer: &Pubkey,
) -> BorrowerAccounts {
    new_depositor_with_balance(
        ctx,
        &mkt.primary_market,
        &mkt.sol_reserve,
        &mkt.usdc_reserve,
        referrer,
        amount,
    )
    .await
}

pub async fn new_usdc_depositor(
    ctx: &mut TestContext,
    mkt: &KaminoMarket,
    amount: u64,
    referrer: &Pubkey,
) -> BorrowerAccounts {
    new_depositor_with_balance(
        ctx,
        &mkt.primary_market,
        &mkt.usdc_reserve,
        &mkt.sol_reserve,
        referrer,
        amount,
    )
    .await
}

pub async fn new_user_generic_reserves(
    ctx: &mut TestContext,
    market: &KaminoMarketGeneric,
    initial_balances: &HashMap<String, f64>,
    referrer: &Pubkey,
) -> BorrowerGenericReservesAccounts {
    let owner = new_keypair(ctx, Sol::one()).await;

    ctx.init_if_needed_user_metadata_for_user(&owner, referrer)
        .await;

    let mut user_reserve_accounts = HashMap::new();

    for (reserve_name, reserve_accounts) in market.reserves.iter() {
        let initial_balance = initial_balances.get(reserve_name).unwrap_or(&0.0);
        let reserve = ctx.get_reserve(reserve_accounts).await;

        if *referrer != Pubkey::default() {
            ctx.init_if_needed_referrer_token_state_for_reserve_mint(
                &owner,
                &reserve_accounts.lending_market,
                &reserve_accounts.address.pubkey(),
                referrer,
            )
            .await;
        }

        let user = new_user_accounts_for_reserve(
            ctx,
            owner.clone(),
            reserve_accounts,
            referrer,
            token_decimal_to_u64(*initial_balance, reserve.liquidity.mint_decimals as u32),
            None,
        )
        .await;

        user_reserve_accounts.insert(reserve_name.clone(), user);
    }

    let obligation =
        get_obligation_pda_vanilla(&market.primary_market.market.pubkey(), &owner.pubkey());
    let current_slot = ctx.get_current_slot().await;

    let user_metadata = get_user_metadata_key(owner.pubkey());

    let borrower_accounts = BorrowerGenericReservesAccounts {
        reserve_accounts: user_reserve_accounts.clone(),
        obligation,
        owner,
        reserves_entered_deposited: vec![],
        reserves_entered_borrowed: vec![],
        last_slot_updated: current_slot,
        user_metadata,
    };

    ctx.init_obligation(
        &market.primary_market,
        &borrower_accounts,
        get_obligation_args_vanilla(),
    )
    .await
    .unwrap();

    borrower_accounts
}

pub async fn new_borrower_generic_reserves(
    ctx: &mut TestContext,
    market: &KaminoMarketGeneric,
    initial_balances: &HashMap<String, f64>,
    deposits: &HashMap<String, f64>,
    borrows: &HashMap<String, f64>,
    referrer: &Pubkey,
) -> BorrowerGenericReservesAccounts {
    let borrower_accounts =
        new_depositor_generic_reserves(ctx, market, initial_balances, deposits, referrer).await;

    for (reserve_name, borrow) in borrows.iter() {
        if borrow > &0.0 {
            let reserve_accs = market.reserves.get(reserve_name).unwrap();
            let reserve = ctx.get_reserve(reserve_accs).await;
            let depositor_accs = borrower_accounts
                .reserve_accounts
                .get(reserve_name)
                .unwrap();

            ctx.borrow_obligation_liquidity(
                &market.primary_market,
                reserve_accs,
                depositor_accs,
                &borrower_accounts.obligation,
                token_decimal_to_u64(*borrow, reserve.liquidity.mint_decimals as u32),
            )
            .await
            .unwrap();
        }
    }

    borrower_accounts
}
pub async fn new_depositor_generic_reserves(
    ctx: &mut TestContext,
    market: &KaminoMarketGeneric,
    initial_balances: &HashMap<String, f64>,
    deposits: &HashMap<String, f64>,
    referrer: &Pubkey,
) -> BorrowerGenericReservesAccounts {
    let borrower_accounts =
        new_user_generic_reserves(ctx, market, initial_balances, referrer).await;

    for (reserve_name, deposit) in deposits.iter() {
        if deposit > &0.0 {
            let reserve_accs = market.reserves.get(reserve_name).unwrap();
            let reserve = ctx.get_reserve(reserve_accs).await;
            let depositor_accs = borrower_accounts
                .reserve_accounts
                .get(reserve_name)
                .unwrap();
            ctx.deposit_reserve_liquidity_and_obligation_collateral(
                reserve_accs,
                depositor_accs,
                &borrower_accounts.obligation,
                token_decimal_to_u64(*deposit, reserve.liquidity.mint_decimals as u32),
            )
            .await
            .unwrap();
        }
    }

    borrower_accounts
}

// ---------- PROGRAM STRUCTS UTILS ----------

impl LendingMarketAccounts {
    pub fn new(owner: Arc<Keypair>) -> Self {
        let lending_market = kp();
        let (authority, _market_authority_bump) = Pubkey::find_program_address(
            &[seeds::LENDING_MARKET_AUTH, lending_market.pubkey().as_ref()],
            &crate::ID,
        );

        let farms_global_config = kp();
        let (farms_treasury_vault_authority, _) = Pubkey::find_program_address(
            &[
                farms::utils::consts::BASE_SEED_FARM_VAULTS_AUTHORITY,
                farms_global_config.pubkey().as_ref(),
            ],
            &farms::ID,
        );

        LendingMarketAccounts {
            market: lending_market,
            owner,
            authority,
            farms_global_config,
            farms_treasury_vault_authority,
        }
    }

    pub async fn new_with_existing_context(ctx: &mut TestContext) -> Self {
        let owner = new_keypair(ctx, Sol::from(10000.0)).await;
        Self::new(owner)
    }
}

impl ReserveAccounts {
    pub fn new(
        market_accounts: &LendingMarketAccounts,
        liquidity_mint: Arc<Keypair>,
        pyth_price: Pubkey,
        switchboard_feed: Pubkey,
        switchboard_twap_feed: Pubkey,
        scope_prices: Pubkey,
        liquidity_mint_token_program: Pubkey,
    ) -> Self {
        use seeds::pda::*;

        let address = kp();
        let InitReservePdas {
            liquidity_supply_vault,
            collateral_ctoken_mint,
            collateral_supply_vault,
            fee_vault,
        } = init_reserve_pdas(&address.pubkey());

        ReserveAccounts {
            address,
            lending_market: market_accounts.market.pubkey(),
            lending_market_authority: market_accounts.authority,
            liquidity_mint,
            liquidity_mint_token_program,
            liquidity_supply: liquidity_supply_vault,
            collateral_mint: collateral_ctoken_mint,
            collateral_supply: collateral_supply_vault,
            fee_receiver: fee_vault,
            pyth_price,
            switchboard_feed,
            switchboard_twap_feed,
            scope_prices,
            admin_farm_accounts: [None, None],
        }
    }
}

pub async fn null_out_account(ctx: &mut TestContext, account_pk: &Pubkey) {
    let mut account = AccountSharedData::new(0, 0, &system_program::id());
    let data = Vec::new();

    account.set_data(data);

    ctx.set_account(account_pk, account);
}

pub async fn update_program_account<T>(
    ctx: &mut TestContext,
    program_account: &T,
    account_pk: &Pubkey,
) where
    T: ZeroCopy + Owner,
{
    let mut account =
        AccountSharedData::new(u32::MAX as u64, std::mem::size_of::<T>() + 8, &T::owner());

    account.set_data(serialize_zero_copy(program_account));

    ctx.set_account(account_pk, account);
}

pub async fn update_reserve(ctx: &mut TestContext, reserve: &Reserve, reserve_pk: &Pubkey) {
    let mut account = AccountSharedData::new(
        u32::MAX as u64,
        std::mem::size_of::<Reserve>() + 8,
        &crate::id(),
    );

    account.set_data(serialize_zero_copy(reserve));

    ctx.set_account(reserve_pk, account);
}

pub fn get_obligation_pda_vanilla(lending_market: &Pubkey, obligation_owner: &Pubkey) -> Pubkey {
    get_obligation_pda_with_seeds(
        lending_market,
        obligation_owner,
        ObligationType::Vanilla,
        0,
        &Pubkey::default(),
        &Pubkey::default(),
    )
}

pub fn get_user_metadata_key(owner: Pubkey) -> Pubkey {
    let (user_metadata_key, _user_metadata_bump) = Pubkey::find_program_address(
        &[seeds::BASE_SEED_USER_METADATA, owner.as_ref()],
        &crate::id(),
    );

    user_metadata_key
}

pub fn get_referrer_token_state_key(referrer: &Pubkey, reserve: &Pubkey) -> Pubkey {
    let (referrer_token_state_key, _referrer_token_state_bump) = Pubkey::find_program_address(
        &[
            seeds::BASE_SEED_REFERRER_TOKEN_STATE,
            referrer.as_ref(),
            reserve.as_ref(),
        ],
        &crate::id(),
    );

    referrer_token_state_key
}

pub fn get_referrer_state_key(referrer: &Pubkey) -> Pubkey {
    let (referrer_state_key, _referrer_state_bump) = Pubkey::find_program_address(
        &[seeds::BASE_SEED_REFERRER_STATE, referrer.as_ref()],
        &crate::id(),
    );

    referrer_state_key
}

pub fn get_short_url_key(short_url: &String) -> Pubkey {
    let (short_url_key, _short_url_bump) = Pubkey::find_program_address(
        &[seeds::BASE_SEED_SHORT_URL, short_url.as_bytes()],
        &crate::id(),
    );

    short_url_key
}

pub fn get_referrer_token_state_key_option(referrer: &Pubkey, reserve: &Pubkey) -> Option<Pubkey> {
    if *referrer == Pubkey::default() {
        return None;
    }

    Some(get_referrer_token_state_key(referrer, reserve))
}

pub fn get_obligation_pda_with_seeds(
    lending_market: &Pubkey,
    obligation_owner: &Pubkey,
    tag: ObligationType,
    id: u8,
    seed1: &Pubkey,
    seed2: &Pubkey,
) -> Pubkey {
    let (obligation, _obligation_bump) = Pubkey::find_program_address(
        &[
            &[u8::try_from(tag).unwrap()],
            &[id],
            obligation_owner.as_ref(),
            lending_market.as_ref(),
            seed1.as_ref(),
            seed2.as_ref(),
        ],
        &crate::id(),
    );

    obligation
}

pub fn get_obligation_pda_from_type(
    obligation_type: ObligationType,
    lending_market: &Pubkey,
    reserve1: &ReserveAccounts,
    reserve2: &ReserveAccounts,
    owner: &Pubkey,
) -> Pubkey {
    let args = get_obligation_args(
        obligation_type,
        reserve1.liquidity_mint.pubkey(),
        reserve2.liquidity_mint.pubkey(),
    );
    get_obligation_pda_with_seeds(
        lending_market,
        owner,
        obligation_type,
        args.id,
        &args.seed1,
        &args.seed2,
    )
}

// ---------- ORACLES ----------

impl GenericOracleAccounts {
    pub fn new(mints_list: &[String]) -> Self {
        let pyth_price_info = mints_list
            .iter()
            .map(|m| (m.clone(), Pubkey::new_unique()))
            .collect::<HashMap<String, Pubkey>>();
        let switchboard_feed = mints_list
            .iter()
            .map(|m| (m.clone(), Pubkey::new_unique()))
            .collect::<HashMap<String, Pubkey>>();
        let switchboard_twap_feed = mints_list
            .iter()
            .map(|m| (m.clone(), Pubkey::new_unique()))
            .collect::<HashMap<String, Pubkey>>();
        let mut scope_id = 0_u16;
        let mut scope_id_gen = || {
            let res = scope_id;
            scope_id += 1;
            res
        };
        let scope_price_ids = mints_list
            .iter()
            .map(|m| (m.clone(), scope_id_gen()))
            .collect::<HashMap<String, u16>>();
        let scope_twap_ids = mints_list
            .iter()
            .map(|m| (m.clone(), scope_id_gen()))
            .collect::<HashMap<String, u16>>();

        GenericOracleAccounts {
            scope_prices_info: Pubkey::new_unique(),
            pyth_price_info,
            switchboard_feed,
            switchboard_twap_feed,
            scope_price_ids,
            scope_twap_ids,
        }
    }
}

#[allow(clippy::new_without_default)]
impl OracleAccounts {
    pub fn new() -> Self {
        OracleAccounts {
            sol_pyth_price_info: Pubkey::new_unique(),
            usdc_pyth_price_info: Pubkey::new_unique(),
            sol_switchboard_feed: Pubkey::new_unique(),
            sol_switchboard_twap_feed: Pubkey::new_unique(),
            usdc_switchboard_feed: Pubkey::new_unique(),
            usdc_switchboard_twap_feed: Pubkey::new_unique(),
            scope_prices: Pubkey::new_unique(),
            sol_scope_price_chain: [0, u16::MAX, u16::MAX, u16::MAX],
            sol_scope_twap_chain: [1, u16::MAX, u16::MAX, u16::MAX],
            usdc_scope_price_chain: [2, u16::MAX, u16::MAX, u16::MAX],
            usdc_scope_twap_chain: [3, u16::MAX, u16::MAX, u16::MAX],
        }
    }
}

pub async fn add_pyth_price(test: &mut ProgramTest, price_address: Pubkey, px: f64) {
    let price_acc = new_price(px);
    let account = to_pyth_account_data(price_acc);
    test.add_account(price_address, account.into());
}

pub async fn add_generic_pyth_accounts(
    test: &mut ProgramTest,
    oracles: &GenericOracleAccounts,
    prices: &HashMap<String, f64>,
) {
    // We need to iterate over oracles (and join with prices inside) since a market may define fewer reserves than prices:
    for (coll, price_address) in oracles.pyth_price_info.iter() {
        add_pyth_price(test, *price_address, prices[coll]).await;
    }
}

pub async fn add_scope_account(test: &mut ProgramTest, scope_prices: &Pubkey, px: f64) {
    let mut scope_price_acc = ScopePrices {
        oracle_mappings: Pubkey::default(),
        prices: [scope::DatedPrice::default(); ::scope::MAX_ENTRIES],
    };

    for (_, dated_price) in ScopePriceIdTest::iter().zip(scope_price_acc.prices.iter_mut()) {
        dated_price.last_updated_slot = 0; // Default to too old price for now
        dated_price.price.value = (px * 10_f64.powi(8)) as u64;
        dated_price.price.exp = 8;
    }

    let mut account = Account::new(
        u32::MAX as u64,
        8 + std::mem::size_of::<ScopePrices>(),
        &SCOPE_PROGRAM_ID,
    );
    account.data[0..8].copy_from_slice(&ScopePrices::discriminator());
    account.data[8..].copy_from_slice(bytemuck::bytes_of(&scope_price_acc));
    test.add_account(*scope_prices, account);
}

pub async fn add_pyth_accounts(test: &mut ProgramTest, oracles: &OracleAccounts, px: f64) {
    add_pyth_price(test, oracles.sol_pyth_price_info, px).await;

    add_pyth_price(
        test,
        oracles.usdc_pyth_price_info,
        1.0, // TODO: don't hardcode it
    )
    .await;
}

pub fn create_pull_feed(result: CurrentResult) -> PullFeedAccountData {
    let mut data = PullFeedAccountData::zeroed();
    data.result = result;
    data.max_staleness = 25; // expressed in slots; i.e. 10 seconds
    data.min_responses = 10;
    data.min_sample_size = 10;
    data
}

pub fn create_result(value: f64, num_samples: u8) -> CurrentResult {
    create_result_with_slot(value, num_samples, 0)
}

pub async fn add_switchboard_account(ctx: &mut TestContext, aggregator_address: &Pubkey, px: f64) {
    let latest_result = create_result(px, 30);

    let feed = create_pull_feed(latest_result);
    let mut account = AccountSharedData::new(u32::MAX as u64, 0, &SWITCHBOARD_PROGRAM_ID);

    account.set_data(serialize_zero_copy(&feed));

    ctx.set_account(aggregator_address, account);
}

pub async fn add_switchboard_aggregator(
    test: &mut ProgramTest,
    aggregator_address: Pubkey,
    px: f64,
) {
    let lastest_round = create_result(px, 30);

    let feed = create_pull_feed(lastest_round);
    let mut account = Account::new(u32::MAX as u64, 0, &SWITCHBOARD_PROGRAM_ID);

    account.data = serialize_zero_copy(&feed);

    test.add_account(aggregator_address, account);
}

pub async fn add_switchboard_accounts(test: &mut ProgramTest, oracles: &OracleAccounts, px: f64) {
    add_switchboard_aggregator(test, oracles.sol_switchboard_feed, px).await;
    add_switchboard_aggregator(test, oracles.sol_switchboard_twap_feed, px).await;

    add_switchboard_aggregator(test, oracles.usdc_switchboard_feed, 1.0).await;
    add_switchboard_aggregator(test, oracles.usdc_switchboard_twap_feed, 1.0).await;
}

pub async fn add_generic_switchboard_accounts(
    test: &mut ProgramTest,
    oracles: &GenericOracleAccounts,
    prices: &HashMap<String, f64>,
) {
    // We need to iterate over oracles (and join with prices inside) since a market may define fewer reserves than prices:
    for switchboard_addresses in [&oracles.switchboard_feed, &oracles.switchboard_twap_feed] {
        for (coll, price_address) in switchboard_addresses {
            add_switchboard_aggregator(test, *price_address, prices[coll]).await;
        }
    }
}

pub fn create_result_with_slot(value: f64, num_samples: u8, slot: u64) -> CurrentResult {
    CurrentResult {
        value: to_sbod_scaled_decimal(value),
        num_samples,
        slot,
        ..CurrentResult::zeroed()
    }
}

pub async fn update_switchboard_slot(
    ctx: &mut TestContext,
    aggregator_address: &Pubkey,
    slot: u64,
) {
    let switchboard_acc = ctx.get_account(*aggregator_address).await.unwrap().unwrap();

    let switchboard_data = switchboard_acc.data;
    let mut feed = PullFeedAccountData::try_deserialize(&mut switchboard_data.as_slice()).unwrap();

    feed.result.slot = slot;

    let mut account = AccountSharedData::new(u32::MAX as u64, 0, &SWITCHBOARD_PROGRAM_ID);

    account.set_data(serialize_zero_copy(&feed));

    ctx.set_account(aggregator_address, account);
}

pub async fn update_switchboard_price(
    test: &mut ProgramTestContext,
    aggregator_address: &Pubkey,
    price: f64,
) {
    let switchboard_acc = test
        .banks_client
        .get_account(*aggregator_address)
        .await
        .unwrap()
        .unwrap();

    let switchboard_data = switchboard_acc.data;
    let mut feed = PullFeedAccountData::try_deserialize(&mut switchboard_data.as_slice()).unwrap();

    feed.result.value = to_sbod_scaled_decimal(price);

    let mut account = AccountSharedData::new(u32::MAX as u64, 0, &SWITCHBOARD_PROGRAM_ID);

    account.set_data(serialize_zero_copy(&feed));

    test.set_account(aggregator_address, &account);
}

pub async fn update_switchboard_price_and_slot(
    ctx: &mut TestContext,
    aggregator_address: &Pubkey,
    price: f64,
    slot: u64,
) {
    let switchboard_acc = ctx.get_account(*aggregator_address).await.unwrap().unwrap();

    let switchboard_data = switchboard_acc.data;
    let mut feed = PullFeedAccountData::try_deserialize(&mut switchboard_data.as_slice()).unwrap();

    feed.result.value = to_sbod_scaled_decimal(price);
    feed.result.slot = slot;

    let mut account = AccountSharedData::new(u32::MAX as u64, 0, &SWITCHBOARD_PROGRAM_ID);
    account.set_data(serialize_zero_copy(&feed));

    ctx.set_account(aggregator_address, account);
}

pub fn new_price(px: f64) -> PriceUpdateV2 {
    new_timestamped_price(px, 0, i64::MAX)
}

// TODO: modify fixed decimals number?
pub fn new_timestamped_price(px: f64, slot: u64, timestamp: i64) -> PriceUpdateV2 {
    PriceUpdateV2 {
        write_authority: Pubkey::new_unique(),
        verification_level: VerificationLevel::Full,
        price_message: PriceFeedMessage {
            feed_id: [13u8; 32],
            price: (px * 10_f64.powi(8)) as i64,
            conf: 0,
            exponent: -8,
            publish_time: timestamp,
            prev_publish_time: timestamp,
            ema_price: (px * 10_f64.powi(8)) as i64,
            ema_conf: 0,
        },
        posted_slot: slot,
    }
}

pub async fn get_pyth_price(ctx: &mut TestContext, pyth_price: &Pubkey) -> PriceUpdateV2 {
    let pyth_acc = ctx.get_account(*pyth_price).await.unwrap().unwrap();

    PriceUpdateV2::try_deserialize(&mut pyth_acc.data.deref()).unwrap()
}

pub async fn update_pyth_price(ctx: &mut TestContext, pyth_price: &Pubkey, px: f64) {
    let price_acc = new_price(px);
    ctx.set_account(pyth_price, to_pyth_account_data(price_acc));
}

pub async fn update_pyth_date(
    ctx: &mut TestContext,
    pyth_price: &Pubkey,
    slot: u64,
    timestamp: i64,
) {
    let mut price_acc = get_pyth_price(ctx, pyth_price).await;
    price_acc.posted_slot = slot;
    price_acc.price_message.publish_time = timestamp;
    price_acc.price_message.prev_publish_time = timestamp;
    ctx.set_account(pyth_price, to_pyth_account_data(price_acc));
}

pub async fn update_pyth_date_and_price(
    ctx: &mut TestContext,
    pyth_price: &Pubkey,
    px: f64,
    slot: u64,
    timestamp: i64,
) {
    let price_acc = new_timestamped_price(px, slot, timestamp);
    ctx.set_account(pyth_price, to_pyth_account_data(price_acc));
}

pub fn to_pyth_account_data(price_acc: PriceUpdateV2) -> AccountSharedData {
    let mut account = AccountSharedData::new(u32::MAX as u64, 0, &PYTH_PROGRAM_ID);
    let mut buffer = PriceUpdateV2::discriminator().to_vec();
    price_acc.serialize(&mut buffer).unwrap();
    account.set_data(buffer);
    account
}

pub fn serialize_zero_copy<T: Discriminator + Pod>(t: &T) -> Vec<u8> {
    let mut serialization = Vec::new();
    serialization.extend(T::discriminator());
    serialization.extend_from_slice(bytemuck::bytes_of(t));
    serialization
}

const COMMON_BUMPS: &[u8] = &[255, 254, 253, 252, 251, 250, 249, 248, 247, 246, 245, 244]; // only to allow returning references from `pda_signer_seeds()`

pub fn pda_signer_seeds<'a>(
    program_address: &Pubkey,
    parts: impl IntoIterator<Item = &'a [u8]>,
) -> Vec<&'a [u8]> {
    let mut seeds = Vec::new();
    for part in parts {
        seeds.push(part.as_ref());
    }
    let (_address, bump) = Pubkey::find_program_address(&seeds, program_address);
    let common_bump_index = (u8::MAX - bump) as usize; // Note: in an unlikely case of panic, add more `COMMON_BUMPS`
    seeds.push(&COMMON_BUMPS[common_bump_index..=common_bump_index]);
    seeds
}

fn to_sbod_scaled_decimal(value: f64) -> i128 {
    let mut value = Decimal::from_f64(value).unwrap();
    value.rescale(PRECISION);
    value.mantissa()
}

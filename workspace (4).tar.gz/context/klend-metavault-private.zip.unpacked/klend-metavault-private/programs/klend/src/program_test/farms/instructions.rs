use std::sync::Arc;

use anchor_lang::{
    prelude::{borsh::BorshSerialize, Pubkey, Rent},
    system_program::System,
    Id, InstructionData, ToAccountMetas,
};
use anchor_spl::token::Token;
use farms::state::FarmConfigOption;
use solana_program::system_instruction;
use solana_sdk::{
    instruction::Instruction, signature::Keypair, signer::Signer, sysvar::SysvarId,
    transaction::Transaction,
};

use crate::program_test::common::types::{FarmAccounts, LendingMarketAccounts, TestContext};

pub async fn add_rewards<'a>(
    ctx: &mut TestContext,
    market: &LendingMarketAccounts,
    farm_accounts: &FarmAccounts,
    amount: u64,
) -> Transaction {
    let accounts = farms::accounts::AddReward {
        payer: market.owner.pubkey(),
        farm_state: farm_accounts.farm_state,
        reward_vault: farm_accounts.reward_vault,
        farm_vaults_authority: farm_accounts.farm_vault_authority,
        payer_reward_token_ata: farm_accounts.admin_reward_ata,
        reward_mint: farm_accounts.reward_mint.pubkey(),
        token_program: Token::id(),
        scope_prices: None,
    }
    .to_account_metas(None);
    let data = farms::instruction::AddRewards {
        amount,
        reward_index: 0, // For testing, only one reward per farm
    }
    .data();
    let instruction = Instruction {
        program_id: farms::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], &market.owner)
        .await
}

pub async fn update_farm_config<'a>(
    ctx: &mut TestContext,
    market_accounts: &LendingMarketAccounts,
    farm_accounts: &FarmAccounts,
    key: FarmConfigOption,
    data: impl BorshSerialize,
) -> Transaction {
    let accounts = farms::accounts::UpdateFarmConfig {
        signer: market_accounts.owner.pubkey(),
        farm_state: farm_accounts.farm_state,
        scope_prices: None,
    }
    .to_account_metas(None);

    let data_buffer = data.try_to_vec().unwrap();
    let ix_data = farms::instruction::UpdateFarmConfig {
        mode: key.into(),
        data: data_buffer,
    }
    .data();

    let instruction = Instruction {
        program_id: farms::id(),
        accounts,
        data: ix_data,
    };

    ctx.create_transaction_with_payer([instruction], &market_accounts.owner)
        .await
}

pub async fn initialize_reward<'a>(
    ctx: &mut TestContext,
    market_accounts: &LendingMarketAccounts,
    farm_accounts: &FarmAccounts,
) -> Transaction {
    let accounts = farms::accounts::InitializeReward {
        farm_admin: market_accounts.owner.pubkey(),
        farm_state: farm_accounts.farm_state,
        global_config: market_accounts.farms_global_config.pubkey(),
        reward_vault: farm_accounts.reward_vault,
        farm_vaults_authority: farm_accounts.farm_vault_authority,
        treasury_vaults_authority: market_accounts.farms_treasury_vault_authority,
        reward_treasury_vault: farm_accounts.reward_treasury_vault,
        reward_mint: farm_accounts.reward_mint.pubkey(),
        token_program: Token::id(),
        system_program: System::id(),
        rent: Rent::id(),
    }
    .to_account_metas(None);
    let data = farms::instruction::InitializeReward {}.data();
    let instruction = Instruction {
        program_id: farms::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], &market_accounts.owner)
        .await
}

#[allow(clippy::too_many_arguments)]
pub async fn init_global_config<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    payer: Arc<Keypair>,
) -> Transaction {
    let ix_preallocate_farm_account = system_instruction::create_account(
        &payer.pubkey(),
        &lending_market_accounts.farms_global_config.pubkey(),
        ctx.get_rent_zero_copy::<farms::state::GlobalConfig>(),
        std::mem::size_of::<farms::state::GlobalConfig>() as u64 + 8,
        &farms::id(),
    );

    let accounts = farms::accounts::InitializeGlobalConfig {
        global_admin: lending_market_accounts.owner.pubkey(),
        global_config: lending_market_accounts.farms_global_config.pubkey(),
        treasury_vaults_authority: lending_market_accounts.farms_treasury_vault_authority,
        system_program: System::id(),
    }
    .to_account_metas(None);

    let data = farms::instruction::InitializeGlobalConfig {}.data();
    let instruction = Instruction {
        program_id: farms::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer_and_extra_signers(
        [ix_preallocate_farm_account, instruction],
        payer,
        [&lending_market_accounts.farms_global_config],
    )
    .await
}

pub async fn harvest_reward<'a>(
    ctx: &mut TestContext,
    lending_market_accounts: &LendingMarketAccounts,
    farm_accounts: &FarmAccounts,
    user: &Arc<Keypair>,
    user_ata: &Pubkey,
    obligation_farm_state: &Pubkey,
) -> Transaction {
    let accounts = farms::accounts::HarvestReward {
        owner: user.pubkey(),
        user_state: *obligation_farm_state,
        farm_state: farm_accounts.farm_state,
        global_config: lending_market_accounts.farms_global_config.pubkey(),
        reward_mint: farm_accounts.reward_mint.pubkey(),
        rewards_vault: farm_accounts.reward_vault,
        rewards_treasury_vault: farm_accounts.reward_treasury_vault,
        user_reward_ata: *user_ata,
        farm_vaults_authority: farm_accounts.farm_vault_authority,
        token_program: Token::id(),
        scope_prices: None,
    }
    .to_account_metas(None);
    let data = farms::instruction::HarvestReward { reward_index: 0 }.data();

    let instruction = Instruction {
        program_id: farms::id(),
        accounts,
        data,
    };

    ctx.create_transaction_with_payer([instruction], user).await
}

#![allow(dead_code)]

use std::sync::Arc;

use anchor_lang::{prelude::Pubkey, AccountDeserialize};
use anchor_spl::{
    token::spl_token,
    token_2022::spl_token_2022::{
        self,
        extension::{confidential_transfer, default_account_state},
        state::AccountState,
    },
    token_interface::{
        spl_token_2022::extension::{pausable, transfer_fee, transfer_hook, ExtensionType},
        Mint,
    },
};
use arrayref::array_ref;
use solana_program::instruction::Instruction;
use solana_program_test::BanksClientError;
use solana_sdk::{
    commitment_config::CommitmentLevel, program_error::ProgramError, program_pack::Pack,
    signature::Keypair, signer::Signer, system_instruction, transport::TransportError,
};
use spl_associated_token_account as ata;
use spl_associated_token_account::{get_associated_token_address_with_program_id, instruction};

use super::{
    setup::{kp, KP},
    types::TestContext,
};
use crate::send_transaction;

pub async fn create_ata(ctx: &mut TestContext, payer: &KP, mint: &Pubkey) -> Pubkey {
    create_ata_with_owner(ctx, payer, &payer.pubkey(), mint).await
}

pub async fn create_ata_if_not_exists(ctx: &mut TestContext, payer: &KP, mint: &Pubkey) -> Pubkey {
    let program_id = get_token_program(ctx, mint).await;
    let address = get_associated_token_address_with_program_id(&payer.pubkey(), mint, &program_id);

    if ctx.get_account(address).await.unwrap().is_none() {
        create_ata_with_owner(ctx, payer, &payer.pubkey(), mint).await;
    }

    address
}

pub async fn create_ata_with_owner(
    ctx: &mut TestContext,
    payer: &KP,
    owner: &Pubkey,
    mint: &Pubkey,
) -> Pubkey {
    let program_id = get_token_program(ctx, mint).await;
    let transaction = ctx
        .create_transaction_with_payer(
            [instruction::create_associated_token_account(
                &payer.pubkey(),
                owner,
                mint,
                &program_id,
            )],
            payer,
        )
        .await;
    let res = ctx
        .process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await;

    if res.is_err() {
        panic!("Failed to create ATA: {:?}", res);
    }

    get_associated_token_address_with_program_id(owner, mint, &program_id)
}

pub async fn create_token_account(
    ctx: &mut TestContext,
    payer: Arc<Keypair>,
    account: &KP,
    mint: &Pubkey,
    owner: &Pubkey,
) -> Result<(), BanksClientError> {
    let token_program = get_token_program(ctx, mint).await;
    let transaction = ctx
        .create_transaction_with_payer_and_extra_signers(
            [
                system_instruction::create_account(
                    &payer.pubkey(),
                    &account.pubkey(),
                    ctx.get_rent(spl_token::state::Account::LEN),
                    spl_token::state::Account::LEN as u64,
                    &token_program,
                ),
                spl_token::instruction::initialize_account(
                    &token_program,
                    &account.pubkey(),
                    mint,
                    owner,
                )
                .unwrap(),
            ],
            &payer,
            [account],
        )
        .await;
    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await?;
    Ok(())
}

pub async fn create_mint(
    ctx: &mut TestContext,
    mint: &KP,
    decimals: u8,
    mint_authority: &Pubkey,
    token_program: &Pubkey,
    extensions: Option<Vec<TokenExtension>>,
) {
    let all_ixs = create_mint_ixs(
        ctx,
        mint,
        decimals,
        mint_authority,
        token_program,
        extensions,
    )
    .await;
    let transaction = ctx
        .create_transaction_with_payer_and_extra_signers(
            all_ixs,
            ctx.initial_market_owner.clone(),
            [mint],
        )
        .await;
    send_transaction!(ctx, transaction).unwrap();
}

pub async fn create_mint_ixs(
    ctx: &mut TestContext,
    mint: &KP,
    decimals: u8,
    mint_authority: &Pubkey,
    token_program: &Pubkey,
    extensions: Option<Vec<TokenExtension>>,
) -> Vec<Instruction> {
    let extension_specs = extensions.unwrap_or_default();
    if token_program == &spl_token::id() && !extension_specs.is_empty() {
        panic!("Extensions are not supported for SPL Token program");
    }
    let mut extension_ixs = vec![];
    let mut extension_types: Vec<ExtensionType> = vec![];
    for extension in extension_specs {
        extension_ixs.push(extension_instruction(
            mint_authority,
            &mint.pubkey(),
            &extension,
        ));
        extension_types.push(extension.into());
    }
    let len =
        ExtensionType::try_calculate_account_len::<spl_token_2022::state::Mint>(&extension_types)
            .unwrap();
    let mint_rent = ctx.get_rent(len);
    let mut all_ixs = vec![system_instruction::create_account(
        &ctx.initial_market_owner.pubkey(),
        &mint.pubkey(),
        mint_rent,
        len as u64,
        token_program,
    )];
    extension_ixs.iter().for_each(|ix| all_ixs.push(ix.clone()));

    all_ixs.push(
        spl_token_2022::instruction::initialize_mint(
            token_program,
            &mint.pubkey(),
            mint_authority,
            Some(mint_authority),
            decimals,
        )
        .unwrap(),
    );

    all_ixs
}

pub fn extension_instruction(
    authority: &Pubkey,
    mint: &Pubkey,
    extension: &TokenExtension,
) -> Instruction {
    match extension {
        TokenExtension::MintCloseAuthority => {
            spl_token_2022::instruction::initialize_mint_close_authority(
                &spl_token_2022::id(),
                mint,
                Some(&Pubkey::new_unique()),
            )
            .unwrap()
        }
        TokenExtension::NonTransferable => {
            spl_token_2022::instruction::initialize_non_transferable_mint(
                &spl_token_2022::id(),
                mint,
            )
            .unwrap()
        }
        TokenExtension::PermanentDelegate => {
            spl_token_2022::instruction::initialize_permanent_delegate(
                &spl_token_2022::id(),
                mint,
                &Pubkey::new_unique(),
            )
            .unwrap()
        }
        TokenExtension::TransferHook(hook_program_id) => transfer_hook::instruction::initialize(
            &spl_token_2022::id(),
            mint,
            Some(*authority),
            *hook_program_id,
        )
        .unwrap(),
        TokenExtension::TransferFeeConfig(transfer_fee_bps) => {
            transfer_fee::instruction::initialize_transfer_fee_config(
                &spl_token_2022::id(),
                mint,
                Some(authority),
                None,
                *transfer_fee_bps,
                u64::MAX,
            )
            .unwrap()
        }
        TokenExtension::ConfidentialTransfer(auto_approve) => {
            confidential_transfer::instruction::initialize_mint(
                &spl_token_2022::id(),
                mint,
                Some(*authority),
                *auto_approve,
                None,
            )
            .unwrap()
        }
        TokenExtension::DefaultAccountState(account_state) => {
            default_account_state::instruction::initialize_default_account_state(
                &spl_token_2022::id(),
                mint,
                account_state,
            )
            .unwrap()
        }
        TokenExtension::Pausable => {
            pausable::instruction::initialize(&spl_token_2022::id(), mint, authority).unwrap()
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum TokenExtension {
    MintCloseAuthority,
    NonTransferable,
    PermanentDelegate,
    TransferHook(Option<Pubkey>),
    TransferFeeConfig(u16),
    /// If true, the mint will automatically approve transfers
    ConfidentialTransfer(bool),
    DefaultAccountState(AccountState),
    Pausable,
}

impl From<TokenExtension> for ExtensionType {
    fn from(extension: TokenExtension) -> Self {
        match extension {
            TokenExtension::MintCloseAuthority => ExtensionType::MintCloseAuthority,
            TokenExtension::NonTransferable => ExtensionType::NonTransferable,
            TokenExtension::PermanentDelegate => ExtensionType::PermanentDelegate,
            TokenExtension::TransferFeeConfig(_) => ExtensionType::TransferFeeConfig,
            TokenExtension::TransferHook(_) => ExtensionType::TransferHook,
            TokenExtension::ConfidentialTransfer(_) => ExtensionType::ConfidentialTransferMint,
            TokenExtension::DefaultAccountState(_) => ExtensionType::DefaultAccountState,
            TokenExtension::Pausable => ExtensionType::Pausable,
        }
    }
}

pub async fn set_transfer_fee(ctx: &mut TestContext, mint: &Pubkey, transfer_fee_bps: u16) {
    let ix = transfer_fee::instruction::set_transfer_fee(
        &spl_token_2022::id(),
        mint,
        &ctx.initial_market_owner.pubkey(),
        &[],
        transfer_fee_bps,
        u64::MAX,
    )
    .unwrap();

    let tx = ctx.create_transaction_by_market_owner([ix]).await;

    send_transaction!(ctx, tx).unwrap();
}

pub async fn set_auto_approve(ctx: &mut TestContext, mint: &Pubkey) {
    let ix = confidential_transfer::instruction::update_mint(
        &spl_token_2022::id(),
        mint,
        &ctx.initial_market_owner.pubkey(),
        &[],
        true,
        None,
    )
    .unwrap();

    let tx = ctx.create_transaction_by_market_owner([ix]).await;

    send_transaction!(ctx, tx).unwrap();
}

pub async fn set_transfer_hook(ctx: &mut TestContext, mint: &Pubkey, transfer_hook: &Pubkey) {
    let ix = transfer_hook::instruction::update(
        &spl_token_2022::id(),
        mint,
        &ctx.initial_market_owner.pubkey(),
        &[],
        Some(*transfer_hook),
    )
    .unwrap();

    let tx = ctx.create_transaction_by_market_owner([ix]).await;

    send_transaction!(ctx, tx).unwrap();
}

pub async fn mint_to(
    ctx: &mut TestContext,
    mint: &Pubkey,
    mint_into_account: &Pubkey,
    amount: u64,
) -> Result<(), TransportError> {
    let token_program = get_token_program(ctx, mint).await;
    let transaction = ctx
        .create_transaction_by_market_owner([spl_token_2022::instruction::mint_to(
            &token_program,
            mint,
            mint_into_account,
            &ctx.initial_market_owner.pubkey(),
            &[],
            amount,
        )
        .unwrap()])
        .await;
    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await?;
    Ok(())
}

pub async fn burn_from_ata(
    ctx: &mut TestContext,
    mint: &Pubkey,
    user: &Keypair,
    amount: u64,
) -> Result<(), TransportError> {
    let ata = ata::get_associated_token_address(&user.pubkey(), mint);
    let transaction = ctx
        .create_transaction_with_payer(
            [spl_token::instruction::burn(
                &spl_token::id(),
                &ata,
                mint,
                &user.pubkey(),
                &[],
                amount,
            )
            .unwrap()],
            user,
        )
        .await;
    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await?;
    Ok(())
}

pub async fn mint_with_authority(
    ctx: &mut TestContext,
    mint: &Pubkey,
    mint_into_account: &Pubkey,
    authority: &KP,
    amount: u64,
) -> Result<(), TransportError> {
    let token_program = get_token_program(ctx, mint).await;
    let transaction = ctx
        .create_transaction_by_market_owner([spl_token_2022::instruction::mint_to(
            &token_program,
            mint,
            mint_into_account,
            &authority.pubkey(),
            &[],
            amount,
        )
        .unwrap()])
        .await;
    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await?;
    Ok(())
}

pub async fn get_token_program(ctx: &mut TestContext, mint: &Pubkey) -> Pubkey {
    ctx.get_account(*mint).await.unwrap().unwrap().owner
}

pub async fn transfer(
    ctx: &mut TestContext,
    from: &Pubkey,
    to: &Pubkey,
    signer: &Keypair,
    amount: u64,
) -> Result<(), TransportError> {
    let transaction = ctx
        .create_transaction_with_payer(
            [spl_token::instruction::transfer(
                &spl_token::id(),
                from,
                to,
                &signer.pubkey(),
                &[],
                amount,
            )
            .unwrap()],
            signer,
        )
        .await;
    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await?;
    Ok(())
}

pub async fn set_mint_auth(
    ctx: &mut TestContext,
    mint: &Pubkey,
    owner: &Pubkey,
    new_auth: &Pubkey,
    payer: Arc<Keypair>,
) {
    let transaction = ctx
        .create_transaction_with_payer(
            [spl_token::instruction::set_authority(
                &spl_token::id(),
                mint,
                Some(new_auth),
                spl_token::instruction::AuthorityType::MintTokens,
                owner,
                &[owner, &payer.pubkey()],
            )
            .unwrap()],
            payer,
        )
        .await;

    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await
        .unwrap();
}

pub async fn set_owner(
    ctx: &mut TestContext,
    account: &Pubkey,
    new_owner: &Pubkey,
    current_owner: Arc<Keypair>,
) {
    let tx = ctx
        .create_transaction_with_payer(
            [spl_token::instruction::set_authority(
                &spl_token::id(),
                account,
                Some(new_owner),
                spl_token::instruction::AuthorityType::AccountOwner,
                &current_owner.pubkey(),
                &[&current_owner.pubkey()],
            )
            .unwrap()],
            current_owner,
        )
        .await;

    send_transaction!(ctx, tx).unwrap()
}

pub async fn thaw_account(
    ctx: &mut TestContext,
    mint_pubkey: &Pubkey,
    mint_authority: &Pubkey,
    token_account: &Pubkey,
    freeze_authority: Arc<Keypair>,
) -> Result<(), BanksClientError> {
    let transaction = ctx
        .create_transaction_with_payer(
            [spl_token_2022::instruction::thaw_account(
                &spl_token_2022::id(),
                token_account,
                mint_pubkey,
                mint_authority,
                &[&freeze_authority.pubkey()],
            )
            .unwrap()],
            freeze_authority,
        )
        .await;

    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await
}

pub async fn pause_mint(
    ctx: &mut TestContext,
    mint_pubkey: &Pubkey,
    pause_authority: Arc<Keypair>,
) -> Result<(), BanksClientError> {
    let authoriy_pk = pause_authority.pubkey();
    let transaction = ctx
        .create_transaction_with_payer(
            [pausable::instruction::pause(
                &spl_token_2022::id(),
                mint_pubkey,
                &authoriy_pk,
                &[&authoriy_pk],
            )
            .unwrap()],
            pause_authority,
        )
        .await;

    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await
}

pub async fn resume_mint(
    ctx: &mut TestContext,
    mint_pubkey: &Pubkey,
    pause_authority: Arc<Keypair>,
) -> Result<(), BanksClientError> {
    let authoriy_pk = pause_authority.pubkey();
    let transaction = ctx
        .create_transaction_with_payer(
            [pausable::instruction::resume(
                &spl_token_2022::id(),
                mint_pubkey,
                &authoriy_pk,
                &[&authoriy_pk],
            )
            .unwrap()],
            pause_authority,
        )
        .await;

    ctx.process_transaction_with_commitment(transaction, CommitmentLevel::Processed)
        .await
}

fn check_data_len(data: &[u8], min_len: usize) -> Result<(), ProgramError> {
    if data.len() < min_len {
        Err(ProgramError::AccountDataTooSmall)
    } else {
        Ok(())
    }
}

fn get_token_balance(data: &[u8]) -> u64 {
    if let Err(_err) = check_data_len(data, spl_token::state::Account::get_packed_len()) {
        return 0;
    }
    let amount = array_ref![data, 64, 8];

    u64::from_le_bytes(*amount)
}

pub async fn balance(ctx: &mut TestContext, account: &Pubkey) -> u64 {
    let acc = ctx.get_account(*account).await.unwrap().unwrap();
    get_token_balance(&acc.data)
}

pub async fn get_mint(ctx: &mut TestContext, mint: &Pubkey) -> Mint {
    let acc = ctx.get_account(*mint).await.unwrap().unwrap();

    let mut data = acc.data.as_slice();
    Mint::try_deserialize_unchecked(&mut data).unwrap()
}

pub async fn decimals(ctx: &mut TestContext, mint: &Pubkey) -> u8 {
    let acc = ctx.get_account(*mint).await.unwrap().unwrap();

    let data = &acc.data;
    data[44]
}

pub async fn create_and_mint_to_ata(
    ctx: &mut TestContext,
    owner: Arc<Keypair>,
    mint: &Pubkey,
    amount: u64,
) -> Pubkey {
    let liquidity_token_owner = create_ata_if_not_exists(ctx, &owner, mint).await;
    mint_to(ctx, mint, &liquidity_token_owner, amount)
        .await
        .unwrap();
    liquidity_token_owner
}

pub async fn create_and_mint_to_token_account(
    ctx: &mut TestContext,
    owner: Arc<Keypair>,
    mint: &Pubkey,
    amount: u64,
) -> Arc<Keypair> {
    let token_account = kp();
    create_token_account(ctx, owner.clone(), &token_account, mint, &owner.pubkey())
        .await
        .unwrap();
    mint_with_authority(ctx, mint, &token_account.pubkey(), &owner, amount)
        .await
        .unwrap();
    token_account
}

pub async fn set_delegate(
    ctx: &mut TestContext,
    token_account: &Pubkey,
    owner: KP,
    new_delegate: &Pubkey,
    delegate_amount: u64,
) {
    let token_account_raw = ctx.get_account(*token_account).await.unwrap().unwrap();
    let token_program_id = token_account_raw.owner;
    let ix = spl_token::instruction::approve(
        &token_program_id,
        token_account,
        new_delegate,
        &owner.pubkey(),
        &[&owner.pubkey()],
        delegate_amount,
    )
    .unwrap();

    let tx = ctx.create_transaction_with_payer([ix], owner).await;

    send_transaction!(ctx, tx).unwrap();
}

use solana_sdk::pubkey::Pubkey;

use crate::{
    program_test::common::types::{LendingMarketAccounts, ReserveAccounts, TestContext},
    ReserveFarmKind,
};

pub struct FarmConfig {
    pub kind: ReserveFarmKind,
    pub top_up_reward_amounts: u64,
    pub rps: u64,
}
pub struct InitializeFarmsArgs<'a> {
    pub market: &'a LendingMarketAccounts,
    pub reserve: &'a mut ReserveAccounts,
    pub configs: Vec<FarmConfig>,
}

pub async fn initialize_farms<'a>(ctx: &mut TestContext, args: InitializeFarmsArgs<'a>) {
    ctx.init_farms(args.market, args.reserve, u64::MAX)
        .await
        .unwrap();

    for config in args.configs {
        crate::program_test::farms::client::add_rewards_to_farm(
            ctx,
            args.market,
            args.reserve,
            config.kind,
            config.top_up_reward_amounts,
        )
        .await
        .unwrap();

        // (reward_index, value)
        let data: (u64, u64) = (0, config.rps);

        crate::program_test::farms::client::farms_update_farm_config(
            ctx,
            args.market,
            args.reserve,
            config.kind,
            farms::state::FarmConfigOption::UpdateRewardRps,
            data,
        )
        .await
        .unwrap();
    }
}

pub fn get_farms_user_state_account(farm_state_key: &Pubkey, owner_key: &Pubkey) -> Pubkey {
    let (user_state, _user_state_bump) = Pubkey::find_program_address(
        &[
            farms::utils::consts::BASE_SEED_USER_STATE,
            farm_state_key.as_ref(),
            owner_key.as_ref(),
        ],
        &farms::ID,
    );

    user_state
}

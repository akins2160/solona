/// Converts a decimal floating-point value to a scaled integer by multiplying by `factor`
/// and rounding to the nearest integer.
pub fn decimal_to_u64(number: f64, factor: u128) -> u64 {
    let scaled = number * (factor as f64);
    // We use `round` here rather than picking a direction (`ceil` or `floor`) because
    // `number` won't usually be represented exactly in floating point. When converting a
    // decimal to f64, the value rounds to whichever representable f64 is closest, which
    // could be either slightly higher or lower than the exact decimal value.
    // For example:
    //   0.1 → 0.10000000000000000555...
    //   0.3 → 0.29999999999999998889...
    // Therefore, we have no control over whether the scaled f64 value will be slightly
    // lower or higher than the exact integer amount we intended to represent. Using `round`
    // gives the most accurate conversion back to an integer.
    scaled.round() as u64
}

pub fn u64_to_decimal(number: u64, factor: u128) -> f64 {
    number as f64 / (factor as f64)
}

/// Converts a USDC decimal amount to an u64 value of lamports.
/// The result is rounded to the nearest integer.
pub fn usdc_decimal_to_u64(number: f64) -> u64 {
    decimal_to_u64(number, 10_u128.pow(6))
}

/// Converts a token decimal amount to an u64 value of lamports, given the token decimals.
/// The result is rounded to the nearest integer.
pub fn token_decimal_to_u64(number: f64, decimal: u32) -> u64 {
    decimal_to_u64(number, 10_u128.pow(decimal))
}

/// Converts a SOL decimal amount to an u64 value of lamports.
/// The result is rounded to the nearest integer.
pub fn sol_decimal_to_u64(number: f64) -> u64 {
    decimal_to_u64(number, 10_u128.pow(9))
}

pub fn token_decimal_to_f64(number: f64, decimal: u32) -> f64 {
    number * (10u128.pow(decimal) as f64)
}

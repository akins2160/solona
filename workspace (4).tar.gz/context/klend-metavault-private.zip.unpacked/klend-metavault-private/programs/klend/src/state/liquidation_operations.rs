//! Liquidation mechanism
//! This module contains the logic for calculating the effects of a liquidation of an obligation
//! The liquidator receives collateral tokens and repays debt tokens, 1 at a time
//! The liquidator pledges an amount to repay part of the debt. The amount is calculated based on the liquidity in the obligation, max liquidatable value allowed by the lending market, and the closing factor (which represents the percentage out of the total debt of the user that is allowed to be liquidated)
//! The liquidator receives collateral tokens in exchange for debt tokens. The amount of collateral tokens received is calculated based on the amount of debt tokens that are being liquidated, the ratio between the collateral value and the liquidatable value, and the liquidation bonus of the reserves it's interacting with.
//! Liquidation bonus is calculated using a linear formula, which caps the liquidation bonus based on how close the user ltv is to bad debt or to max allowed ltv for his obligation, but also based on the max and min liquidation bonuses set by the reserves interacting in the instruction. The closer the user_ltv is to 100%, the likelier the liquidation bonus is further minimized. Likewise, the closer the user_ltv is to max_allowed_ltv, the likelier the liquidation bonus is fixed to the min_liquidation_bonus of the reserve.

use std::{
    cmp::{max, min, Ordering},
    ops::RangeInclusive,
};

use anchor_lang::{err, prelude::msg, Result};

use crate::{
    fraction::FractionExtra,
    obligation_order_operations::{
        find_applicable_obligation_order, ConditionHit, OpportunityType,
    },
    utils::{fraction::fraction, secs, Fraction, DUST_LAMPORT_THRESHOLD, ELEVATION_GROUP_NONE},
    xmsg, CalculateLiquidationResult, LendingError, LendingMarket, LiquidationCheckInputs,
    LiquidationParams, LiquidationReason, Obligation, ObligationCollateral, ObligationLiquidity,
    ObligationOrder, Reserve, ReserveConfig,
};

/// Calculate the maximum liquidatable amount for a given liquidity,
/// relative to the close factor percentage of the total debt value
pub fn max_liquidatable_borrowed_amount(
    market: &LendingMarket,
    obligation: &Obligation,
    liquidity: &ObligationLiquidity,
    liquidation_reason: LiquidationReason,
) -> Fraction {
    match liquidation_reason {
        // For obligation order execution, we are driven by the order's size:
        LiquidationReason::ObligationOrder(obligation_order_index) => {
            let obligation_order = &obligation.obligation_orders[obligation_order_index];
            let order_size_amount = match obligation_order.opportunity_type() {
                OpportunityType::DeleverageSingleDebtAmount => {
                    obligation_order.opportunity_parameter()
                }
                OpportunityType::DeleverageAllDebt => Fraction::MAX,
            };
            order_size_amount.min(liquidity.borrowed_amount())
        }
        // For mature reserve debt, we want to liquidate all of it:
        LiquidationReason::ReserveDebtMaturityReached => liquidity.borrowed_amount(),
        // For expired fixed-term debts we need to take the potential throttling into account:
        LiquidationReason::ObligationBorrowDebtTermReached(secs_since_debt_term_end) => {
            let throttle_protected_amount = market
                .get_term_based_full_liquidation_duration_secs()
                .map(|full_liquidation_duration_secs| {
                    let secs_until_full_liq =
                        full_liquidation_duration_secs.saturating_sub(secs_since_debt_term_end);
                    liquidity
                        .borrowed_amount_at_expiration()
                        .full_mul_int_ratio(secs_until_full_liq, full_liquidation_duration_secs)
                })
                .unwrap_or_default();
            liquidity
                .borrowed_amount()
                .saturating_sub(throttle_protected_amount)
        }
        // For the remaining cases (where a liquidation may actually render the obligation back healthy) we want to observe the liquidation limits:
        LiquidationReason::LtvExceeded
        | LiquidationReason::IndividualDeleveraging
        | LiquidationReason::MarketWideDeleveraging => {
            // Obligation debt for the selected reserve/liquidity
            let obligation_debt_for_liquidity_mv = liquidity.market_value();

            // Entire debt for this obligation
            let total_obligation_debt_mv = obligation.get_borrowed_assets_market_value();

            let liquidation_max_debt_close_factor_rate =
                if obligation.loan_to_value() > market.get_insolvency_risk_unhealthy_ltv() {
                    Fraction::ONE
                } else {
                    market.get_liquidation_max_debt_close_factor()
                };

            let calculated_liquidatable_mv =
                total_obligation_debt_mv * liquidation_max_debt_close_factor_rate;

            let max_liquidatable_mv = calculated_liquidatable_mv
                .min(obligation_debt_for_liquidity_mv)
                .min(market.get_max_liquidatable_debt_market_value_at_once());

            // How much % are we liquidating out of this obligation liquidity debt
            let max_liquidation_ratio = max_liquidatable_mv / obligation_debt_for_liquidity_mv;

            liquidity.borrowed_amount() * max_liquidation_ratio
        }
    }
}

/// Calculate liquidation function for a given obligation
#[allow(clippy::too_many_arguments)]
pub fn calculate_liquidation(
    collateral_reserve: &Reserve,
    debt_reserve: &Reserve,
    debt_amount_to_liquidate: u64, // in lamports
    lending_market: &LendingMarket,
    obligation: &Obligation,
    liquidity: &ObligationLiquidity,
    collateral: &ObligationCollateral,
    timestamp: u64,
    is_debt_reserve_highest_borrow_factor: bool,
    is_collateral_reserve_lowest_liquidation_ltv: bool,
    max_allowed_ltv_override_pct_opt: Option<u64>,
) -> Result<CalculateLiquidationResult> {
    let LiquidationParams {
        liquidation_bonus_rate,
        liquidation_reason,
    } = get_liquidation_params(
        lending_market,
        collateral_reserve,
        liquidity,
        debt_reserve,
        obligation,
        timestamp,
        is_debt_reserve_highest_borrow_factor,
        is_collateral_reserve_lowest_liquidation_ltv,
        max_allowed_ltv_override_pct_opt,
    )?;

    let bonus_multiplier = liquidation_bonus_rate + Fraction::ONE;

    let borrowed_amount = liquidity.borrowed_amount();

    let borrowed_value = liquidity.market_value();

    let debt_amount_to_liquidate =
        Fraction::from_num(debt_amount_to_liquidate).min(borrowed_amount);

    let is_below_min_full_liquidation_value_threshold = !matches!(liquidation_reason, LiquidationReason::ObligationOrder(_)) // this min threshold is not applicable to obligation orders
        && borrowed_value < lending_market.min_full_liquidation_value_threshold;

    // Close out obligations that are too small to liquidate normally
    let debt_liquidation_amount_f = if is_below_min_full_liquidation_value_threshold {
        // In this case (where the `debt_liquidation_amount_f` is not limited by the input
        // `debt_amount_to_liquidate`), we have to manually check, so that we do not transfer out
        // more funds than the liquidator declared to repay:
        if debt_amount_to_liquidate < borrowed_amount {
            msg!(
                "Liquidator-provided debt repay amount {} is too small to satisfy the required full liquidation {}",
                debt_amount_to_liquidate.to_display(),
                borrowed_amount.to_display()
            );
            return err!(LendingError::RepayTooSmallForFullLiquidation);
        }
        borrowed_amount
    } else {
        max_liquidatable_borrowed_amount(lending_market, obligation, liquidity, liquidation_reason)
            .min(debt_amount_to_liquidate)
    };

    let liquidation_ratio = debt_liquidation_amount_f / borrowed_amount;

    let total_liquidation_value_including_bonus =
        borrowed_value * liquidation_ratio * bonus_multiplier;

    // calculate settle_amount and withdraw_amount, repay_amount is settle_amount rounded
    let (settle_amount, repay_amount, withdraw_amount) = calculate_liquidation_amounts(
        total_liquidation_value_including_bonus,
        collateral,
        debt_liquidation_amount_f,
        is_below_min_full_liquidation_value_threshold,
    );

    xmsg!(
        "Obligation is liquidated with liquidation bonus: {} bps, liquidation amount (rounded): {}",
        liquidation_bonus_rate.to_bps().unwrap_or(u32::MAX),
        settle_amount.round().to_display(),
    );

    Ok(CalculateLiquidationResult {
        settle_amount,
        repay_amount,
        withdraw_amount,
        liquidation_bonus_rate,
        liquidation_reason,
    })
}

#[allow(clippy::too_many_arguments)]
pub fn get_liquidation_params(
    lending_market: &LendingMarket,
    collateral_reserve: &Reserve,
    liquidity: &ObligationLiquidity,
    debt_reserve: &Reserve,
    obligation: &Obligation,
    timestamp: u64,
    is_debt_reserve_highest_borrow_factor: bool,
    is_collateral_reserve_lowest_liquidation_ltv: bool,
    max_allowed_ltv_override_pct_opt: Option<u64>,
) -> Result<LiquidationParams> {
    let inputs = LiquidationCheckInputs {
        lending_market,
        collateral_reserve,
        liquidity,
        debt_reserve,
        obligation,
        timestamp,
        max_allowed_ltv_override_pct_opt,
    };

    // Find the first applicable liquidation reason:
    let params = check_liquidate_obligation(&inputs)
        .or_else(|| check_individual_autodeleverage_obligation(&inputs))
        .or_else(|| check_market_wide_autodeleverage_obligation(&inputs))
        .or_else(|| check_reserve_debt_maturity_reached(&inputs))
        .or_else(|| check_borrow_reserve_debt_term_reached(&inputs))
        .or_else(|| check_obligation_order_execution(&inputs))
        .ok_or_else(|| {
            xmsg!(
                "Obligation is healthy and cannot be liquidated, LTV: {}",
                obligation.loan_to_value()
            );
            LendingError::ObligationHealthy
        })?;

    // Certain liquidation reasons have additional requirements:
    if params.liquidation_reason == LiquidationReason::LtvExceeded
        && !is_debt_reserve_highest_borrow_factor
    {
        xmsg!("Debt reserve must be the highest borrow factor reserve");
        return err!(LendingError::LiquidationBorrowFactorPriority);
    }
    if matches!(
        params.liquidation_reason,
        LiquidationReason::LtvExceeded
            | LiquidationReason::ObligationOrder(..)
            | LiquidationReason::ReserveDebtMaturityReached
            | LiquidationReason::ObligationBorrowDebtTermReached(..)
    ) && !is_collateral_reserve_lowest_liquidation_ltv
    {
        xmsg!("Collateral reserve must be the lowest liquidation LTV reserve");
        return err!(LendingError::LiquidationLowestLiquidationLtvPriority);
    }

    xmsg!(
        "Obligation is eligible for liquidation because of {:?} with liquidation bonus: {}bps",
        params.liquidation_reason,
        params.liquidation_bonus_rate.to_bps().unwrap_or(u64::MAX),
    );
    Ok(params)
}

/// Check whether an obligation can be liquidated and return the liquidation params if so
pub fn check_liquidate_obligation(
    &LiquidationCheckInputs {
        lending_market,
        collateral_reserve,
        debt_reserve,
        obligation,
        max_allowed_ltv_override_pct_opt,
        ..
    }: &LiquidationCheckInputs,
) -> Option<LiquidationParams> {
    let user_ltv = obligation.loan_to_value();
    let user_no_bf_ltv = obligation.no_bf_loan_to_value();
    let max_allowed_ltv_user = obligation.unhealthy_loan_to_value();
    let max_allowed_ltv_override_opt = max_allowed_ltv_override_pct_opt.map(Fraction::from_percent);
    let max_allowed_ltv = max_allowed_ltv_override_opt.unwrap_or(max_allowed_ltv_user);

    if user_ltv < max_allowed_ltv {
        // Simply healthy, not worth logging.
        return None;
    }

    if lending_market.is_price_triggered_liquidation_disabled() {
        xmsg!("Obligation is eligible for ltv-exceeded liquidation, but price-triggered liquidations are disabled");
        return None;
    }

    xmsg!("Obligation is eligible for liquidation, borrowed value (scaled): {}, unhealthy borrow value (scaled): {}, LTV: {}%/{}%, max_allowed_ltv_user {}%, max_allowed_ltv_override {:?}%",
        Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf).to_display(),
        Fraction::from_bits(obligation.unhealthy_borrow_value_sf).to_display(),
        user_ltv.to_percent().unwrap_or(u64::MAX),
        max_allowed_ltv.to_percent().unwrap_or(u64::MAX),
        max_allowed_ltv_user.to_percent().unwrap_or(u64::MAX),
        max_allowed_ltv_override_pct_opt,
    );

    let emode_max_liquidation_bonus_bps = get_emode_max_liquidation_bonus(
        lending_market,
        &collateral_reserve.config,
        &debt_reserve.config,
        obligation,
    );

    Some(LiquidationParams {
        liquidation_bonus_rate: calculate_liquidation_bonus(
            &collateral_reserve.config,
            &debt_reserve.config,
            max_allowed_ltv,
            user_ltv,
            user_no_bf_ltv,
            emode_max_liquidation_bonus_bps,
        ),
        liquidation_reason: LiquidationReason::LtvExceeded,
    })
}

pub(crate) fn get_emode_max_liquidation_bonus(
    lending_market: &LendingMarket,
    collateral_reserve: &ReserveConfig,
    debt_reserve: &ReserveConfig,
    obligation: &Obligation,
) -> u16 {
    if obligation.elevation_group != ELEVATION_GROUP_NONE
        && collateral_reserve
            .elevation_groups
            .contains(&obligation.elevation_group)
        && debt_reserve
            .elevation_groups
            .contains(&obligation.elevation_group)
    {
        // Elevation group id already checked to exist in request_elevation_group and update_reserve_config
        let elevation_group = lending_market
            .get_elevation_group(obligation.elevation_group)
            .unwrap()
            .unwrap();

        // Elevation group max liquidation bps is checked to be smaller than the reserve's in update_reserve_config
        // Sanity checks in case there's been any updates on max_liquidation_bonus_bps
        if elevation_group.max_liquidation_bonus_bps > collateral_reserve.max_liquidation_bonus_bps
            || elevation_group.max_liquidation_bonus_bps > debt_reserve.max_liquidation_bonus_bps
            || elevation_group.max_liquidation_bonus_bps == 0
        {
            u16::MAX
        } else {
            elevation_group.max_liquidation_bonus_bps
        }
    } else {
        u16::MAX
    }
}

/// Calculate liquidation amounts (settle_amount, repay_amount, withdraw_amount)
fn calculate_liquidation_amounts(
    total_liquidation_value_including_bonus: Fraction,
    collateral: &ObligationCollateral,
    debt_liquidation_amount: Fraction,
    is_below_min_full_liquidation_value_threshold: bool,
) -> (Fraction, u64, u64) {
    let collateral_value = Fraction::from_bits(collateral.market_value_sf);
    match total_liquidation_value_including_bonus.cmp(&collateral_value) {
        Ordering::Greater => {
            let repay_ratio = collateral_value / total_liquidation_value_including_bonus;

            let repay_amount_f = debt_liquidation_amount * repay_ratio;

            let settle_amount = if is_below_min_full_liquidation_value_threshold {
                debt_liquidation_amount
            } else {
                repay_amount_f
            };

            let repay_amount = settle_amount.to_ceil();

            let withdraw_amount = collateral.deposited_amount;
            (settle_amount, repay_amount, withdraw_amount)
        }
        Ordering::Equal => {
            let settle_amount = debt_liquidation_amount;
            let repay_amount = settle_amount.to_ceil();
            let withdraw_amount = collateral.deposited_amount;
            (settle_amount, repay_amount, withdraw_amount)
        }
        Ordering::Less => {
            let settle_amount = debt_liquidation_amount;
            let repay_amount = settle_amount.to_ceil();
            // withdraw_amount = collateral.deposited_amount * withdraw_ratio
            let withdraw_pct = total_liquidation_value_including_bonus / collateral_value;
            let withdraw_amount_f = Fraction::from_num(collateral.deposited_amount) * withdraw_pct;

            let withdraw_amount = if is_below_min_full_liquidation_value_threshold
                && withdraw_amount_f < DUST_LAMPORT_THRESHOLD
            {
                // This is a dust loan, withdraw amount would <1 lamport to be able to liquidate it properly.
                // We seize the entire collateral for this loan (1 lamport)
                // This can happen in situations where the collateral decimals do not represent a small enough amount
                // e.g. given a loan with 0.000001 USDC collateral, and 0.000000699 - the withdraw amount would be <0.000001 USDC
                DUST_LAMPORT_THRESHOLD
            } else {
                withdraw_amount_f.to_floor()
            };
            (settle_amount, repay_amount, withdraw_amount)
        }
    }
}

pub(crate) fn calculate_liquidation_bonus(
    collateral_reserve_config: &ReserveConfig,
    debt_reserve_config: &ReserveConfig,
    max_allowed_ltv: Fraction,
    user_ltv: Fraction,
    user_no_bf_ltv: Fraction,
    emode_max_liquidation_bonus_bps: u16,
) -> Fraction {
    let bad_debt_ltv = Fraction::ONE;

    if user_no_bf_ltv >= fraction!(0.99) {
        // Current situation (bad or almost bad debt)
        // 0 ----- max_allowed_ltv ----- 100 (bad_debt_ltv) ----- user_no_bf_ltv

        let liquidation_bonus_bad_debt_bps = min(
            collateral_reserve_config.bad_debt_liquidation_bonus_bps,
            debt_reserve_config.bad_debt_liquidation_bonus_bps,
        );

        let liquidation_bonus_bad_debt = Fraction::from_bps(liquidation_bonus_bad_debt_bps);

        let capped_bonus = if user_no_bf_ltv < bad_debt_ltv {
            let diff_to_bad_debt = bad_debt_ltv - user_no_bf_ltv;
            max(liquidation_bonus_bad_debt, diff_to_bad_debt) // cannot overflow because of the check above
        } else {
            liquidation_bonus_bad_debt
        };

        return capped_bonus;
    }

    // Current situation
    // 0 ----- max_allowed_ltv ----- user_ltv | user_no_bf_ltv ----- 100 (bad_debt_ltv) ----- user_ltv

    let unhealthy_factor = user_ltv - max_allowed_ltv;

    // (Capped) Maximum receivable, can't get more than max_bonus
    let max_bonus_bps = max(
        collateral_reserve_config.max_liquidation_bonus_bps,
        debt_reserve_config.max_liquidation_bonus_bps,
    );

    // Emode group max bonus
    let max_bonus_bps = min(max_bonus_bps, emode_max_liquidation_bonus_bps);
    let max_bonus = Fraction::from_bps(max_bonus_bps);

    let min_reserve_bonus_bps = max(
        collateral_reserve_config.min_liquidation_bonus_bps,
        debt_reserve_config.min_liquidation_bonus_bps,
    );

    let min_reserve_bonus = Fraction::from_bps(min_reserve_bonus_bps);

    // (Floored) Minimum receivable, can't get less than min_bonus (2% for example)
    let min_bonus = max(min_reserve_bonus, unhealthy_factor);

    let collared_bonus = min(min_bonus, max_bonus);

    // Bad debt adjusted bonus, ensure bonus doesn't turn obligation to bad debt
    let diff_to_bad_debt = bad_debt_ltv - user_no_bf_ltv;

    min(collared_bonus, diff_to_bad_debt)
}

/// Checks whether the obligation can be auto-deleveraged due to an individual target LTV being set.
fn check_individual_autodeleverage_obligation(
    &LiquidationCheckInputs {
        lending_market,
        collateral_reserve,
        debt_reserve,
        obligation,
        timestamp,
        ..
    }: &LiquidationCheckInputs,
) -> Option<LiquidationParams> {
    if !obligation.is_marked_for_deleveraging() {
        // The default: obligation not marked for individual auto-deleveraging; not worth logging.
        return None;
    }
    if !lending_market.is_autodeleverage_enabled() {
        xmsg!("Obligation is marked for auto-deleveraging, but the feature is disabled");
        return None;
    }
    if lending_market.individual_autodeleverage_margin_call_period_secs == 0 {
        xmsg!("Obligation is marked for auto-deleveraging, but the feature is misconfigured");
        return None;
    }
    let user_ltv = obligation.loan_to_value();
    let autodeleverage_target_ltv =
        Fraction::from_percent(obligation.autodeleverage_target_ltv_pct);
    if user_ltv <= autodeleverage_target_ltv {
        xmsg!("Obligation is marked for auto-deleveraging, but its LTV is already below target");
        return None;
    }
    let secs_since_margin_call_started =
        timestamp.saturating_sub(obligation.autodeleverage_margin_call_started_timestamp);
    let secs_since_deleveraging_started = get_secs_since_deleveraging_started(
        lending_market.individual_autodeleverage_margin_call_period_secs,
        secs_since_margin_call_started,
    )?;
    let days_since_deleveraging_started = secs::to_days_fractional(secs_since_deleveraging_started);
    let liquidation_bonus_rate = calculate_autodeleverage_bonus_rate_from_coll_and_debt_reserves(
        lending_market,
        collateral_reserve,
        debt_reserve,
        obligation,
        days_since_deleveraging_started,
    );
    xmsg!("Auto-deleveraging individual target LTV: {user_ltv}/{autodeleverage_target_ltv}, secs: {secs_since_deleveraging_started} ({days_since_deleveraging_started} days), liquidation bonus: {liquidation_bonus_rate}", );
    Some(LiquidationParams {
        liquidation_bonus_rate,
        liquidation_reason: LiquidationReason::IndividualDeleveraging,
    })
}

/// Checks whether the obligation's debt/collateral can be auto-deleveraged due to deposit/borrow
/// limits being crossed. Returns the liquidation params if so.
fn check_market_wide_autodeleverage_obligation(
    &LiquidationCheckInputs {
        lending_market,
        collateral_reserve,
        debt_reserve,
        obligation,
        timestamp,
        ..
    }: &LiquidationCheckInputs,
) -> Option<LiquidationParams> {
    if !lending_market.is_autodeleverage_enabled() {
        return None;
    }

    if collateral_reserve.config.is_autodeleverage_enabled() {
        let params = get_secs_since_autodeleverage_obligation_collateral_deposit_limit_crossed(
            collateral_reserve,
            timestamp,
        )
        .and_then(|secs_since_deleveraging_started| {
            get_autodeleverage_liquidation_params(
                collateral_reserve,
                obligation,
                secs_since_deleveraging_started,
            )
        });
        if params.is_some() {
            return params;
        }
    }

    if debt_reserve.config.is_autodeleverage_enabled() {
        let params = get_secs_since_autodeleverage_obligation_debt_borrow_limit_crossed(
            debt_reserve,
            timestamp,
        )
        .and_then(|secs_since_deleveraging_started| {
            get_autodeleverage_liquidation_params(
                debt_reserve,
                obligation,
                secs_since_deleveraging_started,
            )
        });
        if params.is_some() {
            return params;
        }
    }

    None
}

fn check_reserve_debt_maturity_reached(
    &LiquidationCheckInputs {
        lending_market,
        debt_reserve,
        obligation,
        timestamp,
        ..
    }: &LiquidationCheckInputs,
) -> Option<LiquidationParams> {
    let Some(secs_since_debt_maturity) = debt_reserve
        .config
        .get_secs_since_debt_maturity_reached(timestamp)
    else {
        return None; // debt maturity not reached yet
    };
    if !lending_market.is_mature_reserve_debt_liquidation_enabled() {
        xmsg!(
            "Debt reserve's maturity timestamp has been reached {} seconds ago, but the feature is disabled",
            secs_since_debt_maturity,
        );
        return None;
    }

    // Note: we interpret the "reserve's debt maturity" as another kind of reserve deleveraging, and
    // hence we calculate its liquidation bonus in the same way:
    let days_since_debt_maturity = secs::to_days_fractional(secs_since_debt_maturity);
    let liquidation_bonus_rate = calculate_autodeleverage_bonus_rate(
        debt_reserve.config.min_deleveraging_bonus_bps,
        debt_reserve.config.deleveraging_bonus_increase_bps_per_day,
        debt_reserve.config.max_liquidation_bonus_bps,
        u16::MAX, // market-wide deleveraging deliberately does NOT take elevation group into account
        days_since_debt_maturity,
        &obligation.no_bf_loan_to_value(),
    );

    xmsg!("Debt reserve's maturity timestamp has been reached, seconds: {secs_since_debt_maturity} ({days_since_debt_maturity} days), liquidation bonus: {liquidation_bonus_rate}", );
    Some(LiquidationParams {
        liquidation_bonus_rate,
        liquidation_reason: LiquidationReason::ReserveDebtMaturityReached,
    })
}

fn check_borrow_reserve_debt_term_reached(
    &LiquidationCheckInputs {
        lending_market,
        collateral_reserve,
        liquidity,
        debt_reserve,
        obligation,
        timestamp,
        ..
    }: &LiquidationCheckInputs,
) -> Option<LiquidationParams> {
    let Some(secs_since_debt_term_end) =
        liquidity.get_secs_since_reserve_debt_term_end(&debt_reserve.config, timestamp)
    else {
        return None; // debt maturity not reached yet
    };
    if !lending_market.is_obligation_borrow_debt_term_liquidation_enabled() {
        xmsg!(
            "Obligation borrow's debt term has been reached {} seconds ago, but the feature is disabled",
            secs_since_debt_term_end,
        );
        return None;
    }
    let days_since_debt_term_end = secs::to_days_fractional(secs_since_debt_term_end);
    // Apply the liquidation bonus same as for the individual obligation autodeleveraging:
    let liquidation_bonus_rate = calculate_autodeleverage_bonus_rate_from_coll_and_debt_reserves(
        lending_market,
        collateral_reserve,
        debt_reserve,
        obligation,
        days_since_debt_term_end,
    );
    xmsg!("Obligation borrow's debt term has been reached {days_since_debt_term_end} days ago, liquidation bonus: {liquidation_bonus_rate}", );
    Some(LiquidationParams {
        liquidation_bonus_rate,
        liquidation_reason: LiquidationReason::ObligationBorrowDebtTermReached(
            secs_since_debt_term_end,
        ),
    })
}

/// Checks whether any of the obligation's orders can be executed.
fn check_obligation_order_execution(
    &LiquidationCheckInputs {
        lending_market,
        collateral_reserve,
        debt_reserve,
        obligation,
        ..
    }: &LiquidationCheckInputs,
) -> Option<LiquidationParams> {
    let (order_index, condition_hit) = find_applicable_obligation_order(
        collateral_reserve,
        debt_reserve,
        obligation,
        lending_market.is_price_triggered_liquidation_disabled(),
    )?;
    let order = &obligation.obligation_orders[order_index];
    if !lending_market.is_obligation_order_execution_enabled() {
        xmsg!(
            "Obligation's order {}. condition {} is hit with {}, but the feature is disabled",
            order_index,
            order.condition_to_display(),
            condition_hit
        );
        return None;
    }
    xmsg!(
        "Obligation's order {}. condition {} is hit with {}, enabling the liquidator to {}",
        order_index,
        order.condition_to_display(),
        condition_hit,
        order.opportunity_to_display()
    );
    Some(LiquidationParams {
        liquidation_bonus_rate: calculate_order_execution_bonus_rate(
            order,
            &condition_hit,
            obligation.no_bf_loan_to_value(),
        ),
        liquidation_reason: LiquidationReason::ObligationOrder(order_index),
    })
}

pub(crate) fn calculate_autodeleverage_bonus_rate_from_coll_and_debt_reserves(
    lending_market: &LendingMarket,
    collateral_reserve: &Reserve,
    debt_reserve: &Reserve,
    obligation: &Obligation,
    days_since_deleveraging_started: Fraction,
) -> Fraction {
    // Some parameters come from a reserve config, and we want all of them to come from the same one:
    let selected_reserve_config = [&collateral_reserve.config, &debt_reserve.config]
        .into_iter()
        .max_by_key(|reserve| {
            // We select the reserve based on the highest bonus limit, and then highest daily increase, and then highest starting bonus:
            (
                reserve.max_liquidation_bonus_bps,
                reserve.deleveraging_bonus_increase_bps_per_day,
                reserve.min_deleveraging_bonus_bps,
            )
        })
        .expect("must exist for a statically-constructed non-empty array");
    calculate_autodeleverage_bonus_rate(
        selected_reserve_config.min_deleveraging_bonus_bps,
        selected_reserve_config.deleveraging_bonus_increase_bps_per_day,
        selected_reserve_config.max_liquidation_bonus_bps,
        get_emode_max_liquidation_bonus(
            lending_market,
            &collateral_reserve.config,
            &debt_reserve.config,
            obligation,
        ),
        days_since_deleveraging_started,
        &obligation.no_bf_loan_to_value(),
    )
}

/// Checks whether a collateral or debt reserve can be auto-deleveraged.
/// Returns the liquidation params if so.
fn get_autodeleverage_liquidation_params(
    autodeleverage_reserve: &Reserve,
    obligation: &Obligation,
    secs_since_deleveraging_started: u64,
) -> Option<LiquidationParams> {
    let days_since_deleveraging_started = secs::to_days_fractional(secs_since_deleveraging_started);
    let autodeleverage_ltv_threshold =
        calculate_autodeleverage_threshold(autodeleverage_reserve, days_since_deleveraging_started);
    let user_ltv = obligation.loan_to_value();
    if user_ltv.ge(&autodeleverage_ltv_threshold) {
        let liquidation_bonus_rate = calculate_autodeleverage_bonus_rate(
            autodeleverage_reserve.config.min_deleveraging_bonus_bps,
            autodeleverage_reserve
                .config
                .deleveraging_bonus_increase_bps_per_day,
            autodeleverage_reserve.config.max_liquidation_bonus_bps,
            u16::MAX, // market-wide deleveraging deliberately does NOT take elevation group into account
            days_since_deleveraging_started,
            &obligation.no_bf_loan_to_value(),
        );

        // TODO: optimize this print
        xmsg!("Auto-deleveraging LTV threshold crossed: {user_ltv}/{autodeleverage_ltv_threshold}, seconds: {secs_since_deleveraging_started} ({days_since_deleveraging_started} days), liquidation bonus: {liquidation_bonus_rate}", );
        Some(LiquidationParams {
            liquidation_bonus_rate,
            liquidation_reason: LiquidationReason::MarketWideDeleveraging,
        })
    } else {
        // TODO: optimize this print
        xmsg!("LTV is below the current auto-deleverage threshold: {user_ltv}/{autodeleverage_ltv_threshold}, seconds since deleveraging started: {secs_since_deleveraging_started}", );
        None
    }
}

/// Checks whether a reserve's collateral can be auto-deleveraged, i.e. the deposit limit is crossed, the timestamp is set, and the margin call period has expired.
/// Returns the duration (in seconds) since deleveraging started if so.
pub fn get_secs_since_autodeleverage_obligation_collateral_deposit_limit_crossed(
    collateral_reserve: &Reserve,
    timestamp: u64,
) -> Option<u64> {
    if collateral_reserve.deposit_limit_crossed() {
        if collateral_reserve.liquidity.deposit_limit_crossed_timestamp == 0 {
            xmsg!("Reserve deposit limit crossed but timestamp not set - need to call refresh reserve?");
            None
        } else {
            xmsg!("Reserve is eligible for collateral auto-deleveraging");
            let secs_since_margin_call_started = timestamp
                .saturating_sub(collateral_reserve.liquidity.deposit_limit_crossed_timestamp);
            get_secs_since_deleveraging_started(
                collateral_reserve
                    .config
                    .deleveraging_margin_call_period_secs,
                secs_since_margin_call_started,
            )
        }
    } else {
        xmsg!("Reserve deposit limit not crossed");
        None
    }
}

/// Checks whether a reserve's debt can be auto-deleveraged, i.e. the borrow limit is crossed, the timestamp is set, and the margin call period has expired.
/// Returns the duration (in seconds) since deleveraging started if so.
pub fn get_secs_since_autodeleverage_obligation_debt_borrow_limit_crossed(
    debt_reserve: &Reserve,
    timestamp: u64,
) -> Option<u64> {
    if debt_reserve.borrow_limit_crossed() {
        if debt_reserve.liquidity.borrow_limit_crossed_timestamp == 0 {
            xmsg!("Reserve borrow limit crossed but timestamp not set - need to call refresh reserve?");
            None
        } else {
            xmsg!("Reserve is eligible for debt auto-deleveraging");
            let secs_since_margin_call_started =
                timestamp.saturating_sub(debt_reserve.liquidity.borrow_limit_crossed_timestamp);
            get_secs_since_deleveraging_started(
                debt_reserve.config.deleveraging_margin_call_period_secs,
                secs_since_margin_call_started,
            )
        }
    } else {
        xmsg!("Reserve borrow limit not crossed");
        None
    }
}

fn get_secs_since_deleveraging_started(
    deleveraging_margin_call_period_secs: u64,
    secs_since_margin_call_started: u64,
) -> Option<u64> {
    let secs_since_deleveraging_started =
        secs_since_margin_call_started.checked_sub(deleveraging_margin_call_period_secs);
    if secs_since_deleveraging_started.is_none() {
        xmsg!("Reserve is eligible for auto-deleveraging, but margin call period not expired ({secs_since_margin_call_started}/{deleveraging_margin_call_period_secs} seconds)");
    }
    secs_since_deleveraging_started
}

/// Calculates the LTV threshold at which an obligation can be auto-deleveraged.
/// The auto-deleverage liquidation threshold decreases (from 100%) by the configured daily rate:
/// `autodeleverage_threshold = 100% - (deleveraging_threshold_decrease_bps_per_day * days_since_deleveraging_started) bps`
/// Returns 0% if the reduction is higher than 100% (i.e. making all loans auto-deleverage-able).
pub(crate) fn calculate_autodeleverage_threshold(
    autodeleverage_reserve: &Reserve,
    days_since_deleveraging_started: Fraction,
) -> Fraction {
    let daily_ltv_threshold_decrease = Fraction::from_bps(
        autodeleverage_reserve
            .config
            .deleveraging_threshold_decrease_bps_per_day,
    );
    let ltv_threshold_reduction = daily_ltv_threshold_decrease * days_since_deleveraging_started;
    Fraction::ONE.saturating_sub(ltv_threshold_reduction)
}

/// Calculate the auto-deleverage liquidation bonus rate.
/// The bonus starts at a configured min and increases by `deleveraging_bonus_increase_bps_per_day`
/// bps per each day passed since deleveraging started. Hence, the formula is:
/// `bonus_bps = reserve_min_deleveraging_bonus + deleveraging_bonus_increase_bps_per_day * days_since_deleveraging_started`
/// On top of this, the bonus cannot exceed:
/// - neither a configured limit (which is the smaller one of the two numbers: the reserve's general
///   bonus limit and the elevation group's limit),
/// - nor a ceiled limit of `1.0 - user_no_bf_ltv` (which ensures that deleveraging improves LTV).
pub(crate) fn calculate_autodeleverage_bonus_rate(
    reserve_min_deleveraging_bonus_bps: u16,
    deleveraging_bonus_increase_bps_per_day: u64,
    reserve_max_liquidation_bonus_bps: u16,
    emode_max_liquidation_bonus_bps: u16,
    days_since_deleveraging_started: Fraction,
    user_no_bf_ltv: &Fraction,
) -> Fraction {
    let configured_min_bonus_rate = Fraction::from_bps(reserve_min_deleveraging_bonus_bps);
    let daily_bonus_increase = Fraction::from_bps(deleveraging_bonus_increase_bps_per_day);

    let liquidation_bonus_rate =
        configured_min_bonus_rate + (daily_bonus_increase * days_since_deleveraging_started);

    // Take the elevation group's potential bonus-lowering into account:
    let configured_max_bonus_rate = Fraction::from_bps(min(
        reserve_max_liquidation_bonus_bps,
        emode_max_liquidation_bonus_bps,
    ));

    // In order to ensure that LTV improves on deleveraging, we apply the same heuristic formula as
    // for the regular liquidations:
    let diff_to_bad_debt = Fraction::ONE.saturating_sub(*user_no_bf_ltv);
    let effective_max_bonus_rate = min(configured_max_bonus_rate, diff_to_bad_debt);

    if liquidation_bonus_rate > effective_max_bonus_rate {
        xmsg!("After {days_since_deleveraging_started} days, at user_no_bf_ltv = {user_no_bf_ltv}, the autodeleverage bonus should be {liquidation_bonus_rate}, but it is capped at {effective_max_bonus_rate}", );
        effective_max_bonus_rate
    } else {
        liquidation_bonus_rate
    }
}

/// Calculates the given order's actual execution bonus rate.
///
/// The min-max bonus range is configured by the user on a per-order basis, and the actual value is
/// interpolated based on the given obligation's state at the moment of order execution.
/// In short: the minimum bonus applies if the order is executed precisely at the point when the
/// condition is met. Then, as the distance from condition's threshold grows, the bonus approaches
/// the configured maximum. See [ObligationOrder::execution_bonus_rate_range()] for details.
///
/// On top of that, similar to regular liquidation, the bonus cannot exceed the ceiled limit of
/// `1.0 - user_no_bf_ltv` (which ensures that order execution improves LTV).
pub(crate) fn calculate_order_execution_bonus_rate(
    order: &ObligationOrder,
    condition_hit: &ConditionHit,
    user_no_bf_ltv: Fraction,
) -> Fraction {
    let theoretic_bonus_rate = match condition_hit.normalized_distance_from_threshold {
        Some(normalized_distance_from_threshold) => interpolate_bonus_rate(
            normalized_distance_from_threshold,
            order.execution_bonus_rate_range(),
        ),
        None => get_constant_bonus_rate(order),
    };
    // In order to ensure that LTV improves on order execution, we apply the same heuristic formula
    // as for the regular liquidations:
    let diff_to_bad_debt = Fraction::ONE.saturating_sub(user_no_bf_ltv);
    if theoretic_bonus_rate > diff_to_bad_debt {
        xmsg!("At user_no_bf_ltv = {user_no_bf_ltv}, the calculated order execution bonus {theoretic_bonus_rate} is capped at {diff_to_bad_debt}", );
        diff_to_bad_debt
    } else {
        theoretic_bonus_rate
    }
}

fn interpolate_bonus_rate(
    normalized_distance_from_threshold: Fraction,
    bonus_rate_range: RangeInclusive<Fraction>,
) -> Fraction {
    bonus_rate_range.start()
        + normalized_distance_from_threshold * (bonus_rate_range.end() - bonus_rate_range.start())
}

fn get_constant_bonus_rate(order: &ObligationOrder) -> Fraction {
    let range = order.execution_bonus_rate_range();
    if range.end() != range.start() {
        panic!(
            "The order validation should not have allowed non-constant bonus range when condition is {}; got: [{}; {}]",
            order.condition_to_display(),
            range.start(),
            range.end()
        );
    }
    *range.start() // it is equal to range.end() too
}

/// Calculate protocol cut of liquidation bonus always at least 1 lamport
// TODO: optimization, could we have the bonus or amount_repayed directly here instead of calculating it again?
pub fn calculate_protocol_liquidation_fee(
    amount_liquidated: u64,
    liquidation_bonus_rate: Fraction,
    protocol_liquidation_fee_pct: u8,
) -> u64 {
    // Convert variables
    let protocol_fee_rate = Fraction::from_percent(protocol_liquidation_fee_pct);
    let amount_liquidated = Fraction::from(amount_liquidated);

    // Calculate bonus
    // protocol_fee = bonus * protocol_liquidation_fee_rate
    // bonus = amount_liquidated - repayed_amount
    // bonus_multiplier = liquidation_bonus_rate + 1
    // amount_liquidated = repayed_amount * bonus_multiplier
    // repayed_amount = amount_liquidated / bonus_multiplier
    // bonus = amount_liquidated - (amount_liquidated / bonus_multiplier)

    let bonus_multiplier = liquidation_bonus_rate + Fraction::ONE;

    let bonus = amount_liquidated - (amount_liquidated / bonus_multiplier);

    let protocol_fee = bonus * protocol_fee_rate;
    let protocol_fee: u64 = protocol_fee.to_ceil();

    max(protocol_fee, 1) // Return at least 1 lamport
}

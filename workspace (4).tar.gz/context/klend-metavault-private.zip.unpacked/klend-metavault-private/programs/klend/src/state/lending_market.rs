use anchor_lang::prelude::*;
use borsh::{BorshDeserialize, BorshSerialize};
use bytemuck::Zeroable;
use derivative::Derivative;
#[cfg(feature = "serde")]
use serde_values::*;

#[cfg(feature = "serde")]
use super::{serde_bool_u8, serde_string, serde_utf_string};
#[cfg(feature = "serde")]
use crate::utils::permissioning::bitflags_str;
use crate::{
    utils::{
        accounts::default_array, permissioning::PermissionedOp, Fraction, FractionExtra,
        CLOSE_TO_INSOLVENCY_RISKY_LTV, DEFAULT_MIN_DEPOSIT_AMOUNT, ELEVATION_GROUP_NONE,
        GLOBAL_ALLOWED_BORROW_VALUE, LENDING_MARKET_SIZE, LIQUIDATION_CLOSE_FACTOR,
        LIQUIDATION_CLOSE_VALUE, MAX_LIQUIDATABLE_VALUE_AT_ONCE, MIN_BORROW_ORDER_FILL_VALUE,
        MIN_NET_VALUE_IN_OBLIGATION, MIN_WITHDRAW_QUEUED_LIQUIDITY_VALUE, PROGRAM_VERSION,
    },
    LendingError, RolloverMode,
};

static_assertions::const_assert_eq!(LENDING_MARKET_SIZE, std::mem::size_of::<LendingMarket>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<LendingMarket>() % 8);
#[derive(PartialEq, Eq, Derivative)]
#[derivative(Debug)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "serde", serde(deny_unknown_fields))]
#[account(zero_copy)]
#[repr(C)]
pub struct LendingMarket {
    /// Version of lending market
    pub version: u64,
    /// Bump seed for derived authority address
    pub bump_seed: u64,
    /// Owner authority which can add new reserves
    #[cfg_attr(feature = "serde", serde(with = "serde_string", default))]
    pub lending_market_owner: Pubkey,
    /// Temporary cache of the lending market owner, used in update_lending_market_owner
    #[cfg_attr(feature = "serde", serde(with = "serde_string", default))]
    pub lending_market_owner_cached: Pubkey,
    /// Currency market prices are quoted in
    /// e.g. "USD" null padded (`*b"USD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"`) or a SPL token mint pubkey
    #[cfg_attr(feature = "serde", serde(with = "serde_utf_string", default))]
    pub quote_currency: [u8; 32],

    /// Referral fee for the lending market, as bps out of the total protocol fee
    pub referral_fee_bps: u16,

    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub emergency_mode: u8,

    /// Whether the obligations on this market should be subject to auto-deleveraging after deposit
    /// or borrow limit is crossed.
    /// Besides this flag, the particular reserve's flag also needs to be enabled (logical `AND`).
    /// **NOTE:** this also affects the individual "target LTV" deleveraging.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub autodeleverage_enabled: u8,

    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub borrow_disabled: u8,

    /// Refresh price from oracle only if it's older than this percentage of the price max age.
    /// e.g. if the max age is set to 100s and this is set to 80%, the price will be refreshed if it's older than 80s.
    /// Price is always refreshed if this set to 0.
    pub price_refresh_trigger_to_max_age_pct: u8,

    /// Percentage of the total borrowed value in an obligation available for liquidation
    pub liquidation_max_debt_close_factor_pct: u8,
    /// Minimum acceptable unhealthy LTV before max_debt_close_factor_pct becomes 100%
    pub insolvency_risk_unhealthy_ltv_pct: u8,
    /// Minimum liquidation value threshold triggering full liquidation for an obligation, in full
    /// units of the quote currency (e.g. `2` means "$2", not "2 lamports of USDC").
    pub min_full_liquidation_value_threshold: u64,

    /// Max allowed liquidation value in one ix call
    pub max_liquidatable_debt_market_value_at_once: u64,
    /// [DEPRECATED] Global maximum unhealthy borrow value allowed for any obligation
    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default)
    )]
    #[derivative(Debug = "ignore")]
    pub reserved0: [u8; 8],
    /// Global maximum allowed borrow value allowed for any obligation
    pub global_allowed_borrow_value: u64,
    /// The address of the emergency council, in charge of taking emergency actions on the market (e.g., enabling emergency mode)
    #[cfg_attr(feature = "serde", serde(with = "serde_string", default))]
    pub emergency_council: Pubkey,

    /// [DEPRECATED] Reward points multiplier per obligation type
    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default)
    )]
    #[derivative(Debug = "ignore")]
    pub reserved1: [u8; 8],

    /// Elevation groups are used to group together reserves that have the same risk parameters and can bump the ltv and liquidation threshold
    pub elevation_groups: [ElevationGroup; 32],
    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default = "default_array")
    )]
    pub elevation_group_padding: [u64; 90],

    /// Min net value accepted to be found in a position after any lending action in an obligation (scaled by quote currency decimals)
    #[cfg_attr(
        feature = "serde",
        serde(
            serialize_with = "serialize_min_net_value",
            deserialize_with = "deserialize_min_net_value"
        )
    )]
    pub min_net_value_in_obligation_sf: u128,

    /// Minimum value to enforce smallest ltv priority checks on the collateral reserves on liquidation
    pub min_value_skip_liquidation_ltv_checks: u64,

    /// Market name, zero-padded.
    #[cfg_attr(feature = "serde", serde(with = "serde_utf_string", default))]
    pub name: [u8; 32],

    /// Minimum value to enforce highest borrow factor priority checks on the debt reserves on liquidation
    pub min_value_skip_liquidation_bf_checks: u64,

    /// Time (in seconds) that must pass before liquidation is allowed on an obligation that has
    /// been individually marked for auto-deleveraging.
    pub individual_autodeleverage_margin_call_period_secs: u64,

    /// Minimum amount of deposit at creation of a reserve to prevent artificial inflation
    /// Note: this amount cannot be recovered, the ctoken associated are never minted
    pub min_initial_deposit_amount: u64,

    /// Whether the obligation orders should be evaluated during liquidations.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub obligation_order_execution_enabled: u8,

    /// Whether the lending market is set as immutable.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub immutable: u8,

    /// Whether new obligation orders can be created.
    /// Note: updating or cancelling existing orders is *not* affected by this flag.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub obligation_order_creation_enabled: u8,

    /// Whether the liquidation operations that are triggered by price changes should be disabled.
    /// This includes regular liquidation (i.e. LTV exceeding the unhealthy threshold) and some
    /// obligation orders' execution.
    ///
    /// *Caution:* this flag is *disabling* the liquidations when `1` - contrary to all the other
    /// liquidation-driving flags (see e.g. [Self::autodeleverage_enabled]).
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub price_triggered_liquidation_disabled: u8,

    /// Whether the debts that reached their reserve's [ReserveConfig::debt_maturity_timestamp] can
    /// be liquidated.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub mature_reserve_debt_liquidation_enabled: u8,

    /// Whether the [Obligation::borrows] that reached their [ReserveConfig::debt_term_seconds] can
    /// be liquidated.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub obligation_borrow_debt_term_liquidation_enabled: u8,

    /// Whether new borrow orders can be created.
    /// Note: updating or cancelling existing orders is *not* affected by this flag.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub borrow_order_creation_enabled: u8,

    /// Whether the existing borrow orders can be filled.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub borrow_order_execution_enabled: u8,

    /// Authority that can propose creating of new reserves but cannot enable them.
    #[cfg_attr(feature = "serde", serde(with = "serde_string", default))]
    pub proposer_authority: Pubkey,

    /// Minimum value that can be filled in a single `fill_borrow_order()` call, in full units of
    /// the quote currency (e.g. `2` means "$2", not "2 lamports of USDC").
    // Note: this exists only to mitigate the "excessive origination fee", which is a potential
    // attack based on repeated low-lamport deposits + permissionless BO fills.
    pub min_borrow_order_fill_value: u64,

    /// Whether any new withdraw tickets can be issued (i.e. whether new requests can enter the
    /// withdraw queue).
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub withdraw_ticket_issuance_enabled: u8,

    /// Whether the existing withdraw tickets can be redeemed (i.e. whether the tickets can be used
    /// to transfer accumulated pending liquidity to destination accounts).
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub withdraw_ticket_redemption_enabled: u8,

    /// Whether the owners can enable the borrow rollover/migration on their obligations.
    ///
    /// *Note 1:* the actual execution of (different kinds of) rollovers are enabled/disabled by:
    /// - [Self::fixed_term_rollover_window_duration_seconds],
    /// - [Self::open_term_rollover_window_duration_seconds],
    /// - [Self::obligation_borrow_migration_to_fixed_execution_enabled].
    ///
    /// *Note 2:* when this configuration is disabled, the obligation owners can still disable their
    /// rollover (i.e. set the obligation's flags to zeroes).
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub obligation_borrow_rollover_configuration_enabled: u8,

    /// Whether the actual execution of a "migration to fixed" rollover flavor is allowed.
    ///
    /// See [FixedTermBorrowRolloverConfig::migration_to_fixed_enabled].
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub obligation_borrow_migration_to_fixed_execution_enabled: u8,

    /// Whether the ticket owners can cancel their withdraw tickets (i.e. recover ctokens from the
    /// queued collateral vault back to their wallet).
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub withdraw_ticket_cancellation_enabled: u8,

    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default = "default_array")
    )]
    #[derivative(Debug = "ignore")]
    pub padding2: [u8; 1],

    /// Maximum APR (in basis points; `FULL_BPS = 10_000` = 100%) at which reserves on this market
    /// may distribute their `rewards_amount_per_slot`. `0` disables rewards on this market
    /// entirely (`topup_reserve_rewards` is rejected). Bounded by `FULL_BPS` (100% APR) when set.
    /// See [ReserveConfig::rewards_amount_per_slot] for the depositor-cap interaction.
    pub reserve_rewards_max_apr_bps: u16,

    /// Minimum value that can be withdrawn in a single `withdraw_queued_liquidity()` call, in full
    /// units of the quote currency (e.g. `2` means "$2", not "2 lamports of USDC").
    // Note: this exists only to mitigate the "excessive loss due to flooring low withdraw amounts",
    // which is a potential attack based on repeated low-lamport deposits + permissionless ticketed
    // withdrawals.
    pub min_withdraw_queued_liquidity_value: u64,

    /// A configurable time window (right before the end of a fixed debt term) during which an
    /// auto-rollover into another *fixed* rate/term can happen.
    ///
    /// When zeroed, this rollover mode is effectively disabled.
    /// Can only be enabled when [Self::min_partial_rollover_value] is configured.
    ///
    /// See [FixedTermBorrowRolloverConfig].
    pub fixed_term_rollover_window_duration_seconds: u64,

    /// A configurable time window (right before the end of a fixed debt term) during which an
    /// auto-rollover into a *variable* (indefinite) rate/term can happen.
    ///
    /// When zeroed, this rollover mode is effectively disabled.
    /// Can only be enabled when [Self::min_partial_rollover_value] is configured.
    ///
    /// This will typically be shorter than [Self::fixed_term_rollover_window_duration_seconds],
    /// acting as a fallback if a fixed reserve liquidity remains unavailable for considerable time.
    pub open_term_rollover_window_duration_seconds: u64,

    /// Minimum dollar value for a partial rollover into a different reserve.
    /// When the achievable rollover amount is below this threshold (and it's not a full rollover),
    /// the rollover is rejected.
    ///
    /// In full units of the quote currency (e.g. `2` means "$2").
    pub min_partial_rollover_value: u64,

    /// The time that must pass before an entire expired debt becomes liquidatable.
    ///
    /// For example:
    /// Let's assume this duration is configured as 100 seconds; then:
    /// - right after fixed-term debt expiration, effectively no debt can be liquidated.
    /// - 30 seconds after expiration, we allow to 30% of the expired debt to be liquidated
    ///    - to be specific: at this point in time, we "protect" from liquidation 70% of the
    ///      [ObligationLiquidity::borrowed_amount_at_expiration] (regardless of how much interest
    ///      was accrued or how much debt was repaid while expired).
    /// - 100 seconds after expiration we allow the entire debt to be liquidated.
    ///
    /// Only effective when [Self::obligation_borrow_debt_term_liquidation_enabled].
    ///
    /// Motivation note: this throttling feature gives an opportunity to execute a configured
    /// auto-rollover (after a partial liquidation brings the debt size down so that there is enough
    /// available liquidity in some compatible reserve).
    ///
    /// When zeroed, an entire expired debt can be liquidated right after expiration (i.e. no
    /// throttling).
    pub term_based_full_liquidation_duration_secs: u64,

    /// If not NULL, operations encoded in permissioned_ops require a signature from this authority
    #[cfg_attr(feature = "serde", serde(with = "serde_string", default))]
    pub permissioning_authority: Pubkey,
    /// Bitmap of operations that require permissioning authority signature
    #[cfg_attr(feature = "serde", serde(with = "bitflags_str", default))]
    pub permissioned_ops: u64,

    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default = "default_array")
    )]
    #[derivative(Debug = "ignore")]
    pub padding1: [u64; 153],
}

impl Default for LendingMarket {
    fn default() -> Self {
        Self {
            version: 0,
            bump_seed: 0,
            lending_market_owner: Pubkey::default(),
            emergency_council: Pubkey::default(),
            quote_currency: default_array(),
            lending_market_owner_cached: Pubkey::default(),
            emergency_mode: 0,
            borrow_disabled: 0,
            price_triggered_liquidation_disabled: 0,
            autodeleverage_enabled: 0,
            liquidation_max_debt_close_factor_pct: LIQUIDATION_CLOSE_FACTOR,
            insolvency_risk_unhealthy_ltv_pct: CLOSE_TO_INSOLVENCY_RISKY_LTV,
            max_liquidatable_debt_market_value_at_once: MAX_LIQUIDATABLE_VALUE_AT_ONCE,
            global_allowed_borrow_value: GLOBAL_ALLOWED_BORROW_VALUE,
            min_full_liquidation_value_threshold: LIQUIDATION_CLOSE_VALUE,
            reserved0: default_array(),
            reserved1: default_array(),
            referral_fee_bps: 0,
            price_refresh_trigger_to_max_age_pct: 0,
            elevation_groups: [ElevationGroup::default(); 32],
            min_value_skip_liquidation_ltv_checks: 0,
            min_value_skip_liquidation_bf_checks: 0,
            elevation_group_padding: default_array(),
            min_net_value_in_obligation_sf: MIN_NET_VALUE_IN_OBLIGATION.to_bits(),
            name: default_array(),
            individual_autodeleverage_margin_call_period_secs: 0,
            min_initial_deposit_amount: DEFAULT_MIN_DEPOSIT_AMOUNT,
            obligation_order_execution_enabled: 0,
            immutable: 0,
            obligation_order_creation_enabled: 0,
            mature_reserve_debt_liquidation_enabled: 0,
            obligation_borrow_debt_term_liquidation_enabled: 0,
            borrow_order_creation_enabled: 0,
            borrow_order_execution_enabled: 0,
            proposer_authority: Pubkey::default(),
            withdraw_ticket_issuance_enabled: 0,
            withdraw_ticket_redemption_enabled: 0,
            withdraw_ticket_cancellation_enabled: 0,
            min_withdraw_queued_liquidity_value: MIN_WITHDRAW_QUEUED_LIQUIDITY_VALUE,
            fixed_term_rollover_window_duration_seconds: 0,
            open_term_rollover_window_duration_seconds: 0,
            obligation_borrow_rollover_configuration_enabled: 0,
            min_borrow_order_fill_value: MIN_BORROW_ORDER_FILL_VALUE,
            term_based_full_liquidation_duration_secs: 0,
            obligation_borrow_migration_to_fixed_execution_enabled: 0,
            min_partial_rollover_value: 0,
            permissioning_authority: Pubkey::default(),
            permissioned_ops: 0,
            padding2: default_array(),
            reserve_rewards_max_apr_bps: 0,
            padding1: default_array(),
        }
    }
}

impl LendingMarket {
    /// Initialize a lending market
    pub fn init(&mut self, params: InitLendingMarketParams) {
        *self = Self::default();
        self.version = PROGRAM_VERSION as u64;
        self.bump_seed = params.bump_seed as u64;
        self.lending_market_owner = params.lending_market_owner;
        self.quote_currency = params.quote_currency;
    }

    /// Returns the [Self::name], interpreted (best-effort) as null-padded utf-8.
    pub fn get_name(&self) -> &str {
        std::str::from_utf8(&self.name)
            .unwrap_or("<invalid utf-8>")
            .trim_end_matches('\0')
    }

    pub fn get_elevation_group(&self, id: u8) -> Result<Option<&ElevationGroup>> {
        if id == ELEVATION_GROUP_NONE {
            Ok(None)
        } else {
            Ok(Some(
                self.elevation_groups
                    .get(id as usize - 1)
                    .ok_or(LendingError::InvalidElevationGroup)?,
            ))
        }
    }

    pub fn set_elevation_group(&mut self, elevation_group: ElevationGroup) -> Result<()> {
        // Sanity check for the none elevation group, this group remains defaulted always
        if elevation_group.id == ELEVATION_GROUP_NONE {
            return err!(LendingError::InvalidElevationGroupConfig);
        }

        self.elevation_groups[elevation_group.get_index()] = elevation_group;

        Ok(())
    }

    pub fn is_borrowing_disabled(&self) -> bool {
        self.borrow_disabled != false as u8
    }

    pub fn is_price_triggered_liquidation_disabled(&self) -> bool {
        self.price_triggered_liquidation_disabled != false as u8
    }

    pub fn is_autodeleverage_enabled(&self) -> bool {
        self.autodeleverage_enabled != false as u8
    }

    pub fn is_obligation_order_execution_enabled(&self) -> bool {
        self.obligation_order_execution_enabled != false as u8
    }

    pub fn is_obligation_order_creation_enabled(&self) -> bool {
        self.obligation_order_creation_enabled != false as u8
    }

    pub fn is_mature_reserve_debt_liquidation_enabled(&self) -> bool {
        self.mature_reserve_debt_liquidation_enabled != false as u8
    }

    pub fn is_obligation_borrow_debt_term_liquidation_enabled(&self) -> bool {
        self.obligation_borrow_debt_term_liquidation_enabled != false as u8
    }

    pub fn is_borrow_order_creation_enabled(&self) -> bool {
        self.borrow_order_creation_enabled != false as u8
    }

    pub fn is_borrow_order_execution_enabled(&self) -> bool {
        self.borrow_order_execution_enabled != false as u8
    }

    pub fn is_withdraw_ticket_issuance_enabled(&self) -> bool {
        self.withdraw_ticket_issuance_enabled != false as u8
    }

    pub fn is_withdraw_ticket_redemption_enabled(&self) -> bool {
        self.withdraw_ticket_redemption_enabled != false as u8
    }

    pub fn is_obligation_borrow_rollover_configuration_enabled(&self) -> bool {
        self.obligation_borrow_rollover_configuration_enabled != false as u8
    }

    pub fn is_withdraw_ticket_cancellation_enabled(&self) -> bool {
        self.withdraw_ticket_cancellation_enabled != false as u8
    }

    /// Resolves the configured [AllowedRolloverTime] for the given rollover mode, or returns an
    /// error if such rollover's execution is currently disabled.
    pub fn resolve_allowed_rollover_time(&self, mode: RolloverMode) -> Result<AllowedRolloverTime> {
        Ok(match mode {
            RolloverMode::FromFixedToFixedTerm => {
                if self.fixed_term_rollover_window_duration_seconds == 0 {
                    return err!(LendingError::BorrowRolloverExecutionDisabled);
                }
                AllowedRolloverTime::BeforeDebtExpiration(
                    self.fixed_term_rollover_window_duration_seconds,
                )
            }
            RolloverMode::FromFixedToOpenTerm => {
                if self.open_term_rollover_window_duration_seconds == 0 {
                    return err!(LendingError::BorrowRolloverExecutionDisabled);
                }
                AllowedRolloverTime::BeforeDebtExpiration(
                    self.open_term_rollover_window_duration_seconds,
                )
            }
            RolloverMode::FromOpenToFixedTerm => {
                if self.obligation_borrow_migration_to_fixed_execution_enabled == false as u8 {
                    return err!(LendingError::BorrowRolloverExecutionDisabled);
                }
                AllowedRolloverTime::Always
            }
        })
    }

    pub fn is_immutable(&self) -> bool {
        self.immutable != false as u8
    }

    pub fn get_insolvency_risk_unhealthy_ltv(&self) -> Fraction {
        Fraction::from_percent(self.insolvency_risk_unhealthy_ltv_pct)
    }

    pub fn get_liquidation_max_debt_close_factor(&self) -> Fraction {
        Fraction::from_percent(self.liquidation_max_debt_close_factor_pct)
    }

    pub fn get_max_liquidatable_debt_market_value_at_once(&self) -> Fraction {
        Fraction::from_num(self.max_liquidatable_debt_market_value_at_once)
    }

    pub fn get_term_based_full_liquidation_duration_secs(&self) -> Option<u64> {
        if self.term_based_full_liquidation_duration_secs == 0 {
            return None;
        }
        Some(self.term_based_full_liquidation_duration_secs)
    }

    pub fn requires_permission(&self, op: PermissionedOp) -> bool {
        self.is_permissioned_market() && op.intersects(self.get_permissioned_ops())
    }

    pub fn check_permissions(
        &self,
        ops: PermissionedOp,
        permissioning_acct: Option<&AccountInfo>,
    ) -> Result<bool> {
        if !self.requires_permission(ops) {
            return Ok(false);
        }
        let acct = permissioning_acct.ok_or(error!(LendingError::MissingPermissioner))?;
        require_keys_eq!(
            acct.key(),
            self.permissioning_authority,
            LendingError::MissingPermissioner
        );
        require!(acct.is_signer, ErrorCode::AccountNotSigner);
        Ok(true)
    }

    pub fn is_permissioned_market(&self) -> bool {
        self.permissioning_authority != Pubkey::default()
    }

    pub fn get_permissioned_ops(&self) -> PermissionedOp {
        PermissionedOp::from_bits_truncate(self.permissioned_ops)
    }

    /// Whether reserve rewards distribution is enabled on this market.
    ///
    /// Disabled when [Self::reserve_rewards_max_apr_bps] is `0`. In that state, topping up
    /// `rewards_amount_available` and configuring a non-zero `rewards_amount_per_slot` are
    /// both rejected.
    pub fn is_reserve_rewards_enabled(&self) -> bool {
        self.reserve_rewards_max_apr_bps > 0
    }
}

/// A specification of *when* some rollover operation is allowed.
pub enum AllowedRolloverTime {
    /// Always allowed.
    Always,

    /// Only allowed during a finite time window (specified in seconds) right before the debt term
    /// expiration.
    BeforeDebtExpiration(u64),
}

/// Initialize a lending market
pub struct InitLendingMarketParams {
    /// Bump seed for derived authority address
    pub bump_seed: u8,
    /// Owner authority which can add new reserves
    pub lending_market_owner: Pubkey,
    /// Currency market prices are quoted in
    /// e.g. "USD" null padded (`*b"USD\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"`) or a SPL token mint pubkey
    pub quote_currency: [u8; 32],
}

#[derive(BorshSerialize, BorshDeserialize, Derivative, PartialEq, Eq)]
#[derivative(Debug)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "serde", serde(deny_unknown_fields))]
#[zero_copy]
#[repr(C)]
pub struct ElevationGroup {
    pub max_liquidation_bonus_bps: u16,
    pub id: u8,
    pub ltv_pct: u8,
    pub liquidation_threshold_pct: u8,
    pub allow_new_loans: u8,
    pub max_reserves_as_collateral: u8,

    #[derivative(Debug = "ignore")]
    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default)
    )]
    pub padding_0: u8,

    /// Mandatory debt reserve for this elevation group
    #[cfg_attr(feature = "serde", serde(with = "serde_string", default))]
    pub debt_reserve: Pubkey,
    #[derivative(Debug = "ignore")]
    #[cfg_attr(
        feature = "serde",
        serde(skip_deserializing, skip_serializing, default)
    )]
    pub padding_1: [u64; 4],
}

impl Default for ElevationGroup {
    fn default() -> Self {
        let mut default = Self::zeroed();
        default.max_reserves_as_collateral = u8::MAX;
        default
    }
}

impl ElevationGroup {
    pub fn new_loans_disabled(&self) -> bool {
        self.allow_new_loans == 0
    }

    pub fn get_index(&self) -> usize {
        self.id as usize - 1
    }
}

#[cfg(feature = "serde")]
mod serde_values {
    use std::result::Result;

    use serde::{
        de::{self, Deserialize, Deserializer},
        Serializer,
    };

    use crate::fraction::Fraction;

    pub fn serialize_min_net_value<S>(value: &u128, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let min_net_action_value_f = Fraction::from_bits(*value);
        serializer.serialize_str(&min_net_action_value_f.to_string())
    }

    pub fn deserialize_min_net_value<'de, D>(deserializer: D) -> Result<u128, D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        let net_value_action_f = Fraction::from_str(&s)
            .map_err(|_| de::Error::custom("min_net_value must be a fraction"))?;

        Ok(net_value_action_f.to_bits())
    }
}

use std::{
    cmp::{max, min},
    ops::{Add, Div, Mul},
};

use anchor_lang::{
    account, err,
    prelude::{msg, Pubkey, *},
    solana_program::clock::Slot,
    Result,
};
use borsh::{BorshDeserialize, BorshSerialize};
use derivative::Derivative;
use num_enum::{IntoPrimitive, TryFromPrimitive};
#[cfg(feature = "serde")]
use serde;

#[cfg(feature = "serde")]
use super::serde_bool_u8;
#[cfg(feature = "serde")]
use super::serde_reserve_status;
use crate::{
    fraction::FractionExtra,
    lending_market::withdrawal_cap_operations::utils::remaining_withdrawal_caps_amount,
    state::{DepositLiquidityResult, LastUpdate, TokenInfo},
    utils::{
        accounts::default_array, borrow_rate_curve::BorrowRateCurve, ten_pow, BigFraction,
        Fraction, FRACTION_ONE_SCALED, FULL_BPS, INITIAL_COLLATERAL_RATE, PROGRAM_VERSION,
        RESERVE_CONFIG_SIZE, RESERVE_SIZE, SLOTS_PER_YEAR, U256,
    },
    BorrowSize, CalculateBorrowResult, CalculateRepayResult, LendingError, LendingResult,
    ReferrerTokenState,
};

#[derive(Default, Debug, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct BigFractionBytes {
    pub value: [u64; 4],
    pub padding: [u64; 2],
}

impl From<BigFraction> for BigFractionBytes {
    fn from(value: BigFraction) -> BigFractionBytes {
        BigFractionBytes {
            value: value.to_bits(),
            padding: [0; 2],
        }
    }
}

impl From<BigFractionBytes> for BigFraction {
    fn from(value: BigFractionBytes) -> BigFraction {
        BigFraction::from_bits(value.value)
    }
}

static_assertions::const_assert_eq!(RESERVE_SIZE, std::mem::size_of::<Reserve>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<Reserve>() % 8);
#[derive(PartialEq, Derivative)]
#[derivative(Debug)]
#[account(zero_copy)]
#[repr(C)]
pub struct Reserve {
    /// Version of the reserve
    pub version: u64,

    /// Last slot when supply and rates updated
    pub last_update: LastUpdate,

    /// Lending market address
    pub lending_market: Pubkey,

    pub farm_collateral: Pubkey,
    pub farm_debt: Pubkey,

    /// Reserve liquidity
    pub liquidity: ReserveLiquidity,

    #[derivative(Debug = "ignore")]
    pub reserve_liquidity_padding: [u64; 150],

    /// Reserve collateral
    pub collateral: ReserveCollateral,

    #[derivative(Debug = "ignore")]
    pub reserve_collateral_padding: [u64; 150],

    /// Reserve configuration values
    pub config: ReserveConfig,

    #[derivative(Debug = "ignore")]
    pub config_padding: [u64; 113],

    pub borrowed_amount_outside_elevation_group: u64,

    /// Amount of token borrowed in lamport of debt asset in the given
    /// elevation group when this reserve is part of the collaterals.
    pub borrowed_amounts_against_this_reserve_in_elevation_groups: [u64; 32],

    /// The tracker of ticket-based withdrawals.
    pub withdraw_queue: WithdrawQueue,

    #[derivative(Debug = "ignore")]
    pub padding: [u64; 204],
}

impl Default for Reserve {
    fn default() -> Self {
        Self {
            version: 0,
            last_update: LastUpdate::default(),
            lending_market: Pubkey::default(),
            liquidity: ReserveLiquidity::default(),
            collateral: ReserveCollateral::default(),
            config: ReserveConfig::default(),
            farm_collateral: Pubkey::default(),
            farm_debt: Pubkey::default(),
            reserve_liquidity_padding: default_array(),
            reserve_collateral_padding: default_array(),
            config_padding: default_array(),
            borrowed_amount_outside_elevation_group: 0,
            borrowed_amounts_against_this_reserve_in_elevation_groups: [0; 32],
            withdraw_queue: WithdrawQueue::default(),
            padding: default_array(),
        }
    }
}

#[derive(
    AnchorSerialize,
    AnchorDeserialize,
    TryFromPrimitive,
    PartialEq,
    Eq,
    Clone,
    Copy,
    Debug,
    strum::EnumIter,
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[repr(u8)]
pub enum ReserveFarmKind {
    Collateral = 0,
    Debt = 1,
}

impl Reserve {
    /// Initialize a reserve
    pub fn init(&mut self, params: InitReserveParams) {
        *self = Self::default();
        self.version = PROGRAM_VERSION as u64;
        self.last_update = LastUpdate::new(params.current_slot);
        self.lending_market = params.lending_market;
        self.liquidity = *params.liquidity;
        self.collateral = *params.collateral;
        self.config = *params.config;
    }

    // GETTERS

    /// Calculate the current borrow rate
    pub fn current_borrow_rate(&self) -> Result<Fraction> {
        let utilization_rate = self.liquidity.utilization_rate();

        self.config
            .borrow_rate_curve
            .get_borrow_rate(utilization_rate)
    }

    /// Get the current borrow factor
    pub fn borrow_factor_f(&self, is_in_elevation_group: bool) -> Fraction {
        if is_in_elevation_group {
            // With an elevation group, borrow factor is reset to 1
            Fraction::ONE
        } else {
            // If no elevation group applied, use the reserve's own borrow factor
            self.config.get_borrow_factor()
        }
    }

    pub fn get_farm(&self, mode: ReserveFarmKind) -> Pubkey {
        match mode {
            ReserveFarmKind::Collateral => self.farm_collateral,
            ReserveFarmKind::Debt => self.farm_debt,
        }
    }

    pub fn token_symbol(&self) -> &str {
        self.config.token_info.symbol()
    }

    /// Returns the total reserve liquidity available for *all* purposes - namely, as of now:
    /// - priority: ticketed withdrawals,
    /// - and then for other operations (if there is surplus).
    ///
    /// In other words: a part of this amount is considered "locked" for priority purposes and
    /// cannot be used for anything else.
    ///
    /// *Note on rounding*: this number is appropriate as input for many computations, but it does
    /// not reflect the amount that can *actually* be withdrawn in exchange for burning ctokens. See
    /// the [Self::total_withdrawable_liquidity_amount()].
    pub fn total_available_liquidity_amount(&self) -> u64 {
        self.liquidity.total_available_amount
    }

    /// Returns the part of reserve liquidity available for *non-priority* purposes (e.g. borrowing,
    /// regular withdraws).
    pub fn freely_available_liquidity_amount(&self) -> u64 {
        // Just reduce the total available amount by the number of tokens that has to be put aside for the queued collateral:
        self.liquidity
            .total_available_amount
            .saturating_sub(self.queued_liquidity_amount())
    }

    /// Calculates the liquidity corresponding to the ctokens locked in the withdraw queue.
    ///
    /// **Note on rounding:** the returned amount is actually "how much liquidity would be paid out
    /// right now, if all this collateral was queued in a single ticket". Since our withdraw
    /// handlers are rounding down to full lamports, `N` consecutive operations might actually end
    /// up withdrawing (up to) `N - 1` less liquidity tokens than the theoretical maximum amount
    /// returned here. Still, this is how much we need to put aside when considering e.g.
    /// [Self::freely_available_liquidity_amount()].
    pub fn queued_liquidity_amount(&self) -> u64 {
        self.collateral_exchange_rate()
            .collateral_to_liquidity(self.withdraw_queue.queued_collateral_amount)
    }

    /// Returns a part of [Self::total_available_liquidity_amount()] that can be *actually*
    /// withdrawn (i.e. transferred out in exchange for burning some integer amount of ctokens).
    ///
    /// This may be slightly less than [Self::total_available_liquidity_amount()], because of
    /// "collateral exchange rate misalignment" when applied to integer amounts of tokens/ctokens.
    ///
    /// ### An example of "slightly less withdrawable than available":
    ///
    /// Let's imagine an exchange rate of 1.425 and 100 total available liquidity tokens:
    /// - For 71 ctokens, we could withdraw 101 tokens (101.175, in theory), but we have only 100.
    /// - For 70 ctokens, we can withdraw 99 tokens (99.75, in theory).
    ///
    /// This means that despite "100 tokens are available", only "99 tokens are withdrawable".
    ///
    /// In the implementation, this is captured by the `liquidity_for_floored_collateral` branch.
    ///
    /// ### An example of "all available is withdrawable":
    ///
    /// Let's imagine an exchange rate of 1.361855670103092798 and 100 total available liquidity:
    /// - For 74 ctokens, we can withdraw 100 tokens (100.777319588, in theory, but we round it down
    ///   in favor of the protocol).
    /// - Since we hit the exact 100 available liquidity, there is no point considering any lower
    ///   or higher amount of ctokens.
    ///
    /// In the implementation, this is captured by the `liquidity_for_ceiled_collateral` branch.
    /// Technically, the condition could be `liquidity_for_ceiled_collateral == available_liquidity`
    /// but out of paranoid safety, we use the `<=` condition on the `if` (also: entering the `else`
    /// branch only makes sense when `>`).
    pub fn total_withdrawable_liquidity_amount(&self) -> u64 {
        let available_liquidity = self.total_available_liquidity_amount();
        let exchange_rate = self.collateral_exchange_rate();
        let ceiled_collateral_for_liquidity =
            exchange_rate.liquidity_to_collateral_ceil(available_liquidity);
        let liquidity_for_ceiled_collateral =
            exchange_rate.collateral_to_liquidity(ceiled_collateral_for_liquidity);
        if liquidity_for_ceiled_collateral <= available_liquidity {
            liquidity_for_ceiled_collateral
        } else {
            let floored_collateral_for_liquidity =
                exchange_rate.liquidity_to_collateral(available_liquidity);
            exchange_rate.collateral_to_liquidity(floored_collateral_for_liquidity)
            // a.k.a. `liquidity_for_floored_collateral`
        }
    }

    /// Returns the collateral amount that would be burned in order to withdraw the entirety of
    /// [Self::total_withdrawable_liquidity_amount()].
    ///
    /// **Note on rounding:** the "total redeemable" here should really say "total redeemable if you
    /// decided to redeem it all at once right now". Since this method is rounding up to full
    /// ctokens, `N` consecutive operations might actually end up burning (up to) `N - 1` more
    /// ctokens than the theoretical amount returned here.
    ///
    /// **Note on socialized loss scenarios:** in extreme cases, the collateral exchange rate may
    /// be `< 1.0`. Of course then [Self::total_withdrawable_liquidity_amount()] will be equal to
    /// [Self::total_available_liquidity_amount()] (i.e. the reserve can be emptied), *but* there
    /// may be a whole *range* of ctoken amounts that represent this liquidity token amount! This
    /// method's contract is to return the lowest number from this valid range.
    ///
    /// ### An example of "heavy socialized loss scenario":
    ///
    /// Let's imagine an exchange rate of 0.7 and 4 total available liquidity tokens:
    /// - For 6 ctokens, we can withdraw 4 tokens (4.2, in theory).
    /// - For 7 ctokens, we can still withdraw just 4 tokens (although it is 4.9, in theory).
    pub fn total_redeemable_collateral_amount(&self) -> u64 {
        let available_liquidity = self.total_available_liquidity_amount();
        let exchange_rate = self.collateral_exchange_rate();
        let ceiled_collateral = exchange_rate.liquidity_to_collateral_ceil(available_liquidity);
        if exchange_rate.collateral_to_liquidity(ceiled_collateral) <= available_liquidity {
            ceiled_collateral
        } else {
            exchange_rate.liquidity_to_collateral(available_liquidity) // a.k.a. `floored_collateral`
        }
    }

    /// Returns the part of reserve collateral redeemable by *non-priority* operations (e.g.
    /// borrowing, regular withdraws).
    pub fn freely_redeemable_collateral_amount(&self) -> u64 {
        self.total_redeemable_collateral_amount()
            .saturating_sub(self.withdraw_queue.queued_collateral_amount)
    }

    /// Returns a non-zero part of [Self::total_available_liquidity_amount()] that can be *actually*
    /// borrowed, given *all* the reserve's constraints and assuming no elevation group. Throws an
    /// appropriate "limit exceeded" error in case a specific limit prevents even the tiniest borrow.
    ///
    /// Note: the timestamp is only relevant for withdrawal cap limit consideration.
    pub fn borrowable_liquidity_amount_outside_elevation_group(
        &self,
        timestamp: u64,
    ) -> Result<u64> {
        // The reserve's inherent liquidity limit: (borrowing may only use "freely-available")
        let sufficient_liquidity_limit = self.freely_available_liquidity_amount();
        if sufficient_liquidity_limit == 0 {
            return err!(LendingError::InsufficientLiquidity);
        }

        // The administrative absolute borrow limit:
        let borrow_capacity_limit = self.remaining_borrow_capacity().to_floor();
        if borrow_capacity_limit == 0 {
            return err!(LendingError::BorrowLimitExceeded);
        }

        // The administrative elevation group borrow limit: (only the "outside" check is needed - see the method's contract)
        let remaining_borrow_limit_outside_elevation_group = self
            .config
            .borrow_limit_outside_elevation_group
            .saturating_sub(self.borrowed_amount_outside_elevation_group);
        if remaining_borrow_limit_outside_elevation_group == 0 {
            return err!(LendingError::ElevationGroupBorrowLimitExceeded); // Note: the error's name does not really match here, but we happen to reuse the same error for within/outside elevation group limits
        }

        // The administrative utilization rate limit:
        let utilization_rate_limit = if let Some(max_borrowing_utilization_rate) =
            self.config.max_borrowing_utilization_rate()
        {
            let utilization_limit_borrow_amount =
                self.liquidity.total_supply() * max_borrowing_utilization_rate;
            // Correctness note on the `- Fraction::DELTA` below: our historical (somewhat
            // questionable) interpretation of the `utilization_limit_block_borrowing_above_pct`
            // field would block a borrow that fits *exactly* within the limit (i.e. using `>=`
            // instead of `>`). To emulate the same behavior here, we have to subtract an ulp.
            utilization_limit_borrow_amount
                .saturating_sub(self.liquidity.total_borrow())
                .saturating_sub(Fraction::DELTA)
                .to_floor::<u64>()
        } else {
            self.liquidity.total_supply().to_floor() // not limited administratively
        };

        if utilization_rate_limit == 0 {
            return err!(LendingError::BorrowingAboveUtilizationRateDisabled);
        }

        // The limit coming from withdrawal caps:
        let withdrawal_caps_limit =
            remaining_withdrawal_caps_amount(&self.config.debt_withdrawal_cap, timestamp);
        if withdrawal_caps_limit == 0 {
            return err!(LendingError::WithdrawalCapReached);
        }

        // One of these will be the most restrictive:
        Ok([
            sufficient_liquidity_limit,
            borrow_capacity_limit,
            remaining_borrow_limit_outside_elevation_group,
            utilization_rate_limit,
            withdrawal_caps_limit,
        ]
        .into_iter()
        .min()
        .expect("statically non-empty array"))
    }

    /// Returns the liquidity currently remaining below the [ReserveConfig::borrow_limit].
    pub fn remaining_borrow_capacity(&self) -> Fraction {
        Fraction::from(self.config.borrow_limit).saturating_sub(self.liquidity.total_borrow())
    }

    pub fn add_farm(&mut self, farm_state: &Pubkey, mode: ReserveFarmKind) {
        match mode {
            ReserveFarmKind::Collateral => self.farm_collateral = *farm_state,
            ReserveFarmKind::Debt => self.farm_debt = *farm_state,
        }
    }

    pub fn compute_depositable_amount_and_minted_collateral(
        &self,
        liquidity_amount: u64,
    ) -> Result<DepositLiquidityResult> {
        // Compute collateral amount to mint from this liquidity amount
        let collateral_amount = self
            .collateral_exchange_rate()
            .liquidity_to_collateral(liquidity_amount);

        // Compute actual amount of liquidity to deposit from this collateral amount
        let liquidity_amount_to_deposit = self
            .collateral_exchange_rate()
            .collateral_to_liquidity_ceil(collateral_amount);

        require_gte!(
            liquidity_amount,
            liquidity_amount_to_deposit,
            LendingError::MathOverflow
        );

        Ok(DepositLiquidityResult {
            liquidity_amount: liquidity_amount_to_deposit,
            collateral_amount,
        })
    }

    /// Record deposited liquidity and amount of collateral tokens to mint
    pub fn deposit_liquidity(
        &mut self,
        liquidity_amount: u64,
        collateral_amount: u64,
    ) -> Result<()> {
        self.liquidity.deposit(liquidity_amount)?;
        self.collateral.mint(collateral_amount)?;

        Ok(())
    }

    /// Record redeemed collateral and return amount of liquidity to withdraw
    pub fn redeem_collateral(
        &mut self,
        collateral_amount: u64,
        use_withdraw_queue: bool,
    ) -> Result<u64> {
        let collateral_exchange_rate = self.collateral_exchange_rate();

        let liquidity_amount = collateral_exchange_rate.collateral_to_liquidity(collateral_amount);

        if use_withdraw_queue {
            self.withdraw_including_queued(liquidity_amount)?;
        } else {
            self.withdraw_freely_available(liquidity_amount)?;
        }
        // Note: it is critical to burn the ctokens AFTER the withdraw - the
        // `withdraw_freely_available()` method relies on the collateral exchange rate (to take the
        // queued ctokens into account), and the exchange rate depends on the total ctoken supply.
        self.collateral.burn(collateral_amount)?;

        Ok(liquidity_amount)
    }

    /// Subtract borrow amount from [Self::freely_available_liquidity_amount()] and add to borrows
    pub fn borrow(&mut self, borrow_f: Fraction, use_withdraw_queue: bool) -> Result<()> {
        if use_withdraw_queue {
            self.withdraw_including_queued(borrow_f.to_floor())?;
        } else {
            self.withdraw_freely_available(borrow_f.to_floor())?;
        }

        let borrowed_amount_f = self.liquidity.total_borrow();
        self.liquidity.borrowed_amount_sf = (borrowed_amount_f + borrow_f).to_bits();

        Ok(())
    }

    /// Subtract settle amount from accumulated_protocol_fees_sf and withdraw_amount from
    /// [Self::freely_available_liquidity_amount()].
    pub fn redeem_fees(&mut self, withdraw_amount: u64) -> Result<()> {
        self.withdraw_freely_available(withdraw_amount)?;

        let accumulated_protocol_fees_f =
            Fraction::from_bits(self.liquidity.accumulated_protocol_fees_sf);
        let withdraw_amount_f = Fraction::from_num(withdraw_amount);
        self.liquidity.accumulated_protocol_fees_sf = accumulated_protocol_fees_f
            .checked_sub(withdraw_amount_f)
            .ok_or_else(|| {
                msg!(
                    "Accumulated protocol fees {} cannot be less than withdraw amount {}",
                    accumulated_protocol_fees_f.to_display(),
                    withdraw_amount_f.to_display()
                );
                error!(LendingError::MathOverflow)
            })?
            .to_bits();

        Ok(())
    }

    /// Subtract settle amount from accumulated_protocol_fees_sf and withdraw_amount from available liquidity
    pub fn withdraw_referrer_fees(
        &mut self,
        withdraw_amount: u64,
        referrer_token_state: &mut ReferrerTokenState,
    ) -> Result<()> {
        self.withdraw_freely_available(withdraw_amount)?;

        let accumulated_referrer_fees_f =
            Fraction::from_bits(self.liquidity.accumulated_referrer_fees_sf);

        let withdraw_amount_f = Fraction::from_num(withdraw_amount);

        let new_accumulated_referrer_fees_f = accumulated_referrer_fees_f
            .checked_sub(withdraw_amount_f)
            .ok_or_else(|| {
                msg!(
                    "Accumulated referrer fees {} cannot be less than withdraw amount {}",
                    accumulated_referrer_fees_f.to_display(),
                    withdraw_amount_f.to_display()
                );
                error!(LendingError::MathOverflow)
            })?;

        self.liquidity.accumulated_referrer_fees_sf = new_accumulated_referrer_fees_f.to_bits();

        let referrer_amount_unclaimed_f =
            Fraction::from_bits(referrer_token_state.amount_unclaimed_sf);

        let new_referrer_amount_unclaimed_f = referrer_amount_unclaimed_f
            .checked_sub(withdraw_amount_f)
            .ok_or_else(|| {
                msg!(
                    "Unclaimed referrer fees {} cannot be less than withdraw amount {}",
                    referrer_amount_unclaimed_f.to_display(),
                    withdraw_amount_f.to_display()
                );
                error!(LendingError::MathOverflow)
            })?;

        referrer_token_state.amount_unclaimed_sf = new_referrer_amount_unclaimed_f.to_bits();

        Ok(())
    }

    /// Collateral exchange rate
    pub fn collateral_exchange_rate(&self) -> CollateralExchangeRate {
        let total_liquidity = self.liquidity.total_supply();
        self.collateral.exchange_rate(total_liquidity)
    }

    /// Update borrow rate and accrue interest
    pub fn accrue_interest(&mut self, current_slot: Slot, referral_fee_bps: u16) -> Result<()> {
        let slots_elapsed = self.last_update.slots_elapsed(current_slot)?;
        if slots_elapsed > 0 {
            let current_borrow_rate = self.current_borrow_rate()?;
            let protocol_take_rate = Fraction::from_percent(self.config.protocol_take_rate_pct);
            let referral_rate = Fraction::from_bps(referral_fee_bps);
            let host_fixed_interest_rate =
                Fraction::from_bps(self.config.host_fixed_interest_rate_bps);

            self.liquidity.compound_interest(
                current_borrow_rate,
                host_fixed_interest_rate,
                slots_elapsed,
                protocol_take_rate,
                referral_rate,
            )?;
        }

        Ok(())
    }

    /// Distributes a slice of [ReserveLiquidity::rewards_amount_available] into
    /// [ReserveLiquidity::total_available_amount] based on the configured
    /// [ReserveConfig::rewards_amount_per_slot] and the number of slots elapsed since the last refresh.
    ///
    /// The amount is bounded by:
    /// - the remaining `rewards_amount_available` budget,
    /// - the market-level APR cap (`max_apr_bps`, applied to the current `total_supply()`).
    ///
    /// Inflates the cToken exchange rate by the distributed amount. Returns `0` when
    /// distribution is disabled or there is nothing to distribute.
    pub fn distribute_rewards(&mut self, current_slot: Slot, max_apr_bps: u16) -> Result<u64> {
        let slots_elapsed = self.last_update.slots_elapsed(current_slot)?;
        if slots_elapsed == 0
            || max_apr_bps == 0
            || self.config.rewards_amount_per_slot == 0
            || self.liquidity.rewards_amount_available == 0
            || self.collateral.mint_total_supply == 0
        {
            return Ok(0);
        }

        let raw_distribution: u128 =
            (self.config.rewards_amount_per_slot as u128).saturating_mul(slots_elapsed as u128);

        // APR cap: max distributable in this period is
        //   total_supply * apr_bps * slots_elapsed / (FULL_BPS * SLOTS_PER_YEAR)
        //
        // Realistic inputs (token-sized `total_supply`, `apr_bps <= FULL_BPS`,
        // decades-worth of `slots_elapsed`) stay comfortably below `u128::MAX`;
        // `saturating_mul` is used as a defensive overflow guard. In any case,
        // `rewards_amount_available` is the cap.
        let total_supply_u128: u128 = self.liquidity.total_supply().to_floor();
        let apr_cap_numerator = total_supply_u128
            .saturating_mul(u128::from(max_apr_bps))
            .saturating_mul(u128::from(slots_elapsed));
        let apr_cap_denominator = u128::from(FULL_BPS) * u128::from(SLOTS_PER_YEAR);
        let apr_cap_u128 = apr_cap_numerator / apr_cap_denominator;

        let to_distribute_u128 = raw_distribution
            .min(apr_cap_u128)
            .min(u128::from(self.liquidity.rewards_amount_available));
        let to_distribute =
            u64::try_from(to_distribute_u128).map_err(|_| error!(LendingError::MathOverflow))?;

        if to_distribute == 0 {
            return Ok(0);
        }

        self.liquidity.rewards_amount_available = self
            .liquidity
            .rewards_amount_available
            .checked_sub(to_distribute)
            .ok_or_else(|| error!(LendingError::MathOverflow))?;
        self.liquidity.total_available_amount = self
            .liquidity
            .total_available_amount
            .checked_add(to_distribute)
            .ok_or_else(|| error!(LendingError::MathOverflow))?;

        msg!(
            "Reserve rewards distributed: slots={} amount={} remaining={}",
            slots_elapsed,
            to_distribute,
            self.liquidity.rewards_amount_available,
        );

        Ok(to_distribute)
    }

    /// Update the timestamp of the last deposit limit breach if it is not already set, or reset to 0 if the cap is no longer crossed
    pub fn update_deposit_limit_crossed_timestamp(&mut self, timestamp: u64) {
        if self.deposit_limit_crossed() {
            if self.liquidity.deposit_limit_crossed_timestamp == 0 {
                self.liquidity.deposit_limit_crossed_timestamp = timestamp;
            }
            // else, already set, nothing to do
        } else {
            self.liquidity.deposit_limit_crossed_timestamp = 0;
        }
    }

    /// Update the timestamp of the last deposit limit breach if it is not already set, or reset to 0 if the cap is no longer crossed
    pub fn update_borrow_limit_crossed_timestamp(&mut self, timestamp: u64) {
        if self.borrow_limit_crossed() {
            if self.liquidity.borrow_limit_crossed_timestamp == 0 {
                self.liquidity.borrow_limit_crossed_timestamp = timestamp;
            }
            // else, already set, nothing to do
        } else {
            self.liquidity.borrow_limit_crossed_timestamp = 0;
        }
    }

    /// Calculate the cumulative borrow rate at a future slot.
    /// Used for estimating the interest that would accrue over a given period.
    ///
    /// Note: this is intended to be used with fixed-term borrows, which have a fixed borrow rate,
    /// so this computation over the projected period is accurate.
    pub fn calculate_future_cumulative_borrow_rate(&self, future_slot: u64) -> Result<BigFraction> {
        let slots_elapsed = self.last_update.slots_elapsed(future_slot)?;
        let current_borrow_rate = self.current_borrow_rate()?;
        let host_fixed_interest_rate = Fraction::from_bps(self.config.host_fixed_interest_rate_bps);
        let previous_cumulative_borrow_rate =
            BigFraction::from(self.liquidity.cumulative_borrow_rate_bsf);

        let compounded_interest_rate = approximate_compounded_interest(
            current_borrow_rate + host_fixed_interest_rate,
            slots_elapsed,
        );

        Ok(previous_cumulative_borrow_rate * BigFraction::from(compounded_interest_rate))
    }

    /// Borrow liquidity up to a maximum market value
    pub fn calculate_borrow(
        &self,
        borrow_size: BorrowSize,
        max_borrow_factor_adjusted_debt_value: Fraction,
        referral_fee_bps: u16,
        is_in_elevation_group: bool,
        has_referrer: bool,
    ) -> Result<CalculateBorrowResult> {
        let borrow_factor_f = self.borrow_factor_f(is_in_elevation_group);

        match borrow_size {
            BorrowSize::AllAvailable => self.calculate_borrow_all_available(
                max_borrow_factor_adjusted_debt_value,
                referral_fee_bps,
                has_referrer,
                borrow_factor_f,
            ),
            BorrowSize::Exact(receive_amount) => self.calculate_borrow_exact(
                receive_amount,
                max_borrow_factor_adjusted_debt_value,
                referral_fee_bps,
                has_referrer,
                borrow_factor_f,
            ),
            BorrowSize::AtMost(requested_receive_amount) => {
                let borrow_exact_result = self.calculate_borrow_exact(
                    requested_receive_amount,
                    max_borrow_factor_adjusted_debt_value,
                    referral_fee_bps,
                    has_referrer,
                    borrow_factor_f,
                );
                // Note: if borrowing the exact requested amount fails, then we want to fall back
                // to "alright then, give me whatever is available", BUT ONLY in some situations
                // (namely: when the problem originates from "you requested too much"). There are
                // other errors which should actually be propagated (e.g. "you requested so little
                // that fees would eat you" - see related `CalculateBorrowTestCase`s).
                if borrow_exact_result == err!(LendingError::BorrowTooLarge)
                    || borrow_exact_result == err!(LendingError::BorrowLimitExceeded)
                    || borrow_exact_result == err!(LendingError::InsufficientLiquidity)
                {
                    self.calculate_borrow_all_available(
                        max_borrow_factor_adjusted_debt_value,
                        referral_fee_bps,
                        has_referrer,
                        borrow_factor_f,
                    )
                } else {
                    borrow_exact_result
                }
            }
        }
    }

    fn calculate_borrow_all_available(
        &self,
        max_borrow_factor_adjusted_debt_value: Fraction,
        referral_fee_bps: u16,
        has_referrer: bool,
        borrow_factor_f: Fraction,
    ) -> Result<CalculateBorrowResult> {
        let max_obligation_borrow_amount = self
            .liquidity
            .market_value_to_liquidity_amount(max_borrow_factor_adjusted_debt_value)
            / borrow_factor_f;
        let max_reserve_borrow_amount = min(
            self.remaining_borrow_capacity(),
            self.freely_available_liquidity_amount().into(),
        );
        let borrow_amount_f = min(max_obligation_borrow_amount, max_reserve_borrow_amount);
        let (origination_fee, referrer_fee) = self.config.fees.calculate_borrow_fees(
            borrow_amount_f,
            FeeCalculation::Inclusive,
            referral_fee_bps,
            has_referrer,
        )?;
        let borrow_amount: u64 = borrow_amount_f.to_floor();
        let receive_amount = borrow_amount - origination_fee - referrer_fee;

        Ok(CalculateBorrowResult {
            borrow_amount_f,
            receive_amount,
            origination_fee,
            referrer_fee,
        })
    }

    fn calculate_borrow_exact(
        &self,
        receive_amount: u64,
        max_borrow_factor_adjusted_debt_value: Fraction,
        referral_fee_bps: u16,
        has_referrer: bool,
        borrow_factor_f: Fraction,
    ) -> Result<CalculateBorrowResult> {
        let receive_amount_f = Fraction::from(receive_amount);
        let (origination_fee, referrer_fee) = self.config.fees.calculate_borrow_fees(
            receive_amount_f,
            FeeCalculation::Exclusive,
            referral_fee_bps,
            has_referrer,
        )?;
        let borrow_amount_f = receive_amount_f + Fraction::from_num(origination_fee + referrer_fee);
        let debt_value = self
            .liquidity
            .liquidity_amount_to_market_value(borrow_amount_f);
        let borrow_factor_adjusted_debt_value = debt_value * borrow_factor_f;

        if borrow_factor_adjusted_debt_value > max_borrow_factor_adjusted_debt_value {
            msg!(
                "Borrow value {} cannot exceed maximum borrow value {}",
                borrow_factor_adjusted_debt_value.to_display(),
                max_borrow_factor_adjusted_debt_value.to_display(),
            );
            return err!(LendingError::BorrowTooLarge);
        }
        let remaining_borrow_capacity_f = self.remaining_borrow_capacity();
        if borrow_amount_f > remaining_borrow_capacity_f {
            msg!(
                "Borrowing {} (including fees: {}) would exceed the reserve's remaining limit {}",
                receive_amount,
                borrow_amount_f.to_display(),
                remaining_borrow_capacity_f.to_display(),
            );
            return err!(LendingError::BorrowLimitExceeded);
        }
        let reserve_available_liquidity_f =
            Fraction::from(self.freely_available_liquidity_amount());
        if borrow_amount_f > reserve_available_liquidity_f {
            msg!(
                "Borrowing {} (including fees: {}) would exceed the reserve's remaining liquidity {}",
                receive_amount,
                borrow_amount_f.to_display(),
                reserve_available_liquidity_f.to_display(),
            );
            return err!(LendingError::InsufficientLiquidity);
        }
        Ok(CalculateBorrowResult {
            borrow_amount_f,
            receive_amount,
            origination_fee,
            referrer_fee,
        })
    }

    /// Repay liquidity up to the borrowed amount
    pub fn calculate_repay(
        &self,
        amount_to_repay: u64,
        borrowed_amount: Fraction,
    ) -> CalculateRepayResult {
        let settle_amount = if amount_to_repay == u64::MAX {
            borrowed_amount
        } else {
            min(Fraction::from(amount_to_repay), borrowed_amount)
        };
        let repay_amount = settle_amount.to_ceil();

        CalculateRepayResult {
            settle_amount,
            repay_amount,
        }
    }

    /// Calculate protocol fee redemption accounting for available liquidity and accumulated fees
    pub fn calculate_redeem_fees(&self) -> u64 {
        min(
            self.freely_available_liquidity_amount(),
            Fraction::from_bits(self.liquidity.accumulated_protocol_fees_sf).to_floor(),
        )
    }

    /// Return true if the deposit limit has been crossed
    pub fn deposit_limit_crossed(&self) -> bool {
        self.liquidity.total_supply() > Fraction::from(self.config.deposit_limit)
    }

    /// Return true if the borrow limit has been crossed
    pub fn borrow_limit_crossed(&self) -> bool {
        self.liquidity.total_borrow() > Fraction::from(self.config.borrow_limit)
    }

    /// Calculate protocol fee redemption accounting for available liquidity and accumulated fees
    pub fn get_withdraw_referrer_fees(&self, referrer_token_state: &ReferrerTokenState) -> u64 {
        let available_unclaimed_sf = min(
            referrer_token_state.amount_unclaimed_sf,
            self.liquidity.accumulated_referrer_fees_sf,
        );
        let available_unclaimed: u64 = Fraction::from_bits(available_unclaimed_sf).to_floor();
        min(
            available_unclaimed,
            self.freely_available_liquidity_amount(),
        )
    }

    /// Removes the given amount from the total available liquidity (including the funds accumulated
    /// order to satisfy the [Self::withdraw_queue]).
    fn withdraw_including_queued(&mut self, liquidity_amount: u64) -> Result<()> {
        if liquidity_amount > self.liquidity.total_available_amount {
            msg!(
                "Withdraw amount {} cannot exceed the total available amount {}",
                liquidity_amount,
                self.liquidity.total_available_amount
            );
            return err!(LendingError::InsufficientLiquidity);
        }
        self.liquidity.total_available_amount -= liquidity_amount; // cannot overflow after the check above
        Ok(())
    }

    /// Removes the given amount from the freely-available part of the liquidity.
    fn withdraw_freely_available(&mut self, liquidity_amount: u64) -> Result<()> {
        let freely_available_amount = self.freely_available_liquidity_amount();
        if liquidity_amount > freely_available_amount {
            msg!(
                "Withdraw liquidity amount {} cannot exceed the freely available amount {}",
                liquidity_amount,
                freely_available_amount
            );
            return err!(LendingError::InsufficientLiquidity);
        }
        self.liquidity.total_available_amount -= liquidity_amount; // cannot overflow after the check above, since `total_available_amount >= freely_available_amount`
        Ok(())
    }

    /// Return true if the reserve has shown signs of activity
    /// Markers for activity are:
    /// - Liquidity available amount is greater than minimum initial deposit amount
    /// - Borrowed amount is greater than zero
    pub fn is_used(&self, min_initial_deposit_amount: u64) -> bool {
        self.total_available_liquidity_amount() > min_initial_deposit_amount
            || self.liquidity.total_borrow() > Fraction::ZERO
            || self.collateral.mint_total_supply > min_initial_deposit_amount
    }

    /// Return true if the reserve cannot receive deposits or borrows
    pub fn is_usage_blocked(&self) -> bool {
        self.config.deposit_limit == 0 && self.config.borrow_limit == 0
    }

    /// Returns true if the reserve is "pre-deposit": i.e. not used *and* its usage is blocked.
    ///
    /// This is just a shorthand for a common ![Self::is_used()] && [Self::is_usage_blocked()]
    /// combination.
    pub fn is_predeposit(&self, min_initial_deposit_amount: u64) -> bool {
        !self.is_used(min_initial_deposit_amount) && self.is_usage_blocked()
    }

    pub fn has_initial_deposit(&self) -> bool {
        self.total_available_liquidity_amount() > 0 || self.collateral.mint_total_supply > 0
    }
}

/// Initialize a reserve
pub struct InitReserveParams {
    /// Last slot when supply and rates updated
    pub current_slot: Slot,
    /// Lending market address
    pub lending_market: Pubkey,
    /// Reserve liquidity
    pub liquidity: Box<ReserveLiquidity>,
    /// Reserve collateral
    pub collateral: Box<ReserveCollateral>,
    /// Reserve configuration values
    pub config: Box<ReserveConfig>,
}

/// Reserve liquidity
#[derive(Debug, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct ReserveLiquidity {
    /// Reserve liquidity mint address
    pub mint_pubkey: Pubkey,
    /// Reserve liquidity supply address
    pub supply_vault: Pubkey,
    /// Reserve liquidity fee collection address
    pub fee_vault: Pubkey,

    /// Total reserve liquidity available.
    ///
    /// Note: not all of this liquidity can be freely used for any purpose. Production code should
    /// use the specialized getters - see e.g. [Reserve::total_available_liquidity_amount()],
    /// [Reserve::freely_available_liquidity_amount()].
    pub total_available_amount: u64,

    /// Reserve liquidity borrowed (scaled fraction)
    pub borrowed_amount_sf: u128,
    /// Reserve liquidity market price in quote currency (scaled fraction)
    pub market_price_sf: u128,
    /// Unix timestamp of the market price (from the oracle)
    pub market_price_last_updated_ts: u64,
    /// Reserve liquidity mint decimals
    pub mint_decimals: u64,

    /// Timestamp when the last refresh reserve detected that the liquidity amount is above the deposit cap. When this threshold is crossed, then redemptions (auto-deleverage) are enabled.
    /// If the threshold is not crossed, then the timestamp is set to 0
    pub deposit_limit_crossed_timestamp: u64,
    /// Timestamp when the last refresh reserve detected that the borrowed amount is above the borrow cap. When this threshold is crossed, then redemptions (auto-deleverage) are enabled.
    /// If the threshold is not crossed, then the timestamp is set to 0
    pub borrow_limit_crossed_timestamp: u64,

    /// Reserve liquidity cumulative borrow rate (scaled fraction)
    pub cumulative_borrow_rate_bsf: BigFractionBytes,
    /// Reserve cumulative protocol fees (scaled fraction)
    pub accumulated_protocol_fees_sf: u128,
    /// Reserve cumulative referrer fees (scaled fraction)
    pub accumulated_referrer_fees_sf: u128,
    /// Reserve pending referrer fees, to be claimed in refresh_obligation by referrer or protocol (scaled fraction)
    pub pending_referrer_fees_sf: u128,
    /// Reserve referrer fee absolute rate calculated at each refresh_reserve operation (scaled fraction)
    pub absolute_referral_rate_sf: u128,
    /// Token program of the liquidity mint
    pub token_program: Pubkey,

    /// Reserve rewards budget remaining for distribution.
    ///
    /// Tokens are deposited via `topup_reserve_rewards` and increase this counter (without
    /// touching [Self::total_available_amount]). On every `refresh_reserve`, up to
    /// `rewards_amount_per_slot * slots_elapsed` tokens are moved from this counter into
    /// [Self::total_available_amount], inflating the cToken exchange rate, capped by the
    /// market-level `reserve_rewards_max_apr_bps` cap.
    pub rewards_amount_available: u64,

    pub padding2: [u64; 50],
    pub padding3: [u128; 32],
}

/// A tracker of ticket-based withdrawals.
#[derive(Debug, PartialEq, Eq, Default)]
#[zero_copy]
#[repr(C)]
pub struct WithdrawQueue {
    /// The part of [ReserveLiquidity::total_available_amount] locked for ticketed withdrawals.
    pub queued_collateral_amount: u64,

    /// The sequence number of the next ticket to be issued when enqueueing to withdraw.
    /// Note: it is also a number of tickets issued so far.
    pub next_issued_ticket_sequence_number: u64,

    /// The sequence number of the next ticket to be used for actually transferring the withdrawn
    /// liquidity (assuming it is available in the reserve).
    /// Note: it is also a number of fully-consumed tickets so far.
    pub next_withdrawable_ticket_sequence_number: u64,
}

impl WithdrawQueue {
    /// Records the given collateral amount as pending withdrawal (for a ticket with sequence number
    /// [Self::next_issued_ticket_sequence_number]) and progresses the next issued ticket.
    ///
    /// Returns the issued ticket's sequence number.
    pub fn enqueue(&mut self, collateral_amount: u64) -> u64 {
        self.queued_collateral_amount += collateral_amount;
        let issued_sequence_number = self.next_issued_ticket_sequence_number;
        self.next_issued_ticket_sequence_number = issued_sequence_number + 1;
        issued_sequence_number
    }

    /// Records the given collateral amount as actually withdrawn (for a ticket with sequence
    /// number [Self::next_withdrawable_ticket_sequence_number]) and progresses the next
    /// withdrawable ticket if this one gets closed (e.g. was just fully-consumed or was already a
    /// tombstone after cancellation).
    pub fn dequeue(&mut self, collateral_amount: u64, ticket_closed: bool) {
        self.queued_collateral_amount -= collateral_amount;
        if ticket_closed {
            self.next_withdrawable_ticket_sequence_number += 1;
        }
    }
}

impl Default for ReserveLiquidity {
    fn default() -> Self {
        Self {
            mint_pubkey: Pubkey::default(),
            supply_vault: Pubkey::default(),
            fee_vault: Pubkey::default(),
            total_available_amount: 0,
            borrowed_amount_sf: 0,
            cumulative_borrow_rate_bsf: BigFractionBytes::from(BigFraction::from(Fraction::ONE)),
            accumulated_protocol_fees_sf: 0,
            market_price_sf: 0,
            mint_decimals: 0,
            deposit_limit_crossed_timestamp: 0,
            borrow_limit_crossed_timestamp: 0,
            accumulated_referrer_fees_sf: 0,
            pending_referrer_fees_sf: 0,
            absolute_referral_rate_sf: 0,
            market_price_last_updated_ts: 0,
            token_program: Pubkey::default(),
            rewards_amount_available: 0,
            padding2: default_array(),
            padding3: default_array(),
        }
    }
}

impl ReserveLiquidity {
    /// Create a new reserve liquidity
    pub fn new(params: NewReserveLiquidityParams) -> Self {
        let NewReserveLiquidityParams {
            mint_pubkey,
            mint_decimals,
            mint_token_program,
            supply_vault,
            fee_vault,
            market_price_sf,
            initial_amount_deposited_in_reserve,
        } = params;

        Self {
            mint_pubkey,
            mint_decimals: mint_decimals.into(),
            supply_vault,
            fee_vault,
            total_available_amount: initial_amount_deposited_in_reserve,
            borrowed_amount_sf: 0,
            cumulative_borrow_rate_bsf: BigFractionBytes::from(BigFraction::from(Fraction::ONE)),
            accumulated_protocol_fees_sf: 0,
            market_price_sf,
            deposit_limit_crossed_timestamp: 0,
            borrow_limit_crossed_timestamp: 0,
            accumulated_referrer_fees_sf: 0,
            pending_referrer_fees_sf: 0,
            absolute_referral_rate_sf: 0,
            market_price_last_updated_ts: 0,
            token_program: mint_token_program,
            rewards_amount_available: 0,
            padding2: default_array(),
            padding3: default_array(),
        }
    }

    /// Calculate the total reserve supply including active loans
    pub fn total_supply(&self) -> Fraction {
        Fraction::from(self.total_available_amount) + Fraction::from_bits(self.borrowed_amount_sf)
            - Fraction::from_bits(self.accumulated_protocol_fees_sf)
            - Fraction::from_bits(self.accumulated_referrer_fees_sf)
            - Fraction::from_bits(self.pending_referrer_fees_sf)
    }

    /// Calculate the total reserve borrowed from active loans
    pub fn total_borrow(&self) -> Fraction {
        Fraction::from_bits(self.borrowed_amount_sf)
    }

    /// Add liquidity to available amount
    pub fn deposit(&mut self, liquidity_amount: u64) -> Result<()> {
        self.total_available_amount = self
            .total_available_amount
            .checked_add(liquidity_amount)
            .ok_or(LendingError::MathOverflow)?;
        Ok(())
    }

    /// Add repay amount to available liquidity and subtract settle amount from total borrows
    pub fn repay(&mut self, repay_amount: u64, settle_amount: Fraction) -> LendingResult<()> {
        self.total_available_amount = self
            .total_available_amount
            .checked_add(repay_amount)
            .ok_or(LendingError::MathOverflow)?;
        let borrowed_amount_f = Fraction::from_bits(self.borrowed_amount_sf);
        let safe_settle_amount = min(settle_amount, borrowed_amount_f);
        self.borrowed_amount_sf = borrowed_amount_f
            .checked_sub(safe_settle_amount)
            .ok_or_else(|| {
                msg!(
                    "Borrowed amount {} cannot be less than settle amount {}",
                    borrowed_amount_f.to_display(),
                    safe_settle_amount.to_display()
                );
                LendingError::MathOverflow
            })?
            .to_bits();

        Ok(())
    }

    /// Accumulate early repay penalty into protocol fees and available liquidity.
    /// The penalty was already transferred by the borrower into the supply vault,
    /// so we just need to account for it.
    pub fn accumulate_early_repay_penalty(&mut self, penalty_lamports: u64) -> LendingResult<()> {
        let penalty_f = Fraction::from_num(penalty_lamports);
        let accumulated_protocol_fees_f = Fraction::from_bits(self.accumulated_protocol_fees_sf);
        self.accumulated_protocol_fees_sf = (accumulated_protocol_fees_f + penalty_f).to_bits();
        self.total_available_amount += penalty_lamports;
        Ok(())
    }

    /// Calculate the liquidity utilization rate of the reserve
    pub fn utilization_rate(&self) -> Fraction {
        let total_supply = self.total_supply();
        if total_supply == Fraction::ZERO {
            // TODO: discuss this should be a rate of 1 IMO.
            return Fraction::ZERO;
        }
        Fraction::from_bits(self.borrowed_amount_sf) / total_supply
    }

    /// A factor to multiply the amount by in order to get lamports (i.e. `10 ^ mint_decimals`).
    pub fn mint_factor(&self) -> u64 {
        ten_pow(usize::try_from(self.mint_decimals).expect("mint decimals is expected to be <20"))
    }

    /// Calculates raw market value (i.e. *no* borrow factor) of the given liquidity amount.
    ///
    /// Note on rounding: the least significant (binary) digit will be rounded *down*.
    // TODO(rounding-correctness): inspect the callers - maybe they should really be using a `_ceil()` variant?
    pub fn liquidity_amount_to_market_value(&self, liquidity_amount: Fraction) -> Fraction {
        let mint_factor_sf = u128::from(self.mint_factor()) * FRACTION_ONE_SCALED;
        liquidity_amount.full_mul_int_ratio(self.market_price_sf, mint_factor_sf)
    }

    /// Calculates liquidity amount worth the given raw market value (i.e. *no* borrow factor).
    ///
    /// Note on rounding: the least significant (binary) digit will be rounded *down*.
    pub fn market_value_to_liquidity_amount(&self, market_value: Fraction) -> Fraction {
        let mint_factor_sf = u128::from(self.mint_factor()) * FRACTION_ONE_SCALED;
        market_value.full_mul_int_ratio(mint_factor_sf, self.market_price_sf)
    }

    /// Compound current borrow rate over elapsed slots
    /// This also calculates protocol fees, which are taken for all obligations
    /// that have borrow from current reserve.
    /// This also calculates referral fees, which are taken into pending_referral_fees
    /// assuming that each obligation has a referral_fee. Then in refresh_obligation
    /// each obligation is checked and the relevant referral_fee is taken from pending_referral_fees
    /// and added to accumulated_referral_fees_sf (if referrer) or accumulated_protocol_fees_sf (if no referrer)
    fn compound_interest(
        &mut self,
        current_borrow_rate: Fraction,
        host_fixed_interest_rate: Fraction,
        slots_elapsed: u64,
        protocol_take_rate: Fraction,
        referral_rate: Fraction,
    ) -> LendingResult<()> {
        // Read / convert current reserve values
        let previous_cumulative_borrow_rate = BigFraction::from(self.cumulative_borrow_rate_bsf);
        let previous_debt_f = Fraction::from_bits(self.borrowed_amount_sf);
        let acc_protocol_fees_f = Fraction::from_bits(self.accumulated_protocol_fees_sf);

        // 15% APR + 1% APR -> 16...% APY
        let compounded_interest_rate = approximate_compounded_interest(
            current_borrow_rate + host_fixed_interest_rate,
            slots_elapsed,
        );
        // 1% APR -> 1% APY
        let compounded_fixed_rate =
            approximate_compounded_interest(host_fixed_interest_rate, slots_elapsed);

        let new_cumulative_borrow_rate: BigFraction =
            previous_cumulative_borrow_rate * BigFraction::from(compounded_interest_rate);

        let new_debt_f = previous_debt_f * compounded_interest_rate;

        // Mathematical approximation, we're actually losing quite a bit in favour of the lenders
        // in the sense that we allocate part of the fixed rate growth to the lenders, rather than to the protocol.

        // Assume x = flat fee, y = variable fee, n = slots_elapsed
        // Previously, borrowers would pay the same as the lenders would receive (1 + y)^n

        // Now, borrowers pay (1 + (x+y)^n) and lenders receive (1 + (x+y))^n - (1+x)^n
        // as the extra (1+x)^n is allocated to the protocol

        // Previously we were giving to lenders (1 + y)^n
        // Now we are giving to lenders ((1 + (x+y))^n) - (1+x)^n which is more than before

        let fixed_host_fee = (previous_debt_f * compounded_fixed_rate) - previous_debt_f;
        let net_new_variable_debt_f = new_debt_f - previous_debt_f - fixed_host_fee;

        let variable_protocol_fee_f = net_new_variable_debt_f * protocol_take_rate;
        let absolute_referral_rate = protocol_take_rate * referral_rate;
        let max_referrers_fees_f = net_new_variable_debt_f * absolute_referral_rate;

        let new_acc_protocol_fees_f =
            acc_protocol_fees_f + fixed_host_fee + variable_protocol_fee_f - max_referrers_fees_f;

        // Update / convert reserve values
        self.cumulative_borrow_rate_bsf = new_cumulative_borrow_rate.into();
        self.pending_referrer_fees_sf += max_referrers_fees_f.to_bits();
        self.accumulated_protocol_fees_sf = new_acc_protocol_fees_f.to_bits();
        self.borrowed_amount_sf = new_debt_f.to_bits();
        self.absolute_referral_rate_sf = absolute_referral_rate.to_bits();

        Ok(())
    }

    /// Forgive bad debt. This essentially socializes the loss across all ctoken holders of
    /// this reserve.
    pub fn forgive_debt(&mut self, liquidity_amount: Fraction) {
        let amt = Fraction::from_bits(self.borrowed_amount_sf);
        let new_amt = amt - liquidity_amount;
        self.borrowed_amount_sf = new_amt.to_bits();
    }

    pub fn get_market_price(&self) -> Fraction {
        Fraction::from_bits(self.market_price_sf)
    }
}

/// Create a new reserve liquidity
pub struct NewReserveLiquidityParams {
    /// Reserve liquidity mint address
    pub mint_pubkey: Pubkey,
    /// Reserve liquidity mint address
    pub mint_decimals: u8,
    /// Reserve liquidity mint token program id
    pub mint_token_program: Pubkey,
    /// Reserve liquidity supply address
    pub supply_vault: Pubkey,
    /// Reserve fee collection address
    pub fee_vault: Pubkey,
    /// Reserve liquidity market price in quote currency
    pub market_price_sf: u128,
    /// Initial liquidity deposit
    pub initial_amount_deposited_in_reserve: u64,
}

/// Reserve collateral
#[derive(Debug, Default, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct ReserveCollateral {
    /// Reserve collateral mint address
    pub mint_pubkey: Pubkey,
    /// Reserve collateral mint supply, used for exchange rate
    pub mint_total_supply: u64,
    /// Reserve collateral supply address
    pub supply_vault: Pubkey,
    pub padding1: [u128; 32],
    pub padding2: [u128; 32],
}

impl ReserveCollateral {
    /// Create a new reserve collateral
    pub fn new(params: NewReserveCollateralParams) -> Self {
        let NewReserveCollateralParams {
            mint_pubkey,
            supply_vault,
            initial_collateral_supply,
        } = params;
        Self {
            mint_pubkey,
            mint_total_supply: initial_collateral_supply,
            supply_vault,
            padding1: [0; 32],
            padding2: [0; 32],
        }
    }

    /// Add collateral to total supply
    pub fn mint(&mut self, collateral_amount: u64) -> Result<()> {
        self.mint_total_supply = self
            .mint_total_supply
            .checked_add(collateral_amount)
            .ok_or(LendingError::MathOverflow)?;
        Ok(())
    }

    /// Remove collateral from total supply
    pub fn burn(&mut self, collateral_amount: u64) -> Result<()> {
        self.mint_total_supply = self
            .mint_total_supply
            .checked_sub(collateral_amount)
            .ok_or_else(|| {
                msg!(
                    "Mint total supply {} cannot be less than collateral amount {}",
                    self.mint_total_supply,
                    collateral_amount
                );
                LendingError::MathOverflow
            })?;
        Ok(())
    }

    /// Return the current collateral exchange rate.
    fn exchange_rate(&self, total_liquidity: Fraction) -> CollateralExchangeRate {
        if self.mint_total_supply == 0 || total_liquidity == Fraction::ZERO {
            INITIAL_COLLATERAL_RATE
        } else {
            CollateralExchangeRate::from_supply_and_liquidity(
                self.mint_total_supply,
                total_liquidity,
            )
        }
    }
}

/// Collateral exchange rate
#[derive(Clone, Copy, Debug)]
pub struct CollateralExchangeRate {
    collateral_supply: u128,
    liquidity: Fraction,
}

impl Default for CollateralExchangeRate {
    fn default() -> Self {
        Self::ONE
    }
}

impl CollateralExchangeRate {
    pub const ONE: Self = Self {
        collateral_supply: 1,
        liquidity: Fraction::ONE,
    };

    pub fn from_supply_and_liquidity(collateral_supply: u64, liquidity: Fraction) -> Self {
        Self {
            collateral_supply: collateral_supply.into(),
            liquidity,
        }
    }

    /// Convert reserve collateral to liquidity
    pub fn collateral_to_liquidity(&self, collateral_amount: u64) -> u64 {
        self.fraction_collateral_to_liquidity(collateral_amount.into())
            .to_floor()
    }

    /// Convert reserve collateral to minimum liquidity needed to mint that amount of collateral
    /// Used on deposit, ceil the result. DO NOT USE ON BURN
    pub fn collateral_to_liquidity_ceil(&self, collateral_amount: u64) -> u64 {
        let collateral_amount_u256 = U256::from(collateral_amount);
        let liquidity_sbf = BigFraction::from(self.liquidity).0;
        let collateral_supply_u256 = U256::from(self.collateral_supply);

        let liquidity_ceil_sbf = collateral_amount_u256
            .checked_mul(liquidity_sbf)
            .and_then(|res| res.checked_add(collateral_supply_u256 - U256::one()))
            .and_then(|res| res.checked_div(collateral_supply_u256))
            .expect("collateral_to_liquidity_ceil: liquidity_amount overflow on calculation");

        let liquidity_ceil_bf = BigFraction(liquidity_ceil_sbf);

        let liquidity_ceil_f = Fraction::try_from(liquidity_ceil_bf).expect(
            "collateral_to_liquidity_ceil: liquidity_amount overflow on fraction conversion",
        );

        liquidity_ceil_f.to_ceil()
    }

    /// Computes fractional liquidity corresponding to the given collateral.
    ///
    /// In case of infinite expansion, the least significant (binary) digit will be rounded down.
    pub fn fraction_collateral_to_liquidity(&self, collateral_amount: Fraction) -> Fraction {
        (BigFraction::from(collateral_amount) * BigFraction::from(self.liquidity)
            / self.collateral_supply)
            .try_into()
            // Should never overflow since this would mean that the liquidity result is more than
            // the maximum representable supply of the token (u64::MAX)
            .expect("fraction_collateral_to_liquidity: liquidity_amount overflow")
    }

    /// Computes fractional liquidity corresponding to the given collateral.
    ///
    /// The least significant (binary) digit will be rounded *up*, which is contrary to [Self::fraction_collateral_to_liquidity()].
    pub fn fraction_collateral_to_liquidity_ceil(&self, collateral_amount: Fraction) -> Fraction {
        self.liquidity.full_mul_int_ratio_ceil(
            collateral_amount.to_bits(),
            Fraction::from_num(self.collateral_supply).to_bits(),
        )
    }

    /// Computes fractional collateral corresponding to the given liquidity.
    ///
    /// In case of infinite expansion, the least significant (binary) digit will be rounded down.
    pub fn fraction_liquidity_to_collateral(&self, liquidity_amount: Fraction) -> Fraction {
        (BigFraction::from(liquidity_amount) * self.collateral_supply / self.liquidity)
            .try_into()
            // Should never overflow since this would mean that the collateral result is more than
            // the maximum representable supply of the token (u64::MAX)
            .expect("fraction_liquidity_to_collateral: collateral_amount overflow")
    }

    /// Computes fractional collateral corresponding to the given liquidity.
    ///
    /// In case of infinite expansion, the least significant (binary) digit will be rounded *up*,
    /// which is contrary to [Self::fraction_liquidity_to_collateral()] (and to the usual notion
    /// of numerical division).
    ///
    /// To be specific, for certain inputs:
    /// - [Self::fraction_liquidity_to_collateral()] may return `133.3333333333333`,
    /// - while [Self::fraction_liquidity_to_collateral_ceil()] `133.3333333333334`.
    ///
    /// This behavior is required when the caller intends to take the *integer* ceiling of some
    /// further computation result (e.g. when computing an amount of ctokens that should be burned
    /// for a given liquidity payout) - in rare cases, the unfortunate flooring of our
    /// finite-precision fraction could lead to incorrect final ceiled integer.
    pub fn fraction_liquidity_to_collateral_ceil(&self, liquidity_amount: Fraction) -> Fraction {
        (BigFraction::from(liquidity_amount) * self.collateral_supply)
            .div_ceil(self.liquidity)
            .try_into()
            // Should never overflow since this would mean that the collateral result is more than
            // the maximum representable supply of the token (u64::MAX)
            .expect("fraction_liquidity_to_collateral_ceil: collateral_amount overflow")
    }

    /// Convert reserve liquidity to collateral
    pub fn liquidity_to_collateral_fraction(&self, liquidity_amount: u64) -> Fraction {
        (BigFraction::from_num(self.collateral_supply * u128::from(liquidity_amount))
            / self.liquidity)
            .try_into()
            // Should never overflow since this would mean that the collateral result is more than
            // the maximum representable supply of the token (u64::MAX)
            .expect("liquidity_to_collateral_fraction: collateral_amount overflow")
    }

    /// Convert reserve liquidity to collateral
    pub fn liquidity_to_collateral(&self, liquidity_amount: u64) -> u64 {
        let collateral_f = self.liquidity_to_collateral_fraction(liquidity_amount);
        collateral_f.try_to_floor().unwrap_or_else(|| {
            // In case of overflow on solana, we can't print the value in fractional form,
            // so we print the scaled value
            #[cfg(target_os = "solana")]
            panic!(
                "liquidity_to_collateral: collateral_amount overflow, collateral_f_scaled: {}",
                collateral_f.to_bits()
            );
            #[cfg(not(target_os = "solana"))]
            panic!(
                "liquidity_to_collateral: collateral_amount overflow, collateral_f: {}",
                collateral_f
            );
        })
    }

    /// Convert reserve liquidity to collateral with rounding up
    pub fn liquidity_to_collateral_ceil(&self, liquidity_amount: u64) -> u64 {
        self.fraction_liquidity_to_collateral_ceil(Fraction::from_num(liquidity_amount))
            .to_ceil()
    }
}

/// Create a new reserve collateral
pub struct NewReserveCollateralParams {
    /// Reserve collateral mint address
    pub mint_pubkey: Pubkey,
    /// Reserve collateral supply address
    pub supply_vault: Pubkey,
    /// Initial collateral supply (non minted)
    pub initial_collateral_supply: u64,
}

static_assertions::const_assert_eq!(RESERVE_CONFIG_SIZE, std::mem::size_of::<ReserveConfig>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<ReserveConfig>() % 8);
/// Reserve configuration values
#[derive(BorshDeserialize, BorshSerialize, PartialEq, Eq, Derivative, Default)]
#[derivative(Debug)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[cfg_attr(feature = "serde", serde(deny_unknown_fields))]
#[zero_copy]
#[repr(C)]
pub struct ReserveConfig {
    /// Status of the reserve Active/Obsolete/Hidden
    #[cfg_attr(feature = "serde", serde(with = "serde_reserve_status"))]
    pub status: u8,
    /// Asset tier -> 0 - regular (collateral & debt), 1 - isolated collateral, 2 - isolated debt
    pub padding_deprecated_asset_tier: u8,
    /// Flat rate that goes to the host
    pub host_fixed_interest_rate_bps: u16,
    /// Starting bonus for deleveraging-related liquidations, in bps.
    pub min_deleveraging_bonus_bps: u16,
    /// Boolean flag to block minting/redeeming of ctokens
    /// Blocks usage of ctokens (minting or withdrawing from obligation)
    /// Effectively blocks deposit_reserve_liquidity and withdraw_obligation_collateral
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub block_ctoken_usage: u8,

    /// The percentage of remaining interest over the debt term that is charged as early repay penalty.
    /// Only meaningful when `debt_term_seconds > 0`.
    pub early_repay_remaining_interest_pct: u8,

    /// Whether the reserve is in emergency mode.
    /// Blocks most user operations involving this reserve, similar to [LendingMarket::emergency_mode]
    /// but scoped to a single reserve. Also cascades to obligations using this reserve as
    /// collateral or debt, blocking borrows and withdrawals on other reserves but still
    /// allowing repays and deposits.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub emergency_mode: u8,

    /// Past reserved space - feel free to reuse.
    #[cfg_attr(feature = "serde", serde(skip_serializing, default))]
    #[derivative(Debug = "ignore")]
    pub reserved_1: [u8; 4],

    /// Cut of the order execution bonus that the protocol receives, as a percentage
    pub protocol_order_execution_fee_pct: u8,
    /// Protocol take rate is the amount borrowed interest protocol receives, as a percentage
    pub protocol_take_rate_pct: u8,
    /// Cut of the liquidation bonus that the protocol receives, as a percentage
    pub protocol_liquidation_fee_pct: u8,
    /// Target ratio of the value of borrows to deposits, as a percentage
    /// 0 if use as collateral is disabled
    pub loan_to_value_pct: u8,
    /// Loan to value ratio at which an obligation can be liquidated, as percentage
    pub liquidation_threshold_pct: u8,
    /// Minimum bonus a liquidator receives when repaying part of an unhealthy obligation, as bps
    pub min_liquidation_bonus_bps: u16,
    /// Maximum bonus a liquidator receives when repaying part of an unhealthy obligation, as bps
    pub max_liquidation_bonus_bps: u16,
    /// Bad debt liquidation bonus for an undercollateralized obligation, as bps
    pub bad_debt_liquidation_bonus_bps: u16,
    /// Time in seconds that must pass before redemptions are enabled after the deposit limit is
    /// crossed.
    /// Only relevant when `autodeleverage_enabled == 1`, and must not be 0 in such case.
    pub deleveraging_margin_call_period_secs: u64,
    /// The rate at which the deleveraging threshold decreases, in bps per day.
    /// Only relevant when `autodeleverage_enabled == 1`, and must not be 0 in such case.
    pub deleveraging_threshold_decrease_bps_per_day: u64,
    /// Program owner fees assessed, separate from gains due to interest accrual
    pub fees: ReserveFees,
    /// Borrow rate curve based on utilization
    pub borrow_rate_curve: BorrowRateCurve,
    /// Borrow factor in percentage - used for risk adjustment
    pub borrow_factor_pct: u64,

    /// Maximum deposit limit of liquidity in native units, u64::MAX for inf
    pub deposit_limit: u64,
    /// Maximum amount borrowed, u64::MAX for inf, 0 to disable borrows (protected deposits)
    pub borrow_limit: u64,
    /// Token id from TokenInfos struct
    pub token_info: TokenInfo,

    /// Deposit withdrawal caps - deposit & redeem
    pub deposit_withdrawal_cap: WithdrawalCaps,
    /// Debt withdrawal caps - borrow & repay
    pub debt_withdrawal_cap: WithdrawalCaps,

    pub elevation_groups: [u8; 20],
    pub disable_usage_as_coll_outside_emode: u8,

    /// Utilization (in percentage) above which borrowing is blocked. 0 to disable.
    pub utilization_limit_block_borrowing_above_pct: u8,

    /// Whether this reserve should be subject to auto-deleveraging after deposit or borrow limit is
    /// crossed.
    /// Besides this flag, the lending market's flag also needs to be enabled (logical `AND`).
    /// **NOTE:** the manual "target LTV" deleveraging is NOT affected by this flag.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub autodeleverage_enabled: u8,

    /// Boolean flag indicating whether the reserve is locked for the proposer authority.
    ///
    /// Once the proposer have finished preparing the reserve, it must be locked to prevent
    /// further changes to the reserve configuration allowing review and voting on the proposal
    /// without alteration during the voting period.
    #[cfg_attr(feature = "serde", serde(with = "serde_bool_u8"))]
    pub proposer_authority_locked: u8,

    /// Maximum amount liquidity of this reserve borrowed outside all elevation groups
    /// - u64::MAX for inf
    /// - 0 to disable borrows outside elevation groups
    pub borrow_limit_outside_elevation_group: u64,

    /// Defines the maximum amount (in lamports of elevation group debt asset)
    /// that can be borrowed when this reserve is used as collateral.
    /// - u64::MAX for inf
    /// - 0 to disable borrows in this elevation group (expected value for the debt asset)
    pub borrow_limit_against_this_collateral_in_elevation_group: [u64; 32],

    /// The rate at which the deleveraging-related liquidation bonus increases, in bps per day.
    /// Only relevant when `autodeleverage_enabled == 1`, and must not be 0 in such case.
    pub deleveraging_bonus_increase_bps_per_day: u64,

    /// The timestamp at which all [Obligation::borrows] using this reserve become liquidatable
    /// (on the same terms as reserve-wide deleveraging).
    /// Inactive when zeroed (i.e. debt never matures).
    ///
    /// Note: this feature is independent of [Self::debt_term_seconds] - the liquidation mechanism
    /// is based directly on the timestamp defined here, on Reserve's level.
    pub debt_maturity_timestamp: u64,

    /// The duration after which any debt coming from this Reserve must be repaid.
    /// Inactive when zeroed (i.e. funds can be borrowed indefinitely).
    ///
    /// Note: this feature is independent of [Self::debt_maturity_timestamp] - the liquidation
    /// mechanism is based on the [ObligationLiquidity::last_borrowed_at_timestamp].
    pub debt_term_seconds: u64,

    /// Rewards distributed per slot to depositors. Drained from
    /// [ReserveLiquidity::rewards_amount_available] into
    /// [ReserveLiquidity::total_available_amount] at each refresh, capped by the
    /// market-level [LendingMarket::reserve_rewards_max_apr_bps]. `0` disables.
    ///
    /// **Note:** because rewards inflate `total_available_amount`, a non-zero RPS on a
    /// reserve with [Self::autodeleverage_enabled] and a finite [Self::deposit_limit]
    /// will eventually cross the cap and arm the autodeleverage countdown. Size
    /// `deposit_limit` and RPS together.
    pub rewards_amount_per_slot: u64,
}

impl ReserveConfig {
    /// Return the BorrowFactor of the reserve as a `Fraction`
    pub fn get_borrow_factor(&self) -> Fraction {
        max(
            Fraction::ONE,
            Fraction::from_percent(self.borrow_factor_pct),
        )
    }

    /// Returns status of the reserve Active/Obsolete/Hidden
    pub fn status(&self) -> ReserveStatus {
        ReserveStatus::try_from(self.status).unwrap()
    }

    pub fn is_autodeleverage_enabled(&self) -> bool {
        self.autodeleverage_enabled != false as u8
    }

    pub fn is_ctoken_usage_blocked(&self) -> bool {
        self.block_ctoken_usage != false as u8
    }

    pub fn is_emergency_mode(&self) -> bool {
        self.emergency_mode != false as u8
    }

    /// Returns the [Self::debt_term_seconds], if defined.
    pub fn get_debt_term_seconds(&self) -> Option<u64> {
        if self.debt_term_seconds == 0 {
            None
        } else {
            Some(self.debt_term_seconds)
        }
    }

    /// Returns the early repay penalty rate as a fraction (e.g. 50 -> 0.5).
    pub fn get_early_repay_penalty_remaining_interest_pct(&self) -> Fraction {
        Fraction::from_percent(self.early_repay_remaining_interest_pct)
    }

    /// Returns the [Self::debt_maturity_timestamp], if defined.
    pub fn get_debt_maturity_timestamp(&self) -> Option<u64> {
        if self.debt_maturity_timestamp == 0 {
            return None; // No debt maturity configured
        }
        Some(self.debt_maturity_timestamp)
    }

    /// Returns the time (in seconds) since [Self::debt_maturity_timestamp], if it is defined and if
    /// it has passed.
    ///
    /// Note: a result of `Some(0)` is valid and means "the debt maturity has just been reached" and
    /// it makes the funds borrowed from this reserve liquidatable.
    pub fn get_secs_since_debt_maturity_reached(&self, current_timestamp: u64) -> Option<u64> {
        self.get_debt_maturity_timestamp()
            .and_then(|debt_maturity_timestamp| {
                current_timestamp.checked_sub(debt_maturity_timestamp)
            })
    }

    /// Returns the maximum rate achievable on the [Self::borrow_rate_curve], in bps.
    pub fn max_borrow_rate_bps(&self) -> u32 {
        self.borrow_rate_curve
            .points
            .iter()
            .map(|point| point.borrow_rate_bps)
            .max()
            .expect("curve has a static >0 length")
    }

    /// Returns the reserve utilization at or above which borrowing is not allowed, if configured.
    pub fn max_borrowing_utilization_rate(&self) -> Option<Fraction> {
        if self.utilization_limit_block_borrowing_above_pct == 0 {
            return None; // not configured
        }
        Some(Fraction::from_percent(
            self.utilization_limit_block_borrowing_above_pct,
        ))
    }

    /// Creates a new config by customizing the given source instance.
    pub fn from_customized(
        source: &ReserveConfig,
        customizations: ReserveConfigCustomizations,
    ) -> Self {
        // Use "destruct and reconstruct", to carefully consider each field:
        let &ReserveConfig {
            status: _, // not needed - we want the new reserve to be initially hidden
            padding_deprecated_asset_tier: _, // not needed - we manually zero the padding
            host_fixed_interest_rate_bps,
            min_deleveraging_bonus_bps,
            block_ctoken_usage,
            emergency_mode,
            reserved_1: _, // not needed - we manually zero the padding
            protocol_order_execution_fee_pct,
            protocol_take_rate_pct,
            protocol_liquidation_fee_pct,
            loan_to_value_pct,
            liquidation_threshold_pct,
            min_liquidation_bonus_bps,
            max_liquidation_bonus_bps,
            bad_debt_liquidation_bonus_bps,
            deleveraging_margin_call_period_secs,
            deleveraging_threshold_decrease_bps_per_day,
            fees,
            borrow_rate_curve,
            borrow_factor_pct,
            deposit_limit: _, // not needed - we want the new reserve to be manually activated
            borrow_limit: _,  // not needed - we want the new reserve to be manually activated
            token_info,
            deposit_withdrawal_cap,
            debt_withdrawal_cap,
            elevation_groups,
            disable_usage_as_coll_outside_emode,
            utilization_limit_block_borrowing_above_pct,
            autodeleverage_enabled,
            proposer_authority_locked: _, // not needed - we want the new reserve to still be editable by the proposer
            borrow_limit_outside_elevation_group,
            borrow_limit_against_this_collateral_in_elevation_group,
            deleveraging_bonus_increase_bps_per_day,
            debt_maturity_timestamp,
            debt_term_seconds,
            early_repay_remaining_interest_pct,
            rewards_amount_per_slot: _, // not needed - new reserves start with no rewards configured
        } = source;

        // When rewriting below, we will be taking the customizations into account:
        let ReserveConfigCustomizations {
            overridden_fixed_rate_bps,
            overridden_debt_term_seconds,
            overridden_elevation_groups,
        } = customizations;

        Self {
            status: ReserveStatus::Hidden.into(), // not rewritten - we want the new reserve to be manually activated
            padding_deprecated_asset_tier: 0,     // not rewritten - we manually zero the padding
            host_fixed_interest_rate_bps,
            min_deleveraging_bonus_bps,
            block_ctoken_usage,
            emergency_mode,
            reserved_1: default_array(), // not rewritten - we manually zero the padding
            protocol_order_execution_fee_pct,
            protocol_take_rate_pct,
            protocol_liquidation_fee_pct,
            loan_to_value_pct,
            liquidation_threshold_pct,
            min_liquidation_bonus_bps,
            max_liquidation_bonus_bps,
            bad_debt_liquidation_bonus_bps,
            deleveraging_margin_call_period_secs,
            deleveraging_threshold_decrease_bps_per_day,
            fees,
            borrow_rate_curve: overridden_fixed_rate_bps
                .map(BorrowRateCurve::new_flat)
                .unwrap_or(borrow_rate_curve),
            borrow_factor_pct,
            deposit_limit: 0, // not rewritten - we want the new reserve to be manually enabled
            borrow_limit: 0,  // not rewritten - we want the new reserve to be manually enabled
            token_info,
            deposit_withdrawal_cap,
            debt_withdrawal_cap,
            elevation_groups: overridden_elevation_groups.unwrap_or(elevation_groups),
            disable_usage_as_coll_outside_emode,
            utilization_limit_block_borrowing_above_pct,
            autodeleverage_enabled,
            proposer_authority_locked: false as u8,
            borrow_limit_outside_elevation_group,
            borrow_limit_against_this_collateral_in_elevation_group,
            deleveraging_bonus_increase_bps_per_day,
            debt_maturity_timestamp, // Note: dumb rewrite (not checking e.g. whether it may have already been expired), but not harmful even if it happens (since we only clone into a reserve that is not yet used)
            debt_term_seconds: overridden_debt_term_seconds.unwrap_or(debt_term_seconds),
            early_repay_remaining_interest_pct,
            rewards_amount_per_slot: 0, // new reserves start with rewards disabled
        }
    }
}

#[repr(u8)]
#[derive(
    AnchorSerialize,
    AnchorDeserialize,
    TryFromPrimitive,
    IntoPrimitive,
    PartialEq,
    Eq,
    Debug,
    Clone,
    Copy,
)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum ReserveStatus {
    Active = 0,
    Obsolete = 1,
    Hidden = 2,
}

/// Reserve Withdrawal Caps State
#[derive(BorshDeserialize, BorshSerialize, PartialEq, Eq, Default, Debug)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
#[zero_copy]
#[repr(C)]
pub struct WithdrawalCaps {
    pub config_capacity: i64,
    #[cfg_attr(
        all(feature = "serde", not(feature = "serialize_caps_interval_values")),
        serde(skip)
    )]
    pub current_total: i64,
    #[cfg_attr(
        all(feature = "serde", not(feature = "serialize_caps_interval_values")),
        serde(skip)
    )]
    pub last_interval_start_timestamp: u64,
    pub config_interval_length_seconds: u64,
}

/// Additional fee information on a reserve
///
/// These exist separately from interest accrual fees, and are specifically for the program owner
/// and referral fee. The fees are paid out as a percentage of liquidity token amounts during
/// repayments and liquidations.
#[derive(BorshDeserialize, BorshSerialize, Default, PartialEq, Eq, Derivative)]
#[derivative(Debug)]
#[zero_copy]
#[repr(C)]
pub struct ReserveFees {
    /// Fee assessed on `BorrowObligationLiquidity`, as scaled fraction (60 bits fractional part)
    /// Must be between `0` and `2^60`, such that `2^60 = 1`.  A few examples for
    /// clarity:
    /// 1% = (1 << 60) / 100 = 11529215046068470
    /// 0.01% (1 basis point) = 115292150460685
    /// 0.00001% (Aave origination fee) = 115292150461
    pub origination_fee_sf: u64,
    /// Fee for flash loan, expressed as scaled fraction.
    /// 0.3% (Aave flash loan fee) = 0.003 * 2^60 = 3458764513820541
    pub flash_loan_fee_sf: u64,
    /// Used for allignment
    #[derivative(Debug = "ignore")]
    pub padding: [u8; 8],
}

#[cfg(feature = "serde")]
mod serde_reserve_fees {
    use std::{fmt, result::Result};

    use serde::{
        de::{self, Deserialize, Deserializer, MapAccess, SeqAccess, Visitor},
        ser::Serialize,
    };

    use super::*;

    impl<'de> Deserialize<'de> for ReserveFees {
        fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'de>,
        {
            #[derive(serde::Deserialize)]
            #[serde(field_identifier, rename_all = "snake_case")]
            enum Field {
                OriginationFee,
                FlashLoanFee,
            }

            struct ReserveFeesVisitor;
            impl<'de> Visitor<'de> for ReserveFeesVisitor {
                type Value = ReserveFees;

                fn expecting(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
                    formatter.write_str("struct ReserveFees")
                }

                fn visit_seq<V>(self, mut seq: V) -> Result<ReserveFees, V::Error>
                where
                    V: SeqAccess<'de>,
                {
                    let origination_fee_sf = seq
                        .next_element()?
                        .ok_or_else(|| serde::de::Error::invalid_length(0, &self))?;
                    let flash_loan_fee_sf = seq
                        .next_element()?
                        .ok_or_else(|| serde::de::Error::invalid_length(1, &self))?;
                    Ok(ReserveFees {
                        origination_fee_sf,
                        flash_loan_fee_sf,
                        padding: [0; 8],
                    })
                }

                fn visit_map<V>(self, mut map: V) -> Result<ReserveFees, V::Error>
                where
                    V: MapAccess<'de>,
                {
                    let mut origination_fee_f: Option<Fraction> = None;
                    let mut flash_loan_fee_f: Option<Fraction> = None;
                    while let Some(key) = map.next_key()? {
                        match key {
                            Field::OriginationFee => {
                                if origination_fee_f.is_some() {
                                    return Err(de::Error::duplicate_field("origination_fee"));
                                }
                                origination_fee_f = Some(map.next_value()?);
                            }
                            Field::FlashLoanFee => {
                                if flash_loan_fee_f.is_some() {
                                    return Err(de::Error::duplicate_field("flash_loan_fee"));
                                }

                                // if the next value is "disabled", then flash_loan_fee must be None

                                let flash_loan_fee_str: Option<String> = map.next_value()?;
                                match flash_loan_fee_str.as_deref() {
                                    Some("disabled") => {
                                        flash_loan_fee_f = None;
                                    }
                                    Some(x) => {
                                        flash_loan_fee_f =
                                            Some(Fraction::from_str(x).map_err(|_| {
                                                de::Error::custom(
                                                    "flash_loan_fee must be a fraction",
                                                )
                                            })?);
                                    }
                                    None => {
                                        return Err(de::Error::custom(
                                            "flash_loan_fee must be a fraction or 'disabled'",
                                        ));
                                    }
                                }
                            }
                        }
                    }

                    let origination_fee_f = origination_fee_f
                        .ok_or_else(|| de::Error::missing_field("origination_fee"))?;
                    let flash_loan_fee_f =
                        flash_loan_fee_f.unwrap_or(Fraction::from_bits(u64::MAX.into()));
                    Ok(ReserveFees {
                        origination_fee_sf: u64::try_from(origination_fee_f.to_bits()).map_err(
                            |_| de::Error::custom("origination_fee does not fit in u64"),
                        )?,
                        flash_loan_fee_sf: u64::try_from(flash_loan_fee_f.to_bits())
                            .map_err(|_| de::Error::custom("flash_loan_fee does not fit in u64"))?,
                        padding: [0; 8],
                    })
                }
            }

            const FIELDS: &[&str] = &["origination_fee", "flash_loan_fee"];
            deserializer.deserialize_struct("ReserveFees", FIELDS, ReserveFeesVisitor)
        }
    }

    impl Serialize for ReserveFees {
        fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
        where
            S: serde::Serializer,
        {
            #[derive(serde::Serialize)]
            struct ReserveFeesSerde {
                origination_fee: Fraction,
                flash_loan_fee: String,
            }

            let origination_fee_f = Fraction::from_bits(self.origination_fee_sf.into());

            let flash_loan_fee = if self.flash_loan_fee_sf == u64::MAX {
                "disabled".to_string()
            } else {
                Fraction::from_bits(self.flash_loan_fee_sf.into()).to_string()
            };

            let fees = ReserveFeesSerde {
                origination_fee: origination_fee_f,
                flash_loan_fee,
            };
            fees.serialize(serializer)
        }
    }
}

impl ReserveFees {
    /// Calculates the origination fee and referral fee on borrow.
    pub fn calculate_borrow_fees(
        &self,
        borrow_amount: Fraction,
        fee_calculation: FeeCalculation,
        referral_fee_bps: u16,
        has_referrer: bool,
    ) -> Result<(u64, u64)> {
        self.calculate_fees(
            borrow_amount,
            self.origination_fee_sf,
            fee_calculation,
            referral_fee_bps,
            has_referrer,
        )
    }

    /// Calculate the owner and referral fees on flash loan
    pub fn calculate_flash_loan_fees(
        &self,
        flash_loan_amount_f: Fraction,
        referral_fee_bps: u16,
        has_referrer: bool,
    ) -> Result<(u64, u64)> {
        let (protocol_fee, referral_fee) = self.calculate_fees(
            flash_loan_amount_f,
            self.flash_loan_fee_sf,
            FeeCalculation::Exclusive,
            referral_fee_bps,
            has_referrer,
        )?;

        Ok((protocol_fee, referral_fee))
    }

    /// Calculates origination fees -> protocol fee and referral fee
    /// The returned fees are additive and should both be used where relevant
    fn calculate_fees(
        &self,
        amount: Fraction,
        fee_sf: u64,
        fee_calculation: FeeCalculation,
        referral_fee_bps: u16,
        has_referrer: bool,
    ) -> Result<(u64, u64)> {
        let origination_fee_rate = Fraction::from_bits(fee_sf.into());
        let referral_fee_rate = Fraction::from_bps(referral_fee_bps);
        if origination_fee_rate > Fraction::ZERO && amount > Fraction::ZERO {
            let need_to_assess_referral_fee = referral_fee_rate > Fraction::ZERO && has_referrer;
            let minimum_fee = 1u64; // 1 token to market owner, nothing to referrer

            let origination_fee_amount = match fee_calculation {
                // Calculate fee to be added to borrow: fee = amount * rate
                FeeCalculation::Exclusive => amount.mul(origination_fee_rate),
                // Calculate fee to be subtracted from borrow: fee = amount * (rate / (rate + 1))
                FeeCalculation::Inclusive => {
                    let origination_fee_rate =
                        origination_fee_rate.div(origination_fee_rate.add(Fraction::ONE));
                    amount.mul(origination_fee_rate)
                }
            };

            let origination_fee_f = origination_fee_amount.max(minimum_fee.into());
            if origination_fee_f >= amount {
                msg!("Borrow amount is too small to receive liquidity after fees");
                return err!(LendingError::BorrowTooSmall);
            }

            let origination_fee: u64 = origination_fee_f.to_round();
            let referral_fee = if need_to_assess_referral_fee {
                // When referral_fee_bps is 10_000, we want to ensure no origination_fee is left (in some cases it would because of the rounding - using to_round for origination_fee vs to_floor for referral_fee)
                if referral_fee_bps == 10_000 {
                    origination_fee
                } else {
                    let referral_fee_f = origination_fee_f * referral_fee_rate;
                    referral_fee_f.to_floor::<u64>()
                }
            } else {
                0
            };

            let protocol_fee = origination_fee - referral_fee;

            Ok((protocol_fee, referral_fee))
        } else {
            Ok((0, 0))
        }
    }
}

#[derive(AnchorSerialize, AnchorDeserialize, Debug, PartialEq, Eq)]
/// Calculate fees exlusive or inclusive of an amount
pub enum FeeCalculation {
    /// Fee added to amount: fee = rate * amount
    Exclusive,
    /// Fee included in amount: fee = (rate / (1 + rate)) * amount
    Inclusive,
}

/// Function to calculate the interest using a compounded interest rate formula.
/// To avoid the use of the expensive "pow", the calculation is performed using a binomial
/// approximation for a great CU cost reductions.
/// The approximation slightly under-evaluate the compounded interest rate.
///
/// `(1+x)^n = 1 + nx + (n(n-1)/2!) * x^2 + (n(n-1)(n-2)/3!) * x^3 + ...`
///
/// We use the first 3 terms of the binomial series to approximate the compounded interest rate.
/// The formula above is equivalent to:
/// `(1+x)^n = 1 + nx + nx * (n-1)*x/2 + nx * (n-1)*x/2 * (n-2)*x/3 + ...`
/// and if we denote the first 3 terms by `first_term`, `second_term` and `third_term`, we have:
/// `first_term = nx`
/// `second_term = first_term * (n-1) * x / 2`
/// `third_term = second_term * (n-2) * x / 3`
///
/// # Arguments
///
/// * `rate` - The interest rate per year
/// * `elapsed_slots` - The number of slots elapsed since the last update
///
/// # Returns
///
/// The interest rate compounded during the time_delta
pub fn approximate_compounded_interest(rate: Fraction, elapsed_slots: u64) -> Fraction {
    let base = rate / u128::from(SLOTS_PER_YEAR); // slot rate = x

    match elapsed_slots {
        0 => return Fraction::ONE,
        1 => return Fraction::ONE + base,
        2 => return (Fraction::ONE + base) * (Fraction::ONE + base),
        3 => return (Fraction::ONE + base) * (Fraction::ONE + base) * (Fraction::ONE + base),
        4 => {
            let pow_two = (Fraction::ONE + base) * (Fraction::ONE + base);
            return pow_two * pow_two;
        }
        _ => (), // continue with the approximation
    }

    let exp: u128 = elapsed_slots.into();
    // Use wrapping sub to remove all bound check since we know that exp > 3
    let exp_minus_one = exp.wrapping_sub(1);
    let exp_minus_two = exp.wrapping_sub(2);

    let first_term = base * exp;

    let second_term = (first_term * base * exp_minus_one) / 2;

    let third_term = (second_term * base * exp_minus_two) / 3;

    Fraction::ONE + first_term + second_term + third_term
}

/// A set of "customizations" available to [ReserveConfig::from_customized()].
pub struct ReserveConfigCustomizations {
    /// The fixed rate to override the [ReserveConfig::borrow_rate_curve] with, in bps.
    pub overridden_fixed_rate_bps: Option<u32>,

    /// The overridden [ReserveConfig::debt_term_seconds].
    pub overridden_debt_term_seconds: Option<u64>,

    /// The overridden [ReserveConfig::elevation_groups].
    pub overridden_elevation_groups: Option<[u8; 20]>,
}

#[cfg(feature = "program-test")]
mod program_test_impls {
    use super::*;

    impl PartialEq for CollateralExchangeRate {
        fn eq(&self, other: &Self) -> bool {
            Fraction::from(*self) == Fraction::from(*other)
        }
    }

    impl Eq for CollateralExchangeRate {}

    impl From<CollateralExchangeRate> for Fraction {
        fn from(exchange_rate: CollateralExchangeRate) -> Self {
            Fraction::from_num(exchange_rate.collateral_supply) / exchange_rate.liquidity
        }
    }
}

use std::{
    fmt::Display,
    ops::{Range, RangeInclusive},
};

use anchor_lang::{err, Result};
use fixed::prelude::ToFixed;
use num_enum::{IntoPrimitive, TryFromPrimitive};
use solana_program::msg;

use crate::{
    fraction,
    fraction::FractionExtra,
    utils::{accounts::is_default_array, Fraction},
    xmsg, LendingError, LendingMarket, Obligation, ObligationOrder, Reserve,
};

/// A sane range of "debt/coll price ratio" threshold.
const VALID_DEBT_COLL_PRICE_RATIO_RANGE: RangeInclusive<Fraction> =
    fraction!(0.000000000000001)..=fraction!(1000000000000000);

/// A sane range of "user LTV" threshold.
/// Note: technically, LTV of 0% or 100% is valid - however, it does not make sense as a threshold
/// (since such condition is e.g. always met). We prefer to restrict them, mostly to catch invalid
/// zeroed configuration.
const VALID_USER_LTV_RANGE: Range<Fraction> = fraction!(0.01)..fraction!(1.0);

/// A sane range of "difference to liquidation LTV".
const VALID_DIFF_TO_LIQUIDATION_LTV_RANGE: Range<Fraction> = VALID_USER_LTV_RANGE;

/// Sanity limit for order execution bonus.
const EXECUTION_BONUS_SANITY_LIMIT: Fraction = fraction!(0.1); // assuming no one picks >10% on purpose

/// A type discriminator for a condition (under which an obligation order is applicable).
#[repr(u8)]
#[derive(PartialEq, Eq, Debug, Clone, Copy, TryFromPrimitive, IntoPrimitive)]
pub enum ConditionType {
    /// Never hit.
    ///
    /// Note: an entire order must be zeroed - this is equivalent to a null order (i.e. empty slot).
    Never = 0,

    /// Hit when the `obligation_user_ltv > condition_threshold`.
    UserLtvAbove = 1,

    /// Hit when the `obligation_user_ltv < condition_threshold`.
    UserLtvBelow = 2,

    /// Hit when the `debt_token_oracle_price / collateral_token_price > condition_threshold`.
    ///
    /// Note: the Obligation must be single-debt-single-coll.
    DebtCollPriceRatioAbove = 3,

    /// Hit when the `debt_token_oracle_price / collateral_token_price < condition_threshold`.
    ///
    /// Note: the Obligation must be single-debt-single-coll.
    DebtCollPriceRatioBelow = 4,

    /// Always hit.
    ///
    /// Notes: the `condition_threshold` must be zeroed; the configured execution bonus must be
    /// constant; the reported distance from threshold will always be 0.
    Always = 5,

    /// Hit when the `obligation_liquidation_ltv - obligation_user_ltv < condition_threshold`.
    ///
    /// Note: this is conceptually a [Self::UserLtvAbove], with a threshold defined "dynamically" as
    /// `obligation_liquidation_ltv - condition_threshold`.
    ///
    /// Example:
    /// If an Obligation is supposed to be liquidated at LTV = 81%, then an ObligationOrder with
    /// `LiquidationLtvCloserThan(condition_threshold = 0.06)` will be executable when LTV > 75%.
    LiquidationLtvCloserThan = 6,
}

/// A type discriminator for an opportunity (available to liquidators when an obligation order is
/// applicable).
#[repr(u8)]
#[derive(PartialEq, Eq, Debug, Clone, Copy, TryFromPrimitive, IntoPrimitive)]
pub enum OpportunityType {
    /// The `opportunity_parameter` specifies the amount of the debt token (in lamports) that can be
    /// repaid by the order executor.
    ///
    /// Note: the Obligation must be single-debt.
    DeleverageSingleDebtAmount = 0,

    /// The entire debt can be repaid by the order executor.
    ///
    /// Note: the `opportunity_parameter` must be `Fraction::MAX`.
    DeleverageAllDebt = 1,
}

/// An obligation's applicable order (its index and its [ConditionHit]).
pub type ApplicableObligationOrder = (usize, ConditionHit);

/// Numeric details on why an order's condition was met.
#[derive(PartialEq, Eq, Debug)]
pub struct ConditionHit {
    /// The distance between the current value (e.g. "current LTV") and the condition's
    /// threshold (e.g. "when LTV > 70%"), normalized with regard to the most extreme value
    /// (e.g. "liquidation LTV = 90%").
    ///
    /// Following the above example:
    /// - when current LTV = 70% (i.e. at condition threshold), this normalized distance is `0`,
    /// - when current LTV = 90% (i.e. at liquidation point), this normalized distance is `1`,
    /// - when current LTV = 82% (i.e. some number in-between), this normalized distance is `0.6`.
    ///
    /// In other words: this is a `[0; 1]` measure of how hard the condition threshold is crossed.
    ///
    /// May be `None` if a particular condition type does not meaningfully define "threshold" (e.g.
    /// a [ConditionType::Always] is always met, regardless of any "current value" or "extreme
    /// value").
    pub normalized_distance_from_threshold: Option<Fraction>,
}

// Note: Display impl only needed because calling Debug on Fraction results in a corrupted ELF.
impl Display for ConditionHit {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match &self.normalized_distance_from_threshold {
            None => f.write_str("<undefined distance from threshold>"),
            Some(normalized_distance_from_threshold) => write!(
                f,
                "distance from threshold = {}",
                normalized_distance_from_threshold
            ),
        }
    }
}

/// Returns the given obligation's [ApplicableObligationOrder], if any.
///
/// An "applicable" order is the first one (based on [Obligation::obligation_orders] index) which
/// has its condition met. Note: if some latter order also has a met condition, it will be ignored.
pub fn find_applicable_obligation_order(
    collateral_reserve: &Reserve,
    debt_reserve: &Reserve,
    obligation: &Obligation,
    price_triggered_liquidation_disabled: bool,
) -> Option<ApplicableObligationOrder> {
    for (order_index, order) in obligation.obligation_orders.iter().enumerate() {
        if let Some(condition_hit) =
            evaluate_order_condition(collateral_reserve, debt_reserve, obligation, order)
        {
            if order.condition_type().is_price_triggered() && price_triggered_liquidation_disabled {
                xmsg!(
                    "Obligation's order {}. condition {} is hit with {}, but price-triggered liquidations are disabled",
                    order_index,
                    order.condition_to_display(),
                    condition_hit
                );
                continue;
            }
            return Some((order_index, condition_hit));
        }
    }
    None
}

/// Checks whether the implied "user operation" modifying the given obligation has rendered any of
/// its current orders no-longer-well-defined.
///
/// Some orders are only well-defined for a single debt and/or a single collateral, or may have
/// other constraints regarding the obligation (see [ObligationOrder::is_supported_by()]).
/// When an obligation has such an order, we block any user operation which would e.g. add another
/// debt to the obligation - we require that the user removes the conflicting order first.
pub fn check_orders_supported_after_user_operation(obligation: &mut Obligation) -> Result<()> {
    let has_unsupported_orders = obligation
        .obligation_orders
        .iter()
        .any(|order| !order.is_supported_by(obligation));
    if has_unsupported_orders {
        // iterate again, to only collect them into a vec here, after we know we need to log them:
        let unsupported_orders = obligation
            .obligation_orders
            .iter()
            .filter(|order| !order.is_supported_by(obligation))
            .collect::<Vec<_>>();
        msg!(
            "The obligation has orders which have to be cancelled before the operation: {:?}",
            unsupported_orders
        );
        return err!(LendingError::OperationNotPermittedWithCurrentObligationOrders);
    }
    Ok(())
}

/// Removes all [Obligation::obligation_orders] from the given obligation and returns whether there
/// actually were any.
///
/// This happens when a liquidation (regardless if regular one or order execution) has left the
/// obligation without any debt.
pub fn remove_all_orders(obligation: &mut Obligation) -> bool {
    let mut had_orders = false;
    for order in obligation.obligation_orders.iter_mut() {
        // Technically, we could just memset unconditionally, but we also want to return whether there were any orders:
        if order != &ObligationOrder::default() {
            *order = ObligationOrder::default();
            had_orders = true;
        }
    }
    had_orders
}

/// Sets the new state of the obligation's order at the given index, if the obligation's state
/// allows that.
/// Assumes that the given order is valid.
pub fn set_order_on_obligation(
    lending_market: &LendingMarket,
    obligation: &mut Obligation,
    index: u8,
    order: ObligationOrder,
) -> Result<()> {
    validate_order(order)?;
    if !order.is_supported_by(obligation) {
        msg!("Order {:?} not supported by obligation", order);
        return err!(LendingError::OrderConfigurationNotSupportedByObligation);
    }

    let index = usize::from(index);
    if index >= obligation.obligation_orders.len() {
        msg!(
            "Obligation may have at most {} orders; got index {}",
            obligation.obligation_orders.len(),
            index
        );
        return err!(LendingError::OrderIndexOutOfBounds);
    }

    let previous_order = &mut obligation.obligation_orders[index];
    if !previous_order.is_active()
        && order.is_active()
        && !lending_market.is_obligation_order_creation_enabled()
    {
        msg!("Creation of new obligation orders is disabled by the market's configuration");
        return err!(LendingError::OrderCreationDisabled);
    }

    msg!(
        "Setting obligation order[{}]; previous: {:?}; new: {:?}",
        index,
        previous_order,
        order
    );
    *previous_order = order;

    Ok(())
}

// ONLY INTERNALS BELOW

impl ConditionType {
    pub fn is_supported_by(&self, obligation: &Obligation) -> bool {
        match self {
            Self::Never => true,                             // null order always allowed
            Self::UserLtvAbove | Self::UserLtvBelow => true, // user LTV can be calculated for any obligation
            Self::DebtCollPriceRatioAbove | Self::DebtCollPriceRatioBelow => {
                obligation.is_single_debt_single_coll() // price ratio calculation assumes exactly 1 collateral and exactly 1 debt
            }
            Self::Always => true, // not dependent on obligation at all
            Self::LiquidationLtvCloserThan => true, // user LTV and liquidation LTV can be calculated for any obligation
        }
    }

    /// Whether this condition depends on price movements.
    ///
    /// An execution of such order is *disabled* when the
    /// [LendingMarket::price_triggered_liquidation_disabled] is set.
    pub fn is_price_triggered(&self) -> bool {
        match self {
            ConditionType::Never | ConditionType::Always => false,
            ConditionType::UserLtvAbove
            | ConditionType::UserLtvBelow
            | ConditionType::DebtCollPriceRatioAbove
            | ConditionType::DebtCollPriceRatioBelow
            | ConditionType::LiquidationLtvCloserThan => true,
        }
    }
}

impl OpportunityType {
    pub fn is_supported_by(&self, obligation: &Obligation) -> bool {
        match self {
            Self::DeleverageSingleDebtAmount => obligation.single_debt().is_some(), // the specified "amount" needs a context of exactly 1 debt
            Self::DeleverageAllDebt => true, // can always just "repay all"
        }
    }
}

fn validate_order(order: ObligationOrder) -> Result<()> {
    match ConditionType::try_from(order.condition_type) {
        Ok(ConditionType::DebtCollPriceRatioAbove | ConditionType::DebtCollPriceRatioBelow) => {
            if !VALID_DEBT_COLL_PRICE_RATIO_RANGE.contains(&order.condition_threshold()) {
                msg!(
                    "Invalid price ratio threshold {}; should be in range [{}; {}]",
                    order.condition_threshold().to_display(),
                    VALID_DEBT_COLL_PRICE_RATIO_RANGE.start().to_display(),
                    VALID_DEBT_COLL_PRICE_RATIO_RANGE.end().to_display(),
                );
                return err!(LendingError::InvalidOrderConfiguration);
            }
        }
        Ok(ConditionType::UserLtvAbove | ConditionType::UserLtvBelow) => {
            if !VALID_USER_LTV_RANGE.contains(&order.condition_threshold()) {
                msg!(
                    "Invalid LTV threshold {}; should be in range [{}; {})",
                    order.condition_threshold().to_display(),
                    VALID_USER_LTV_RANGE.start.to_display(),
                    VALID_USER_LTV_RANGE.end.to_display(),
                );
                return err!(LendingError::InvalidOrderConfiguration);
            }
        }
        Ok(ConditionType::Always) => {
            if order.condition_threshold() != Fraction::default() {
                msg!(
                    "An unconditional order should use zeroed condition threshold; got {}",
                    order.condition_threshold().to_display()
                );
                return err!(LendingError::InvalidOrderConfiguration);
            }
            let bonus_range = order.execution_bonus_rate_range();
            if bonus_range.start() != bonus_range.end() {
                msg!(
                    "An unconditional order should define a constant bonus; got range [{}; {}]",
                    bonus_range.start().to_display(),
                    bonus_range.end().to_display(),
                );
                return err!(LendingError::InvalidOrderConfiguration);
            }
        }
        Ok(ConditionType::Never) => {
            if order != ObligationOrder::default() {
                msg!("A void order should be entirely zeroed; got {:?}", order);
                return err!(LendingError::InvalidOrderConfiguration);
            }
            // NOTE: early exit - no other checks on the order are needed when it gets zeroed:
            return Ok(());
        }
        Ok(ConditionType::LiquidationLtvCloserThan) => {
            if !VALID_DIFF_TO_LIQUIDATION_LTV_RANGE.contains(&order.condition_threshold()) {
                msg!(
                    "Invalid difference to liquidation LTV {}; should be in range [{}; {})",
                    order.condition_threshold().to_display(),
                    VALID_USER_LTV_RANGE.start.to_display(),
                    VALID_USER_LTV_RANGE.end.to_display(),
                );
                return err!(LendingError::InvalidOrderConfiguration);
            }
        }
        Err(error) => {
            msg!(
                "Invalid order condition type {}: {:?}",
                order.condition_type,
                error
            );
            return err!(LendingError::InvalidOrderConfiguration);
        }
    }
    match OpportunityType::try_from(order.opportunity_type) {
        Ok(OpportunityType::DeleverageSingleDebtAmount) => {
            if order.opportunity_parameter().is_zero() {
                msg!("Single debt deleveraging opportunity amount cannot be 0");
                return err!(LendingError::InvalidOrderConfiguration);
            }
            if order.opportunity_parameter() == Fraction::MAX {
                msg!("Single debt deleveraging opportunity amount must be finite (use DeleverageAllDebt for repaying all debt)");
                return err!(LendingError::InvalidOrderConfiguration);
            }
        }
        Ok(OpportunityType::DeleverageAllDebt) => {
            if order.opportunity_parameter() != Fraction::MAX {
                msg!("Deleveraging all debt opportunity must allow repaying the entire amount (Fraction::MAX)");
                return err!(LendingError::InvalidOrderConfiguration);
            }
        }
        Err(error) => {
            msg!(
                "Invalid order opportunity type {}: {:?}",
                order.opportunity_type,
                error
            );
            return err!(LendingError::InvalidOrderConfiguration);
        }
    }
    let execution_bonus_rate_range = order.execution_bonus_rate_range();
    if execution_bonus_rate_range.start() > execution_bonus_rate_range.end() {
        msg!(
            "Minimum execution bonus {} higher than maximum {}",
            execution_bonus_rate_range.start().to_display(),
            execution_bonus_rate_range.end().to_display(),
        );
        return err!(LendingError::InvalidOrderConfiguration);
    }
    if execution_bonus_rate_range.end() > &EXECUTION_BONUS_SANITY_LIMIT {
        msg!(
            "Maximum execution bonus {} higher than sanity limit {}",
            execution_bonus_rate_range.end().to_display(),
            EXECUTION_BONUS_SANITY_LIMIT.to_display()
        );
        return err!(LendingError::InvalidOrderConfiguration);
    }
    if !is_default_array(&order.padding1) || !is_default_array(&order.padding2) {
        msg!("Padding fields must be zeroed");
        return err!(LendingError::InvalidOrderConfiguration);
    }
    Ok(())
}

fn evaluate_order_condition(
    collateral_reserve: &Reserve,
    debt_reserve: &Reserve,
    obligation: &Obligation,
    order: &ObligationOrder,
) -> Option<ConditionHit> {
    match order.condition_type() {
        ConditionType::Always => Some(ConditionHit::without_distance()), // always hit, and the `normalized_distance_from_threshold` is irrelevant in this case
        ConditionType::Never => None, // this one is never hit; the remaining ones fall into one of 2 categories:
        ConditionType::UserLtvAbove => evaluate_stop_loss(
            obligation.loan_to_value(),
            order.condition_threshold(),
            obligation.unhealthy_loan_to_value(),
        ),
        ConditionType::UserLtvBelow => {
            evaluate_take_profit(obligation.loan_to_value(), order.condition_threshold())
        }
        ConditionType::DebtCollPriceRatioAbove => {
            let price_ratio = calculate_price_ratio(debt_reserve, collateral_reserve);
            evaluate_stop_loss(
                price_ratio,
                order.condition_threshold(),
                // For single-debt-single-coll obligations, the price ratio is directly proportional
                // to LTV - so we can calculate the "liquidation price ratio" simply by scaling the
                // current value by the ratio of unhealthy/current LTV:
                price_ratio * obligation.unhealthy_loan_to_value() / obligation.loan_to_value(),
            )
        }
        ConditionType::DebtCollPriceRatioBelow => evaluate_take_profit(
            calculate_price_ratio(debt_reserve, collateral_reserve),
            order.condition_threshold(),
        ),
        ConditionType::LiquidationLtvCloserThan => {
            let unhealthy_ltv = obligation.unhealthy_loan_to_value();
            evaluate_stop_loss(
                obligation.loan_to_value(),
                unhealthy_ltv.saturating_sub(order.condition_threshold()),
                unhealthy_ltv,
            )
        }
    }
}

fn evaluate_stop_loss(
    current_value: Fraction,
    condition_threshold: Fraction,
    liquidation_threshold: Fraction,
) -> Option<ConditionHit> {
    if current_value <= condition_threshold {
        return None; // SL not hit
    }
    let normalized_distance_towards_liquidation = if condition_threshold >= liquidation_threshold {
        // A theoretically-impossible case (the user may of course set his order's condition
        // threshold that high, but then the current value is above liquidation threshold, so
        // liquidation logic should kick in and never reach this function). Anyway, let's
        // interpret it as maximum distance from threshold:
        Fraction::ONE
    } else {
        // By now we know they are both > 0:
        let current_distance = current_value - condition_threshold;
        let maximum_distance = liquidation_threshold - condition_threshold;
        current_distance / maximum_distance
    };
    Some(ConditionHit::with_distance(
        normalized_distance_towards_liquidation,
    ))
}

fn evaluate_take_profit(
    current_value: Fraction,
    condition_threshold: Fraction,
) -> Option<ConditionHit> {
    if current_value >= condition_threshold {
        return None; // TP not hit
    }
    let distance_towards_0 = condition_threshold - current_value; // by now we know it is > 0
    Some(ConditionHit::with_distance(
        distance_towards_0 / condition_threshold,
    ))
}

fn calculate_price_ratio(numerator_reserve: &Reserve, denominator_reserve: &Reserve) -> Fraction {
    let numerator_price = numerator_reserve.liquidity.get_market_price();
    let denominator_price = denominator_reserve.liquidity.get_market_price();
    numerator_price / denominator_price
}

impl ConditionHit {
    /// Creates an instance for condition types that have well-defined "distance from threshold".
    pub fn with_distance(normalized_distance_from_threshold: impl ToFixed) -> Self {
        Self {
            normalized_distance_from_threshold: Some(Fraction::from_num(
                normalized_distance_from_threshold,
            )),
        }
    }

    /// Creates an instance for condition types that do not have any notion of "distance from
    /// threshold".
    pub fn without_distance() -> Self {
        Self {
            normalized_distance_from_threshold: None,
        }
    }
}

use crate::{
    utils::Fraction, LendingMarket, Obligation, ObligationLiquidity, PriceStatusFlags, Reserve,
};

/// Deposit liquidity result
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DepositLiquidityResult {
    /// Amount of liquidity to actually deposit from user wallet
    pub liquidity_amount: u64,
    /// Amount of collateral to mint
    pub collateral_amount: u64,
}

/// An input amount for borrow calculation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BorrowSize {
    /// Borrow an amount needed to receive exactly the given amount of liquidity, in lamports.
    ///
    /// The actually borrowed amount will be greater than this number, since the fees are added.
    Exact(u64),

    /// As much as possible without exceeding any configured limit or the obligation's maximum LTV
    /// (after fees).
    AllAvailable,

    /// Similar to [Self::AllAvailable], but up to the given limit on the received liquidity amount.
    AtMost(u64),
}

impl BorrowSize {
    /// Creates a [Self::Exact] or [Self::AllAvailable], according to our conventional meaning of
    /// [u64::MAX].
    pub fn exact_or_all_available(liquidity_amount: u64) -> BorrowSize {
        if liquidity_amount == u64::MAX {
            BorrowSize::AllAvailable
        } else {
            BorrowSize::Exact(liquidity_amount)
        }
    }

    /// Returns true if this size would not allow any borrow.
    pub fn is_zero(&self) -> bool {
        match self {
            BorrowSize::Exact(amount_lte) | BorrowSize::AtMost(amount_lte) => *amount_lte == 0,
            BorrowSize::AllAvailable => false,
        }
    }
}

/// Calculate borrow result
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CalculateBorrowResult {
    /// Total amount of borrow including fees
    pub borrow_amount_f: Fraction,
    /// Borrow amount portion of total amount
    pub receive_amount: u64,
    /// Loan origination fee
    pub origination_fee: u64,
    /// Host fee portion of origination fee
    pub referrer_fee: u64,
}

/// Calculate repay result
#[derive(Debug)]
pub struct CalculateRepayResult {
    /// Amount of liquidity that is settled from the obligation.
    pub settle_amount: Fraction,
    /// Amount that will be repaid as u64
    pub repay_amount: u64,
}

/// Rollover (or migration) result for the "different reserve" case.
///
/// Note: it looks specific to the "different reserve" rollover case, and that's no accident - the
/// "same reserve" case does not require any transfers (only happens in accounting).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FixedTermRolloverResult {
    /// The amount of debt (from the source reserve) that got rolled over.
    ///
    /// This field only reports the performed accounting update, to be used by post-checks.
    pub repaid_amount: Fraction,

    /// The amount that had to be borrowed (from the target reserve) in order to roll over.
    ///
    /// This value cannot be simply equal to [Self::repaid_amount]: for full rollover, it needs to
    /// be rounded up to the nearest lamport, since fractional liquidity cannot be withdrawn from
    /// a reserve. The type here is [Fraction] only for convenient interaction with borrow-related
    /// calculations.
    ///
    /// This field only reports the performed accounting update, to be used by post-checks.
    pub borrowed_amount: Fraction,

    /// The actual tokens to be transferred from target reserve to source reserve.
    pub tokens_to_transfer_over: u64,
}

/// Calculate liquidation result
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CalculateLiquidationResult {
    /// Amount of liquidity that is settled from the obligation. It includes
    /// the amount of loan that was defaulted if collateral is depleted.
    pub settle_amount: Fraction,
    /// Amount that will be repaid as u64
    pub repay_amount: u64,
    /// Amount of collateral to withdraw in exchange for repay amount
    pub withdraw_amount: u64,
    /// Final bonus of the reserve
    pub liquidation_bonus_rate: Fraction,
    /// The reason for liquidation.
    /// Note: the obligation may be subject to liquidation for multiple simultaneous reasons, and
    /// the one returned here is selected based on priority.
    pub liquidation_reason: LiquidationReason,
}

/// A reason for liquidation.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LiquidationReason {
    /// The obligation's user LTV has exceeded its maximum allowed LTV.
    /// Can be *disabled* only by [LendingMarket::price_triggered_liquidation_disabled] (together
    /// with other price-triggered liquidations).
    LtvExceeded,
    /// The obligation is marked for target-LTV deleveraging.
    /// Can be enabled by [LendingMarket::autodeleverage_enabled].
    IndividualDeleveraging,
    /// A deposit/borrow limit of some reserve (used by the obligation) is exceeded.
    /// Can be enabled by [LendingMarket::autodeleverage_enabled].
    MarketWideDeleveraging,
    /// The obligation owner has added some orders, and one of them (indicated by the given index)
    /// has a satisfied condition.
    /// Can be enabled by [LendingMarket::obligation_order_execution_enabled].
    /// For *some* price-dependent order conditions, this liquidation flavor can be *disabled* by
    /// [LendingMarket::price_triggered_liquidation_disabled] (together with other price-triggered
    /// liquidations).
    ObligationOrder(usize),
    /// A debt maturity timestamp of some reserve (used by the obligation) has been reached.
    /// Can be enabled by [LendingMarket::mature_reserve_debt_liquidation_enabled].
    ReserveDebtMaturityReached,
    /// A reserve's debt term has been reached for the obligation's borrow (and it happened the
    /// given number of seconds ago).
    /// Can be enabled by [LendingMarket::obligation_borrow_debt_term_liquidation_enabled].
    ObligationBorrowDebtTermReached(u64),
}

/// Calculate liquidation result
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LiquidateObligationResult {
    /// Amount of liquidity that is settled from the obligation. It includes
    /// the amount of loan that was defaulted if collateral is depleted.
    pub settle_amount: Fraction,
    /// Amount that will be repaid as u64
    pub repay_amount: u64,
    /// Amount of collateral to withdraw in exchange for repay amount
    pub withdraw_amount: u64,
    /// Amount of collateral to redeem in exchange for liquidity amount
    pub withdraw_collateral_amount: u64,
    /// Final bonus of the reserve
    pub liquidation_bonus_rate: Fraction,
    /// The reason for liquidation.
    /// Note: the obligation may be subject to liquidation for multiple simultaneous reasons, and
    /// the one returned here is selected based on priority.
    pub liquidation_reason: LiquidationReason,
}

/// Liquidate and redeem result
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LiquidateAndRedeemResult {
    /// Amount that will be repaid as u64
    pub repay_amount: u64,
    /// Amount of collateral to withdraw in exchange for repay amount
    pub withdraw_amount: u64,
    /// Amount of collateral to redeem in exchange for liquidity amount
    pub withdraw_collateral_amount: u64,
    /// Total withdraw liquidity amount + protocol fee
    pub total_withdraw_liquidity_amount: Option<(u64, u64)>,
    /// The reason for liquidation, as selected by [get_liquidation_params] priority order.
    pub liquidation_reason: LiquidationReason,
}

pub struct LiquidationCheckInputs<'l> {
    pub lending_market: &'l LendingMarket,
    pub collateral_reserve: &'l Reserve,
    pub liquidity: &'l ObligationLiquidity,
    pub debt_reserve: &'l Reserve,
    pub obligation: &'l Obligation,
    pub timestamp: u64,
    pub max_allowed_ltv_override_pct_opt: Option<u64>,
}

#[cfg_attr(feature = "program-test", derive(Debug))]
pub struct LiquidationParams {
    pub liquidation_bonus_rate: Fraction,
    pub liquidation_reason: LiquidationReason,
}

pub struct RefreshObligationDepositsResult {
    pub lowest_deposit_liquidation_ltv_threshold_pct: u8,
    pub lowest_deposit_max_ltv_pct: u8,
    pub num_of_obsolete_reserves: u8,
    pub deposited_value_f: Fraction,
    pub allowed_borrow_value_f: Fraction,
    pub unhealthy_borrow_value_f: Fraction,
    /// Represent the worst case flag status combined from all reserves used by the obligation
    pub prices_state: PriceStatusFlags,
    pub borrowing_disabled: bool,
}

pub struct RefreshObligationBorrowsResult {
    pub borrow_factor_adjusted_debt_value_f: Fraction,
    pub borrowed_assets_market_value_f: Fraction,
    pub prices_state: PriceStatusFlags,
    pub highest_borrow_factor_pct: u64,
    /// Number of lamports of the borrowed asset if there is only one
    /// (Used for elevation group debt limits)
    pub borrowed_amount_in_elevation_group: Option<u64>,
    pub num_of_obsolete_reserves: u8,
}

pub struct RedeemCollateralOptions {
    /// Whether to update (and then check!) the reserve's withdrawal caps after redeeming.
    pub add_amount_to_withdrawal_caps: bool,

    /// Whether the operation may use the entire available liquidity, including the funds reserved
    /// for satisfying the tickets of the withdraw queue.
    pub use_withdraw_queue: bool,
}

impl RedeemCollateralOptions {
    /// The options for regular use-cases.
    ///
    /// Note: this is not a usual "zeroed" / [Default] instance - it has deliberate settings to be
    /// used for regular redeems. That is why it avoids the "default" (in its name or in a trait).
    pub const REGULAR: Self = Self {
        add_amount_to_withdrawal_caps: true,
        use_withdraw_queue: false,
    };

    /// The options for withdrawing queued liquidity.
    pub const FOR_WITHDRAW_QUEUED_LIQUIDITY: Self = Self {
        add_amount_to_withdrawal_caps: true,
        use_withdraw_queue: true,
    };

    /// The options for redeeming collateral after protocol-enforced liquidation (i.e. based on
    /// unhealthy LTV or deleveraging or exceeded debt term/maturity).
    pub const FOR_PROTOCOL_ENFORCED_LIQUIDATION: Self = Self {
        add_amount_to_withdrawal_caps: false,
        use_withdraw_queue: true,
    };

    /// The options for redeeming collateral after user-requested liquidation (i.e. execution of
    /// obligation orders).
    pub const FOR_USER_REQUESTED_LIQUIDATION: Self = Self {
        add_amount_to_withdrawal_caps: true,
        use_withdraw_queue: false,
    };

    pub fn resolve(liquidation_reason: LiquidationReason) -> Self {
        match liquidation_reason {
            LiquidationReason::LtvExceeded
            | LiquidationReason::IndividualDeleveraging
            | LiquidationReason::MarketWideDeleveraging
            | LiquidationReason::ReserveDebtMaturityReached
            | LiquidationReason::ObligationBorrowDebtTermReached(_) => {
                Self::FOR_PROTOCOL_ENFORCED_LIQUIDATION
            }
            LiquidationReason::ObligationOrder(_) => Self::FOR_USER_REQUESTED_LIQUIDATION,
        }
    }
}

pub struct TicketedWithdrawResult {
    /// Collateral to be burned from the ticket.
    pub collateral_amount_to_burn: u64,

    /// Liquidity to be transferred in exchange.
    pub liquidity_amount_to_withdraw: u64,
}

pub enum LendingAction {
    Additive(u64),
    Subtractive(u64),
}

impl LendingAction {
    pub fn subtractive_signed(net_subtracted: i64) -> Self {
        if net_subtracted >= 0 {
            Self::Subtractive(net_subtracted as u64) // safe to just cast after the `if` above
        } else {
            Self::Additive(net_subtracted.unsigned_abs())
        }
    }
}

#[derive(PartialEq)]
pub enum MaxReservesAsCollateralCheck {
    Perform,
    Skip,
}

#[derive(Copy, Clone, PartialEq, Eq)]
pub enum LtvMaxWithdrawalCheck {
    /// Withdraw up to max ltv
    MaxLtv,
    /// Withdraw up to liquidation threshold
    LiquidationThreshold,
}

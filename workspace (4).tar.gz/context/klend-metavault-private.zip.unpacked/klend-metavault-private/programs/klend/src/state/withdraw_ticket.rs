use anchor_lang::prelude::*;
use derivative::Derivative;
use num_enum::{IntoPrimitive, TryFromPrimitive};
use solana_program::pubkey::Pubkey;

use crate::utils::{CORRESPONDING_KAMINO_VAULT_PROGRAM_ID, WITHDRAW_TICKET_SIZE};

static_assertions::const_assert_eq!(WITHDRAW_TICKET_SIZE, std::mem::size_of::<WithdrawTicket>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<WithdrawTicket>() % 8);

/// A finite-lifecycle account representing a specific depositor's place in the withdraw queue of
/// a specific reserve.
///
/// The lifecycle:
/// 1. The depositor holding ctokens wants to withdraw funds from the reserve, and finds out that
///    the required amount is not available (due to high utilization).
/// 2. The depositor calls the `enqueue_to_withdraw` handler.
/// 3. The handler transfers the depositor's ctokens to the reserve's internal "pending" vault.
/// 4. The handler initializes a new [WithdrawTicket] account, with the next available sequence
///    number.
/// 5. The depositor waits until his ticket is the next expected one for actual withdraw, and until
///    the reserve has enough liquidity.
/// 6. Anyone (the depositor or a bot) calls the permissionless `withdraw_queued_liquidity`
///    handler. If the ticket became invalid (e.g. destination account no longer exists), then the
///    depositor can call the `recover_invalid_ticket_collateral` handler instead.
/// 7. The handler transfers the liquidity amount according to the current exchange rate.
/// 8. The handler closes the ticket account.
#[derive(PartialEq, Derivative)]
#[derivative(Debug)]
#[account(zero_copy)]
#[repr(C)]
pub struct WithdrawTicket {
    /// This ticket's place in the queue; the same as used for PDA derivation.
    pub sequence_number: u64,

    /// The funds' owner (the user who called the `enqueue_to_withdraw` handler).
    pub owner: Pubkey,

    /// The reserve to withdraw from.
    pub reserve: Pubkey,

    /// The token account to which the finally-available liquidity should be transferred (by the
    /// `withdraw_queued_liquidity` handler).
    pub user_destination_liquidity_ta: Pubkey,

    /// The amount of collateral still waiting to be withdrawn using this ticket.
    pub queued_collateral_amount: u64,

    /// The timestamp at which the queue was entered.
    ///
    /// This is currently only a piece of metadata, not used by the logic.
    pub created_at_timestamp: u64,

    /// Whether the ticket has been found to be invalid (e.g. the [Self::user_destination_liquidity]
    /// has been repurposed) by the `withdraw_queued_liquidity` handler.
    /// To be specific: valid = `0`, invalid = `1`.
    ///
    /// An invalid ticket cannot be made valid again, and can only be passed to the
    /// `recover_invalid_ticket_collateral` handler.
    pub invalid: u8,

    /// One of the valid [ProgressCallbackType] representations.
    pub progress_callback_type: u8,

    /// Inner padding, for alignment.
    #[derivative(Debug = "ignore")]
    pub alignment_padding: [u8; 6],

    /// The (optional) accounts to be used by [Self::progress_callback_type]s.
    pub progress_callback_custom_accounts: [Pubkey; 2],

    /// Trailing padding, for future developments.
    #[derivative(Debug = "ignore")]
    pub end_padding: [u64; 40],
}

/// A callback to be notified when the ticket is being processed.
///
/// ## Why an enum?
///
/// Only reliable programs may be used for callbacks (since any error or panic returned from a CPI
/// aborts an entire transaction, which would stall the queue progress). Hence, we need a whitelist,
/// and the simplest initial implementation is a hardcoded enum. If we want to be able to add new
/// whitelist items without SC updates, we can implement such support using a special enum value
/// (e.g. `SPECIFIED_BY_PDA = 255`).
#[repr(u8)]
#[derive(
    PartialEq,
    Eq,
    Debug,
    Clone,
    Copy,
    AnchorSerialize,
    AnchorDeserialize,
    TryFromPrimitive,
    IntoPrimitive,
)]
pub enum ProgressCallbackType {
    /// Do not notify any callback.
    None = 0,

    /// CPI into the Kvault's `UpdateKlendQueueAccounting` handler.
    ///
    /// The passed instruction data will be:
    /// - the handler's discriminator (required by the Anchor's routing),
    /// - the [WithdrawTicketProgressEvent] representation (`u8`),
    /// - the *event-specific data* (see the particular event's enum rustdoc for details).
    KlendQueueAccountingHandlerOnKvault = 1,
}

impl ProgressCallbackType {
    /// The target program to be called-back.
    pub fn program_address(&self) -> Pubkey {
        match self {
            ProgressCallbackType::None => Pubkey::default(),
            ProgressCallbackType::KlendQueueAccountingHandlerOnKvault => {
                CORRESPONDING_KAMINO_VAULT_PROGRAM_ID
            }
        }
    }
}

#[repr(u8)]
#[derive(
    PartialEq,
    Eq,
    Debug,
    Clone,
    Copy,
    AnchorSerialize,
    AnchorDeserialize,
    TryFromPrimitive,
    IntoPrimitive,
)]
pub enum WithdrawTicketProgressEvent {
    /// Some amount of queued collateral was burnt from the ticket (possibly: all of it), in an
    /// exchange for some amount of liquidity transferred to the ticket's destination account.
    ///
    /// The *event-specific data* will be:
    /// - consecutive serialized fields of the [crate::state::types::TicketedWithdrawResult] struct.
    ///
    /// The passed accounts will be:
    /// - the withdraw ticket (readonly, signer),
    /// - its associated reserve (readonly),
    /// - its associated lending market (readonly),
    /// - its queued collateral vault TA (readonly, meant for potential balance verifications),
    /// - its liquidity destination TA (readonly, meant for potential balance verifications),
    /// - the Kvault's `VaultState` which disinvested from the reserve, configured in the
    ///   [WithdrawTicket::progress_callback_custom_accounts]`[0]` (writable).
    QueuedLiquidityWithdrawn = 0,
}

impl WithdrawTicket {
    /// The typed [Self::progress_callback_type] field.
    pub fn progress_callback_type(&self) -> ProgressCallbackType {
        ProgressCallbackType::try_from_primitive(self.progress_callback_type)
            .expect("validated when configuring the callback")
    }

    /// Returns `true` if the ticket is still considered valid (see [Self::invalid]).
    pub fn is_valid(&self) -> bool {
        self.invalid == false as u8
    }

    /// Returns `true` if the ticket is fully cancelled.
    pub fn is_fully_cancelled(&self) -> bool {
        self.queued_collateral_amount == 0
    }
}

//! These states add logic to be able to store ReferrerState as well as a ShortUrl. This basically keeps track of users who became referrers and their unique link that will allow
//!
//! This design allows us to have a unique ShortUrl per referrer:
//! - If they want to close it, they can
//! - If they want to change it, we can use delete + create to update the short_url
//! - Everyone can create the accounts and they just pay the rent, which they get back when they close the account.
//! - While the account is active, the link works as we find the account on-chain and get the referrer. Once it's deleted it will no longer work because it won't be present on-chain anymore, until it's created again. Being a PDA derived from the short_url, we know it's also unique
//! Note1: We are not affected by people creating referrer accounts anyway as it's all on-chain and it will cost us nothing.
//! Note2: due to the short_url being used as a seed for the PDA, it can have a maximum length of 32 characters (32 bytes)
//!
//! The ReferrerTokenState keeps track of all the states of rewards for a specific referrer and mint. This allows us to have multiple accounts per referrer, one per reserve.
//! These accounts get updated with fees acummulated from all people referred, when they borrow or when they have borrow interest compounded from their borrows
//!
//! The UserMetadata keeps track of who the referrer is for each individual user
//! - pubkey::default() -> no referrer
//! - != pubkey::default() -> the referrer
//! The UserMetadata is initialized the first time a new user (wallet) interacts with the protocol by creating an obligation
//! Any time that user will use the protocol, he would still have the referrer in the UserMetadata account

use std::fmt::{self, Display, Formatter};

use anchor_lang::prelude::*;
use derivative::Derivative;
use solana_program::pubkey::Pubkey;

use crate::utils::{Fraction, REFERRER_STATE_SIZE, REFERRER_TOKEN_STATE_SIZE, USER_METADATA_SIZE};

static_assertions::const_assert_eq!(
    REFERRER_TOKEN_STATE_SIZE,
    std::mem::size_of::<ReferrerTokenState>()
);
static_assertions::const_assert_eq!(0, std::mem::size_of::<ReferrerTokenState>() % 8);
/// Referrer account -> each owner can have multiple accounts for specific reserves
#[derive(PartialEq, Derivative, Default)]
#[derivative(Debug)]
#[account(zero_copy)]
#[repr(C)]
pub struct ReferrerTokenState {
    /// Pubkey of the referrer/owner
    pub referrer: Pubkey,
    /// Token mint for the account
    pub mint: Pubkey,
    /// Amount that has been accumulated and not claimed yet -> available to claim (scaled fraction)
    pub amount_unclaimed_sf: u128,
    /// Amount that has been accumulated in total -> both already claimed and unclaimed (scaled fraction)
    pub amount_cumulative_sf: u128,
    /// Referrer token state bump, used for address validation
    pub bump: u64,

    #[derivative(Debug = "ignore")]
    pub padding: [u64; 31],
}

impl Display for ReferrerTokenState {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        let Self {
            referrer,
            mint,
            amount_unclaimed_sf,
            amount_cumulative_sf,
            bump: _,
            padding: _,
        } = self;
        let amount_unclaimed = Fraction::from_bits(*amount_unclaimed_sf).saturating_to_num::<u64>();
        let amount_cumulative =
            Fraction::from_bits(*amount_cumulative_sf).saturating_to_num::<u64>();
        write!(
            f,
            "Referrer Account: referrer: {}, mint: {}, amount_unclaimed (integer part): {}, amount_cumulative (integer part): {}",
            referrer, mint, amount_unclaimed, amount_cumulative
        )?;

        Ok(())
    }
}

static_assertions::const_assert_eq!(USER_METADATA_SIZE, std::mem::size_of::<UserMetadata>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<UserMetadata>() % 8);
/// Referrer account -> each owner can have multiple accounts for specific reserves
#[derive(PartialEq, Derivative)]
#[derivative(Debug)]
#[account(zero_copy)]
#[repr(C)]
pub struct UserMetadata {
    /// Pubkey of the referrer/owner - pubkey::default if no referrer
    pub referrer: Pubkey,
    /// Bump used for validation of account address
    pub bump: u64,
    /// User lookup table - used to store all user accounts - atas for each reserve mint, each obligation PDA, UserMetadata itself and all referrer_token_states if there is a referrer
    pub user_lookup_table: Pubkey,
    /// User metadata account owner
    pub owner: Pubkey,

    #[derivative(Debug = "ignore")]
    pub padding_1: [u64; 51],
    #[derivative(Debug = "ignore")]
    pub padding_2: [u64; 64],
}

impl Default for UserMetadata {
    fn default() -> Self {
        Self {
            referrer: Pubkey::default(),
            bump: 0,
            user_lookup_table: Pubkey::default(),
            owner: Pubkey::default(),
            padding_1: [0; 51],
            padding_2: [0; 64],
        }
    }
}

static_assertions::const_assert_eq!(REFERRER_STATE_SIZE, std::mem::size_of::<ReferrerState>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<ReferrerState>() % 8);
#[derive(PartialEq, Derivative)]
#[derivative(Debug)]
#[account(zero_copy)]
#[repr(C)]
pub struct ReferrerState {
    pub short_url: Pubkey,
    pub owner: Pubkey,
}

#[derive(PartialEq, Debug)]
#[account()]
pub struct ShortUrl {
    pub referrer: Pubkey,
    pub short_url: String,
}

use std::{
    cmp::Ordering,
    fmt::{self, Display, Formatter},
    ops::RangeInclusive,
};

use anchor_lang::{account, err, prelude::*, solana_program::clock::Slot, Result};
use borsh::{BorshDeserialize, BorshSerialize};
use derivative::Derivative;
use num_enum::{IntoPrimitive, TryFromPrimitive};
#[cfg(feature = "serde")]
use strum::EnumIter;
use strum::EnumString;

use crate::{
    obligation_order_operations::{ConditionType, OpportunityType},
    state::{LastUpdate, LtvMaxWithdrawalCheck, Reserve},
    utils::{
        accounts::default_array, secs, BigFraction, Fraction, FractionExtra, IterExt,
        ELEVATION_GROUP_NONE, OBLIGATION_SIZE, U256,
    },
    xmsg, BigFractionBytes, LendingError, ReserveConfig,
};

/// State of ownership transfer for an obligation
#[derive(Clone, Copy, Debug, PartialEq, Eq, IntoPrimitive, TryFromPrimitive)]
#[repr(u8)]
pub enum OwnershipTransferState {
    /// No ownership transfer in progress
    None = 0,
    /// Ownership transfer has been initiated by the current owner
    Initiated = 1,
    /// Ownership transfer has been approved by the global admin
    Approved = 2,
}

static_assertions::const_assert_eq!(OBLIGATION_SIZE, std::mem::size_of::<Obligation>());
static_assertions::const_assert_eq!(0, std::mem::size_of::<Obligation>() % 8);
/// Lending market obligation state
#[derive(PartialEq, Derivative)]
#[derivative(Debug)]
#[account(zero_copy)]
#[repr(C)]
pub struct Obligation {
    /// Version of the struct
    pub tag: u64,
    /// Last update to collateral, liquidity, or their market values
    pub last_update: LastUpdate,
    /// Lending market address
    pub lending_market: Pubkey,
    /// Owner authority which can borrow liquidity
    pub owner: Pubkey,
    /// Deposited collateral for the obligation, unique by deposit reserve address
    pub deposits: [ObligationCollateral; 8],
    /// Worst LTV for the collaterals backing the loan, represented as a percentage
    pub lowest_reserve_deposit_liquidation_ltv: u64,
    /// Market value of deposits (scaled fraction)
    pub deposited_value_sf: u128,

    /// Borrowed liquidity for the obligation, unique by borrow reserve address
    pub borrows: [ObligationLiquidity; 5],
    /// Risk adjusted market value of borrows/debt (sum of price * borrowed_amount * borrow_factor) (scaled fraction)
    pub borrow_factor_adjusted_debt_value_sf: u128,
    /// Market value of borrows - used for max_liquidatable_borrowed_amount (scaled fraction)
    pub borrowed_assets_market_value_sf: u128,
    /// The maximum borrow value at the weighted average loan to value ratio (scaled fraction)
    pub allowed_borrow_value_sf: u128,
    /// The dangerous borrow value at the weighted average liquidation threshold (scaled fraction)
    pub unhealthy_borrow_value_sf: u128,

    /// The asset tier of the deposits
    pub padding_deprecated_asset_tiers: [u8; 13],

    /// The elevation group id the obligation opted into.
    pub elevation_group: u8,

    /// The number of obsolete reserves the obligation has a deposit in
    pub num_of_obsolete_deposit_reserves: u8,

    /// Marked = 1 if borrows array is not empty, 0 = borrows empty
    pub has_debt: u8,

    /// Wallet address of the referrer
    pub referrer: Pubkey,

    /// Marked = 1 if borrowing disabled, 0 = borrowing enabled
    pub borrowing_disabled: u8,

    /// A target LTV set by the market owner when marking this obligation for deleveraging.
    /// Only effective when `deleveraging_margin_call_started_slot != 0`.
    pub autodeleverage_target_ltv_pct: u8,

    /// The lowest max LTV found amongst the collateral deposits
    pub lowest_reserve_deposit_max_ltv_pct: u8,

    /// The number of obsolete reserves the obligation has a borrow in
    pub num_of_obsolete_borrow_reserves: u8,

    /// State of ownership transfer, see [OwnershipTransferState]
    pub ownership_transfer_state: u8,

    #[derivative(Debug = "ignore")]
    pub reserved: [u8; 3],

    pub highest_borrow_factor_pct: u64,

    /// A timestamp at which the market owner most-recently marked this obligation for deleveraging.
    /// Zero if not currently subject to deleveraging.
    pub autodeleverage_margin_call_started_timestamp: u64,

    /// Owner-defined, permissionlessly-executed repay orders.
    /// Typical use-cases would be a stop-loss and a take-profit (possibly co-existing).
    pub obligation_orders: [ObligationOrder; 2],

    /// Owner-defined, permissionlessly-executed borrow order applicable to this obligation.
    /// Non-zeroed only on a newly-initialized fixed-rate, fixed-term obligation.
    pub borrow_order: BorrowOrder,

    /// Pending owner during ownership transfer process.
    /// Pubkey::default() means no pending owner (similar to Option::None)
    pub pending_owner: Pubkey,

    #[derivative(Debug = "ignore")]
    pub padding_3: [u64; 69],
}

impl Default for Obligation {
    fn default() -> Self {
        Self {
            tag: 0,
            last_update: LastUpdate::default(),
            lending_market: Pubkey::default(),
            owner: Pubkey::default(),
            deposits: default_array(),
            borrows: default_array(),
            deposited_value_sf: 0,
            borrowed_assets_market_value_sf: 0,
            allowed_borrow_value_sf: 0,
            unhealthy_borrow_value_sf: 0,
            padding_deprecated_asset_tiers: default_array(),
            lowest_reserve_deposit_liquidation_ltv: 0,
            borrow_factor_adjusted_debt_value_sf: 0,
            elevation_group: ELEVATION_GROUP_NONE,
            num_of_obsolete_deposit_reserves: 0,
            num_of_obsolete_borrow_reserves: 0,
            has_debt: 0,
            borrowing_disabled: 0,
            highest_borrow_factor_pct: 0,
            lowest_reserve_deposit_max_ltv_pct: 0,
            reserved: default_array(),
            padding_3: default_array(),
            referrer: Pubkey::default(),
            autodeleverage_target_ltv_pct: 0,
            autodeleverage_margin_call_started_timestamp: 0,
            obligation_orders: default_array(),
            borrow_order: Default::default(),
            pending_owner: Pubkey::default(),
            ownership_transfer_state: OwnershipTransferState::None.into(),
        }
    }
}

impl Display for Obligation {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "Obligation summary, collateral value ${}, liquidity risk adjusted value ${}, liquidity risk unadjusted value ${} ltv {}%",
            Fraction::from_bits(self.deposited_value_sf).to_display(),
            Fraction::from_bits(self.borrow_factor_adjusted_debt_value_sf).to_display(),
            Fraction::from_bits(self.borrowed_assets_market_value_sf).to_display(),
            if self.deposited_value_sf > 0 {self.loan_to_value().to_percent().unwrap_or(u16::MAX)} else { 0 },
        )?;

        for collateral in self.active_deposits() {
            write!(
                f,
                "\n  Collateral reserve: {}, value: ${}, lamports: {}",
                collateral.deposit_reserve,
                Fraction::from_bits(collateral.market_value_sf).to_display(),
                collateral.deposited_amount,
            )?;
        }

        for liquidity in self.active_borrows() {
            write!(
                f,
                "\n  Borrowed reserve  : {}, value: ${}, lamports: {}",
                liquidity.borrow_reserve,
                liquidity.market_value().to_display(),
                liquidity
                    .borrowed_amount()
                    .checked_to_num()
                    .unwrap_or(u128::MAX),
            )?;
        }

        Ok(())
    }
}

/// Possible success results of an `Obligation::withdraw` call
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum WithdrawResult {
    /// The collateral was fully withdrawn
    Full,
    /// The collateral was partially withdrawn
    Partial,
}

impl Obligation {
    pub const LEN: usize = 1784;

    /// Initialize an obligation
    pub fn init(&mut self, params: InitObligationParams) {
        *self = Self::default();
        self.tag = params.tag;
        self.last_update = LastUpdate::new(params.current_slot);
        self.lending_market = params.lending_market;
        self.owner = params.owner;
        self.deposits = params.deposits;
        self.borrows = params.borrows;
        self.referrer = params.referrer;
    }

    /// Calculate the current ratio of borrowed value to deposited value
    pub fn loan_to_value(&self) -> Fraction {
        Fraction::from_bits(self.borrow_factor_adjusted_debt_value_sf)
            / Fraction::from_bits(self.deposited_value_sf)
    }

    pub fn no_bf_loan_to_value(&self) -> Fraction {
        Fraction::from_bits(self.borrowed_assets_market_value_sf)
            / Fraction::from_bits(self.deposited_value_sf)
    }

    /// Calculate the maximum ratio of borrowed value to deposited value at which point the loan will be considered unhealthy and eligible for liquidation
    pub fn unhealthy_loan_to_value(&self) -> Fraction {
        Fraction::from_bits(self.unhealthy_borrow_value_sf)
            / Fraction::from_bits(self.deposited_value_sf)
    }

    /// Repay liquidity and remove it from borrows if zeroed out
    pub fn repay(&mut self, settle_amount: Fraction, liquidity_index: usize) {
        let liquidity = &mut self.borrows[liquidity_index];
        if settle_amount == liquidity.borrowed_amount() {
            self.borrows[liquidity_index] = ObligationLiquidity::default();
        } else {
            liquidity.repay(settle_amount);
        }
    }

    /// Withdraw collateral and remove it from deposits if zeroed out
    /// Returns `WithdrawResult::Full` if the collateral was fully withdrawn
    /// Returns `WithdrawResult::Partial` if the collateral was partially withdrawn
    pub fn withdraw(
        &mut self,
        withdraw_amount: u64,
        collateral_index: usize,
    ) -> Result<WithdrawResult> {
        let collateral = &mut self.deposits[collateral_index];
        if withdraw_amount == collateral.deposited_amount {
            self.deposits[collateral_index] = ObligationCollateral::default();
            Ok(WithdrawResult::Full)
        } else {
            collateral.withdraw(withdraw_amount)?;
            Ok(WithdrawResult::Partial)
        }
    }

    /// Calculate the maximum collateral value that can be withdrawn
    pub fn max_withdraw_value(
        &self,
        obligation_collateral: &ObligationCollateral,
        reserve_max_ltv_pct: u8,
        reserve_liq_threshold_pct: u8,
        ltv_max_withdrawal_check: LtvMaxWithdrawalCheck,
    ) -> Fraction {
        let (highest_allowed_borrow_value, withdraw_collateral_ltv_pct) =
            if ltv_max_withdrawal_check == LtvMaxWithdrawalCheck::LiquidationThreshold {
                (
                    Fraction::from_bits(self.unhealthy_borrow_value_sf.saturating_sub(1)),
                    reserve_liq_threshold_pct,
                )
            } else {
                (
                    Fraction::from_bits(self.allowed_borrow_value_sf),
                    reserve_max_ltv_pct,
                )
            };

        let borrow_factor_adjusted_debt_value =
            Fraction::from_bits(self.borrow_factor_adjusted_debt_value_sf);

        if highest_allowed_borrow_value <= borrow_factor_adjusted_debt_value {
            return Fraction::ZERO;
        }

        // Max ltv of the reserve is 0, then the deposited amount from this reserve does not back any debt.
        if withdraw_collateral_ltv_pct == 0 {
            return Fraction::from_bits(obligation_collateral.market_value_sf);
        }

        highest_allowed_borrow_value.saturating_sub(borrow_factor_adjusted_debt_value) * 100_u128
            / u128::from(withdraw_collateral_ltv_pct)
    }

    /// Calculate the maximum liquidity value that can be borrowed
    pub fn remaining_borrow_value(&self) -> Fraction {
        // Saturating sub as the borrow value can already be higher than the
        // allowed borrow value (accrued interest, parameter change...)
        Fraction::from_bits(
            self.allowed_borrow_value_sf
                .saturating_sub(self.borrow_factor_adjusted_debt_value_sf),
        )
    }

    /// Find collateral by deposit reserve
    pub fn find_collateral_in_deposits(
        &self,
        deposit_reserve: Pubkey,
    ) -> Result<&ObligationCollateral> {
        if self.is_active_deposits_empty() {
            xmsg!("Obligation has no deposits");
            return err!(LendingError::ObligationDepositsEmpty);
        }
        let collateral = self
            .deposits
            .iter()
            .find(|collateral| collateral.deposit_reserve == deposit_reserve)
            .ok_or(LendingError::InvalidObligationCollateral)?;
        Ok(collateral)
    }

    /// Find or add collateral by deposit reserve
    /// Returns the ObligationCollateral and whether it had to be added.
    pub fn find_or_add_collateral_to_deposits(
        &mut self,
        deposit_reserve: Pubkey,
    ) -> Result<(&mut ObligationCollateral, bool)> {
        if let Some(collateral_index) = self
            .deposits
            .iter_mut()
            .position(|collateral| collateral.deposit_reserve == deposit_reserve)
        {
            Ok((&mut self.deposits[collateral_index], false))
        } else if let Some(collateral_index) = self.deposits.iter().position(|c| !c.is_active()) {
            let collateral = &mut self.deposits[collateral_index];
            *collateral = ObligationCollateral::new(deposit_reserve);
            Ok((collateral, true))
        } else {
            xmsg!("Obligation has no empty deposits");
            err!(LendingError::ObligationReserveLimit)
        }
    }

    pub fn position_of_collateral_in_deposits(&self, deposit_reserve: Pubkey) -> Result<usize> {
        if self.is_active_deposits_empty() {
            xmsg!("Obligation has no deposits");
            return err!(LendingError::ObligationDepositsEmpty);
        }
        self.deposits
            .iter()
            .position(|collateral| collateral.deposit_reserve == deposit_reserve)
            .ok_or(error!(LendingError::InvalidObligationCollateral))
    }

    /// Find liquidity by borrow reserve
    pub fn find_liquidity_in_borrows(
        &self,
        borrow_reserve: Pubkey,
    ) -> Result<(&ObligationLiquidity, usize)> {
        if self.is_active_borrows_empty() {
            xmsg!("Obligation has no borrows");
            return err!(LendingError::ObligationBorrowsEmpty);
        }
        let liquidity_index = self
            .find_liquidity_index_in_borrows(borrow_reserve)
            .ok_or_else(|| error!(LendingError::InvalidObligationLiquidity))?;
        Ok((&self.borrows[liquidity_index], liquidity_index))
    }

    /// Find liquidity by borrow reserve mut
    pub fn find_liquidity_in_borrows_mut(
        &mut self,
        borrow_reserve: Pubkey,
    ) -> Result<(&mut ObligationLiquidity, usize)> {
        if self.is_active_borrows_empty() {
            xmsg!("Obligation has no borrows");
            return err!(LendingError::ObligationBorrowsEmpty);
        }
        let liquidity_index = self
            .find_liquidity_index_in_borrows(borrow_reserve)
            .ok_or_else(|| error!(LendingError::InvalidObligationLiquidity))?;
        Ok((&mut self.borrows[liquidity_index], liquidity_index))
    }

    /// Find or add liquidity by borrow reserve
    /// Returns the index and the liquidity
    pub fn find_or_add_liquidity_to_borrows(
        &mut self,
        borrow_reserve: Pubkey,
        cumulative_borrow_rate: BigFraction,
    ) -> Result<(&mut ObligationLiquidity, usize)> {
        if let Some(liquidity_index) = self.find_liquidity_index_in_borrows(borrow_reserve) {
            Ok((&mut self.borrows[liquidity_index], liquidity_index))
        } else if let Some((index, liquidity)) = self
            .borrows
            .iter_mut()
            .enumerate()
            .find(|c| !c.1.is_active())
        {
            *liquidity = ObligationLiquidity::new(borrow_reserve, cumulative_borrow_rate);

            Ok((liquidity, index))
        } else {
            xmsg!("Obligation has no empty borrows");
            err!(LendingError::ObligationReserveLimit)
        }
    }

    pub fn find_liquidity_index_in_borrows(&self, borrow_reserve: Pubkey) -> Option<usize> {
        self.borrows
            .iter()
            .position(|liquidity| liquidity.borrow_reserve == borrow_reserve)
    }

    pub fn is_active_deposits_empty(&self) -> bool {
        // Note: technically, this could be `self.active_deposits().next().is_none()`, but the rust
        // compiler is known to optimize `.all(...)` better:
        self.deposits.iter().all(|deposit| !deposit.is_active())
    }

    pub fn is_active_borrows_empty(&self) -> bool {
        // Note: technically, this could be `self.active_borrows().next().is_none()`, but the rust
        // compiler is known to optimize `.all(...)` better:
        self.borrows.iter().all(|borrow| !borrow.is_active())
    }

    pub fn active_deposits_count(&self) -> usize {
        self.active_deposits().count()
    }

    pub fn active_borrows_count(&self) -> usize {
        self.active_borrows().count()
    }

    pub fn active_deposits(&self) -> impl Iterator<Item = &ObligationCollateral> {
        self.deposits.iter().filter(|c| c.is_active())
    }

    pub fn active_borrows(&self) -> impl Iterator<Item = &ObligationLiquidity> {
        self.borrows.iter().filter(|c| c.is_active())
    }

    pub fn active_deposits_mut(&mut self) -> impl Iterator<Item = &mut ObligationCollateral> {
        self.deposits.iter_mut().filter(|c| c.is_active())
    }

    pub fn active_borrows_mut(&mut self) -> impl Iterator<Item = &mut ObligationLiquidity> {
        self.borrows.iter_mut().filter(|c| c.is_active())
    }

    /// Mutably gets an [ObligationLiquidity] at `self.borrows[index]`, checking that it is active.
    pub fn get_active_borrow_mut(&mut self, index: usize) -> Result<&mut ObligationLiquidity> {
        let Some(borrow) = self.borrows.get_mut(index) else {
            xmsg!("Invalid obligation borrow index: {}", index);
            return err!(LendingError::InvalidObligationLiquidity);
        };
        if !borrow.is_active() {
            xmsg!("Obligation borrow slot {} not active", index);
            return err!(LendingError::InvalidObligationLiquidity);
        }
        Ok(borrow)
    }

    /// Get the total borrowed amount in the obligation if there is only one token borrowed
    /// Value is rounded up to an integer number of lamports
    ///
    /// ## Returns
    ///
    /// - Returns None if there are multiple tokens borrowed
    /// - Returns Some(amount) if there is only one token borrowed
    pub fn get_borrowed_amount_if_single_token(&self) -> Option<u64> {
        if self.active_borrows_count() > 1 {
            None
        } else {
            Some(
                Fraction::from_bits(self.borrows.iter().map(|l| l.borrowed_amount_sf).sum())
                    .to_ceil::<u64>(),
            )
        }
    }

    pub fn get_bf_adjusted_debt_value(&self) -> Fraction {
        Fraction::from_bits(self.borrow_factor_adjusted_debt_value_sf)
    }

    pub fn get_allowed_borrow_value(&self) -> Fraction {
        Fraction::from_bits(self.allowed_borrow_value_sf)
    }

    pub fn get_unhealthy_borrow_value(&self) -> Fraction {
        Fraction::from_bits(self.unhealthy_borrow_value_sf)
    }

    /// Market value of borrows - used for `max_liquidatable_borrowed_amount()`.
    pub fn get_borrowed_assets_market_value(&self) -> Fraction {
        Fraction::from_bits(self.borrowed_assets_market_value_sf)
    }

    pub fn has_referrer(&self) -> bool {
        self.referrer != Pubkey::default()
    }

    pub fn update_has_debt(&mut self) {
        self.has_debt = u8::from(!self.is_active_borrows_empty());
    }

    /// Returns the (cached) `has_debt` field, as bool.
    ///
    /// Note: this does _not_ inspect the `borrows` array, and instead relies on proper refreshes of
    /// the field (see [Self::update_has_debt()]).
    pub fn has_debt(&self) -> bool {
        self.has_debt == true as u8
    }

    pub fn is_marked_for_deleveraging(&self) -> bool {
        self.autodeleverage_margin_call_started_timestamp != 0
    }

    pub fn mark_for_deleveraging(&mut self, current_timestamp: u64, target_ltv_pct: u8) {
        if current_timestamp == 0 {
            panic!("value reserved for non-marked state");
        }
        self.autodeleverage_margin_call_started_timestamp = current_timestamp;
        self.autodeleverage_target_ltv_pct = target_ltv_pct;
    }

    pub fn unmark_for_deleveraging(&mut self) {
        self.autodeleverage_margin_call_started_timestamp = 0;
        self.autodeleverage_target_ltv_pct = 0;
    }

    pub fn check_not_marked_for_deleveraging(&self) -> Result<()> {
        if self.is_marked_for_deleveraging() {
            xmsg!(
                "Obligation marked for deleveraging since {}",
                self.autodeleverage_margin_call_started_timestamp
            );
            return err!(LendingError::ObligationCurrentlyMarkedForDeleveraging);
        }
        Ok(())
    }

    pub fn has_obsolete_reserves(&self) -> bool {
        self.num_of_obsolete_borrow_reserves > 0 || self.num_of_obsolete_deposit_reserves > 0
    }

    /// Returns the only debt of this obligation, if it is of a "single debt" type (which may enable
    /// certain features, e.g. more available types of obligation orders).
    ///
    /// Please note that this means *exactly* 1 debt (i.e. an obligation without debt is *not*
    /// considered to be "single debt").
    pub fn single_debt(&self) -> Option<&ObligationLiquidity> {
        self.active_borrows().only_element()
    }

    /// Returns the only collateral of this obligation, if it is of a "single collateral" type
    /// (which may enable certain features, e.g. more available types of obligation orders).
    ///
    /// Please note that this means *exactly* 1 collateral (i.e. an obligation without collateral is
    /// *not* considered to be "single collateral").
    pub fn single_collateral(&self) -> Option<&ObligationCollateral> {
        self.active_deposits().only_element()
    }

    /// Returns true if this obligation is of a "single debt, single coll" type (which may enable
    /// certain features, e.g. more available types of obligation orders).
    ///
    /// Please note that this means *exactly* 1 debt and *exactly* 1 collateral (i.e. an obligation
    /// without debt is *not* considered to be "single debt, single coll").
    pub fn is_single_debt_single_coll(&self) -> bool {
        self.active_deposits_count() == 1 && self.active_borrows_count() == 1
    }

    /// Deserialized ownership_transfer_state field
    pub fn ownership_transfer_state(&self) -> OwnershipTransferState {
        OwnershipTransferState::try_from(self.ownership_transfer_state)
            .expect("Invalid serialized ownership transfer state")
    }

    /// Returns true if ownership transfer is in progress
    pub fn is_ownership_transfer_in_progress(&self) -> bool {
        self.ownership_transfer_state() != OwnershipTransferState::None
    }

    pub fn check_ownership_transfer_not_in_progress(&self) -> Result<()> {
        if self.is_ownership_transfer_in_progress() {
            xmsg!("Obligation ownership transfer in progress");
            return err!(LendingError::ObligationOwnershipTransferInProgress);
        }
        Ok(())
    }

    /// Returns true if ownership transfer is in initiated state
    pub fn is_ownership_transfer_in_initiated_state(&self) -> bool {
        self.ownership_transfer_state() == OwnershipTransferState::Initiated
    }

    /// Returns true if ownership transfer is in approved state
    pub fn is_ownership_transfer_approved(&self) -> bool {
        self.ownership_transfer_state() == OwnershipTransferState::Approved
    }

    pub fn check_ownership_transfer_in_initiated_state(&self) -> Result<()> {
        if !self.is_ownership_transfer_in_initiated_state() {
            xmsg!("Obligation ownership transfer not in initiated state");
            return err!(LendingError::ObligationOwnershipTransferNotInInitiatedState);
        }
        Ok(())
    }

    pub fn check_ownership_transfer_approved(&self) -> Result<()> {
        if !self.is_ownership_transfer_approved() {
            xmsg!("Obligation ownership transfer not approved");
            return err!(LendingError::ObligationOwnershipTransferNotApproved);
        }
        Ok(())
    }

    /// Initiates ownership transfer (sets the flag and pending owner)
    /// This function assumes that a check that the ownership transfer is NOT in progress has already
    /// been performed in the handler
    pub fn initiate_ownership_transfer(&mut self, pending_owner: Pubkey) -> Result<()> {
        // Validate pending_owner is not the default pubkey
        if pending_owner == Pubkey::default() {
            xmsg!("Pending owner cannot be the default pubkey");
            return err!(LendingError::ObligationInvalidPendingOwner);
        }

        // Validate pending_owner is not the current owner
        if pending_owner == self.owner {
            xmsg!("Pending owner cannot be the current owner");
            return err!(LendingError::ObligationInvalidPendingOwner);
        }

        self.ownership_transfer_state = OwnershipTransferState::Initiated.into();
        self.pending_owner = pending_owner;
        Ok(())
    }

    /// Approves the ownership transfer (sets the approval flag)
    /// This function assumes that the handler has already verified:
    /// - The ownership transfer is in initiated state
    /// - The correct pending_owner is being approved
    pub fn approve_ownership_transfer(&mut self) -> Result<()> {
        self.ownership_transfer_state = OwnershipTransferState::Approved.into();
        Ok(())
    }

    /// Accepts ownership transfer (completes the transfer)
    /// This function assumes that a check that the ownership transfer is in approved state
    /// has already been performed in the handler
    pub fn accept_ownership(&mut self) -> Result<()> {
        self.owner = self.pending_owner;
        self.pending_owner = Pubkey::default();
        self.ownership_transfer_state = OwnershipTransferState::None.into();
        Ok(())
    }

    /// Aborts ownership transfer (resets the state)
    /// This function assumes that a check that the ownership transfer is in progress has already
    /// been performed in the handler
    pub fn abort_ownership_transfer(&mut self) -> Result<()> {
        self.pending_owner = Pubkey::default();
        self.ownership_transfer_state = OwnershipTransferState::None.into();
        Ok(())
    }
}

/// Initialize an obligation
pub struct InitObligationParams {
    /// Last update to collateral, liquidity, or their market values
    pub current_slot: Slot,
    /// Lending market address
    pub lending_market: Pubkey,
    /// Owner authority which can borrow liquidity
    pub owner: Pubkey,
    /// Deposited collateral for the obligation, unique by deposit reserve address
    pub deposits: [ObligationCollateral; 8],
    /// Borrowed liquidity for the obligation, unique by borrow reserve address
    pub borrows: [ObligationLiquidity; 5],
    /// Obligation tag 0 - vanilla vault, 1 - multiply vault, 2 - leverage vault
    pub tag: u64,
    /// Referrer of the owner of the obligation
    pub referrer: Pubkey,
}

#[derive(AnchorDeserialize, AnchorSerialize)]
pub struct InitObligationArgs {
    pub tag: u8,
    pub id: u8,
}

/// Obligation collateral state
#[derive(Debug, Default, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct ObligationCollateral {
    /// Reserve collateral is deposited to
    pub deposit_reserve: Pubkey,
    /// Amount of collateral deposited
    pub deposited_amount: u64,
    /// Collateral market value in quote currency (scaled fraction)
    pub market_value_sf: u128,
    /// Debt amount (lamport) taken against this collateral.
    /// (only meaningful if this obligation is part of an elevation group, otherwise 0)
    /// This is only indicative of the debt computed on the last refresh obligation.
    /// If the obligation have multiple collateral this value is the same for all of them.
    pub borrowed_amount_against_this_collateral_in_elevation_group: u64,
    pub padding: [u64; 9],
}

impl ObligationCollateral {
    /// Create new obligation collateral
    pub fn new(deposit_reserve: Pubkey) -> Self {
        Self {
            deposit_reserve,
            deposited_amount: 0,
            market_value_sf: 0,
            borrowed_amount_against_this_collateral_in_elevation_group: 0,
            padding: [0; 9],
        }
    }

    /// Increase deposited collateral
    pub fn deposit(&mut self, collateral_amount: u64) -> Result<()> {
        self.deposited_amount = self
            .deposited_amount
            .checked_add(collateral_amount)
            .ok_or(LendingError::MathOverflow)?;
        Ok(())
    }

    /// Decrease deposited collateral
    pub fn withdraw(&mut self, collateral_amount: u64) -> Result<()> {
        self.deposited_amount = self
            .deposited_amount
            .checked_sub(collateral_amount)
            .ok_or(LendingError::MathOverflow)?;
        Ok(())
    }

    /// Returns true if this instance should be considered an active/non-void/non-null/used entry in
    /// the [Obligation::deposits] array.
    pub fn is_active(&self) -> bool {
        self.deposit_reserve != Pubkey::default()
    }
}

/// Obligation liquidity state
#[derive(Debug, Default, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct ObligationLiquidity {
    /// Reserve liquidity is borrowed from
    pub borrow_reserve: Pubkey,
    /// Borrow rate used for calculating interest (big scaled fraction)
    pub cumulative_borrow_rate_bsf: BigFractionBytes,

    /// The timestamp at which this debt was taken.
    ///
    /// Conceptually, every borrow can be interpreted as "closing the previous loan and starting a
    /// new one" (which would make a plain ` borrowed_at ` an even better name). But in terms of
    /// implementation, this fields records when the *last* borrow operation from this reserve
    /// happened (i.e. adding debt of the same reserve *does* move this timestamp).
    ///
    /// Note: this field is *not* only metadata: it is used in the logic, e.g. for enforcing the
    /// fixed-term borrows (i.e. those induced by [ReserveConfig::debt_term_seconds]).
    pub last_borrowed_at_timestamp: u64,

    /// Amount of liquidity borrowed plus interest (scaled fraction)
    pub borrowed_amount_sf: u128,
    /// Liquidity market value in quote currency (scaled fraction)
    pub market_value_sf: u128,
    /// Risk adjusted liquidity market value in quote currency - DEBUG ONLY - use market_value instead
    pub borrow_factor_adjusted_market_value_sf: u128,

    /// Amount of liquidity borrowed outside of an elevation group
    pub borrowed_amount_outside_elevation_groups: u64,

    /// The user's auto-rollover/migration opt-ins. Some settings are effective only for fixed-term
    /// borrows, while others only for open-term borrows - see individual field docs.
    pub fixed_term_borrow_rollover_config: FixedTermBorrowRolloverConfig,

    /// An amount of liquidity that was borrowed when this fixed-term borrow expired (i.e. zeroed if
    /// this borrow is not fixed-term, or if it did not yet expire).
    ///
    /// Needed to honor the [LendingMarket::term_based_full_liquidation_duration_secs].
    ///
    /// This value is captured by [Self::capture_borrowed_amount_at_expiration] during obligation's
    /// refresh - please see the method's docs for gotchas.
    ///
    /// Note on precision: we use a `u64` field, since the remaining space within this struct is
    /// rather scarce, and we do not need sub-lamport precision for the liquidation throttling rate.
    pub borrowed_amount_at_expiration: u64,

    pub padding2: [u64; 4],
}

impl ObligationLiquidity {
    /// Create new obligation liquidity
    pub fn new(borrow_reserve: Pubkey, cumulative_borrow_rate_bf: BigFraction) -> Self {
        Self {
            borrow_reserve,
            cumulative_borrow_rate_bsf: cumulative_borrow_rate_bf.into(),
            last_borrowed_at_timestamp: 0, // deliberately not set - nothing borrowed yet (see the field below for evidence)
            borrowed_amount_sf: 0,
            market_value_sf: 0,
            borrow_factor_adjusted_market_value_sf: 0,
            borrowed_amount_outside_elevation_groups: 0,
            fixed_term_borrow_rollover_config: FixedTermBorrowRolloverConfig::default(),
            borrowed_amount_at_expiration: 0,
            padding2: default_array(),
        }
    }

    /// Decrease borrowed liquidity
    pub fn repay(&mut self, settle_amount: Fraction) {
        self.borrowed_amount_sf = (self.borrowed_amount() - settle_amount).to_bits();
    }

    /// Increase borrowed liquidity
    pub fn borrow(&mut self, borrow_amount: Fraction, current_timestamp: u64) {
        self.borrowed_amount_sf = (self.borrowed_amount() + borrow_amount).to_bits();
        self.last_borrowed_at_timestamp = current_timestamp;
    }

    /// Accrue interest
    pub fn accrue_interest(&mut self, new_cumulative_borrow_rate: BigFraction) -> Result<()> {
        let former_cumulative_borrow_rate_bsf: U256 = U256(self.cumulative_borrow_rate_bsf.value);
        let new_cumulative_borrow_rate_bsf: U256 = new_cumulative_borrow_rate.0;

        match new_cumulative_borrow_rate_bsf.cmp(&former_cumulative_borrow_rate_bsf) {
            Ordering::Less => {
                xmsg!("Interest rate cannot be negative");
                return err!(LendingError::NegativeInterestRate);
            }
            Ordering::Equal => {}
            Ordering::Greater => {
                self.borrowed_amount_sf = Self::calculate_amount_with_accrued_interest(
                    self.borrowed_amount_sf,
                    former_cumulative_borrow_rate_bsf,
                    new_cumulative_borrow_rate_bsf,
                )?;
                self.cumulative_borrow_rate_bsf.value = new_cumulative_borrow_rate_bsf.0;
            }
        }

        Ok(())
    }

    /// Captures the current [Self::borrowed_amount()] (rounded up to full lamports) into the
    /// [Self::borrowed_amount_at_expiration], if this happens to be a fixed-term debt that has just
    /// expired.
    ///
    /// Note on correctness: the amount captured here is actually "debt at the moment of first
    /// obligation refresh after the expiration". We technically could estimate a more accurate
    /// amount (by subtracting the interest accrued during the time difference) - however, this
    /// value only drives the *throttling* of liquidation rate (i.e. *not* any actual final amount
    /// that gets repaid) and the inaccuracy should still be minor (assuming timely liquidations,
    /// which is something we often rely on).
    pub fn capture_borrowed_amount_at_expiration(
        &mut self,
        reserve_config: &ReserveConfig,
        timestamp: u64,
    ) {
        if self.borrowed_amount_at_expiration != 0 {
            return; // already captured
        }
        if self
            .get_secs_since_reserve_debt_term_end(reserve_config, timestamp)
            .is_none()
        {
            return; // not expired
        }
        self.borrowed_amount_at_expiration = self.borrowed_amount().to_ceil(); // we are ok with approximation, and we do not want to store literal 0 (which would mean "not captured")
    }

    /// Apply a cumulative borrow rate change to an amount, returning the amount with accrued interest:
    /// new_borrowed_amount = old_borrowed_amount * new_cumulative_borrow_rate / old_cumulative_borrow_rate
    fn calculate_amount_with_accrued_interest(
        amount_sf: u128,
        former_cumulative_borrow_rate_bsf: U256,
        new_cumulative_borrow_rate_bsf: U256,
    ) -> Result<u128> {
        // All values are scaled fractions (same number of fractional bits). Because we multiply
        // then divide by a scaled fraction we can make the computation more efficient by skipping the
        // conversion to Fraction or BigFraction. Therefore we do the computations directly on U256.

        let amount_sf_u256 = U256::from(amount_sf) * new_cumulative_borrow_rate_bsf
            / former_cumulative_borrow_rate_bsf;
        amount_sf_u256
            .try_into()
            .map_err(|_| error!(LendingError::MathOverflow))
    }

    /// Calculate the interest that would accrue on the given amount over the given time period,
    /// based on this obligation liquidity's current cumulative borrow rate and the reserve's
    /// interest rate curve.
    ///
    /// This assumes the current cumulative borrow rate on this obligation liquidity matches the
    /// current rate on the reserve liquidity, which is the case when both the obligation and the
    /// reserve have been refreshed in the current slot.
    fn calculate_interest_for_period(
        &self,
        amount: Fraction,
        time_period: Fraction,
        reserve: &Reserve,
    ) -> Result<Fraction> {
        let future_slot =
            secs::estimate_slot_after_period(reserve.last_update.get_slot(), time_period)?;
        let future_cumulative_borrow_rate_bsf =
            reserve.calculate_future_cumulative_borrow_rate(future_slot)?;

        let amount_with_interest =
            Fraction::from_bits(Self::calculate_amount_with_accrued_interest(
                amount.to_bits(),
                U256(self.cumulative_borrow_rate_bsf.value),
                future_cumulative_borrow_rate_bsf.0,
            )?);

        Ok(amount_with_interest - amount)
    }

    /// Returns true if this instance should be considered an active/non-void/non-null/used entry in
    /// the [Obligation::borrows] array.
    pub fn is_active(&self) -> bool {
        self.borrow_reserve != Pubkey::default()
    }

    /// Liquidity market value in quote currency.
    pub fn market_value(&self) -> Fraction {
        Fraction::from_bits(self.market_value_sf)
    }

    /// A parsed [Self::borrowed_amount_sf].
    pub fn borrowed_amount(&self) -> Fraction {
        Fraction::from_bits(self.borrowed_amount_sf)
    }

    /// A parsed [Self::borrowed_amount_at_expiration].
    pub fn borrowed_amount_at_expiration(&self) -> Fraction {
        Fraction::from_num(self.borrowed_amount_at_expiration)
    }

    /// Returns time (in seconds) since the corresponding reserve's debt term has been reached by
    /// this borrow.
    pub fn get_secs_since_reserve_debt_term_end(
        &self,
        reserve_config: &ReserveConfig,
        timestamp: u64,
    ) -> Option<u64> {
        timestamp.checked_sub(self.get_debt_term_end_timestamp(reserve_config)?)
    }

    /// Returns this borrow's debt term end timestamp based on the given reserve's config.
    pub fn get_debt_term_end_timestamp(&self, reserve_config: &ReserveConfig) -> Option<u64> {
        let Some(debt_term_seconds) = reserve_config.get_debt_term_seconds() else {
            return None; // default case: open term
        };
        if self.last_borrowed_at_timestamp == 0 {
            xmsg!(
                "Debt reserve has a debt term of {} seconds, but an Obligation did not track its borrow timestamp; ignoring it",
                debt_term_seconds,
            );
            return None; // this situation should not happen in practice (since we do not plan to set debt term of pre-existing reserves); still, if it does, all we can do is ignore the pre-existing borrows
        }
        Some(self.last_borrowed_at_timestamp + debt_term_seconds)
    }

    /// Calculate the early repay penalty for a given repay amount.
    ///
    /// The penalty is [`ReserveConfig::get_early_repay_penalty_remaining_interest_pct`] of the
    /// interest that would accrue on the repaid amount over the remaining debt term.
    ///
    /// Returns 0 when:
    /// - The reserve is open-term (`debt_term_seconds == 0`)
    /// - `last_borrowed_at_timestamp == 0` (legacy/untracked borrow)
    /// - The debt has matured (elapsed >= debt_term_seconds)
    ///
    /// Panics if `repay_amount > borrowed_amount` (callers must cap repay to the outstanding debt)
    pub fn calculate_early_repay_penalty(
        &self,
        reserve: &Reserve,
        repay_amount: Fraction,
        current_timestamp: u64,
    ) -> Result<u64> {
        let Some(debt_term_seconds) = reserve.config.get_debt_term_seconds() else {
            return Ok(0); // indefinite debt term
        };

        if self.last_borrowed_at_timestamp == 0 {
            xmsg!(
                "Debt reserve has a debt term of {} seconds, but an Obligation did not track its last borrow timestamp; ignoring it",
                debt_term_seconds,
            );
            return Ok(0);
        }

        // If there's no borrow amount (should not happen in practice)
        if self.borrowed_amount_sf == 0 {
            return Ok(0);
        }

        if repay_amount > self.borrowed_amount() {
            panic!("caller must cap repay_amount to borrowed_amount");
        }

        let seconds_since_last_borrowed =
            current_timestamp.saturating_sub(self.last_borrowed_at_timestamp);
        if seconds_since_last_borrowed >= debt_term_seconds {
            return Ok(0); // No penalty when debt expired (unlikely situation, assuming an efficient liquidator bot)
        }

        let remaining_secs = debt_term_seconds - seconds_since_last_borrowed;
        let remaining_interest = self.calculate_interest_for_period(
            repay_amount,
            Fraction::from_num(remaining_secs),
            reserve,
        )?;

        let penalty_pct = reserve
            .config
            .get_early_repay_penalty_remaining_interest_pct();

        Ok((remaining_interest * penalty_pct).to_ceil::<u64>())
    }
}

/// Settings driving the auto-rollover (or migration) of an [ObligationLiquidity]'s borrow.
///
/// This covers three flavors:
/// - *fixed-to-fixed*: a fixed-term borrow rolling into another fixed-term reserve,
/// - *fixed-to-open*: a fixed-term borrow rolling into an open-term reserve,
/// - *open-to-fixed*: an open-term borrow migrating into a fixed-term reserve.
///
/// By its nature (not a special case), the zeroed struct means "no auto-rollover/migration".
#[derive(Debug, Default, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct FixedTermBorrowRolloverConfig {
    /// Whether this *fixed-term* borrow can be permissionlessly prolonged. The funds used to roll
    /// over can come:
    /// - either from a *fixed-term* reserve (same or a different one):
    ///   - This can only happen within [LendingMarket::fixed_term_rollover_window_duration_seconds].
    ///   - The target reserve must meet all the criteria defined in this config (see
    ///     [Self::max_borrow_rate_bps] and [Self::min_debt_term_seconds]).
    ///   - Note: not possible when [Self::min_debt_term_seconds] is `0` (open-term only).
    /// - or from an *open-term* reserve:
    ///   - This can only happen within [LendingMarket::open_term_rollover_window_duration_seconds].
    ///   - The user must explicitly set [Self::open_term_allowed] here.
    ///
    /// This setting is not effective when the borrow is currently using an *open-term* reserve.
    pub auto_rollover_enabled: u8,

    /// When `1`, then [Self::auto_rollover_enabled] is allowed to roll this borrow over into any
    /// open-term reserve.
    ///
    /// Please note that if such rollover actually happens, then [Self::max_borrow_rate_bps]
    /// condition does not apply - technically, it could be evaluated, but open-term reserves
    /// typically use float-rate (utilization-driven borrow rate curve) which has very high maximum
    /// (when at 100% utilization) that would not meet any practical criteria here.
    pub open_term_allowed: u8,

    /// Whether this *open-term* borrow can be permissionlessly migrated into a fixed-term reserve:
    /// - This can happen at any moment (as soon as liquidity becomes available).
    /// - The target fixed-term reserve must meet all the criteria defined in this config (see
    ///   [Self::max_borrow_rate_bps] and [Self::min_debt_term_seconds]).
    ///
    /// This setting is not effective when the borrow is currently using a *fixed-term* reserve.
    ///
    /// Cannot be enabled when [Self::min_debt_term_seconds] is `0` (open-term only), because
    /// migrating into a fixed-term reserve contradicts the open-term-only intent.
    pub migration_to_fixed_enabled: u8,

    /// Internal alignment padding (free to reuse).
    pub alignment_padding: [u8; 1],

    /// A maximum allowed borrow rate of a reserve that can be used for a rollover/migration.
    ///
    /// Note: this must be set (i.e. non-zero) when enabling any rollover/migration flavor, but is
    /// of course not effective when rollover/migration is not enabled.
    pub max_borrow_rate_bps: u32,

    /// A minimum debt term (in seconds) of a fixed-term reserve that can be used for a
    /// rollover/migration.
    ///
    /// When `0`, the owner only accepts open-term reserves as rollover targets — i.e. rolling over
    /// (or migrating) into a fixed-term reserve is not allowed. This is consistent with the
    /// semantics of [BorrowOrder::min_debt_term_seconds].
    ///
    /// This means that `0` is incompatible with [Self::migration_to_fixed_enabled] (which requires
    /// a fixed-term target) — this combination is rejected at configuration time.
    pub min_debt_term_seconds: u64,
}

impl FixedTermBorrowRolloverConfig {
    pub fn is_auto_rollover_enabled(&self) -> bool {
        self.auto_rollover_enabled != false as u8
    }

    pub fn is_migration_to_fixed_enabled(&self) -> bool {
        self.migration_to_fixed_enabled != false as u8
    }

    /// Resolves the way in which this rollover configuration allows to roll over from the given
    /// source reserve into the given target.
    pub fn resolve_rollover_mode(
        &self,
        source_reserve_config: &ReserveConfig,
        target_reserve_config: &ReserveConfig,
    ) -> Result<RolloverMode> {
        if source_reserve_config.get_debt_term_seconds().is_some() {
            // When source is fixed-term, then we have to resolve which of the "classic" rollover flavors this is: (into-fixed vs into-open)
            self.resolve_rollover_from_fixed_term_mode(target_reserve_config)
        } else {
            // When source is open-term, then we know this is a migration to fixed-term, and we just need to check its conditions being met:
            self.check_migration_to_fixed_term_possible(target_reserve_config)?;
            Ok(RolloverMode::FromOpenToFixedTerm)
        }
    }

    /// Resolves rollover mode when source borrow is fixed-term.
    fn resolve_rollover_from_fixed_term_mode(
        &self,
        target_reserve_config: &ReserveConfig,
    ) -> Result<RolloverMode> {
        // Maybe the owner did not even opt-in?
        if !self.is_auto_rollover_enabled() {
            return err!(LendingError::ObligationBorrowRolloverNotEnabledByOwner);
        }

        // Maybe the target reserve is open-term?
        let Some(target_debt_term_seconds) = target_reserve_config.get_debt_term_seconds() else {
            return if self.open_term_allowed == false as u8 {
                // If so, the owner must allow it...
                xmsg!("Owner did not allow rollover into open-term reserve");
                err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch)
            } else {
                // ... and if he does, we do not need to check anything else:
                Ok(RolloverMode::FromFixedToOpenTerm)
                // Note: the early return above means that the borrow rate condition is not evaluated
                // for open-term target reserves (even though, in theory, an open-term reserve can
                // be a fixed-rate and can totally exceed the user's configured maximum acceptable
                // borrow rate). However, by explicit business decision, we consider that user agrees
                // to any borrow rate when rolling over into an open-term reserve.
            };
        };

        // Maybe the target fixed reserve does not match the owner's wishes regarding the borrow rate?
        // (see the note above explaining why we check the borrow rate only for fixed rates)
        let target_borrow_rate_bps = target_reserve_config.max_borrow_rate_bps();
        if target_borrow_rate_bps > self.max_borrow_rate_bps {
            xmsg!(
                "Target reserve borrow rate ({} bps) is higher than the maximum allowed {} bps",
                target_borrow_rate_bps,
                self.max_borrow_rate_bps
            );
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        }

        // Maybe the owner only wants open-term? (min_debt_term_seconds = 0 means "open-term only")
        if self.min_debt_term_seconds == 0 {
            xmsg!("Owner's min_debt_term_seconds is 0 (open-term only), but target is fixed-term");
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        }

        // Maybe the target fixed reserve does not match the owner's wishes regarding the debt term?
        if target_debt_term_seconds < self.min_debt_term_seconds {
            xmsg!(
                "Target reserve debt term ({} seconds) is lower than the minimum allowed {} seconds",
                target_debt_term_seconds,
                self.min_debt_term_seconds
            );
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        }

        Ok(RolloverMode::FromFixedToFixedTerm)
    }

    /// Checks whether migration to the given fixed-term reserve is possible.
    fn check_migration_to_fixed_term_possible(
        &self,
        target_reserve_config: &ReserveConfig,
    ) -> Result<()> {
        // Maybe the owner did not opt-in to migration?
        if !self.is_migration_to_fixed_enabled() {
            xmsg!("Migration to fixed-term is not enabled by owner");
            return err!(LendingError::ObligationBorrowRolloverNotEnabledByOwner);
        }

        // Target must be fixed-term:
        let Some(target_debt_term_seconds) = target_reserve_config.get_debt_term_seconds() else {
            xmsg!("Migration target must be a fixed-term reserve");
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        };

        // Check borrow rate constraint:
        let target_borrow_rate_bps = target_reserve_config.max_borrow_rate_bps();
        if target_borrow_rate_bps > self.max_borrow_rate_bps {
            xmsg!(
                "Target reserve borrow rate ({} bps) is higher than the maximum allowed {} bps",
                target_borrow_rate_bps,
                self.max_borrow_rate_bps
            );
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        }

        // Maybe the owner only wants open-term? (min_debt_term_seconds = 0 means "open-term only",
        // which contradicts migration-to-fixed — this should be caught at config time, but we check
        // here too for defense in depth)
        if self.min_debt_term_seconds == 0 {
            xmsg!("Owner's min_debt_term_seconds is 0 (open-term only), but migration target is fixed-term");
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        }

        // Check debt term constraint:
        if target_debt_term_seconds < self.min_debt_term_seconds {
            xmsg!(
                "Target reserve debt term ({} seconds) is lower than the minimum allowed {} seconds",
                target_debt_term_seconds,
                self.min_debt_term_seconds
            );
            return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
        }

        Ok(())
    }
}

/// The rollover/migration flavor, driving the effective rollover window duration.
#[derive(PartialEq, Eq, Clone, Copy, Debug, EnumString)]
pub enum RolloverMode {
    FromFixedToFixedTerm,
    FromFixedToOpenTerm,
    FromOpenToFixedTerm, // Note: conceptually not a "rollover" (i.e. the original open-term borrow never needs rolling), but handling is the same, so we cover it under the "rollover" name
}

/// A discriminator of a user-configurable piece of [Obligation].
///
/// Implementation note: due to TS-side codegen quirks (and a "convention" currently seen e.g.
/// within reserve and market update operations), this is not a true Rust enum. The new value of
/// a config item is provided in a separate handler argument (borsh-serialized), and its expected
/// type is defined by each discriminator here. Additionally, each update mode acts on a specific
/// [ObligationConfigUpdateSubject] (e.g. the auto-rollover of fixed-term borrows is configured on
/// a per-borrow basis), which is also specified by separate handler arguments.
#[derive(
    AnchorSerialize,
    AnchorDeserialize,
    TryFromPrimitive,
    PartialEq,
    Eq,
    Clone,
    Copy,
    Debug,
    EnumString,
)]
#[cfg_attr(feature = "serde", derive(EnumIter))]
#[repr(u8)]
pub enum UpdateObligationConfigMode {
    /// Updates the [FixedTermBorrowRolloverConfig::auto_rollover_enabled] on a
    /// [ObligationConfigUpdateSubject::Borrow].
    FixedTermRolloverEnabled = 0,

    /// Updates the [FixedTermBorrowRolloverConfig::max_borrow_rate_bps] on a
    /// [ObligationConfigUpdateSubject::Borrow].
    FixedTermRolloverMaxBorrowRateBps = 1,

    /// Updates the [FixedTermBorrowRolloverConfig::min_debt_term_seconds] on a
    /// [ObligationConfigUpdateSubject::Borrow].
    FixedTermRolloverMinDebtTermSeconds = 2,

    /// Updates the [FixedTermBorrowRolloverConfig::open_term_allowed] on a
    /// [ObligationConfigUpdateSubject::Borrow].
    FixedTermRolloverOpenTermAllowed = 3,

    /// Updates the [FixedTermBorrowRolloverConfig::migration_to_fixed_enabled] on a
    /// [ObligationConfigUpdateSubject::Borrow].
    MigrationToFixedEnabled = 4,
}

/// A level at which a specific [UpdateObligationConfigMode] should be applied.
#[derive(PartialEq, Eq, Clone, Copy, Debug)]
pub enum ObligationConfigUpdateSubject {
    /// Meant for update modes affecting [Obligation]-wide config items.
    Obligation,

    /// Meant for update modes affecting a specific [Obligation::deposits] (of the given reserve).
    Deposit(Pubkey),

    /// Meant for update modes affecting a specific [Obligation::borrows] (of the given reserve).
    Borrow(Pubkey),
}

impl ObligationConfigUpdateSubject {
    /// Resolves the subject from the handler's input accounts.
    pub fn resolve(
        specific_deposit_reserve_address: Option<Pubkey>,
        specific_borrow_reserve_address: Option<Pubkey>,
    ) -> Result<Self> {
        Ok(
            match (
                specific_deposit_reserve_address,
                specific_borrow_reserve_address,
            ) {
                (Some(_), Some(_)) => {
                    xmsg!("Cannot choose both a deposit and a borrow");
                    return err!(LendingError::InvalidObligationConfigUpdateSubject);
                }
                (None, None) => Self::Obligation,
                (Some(deposit), None) => Self::Deposit(deposit),
                (None, Some(borrow)) => Self::Borrow(borrow),
            },
        )
    }

    /// Requires that a specific borrow is being configured, and returns its reserve address.
    pub fn borrow_reserve_address(&self) -> Result<Pubkey> {
        let Self::Borrow(reserve_address) = self else {
            return err!(LendingError::InvalidObligationConfigUpdateSubject);
        };
        Ok(*reserve_address)
    }
}

/// A single obligation order.
/// See [Obligation::obligation_orders].
#[derive(BorshSerialize, BorshDeserialize, Debug, Default, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct ObligationOrder {
    /// A threshold value used by the condition (scaled [Fraction]).
    /// The exact meaning depends on the specific [Self::condition_type].
    ///
    /// Examples:
    /// - when `condition_type == 2 (UserLtvBelow)`:
    ///   then a value of `0.455` here means that the order is active only when the obligation's
    ///   user LTV is less than `0.455` (i.e. < 45.5%).
    /// - when `condition_type == 3 (DebtCollPriceRatioAbove)`:
    ///   assuming the obligation uses BTC collateral for SOL debt, then a value of `491.3` here
    ///   means that the order is active only when the BTC-SOL price is greater than `491.3` (i.e.
    ///   > 491.3 SOL per BTC).
    pub condition_threshold_sf: u128,

    /// A configuration parameter used by the opportunity (scaled [Fraction]).
    /// The exact meaning depends on the specific [Self::opportunity_type].
    ///
    /// Examples:
    /// - when `opportunity_type == 0 (DeleverageSingleDebtAmount)`:
    ///   Assuming the obligation uses BTC collateral for SOL debt, then a value of `1_234_000_000`
    ///   here means that a liquidator may repay up to 1234000000 lamports (i.e. 1.234 SOL) on this
    ///   obligation.
    ///   Note: the special value of [Fraction::MAX] is *not* allowed in this case.
    /// - when `opportunity_type == 1 (DeleverageAllDebtAmount)`:
    ///   The only allowed value in this case is [Fraction::MAX] (to emphasize that *all* debt
    ///   should be repaid).
    pub opportunity_parameter_sf: u128,

    /// A *minimum* additional fraction of collateral transferred to the liquidator, in bps.
    ///
    /// The minimum bonus is applied exactly when the [Self::condition_threshold_sf] is met, and
    /// grows linearly towards the [Self::max_execution_bonus_bps].
    ///
    /// Example: a value of `50` here means 50bps == 0.5% bonus for an "LTV > 65%" order, when
    /// executed precisely at the moment LTV exceeds 65%.
    pub min_execution_bonus_bps: u16,

    /// A *maximum* additional fraction of collateral transferred to the liquidator, in bps.
    ///
    /// The maximum bonus is applied at the relevant "extreme" state of the obligation, i.e.:
    /// - for a stop-loss condition, it is a point at which the obligation becomes liquidatable;
    /// - for a take-profit condition, it is a point at which obligation has 0% LTV.
    ///
    /// In non-extreme states, the actual bonus value is interpolated linearly, starting from
    /// [Self::min_execution_bonus_bps] (at the point specified by the order's condition).
    ///
    /// Example: a value of `300` here means 300bps == 3.0% bonus for a "debt/coll price > 140"
    /// order, when executed at a higher price = 200, at which the obligation's LTV happens to
    /// be equal to its liquidation LTV.
    pub max_execution_bonus_bps: u16,

    /// Serialized [ConditionType].
    /// The entire order is void when this is zeroed (i.e. representing [ConditionType::Never]).
    ///
    /// Example: a value of `2` here denotes `UserLtvBelow` condition type. Of course, to
    /// interpret this condition, we also need to take the [Self::condition_threshold_sf] into
    /// account.
    pub condition_type: u8,

    /// Serialized [OpportunityType].
    ///
    /// Example: a value of `0` here denotes `DeleverageSingleDebtAmount` opportunity. Of course, to
    /// interpret this opportunity, we also need to take the [Self::opportunity_parameter_sf] into
    /// account.
    pub opportunity_type: u8,

    /// Alignment padding.
    /// The fields above take up 2+2+1+1 bytes = 48 bits, which means we need 80 bits = 10 bytes to
    /// align with `u128`s.
    pub padding1: [u8; 10],

    /// End padding.
    /// The total size of a single instance is 8*u128 = 128 bytes.
    pub padding2: [u128; 5],
}

impl ObligationOrder {
    /// Deserialized [Self::condition_type] field.
    pub fn condition_type(&self) -> ConditionType {
        ConditionType::try_from(self.condition_type).expect("Invalid serialized condition")
    }

    /// Deserialized [Self::condition_threshold_sf] field.
    pub fn condition_threshold(&self) -> Fraction {
        Fraction::from_bits(self.condition_threshold_sf)
    }

    /// Deserialized [Self::opportunity_type] field.
    pub fn opportunity_type(&self) -> OpportunityType {
        OpportunityType::try_from(self.opportunity_type).expect("Invalid serialized opportunity")
    }

    /// Deserialized [Self::opportunity_parameter_sf] field.
    pub fn opportunity_parameter(&self) -> Fraction {
        Fraction::from_bits(self.opportunity_parameter_sf)
    }

    /// Returns a range of minimum to maximum execution bonus rate.
    /// The "rate" here means e.g. `0.004` for "40 bps" bonus.
    ///
    /// See [Self::min_execution_bonus_bps]/[Self::max_execution_bonus_bps] fields for details on
    /// the actual bonus interpolation.
    pub fn execution_bonus_rate_range(&self) -> RangeInclusive<Fraction> {
        Fraction::from_bps(self.min_execution_bonus_bps)
            ..=Fraction::from_bps(self.max_execution_bonus_bps)
    }

    /// Returns whether this order can be placed on the given obligation.
    ///
    /// Some orders' conditions or opportunities require e.g. an exactly 1 debt, and they would not
    /// be well-defined on a multiple debt obligation.
    pub fn is_supported_by(&self, obligation: &Obligation) -> bool {
        if self == &ObligationOrder::default() {
            return true; // we always allow to cancel an order
        }
        self.condition_type().is_supported_by(obligation)
            && self.opportunity_type().is_supported_by(obligation)
    }

    /// Adjusts this order to reflect that it was partially/fully used by a liquidation process.
    pub fn consume(&mut self, debt_repay_amount: u64) {
        match self.opportunity_type() {
            OpportunityType::DeleverageSingleDebtAmount => {
                self.use_deleverage_single_debt_amount_opportunity(debt_repay_amount);
            }
            OpportunityType::DeleverageAllDebt => {
                xmsg!("An opportunity to liquidate all debt was used by liquidator repaying amount {} (order unaffected)", debt_repay_amount);
            }
        }
    }

    /// Renders a summary of this order's condition, suitable for logging.
    pub fn condition_to_display(&self) -> impl Display {
        match self.condition_type() {
            ConditionType::Never => "<inactive>".to_string(),
            ConditionType::UserLtvAbove => format!("LTV > {}", self.condition_threshold()),
            ConditionType::UserLtvBelow => format!("LTV < {}", self.condition_threshold()),
            ConditionType::DebtCollPriceRatioAbove => format!(
                "ratio of (debt token price / collateral token price) > {}",
                self.condition_threshold()
            ),
            ConditionType::DebtCollPriceRatioBelow => format!(
                "ratio of (debt token price / collateral token price) < {}",
                self.condition_threshold()
            ),
            ConditionType::Always => "<unconditional>".to_string(),
            ConditionType::LiquidationLtvCloserThan => format!(
                "LTV closer than {} to liquidation",
                self.condition_threshold()
            ),
        }
    }

    /// Renders a summary of this order's opportunity, suitable for logging.
    pub fn opportunity_to_display(&self) -> impl Display {
        match self.opportunity_type() {
            OpportunityType::DeleverageSingleDebtAmount => format!(
                "repay amount {} of single debt",
                self.opportunity_parameter()
            ),
            OpportunityType::DeleverageAllDebt => "repay all debt".to_string(),
        }
    }

    /// Adjusts the `DeleverageSingleDebtAmount` opportunity after a liquidation that used it.
    ///
    /// To be specific:
    /// - if the given `debt_repay_amount` is greater than [Self::opportunity_parameter_sf], then
    ///   the order gets cleared;
    /// - if the given `debt_repay_amount` is less than [Self::opportunity_parameter_sf], then the
    ///   opportunity will be left with the leftover difference.
    fn use_deleverage_single_debt_amount_opportunity(&mut self, debt_repay_amount: u64) {
        let liquidatable_debt_amount = self.opportunity_parameter();
        let updated_liquidatable_debt_amount =
            liquidatable_debt_amount.saturating_sub(Fraction::from_num(debt_repay_amount));

        if updated_liquidatable_debt_amount.is_zero() {
            xmsg!("An opportunity to liquidate {} of single debt was fully used by liquidator repaying amount {} (order cleared)", liquidatable_debt_amount, debt_repay_amount);
            *self = ObligationOrder::default();
            return;
        }

        xmsg!("An opportunity to liquidate {} of single debt was partially used by liquidator repaying amount {} ({} left on the order)", liquidatable_debt_amount, debt_repay_amount, updated_liquidatable_debt_amount);
        self.opportunity_parameter_sf = updated_liquidatable_debt_amount.to_bits();
    }

    /// Returns true if this instance should be considered an active/non-void/non-null/used entry in
    /// the [Obligation::obligation_orders] array.
    pub fn is_active(&self) -> bool {
        self.condition_type != 0 // the "set order" handler ensures that when this field is zeroed, then entire struct is zeroed; also conceptually: this explicit "never" condition is sufficient to consider an order inactive
    }
}

/// A borrow order.
///
/// When the [Obligation::borrow_order] is populated (i.e. non-zeroed) on an Obligation, then the
/// permissionless "fill" operations may borrow liquidity to the owner according to this
/// specification.
#[derive(BorshSerialize, BorshDeserialize, Debug, Default, PartialEq, Eq)]
#[zero_copy]
#[repr(C)]
pub struct BorrowOrder {
    /// The asset to be borrowed.
    /// The reserves used for [Obligation::borrows] *must* all provide exactly this asset.
    pub debt_liquidity_mint: Pubkey,

    /// The amount of debt that still needs to be filled, in lamports.
    pub remaining_debt_amount: u64,

    /// The token account owned by the [Obligation::owner] and holding [Self::debt_liquidity_mint],
    /// where the filled funds should be transferred to.
    pub filled_debt_destination: Pubkey,

    /// The minimum allowed debt term that the obligation owner agrees to.
    /// The reserves used to fill this order *cannot* define their debt term *lower* than this.
    ///
    /// If zeroed, then only open-term reserves may be used.
    pub min_debt_term_seconds: u64,

    /// The time until which the borrow order can still be filled.
    pub fillable_until_timestamp: u64,

    /// The time at which this order was placed.
    /// Currently, this is only a piece of metadata.
    pub placed_at_timestamp: u64,

    /// The time at which this order was most-recently updated (including: created).
    /// Currently, this is only a piece of metadata.
    pub last_updated_at_timestamp: u64,

    /// The amount of debt that was originally requested when this order was most-recently updated.
    /// In other words: this field holds a value of [Self::remaining_debt_amount] captured at
    /// [Self::last_updated_at_timestamp].
    /// Currently, this is only a piece of metadata.
    pub requested_debt_amount: u64,

    /// The maximum borrow rate that the obligation owner agrees to.
    /// The reserves used for [Obligation::borrows] *cannot* define their maximum borrow rate
    /// *higher* than this.
    pub max_borrow_rate_bps: u32,

    /// Whether the [Self::remaining_debt_amount] is non-zero.
    ///
    /// This field is *not* used by smart contract logic (which prefers to treat the above
    /// [Self::remaining_debt_amount]-based definition as the single source of truth). However, it
    /// is useful for off-chain bots (order-searchers) to efficiently list (i.e. `memcmp` filter)
    /// just the obligations that have active borrow orders.
    pub active: u8,

    /// When `1`, all [Obligation::borrows] that get filled by this order will have their
    /// [FixedTermBorrowRolloverConfig::auto_rollover_enabled] flag set.
    ///
    /// Additionally, their rollover customizations:
    /// - will exactly match this order's constraints regarding [Self::min_debt_term_seconds] and
    ///   [Self::max_borrow_rate_bps];
    /// - will use the [FixedTermBorrowRolloverConfig::open_term_allowed] fallback.
    ///
    /// See [BorrowOrder::get_rollover_config_for_filled_borrow()].
    ///
    /// Clarification note: when `0`, this setting has no effect on any borrow (i.e. if an existing
    /// borrow was independently marked for auto-rollover, it will *not* be unmarked when filled by
    /// this order).
    ///
    /// Feature flag note: when [LendingMarket::obligation_borrow_rollover_configuration_enabled] is
    /// disabled, this setting has no effect on any borrow (i.e. the fill will be successful, but
    /// the borrow will not be marked for auto-rollover.
    pub enable_auto_rollover_on_filled_borrows: u8,

    /// Alignment padding.
    pub padding1: [u8; 2],

    /// End padding.
    pub end_padding: [u64; 5],
}

impl BorrowOrder {
    /// Returns the [Self::min_debt_term_seconds], or [None] if this order wants open-term.
    pub fn get_min_debt_term_seconds(&self) -> Option<u64> {
        if self.min_debt_term_seconds == 0 {
            return None;
        }
        Some(self.min_debt_term_seconds)
    }

    /// Zeroes this order if its [Self::fillable_until_timestamp] is older than the given one.
    pub fn clear_if_past_fillable_timestamp(&mut self, timestamp: u64) {
        if self != &Default::default() && self.fillable_until_timestamp < timestamp {
            xmsg!(
                "Clearing expired borrow order - fillable until {}",
                self.fillable_until_timestamp
            );
            *self = Default::default();
        }
    }

    /// Returns the auto-rollover config that should be propagated to all [Obligation::borrows]
    /// after getting filled by this order (see [Self::enable_auto_rollover_on_filled_borrows]).
    ///
    /// Note: [Self::min_debt_term_seconds] of `0` means "open-term only" — consistently with how
    /// this field is interpreted during rollover resolution (see
    /// [FixedTermBorrowRolloverConfig::resolve_rollover_from_fixed_term_mode]). In that case,
    /// migration-to-fixed is not enabled, because it would contradict the open-term-only intent.
    pub fn get_rollover_config_for_filled_borrow(&self) -> Option<FixedTermBorrowRolloverConfig> {
        if self.enable_auto_rollover_on_filled_borrows == false as u8 {
            return None; // user does not want to auto-set the rollover flag on such borrows
        }
        Some(FixedTermBorrowRolloverConfig {
            auto_rollover_enabled: true as u8,
            open_term_allowed: true as u8, // we deliberately opt-in for this by default
            migration_to_fixed_enabled: (self.min_debt_term_seconds != 0) as u8, // if such migration is meant to target fixed-term, then we cannot have it when min_debt_term says "only open-term"
            max_borrow_rate_bps: self.max_borrow_rate_bps,
            min_debt_term_seconds: self.min_debt_term_seconds,
            alignment_padding: default_array(),
        })
    }
}

/// A set of owner-configurable properties of a [BorrowOrder], used as an input to the order
/// initialization/update handler.
#[derive(Clone, Debug)]
pub struct BorrowOrderConfig {
    pub debt_liquidity_mint: Pubkey,
    pub remaining_debt_amount: u64,
    pub filled_debt_destination: Pubkey,
    pub max_borrow_rate_bps: u32,
    pub min_debt_term_seconds: u64,
    pub fillable_until_timestamp: u64,
    pub enable_auto_rollover_on_filled_borrows: u8,
}

use std::fmt::Debug;

use anchor_lang::{err, Result};
use solana_program::{clock::Clock, msg, pubkey::Pubkey};

use crate::{
    lending_market::utils::calculate_market_value_from_liquidity_amount,
    utils::{accounts::default_array, EventEmitter, Fraction, FractionExtra},
    BorrowOrder, BorrowOrderCancelEvent, BorrowOrderConfig, BorrowOrderFullFillEvent,
    BorrowOrderPartialFillEvent, BorrowOrderPlaceEvent, BorrowOrderUpdateEvent,
    FixedTermBorrowRolloverConfig, LendingError, LendingMarket, Obligation, Reserve,
};

/// Sets the new state of the given borrow order, if valid and allowed by the configuration.
///
/// There is a slight difference in creating a new vs updating the existing borrow order (mostly
/// regarding the validation) - please see the [update_borrow_order_config()] function for details.
/// Cancelling the (remaining part of the) current borrow order is expressed via a [None] argument.
pub fn set_borrow_order(
    lending_market: &LendingMarket,
    reserve: &Reserve,
    borrow_order: &mut BorrowOrder,
    order_config: Option<BorrowOrderConfig>,
    clock: &Clock,
    event_emitter: impl EventEmitter,
) -> Result<()> {
    // Handle the easy cancellation:
    let Some(order_config) = order_config else {
        if borrow_order == &Default::default() {
            msg!("Ignored a no-op cancellation of the borrow order");
        } else {
            event_emitter.emit(BorrowOrderCancelEvent {
                before: *borrow_order,
            })?;
            *borrow_order = BorrowOrder::default();
        }
        return Ok(());
    };

    let timestamp = clock.unix_timestamp.try_into().expect("negative timestamp");

    // If not a cancellation, then we require a valid config:
    check_order_config_valid(&order_config, lending_market, reserve, timestamp)?;

    // We want to distinguish between "create" vs "update" cases (below). So, let's make sure that an expired order is treated as "not exists":
    borrow_order.clear_if_past_fillable_timestamp(timestamp);

    // The "create" vs "update" cases differ (in terms of which fields can be set):
    if borrow_order == &Default::default() {
        // We are only gating creation here: (updates and cancellations are allowed regardless of the market's config)
        check_borrow_order_creation_enabled(lending_market)?;
        initialize_borrow_order(borrow_order, order_config, timestamp)?;
        event_emitter.emit(BorrowOrderPlaceEvent {
            after: *borrow_order,
        })?;
    } else {
        let borrow_order_initial_state = *borrow_order; // for event only
        update_borrow_order_config(borrow_order, order_config, timestamp)?;
        event_emitter.emit(BorrowOrderUpdateEvent {
            before: borrow_order_initial_state,
            after: *borrow_order,
        })?;
    }

    Ok(())
}

/// Marks the requested part (possibly an entirety) of the borrow order as "filled", if it is
/// allowed to do so using the given reserve.
///
/// Note: this method assumes that the given amount respects the order's size, and panics otherwise.
pub fn fill_borrow_order(
    lending_market: &LendingMarket,
    reserve: &Reserve,
    borrow_order: &mut BorrowOrder,
    clock: &Clock,
    amount: u64,
    event_emitter: impl EventEmitter,
) -> Result<()> {
    check_borrow_order_execution_enabled(lending_market)?;

    // Cannot fill using a reserve that may *potentially* reach higher borrow rate than requested:
    let reserve_max_borrow_rate_bps = reserve.config.max_borrow_rate_bps();
    if reserve_max_borrow_rate_bps > borrow_order.max_borrow_rate_bps {
        msg!(
            "Cannot use reserve with max borrow rate of {} bps on an order requesting max {} bps",
            reserve_max_borrow_rate_bps,
            borrow_order.max_borrow_rate_bps
        );
        return err!(LendingError::BorrowOrderMaxBorrowRateExceeded);
    }

    // Cannot fill using a reserve with a debt term shorter than requested by the order:
    if !is_term_satisfied(
        borrow_order.get_min_debt_term_seconds(),
        reserve.config.get_debt_term_seconds(),
    ) {
        msg!(
            "Cannot use reserve with debt term of {:?} seconds on an order requesting min {:?} seconds",
            reserve.config.get_debt_term_seconds(),
            borrow_order.get_min_debt_term_seconds()
        );
        return err!(LendingError::BorrowOrderMinDebtTermInsufficient);
    }

    let current_timestamp: u64 = clock.unix_timestamp.try_into().expect("negative timestamp");
    // The `saturating_sub()` below correctly handles the already-expired reserve too; however,
    // in practice we will not see such reserve here, because the borrow logic will throw the more
    // specific `LendingError::ReserveDebtMaturityReached` before reaching this line.
    let seconds_until_reserve_debt_maturity =
        reserve
            .config
            .get_debt_maturity_timestamp()
            .map(|reserve_debt_maturity_timestamp| {
                reserve_debt_maturity_timestamp.saturating_sub(current_timestamp)
            });

    // Cannot fill using a reserve with a debt maturity timestamp set too early for this order:
    if !is_term_satisfied(
        borrow_order.get_min_debt_term_seconds(),
        seconds_until_reserve_debt_maturity,
    ) {
        msg!(
            "Cannot use reserve with debt maturity timestamp {:?} (i.e. in {:?} seconds) on an order requesting min {:?} seconds",
            reserve.config.get_debt_maturity_timestamp(),
            seconds_until_reserve_debt_maturity,
            borrow_order.get_min_debt_term_seconds(),
        );
        return err!(LendingError::BorrowOrderMinDebtTermInsufficient);
    }

    // Cannot fill at all after the timestamp configured by the order:
    if current_timestamp > borrow_order.fillable_until_timestamp {
        msg!(
            "At current timestamp {} it is no longer possible to fill an order fillable until {}",
            current_timestamp,
            borrow_order.fillable_until_timestamp
        );
        return err!(LendingError::BorrowOrderFillTimeLimitExceeded);
    }

    // When we are *not* filling the entire order...
    let new_remaining_debt_amount = borrow_order.remaining_debt_amount - amount;
    if new_remaining_debt_amount > 0 {
        // ... then we cannot fill less than the configured minimum:
        let fill_value =
            calculate_market_value_from_liquidity_amount(reserve, Fraction::from_num(amount));
        if fill_value < lending_market.min_borrow_order_fill_value {
            msg!(
                "Filled amount {} would have value {}, lower than the configured minimum {}",
                amount,
                fill_value.to_display(),
                lending_market.min_borrow_order_fill_value
            );
            return err!(LendingError::BorrowOrderFillValueTooSmall);
        }

        // ... and the remainder must also be above the minimum (to prevent dust orders):
        check_order_remaining_debt_value(new_remaining_debt_amount, lending_market, reserve)?;
    }

    let borrow_order_initial_state = *borrow_order; // for event only

    // This will panic if the filled amount is too large; we rely on the borrow logic to honor the order size (we call it with `BorrowSize::AtMost(...)`):
    borrow_order.remaining_debt_amount = new_remaining_debt_amount;

    if borrow_order.remaining_debt_amount == 0 {
        event_emitter.emit(BorrowOrderFullFillEvent {
            before: borrow_order_initial_state,
        })?;
        *borrow_order = BorrowOrder::default(); // a technically-not-required housekeeping (lets the bots avoid pulling obligations with inactive borrow orders, though)
    } else {
        event_emitter.emit(BorrowOrderPartialFillEvent {
            before: borrow_order_initial_state,
            after: *borrow_order,
        })?;
    }

    Ok(())
}

/// Sets the filled [ObligationLiquidity::fixed_term_borrow_rollover_config] to the given one (that
/// is supposed to come from [BorrowOrder::get_rollover_config_for_filled_borrow]), or no-ops if the
/// market's configuration does not allow configuring auto-rollover on borrows.
///
/// For completely new borrows of the given reserve, the config is simply propagated. For
/// pre-existing borrows, the borrow order's config must match the existing rollover config exactly.
/// Otherwise, the fill is rejected - to avoid silently changing the user's pre-existing rollover
/// preferences.
pub fn propagate_rollover_config_to_borrow(
    lending_market: &LendingMarket,
    obligation: &mut Obligation,
    reserve_address: Pubkey,
    rollover_config: FixedTermBorrowRolloverConfig,
    already_borrowed_from_same_reserve: bool,
) -> Result<()> {
    if !lending_market.is_obligation_borrow_rollover_configuration_enabled() {
        msg!("Borrow order is supposed to enable auto-rollover on its borrows, but the feature is disabled on market level");
        return err!(LendingError::BorrowRolloverConfigurationDisabled);
    }
    let (borrow, index) = obligation.find_liquidity_in_borrows_mut(reserve_address)?;

    if already_borrowed_from_same_reserve {
        msg!(
            "Filled pre-existing borrow's[{}] previous rollover config: {:?}",
            index,
            borrow.fixed_term_borrow_rollover_config
        );
        if borrow.fixed_term_borrow_rollover_config != rollover_config {
            msg!("Borrow order's rollover config does not match the pre-existing borrow slot's config");
            return err!(LendingError::ObligationBorrowRolloverConfigMismatch);
        }
        return Ok(()); // nothing to propagate, the same config is already there
    }

    borrow.fixed_term_borrow_rollover_config = rollover_config;
    msg!(
        "Borrow order propagated new rollover config: {:?}",
        borrow.fixed_term_borrow_rollover_config
    );
    Ok(())
}

// ONLY INTERNALS BELOW

fn check_borrow_order_creation_enabled(lending_market: &LendingMarket) -> Result<()> {
    if !lending_market.is_borrow_order_creation_enabled() {
        msg!("Creation of new borrow orders is disabled by the market's configuration");
        return err!(LendingError::OrderCreationDisabled);
    }
    Ok(())
}

fn check_borrow_order_execution_enabled(lending_market: &LendingMarket) -> Result<()> {
    if !lending_market.is_borrow_order_execution_enabled() {
        msg!("Execution of borrow orders is disabled by the market's configuration");
        return err!(LendingError::BorrowOrderExecutionDisabled);
    }
    Ok(())
}

fn check_order_config_valid(
    order_config: &BorrowOrderConfig,
    lending_market: &LendingMarket,
    reserve: &Reserve,
    timestamp: u64,
) -> Result<()> {
    let BorrowOrderConfig {
        debt_liquidity_mint: _, // anchor ensures it is "a mint", and we currently cannot validate anything more about it
        remaining_debt_amount,
        filled_debt_destination: _, // validated by anchor constraints
        max_borrow_rate_bps,
        min_debt_term_seconds: _, // always valid (zeroed means "must be open-term")
        fillable_until_timestamp,
        enable_auto_rollover_on_filled_borrows: _, // always valid
    } = order_config;

    // It could be technically valid (and would be a wonderful opportunity) to request max 0% APR...
    if *max_borrow_rate_bps == 0 {
        msg!("Borrow order must specify max borrow rate"); // ... but we prefer to explicitly disallow that, to avoid accidental misconfigurations.
        return err!(LendingError::InvalidOrderConfiguration);
    }

    // Cannot request to borrow 0:
    if *remaining_debt_amount == 0 {
        msg!("Borrow order must request non-0 debt",);
        return err!(LendingError::InvalidOrderConfiguration);
    }

    // Must give some time for filling:
    if *fillable_until_timestamp < timestamp {
        msg!(
            "Fillable until timestamp {} cannot be in the past (at {})",
            fillable_until_timestamp,
            timestamp
        );
        return err!(LendingError::InvalidOrderConfiguration);
    }

    // Cannot create dust borrow orders:
    check_order_remaining_debt_value(*remaining_debt_amount, lending_market, reserve)?;

    Ok(())
}

fn check_order_remaining_debt_value(
    remaining_debt_amount: u64,
    lending_market: &LendingMarket,
    reserve: &Reserve,
) -> Result<()> {
    let order_value = calculate_market_value_from_liquidity_amount(
        reserve,
        Fraction::from_num(remaining_debt_amount),
    );
    if order_value < lending_market.min_borrow_order_fill_value {
        msg!(
            "Borrow order's remaining debt {} would have value {}, below the configured minimum {}",
            remaining_debt_amount,
            order_value.to_display(),
            lending_market.min_borrow_order_fill_value
        );
        return err!(LendingError::BorrowOrderValueTooSmall);
    }
    Ok(())
}

fn initialize_borrow_order(
    borrow_order: &mut BorrowOrder,
    initial_order_config: BorrowOrderConfig,
    timestamp: u64,
) -> Result<()> {
    // Gather the initial values:
    let BorrowOrderConfig {
        debt_liquidity_mint,
        remaining_debt_amount,
        filled_debt_destination,
        max_borrow_rate_bps,
        min_debt_term_seconds,
        fillable_until_timestamp,
        enable_auto_rollover_on_filled_borrows,
    } = initial_order_config;

    // Create a totally new order from these values and the metadata:
    *borrow_order = BorrowOrder {
        active: true as u8,
        debt_liquidity_mint,
        remaining_debt_amount,
        filled_debt_destination,
        min_debt_term_seconds,
        fillable_until_timestamp,
        max_borrow_rate_bps,
        enable_auto_rollover_on_filled_borrows,
        placed_at_timestamp: timestamp,
        last_updated_at_timestamp: timestamp,
        requested_debt_amount: remaining_debt_amount,
        padding1: default_array(),
        end_padding: default_array(),
    };

    Ok(())
}

fn update_borrow_order_config(
    borrow_order: &mut BorrowOrder,
    new_order_config: BorrowOrderConfig,
    timestamp: u64,
) -> Result<()> {
    // Refer all the config fields of the current order:
    // Only some are updatable. But for those that are not, we want to actually enforce that the
    // input new config does not try to update them.
    let BorrowOrder {
        active: _, // not subject to change during order config update (we do not enter this method when `new_order_config.remaining_debt_amount = 0`)
        debt_liquidity_mint: current_debt_liquidity_mint,
        remaining_debt_amount: current_remaining_debt_amount,
        filled_debt_destination: current_filled_debt_destination,
        max_borrow_rate_bps: current_max_borrow_rate_bps,
        min_debt_term_seconds: current_min_debt_term_seconds,
        fillable_until_timestamp: current_fillable_until_timestamp,
        enable_auto_rollover_on_filled_borrows: current_enable_auto_rollover_on_filled_borrows,
        placed_at_timestamp: _, // we are not updating this (only set on initial order placement)
        last_updated_at_timestamp, // an auto-updated piece of metadata
        requested_debt_amount,  // an auto-updated piece of metadata
        padding1: _,            // we are never updating padding
        end_padding: _,         // we are never updating padding
    } = borrow_order;

    // Gather all the new config values:
    let BorrowOrderConfig {
        debt_liquidity_mint: new_debt_liquidity_mint,
        remaining_debt_amount: new_remaining_debt_amount,
        filled_debt_destination: new_filled_debt_destination,
        max_borrow_rate_bps: new_max_borrow_rate_bps,
        min_debt_term_seconds: new_min_debt_term_seconds,
        fillable_until_timestamp: new_fillable_until_timestamp,
        enable_auto_rollover_on_filled_borrows: new_enable_auto_rollover_on_filled_borrows,
    } = new_order_config;

    // Populate the new metadata:
    *last_updated_at_timestamp = timestamp;
    if new_remaining_debt_amount != *current_remaining_debt_amount {
        *requested_debt_amount = new_remaining_debt_amount;
    }

    // Update the config fields:
    *current_remaining_debt_amount = new_remaining_debt_amount;
    *current_max_borrow_rate_bps = new_max_borrow_rate_bps;
    *current_min_debt_term_seconds = new_min_debt_term_seconds;
    *current_fillable_until_timestamp = new_fillable_until_timestamp;
    *current_enable_auto_rollover_on_filled_borrows = new_enable_auto_rollover_on_filled_borrows;

    // Make sure the caller did not expect to change the non-updatable fields:
    // He should cancel the order and place a new one instead.
    check_not_updated(
        "debt liquidity mint",
        current_debt_liquidity_mint,
        new_debt_liquidity_mint,
    )?;
    check_not_updated(
        "filled debt destination",
        current_filled_debt_destination,
        new_filled_debt_destination,
    )?;

    Ok(())
}

fn check_not_updated<T: PartialEq + Debug>(name: &str, current: &T, new: T) -> Result<()> {
    if new != *current {
        msg!(
            "Cannot update the borrow order's {} (currently {:?}, requested {:?})",
            name,
            current,
            new
        );
        return err!(LendingError::NonUpdatableOrderConfiguration);
    }
    Ok(())
}

// Note: the whole reason this function exists (over just using a `<=`) is to handle the special
// meaning of `None` on both sides (i.e. open-term).
fn is_term_satisfied(min_requested_seconds: Option<u64>, max_offered_seconds: Option<u64>) -> bool {
    match (min_requested_seconds, max_offered_seconds) {
        (None, None) => true, // the order wants open-term, and the reserve is open-term - fine!
        (None, Some(_)) => false, // the order wants open-term, but the reserve is fixed-term - nope!
        (Some(_), None) => true, // the order wants some fixed-term, and the reserve is open-term - also fine! (we only check the term duration here; fixed-rate is a separate aspect)
        (Some(min_requested), Some(max_offered)) => min_requested <= max_offered, // simple compare them
    }
}

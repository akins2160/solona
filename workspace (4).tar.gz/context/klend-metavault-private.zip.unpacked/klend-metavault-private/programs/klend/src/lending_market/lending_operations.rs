use std::{cell::RefMut, cmp::min, mem::size_of, ops::Add};

use anchor_lang::{err, prelude::*, require, solana_program::clock::Slot, Result};
use solana_program::clock::{self, Clock};

use crate::{
    approximate_compounded_interest,
    fraction::FractionExtra,
    lending_market::{
        config_items::{self, renderings, validations},
        lending_checks::validate_referrer_token_state,
        utils::{
            calculate_market_value_from_liquidity_amount,
            calculate_obligation_collateral_market_value,
            calculate_obligation_liquidity_market_value, check_borrow_possible,
            check_elevation_group_borrowing_enabled, check_obligation_collateral_deposit_reserve,
            check_obligation_fully_refreshed_and_not_null,
            check_obligation_liquidity_borrow_reserve, check_repay_possible,
            check_same_elevation_group, get_elevation_group, get_max_ltv_and_liquidation_threshold,
            post_borrow_obligation_invariants, post_deposit_obligation_invariants,
            post_repay_obligation_invariants, post_withdraw_obligation_invariants,
            update_elevation_group_debt_trackers_on_repay,
        },
        withdrawal_cap_operations::utils::{add_to_withdrawal_accum, sub_from_withdrawal_accum},
    },
    liquidation_operations, obligation_order_operations,
    state::{CalculateBorrowResult, CalculateLiquidationResult, CalculateRepayResult, Reserve},
    utils::{
        accounts::is_default_array, consts::NO_DELEVERAGING_MARKER, AnyAccountLoader, BigFraction,
        Fraction, GetPriceResult, IterExt, ELEVATION_GROUP_NONE, PROGRAM_VERSION,
    },
    withdraw_ticket::WithdrawTicket,
    xmsg, AllowedRolloverTime, BorrowSize, DepositLiquidityResult, ElevationGroup,
    FixedTermBorrowRolloverConfig, FixedTermRolloverResult, LendingError, LendingMarket,
    LiquidateAndRedeemResult, LiquidateObligationResult, LiquidationReason, LtvMaxWithdrawalCheck,
    MaxReservesAsCollateralCheck, Obligation, ObligationConfigUpdateSubject, ObligationLiquidity,
    PriceStatusFlags, RedeemCollateralOptions, ReferrerTokenState, RefreshObligationBorrowsResult,
    RefreshObligationDepositsResult, ReserveConfig, ReserveConfigCustomizations, ReserveStatus,
    TicketedWithdrawResult, UpdateConfigMode, UpdateObligationConfigMode, WithdrawResult,
};

pub fn refresh_reserve(
    reserve: &mut Reserve,
    clock: &Clock,
    price: Option<GetPriceResult>,
    referral_fee_bps: u16,
    reserve_rewards_max_apr_bps: u16,
) -> Result<()> {
    let slot = clock.slot;

    // 1. Accrue interest
    reserve.accrue_interest(slot, referral_fee_bps)?;

    // 2. Distribute reserve rewards (must run before `update_slot` resets `slots_elapsed`).
    reserve.distribute_rewards(slot, reserve_rewards_max_apr_bps)?;

    // 3. Update the price if possible
    let price_status = if reserve.config.is_emergency_mode() {
        // In emergency mode, invalidate price age and status but don't update from oracle
        reserve.liquidity.market_price_last_updated_ts = 0;
        Some(PriceStatusFlags::empty())
    } else if let Some(GetPriceResult {
        price,
        status,
        timestamp,
    }) = price
    {
        // If the price is provided, we update the price and its status

        reserve.liquidity.market_price_sf = price.to_bits();
        reserve.liquidity.market_price_last_updated_ts = timestamp;

        Some(status)
    } else if !is_saved_price_age_valid(reserve, clock.unix_timestamp) {
        // If the saved price is not valid anymore, reset the price status and keep the old price
        Some(PriceStatusFlags::empty())
    } else {
        // Else, the price age is still in range, we can keep the price status unchanged.
        None
    };

    // 4. Refresh last_update to current slot and elected price status
    reserve.last_update.update_slot(slot, price_status);

    // 5. Default to 0 all previously used padding
    reserve.config.reserved_1 = Default::default();

    Ok(())
}

pub fn is_saved_price_age_valid(reserve: &Reserve, current_ts: clock::UnixTimestamp) -> bool {
    let current_ts: u64 = current_ts.try_into().expect("Negative timestamp");
    let price_last_updated_ts = reserve.liquidity.market_price_last_updated_ts;
    let price_max_age = reserve.config.token_info.max_age_price_seconds;

    // If the price is older than the max age, it is stale
    current_ts.saturating_sub(price_last_updated_ts) < price_max_age
}

pub fn is_price_refresh_needed(
    reserve: &Reserve,
    market: &LendingMarket,
    current_ts: clock::UnixTimestamp,
) -> bool {
    let current_ts = current_ts as u64;
    let price_last_updated_ts = reserve.liquidity.market_price_last_updated_ts;
    let price_max_age = reserve.config.token_info.max_age_price_seconds;
    let price_refresh_trigger_to_max_age_pct: u64 =
        market.price_refresh_trigger_to_max_age_pct.into();
    let price_refresh_trigger_to_max_age_secs =
        price_max_age * price_refresh_trigger_to_max_age_pct / 100;

    // If the price is older than the trigger to max age, refresh is needed
    current_ts.saturating_sub(price_last_updated_ts) >= price_refresh_trigger_to_max_age_secs
}

pub fn refresh_reserve_limit_timestamps(reserve: &mut Reserve, timestamp: u64) {
    reserve.update_deposit_limit_crossed_timestamp(timestamp);
    reserve.update_borrow_limit_crossed_timestamp(timestamp);
}

pub fn deposit_reserve_liquidity(
    reserve: &mut Reserve,
    clock: &Clock,
    liquidity_amount: u64,
) -> Result<DepositLiquidityResult> {
    // CHECKS
    if liquidity_amount == 0 {
        msg!("Liquidity amount provided cannot be zero");
        return err!(LendingError::InvalidAmount);
    }

    if reserve
        .last_update
        .is_stale(clock.slot, PriceStatusFlags::NONE)?
    {
        msg!("Reserve is stale and must be refreshed in the current slot");
        return err!(LendingError::ReserveStale);
    }

    let deposit_result =
        reserve.compute_depositable_amount_and_minted_collateral(liquidity_amount)?;

    // Liquidity deposit checks
    let liquidity_amount_f = Fraction::from(deposit_result.liquidity_amount);
    let deposit_limit_f = Fraction::from(reserve.config.deposit_limit);
    let reserve_liquidity_supply_f = reserve.liquidity.total_supply();

    let new_reserve_liquidity_supply_f = liquidity_amount_f + reserve_liquidity_supply_f;

    if new_reserve_liquidity_supply_f > deposit_limit_f {
        msg!(
            "Cannot deposit liquidity above the reserve deposit limit. New total deposit: {} > limit: {}",
            new_reserve_liquidity_supply_f.to_display(),
            reserve.config.deposit_limit
        );
        return err!(LendingError::DepositLimitExceeded);
    }

    sub_from_withdrawal_accum(
        &mut reserve.config.deposit_withdrawal_cap,
        deposit_result.liquidity_amount,
        u64::try_from(clock.unix_timestamp).unwrap(),
    )?;

    reserve.deposit_liquidity(
        deposit_result.liquidity_amount,
        deposit_result.collateral_amount,
    )?;

    reserve.last_update.mark_stale();

    Ok(deposit_result)
}

#[allow(clippy::too_many_arguments)]
pub fn borrow_obligation_liquidity<'info, T>(
    lending_market: &LendingMarket,
    borrow_reserve: &mut Reserve,
    obligation: &mut Obligation,
    borrow_size: BorrowSize,
    clock: &Clock,
    borrow_reserve_pk: Pubkey,
    referrer_token_state: Option<RefMut<ReferrerTokenState>>,
    deposit_reserves_iter: impl Iterator<Item = T>,
) -> Result<CalculateBorrowResult>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    // CHECKS
    if borrow_size.is_zero() {
        msg!("Liquidity amount provided cannot be zero");
        return err!(LendingError::InvalidAmount);
    }

    check_borrow_possible(lending_market, borrow_reserve, obligation, clock)?;

    let remaining_borrow_value = obligation.remaining_borrow_value();
    if remaining_borrow_value == Fraction::ZERO {
        msg!("Remaining borrow value is zero");
        return err!(LendingError::BorrowTooLarge);
    }

    // INTERACTIONS
    if borrow_reserve.remaining_borrow_capacity() == Fraction::ZERO {
        msg!("Borrow reserve is at full capacity");
        return err!(LendingError::BorrowLimitExceeded);
    }

    let CalculateBorrowResult {
        borrow_amount_f,
        receive_amount,
        origination_fee,
        referrer_fee,
    } = borrow_reserve.calculate_borrow(
        borrow_size,
        remaining_borrow_value,
        lending_market.referral_fee_bps,
        obligation.elevation_group != ELEVATION_GROUP_NONE,
        referrer_token_state.is_some(),
    )?;

    let borrow_amount = borrow_amount_f.to_ceil();
    msg!(
        "Requested: {:?}, calculated: borrow_amount_f {}, receive_amount {}",
        borrow_size,
        borrow_amount_f.to_display(),
        receive_amount
    );

    let current_timestamp = u64::try_from(clock.unix_timestamp).unwrap();
    add_to_withdrawal_accum(
        &mut borrow_reserve.config.debt_withdrawal_cap,
        borrow_amount,
        current_timestamp,
    )?;

    if receive_amount == 0 {
        msg!("Borrow amount is too small to receive liquidity after fees");
        return err!(LendingError::BorrowTooSmall);
    }

    check_below_reserve_utilization_limit(borrow_reserve, borrow_amount_f)?;

    borrow_reserve.borrow(borrow_amount_f, false)?;
    borrow_reserve.last_update.mark_stale();

    let cumulative_borrow_rate_bf =
        BigFraction::from(borrow_reserve.liquidity.cumulative_borrow_rate_bsf);

    // EFFECTS

    let borrow_index = {
        // Limit scope to avoid borrow checker issues
        let (obligation_liquidity, borrow_index) = obligation
            .find_or_add_liquidity_to_borrows(borrow_reserve_pk, cumulative_borrow_rate_bf)?;

        // Similar to the debt maturity case - it does not make sense to allow adding more debt to
        // a borrow that has exceeded the debt term:
        if let Some(secs_since_debt_term_end) = obligation_liquidity
            .get_secs_since_reserve_debt_term_end(&borrow_reserve.config, current_timestamp)
        {
            msg!(
                "Obligation borrow's debt term has been reached {} seconds ago, cannot borrow more",
                secs_since_debt_term_end
            );
            return err!(LendingError::DebtReachedReserveDebtTerm);
        }

        obligation_liquidity.borrow(borrow_amount_f, current_timestamp);

        borrow_index
    };

    if let Some(mut referrer_token_state) = referrer_token_state {
        if lending_market.referral_fee_bps > 0 {
            add_referrer_fee(
                borrow_reserve,
                &mut referrer_token_state,
                Fraction::from_num(referrer_fee),
            )?;

            borrow_reserve.liquidity.total_available_amount += referrer_fee;
        }
    }

    obligation_order_operations::check_orders_supported_after_user_operation(obligation)?;

    obligation.has_debt = 1; // Avoid iterating with update_has_debt(), 1 borrow implies has_debt
    obligation.last_update.mark_stale();

    let elevation_group = lending_market.get_elevation_group(obligation.elevation_group)?;
    utils::update_elevation_group_debt_trackers_on_borrow(
        borrow_amount,
        obligation,
        borrow_index,
        elevation_group,
        &borrow_reserve_pk,
        borrow_reserve,
        deposit_reserves_iter,
    )?;

    post_borrow_obligation_invariants(
        borrow_amount_f,
        obligation,
        borrow_reserve,
        Fraction::from_bits(obligation.borrows[borrow_index].market_value_sf),
        Fraction::from_bits(lending_market.min_net_value_in_obligation_sf),
    )?;

    Ok(CalculateBorrowResult {
        borrow_amount_f,
        receive_amount,
        origination_fee,
        referrer_fee,
    })
}

pub fn deposit_obligation_collateral(
    lending_market: &LendingMarket,
    deposit_reserve: &mut Reserve,
    obligation: &mut Obligation,
    slot: Slot,
    collateral_amount: u64,
    deposit_reserve_pk: Pubkey,
    max_reserves_as_collateral_check: MaxReservesAsCollateralCheck,
) -> Result<()> {
    // CHECKS
    if collateral_amount == 0 {
        msg!("Collateral amount provided cannot be zero");
        return err!(LendingError::InvalidAmount);
    }

    if deposit_reserve
        .last_update
        .is_stale(slot, PriceStatusFlags::NONE)?
    {
        msg!("Deposit reserve is stale and must be refreshed in the current slot");
        return err!(LendingError::ReserveStale);
    }

    if obligation
        .last_update
        .is_stale(slot, PriceStatusFlags::NONE)?
    {
        msg!("Obligation is stale and must be refreshed in the current slot");
        return err!(LendingError::ObligationStale);
    }

    if deposit_reserve.config.disable_usage_as_coll_outside_emode > 0
        && obligation.elevation_group == ELEVATION_GROUP_NONE
        && obligation.borrow_factor_adjusted_debt_value_sf > 0
    {
        msg!("Deposit reserve is disabled for usage as collateral outside elevation group");
        return err!(LendingError::DepositDisabledOutsideElevationGroup);
    }

    check_same_elevation_group(obligation, deposit_reserve)?;
    let elevation_group = get_elevation_group(obligation.elevation_group, lending_market)?;
    let (_, liquidation_threshold_pct) =
        get_max_ltv_and_liquidation_threshold(deposit_reserve, elevation_group);

    if liquidation_threshold_pct == 0 {
        // Depositing is generally very welcome for marked obligations, but depositing a 0-ltv asset
        // is not (it would lower the obligation's LTV below target, but would not reduce the risk
        // exposure, since the added collateral cannot be liquidated).
        obligation.check_not_marked_for_deleveraging()?;
    }

    let pre_deposit_count = obligation.active_deposits_count();
    let total_borrowed_amount = obligation.get_borrowed_amount_if_single_token();

    let pre_collateral_market_value_f = {
        let (obligation_collateral, newly_added) =
            obligation.find_or_add_collateral_to_deposits(deposit_reserve_pk)?;
        if newly_added {
            utils::update_elevation_group_debt_trackers_on_new_deposit(
                total_borrowed_amount,
                obligation_collateral,
                pre_deposit_count,
                elevation_group,
                &deposit_reserve_pk,
                deposit_reserve,
                max_reserves_as_collateral_check,
            )?;
        }

        obligation_collateral.deposit(collateral_amount)?;

        Fraction::from_bits(obligation_collateral.market_value_sf)
    };
    obligation_order_operations::check_orders_supported_after_user_operation(obligation)?;

    obligation.last_update.mark_stale();

    deposit_reserve.last_update.mark_stale();

    // PROTOCOL INVARIANT CHECKS

    post_deposit_obligation_invariants(
        deposit_reserve
            .collateral_exchange_rate()
            .fraction_collateral_to_liquidity(Fraction::from(collateral_amount)),
        obligation,
        deposit_reserve,
        pre_collateral_market_value_f,
        Fraction::from_bits(lending_market.min_net_value_in_obligation_sf),
    )?;

    Ok(())
}

pub fn withdraw_obligation_collateral(
    lending_market: &LendingMarket,
    withdraw_reserve: &mut Reserve,
    obligation: &mut Obligation,
    collateral_amount: u64,
    slot: Slot,
    withdraw_reserve_pk: Pubkey,
    ltv_max_withdrawal_check: LtvMaxWithdrawalCheck,
) -> Result<u64> {
    // CHECKS
    if collateral_amount == 0 {
        return err!(LendingError::InvalidAmount);
    }

    let is_borrows_empty = obligation.is_active_borrows_empty();

    let required_price_status = if is_borrows_empty {
        PriceStatusFlags::NONE
    } else {
        PriceStatusFlags::ALL_CHECKS
    };

    if withdraw_reserve
        .last_update
        .is_stale(slot, required_price_status)?
    {
        msg!(
            "Withdraw reserve is stale and must be refreshed in the current slot, price status: {:08b}",
            withdraw_reserve.last_update.get_price_status().0
        );
        return err!(LendingError::ReserveStale);
    }

    if obligation
        .last_update
        .is_stale(slot, required_price_status)?
    {
        msg!(
            "Obligation is stale and must be refreshed in the current slot, price status: {:08b}",
            obligation.last_update.get_price_status().0
        );
        return err!(LendingError::ObligationStale);
    }

    let collateral_index = obligation.position_of_collateral_in_deposits(withdraw_reserve_pk)?;
    let collateral = &obligation.deposits[collateral_index];
    if collateral.deposited_amount == 0 {
        return err!(LendingError::ObligationCollateralEmpty);
    }

    if !is_borrows_empty {
        check_elevation_group_borrowing_enabled(lending_market, obligation)?;
    }

    if obligation.has_obsolete_reserves()
        && withdraw_reserve.config.status() == ReserveStatus::Active
    {
        return err!(LendingError::ObligationInObsoleteReserve);
    }

    let (reserve_max_ltv_pct, reserve_liq_threshold_ltv_pct) =
        get_max_ltv_and_liquidation_threshold(
            withdraw_reserve,
            get_elevation_group(obligation.elevation_group, lending_market)?,
        );

    // INTERACTIONS

    let withdraw_amount = if is_borrows_empty {
        if collateral_amount == u64::MAX {
            collateral.deposited_amount
        } else {
            collateral.deposited_amount.min(collateral_amount)
        }
    } else if obligation.deposited_value_sf == 0 {
        msg!("Obligation deposited value is zero");
        return err!(LendingError::ObligationDepositsZero);
    } else {
        let max_withdraw_value = obligation.max_withdraw_value(
            collateral,
            reserve_max_ltv_pct,
            reserve_liq_threshold_ltv_pct,
            ltv_max_withdrawal_check,
        );

        if max_withdraw_value == Fraction::ZERO {
            return err!(LendingError::MaximumWithdrawValueZero);
        }

        let collateral_value = Fraction::from_bits(collateral.market_value_sf);
        let withdraw_amount = if collateral_amount == u64::MAX {
            let withdraw_value = max_withdraw_value.min(collateral_value);
            let withdraw_ratio = withdraw_value / collateral_value;
            let ratioed_amount_f = withdraw_ratio * u128::from(collateral.deposited_amount);
            let ratioed_amount: u64 = ratioed_amount_f.to_floor();

            min(collateral.deposited_amount, ratioed_amount)
        } else {
            let withdraw_amount = collateral_amount.min(collateral.deposited_amount);
            let withdraw_ratio = Fraction::from(withdraw_amount)
                .div_ceil(&Fraction::from(collateral.deposited_amount));

            // Make withdraw ratio more restrictive, in case withdraw_value is slightly less than max_withdraw_value, because of Fraction's rounding => hence being able to put the obligation in a liquidatable state
            let withdraw_value: Fraction = collateral_value * withdraw_ratio;

            let exceeds_max_withdraw_value =
                if ltv_max_withdrawal_check == LtvMaxWithdrawalCheck::LiquidationThreshold {
                    withdraw_value >= max_withdraw_value
                } else {
                    withdraw_value > max_withdraw_value
                };

            if exceeds_max_withdraw_value {
                msg!("Withdraw value cannot exceed maximum withdraw value, collateral_amount={}, collateral.deposited_amount={} withdraw_pct={}, collateral_value={}, max_withdraw_value={} withdraw_value={}",
                    collateral_amount,
                    collateral.deposited_amount,
                    withdraw_ratio.to_display(),
                    collateral_value.to_display(),
                    max_withdraw_value.to_display(),
                    withdraw_value.to_display());
                return err!(LendingError::WithdrawTooLarge);
            }
            withdraw_amount
        };

        if withdraw_amount == 0 {
            msg!("Withdraw amount is too small to transfer collateral");
            return err!(LendingError::WithdrawTooSmall);
        }
        withdraw_amount
    };

    let previous_debt_in_elevation_group =
        collateral.borrowed_amount_against_this_collateral_in_elevation_group;
    let is_full_withdrawal = obligation.withdraw(withdraw_amount, collateral_index)?;
    obligation.last_update.mark_stale();

    if is_full_withdrawal == WithdrawResult::Full {
        utils::update_elevation_group_debt_trackers_on_full_withdraw(
            previous_debt_in_elevation_group,
            obligation.elevation_group,
            withdraw_reserve,
        )?;
    }

    // PROTOCOL INVARIANT CHECKS

    post_withdraw_obligation_invariants(
        withdraw_reserve
            .collateral_exchange_rate()
            .fraction_collateral_to_liquidity(Fraction::from(withdraw_amount)),
        obligation,
        withdraw_reserve,
        reserve_liq_threshold_ltv_pct,
        Fraction::from_bits(obligation.deposits[collateral_index].market_value_sf),
        Fraction::from_bits(lending_market.min_net_value_in_obligation_sf),
    )?;

    Ok(withdraw_amount)
}

pub fn redeem_reserve_collateral(
    reserve: &mut Reserve,
    collateral_amount: u64,
    clock: &Clock,
    RedeemCollateralOptions {
        add_amount_to_withdrawal_caps,
        use_withdraw_queue,
    }: RedeemCollateralOptions,
) -> Result<u64> {
    // CHECKS
    if collateral_amount == 0 {
        msg!("Collateral amount provided cannot be zero");
        return err!(LendingError::InvalidAmount);
    }

    if reserve
        .last_update
        .is_stale(clock.slot, PriceStatusFlags::NONE)?
    {
        msg!("Reserve is stale and must be refreshed in the current slot");
        return err!(LendingError::ReserveStale);
    }
    // EFFECTS

    let liquidity_amount = reserve.redeem_collateral(collateral_amount, use_withdraw_queue)?;
    // refresh the reserve/deposit timestamps to ensure they cannot be manipulated without risk of capital
    let timestamp = u64::try_from(clock.unix_timestamp).unwrap();
    refresh_reserve_limit_timestamps(reserve, timestamp);
    reserve.last_update.mark_stale();

    if add_amount_to_withdrawal_caps {
        add_to_withdrawal_accum(
            &mut reserve.config.deposit_withdrawal_cap,
            liquidity_amount,
            u64::try_from(clock.unix_timestamp).unwrap(),
        )?;
    }

    Ok(liquidity_amount)
}

pub fn enqueue_to_withdraw(
    lending_market: &LendingMarket,
    reserve: &mut Reserve,
    collateral_amount: u64,
) -> Result<u64> {
    if collateral_amount == 0 {
        msg!("Cannot enqueue to withdraw a zero amount");
        return err!(LendingError::InvalidAmount);
    }
    check_min_withdraw_ticket_value(lending_market, reserve, collateral_amount)?;
    Ok(reserve.withdraw_queue.enqueue(collateral_amount))
}

pub fn withdraw_queued_liquidity(
    lending_market: &LendingMarket,
    reserve: &mut Reserve,
    withdraw_ticket: &mut WithdrawTicket,
    clock: &Clock,
) -> Result<TicketedWithdrawResult> {
    let max_redeemable_collateral_amount = reserve.total_redeemable_collateral_amount();
    if max_redeemable_collateral_amount == 0 {
        return err!(LendingError::InsufficientLiquidity); // we cannot even do partial in such case
    }

    let collateral_amount_to_burn = min(
        withdraw_ticket.queued_collateral_amount,
        max_redeemable_collateral_amount,
    );
    let remaining_collateral = withdraw_ticket.queued_collateral_amount - collateral_amount_to_burn;
    let ticket_emptied = remaining_collateral == 0;

    // Leaving dust in the ticket is not allowed:
    if !ticket_emptied {
        check_min_withdraw_ticket_value(lending_market, reserve, remaining_collateral)?;
    }

    withdraw_ticket.queued_collateral_amount = remaining_collateral;

    let liquidity_amount_to_withdraw = redeem_reserve_collateral(
        reserve,
        collateral_amount_to_burn,
        clock,
        RedeemCollateralOptions::FOR_WITHDRAW_QUEUED_LIQUIDITY,
    )?;
    check_min_withdrawn_queued_liquidity_value(
        lending_market,
        reserve,
        liquidity_amount_to_withdraw,
        ticket_emptied,
    )?;
    reserve
        .withdraw_queue
        .dequeue(collateral_amount_to_burn, ticket_emptied);

    Ok(TicketedWithdrawResult {
        collateral_amount_to_burn,
        liquidity_amount_to_withdraw,
    })
}

pub fn cancel_withdraw_ticket(
    lending_market: &LendingMarket,
    reserve: &mut Reserve,
    withdraw_ticket: &mut WithdrawTicket,
    collateral_amount_to_cancel: u64,
) -> Result<u64> {
    // Validate and calculate the actual amount to cancel:
    if collateral_amount_to_cancel == 0 {
        msg!("Cannot cancel 0 ctokens");
        return err!(LendingError::InvalidAmount);
    }
    let amount_to_cancel = min(
        collateral_amount_to_cancel,
        withdraw_ticket.queued_collateral_amount,
    );

    // Leaving dust in the ticket is not allowed:
    let remaining_collateral = withdraw_ticket.queued_collateral_amount - amount_to_cancel;
    if remaining_collateral != 0 {
        check_min_withdraw_ticket_value(lending_market, reserve, remaining_collateral)?;
    }
    // Note: cancelling some very small amount is allowed, though (it does not hurt anyone except the owner, who needs to sign)

    // Update ticket and reserve accounting:
    withdraw_ticket.queued_collateral_amount = remaining_collateral;
    reserve.withdraw_queue.dequeue(amount_to_cancel, false); // Note: even full cancellation does NOT progress the queue (because it's not necessarily its turn!) - we leave the tombstone behind

    Ok(amount_to_cancel)
}

pub fn redeem_fees(reserve: &mut Reserve, slot: Slot) -> Result<u64> {
    if reserve.last_update.is_stale(slot, PriceStatusFlags::NONE)? {
        msg!(
            "reserve is stale and must be refreshed in the current slot, price status: {:08b}",
            reserve.last_update.get_price_status().0
        );
        return err!(LendingError::ReserveStale);
    }

    let withdraw_amount = reserve.calculate_redeem_fees();

    if withdraw_amount == 0 {
        return err!(LendingError::InsufficientProtocolFeesToRedeem);
    }

    reserve.redeem_fees(withdraw_amount)?;
    reserve.last_update.mark_stale();

    Ok(withdraw_amount)
}

pub fn repay_obligation_liquidity<'info, T>(
    repay_reserve: &mut Reserve,
    obligation: &mut Obligation,
    clock: &Clock,
    liquidity_amount: u64,
    repay_reserve_pk: Pubkey,
    lending_market: &LendingMarket,
    deposit_reserves_iter: impl Iterator<Item = T>,
) -> Result<u64>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    // CHECKS
    if liquidity_amount == 0 {
        msg!("Liquidity amount provided cannot be zero");
        return err!(LendingError::InvalidAmount);
    }

    let (liquidity, liquidity_index) = obligation.find_liquidity_in_borrows(repay_reserve_pk)?;
    if liquidity.borrowed_amount_sf == 0 {
        msg!("Liquidity borrowed amount is zero");
        return err!(LendingError::ObligationLiquidityEmpty);
    }

    check_repay_possible(repay_reserve, obligation, clock)?;

    // EFFECTS

    let CalculateRepayResult {
        settle_amount,
        repay_amount,
    } = repay_reserve.calculate_repay(liquidity_amount, liquidity.borrowed_amount());

    if repay_amount == 0 {
        msg!("Repay amount is too small to transfer liquidity");
        return err!(LendingError::RepayTooSmall);
    }

    let timestamp = u64::try_from(clock.unix_timestamp).unwrap();

    let early_repay_penalty =
        liquidity.calculate_early_repay_penalty(repay_reserve, settle_amount, timestamp)?;

    let repay_amount_with_penalty = repay_amount + early_repay_penalty;

    sub_from_withdrawal_accum(
        &mut repay_reserve.config.debt_withdrawal_cap,
        repay_amount,
        timestamp,
    )?;

    update_elevation_group_debt_trackers_on_repay(
        repay_amount,
        obligation,
        liquidity_index,
        repay_reserve,
        deposit_reserves_iter,
    )?;

    repay_reserve.liquidity.repay(repay_amount, settle_amount)?;

    if early_repay_penalty > 0 {
        repay_reserve
            .liquidity
            .accumulate_early_repay_penalty(early_repay_penalty)?;
    }

    repay_reserve.last_update.mark_stale();

    obligation.repay(settle_amount, liquidity_index);

    obligation.update_has_debt();
    utils::clear_obligation_orders_if_no_debt(obligation);
    obligation.last_update.mark_stale();

    obligation_order_operations::check_orders_supported_after_user_operation(obligation)?;

    // PROTOCOL INVARIANT CHECKS

    post_repay_obligation_invariants(
        settle_amount,
        obligation,
        repay_reserve,
        Fraction::from_bits(obligation.borrows[liquidity_index].market_value_sf),
        Fraction::from_bits(lending_market.min_net_value_in_obligation_sf),
    )?;

    Ok(repay_amount_with_penalty)
}

#[allow(clippy::too_many_arguments)]
pub fn request_elevation_group<'info, T, U>(
    program_id: &Pubkey,
    obligation: &mut Obligation,
    lending_market: &LendingMarket,
    clock: &Clock,
    new_elevation_group: u8,
    deposit_reserves_iter: impl Iterator<Item = T> + Clone,
    borrow_reserves_iter: impl Iterator<Item = T> + Clone,
    mut referrer_token_states_iter: impl Iterator<Item = U>,
) -> Result<()>
where
    T: AnyAccountLoader<'info, Reserve>,
    U: AnyAccountLoader<'info, ReferrerTokenState>,
{
    // We check to have the obligation refreshed to have the latest
    // borrowed value of the obligation
    check_obligation_fully_refreshed_and_not_null(obligation, clock.slot)?;

    // Check that elevation group is not joining the same elevation group
    require!(
        obligation.elevation_group != new_elevation_group,
        LendingError::ElevationGroupAlreadyActivated
    );

    let initial_ltv = obligation.loan_to_value();

    // Step 1: Reset the tracked debts of the elevation group in the reserves
    reset_elevation_group_debts(
        obligation,
        get_elevation_group(obligation.elevation_group, lending_market)?,
        deposit_reserves_iter.clone(),
        borrow_reserves_iter.clone(),
    )?;

    // Step 2: Refresh obligation borrows deposit and set the tracked debts of the elevation group in the reserves
    let elevation_group = get_elevation_group(new_elevation_group, lending_market)?;

    if let Some(elevation_group) = elevation_group {
        // Check whether elevation group is enabled
        require!(
            !elevation_group.new_loans_disabled(),
            LendingError::ElevationGroupNewLoansDisabled
        );

        require!(
            elevation_group.debt_reserve != Pubkey::default(),
            LendingError::ElevationGroupWithoutDebtReserve
        );

        require_gt!(
            elevation_group.max_reserves_as_collateral,
            0,
            LendingError::ElevationGroupMaxCollateralReserveZero
        );
        require_gte!(
            usize::from(elevation_group.max_reserves_as_collateral),
            obligation.active_deposits_count(),
            LendingError::ObligationCollateralExceedsElevationGroupLimit
        );
    }

    let RefreshObligationBorrowsResult {
        borrow_factor_adjusted_debt_value_f: borrow_factor_adjusted_debt_value,
        borrowed_amount_in_elevation_group,
        ..
    } = refresh_obligation_borrows(
        program_id,
        obligation,
        lending_market,
        clock,
        elevation_group,
        borrow_reserves_iter.clone(),
        &mut referrer_token_states_iter,
    )?;

    let RefreshObligationDepositsResult {
        allowed_borrow_value_f: allowed_borrow_value,
        deposited_value_f: deposited_value,
        borrowing_disabled,
        ..
    } = refresh_obligation_deposits(
        obligation,
        lending_market,
        clock.slot,
        elevation_group,
        deposit_reserves_iter.clone(),
        borrowed_amount_in_elevation_group,
    )?;

    if allowed_borrow_value < borrow_factor_adjusted_debt_value {
        msg!("The obligation is not healthy enough to support the new elevation group");
        return Err(
            error!(LendingError::UnhealthyElevationGroupLtv).with_values((
                allowed_borrow_value.to_display(),
                borrow_factor_adjusted_debt_value.to_display(),
            )),
        );
    }

    check_ltv_not_worse_if_marked_for_deleveraging(
        obligation,
        initial_ltv,
        borrow_factor_adjusted_debt_value,
        deposited_value,
    )?;

    msg!(
        "Previous elevation group: {} . Requested elevation group for: {}",
        obligation.elevation_group,
        new_elevation_group
    );

    obligation.elevation_group = new_elevation_group;
    obligation.borrowing_disabled = borrowing_disabled.into();
    obligation.last_update.mark_stale();

    // Step 3: Check the elevation group borrow limit constraints are not crossed
    utils::check_elevation_group_borrow_limit_constraints(
        obligation,
        elevation_group,
        deposit_reserves_iter,
        borrow_reserves_iter,
    )?;

    Ok(())
}

fn check_min_withdraw_ticket_value(
    lending_market: &LendingMarket,
    reserve: &Reserve,
    collateral_amount: u64,
) -> Result<()> {
    let liquidity_amount = reserve
        .collateral_exchange_rate()
        .collateral_to_liquidity(collateral_amount);
    let ticket_value =
        calculate_market_value_from_liquidity_amount(reserve, Fraction::from_num(liquidity_amount));
    if ticket_value < lending_market.min_withdraw_queued_liquidity_value {
        xmsg!(
            "Withdraw ticket collateral {} (liquidity {}) would have value {}, lower than the configured minimum {}",
            collateral_amount,
            liquidity_amount,
            ticket_value.to_display(),
            lending_market.min_withdraw_queued_liquidity_value
        );
        return err!(LendingError::WithdrawTicketValueTooSmall);
    }
    Ok(())
}

/// Rollovers a fixed-term loan using the same reserve.
///
/// This mode simply "resets the clock" on the existing borrow, and thus skips all the side effects
/// typically associated with a repay and borrow (they would all be effectively no-op). In fact, the
/// regular repay and borrow logic is not reused here, and the only required subset of checks is
/// captured by the shared [check_repay_possible()] and [check_borrow_possible()].
pub fn rollover_borrow_into_same_reserve(
    market: &LendingMarket,
    reserve_address: Pubkey,
    reserve: &Reserve,
    obligation: &mut Obligation,
    clock: &Clock,
) -> Result<()> {
    // Check all the preconditions for rollover:
    let (borrow, borrow_index) = obligation.find_liquidity_in_borrows(reserve_address)?;
    check_rollover_possible(
        market,
        reserve_address,
        reserve,
        reserve_address, // no typo - target reserve same as source reserve
        reserve,
        obligation,
        borrow,
        clock,
    )?;
    check_same_reserve_rollover_liquidity_available(reserve, borrow)?;
    check_below_reserve_borrow_limit(reserve, Fraction::ZERO)?;
    check_below_reserve_utilization_limit(reserve, Fraction::ZERO)?;
    check_borrow_limit_outside_elevation_group_not_exceeded(reserve)?; // Note: earlier, we check that the obligation is not in elevation group, so here we only need to care about this variant

    // The actual "rollover" operation looks disappointingly easy in the "same reserve" case:
    let borrow = obligation.get_active_borrow_mut(borrow_index)?; // re-borrow the borrow, this time mut
    borrow.last_borrowed_at_timestamp = u64::try_from(clock.unix_timestamp).unwrap(); // normally, any borrow does this; here we have to move the timestamp manually, because we do not borrow even 1 lamport more
    borrow.borrowed_amount_at_expiration = 0; // the debt has just been prolonged above - hence the "amount at expiration" should be zeroed

    // A regular "borrow" would also mark the reserve as updated, but we actually only touch the obligation:
    obligation.last_update.mark_stale();

    // There is no "effects" of this operation (i.e. no transfers happen):
    Ok(())
}

/// Rollovers (or migrates) a loan using a different reserve.
///
/// Covers fixed-to-fixed, fixed-to-open, and open-to-fixed flavors.
///
/// This mode re-uses more common parts of regular repay and borrow operations (compared to the
/// trivial [rollover_borrow_into_same_reserve()]). However, it still skips some aspects, and here
/// is their complete list:
///
/// 1) No `has_debt` update nor obligation orders' purge/checks.
///    - on rollover, the obligation conceptually has debt at all times,
///    - the number of borrows cannot go up (i.e. a single-debt obligation will stay single-debt).
///
/// 2) No borrow fees.
///    - by a business decision, rollover does not imply (re-)origination fee,
///    - and by extension, we do not handle referrer fee either.
pub fn rollover_borrow_into_different_reserve(
    market: &LendingMarket,
    source_reserve_address: Pubkey,
    source_reserve: &mut Reserve,
    target_reserve_address: Pubkey,
    target_reserve: &mut Reserve,
    obligation: &mut Obligation,
    clock: &Clock,
) -> Result<FixedTermRolloverResult> {
    // Check the non-accounting preconditions for rollover:
    let (source_borrow, source_borrow_index) =
        obligation.find_liquidity_in_borrows(source_reserve_address)?;
    check_rollover_possible(
        market,
        source_reserve_address,
        source_reserve,
        target_reserve_address,
        target_reserve,
        obligation,
        source_borrow,
        clock,
    )?;

    // Rollover into a different reserve means "repaying in the source reserve accounting, borrowing
    // in the target reserve accounting, and transferring the actual funds between the reserves":
    let full_borrow_amount = source_borrow.borrowed_amount();
    let timestamp = u64::try_from(clock.unix_timestamp).unwrap();
    let tokens_to_transfer_over = min(
        target_reserve.borrowable_liquidity_amount_outside_elevation_group(timestamp)?, // when successful, this always returns >= 1
        full_borrow_amount.to_ceil(), // since we do not keep 0s in `borrows`, this also is >= 1 (due to ceil())
    );

    // For partial rollovers, enforce the minimum dollar value threshold:
    let is_full_rollover = Fraction::from(tokens_to_transfer_over) >= full_borrow_amount;
    if !is_full_rollover {
        let rollover_value = calculate_market_value_from_liquidity_amount(
            target_reserve,
            Fraction::from(tokens_to_transfer_over),
        );
        if rollover_value < market.min_partial_rollover_value {
            msg!(
                "Partial rollover value {} below minimum {}",
                rollover_value.to_display(),
                market.min_partial_rollover_value
            );
            return err!(LendingError::PartialRolloverValueTooSmall);
        }
    }

    // We borrow full lamports, but we repay only up to the entire debt (that may be fractional):
    let borrowed_amount = Fraction::from(tokens_to_transfer_over);
    let repaid_amount = min(borrowed_amount, full_borrow_amount);
    let obligation_borrowed_amount_increase = borrowed_amount - repaid_amount;

    // Make sure the obligation can handle the increased debt:
    check_below_obligation_allowed_borrow_value(
        obligation,
        target_reserve,
        obligation_borrowed_amount_increase,
    )?;

    // Update withdrawal caps on source and target reserves: (same as what a regular repay and borrow would do)
    // Note: these calls also do limit checks, but since we already took the withdrawal caps into
    // account (when calculating tokens_to_transfer_over), we do not expect violations here (except
    // maybe in case of weird rounding).
    sub_from_withdrawal_accum(
        &mut source_reserve.config.debt_withdrawal_cap,
        tokens_to_transfer_over,
        timestamp,
    )?;
    add_to_withdrawal_accum(
        &mut target_reserve.config.debt_withdrawal_cap,
        tokens_to_transfer_over,
        timestamp,
    )?;

    // Repay and borrow on the reserves' level:
    source_reserve
        .liquidity
        .repay(tokens_to_transfer_over, repaid_amount)?;
    target_reserve.borrow(borrowed_amount, false)?; // not using withdraw queue

    // Preserve the current rollover config when applicable:
    let preserved_rollover_config = if preserves_rollover_config(source_borrow, target_reserve) {
        source_borrow.fixed_term_borrow_rollover_config
    } else {
        FixedTermBorrowRolloverConfig::default()
    };

    // Repay and borrow on the obligation's level:
    obligation.repay(repaid_amount, source_borrow_index);
    let (target_borrow, target_borrow_index) = obligation.find_or_add_liquidity_to_borrows(
        target_reserve_address,
        BigFraction::from(target_reserve.liquidity.cumulative_borrow_rate_bsf),
    )?;
    target_borrow.borrow(borrowed_amount, timestamp);
    target_borrow.borrowed_amount_at_expiration = 0; // The target borrow (even if pre-existed and expired!) has just been prolonged by the borrow() above - hence the "amount at expiration" should be zeroed

    // Propagate the rollover/migration config to the new borrow (see resolution above):
    target_borrow.fixed_term_borrow_rollover_config = preserved_rollover_config;

    // Update (and check) the outside-elevation-group debt trackers:
    utils::update_elevation_group_debt_trackers_on_rollover(
        obligation,
        tokens_to_transfer_over,
        source_reserve,
        target_reserve,
        source_reserve_address,
        target_borrow_index,
    )?;

    // A partial rollover into a different reserve may increase the number of borrows, and some obligation orders
    obligation_order_operations::check_orders_supported_after_user_operation(obligation)?;

    // We touched the accounting on all of these:
    source_reserve.last_update.mark_stale();
    target_reserve.last_update.mark_stale();
    obligation.last_update.mark_stale();

    // The effects here only involve moving liquidity between reserves:
    Ok(FixedTermRolloverResult {
        repaid_amount,
        borrowed_amount,
        tokens_to_transfer_over,
    })
}

/// Checks that:
/// - the configuration allows repaying and borrowing from corresponding reserves,
/// - the rollover happens in the appropriate time window,
/// - and the target reserve has the same borrow factor as the source (to avoid affecting LTV).
#[allow(clippy::too_many_arguments)]
fn check_rollover_possible(
    market: &LendingMarket,
    source_reserve_address: Pubkey,
    source_reserve: &Reserve,
    target_reserve_address: Pubkey,
    target_reserve: &Reserve,
    obligation: &Obligation,
    source_borrow: &ObligationLiquidity,
    clock: &Clock,
) -> Result<()> {
    // Rollovers are not supported for obligations that are in an elevation group:
    if obligation.elevation_group != ELEVATION_GROUP_NONE {
        // Note on rationale:
        // Technically, a rollover into same reserve *could* be successful while in an elevation
        // group. However, it definitely would not be possible for the "different reserve" case
        // (if the obligation was in any group, then the rollover's target reserve would violate it,
        // since an elevation group has exactly one configured debt reserve). For consistency and
        // simplicity, we ban rollovers in elevation groups entirely.
        msg!("Cannot rollover an obligation that is in an elevation group");
        return err!(LendingError::RolloverNotSupportedInElevationGroup);
    }

    // Check if the configuration does not preclude repaying + borrowing in general:
    check_repay_possible(source_reserve, obligation, clock)?;
    check_borrow_possible(market, target_reserve, obligation, clock)?;

    // Check that the target reserve has the same borrow factor as the source:
    if target_reserve.config.borrow_factor_pct != source_reserve.config.borrow_factor_pct {
        xmsg!(
            "Target reserve borrow factor ({}) is different from source reserve's ({})",
            target_reserve.config.borrow_factor_pct,
            source_reserve.config.borrow_factor_pct
        );
        return err!(LendingError::ObligationBorrowRolloverTargetReserveMismatch);
    }

    // Find out which rollover flavor this is:
    let rollover_mode = source_borrow
        .fixed_term_borrow_rollover_config
        .resolve_rollover_mode(&source_reserve.config, &target_reserve.config)?;

    // Check any time requirements this implies:
    match market.resolve_allowed_rollover_time(rollover_mode)? {
        AllowedRolloverTime::Always => {
            // Nothing to check regarding time.
        }
        AllowedRolloverTime::BeforeDebtExpiration(window_seconds) => {
            check_within_rollover_window(source_reserve, source_borrow, window_seconds, clock)?;
        }
    }

    // If the (different) target reserve has a pre-existing borrow slot, we do have additional constraints:
    if source_reserve_address != target_reserve_address {
        if let Ok((existing_target_borrow, _)) =
            obligation.find_liquidity_in_borrows(target_reserve_address)
        {
            check_rollover_into_existing_slot_possible(
                source_borrow,
                existing_target_borrow,
                source_reserve,
                target_reserve,
            )?;
        }
    }

    // Note: unlike for target reserve, there are no specific requirements regarding the source
    // reserve's accounting - if repaying is generally possible (i.e. reserve/obligation not stale),
    // then repaying any amount is allowed.

    Ok(())
}

/// Determines whether the [ObligationLiquidity::fixed_term_borrow_rollover_config] should be left
/// as-is (rather than being cleared) after the given rollover operation.
fn preserves_rollover_config(
    source_borrow: &ObligationLiquidity,
    target_reserve: &Reserve,
) -> bool {
    // If the target reserve is fixed-term, then we want to keep rolling over the same way in the future...
    target_reserve.config.get_debt_term_seconds().is_some()
        // ... and even if migrating to open-term, we want to allow the migration trip back *if the user opted-in* for that:
        || source_borrow.fixed_term_borrow_rollover_config.is_migration_to_fixed_enabled()
}

/// Checks that the source borrow can be merged into an already-existing target borrow slot (i.e.
/// when the obligation already borrows from the target reserve).
///
/// Importantly, this requires identical rollover configurations on source and target borrows.
/// Additionally, this operation must prolong the remaining borrow duration (if the source borrow is
/// fixed-term). As a special case, rolling over from open- to fixed-term is also allowed here (i.e.
/// we assume that `migration_to_fixed_enabled` opt-in was already checked).
///
/// Visibility note: this is `pub(crate)` only for unit-test's purposes.
pub(crate) fn check_rollover_into_existing_slot_possible(
    source_borrow: &ObligationLiquidity,
    target_borrow: &ObligationLiquidity,
    source_reserve: &Reserve,
    target_reserve: &Reserve,
) -> Result<()> {
    // The rollover configs must match (so that we don't silently change the user's rollover preferences):
    if source_borrow.fixed_term_borrow_rollover_config
        != target_borrow.fixed_term_borrow_rollover_config
    {
        msg!("Source and target borrow slots have different rollover configs");
        return err!(LendingError::ObligationBorrowRolloverConfigMismatch);
    }

    // The target's remaining duration must be > the source's (so that we avoid possible "oscillation" between reserves):
    match (
        source_borrow.get_debt_term_end_timestamp(&source_reserve.config),
        target_borrow.get_debt_term_end_timestamp(&target_reserve.config),
    ) {
        (Some(source_end_timestamp), Some(target_end_timestamp)) => {
            if target_end_timestamp <= source_end_timestamp {
                msg!(
                    "Target borrow term end {} <= source borrow term end {}",
                    target_end_timestamp,
                    source_end_timestamp,
                );
                err!(LendingError::ObligationBorrowRolloverMustProlongDebtTerm)
            } else {
                // Even though we cannot offer full debt-term (because of merging into some existing
                // borrow), we still improve the borrower's situation (regarding the remaining debt
                // duration), so we allow this.
                Ok(())
            }
        }
        (None, Some(_target_end_timestamp)) => {
            // Source is open-term, target is fixed-term: this technically "shortens" the debt term,
            // but the user has agreed to this via `migration_to_fixed_enabled = true` in rollover
            // config (i.e. we are already past the `check_migration_to_fixed_term_possible()`).
            Ok(())
        }
        (Some(_source_end_timestamp), None) => {
            // Target is open-term (i.e. the user agreed to `open_term_allowed = true`), so we allow
            // this, similar as above.
            Ok(())
        }
        (None, None) => {
            panic!("Unreachable: rollover from open- to open-term");
        }
    }
}

/// Checks that the current timestamp is within the given rollover window (i.e. close enough to the
/// debt term expiration).
fn check_within_rollover_window(
    source_reserve: &Reserve,
    source_borrow: &ObligationLiquidity,
    rollover_window_duration_seconds: u64,
    clock: &Clock,
) -> Result<()> {
    // Find out when the current borrow ends:
    let Some(debt_term_end_timestamp) =
        source_borrow.get_debt_term_end_timestamp(&source_reserve.config)
    else {
        // We can only reach this line in an "impossible" case of a very old borrow that did not track its start timestamp: (and the getter already logs this fact)
        return err!(LendingError::ObligationBorrowRolloverNotApplicable);
    };

    // And check it against the configured rollover time window:
    let timestamp = u64::try_from(clock.unix_timestamp).unwrap();
    let seconds_until_debt_term_end = debt_term_end_timestamp.saturating_sub(timestamp);
    if rollover_window_duration_seconds < seconds_until_debt_term_end {
        msg!(
            "Borrow debt term ends at {} (in {} seconds), outside the {} seconds rollover window",
            debt_term_end_timestamp,
            seconds_until_debt_term_end,
            rollover_window_duration_seconds
        );
        return err!(LendingError::ObligationBorrowOutsideRolloverWindow);
    }

    Ok(())
}

/// Checks that the reserve has enough freely-available liquidity for "same reserve" rollover.
///
/// Note: the "different reserve" flavor does not need this kind of explicit check, since it re-uses
/// the [Reserve::borrow()] logic, which includes the regular freely-available liquidity check.
fn check_same_reserve_rollover_liquidity_available(
    reserve: &Reserve,
    borrow: &ObligationLiquidity,
) -> Result<()> {
    let rollover_amount = borrow.borrowed_amount();
    // We should not compare against the `reserve.freely_available_liquidity_amount()` - instead,
    // we are interested in a theoretical amount that includes the repay of current debt. Hence,
    // we recreate the (adjusted) computation below:
    let total_available_liquidity_after_repay =
        Fraction::from(reserve.liquidity.total_available_amount) + rollover_amount;
    let freely_available_liquidity_after_repay = total_available_liquidity_after_repay
        .saturating_sub(Fraction::from(reserve.queued_liquidity_amount()));
    if rollover_amount > freely_available_liquidity_after_repay {
        msg!(
            "Rolling over {} would exceed the target reserve's freely-available liquidity {}",
            rollover_amount,
            freely_available_liquidity_after_repay,
        );
        return err!(LendingError::InsufficientLiquidity);
    }
    Ok(())
}

fn check_min_withdrawn_queued_liquidity_value(
    lending_market: &LendingMarket,
    reserve: &Reserve,
    liquidity_amount_to_withdraw: u64,
    ticket_emptied: bool,
) -> Result<()> {
    if ticket_emptied {
        return Ok(()); // if this closes a ticket, we have to allow any amount (otherwise it would be a liveness-break)
    }
    let liquidity_value_to_withdraw = calculate_market_value_from_liquidity_amount(
        reserve,
        Fraction::from_num(liquidity_amount_to_withdraw),
    );
    if liquidity_value_to_withdraw < lending_market.min_withdraw_queued_liquidity_value {
        xmsg!(
            "Withdrawn liquidity {} would have value {}, lower than the configured minimum {}",
            liquidity_amount_to_withdraw,
            liquidity_value_to_withdraw.to_display(),
            lending_market.min_withdraw_queued_liquidity_value
        );
        return err!(LendingError::WithdrawQueuedLiquidityValueTooSmall);
    }
    Ok(())
}

fn check_ltv_not_worse_if_marked_for_deleveraging(
    obligation: &Obligation,
    initial_ltv: Fraction,
    resulting_borrow_factor_adjusted_debt_value: Fraction,
    resulting_deposited_value: Fraction,
) -> Result<()> {
    if obligation.is_marked_for_deleveraging() {
        let resulting_ltv = resulting_borrow_factor_adjusted_debt_value / resulting_deposited_value;
        if resulting_ltv > initial_ltv {
            msg!(
                "Obligation marked for deleveraging - cannot worsen its LTV from {} to {}",
                initial_ltv,
                resulting_ltv
            );
            return err!(LendingError::WorseLtvBlocked);
        }
    }
    Ok(())
}

/// Checks that the utilization rate after additionally borrowing the given amount is below the
/// given reserve's configured limit.
pub fn check_below_reserve_utilization_limit(
    reserve: &Reserve,
    borrow_amount: Fraction,
) -> Result<()> {
    let new_utilization_rate =
        (reserve.liquidity.total_borrow() + borrow_amount) / reserve.liquidity.total_supply();
    let utilization_limit = reserve.config.utilization_limit_block_borrowing_above_pct;
    // Note: deliberate `>=` - that's how our logic has always interpreted this limit
    if new_utilization_rate >= Fraction::from_percent(utilization_limit) && utilization_limit != 0 {
        msg!(
            "Borrowing above utilization rate is disabled, current {}, new {}, limit {}",
            reserve.liquidity.utilization_rate().to_display(),
            new_utilization_rate.to_display(),
            utilization_limit
        );
        return err!(LendingError::BorrowingAboveUtilizationRateDisabled);
    }
    Ok(())
}

/// Checks that the target reserve has enough room below its configured absolute borrow limit.
pub fn check_below_reserve_borrow_limit(reserve: &Reserve, borrow_amount: Fraction) -> Result<()> {
    let new_total_borrow = reserve.liquidity.total_borrow() + borrow_amount;
    // Note: contrary to the `utilization_limit_block_borrowing_above_pct`, we correctly use `>` here
    if new_total_borrow > Fraction::from(reserve.config.borrow_limit) {
        msg!(
            "Borrowing {} more would exceed the target reserve's limit {} (current: {})",
            borrow_amount.to_display(),
            reserve.config.borrow_limit,
            reserve.liquidity.total_borrow().to_display()
        );
        return err!(LendingError::BorrowLimitExceeded);
    }
    Ok(())
}

/// Checks that `borrow_limit_outside_elevation_group` has not been exceeded on the given reserve.
///
/// This is needed for rollover into same reserve - even though such operation does not increase
/// borrowed amount, the limit may have been lowered administratively (and the admin's intent was to
/// wind down borrowing, including "not extending current loans").
fn check_borrow_limit_outside_elevation_group_not_exceeded(reserve: &Reserve) -> Result<()> {
    if reserve.borrowed_amount_outside_elevation_group
        > reserve.config.borrow_limit_outside_elevation_group
    {
        msg!(
            "Borrowed amount outside elevation group {} exceeds the limit {}",
            reserve.borrowed_amount_outside_elevation_group,
            reserve.config.borrow_limit_outside_elevation_group,
        );
        return err!(LendingError::ElevationGroupBorrowLimitExceeded);
    }
    Ok(())
}

/// Checks that the obligation's borrow value after additionally borrowing the given amount is below
/// its maximum allowed borrow value.
pub fn check_below_obligation_allowed_borrow_value(
    obligation: &Obligation,
    reserve: &Reserve,
    borrowed_amount_increase: Fraction,
) -> Result<()> {
    // An LTV check equivalent to that in `calculate_borrow_exact()`:
    let borrowed_value_increase = reserve
        .liquidity
        .liquidity_amount_to_market_value(borrowed_amount_increase);
    let bf_adjusted_borrowed_value_increase = borrowed_value_increase
        * reserve.borrow_factor_f(obligation.elevation_group != ELEVATION_GROUP_NONE);
    require_gte!(
        obligation.remaining_borrow_value(),
        bf_adjusted_borrowed_value_increase,
        LendingError::BorrowTooLarge,
    );
    Ok(())
}

/// Remove the tracked debts of the elevation group from the reserves (prepare for change of elevation group)
pub(crate) fn reset_elevation_group_debts<'info, T>(
    obligation: &mut Obligation,
    elevation_group: Option<&ElevationGroup>,
    deposit_reserves_iter: impl Iterator<Item = T> + Clone,
    borrow_reserves_iter: impl Iterator<Item = T> + Clone,
) -> Result<()>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    // Reset tracked debts on collaterals
    if let Some(elevation_group) = elevation_group {
        let elevation_group_index = elevation_group.get_index();
        let deposits_and_reserves = obligation
            .active_deposits_mut()
            .zip_exact(deposit_reserves_iter);
        for deposit_and_reserve in deposits_and_reserves {
            let (deposit, reserve) =
                deposit_and_reserve.map_err(|_| error!(LendingError::InvalidAccountInput))?;
            require_keys_eq!(
                deposit.deposit_reserve,
                reserve.get_pubkey(),
                LendingError::InvalidAccountInput
            );

            let mut reserve = reserve.get_mut()?;

            reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                [elevation_group_index] = reserve
                .borrowed_amounts_against_this_reserve_in_elevation_groups[elevation_group_index]
                .saturating_sub(deposit.borrowed_amount_against_this_collateral_in_elevation_group);

            deposit.borrowed_amount_against_this_collateral_in_elevation_group = 0;
        }
    } else {
        // Reset tracked debts on borrows
        let borrows_and_reserves = obligation
            .active_borrows_mut()
            .zip_exact(borrow_reserves_iter);
        for borrow_and_reserve in borrows_and_reserves {
            let (borrow, reserve) =
                borrow_and_reserve.map_err(|_| error!(LendingError::InvalidAccountInput))?;
            let mut reserve = reserve.get_mut()?;
            reserve.borrowed_amount_outside_elevation_group = reserve
                .borrowed_amount_outside_elevation_group
                .saturating_sub(borrow.borrowed_amount_outside_elevation_groups);

            borrow.borrowed_amount_outside_elevation_groups = 0;
        }
    }

    Ok(())
}

pub fn refresh_obligation_deposits<'info, T>(
    obligation: &mut Obligation,
    lending_market: &LendingMarket,
    slot: Slot,
    elevation_group: Option<&ElevationGroup>,
    mut reserves_iter: impl Iterator<Item = T>,
    borrowed_amount_in_elevation_group: Option<u64>,
) -> Result<RefreshObligationDepositsResult>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    let mut lowest_deposit_liquidation_ltv_threshold_pct = u8::MAX;
    let mut lowest_deposit_max_ltv_pct = u8::MAX;
    let mut deposited_value = Fraction::ZERO;
    let mut allowed_borrow_value = Fraction::ZERO;
    let mut unhealthy_borrow_value = Fraction::ZERO;
    let mut num_of_obsolete_reserves = 0;
    let mut prices_state = PriceStatusFlags::all();
    let mut borrowing_disabled = false;

    let elevation_group_and_borrowed_amount: Option<(&ElevationGroup, u64)> = match (
        elevation_group,
        borrowed_amount_in_elevation_group,
    ) {
        (Some(elevation_group), Some(borrowed_amount)) => Some((elevation_group, borrowed_amount)),
        (None, None) => None,
        _ => {
            panic!("Elevation group and borrowed amount must be both set or both unset when refreshing deposits.");
        }
    };

    for (index, deposit) in obligation
        .deposits
        .iter_mut()
        .enumerate()
        .filter(|(_, deposit)| deposit.is_active())
    {
        let deposit_reserve = reserves_iter
            .next()
            .ok_or(error!(LendingError::InvalidAccountInput))?;

        let deposit_reserve_info_key = deposit_reserve.get_pubkey();

        let mut deposit_reserve = deposit_reserve
            .get_mut()
            .map_err(|_| error!(LendingError::InvalidAccountInput))?;

        // Handle both cases -- we blocked borrows for elevation group and/or blocked borrows for specific reserve
        if elevation_group.is_none()
            && deposit_reserve.config.disable_usage_as_coll_outside_emode > 0
        {
            borrowing_disabled = true;
        }

        if deposit_reserve.config.status() == ReserveStatus::Obsolete {
            num_of_obsolete_reserves += 1;
        }

        check_obligation_collateral_deposit_reserve(
            deposit,
            &deposit_reserve,
            deposit_reserve_info_key,
            index,
            slot,
        )?;

        if let Some((elevation_group, debt_amount)) = elevation_group_and_borrowed_amount {
            let elevation_group_index = elevation_group.get_index();
            require!(
                deposit_reserve
                    .config
                    .elevation_groups
                    .contains(&elevation_group.id),
                LendingError::InconsistentElevationGroup
            );

            require_keys_neq!(
                deposit_reserve_info_key,
                elevation_group.debt_reserve,
                LendingError::ElevationGroupDebtReserveAsCollateral
            );

            // Remove previous debt, add new and save the last refreshed debt
            deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                [elevation_group_index] = deposit_reserve
                .borrowed_amounts_against_this_reserve_in_elevation_groups[elevation_group_index]
                .saturating_sub(deposit.borrowed_amount_against_this_collateral_in_elevation_group);
            deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                [elevation_group_index] += debt_amount;
            deposit.borrowed_amount_against_this_collateral_in_elevation_group = debt_amount;
        }

        let market_value_f =
            calculate_obligation_collateral_market_value(&deposit_reserve, deposit);
        deposit.market_value_sf = market_value_f.to_bits();

        let (coll_ltv_pct, coll_liquidation_threshold_pct) =
            get_max_ltv_and_liquidation_threshold(&deposit_reserve, elevation_group);

        if market_value_f >= lending_market.min_value_skip_liquidation_ltv_checks
            && coll_liquidation_threshold_pct > 0
        {
            lowest_deposit_liquidation_ltv_threshold_pct =
                lowest_deposit_liquidation_ltv_threshold_pct.min(coll_liquidation_threshold_pct);
        }

        lowest_deposit_max_ltv_pct = lowest_deposit_max_ltv_pct.min(coll_ltv_pct);

        deposited_value = deposited_value.add(market_value_f);
        allowed_borrow_value += market_value_f * Fraction::from_percent(coll_ltv_pct);
        unhealthy_borrow_value +=
            market_value_f * Fraction::from_percent(coll_liquidation_threshold_pct);

        // Erase all price status flags that are not set in the reserve
        prices_state &= deposit_reserve.last_update.get_price_status();

        xmsg!(
            "Deposit: {} amount: {} value: {}",
            &deposit_reserve.config.token_info.symbol(),
            deposit_reserve
                .collateral_exchange_rate()
                .fraction_collateral_to_liquidity(deposit.deposited_amount.into())
                .to_display(),
            market_value_f.to_display()
        );
    }

    Ok(RefreshObligationDepositsResult {
        lowest_deposit_liquidation_ltv_threshold_pct,
        lowest_deposit_max_ltv_pct,
        num_of_obsolete_reserves,
        deposited_value_f: deposited_value,
        allowed_borrow_value_f: allowed_borrow_value,
        unhealthy_borrow_value_f: unhealthy_borrow_value,
        prices_state,
        borrowing_disabled,
    })
}

pub fn refresh_obligation_borrows<'info, T, U>(
    program_id: &Pubkey,
    obligation: &mut Obligation,
    lending_market: &LendingMarket,
    clock: &Clock,
    elevation_group: Option<&ElevationGroup>,
    mut reserves_iter: impl Iterator<Item = T>,
    mut referrer_token_states_iter: impl Iterator<Item = U>,
) -> Result<RefreshObligationBorrowsResult>
where
    T: AnyAccountLoader<'info, Reserve>,
    U: AnyAccountLoader<'info, ReferrerTokenState>,
{
    let mut borrowed_assets_market_value = Fraction::ZERO;
    let mut borrow_factor_adjusted_debt_value = Fraction::ZERO;
    let mut prices_state = PriceStatusFlags::all();
    let mut highest_borrow_factor_f = Fraction::ONE;
    let mut num_of_obsolete_reserves = 0;

    let obligation_has_referrer = obligation.has_referrer();
    let mut borrowed_amounts_accumulator_for_elevation_group = 0_u64;
    let mut num_borrow_reserves = 0;

    for (index, borrow) in obligation
        .borrows
        .iter_mut()
        .enumerate()
        .filter(|(_, borrow)| borrow.is_active())
    {
        num_borrow_reserves += 1;
        let borrow_reserve = reserves_iter
            .next()
            .ok_or(error!(LendingError::InvalidAccountInput))?;

        let borrow_reserve_info_key = borrow_reserve.get_pubkey();

        let borrow_reserve = &mut borrow_reserve
            .get_mut()
            .map_err(|_| error!(LendingError::InvalidAccountInput))?;

        check_obligation_liquidity_borrow_reserve(
            borrow,
            borrow_reserve,
            borrow_reserve_info_key,
            index,
            clock.slot,
        )?;

        let cumulative_borrow_rate_bf =
            BigFraction::from(borrow_reserve.liquidity.cumulative_borrow_rate_bsf);

        let previous_borrowed_amount_f = borrow.borrowed_amount();

        borrow.accrue_interest(cumulative_borrow_rate_bf)?;

        let borrowed_amount_f = borrow.borrowed_amount();
        let borrowed_amount = borrowed_amount_f.to_ceil::<u64>();
        borrowed_amounts_accumulator_for_elevation_group += borrowed_amount; // < This will be used only if we have a unique debt reserve

        // Check elevation group config and update debt if outside elevation group
        {
            if let Some(elevation_group) = elevation_group {
                require!(
                    borrow_reserve
                        .config
                        .elevation_groups
                        .contains(&elevation_group.id),
                    LendingError::InconsistentElevationGroup
                );
                // TODO: double check compatibility with deployed market, we shall be able to leave the elevation group if we have more
                // than one borrow reserve while being in an elevation group.
                require_keys_eq!(
                    borrow_reserve_info_key,
                    elevation_group.debt_reserve,
                    LendingError::ElevationGroupHasAnotherDebtReserve
                );
            } else {
                borrow_reserve.borrowed_amount_outside_elevation_group = borrow_reserve
                    .borrowed_amount_outside_elevation_group
                    .saturating_sub(borrow.borrowed_amount_outside_elevation_groups);
                borrow_reserve.borrowed_amount_outside_elevation_group += borrowed_amount;
                borrow.borrowed_amount_outside_elevation_groups = borrowed_amount;
            }
        }

        if borrow_reserve.config.status() == ReserveStatus::Obsolete {
            num_of_obsolete_reserves += 1;
        }

        accumulate_referrer_fees(
            program_id,
            borrow_reserve_info_key,
            borrow_reserve,
            &obligation.referrer,
            lending_market.referral_fee_bps,
            obligation.last_update.slots_elapsed(clock.slot)?,
            borrowed_amount_f,
            previous_borrowed_amount_f,
            obligation_has_referrer,
            &mut referrer_token_states_iter,
        )?;

        let market_value_f = calculate_obligation_liquidity_market_value(borrow_reserve, borrow);

        borrow.market_value_sf = market_value_f.to_bits();

        borrowed_assets_market_value += market_value_f;

        let borrow_factor_f = borrow_reserve.borrow_factor_f(elevation_group.is_some());

        if market_value_f >= lending_market.min_value_skip_liquidation_bf_checks {
            highest_borrow_factor_f = highest_borrow_factor_f.max(borrow_factor_f);
        }

        let borrow_factor_adjusted_market_value: Fraction = market_value_f * borrow_factor_f;
        borrow.borrow_factor_adjusted_market_value_sf =
            borrow_factor_adjusted_market_value.to_bits();

        borrow_factor_adjusted_debt_value += borrow_factor_adjusted_market_value;

        // Capture the value needed for throttling purposes (if it came to term-based liquidation):
        borrow.capture_borrowed_amount_at_expiration(
            &borrow_reserve.config,
            clock.unix_timestamp.try_into().unwrap(),
        );

        // Entering into the for loop means that the obligation has debt (borrow reserves != Pubkey::default)
        obligation.has_debt = 1;

        // Erase all price status flags that are not set in the reserve
        prices_state &= borrow_reserve.last_update.get_price_status();

        xmsg!(
            "Borrow: {} amount: {} value: {} value_bf: {}",
            &borrow_reserve.config.token_info.symbol(),
            borrow.borrowed_amount().to_display(),
            market_value_f.to_display(),
            borrow_factor_adjusted_market_value.to_display()
        );
    }

    let borrowed_amount_in_elevation_group = if elevation_group.is_some() {
        // If we are in an elevation group, there must be a unique debt reserve
        // We check that there is only one borrow reserve and return the borrowed amount
        require!(
            num_borrow_reserves <= 1,
            LendingError::InconsistentElevationGroup
        );
        Some(borrowed_amounts_accumulator_for_elevation_group)
    } else {
        None
    };

    Ok(RefreshObligationBorrowsResult {
        num_of_obsolete_reserves,
        borrowed_assets_market_value_f: borrowed_assets_market_value,
        borrow_factor_adjusted_debt_value_f: borrow_factor_adjusted_debt_value,
        borrowed_amount_in_elevation_group,
        prices_state,
        highest_borrow_factor_pct: highest_borrow_factor_f.to_percent::<u64>().unwrap(), // safe to unwrap: the Fraction is constructed from `borrow_factor_pct: u64` during the ix
    })
}

#[allow(clippy::too_many_arguments)]
pub fn refresh_obligation<'info, T, U>(
    program_id: &Pubkey,
    obligation: &mut Obligation,
    lending_market: &LendingMarket,
    clock: &Clock,
    mut deposit_reserves_iter: impl Iterator<Item = T>,
    mut borrow_reserves_iter: impl Iterator<Item = T>,
    mut referrer_token_states_iter: impl Iterator<Item = U>,
) -> Result<()>
where
    T: AnyAccountLoader<'info, Reserve>,
    U: AnyAccountLoader<'info, ReferrerTokenState>,
{
    let timestamp = clock.unix_timestamp.try_into().expect("negative timestamp");
    let slot = clock.slot;

    // For consistency pre asset-tiers obligation with post asset-tiers obligation
    let elevation_group = get_elevation_group(obligation.elevation_group, lending_market)?;

    let RefreshObligationBorrowsResult {
        num_of_obsolete_reserves: num_of_obsolete_borrow_reserves,
        borrow_factor_adjusted_debt_value_f,
        borrowed_assets_market_value_f,
        prices_state: borrows_prices_state,
        borrowed_amount_in_elevation_group,
        highest_borrow_factor_pct,
    } = refresh_obligation_borrows(
        program_id,
        obligation,
        lending_market,
        clock,
        elevation_group,
        &mut borrow_reserves_iter,
        &mut referrer_token_states_iter,
    )?;

    let RefreshObligationDepositsResult {
        lowest_deposit_liquidation_ltv_threshold_pct,
        lowest_deposit_max_ltv_pct,
        num_of_obsolete_reserves: num_of_obsolete_deposit_reserves,
        deposited_value_f,
        allowed_borrow_value_f: allowed_borrow_value,
        unhealthy_borrow_value_f: unhealthy_borrow_value,
        prices_state: deposits_prices_state,
        borrowing_disabled,
    } = refresh_obligation_deposits(
        obligation,
        lending_market,
        slot,
        elevation_group,
        &mut deposit_reserves_iter,
        borrowed_amount_in_elevation_group,
    )?;

    obligation.borrowed_assets_market_value_sf = borrowed_assets_market_value_f.to_bits();

    obligation.deposited_value_sf = deposited_value_f.to_bits();

    obligation.borrow_factor_adjusted_debt_value_sf = borrow_factor_adjusted_debt_value_f.to_bits();

    obligation.allowed_borrow_value_sf = min(
        allowed_borrow_value,
        Fraction::from(lending_market.global_allowed_borrow_value),
    )
    .to_bits();

    obligation.unhealthy_borrow_value_sf = unhealthy_borrow_value.to_bits();

    obligation.lowest_reserve_deposit_liquidation_ltv =
        lowest_deposit_liquidation_ltv_threshold_pct.into();
    obligation.lowest_reserve_deposit_max_ltv_pct = lowest_deposit_max_ltv_pct;

    obligation.num_of_obsolete_borrow_reserves = num_of_obsolete_borrow_reserves;
    obligation.num_of_obsolete_deposit_reserves = num_of_obsolete_deposit_reserves;

    obligation.borrowing_disabled = borrowing_disabled.into();
    obligation.highest_borrow_factor_pct = highest_borrow_factor_pct;

    obligation
        .borrow_order
        .clear_if_past_fillable_timestamp(timestamp);

    let prices_state = deposits_prices_state.intersection(borrows_prices_state);
    obligation.last_update.update_slot(slot, Some(prices_state));

    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub fn liquidate_and_redeem<'info, T>(
    lending_market: &LendingMarket,
    repay_reserve: &dyn AnyAccountLoader<Reserve>,
    withdraw_reserve: &dyn AnyAccountLoader<Reserve>,
    obligation: &mut Obligation,
    clock: &Clock,
    liquidity_amount: u64,
    min_acceptable_received_liquidity_amount: u64,
    max_allowed_ltv_override_pct_opt: Option<u64>,
    deposit_reserves_iter: impl Iterator<Item = T>,
) -> Result<LiquidateAndRedeemResult>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    let LiquidateObligationResult {
        settle_amount: _,
        repay_amount,
        withdraw_collateral_amount,
        withdraw_amount,
        liquidation_bonus_rate,
        liquidation_reason,
    } = liquidate_obligation(
        lending_market,
        repay_reserve,
        withdraw_reserve,
        obligation,
        clock,
        liquidity_amount,
        max_allowed_ltv_override_pct_opt,
        deposit_reserves_iter,
    )?;

    let withdraw_reserve = &mut withdraw_reserve.get_mut()?;

    let total_withdraw_liquidity_amount = post_liquidate_redeem(
        withdraw_reserve,
        repay_amount,
        withdraw_amount,
        withdraw_collateral_amount,
        liquidation_bonus_rate,
        liquidation_reason,
        min_acceptable_received_liquidity_amount,
        clock,
    )?;

    Ok(LiquidateAndRedeemResult {
        repay_amount,
        withdraw_amount,
        total_withdraw_liquidity_amount,
        withdraw_collateral_amount,
        liquidation_reason,
    })
}

#[allow(clippy::too_many_arguments)]
pub fn liquidate_obligation<'info, T>(
    lending_market: &LendingMarket,
    repay_reserve: &dyn AnyAccountLoader<Reserve>,
    withdraw_reserve: &dyn AnyAccountLoader<Reserve>,
    obligation: &mut Obligation,
    clock: &Clock,
    liquidity_amount: u64,
    max_allowed_ltv_override_pct_opt: Option<u64>,
    deposit_reserves_iter: impl Iterator<Item = T>,
) -> Result<LiquidateObligationResult>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    xmsg!(
        "Liquidating liquidation_close_factor_pct: {}, liquidation_max_value: {}",
        lending_market.liquidation_max_debt_close_factor_pct,
        lending_market.max_liquidatable_debt_market_value_at_once
    );
    // Warning: repay and withdraw reserves might be the same, we can't load mut both at the same time
    let repay_reserve_ref = repay_reserve.get()?;
    let withdraw_reserve_ref = withdraw_reserve.get()?;

    let elevation_group = get_elevation_group(obligation.elevation_group, lending_market)?;
    let (_, collateral_liquidation_threshold_pct) =
        get_max_ltv_and_liquidation_threshold(&withdraw_reserve_ref, elevation_group);

    if collateral_liquidation_threshold_pct == 0 {
        xmsg!(
            "Liquidation threshold of the withdraw reserve is 0 and can't be used for liquidation"
        );
        return err!(LendingError::CollateralNonLiquidatable);
    }

    utils::assert_obligation_liquidatable(
        &repay_reserve_ref,
        &withdraw_reserve_ref,
        obligation,
        liquidity_amount,
        clock.slot,
    )?;

    let (liquidity, liquidity_index) =
        obligation.find_liquidity_in_borrows(repay_reserve.get_pubkey())?;
    if liquidity.borrow_factor_adjusted_market_value_sf == 0 {
        msg!("Obligation borrow value is zero");
        return err!(LendingError::ObligationLiquidityEmpty);
    }

    let collateral_index =
        obligation.position_of_collateral_in_deposits(withdraw_reserve.get_pubkey())?;
    let collateral = &obligation.deposits[collateral_index];
    if collateral.market_value_sf == 0 {
        msg!("Obligation deposit value is zero");
        return err!(LendingError::ObligationCollateralEmpty);
    }

    // Can still liquidate dust amounts, only not blocking the big amounts
    let is_debt_reserve_highest_borrow_factor =
        repay_reserve_ref.config.borrow_factor_pct >= obligation.highest_borrow_factor_pct;

    let is_collateral_reserve_lowest_liquidation_ltv = collateral_liquidation_threshold_pct as u64
        <= obligation.lowest_reserve_deposit_liquidation_ltv;

    let CalculateLiquidationResult {
        settle_amount,
        repay_amount,
        withdraw_amount,
        liquidation_bonus_rate,
        liquidation_reason,
    } = liquidation_operations::calculate_liquidation(
        &withdraw_reserve_ref,
        &repay_reserve_ref,
        liquidity_amount,
        lending_market,
        obligation,
        liquidity,
        collateral,
        u64::try_from(clock.unix_timestamp).unwrap(),
        is_debt_reserve_highest_borrow_factor,
        is_collateral_reserve_lowest_liquidation_ltv,
        max_allowed_ltv_override_pct_opt,
    )?;

    let is_full_withdrawal = collateral.deposited_amount == withdraw_amount;

    // Drop the non mut ref to allow the following mutations one by one
    drop(repay_reserve_ref);
    drop(withdraw_reserve_ref);

    let previous_borrowed_amount_against_this_collateral_in_elevation_group;
    {
        let mut repay_reserve_ref_mut = repay_reserve.get_mut()?;

        utils::update_elevation_group_debt_trackers_on_repay(
            repay_amount,
            obligation,
            liquidity_index,
            &mut repay_reserve_ref_mut,
            deposit_reserves_iter,
        )?;

        // Save the current tracker value now in case it get deleted in the following step because
        // of a full withdrawal
        previous_borrowed_amount_against_this_collateral_in_elevation_group = obligation.deposits
            [collateral_index]
            .borrowed_amount_against_this_collateral_in_elevation_group;

        utils::repay_and_withdraw_from_obligation_post_liquidation(
            obligation,
            &mut repay_reserve_ref_mut,
            settle_amount,
            withdraw_amount,
            repay_amount,
            liquidity_index,
            collateral_index,
        )?;
    }

    if obligation.has_debt() {
        // if there is any debt left...
        if let LiquidationReason::ObligationOrder(obligation_order_index) = liquidation_reason {
            // ...and an order was used for liquidation, then we have to update this order's state:
            let order = &mut obligation.obligation_orders[obligation_order_index];
            order.consume(repay_amount);
        }
    }

    let mut withdraw_reserve_ref_mut = withdraw_reserve.get_mut()?;
    let withdraw_collateral_amount = {
        refresh_reserve(
            &mut withdraw_reserve_ref_mut,
            clock,
            None,
            lending_market.referral_fee_bps,
            lending_market.reserve_rewards_max_apr_bps,
        )?;
        let redeem_collateral_options = RedeemCollateralOptions::resolve(liquidation_reason);
        let max_redeemable_collateral = if redeem_collateral_options.use_withdraw_queue {
            withdraw_reserve_ref_mut.total_redeemable_collateral_amount()
        } else {
            withdraw_reserve_ref_mut.freely_redeemable_collateral_amount()
        };
        min(withdraw_amount, max_redeemable_collateral)
    };
    if is_full_withdrawal {
        utils::update_elevation_group_debt_trackers_on_full_withdraw(
            previous_borrowed_amount_against_this_collateral_in_elevation_group,
            obligation.elevation_group,
            &mut withdraw_reserve_ref_mut,
        )?;
    }

    Ok(LiquidateObligationResult {
        settle_amount,
        repay_amount,
        withdraw_amount,
        withdraw_collateral_amount,
        liquidation_bonus_rate,
        liquidation_reason,
    })
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn post_liquidate_redeem(
    withdraw_reserve: &mut Reserve,
    repay_amount: u64,
    withdraw_amount: u64,
    withdraw_collateral_amount: u64,
    liquidation_bonus_rate: Fraction,
    liquidation_reason: LiquidationReason,
    min_acceptable_received_liquidity_amount: u64,
    clock: &Clock,
) -> Result<Option<(u64, u64)>> {
    // if there is liquidity redeem it
    if withdraw_collateral_amount != 0 {
        let withdraw_liquidity_amount = redeem_reserve_collateral(
            withdraw_reserve,
            withdraw_collateral_amount,
            clock,
            RedeemCollateralOptions::resolve(liquidation_reason),
        )?;
        let protocol_liquidation_fee_pct = match liquidation_reason {
            LiquidationReason::LtvExceeded
            | LiquidationReason::IndividualDeleveraging
            | LiquidationReason::MarketWideDeleveraging
            | LiquidationReason::ReserveDebtMaturityReached
            | LiquidationReason::ObligationBorrowDebtTermReached(_) => {
                withdraw_reserve.config.protocol_liquidation_fee_pct
            }
            LiquidationReason::ObligationOrder(_) => {
                withdraw_reserve.config.protocol_order_execution_fee_pct
            }
        };
        let protocol_liquidation_fee = liquidation_operations::calculate_protocol_liquidation_fee(
            withdraw_liquidity_amount,
            liquidation_bonus_rate,
            protocol_liquidation_fee_pct,
        );
        let net_withdraw_liquidity_amount = withdraw_liquidity_amount - protocol_liquidation_fee;
        xmsg!(
            "pnl: Liquidator repaid {} and withdrew {} collateral with fees {}",
            repay_amount,
            net_withdraw_liquidity_amount,
            protocol_liquidation_fee
        );

        if net_withdraw_liquidity_amount < min_acceptable_received_liquidity_amount {
            return err!(LendingError::LiquidationRewardTooSmall);
        }

        // Protocol fee is subtracted from withdraw liquidity amount in token transfers
        Ok(Some((withdraw_liquidity_amount, protocol_liquidation_fee)))
    } else {
        let theoretical_withdraw_liquidity_amount = withdraw_reserve
            .collateral_exchange_rate()
            .collateral_to_liquidity(withdraw_amount);

        if theoretical_withdraw_liquidity_amount < min_acceptable_received_liquidity_amount {
            return err!(LendingError::LiquidationRewardTooSmall);
        }

        xmsg!(
            "pnl: Liquidator repaid {} and withdrew {} ctokens",
            repay_amount,
            withdraw_amount
        );
        Ok(None)
    }
}

pub fn flash_borrow_reserve_liquidity(reserve: &mut Reserve, liquidity_amount: u64) -> Result<()> {
    if reserve.config.fees.flash_loan_fee_sf == u64::MAX {
        msg!("Flash loans are disabled for this reserve");
        return err!(LendingError::FlashLoansDisabled);
    }

    // Borrow limits do not apply to flash operations
    // let borrowed_amount_f = reserve.liquidity.total_borrow();
    let liquidity_amount_f = Fraction::from(liquidity_amount);
    // let borrow_limit_f = Fraction::from(reserve.config.borrow_limit);
    // let new_total_borrow_f = borrowed_amount_f + liquidity_amount_f;
    // if new_total_borrow_f > borrow_limit_f {
    //     msg!(
    //         "Cannot borrow above the borrow limit. New total borrow: {} > limit: {}",
    //         new_total_borrow_f,
    //         reserve.config.borrow_limit
    //     );
    //     return err!(LendingError::InvalidAmount);
    // }

    reserve.borrow(liquidity_amount_f, true)?;
    reserve.last_update.mark_stale();

    Ok(())
}

pub fn flash_repay_reserve_liquidity<'info, T>(
    lending_market: &LendingMarket,
    reserve: &mut Reserve,
    liquidity_amount: u64,
    timestamp: u64,
    referrer_token_state_loader: Option<&T>,
) -> Result<(u64, u64)>
where
    T: AnyAccountLoader<'info, ReferrerTokenState>,
{
    let flash_loan_amount = liquidity_amount;

    let flash_loan_amount_f = Fraction::from(flash_loan_amount);
    let (protocol_fee, referrer_fee) = reserve.config.fees.calculate_flash_loan_fees(
        flash_loan_amount_f,
        lending_market.referral_fee_bps,
        referrer_token_state_loader.is_some(),
    )?;

    reserve
        .liquidity
        .repay(flash_loan_amount, flash_loan_amount_f)?;
    // refresh the reserve/deposit timestamps to ensure they cannot be manipulated without risk of capital
    refresh_reserve_limit_timestamps(reserve, timestamp);
    reserve.last_update.mark_stale();

    if let Some(referrer_token_state_loader) = referrer_token_state_loader {
        if lending_market.referral_fee_bps > 0 {
            let referrer_token_state = &mut referrer_token_state_loader.get_mut()?;

            add_referrer_fee(
                reserve,
                referrer_token_state,
                Fraction::from_num(referrer_fee),
            )?;

            reserve.liquidity.total_available_amount += referrer_fee;
        }
    }

    let flash_loan_amount_with_referral_fee = flash_loan_amount + referrer_fee;

    Ok((flash_loan_amount_with_referral_fee, protocol_fee))
}

pub fn socialize_loss<'info, T>(
    reserve: &mut Reserve,
    reserve_pk: &Pubkey,
    obligation: &mut Obligation,
    liquidity_amount: u64,
    slot: u64,
    deposit_reserves_iter: impl Iterator<Item = T>,
) -> Result<Fraction>
where
    T: AnyAccountLoader<'info, Reserve>,
{
    if reserve
        .last_update
        .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?
    {
        msg!(
            "Reserve is stale and must be refreshed in the current slot, price status: {:08b}",
            reserve.last_update.get_price_status().0
        );
        return Err(LendingError::ReserveStale.into());
    }

    if obligation
        .last_update
        .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?
    {
        msg!(
            "Obligation is stale and must be refreshed in the current slot, price status: {:08b}",
            obligation.last_update.get_price_status().0
        );
        return Err(LendingError::ObligationStale.into());
    }

    if !obligation.is_active_deposits_empty() {
        msg!("Obligation hasn't been fully liquidated!");
        return Err(LendingError::CannotSocializeObligationWithCollateral.into());
    }

    if obligation.is_active_deposits_empty() && obligation.is_active_borrows_empty() {
        msg!("Obligation has no deposits or borrows");
        return Err(LendingError::ObligationEmpty.into());
    }

    let (liquidity, liquidity_index) = obligation.find_liquidity_in_borrows(*reserve_pk)?;

    // with socialize_loss, ctoken_exchange_rate grows bigger,
    // because the total supply is reduced (from the ratio: collateral_mint_supply / total_supply)
    // however, total_supply can -> to 0, hence ctoken_rate -> infinity (in theory)
    // however, there's a special case, when total_supply becomes 0 after loss socialization
    // the reserve becomes unusable after this operation

    let liquidity_amount_f = Fraction::from(liquidity_amount);
    let borrowed_amount_f = liquidity.borrowed_amount();
    let forgive_amount_f = min(liquidity_amount_f, borrowed_amount_f);

    if forgive_amount_f >= reserve.liquidity.total_supply() {
        msg!("Reserve becomes deprecated");
        reserve.version = u64::MAX;
    }

    msg!("Forgiving debt amount {}", forgive_amount_f.to_display());

    utils::update_elevation_group_debt_trackers_on_repay(
        forgive_amount_f.to_ceil(),
        obligation,
        liquidity_index,
        reserve,
        deposit_reserves_iter,
    )?;

    reserve.liquidity.forgive_debt(forgive_amount_f);
    reserve.last_update.mark_stale();

    obligation.repay(forgive_amount_f, liquidity_index);

    obligation.update_has_debt();
    utils::clear_obligation_orders_if_no_debt(obligation);
    obligation.last_update.mark_stale();

    Ok(forgive_amount_f)
}

pub fn mark_obligation_for_deleveraging(
    lending_market: &LendingMarket,
    obligation: &mut Obligation,
    autodeleverage_target_ltv_pct: u8,
    timestamp: u64,
) -> Result<()> {
    // Note: we use a special marker value of a target LTV (== `255`) to denote "unmarking" of an
    // obligation. A more natural `Option<%>` would be cumbersome to handle for callers.
    if autodeleverage_target_ltv_pct == NO_DELEVERAGING_MARKER {
        if obligation.is_marked_for_deleveraging() {
            msg!(
                "Unmarking deleveraged obligation (was started at timestamp {} with target LTV {}%)",
                obligation.autodeleverage_margin_call_started_timestamp,
                obligation.autodeleverage_target_ltv_pct
            );
            obligation.unmark_for_deleveraging()
        } else {
            msg!("No-op unmarking of not-currently-marked obligation");
        }
        return Ok(());
    }

    // If this is not the "unmarking" special case, then we expect a valid percentage:
    if autodeleverage_target_ltv_pct > 100 {
        msg!(
            "Percentage outside valid range: {}",
            autodeleverage_target_ltv_pct
        );
        return err!(LendingError::InvalidConfig);
    }

    // Re-marking an already-marked obligation would include some non-obvious behaviors (e.g.
    // whether to reset the margin call period). We prefer to disallow re-marking, and instead
    // require an explicit unmarking first.
    obligation.check_not_marked_for_deleveraging()?;

    // We want to avoid marking any obligation before initializing the (default 0) margin call
    // period on the market:
    if lending_market.individual_autodeleverage_margin_call_period_secs == 0 {
        msg!("Lending market is missing the `individual_autodeleverage_margin_call_period_secs` configuration");
        return err!(LendingError::InvalidConfig);
    }

    // The end of the happy-path: simply mark the obligation.
    msg!(
        "Marking obligation for deleveraging with target LTV {}%",
        autodeleverage_target_ltv_pct
    );
    obligation.mark_for_deleveraging(timestamp, autodeleverage_target_ltv_pct);
    Ok(())
}

pub fn clear_expired_borrow_order_on_initiating_obligation_ownership_transfer(
    obligation: &mut Obligation,
    clock: &Clock,
) -> Result<()> {
    let timestamp = clock.unix_timestamp.try_into().expect("negative timestamp");

    obligation
        .borrow_order
        .clear_if_past_fillable_timestamp(timestamp);

    Ok(())
}

pub fn add_referrer_fee(
    borrow_reserve: &mut Reserve,
    referrer_token_state: &mut ReferrerTokenState,
    referrer_fee: Fraction,
) -> Result<()> {
    let referrer_fee_sf = referrer_fee.to_sf();
    referrer_token_state.amount_cumulative_sf += referrer_fee_sf;
    referrer_token_state.amount_unclaimed_sf += referrer_fee_sf;

    borrow_reserve.liquidity.accumulated_referrer_fees_sf += referrer_fee_sf;

    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub fn accumulate_referrer_fees<'info, T>(
    program_id: &Pubkey,
    borrow_reserve_info_key: Pubkey,
    borrow_reserve: &mut Reserve,
    obligation_referrer: &Pubkey,
    lending_market_referral_fee_bps: u16,
    slots_elapsed: u64,
    borrowed_amount_f: Fraction,
    previous_borrowed_amount_f: Fraction,
    obligation_has_referrer: bool,
    referrer_token_states_iter: &mut impl Iterator<Item = T>,
) -> Result<()>
where
    T: AnyAccountLoader<'info, ReferrerTokenState>,
{
    // The below calculation is done in order to subtract the pending_referral_fees from the borrow reserved
    // which are accumulated with the assumption that each obligation has a referrer.
    // Based on wether this obligation has a referrer or not, the referrer_fee will be added to the
    // accumulated_protocol_fees_sf, or the accumulated_referrer_fees_sf and referrer_token_state accumulators

    let absolute_referral_rate =
        Fraction::from_bits(borrow_reserve.liquidity.absolute_referral_rate_sf);

    if absolute_referral_rate == Fraction::ZERO {
        // Referral rate is zero, no referrer fees to accumulate
        return Ok(());
    }

    // Compute referrer fee
    let fixed_rate = approximate_compounded_interest(
        Fraction::from_bps(borrow_reserve.config.host_fixed_interest_rate_bps),
        slots_elapsed,
    );
    let net_new_debt = borrowed_amount_f - previous_borrowed_amount_f;
    let net_new_fixed_debt = previous_borrowed_amount_f * fixed_rate - previous_borrowed_amount_f;
    if net_new_fixed_debt > net_new_debt {
        // Fixed debt is higher than the net new debt, probably mismatch of slots refreshed
        return Err(LendingError::CannotCalculateReferralAmountDueToSlotsMismatch.into());
    }
    let net_new_variable_debt_f = net_new_debt - net_new_fixed_debt;

    // Referral rate is only applied after the fixed debt is set aside for the host
    let referrer_fee_f = net_new_variable_debt_f * absolute_referral_rate;

    let referrer_fee_capped_sf = min(
        referrer_fee_f.to_bits(),
        borrow_reserve.liquidity.pending_referrer_fees_sf,
    );

    borrow_reserve.liquidity.pending_referrer_fees_sf -= referrer_fee_capped_sf;

    if obligation_has_referrer && lending_market_referral_fee_bps > 0 {
        // there is a referrer
        let referrer_token_state_loader = referrer_token_states_iter
            .next()
            .ok_or(error!(LendingError::InvalidAccountInput))?;
        let referrer_token_state = &mut referrer_token_state_loader
            .get_mut()
            .map_err(|_| error!(LendingError::InvalidAccountInput))?;

        validate_referrer_token_state(
            program_id,
            referrer_token_state,
            referrer_token_state_loader.get_pubkey(),
            borrow_reserve.liquidity.mint_pubkey,
            *obligation_referrer,
            borrow_reserve_info_key,
        )?;

        add_referrer_fee(
            borrow_reserve,
            referrer_token_state,
            Fraction::from_sf(referrer_fee_capped_sf),
        )?;
    } else {
        borrow_reserve.liquidity.accumulated_protocol_fees_sf += referrer_fee_capped_sf;
    }

    Ok(())
}

pub fn withdraw_referrer_fees(
    reserve: &mut Reserve,
    slot: Slot,
    referrer_token_state: &mut ReferrerTokenState,
) -> Result<u64> {
    if reserve
        .last_update
        .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?
    {
        msg!(
            "reserve is stale and must be refreshed in the current slot, price status: {:08b}",
            reserve.last_update.get_price_status().0
        );
        return err!(LendingError::ReserveStale);
    }

    let withdraw_amount = reserve.get_withdraw_referrer_fees(referrer_token_state);

    if withdraw_amount == 0 {
        return err!(LendingError::InsufficientReferralFeesToRedeem);
    }

    reserve.withdraw_referrer_fees(withdraw_amount, referrer_token_state)?;
    reserve.last_update.mark_stale();

    Ok(withdraw_amount)
}

pub fn update_reserve_config(
    reserve: &mut Reserve,
    mode: UpdateConfigMode,
    value: &[u8],
    clock: &Clock,
) -> Result<()> {
    // TODO: Enforce value type on mode
    match mode {
        UpdateConfigMode::UpdateLoanToValuePct => {
            config_items::for_named_field!(&mut reserve.config.loan_to_value_pct)
                .validating(validations::check_valid_pct)
                .set(value)?;
        }
        UpdateConfigMode::UpdateMaxLiquidationBonusBps => {
            config_items::for_named_field!(&mut reserve.config.max_liquidation_bonus_bps)
                .validating(validations::check_valid_bps)
                .set(value)?;
        }
        UpdateConfigMode::UpdateLiquidationThresholdPct => {
            config_items::for_named_field!(&mut reserve.config.liquidation_threshold_pct)
                .validating(validations::check_valid_pct)
                .set(value)?;
        }
        UpdateConfigMode::UpdateProtocolLiquidationFee => {
            config_items::for_named_field!(&mut reserve.config.protocol_liquidation_fee_pct)
                .validating(validations::check_valid_pct)
                .set(value)?;
        }
        UpdateConfigMode::UpdateProtocolOrderExecutionFee => {
            config_items::for_named_field!(&mut reserve.config.protocol_order_execution_fee_pct)
                .validating(validations::check_valid_pct)
                .set(value)?;
        }
        UpdateConfigMode::UpdateProtocolTakeRate => {
            config_items::for_named_field!(&mut reserve.config.protocol_take_rate_pct)
                .validating(validations::check_valid_pct)
                .set(value)?;
        }
        UpdateConfigMode::UpdateFeesOriginationFee => {
            config_items::for_named_field!(&mut reserve.config.fees.origination_fee_sf)
                .validating(check_proper_fraction)
                .rendering(renderings::as_fraction)
                .set(value)?;
        }
        UpdateConfigMode::UpdateFeesFlashLoanFee => {
            config_items::for_named_field!(&mut reserve.config.fees.flash_loan_fee_sf)
                .validating(check_proper_fraction_or_max)
                .rendering(renderings::as_fraction)
                .set(value)?;
        }
        UpdateConfigMode::UpdateDepositLimit => {
            config_items::for_named_field!(&mut reserve.config.deposit_limit).set(value)?;
        }
        UpdateConfigMode::UpdateBorrowLimit => {
            config_items::for_named_field!(&mut reserve.config.borrow_limit).set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoLowerHeuristic => {
            config_items::for_named_field!(&mut reserve.config.token_info.heuristic.lower)
                .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoUpperHeuristic => {
            config_items::for_named_field!(&mut reserve.config.token_info.heuristic.upper)
                .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoExpHeuristic => {
            config_items::for_named_field!(&mut reserve.config.token_info.heuristic.exp)
                .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoTwapDivergence => {
            config_items::for_named_field!(&mut reserve.config.token_info.max_twap_divergence_bps)
                .validating(validations::check_valid_bps)
                .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoScopeChain => {
            config_items::for_named_field!(
                &mut reserve.config.token_info.scope_configuration.price_chain
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoScopeTwap => {
            config_items::for_named_field!(
                &mut reserve.config.token_info.scope_configuration.twap_chain
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoName => {
            config_items::for_named_field!(&mut reserve.config.token_info.name)
                .rendering(renderings::as_utf8_null_padded_string)
                .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoPriceMaxAge => {
            config_items::for_named_field!(&mut reserve.config.token_info.max_age_price_seconds)
                .set(value)?;
        }
        UpdateConfigMode::UpdateTokenInfoTwapMaxAge => {
            config_items::for_named_field!(&mut reserve.config.token_info.max_age_twap_seconds)
                .set(value)?;
        }
        UpdateConfigMode::UpdateScopePriceFeed => {
            config_items::for_named_field!(
                &mut reserve.config.token_info.scope_configuration.price_feed
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdatePythPrice => {
            config_items::for_named_field!(&mut reserve.config.token_info.pyth_configuration.price)
                .set(value)?;
        }
        UpdateConfigMode::UpdateSwitchboardFeed => {
            config_items::for_named_field!(
                &mut reserve
                    .config
                    .token_info
                    .switchboard_configuration
                    .price_aggregator
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateSwitchboardTwapFeed => {
            config_items::for_named_field!(
                &mut reserve
                    .config
                    .token_info
                    .switchboard_configuration
                    .twap_aggregator
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateBorrowRateCurve => {
            config_items::for_named_field!(&mut reserve.config.borrow_rate_curve).set(value)?;
        }
        UpdateConfigMode::UpdateDebtWithdrawalCap => {
            // value should be an array of [capacity, interval_length_seconds]
            config_items::for_named_field!(&mut reserve.config.debt_withdrawal_cap.config_capacity)
                .validating(validations::check_not_negative)
                .set(value)?;
            config_items::for_named_field!(
                &mut reserve
                    .config
                    .debt_withdrawal_cap
                    .config_interval_length_seconds
            )
            .set(&value[size_of::<u64>()..])?;
        }
        UpdateConfigMode::UpdateDepositWithdrawalCap => {
            // value should be an array of [capacity, interval_length_seconds]
            config_items::for_named_field!(
                &mut reserve.config.deposit_withdrawal_cap.config_capacity
            )
            .validating(validations::check_not_negative)
            .set(value)?;
            config_items::for_named_field!(
                &mut reserve
                    .config
                    .deposit_withdrawal_cap
                    .config_interval_length_seconds
            )
            .set(&value[size_of::<u64>()..])?;
        }
        UpdateConfigMode::UpdateBadDebtLiquidationBonusBps => {
            config_items::for_named_field!(&mut reserve.config.bad_debt_liquidation_bonus_bps)
                .validating(validations::check_lte(100u64)) // Note: this is deliberate max = 100 *bps* (bad debt liquidation bonus cannot be more than 1%)
                .set(value)?;
        }
        UpdateConfigMode::UpdateMinLiquidationBonusBps => {
            config_items::for_named_field!(&mut reserve.config.min_liquidation_bonus_bps)
                .validating(validations::check_valid_bps)
                .set(value)?;
        }
        UpdateConfigMode::UpdateDeleveragingMarginCallPeriod => {
            config_items::for_named_field!(
                &mut reserve.config.deleveraging_margin_call_period_secs
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateBorrowFactor => {
            config_items::for_named_field!(&mut reserve.config.borrow_factor_pct)
                .validating(validations::check_gte(100u64)) // borrow factor must be >=100%
                .set(value)?;
        }
        UpdateConfigMode::UpdateElevationGroup => {
            config_items::for_named_field!(&mut reserve.config.elevation_groups).set(value)?;
        }
        UpdateConfigMode::UpdateDeleveragingThresholdDecreaseBpsPerDay => {
            config_items::for_named_field!(
                &mut reserve.config.deleveraging_threshold_decrease_bps_per_day
            )
            // Note: the `check_valid_bps` is not relevant here (since "a million bps per day" is a valid "speed")
            .set(value)?;
        }
        UpdateConfigMode::UpdateReserveStatus => {
            config_items::for_named_field!(&mut reserve.config.status)
                .representing_u8_enum::<ReserveStatus>()
                .set(value)?;
        }
        UpdateConfigMode::UpdateBorrowLimitOutsideElevationGroup => {
            config_items::for_named_field!(
                &mut reserve.config.borrow_limit_outside_elevation_group
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateBorrowLimitsInElevationGroupAgainstThisReserve => {
            config_items::for_named_field!(
                &mut reserve
                    .config
                    .borrow_limit_against_this_collateral_in_elevation_group
            )
            .set(value)?;
        }
        UpdateConfigMode::UpdateFarmCollateral => {
            config_items::for_named_field!(&mut reserve.farm_collateral).set(value)?;
        }
        UpdateConfigMode::UpdateFarmDebt => {
            config_items::for_named_field!(&mut reserve.farm_debt).set(value)?;
        }
        UpdateConfigMode::UpdateDisableUsageAsCollateralOutsideEmode => {
            config_items::for_named_field!(&mut reserve.config.disable_usage_as_coll_outside_emode)
                .validating(validations::check_bool)
                .set(value)?;
        }
        UpdateConfigMode::UpdateBlockBorrowingAboveUtilizationPct => {
            config_items::for_named_field!(
                &mut reserve.config.utilization_limit_block_borrowing_above_pct
            )
            .validating(validations::check_valid_pct)
            .set(value)?;
        }
        UpdateConfigMode::UpdateBlockPriceUsage => {
            config_items::for_named_field!(&mut reserve.config.token_info.block_price_usage)
                .validating(validations::check_bool)
                .set(value)?;
        }
        UpdateConfigMode::UpdateHostFixedInterestRateBps => {
            config_items::for_named_field!(&mut reserve.config.host_fixed_interest_rate_bps)
                .validating(validations::check_valid_bps)
                .set(value)?;
        }
        UpdateConfigMode::UpdateAutodeleverageEnabled => {
            config_items::for_named_field!(&mut reserve.config.autodeleverage_enabled)
                .validating(validations::check_bool)
                .set(value)?;
        }
        UpdateConfigMode::UpdateDeleveragingBonusIncreaseBpsPerDay => {
            config_items::for_named_field!(
                &mut reserve.config.deleveraging_bonus_increase_bps_per_day
            )
            // Note: the `check_valid_bps` is not relevant here (since "a million bps per day" is a valid "speed")
            .set(value)?;
        }
        UpdateConfigMode::UpdateMinDeleveragingBonusBps => {
            config_items::for_named_field!(&mut reserve.config.min_deleveraging_bonus_bps)
                .validating(validations::check_valid_bps)
                .set(value)?;
        }
        UpdateConfigMode::UpdateDebtMaturityTimestamp => {
            config_items::for_named_field!(&mut reserve.config.debt_maturity_timestamp)
                .validating(|timestamp| utils::check_not_set_in_the_past(*timestamp, clock))
                .set(value)?;
        }
        UpdateConfigMode::UpdateProposerAuthorityLock => {
            config_items::for_named_field!(&mut reserve.config.proposer_authority_locked)
                .validating(validations::check_bool)
                .set(value)?;
        }
        UpdateConfigMode::UpdateDebtTermSeconds => {
            let reserve_has_borrows = reserve.liquidity.borrowed_amount_sf > 0;
            let previous_debt_term_seconds = reserve.config.get_debt_term_seconds();
            config_items::for_named_field!(&mut reserve.config.debt_term_seconds)
                .validating(|new_debt_term_seconds| {
                    check_debt_term_not_shortened_on_reserve_having_borrows(
                        previous_debt_term_seconds,
                        Some(*new_debt_term_seconds).filter(|non_zero| *non_zero > 0),
                        reserve_has_borrows,
                    )
                })
                .set(value)?;
        }
        UpdateConfigMode::UpdateEarlyRepayRemainingInterestPct => {
            config_items::for_named_field!(&mut reserve.config.early_repay_remaining_interest_pct)
                .validating(validations::check_valid_pct)
                .set(value)?;
        }
        UpdateConfigMode::UpdateBlockCTokenUsage => {
            config_items::for_named_field!(&mut reserve.config.block_ctoken_usage)
                .validating(validations::check_bool)
                .set(value)?;
        }
        UpdateConfigMode::UpdateReserveEmergencyMode => {
            config_items::for_named_field!(&mut reserve.config.emergency_mode)
                .validating(validations::check_bool)
                .set(value)?;
        }
        UpdateConfigMode::UpdateRewardsAmountPerSlot => {
            config_items::for_named_field!(&mut reserve.config.rewards_amount_per_slot)
                .set(value)?;
        }
        UpdateConfigMode::DeprecatedUpdateFeesReferralFeeBps
        | UpdateConfigMode::DeprecatedUpdateMultiplierSideBoost
        | UpdateConfigMode::DeprecatedUpdateMultiplierTagBoost
        | UpdateConfigMode::DeprecatedUpdateDebtWithdrawalCapCurrentTotal
        | UpdateConfigMode::DeprecatedUpdateAssetTier
        | UpdateConfigMode::DeprecatedUpdateEntireReserveConfig
        | UpdateConfigMode::DeprecatedUpdateDepositWithdrawalCapCurrentTotal => {
            panic!("Deprecated endpoint")
        }
    }

    reserve.last_update.mark_stale();
    Ok(())
}

pub fn clone_reserve_config(
    source_reserve: &Reserve,
    target_reserve: &mut Reserve,
    customizations: ReserveConfigCustomizations,
) -> Result<()> {
    target_reserve.config = ReserveConfig::from_customized(&source_reserve.config, customizations);

    if source_reserve.lending_market != target_reserve.lending_market
        && !is_default_array(&target_reserve.config.elevation_groups)
    {
        msg!(
            "Cannot clone from {} into different market {} reserve config with elevation groups {:?}",
            source_reserve.lending_market, target_reserve.lending_market, target_reserve.config.elevation_groups
        );
        return err!(LendingError::InvalidConfig);
    }

    Ok(())
}

/// Checks that the [ReserveConfig::debt_term_seconds] update does not shorten the term, which would
/// surprise the existing borrowers with early liquidations.
fn check_debt_term_not_shortened_on_reserve_having_borrows(
    previous_debt_term_seconds: Option<u64>,
    new_debt_term_seconds: Option<u64>,
    reserve_has_borrows: bool,
) -> Result<()> {
    if !reserve_has_borrows {
        return Ok(()); // fine to re-configure the debt term on a yet-unused reserve
    }
    let Some(new_debt_term_seconds) = new_debt_term_seconds else {
        return Ok(()); // always fine to remove the debt term (i.e. make it indefinite), albeit unlikely
    };
    let Some(previous_debt_term_seconds) = previous_debt_term_seconds else {
        msg!(
            "Cannot introduce debt term of {} seconds on a reserve with active borrows",
            new_debt_term_seconds
        );
        return err!(LendingError::InvalidConfig);
    };
    if new_debt_term_seconds < previous_debt_term_seconds {
        msg!(
            "Cannot shorten the debt term from {} seconds down to {} seconds on a reserve with active borrows",
            previous_debt_term_seconds, new_debt_term_seconds
        );
        return err!(LendingError::InvalidConfig);
    }
    Ok(())
}

pub fn update_obligation_config(
    obligation: &mut Obligation,
    market: &LendingMarket,
    subject: ObligationConfigUpdateSubject,
    mode: UpdateObligationConfigMode,
    value: &[u8],
) -> Result<()> {
    msg!(
        "Updating {:?} with mode {:?} and value {:?}",
        subject,
        mode,
        value
    );
    match mode {
        UpdateObligationConfigMode::FixedTermRolloverEnabled => {
            let rollover_config = &mut obligation
                .find_liquidity_in_borrows_mut(subject.borrow_reserve_address()?)?
                .0
                .fixed_term_borrow_rollover_config;
            config_items::for_field(&mut rollover_config.auto_rollover_enabled)
                .named("fixed_term_borrow_rollover_config.auto_rollover_enabled")
                .validating(validations::check_bool)
                .set(value)?;
            if rollover_config.is_auto_rollover_enabled() {
                utils::check_enabled_rollover_config_integrity(market, rollover_config)?;
            }
        }
        UpdateObligationConfigMode::FixedTermRolloverMaxBorrowRateBps => {
            let rollover_config = &mut obligation
                .find_liquidity_in_borrows_mut(subject.borrow_reserve_address()?)?
                .0
                .fixed_term_borrow_rollover_config;
            config_items::for_field(&mut rollover_config.max_borrow_rate_bps)
                .named("fixed_term_borrow_rollover_config.max_borrow_rate_bps")
                .set(value)?;
            utils::check_enabled_rollover_config_integrity(market, rollover_config)?;
        }
        UpdateObligationConfigMode::FixedTermRolloverMinDebtTermSeconds => {
            let rollover_config = &mut obligation
                .find_liquidity_in_borrows_mut(subject.borrow_reserve_address()?)?
                .0
                .fixed_term_borrow_rollover_config;
            config_items::for_field(&mut rollover_config.min_debt_term_seconds)
                .named("fixed_term_borrow_rollover_config.min_debt_term_seconds")
                .set(value)?;
            utils::check_enabled_rollover_config_integrity(market, rollover_config)?;
        }
        UpdateObligationConfigMode::FixedTermRolloverOpenTermAllowed => {
            let rollover_config = &mut obligation
                .find_liquidity_in_borrows_mut(subject.borrow_reserve_address()?)?
                .0
                .fixed_term_borrow_rollover_config;
            config_items::for_field(&mut rollover_config.open_term_allowed)
                .named("fixed_term_borrow_rollover_config.open_term_allowed")
                .validating(validations::check_bool)
                .set(value)?;
            utils::check_enabled_rollover_config_integrity(market, rollover_config)?;
        }
        UpdateObligationConfigMode::MigrationToFixedEnabled => {
            let rollover_config = &mut obligation
                .find_liquidity_in_borrows_mut(subject.borrow_reserve_address()?)?
                .0
                .fixed_term_borrow_rollover_config;
            config_items::for_field(&mut rollover_config.migration_to_fixed_enabled)
                .named("fixed_term_borrow_rollover_config.migration_to_fixed_enabled")
                .validating(validations::check_bool)
                .set(value)?;
            if rollover_config.is_migration_to_fixed_enabled() {
                utils::check_enabled_rollover_config_integrity(market, rollover_config)?;
            }
        }
    }
    Ok(())
}

/// Checks whether the given [u64] fraction is <= 1.0.
fn check_proper_fraction(sf: &u64) -> Result<()> {
    validations::check_lte(Fraction::ONE.to_bits())(sf) // Note: if Rust had currying, this would be a use-case
}

/// Performs a [check_proper_fraction()], but also allows a special value of [u64::MAX].
fn check_proper_fraction_or_max(sf: &u64) -> Result<()> {
    if *sf == u64::MAX {
        return Ok(()); // the allowed special-case
    }
    check_proper_fraction(sf)
}

pub mod utils {
    use anchor_lang::require_neq;
    use num_enum::TryFromPrimitive;

    use super::*;
    use crate::{
        fraction::FRACTION_ONE_SCALED,
        state::ReserveConfig,
        utils::{
            accounts::has_ata_address, borsh_deserialize, ELEVATION_GROUP_NONE, FULL_BPS,
            MAX_NUM_ELEVATION_GROUPS,
        },
        ElevationGroup, FixedTermBorrowRolloverConfig, ObligationCollateral, ObligationLiquidity,
    };

    pub(crate) fn repay_and_withdraw_from_obligation_post_liquidation(
        obligation: &mut Obligation,
        repay_reserve: &mut Reserve,
        settle_amount: Fraction,
        withdraw_amount: u64,
        repay_amount: u64,
        liquidity_index: usize,
        collateral_index: usize,
    ) -> Result<()> {
        if repay_amount == 0 {
            msg!("Liquidation is too small to transfer liquidity");
            return err!(LendingError::LiquidationTooSmall);
        }
        if withdraw_amount == 0 {
            msg!("Liquidation is too small to receive collateral");
            return err!(LendingError::LiquidationTooSmall);
        }

        repay_reserve.liquidity.repay(repay_amount, settle_amount)?;
        repay_reserve.last_update.mark_stale();

        obligation.repay(settle_amount, liquidity_index);
        obligation.withdraw(withdraw_amount, collateral_index)?;

        obligation.update_has_debt();
        clear_obligation_orders_if_no_debt(obligation);
        obligation.last_update.mark_stale();

        Ok(())
    }

    pub(crate) fn calculate_market_value_from_liquidity_amount(
        reserve: &Reserve,
        liquidity_amount: Fraction,
    ) -> Fraction {
        // TODO(refactor): remove this "middleman" function - the delegate below is more resilient to precision loss and more explicit about rounding
        reserve
            .liquidity
            .liquidity_amount_to_market_value(liquidity_amount)
    }

    pub(crate) fn calculate_obligation_collateral_market_value(
        deposit_reserve: &Reserve,
        deposit: &ObligationCollateral,
    ) -> Fraction {
        let liquidity_amount_from_collateral = deposit_reserve
            .collateral_exchange_rate()
            .fraction_collateral_to_liquidity(deposit.deposited_amount.into());

        calculate_market_value_from_liquidity_amount(
            deposit_reserve,
            liquidity_amount_from_collateral,
        )
    }

    pub(crate) fn calculate_obligation_liquidity_market_value(
        borrow_reserve: &Reserve,
        borrow: &ObligationLiquidity,
    ) -> Fraction {
        // market_value = (borrowed_amount * market_price) / (10 ^ mint_decimals)

        calculate_market_value_from_liquidity_amount(borrow_reserve, borrow.borrowed_amount())
    }

    pub(crate) fn check_obligation_collateral_deposit_reserve(
        deposit: &ObligationCollateral,
        deposit_reserve: &Reserve,
        deposit_reserve_pk: Pubkey,
        index: usize,
        slot: u64,
    ) -> Result<()> {
        if deposit.deposit_reserve != deposit_reserve_pk {
            msg!(
                "Deposit reserve of collateral {} does not match the deposit reserve provided",
                index
            );
            return err!(LendingError::InvalidAccountInput);
        }

        // No need to check the price status here it will be propagated to the obligation.
        if deposit_reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::NONE)?
        {
            msg!(
                "Deposit reserve {} provided for collateral {} is stale and must be refreshed in the current slot. Last Update {:?}",
                deposit.deposit_reserve,
                index,
                deposit_reserve.last_update,
            );
            return err!(LendingError::ReserveStale);
        }

        if deposit_reserve.version != PROGRAM_VERSION as u64 {
            msg!(
                "Deposit reserve {} provided for collateral {} has been deprecated.",
                deposit.deposit_reserve,
                index,
            );
            return err!(LendingError::ReserveDeprecated);
        }

        Ok(())
    }

    pub(crate) fn check_obligation_liquidity_borrow_reserve(
        borrow: &ObligationLiquidity,
        borrow_reserve: &Reserve,
        borrow_reserve_pk: Pubkey,
        index: usize,
        slot: u64,
    ) -> Result<()> {
        if borrow.borrow_reserve != borrow_reserve_pk {
            msg!(
                "Borrow reserve of liquidity {} does not match the borrow reserve provided",
                index
            );
            return err!(LendingError::InvalidAccountInput);
        }

        // No need to check the price status here it will be propagated to the obligation.
        if borrow_reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::NONE)?
        {
            msg!(
                "Borrow reserve {} provided for liquidity {} is stale
                and must be refreshed in the current slot. Last Update {:?}",
                borrow.borrow_reserve,
                index,
                borrow_reserve.last_update,
            );
            return err!(LendingError::ReserveStale);
        }

        if borrow_reserve.version != PROGRAM_VERSION as u64 {
            msg!(
                "Borrow reserve {} provided for liquidity {} has been deprecated.",
                borrow.borrow_reserve,
                index,
            );
            return err!(LendingError::ReserveDeprecated);
        }

        Ok(())
    }

    pub fn check_elevation_group_borrowing_enabled(
        market: &LendingMarket,
        obligation: &Obligation,
    ) -> Result<()> {
        if let Some(elevation_group) = get_elevation_group(obligation.elevation_group, market)? {
            require!(
                !elevation_group.new_loans_disabled(),
                LendingError::ElevationGroupNewLoansDisabled
            );
        }
        Ok(())
    }

    /// This function must be called when requesting an elevation group change (in or out)
    /// It will check that the limits that will now applies to the obligation are respected
    /// This allow to fail the elevation group request if any of the constraints are not met.
    pub fn check_elevation_group_borrow_limit_constraints<'info, T>(
        obligation: &Obligation,
        elevation_group: Option<&ElevationGroup>,
        deposit_reserves_iter: impl Iterator<Item = T>,
        borrow_reserves_iter: impl Iterator<Item = T>,
    ) -> Result<()>
    where
        T: AnyAccountLoader<'info, Reserve>,
    {
        // Assert on the borrow side
        {
            let borrows_and_reserves = obligation.active_borrows().zip_exact(borrow_reserves_iter);
            for borrow_and_reserve in borrows_and_reserves {
                let (borrow, reserve_acc) =
                    borrow_and_reserve.map_err(|_| error!(LendingError::InvalidAccountInput))?;
                let reserve_pk = reserve_acc.get_pubkey();
                let borrow_reserve = reserve_acc.get()?;
                require_keys_eq!(
                    borrow.borrow_reserve,
                    reserve_pk,
                    LendingError::InvalidAccountInput
                );

                if let Some(elevation_group) = elevation_group {
                    require!(
                        borrow_reserve
                            .config
                            .elevation_groups
                            .contains(&elevation_group.id),
                        LendingError::InconsistentElevationGroup
                    );
                    require_keys_eq!(
                        reserve_pk,
                        elevation_group.debt_reserve,
                        LendingError::ElevationGroupHasAnotherDebtReserve
                    );
                } else {
                    // We are outside of an elevation group, the borrows outside of
                    // elevation group should be below the borrow_limit_outside_elevation_group
                    require_gte!(
                        borrow_reserve.config.borrow_limit_outside_elevation_group,
                        borrow_reserve.borrowed_amount_outside_elevation_group,
                        LendingError::ElevationGroupBorrowLimitExceeded
                    );
                }
            }
        }

        // Assert on the deposit side
        {
            let deposits_and_reserves = obligation
                .active_deposits()
                .zip_exact(deposit_reserves_iter);
            for deposit_and_reserve in deposits_and_reserves {
                let (deposit, reserve_acc) =
                    deposit_and_reserve.map_err(|_| error!(LendingError::InvalidAccountInput))?;
                let reserve_pk = reserve_acc.get_pubkey();
                let deposit_reserve = reserve_acc.get()?;
                require_keys_eq!(
                    deposit.deposit_reserve,
                    reserve_pk,
                    LendingError::InvalidAccountInput
                );

                if let Some(elevation_group) = elevation_group {
                    let elevation_group_index = elevation_group.get_index();
                    require!(
                        deposit_reserve
                            .config
                            .elevation_groups
                            .contains(&elevation_group.id),
                        LendingError::InconsistentElevationGroup
                    );
                    require_keys_neq!(
                        reserve_pk,
                        elevation_group.debt_reserve,
                        LendingError::ElevationGroupDebtReserveAsCollateral
                    );

                    // Check the debt taken against this reserve is below the limit in the elevation group
                    require_gte!(
                        deposit_reserve
                            .config
                            .borrow_limit_against_this_collateral_in_elevation_group
                            [elevation_group_index],
                        deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                            [elevation_group_index],
                        LendingError::ElevationGroupBorrowLimitExceeded,
                    );
                } else {
                    // We are outside of an elevation group there is no constraint on the deposits
                }
            }

            // If obligation has borrows, check that borrowing is enabled outside of elevation group
            if !obligation.is_active_borrows_empty() {
                check_non_elevation_group_borrowing_enabled(obligation)?;
            }
        }
        Ok(())
    }

    pub fn update_elevation_group_debt_trackers_on_borrow<'info, T>(
        new_borrowed_amount: u64,
        obligation: &mut Obligation,
        obligation_borrow_index: usize,
        elevation_group: Option<&ElevationGroup>,
        borrow_reserve_pk: &Pubkey,
        borrow_reserve: &mut Reserve,
        mut deposit_reserves_iter: impl Iterator<Item = T>,
    ) -> Result<()>
    where
        T: AnyAccountLoader<'info, Reserve>,
    {
        if let Some(elevation_group) = elevation_group {
            let elevation_group_index = elevation_group.get_index();

            require_keys_eq!(
                elevation_group.debt_reserve,
                *borrow_reserve_pk,
                LendingError::ElevationGroupHasAnotherDebtReserve
            );
            // Check/update the elevation group borrow limits for the each of the collateral reserve
            for obligation_deposit in obligation.active_deposits_mut() {
                let deposit_reserve = deposit_reserves_iter
                    .next()
                    .ok_or_else(|| error!(LendingError::InvalidAccountInput))?;
                require_keys_eq!(
                    deposit_reserve.get_pubkey(),
                    obligation_deposit.deposit_reserve
                );

                let mut deposit_reserve = deposit_reserve.get_mut()?;

                let debt_limit = deposit_reserve
                    .config
                    .borrow_limit_against_this_collateral_in_elevation_group[elevation_group_index];
                let prev_borrowed_amounts_against_this_reserve_in_elevation_groups =
                    deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                        [elevation_group_index];
                let new_borrowed_amounts_against_this_reserve_in_elevation_groups =
                    prev_borrowed_amounts_against_this_reserve_in_elevation_groups
                        .checked_add(new_borrowed_amount)
                        .ok_or_else(|| error!(LendingError::ElevationGroupBorrowLimitExceeded))?;

                msg!("Refreshed debt in elevation group reserve {} before {prev_borrowed_amounts_against_this_reserve_in_elevation_groups} after {new_borrowed_amounts_against_this_reserve_in_elevation_groups} limit {debt_limit}",
                    obligation_deposit.deposit_reserve,
                );

                require_gte!(
                    debt_limit,
                    new_borrowed_amounts_against_this_reserve_in_elevation_groups,
                    LendingError::ElevationGroupBorrowLimitExceeded
                );
                deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                    [elevation_group_index] =
                    new_borrowed_amounts_against_this_reserve_in_elevation_groups;

                obligation_deposit.borrowed_amount_against_this_collateral_in_elevation_group +=
                    new_borrowed_amount;
            }
        } else {
            let borrow_limit = borrow_reserve.config.borrow_limit_outside_elevation_group;
            msg!(
                "Last refreshed borrows (outside elevation group) {}",
                borrow_reserve.borrowed_amount_outside_elevation_group
            );
            let new_total_borrow_amount = borrow_reserve
                .borrowed_amount_outside_elevation_group
                .checked_add(new_borrowed_amount)
                .ok_or_else(|| error!(LendingError::MathOverflow))?;

            require_gte!(
                borrow_limit,
                new_total_borrow_amount,
                LendingError::BorrowLimitExceeded
            );

            borrow_reserve.borrowed_amount_outside_elevation_group = new_total_borrow_amount;
            obligation.borrows[obligation_borrow_index].borrowed_amount_outside_elevation_groups +=
                new_borrowed_amount;
        }
        Ok(())
    }

    pub fn update_elevation_group_debt_trackers_on_repay<'info, T>(
        repay_amount: u64,
        obligation: &mut Obligation,
        obligation_borrow_index: usize,
        borrow_reserve: &mut Reserve,
        mut deposit_reserves_iter: impl Iterator<Item = T>,
    ) -> Result<()>
    where
        T: AnyAccountLoader<'info, Reserve>,
    {
        if obligation.elevation_group != ELEVATION_GROUP_NONE {
            let elevation_group_index = obligation.elevation_group as usize - 1;
            // Remove the repay amount from the elevation group borrow limit for the each of the collateral reserve
            for obligation_deposit in obligation.active_deposits_mut() {
                let deposit_reserve = deposit_reserves_iter
                    .next()
                    .ok_or_else(|| error!(LendingError::InvalidAccountInput))?;
                require_keys_eq!(
                    deposit_reserve.get_pubkey(),
                    obligation_deposit.deposit_reserve
                );
                let mut deposit_reserve = deposit_reserve.get_mut()?;
                let debt_limit = deposit_reserve
                    .config
                    .borrow_limit_against_this_collateral_in_elevation_group[elevation_group_index];
                let pre_debt_amount = deposit_reserve
                    .borrowed_amounts_against_this_reserve_in_elevation_groups
                    [elevation_group_index];
                let new_debt_amount = pre_debt_amount.saturating_sub(repay_amount);

                msg!("Refreshed debt in elevation group reserve {} before {pre_debt_amount} after {new_debt_amount} limit {debt_limit}",
                    obligation_deposit.deposit_reserve,
                );
                deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                    [elevation_group_index] = new_debt_amount;
                obligation_deposit.borrowed_amount_against_this_collateral_in_elevation_group =
                    obligation_deposit
                        .borrowed_amount_against_this_collateral_in_elevation_group
                        .saturating_sub(repay_amount);
            }
        } else {
            let new_total_borrow_amount = borrow_reserve
                .borrowed_amount_outside_elevation_group
                .saturating_sub(repay_amount);

            msg!(
                "Last refreshed borrows (outside elevation group) {}",
                borrow_reserve.borrowed_amount_outside_elevation_group
            );

            borrow_reserve.borrowed_amount_outside_elevation_group = new_total_borrow_amount;
            obligation.borrows[obligation_borrow_index].borrowed_amount_outside_elevation_groups =
                obligation.borrows[obligation_borrow_index]
                    .borrowed_amount_outside_elevation_groups
                    .saturating_sub(repay_amount);
        }
        Ok(())
    }

    pub fn update_elevation_group_debt_trackers_on_new_deposit(
        total_borrowed: Option<u64>,
        obligation_collateral: &mut ObligationCollateral,
        pre_deposit_count: usize,
        elevation_group: Option<&ElevationGroup>,
        deposit_reserve_pk: &Pubkey,
        deposit_reserve: &mut Reserve,
        max_reserves_as_collateral_check: MaxReservesAsCollateralCheck,
    ) -> Result<()> {
        if let Some(elevation_group) = elevation_group {
            require_keys_neq!(
                elevation_group.debt_reserve,
                *deposit_reserve_pk,
                LendingError::ElevationGroupDebtReserveAsCollateral
            );

            if max_reserves_as_collateral_check == MaxReservesAsCollateralCheck::Perform {
                require_gte!(
                    usize::from(elevation_group.max_reserves_as_collateral),
                    pre_deposit_count + 1,
                    LendingError::ObligationCollateralExceedsElevationGroupLimit
                );
            }

            let elevation_group_index = elevation_group.get_index();

            let total_borrowed = total_borrowed
                .ok_or_else(|| error!(LendingError::ObligationElevationGroupMultipleDebtReserve))?;

            deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                [elevation_group_index] += total_borrowed;
            obligation_collateral.borrowed_amount_against_this_collateral_in_elevation_group =
                total_borrowed;
        }
        // Else we don't track anything in the deposit reserve
        Ok(())
    }

    pub fn update_elevation_group_debt_trackers_on_full_withdraw(
        previous_debt_in_elevation_group: u64,
        elevation_group_id: u8,
        deposit_reserve: &mut Reserve,
    ) -> Result<()> {
        if elevation_group_id != ELEVATION_GROUP_NONE {
            let elevation_group_index = elevation_group_id as usize - 1;

            deposit_reserve.borrowed_amounts_against_this_reserve_in_elevation_groups
                [elevation_group_index] = deposit_reserve
                .borrowed_amounts_against_this_reserve_in_elevation_groups[elevation_group_index]
                .saturating_sub(previous_debt_in_elevation_group);
        }
        // Else the borrowed amount is not tracked
        Ok(())
    }

    /// Updates the [Reserve::borrowed_amount_outside_elevation_group] and the corresponding
    /// [ObligationLiquidity::borrowed_amount_outside_elevation_groups] trackers for a rollover
    /// *into a different reserve*.
    ///
    /// Note: does *not* update [Reserve::borrowed_amounts_against_this_reserve_in_elevation_groups]
    /// (unlike the sibling [update_elevation_group_debt_trackers_on_repay()]), since we do not
    /// allow rollovers for obligations in elevation group (checked before reaching this point).
    ///
    /// Note: does *not* check the reserve's limit (the rollover logic already takes it into account
    /// during maximum rolled-over part calculation).
    ///
    /// Note on the awkward `borrows + source_borrow_reserve_address + target_borrow_index` inputs:
    /// In full rollover cases:
    /// - it may happen that `source_borrow == target_borrow` (and thus they couldn't be both
    ///   mutably borrowed, to be passed as &mut structs);
    /// - the `source_borrow_index` discovered by the earlier logic is no longer valid (hence we
    ///   better just try to locate it by address again).
    #[allow(clippy::too_many_arguments)]
    pub fn update_elevation_group_debt_trackers_on_rollover(
        obligation: &mut Obligation,
        tokens_moved_over: u64,
        source_borrow_reserve: &mut Reserve,
        target_borrow_reserve: &mut Reserve,
        source_borrow_reserve_address: Pubkey,
        target_borrow_index: usize,
    ) -> Result<()> {
        // Source reserve reduces its debt: (saturating, same as in the `..._on_repay()` variant)
        source_borrow_reserve.borrowed_amount_outside_elevation_group = source_borrow_reserve
            .borrowed_amount_outside_elevation_group
            .saturating_sub(tokens_moved_over);

        // Target reserve increases this debt:
        target_borrow_reserve.borrowed_amount_outside_elevation_group += tokens_moved_over;

        // Update the tracking on the obligation borrows:
        // Note: for full rollover, the source borrow was zeroed (and on top of that, it may even
        // have been reused for the target borrow!), so we only want to update it if it still
        // represents the source debt.
        if let Ok((source_borrow, _index)) =
            obligation.find_liquidity_in_borrows_mut(source_borrow_reserve_address)
        {
            source_borrow.borrowed_amount_outside_elevation_groups = source_borrow
                .borrowed_amount_outside_elevation_groups
                .saturating_sub(tokens_moved_over);
        }

        // Target borrow is easier:
        let target_borrow = &mut obligation.borrows[target_borrow_index];
        target_borrow.borrowed_amount_outside_elevation_groups += tokens_moved_over;

        Ok(())
    }

    /// Clears the [Obligation::obligation_orders] if the obligation has currently no debt
    /// (according to the cached [Obligation::has_debt]!).
    pub fn clear_obligation_orders_if_no_debt(obligation: &mut Obligation) {
        if !obligation.has_debt() {
            let obligation_had_orders = obligation_order_operations::remove_all_orders(obligation);
            if obligation_had_orders {
                xmsg!("All obligation's debts were cleared; removing all its orders");
            }
        }
    }

    /// Checks whether the current *non-accounting* state of the given market, reserve and
    /// obligation allows for borrowing any amount.
    ///
    /// In other words: this includes all checks that do not touch the actual token amounts, limits,
    /// LTVs, etc.
    pub fn check_borrow_possible(
        market: &LendingMarket,
        reserve: &Reserve,
        obligation: &Obligation,
        clock: &Clock,
    ) -> Result<()> {
        // Market-level flag:
        if market.is_borrowing_disabled() {
            return err!(LendingError::BorrowingDisabled);
        }

        // Reserve freshness:
        if reserve
            .last_update
            .is_stale(clock.slot, PriceStatusFlags::ALL_CHECKS)?
        {
            msg!(
                "Borrow reserve is stale and must be refreshed in the current slot, price_status: {:08b}",
                reserve.last_update.get_price_status().0
            );
            return err!(LendingError::ReserveStale);
        }

        // Reserve's debt maturity:
        let timestamp = u64::try_from(clock.unix_timestamp).unwrap();
        if let Some(secs_since_debt_maturity_reached) = reserve
            .config
            .get_secs_since_debt_maturity_reached(timestamp)
        {
            msg!(
                "Cannot borrow from a reserve that reached its debt maturity {} seconds ago",
                secs_since_debt_maturity_reached
            );
            // Technically, borrowing from a reserve that reached its debt maturity would be
            // harmless to the protocol, i.e. the debt would immediately be liquidatable; but it
            // makes no sense from the business PoV:
            return err!(LendingError::ReserveDebtMaturityReached);
        }

        // Obligation's state:
        obligation.check_not_marked_for_deleveraging()?;
        if obligation.has_obsolete_reserves() {
            return err!(LendingError::ObligationInObsoleteReserve);
        }

        // Obligation's freshness:
        check_obligation_fully_refreshed_and_not_null(obligation, clock.slot)?;

        // Elevation group:
        check_same_elevation_group(obligation, reserve)?;
        check_elevation_group_borrowing_enabled(market, obligation)?;
        check_non_elevation_group_borrowing_enabled(obligation)?;

        Ok(())
    }

    /// Checks whether the current *non-accounting* state of the given reserve and obligation allows
    /// for repaying any amount.
    ///
    /// In other words: this includes all checks that do not touch the actual token amounts, limits,
    /// LTVs, etc.
    pub fn check_repay_possible(
        reserve: &Reserve,
        obligation: &Obligation,
        clock: &Clock,
    ) -> Result<()> {
        // Reserve freshness:
        if reserve
            .last_update
            .is_stale(clock.slot, PriceStatusFlags::NONE)?
        {
            msg!("Repay reserve is stale and must be refreshed in the current slot");
            return err!(LendingError::ReserveStale);
        }

        // Obligation's freshness:
        if obligation
            .last_update
            .is_stale(clock.slot, PriceStatusFlags::NONE)?
        {
            msg!("Obligation is stale and must be refreshed in the current slot");
            return err!(LendingError::ObligationStale);
        }

        Ok(())
    }

    pub fn check_non_elevation_group_borrowing_enabled(obligation: &Obligation) -> Result<()> {
        if obligation.elevation_group == ELEVATION_GROUP_NONE && obligation.borrowing_disabled > 0 {
            err!(LendingError::BorrowingDisabledOutsideElevationGroup)
        } else {
            Ok(())
        }
    }

    pub fn check_same_elevation_group(obligation: &Obligation, reserve: &Reserve) -> Result<()> {
        if obligation.elevation_group != ELEVATION_GROUP_NONE
            && !reserve
                .config
                .elevation_groups
                .contains(&obligation.elevation_group)
        {
            return err!(LendingError::InconsistentElevationGroup);
        }

        Ok(())
    }

    pub fn post_deposit_obligation_invariants(
        amount: Fraction,
        obligation: &Obligation,
        reserve: &Reserve,
        previous_collateral_asset_mv: Fraction,
        min_accepted_net_value: Fraction,
    ) -> Result<()> {
        let asset_mv = calculate_market_value_from_liquidity_amount(reserve, amount);

        let new_total_deposited_mv = Fraction::from_bits(obligation.deposited_value_sf) + asset_mv;

        let new_collateral_asset_mv = previous_collateral_asset_mv + asset_mv;

        let new_ltv = Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf)
            / new_total_deposited_mv;

        if new_collateral_asset_mv > 0 && new_collateral_asset_mv < min_accepted_net_value {
            msg!(
                "Obligation new collateral value after deposit {} for ${}",
                new_collateral_asset_mv.to_display(),
                reserve.token_symbol()
            );
            return err!(LendingError::NetValueRemainingTooSmall);
        }

        // skip LTV check if obligation had no deposit prior to deposit, cached value updated in refresh obligation
        if obligation.deposited_value_sf != 0 {
            // No action happened that would have worsened the LTV of the obligation
            if new_ltv > obligation.loan_to_value() {
                msg!(
                    "Obligation new LTV after deposit {} of {}",
                    new_ltv.to_display(),
                    reserve.token_symbol()
                );
                return err!(LendingError::WorseLtvBlocked);
            }
        }

        Ok(())
    }

    pub fn post_withdraw_obligation_invariants(
        amount: Fraction,
        obligation: &Obligation,
        reserve: &Reserve,
        reserve_liquidation_threshold_pct: u8,
        previous_collateral_asset_mv: Fraction,
        min_accepted_net_value: Fraction,
    ) -> Result<()> {
        let asset_mv = calculate_market_value_from_liquidity_amount(reserve, amount);

        // Prices should be refreshed here, overflow error if asset_mv > deposited_value
        let new_total_deposited_mv = Fraction::from_bits(obligation.deposited_value_sf) - asset_mv;
        let debt_value_bf = Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf);

        // There hasn't been a full withdrawal of the collateral position
        if previous_collateral_asset_mv != 0 {
            let new_collateral_asset_mv = previous_collateral_asset_mv - asset_mv;

            if new_collateral_asset_mv > 0 && new_collateral_asset_mv < min_accepted_net_value {
                msg!(
                    "Obligation new collateral value after withdraw {} for {}",
                    new_collateral_asset_mv.to_display(),
                    reserve.token_symbol()
                );
                return err!(LendingError::NetValueRemainingTooSmall);
            }
        }

        if new_total_deposited_mv == 0 && debt_value_bf > 0 {
            msg!("Obligation is in a state where liabilities are bigger than the assets of the user debt mv: {}, deposited mv: {}",
                debt_value_bf.to_display(),
                new_total_deposited_mv.to_display()
            );
            return err!(LendingError::LiabilitiesBiggerThanAssets);
        }

        // Skip LTV check if new coll is 0
        if new_total_deposited_mv != 0 {
            // No action happened that set liabilities bigger than assets of the obligation

            if Fraction::from_bits(obligation.borrowed_assets_market_value_sf)
                >= new_total_deposited_mv
            {
                msg!(
                    "Obligation new total deposited market value after withdraw {} of {}",
                    new_total_deposited_mv.to_display(),
                    reserve.token_symbol()
                );
                return err!(LendingError::LiabilitiesBiggerThanAssets);
            }

            let new_ltv = debt_value_bf / new_total_deposited_mv;

            // We are using saturating ops below - worst case, it should give a `0` result, which triggers the `LendingError::WorseLtvThanUnhealthyLtv` (prefer error to panic):
            let new_unhealthy_borrow_value =
                Fraction::from_bits(obligation.unhealthy_borrow_value_sf).saturating_sub(
                    asset_mv
                        .saturating_mul(Fraction::from_percent(reserve_liquidation_threshold_pct)),
                );

            let new_unhealthy_ltv = new_unhealthy_borrow_value / new_total_deposited_mv;

            // No action happened that would have worsened the LTV of the obligation
            if new_ltv >= new_unhealthy_ltv && new_ltv != 0 {
                msg!(
                    "Obligation new LTV/new unhealthy LTV after withdraw {:.2}/{:.2} of {}",
                    new_ltv.to_display(),
                    new_unhealthy_ltv.to_display(),
                    reserve.token_symbol()
                );
                return err!(LendingError::WorseLtvThanUnhealthyLtv);
            }
        }

        Ok(())
    }

    pub fn post_repay_and_withdraw_obligation_enforcements(
        obligation: &Obligation,
        withdraw_reserve: &Reserve,
        initial_ltv_before_repay: Fraction,
    ) -> Result<()> {
        let debt_value = Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf);

        let new_total_deposited_mv = Fraction::from_bits(obligation.deposited_value_sf);

        // If the obligation has other deposits with ltv > 0, we cannot have debt backed by that collateral
        if obligation.lowest_reserve_deposit_max_ltv_pct == 0 && debt_value > 0 {
            return err!(LendingError::ZeroMaxLtvAssetsInDeposits);
        }

        // Withdrawal must happen from the lowest LTV collateral
        if obligation.lowest_reserve_deposit_max_ltv_pct < withdraw_reserve.config.loan_to_value_pct
            && debt_value > 0
        {
            return err!(LendingError::LowestLtvAssetsPriority);
        }

        // Skip LTV check if new coll is 0
        if new_total_deposited_mv != 0 {
            let new_unhealthy_ltv = obligation.unhealthy_loan_to_value();

            let new_ltv = obligation.loan_to_value();

            if new_ltv > initial_ltv_before_repay {
                msg!("Obligation new LTV/initial LTV after withdraw with permissive withdraw flag {}/{}", new_ltv.to_display(), initial_ltv_before_repay.to_display());
                return err!(LendingError::WorseLtvBlocked);
            }

            if new_ltv >= new_unhealthy_ltv {
                msg!(
                    "Obligation new LTV/new unhealthy LTV after withdrawal {}/{}",
                    new_ltv.to_display(),
                    new_unhealthy_ltv.to_display()
                );
                return err!(LendingError::WorseLtvThanUnhealthyLtv);
            }
        }

        if new_total_deposited_mv == 0 && debt_value > 0 {
            msg!(
                "Obligation is in a state where liabilities are bigger than the assets of the user debt mv: {}, deposited mv: {}",
                debt_value.to_display(),
                new_total_deposited_mv.to_display()
            );
            return err!(LendingError::LiabilitiesBiggerThanAssets);
        }

        Ok(())
    }
    pub fn post_deposit_and_withdraw_obligation_enforcements(
        obligation: &Obligation,
        withdraw_reserve: &Reserve,
        lending_market: &LendingMarket,
        initial_ltv: Fraction,
        max_reserves_as_collateral_check: MaxReservesAsCollateralCheck,
    ) -> Result<()> {
        let debt_value = Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf);

        let new_total_deposited_mv = Fraction::from_bits(obligation.deposited_value_sf);

        // 1. If the obligation has other deposits with ltv > 0, we cannot have debt backed by that collateral
        if obligation.lowest_reserve_deposit_max_ltv_pct == 0 && debt_value > 0 {
            return err!(LendingError::ZeroMaxLtvAssetsInDeposits);
        }

        // 2. Withdrawal must happen from the lowest LTV collateral
        if obligation.lowest_reserve_deposit_max_ltv_pct < withdraw_reserve.config.loan_to_value_pct
            && debt_value > 0
        {
            return err!(LendingError::LowestLtvAssetsPriority);
        }

        // 3. Check if new ltv is higher compared to the initial LTV
        //                        or if it's higher than unhealthy LTV
        // Skip this check if new coll is 0 (we cannot compute LTV)
        if new_total_deposited_mv != 0 {
            let new_unhealthy_ltv = obligation.unhealthy_loan_to_value();

            let new_ltv = obligation.loan_to_value();

            if new_ltv > initial_ltv {
                msg!("Obligation new LTV/initial LTV after withdraw with permissive withdraw flag {}/{}", new_ltv.to_display(), initial_ltv.to_display());
                return err!(LendingError::WorseLtvBlocked);
            }

            if new_ltv >= new_unhealthy_ltv {
                msg!(
                    "Obligation new LTV/new unhealthy LTV after withdrawal {}/{}",
                    new_ltv.to_display(),
                    new_unhealthy_ltv.to_display()
                );
                return err!(LendingError::WorseLtvThanUnhealthyLtv);
            }
        }

        // 4. Check that assets are still bigger than liabilities (this should never trigger)
        if new_total_deposited_mv == 0 && debt_value > 0 {
            msg!(
                "Obligation is in a state where liabilities are bigger than the assets of the user debt mv: {}, deposited mv: {}",
                debt_value.to_display(),
                new_total_deposited_mv.to_display()
            );
            return err!(LendingError::LiabilitiesBiggerThanAssets);
        }

        // 5. Because we disable the max reserves as collateral check in this instruction we need to make
        // sure that in the end the constraint still holds.
        if max_reserves_as_collateral_check == MaxReservesAsCollateralCheck::Perform {
            if let Some(elevation_group) =
                get_elevation_group(obligation.elevation_group, lending_market)?
            {
                require_gte!(
                    usize::from(elevation_group.max_reserves_as_collateral),
                    obligation.active_deposits_count(),
                    LendingError::ObligationCollateralExceedsElevationGroupLimit
                );
            }
        }

        Ok(())
    }

    pub fn post_borrow_obligation_invariants(
        amount: Fraction,
        obligation: &Obligation,
        reserve: &Reserve,
        liquidity_asset_mv: Fraction,
        min_accepted_net_value: Fraction,
    ) -> Result<()> {
        let asset_mv = calculate_market_value_from_liquidity_amount(reserve, amount);

        let new_total_bf_debt_mv =
            Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf)
                + asset_mv
                    * reserve.borrow_factor_f(obligation.elevation_group != ELEVATION_GROUP_NONE);
        let new_total_no_bf_debt_mv =
            Fraction::from_bits(obligation.borrowed_assets_market_value_sf) + asset_mv;
        let new_liquidity_asset_mv = liquidity_asset_mv + asset_mv;

        if new_liquidity_asset_mv > 0 && new_liquidity_asset_mv < min_accepted_net_value {
            msg!(
                "Obligation new borrowed value after borrow {} for {}",
                new_liquidity_asset_mv.to_display(),
                reserve.token_symbol()
            );
            return err!(LendingError::NetValueRemainingTooSmall);
        }
        let new_ltv = new_total_bf_debt_mv / Fraction::from_bits(obligation.deposited_value_sf);

        if new_ltv > obligation.unhealthy_loan_to_value() {
            msg!(
                "Obligation new LTV/new unhealthy LTV after borrow {:.2}/{:.2} of {}",
                new_ltv.to_display(),
                obligation.unhealthy_loan_to_value().to_display(),
                reserve.token_symbol()
            );
            return err!(LendingError::WorseLtvThanUnhealthyLtv);
        }

        if new_total_no_bf_debt_mv >= Fraction::from_bits(obligation.deposited_value_sf) {
            msg!(
                "Obligation can't have more liabilities than assets after borrow {} of {}",
                new_total_no_bf_debt_mv.to_display(),
                reserve.token_symbol()
            );
            return err!(LendingError::LiabilitiesBiggerThanAssets);
        }

        Ok(())
    }

    pub fn post_repay_obligation_invariants(
        amount: Fraction,
        obligation: &Obligation,
        reserve: &Reserve,
        liquidity_asset_mv: Fraction,
        min_accepted_net_value: Fraction,
    ) -> Result<()> {
        let asset_mv = calculate_market_value_from_liquidity_amount(reserve, amount);
        // Prices should be refreshed here, overflow error if asset_mv > deposited_value
        let new_total_bf_debt_mv =
            Fraction::from_bits(obligation.borrow_factor_adjusted_debt_value_sf)
                - asset_mv
                    * reserve.borrow_factor_f(obligation.elevation_group != ELEVATION_GROUP_NONE);
        let total_deposited_mv = Fraction::from_bits(obligation.deposited_value_sf);

        // There hasn't been a full repayment of the liquidity position
        if liquidity_asset_mv != 0 {
            let new_liquidity_asset_mv = liquidity_asset_mv - asset_mv;

            if new_liquidity_asset_mv > 0 && new_liquidity_asset_mv < min_accepted_net_value {
                msg!(
                    "Obligation new borrowed value after repay {} for {}",
                    new_liquidity_asset_mv.to_display(),
                    reserve.token_symbol()
                );
                return err!(LendingError::NetValueRemainingTooSmall);
            }
        }
        // Skip bad debt case (deposited = 0)
        if total_deposited_mv > 0 {
            let new_ltv = new_total_bf_debt_mv / total_deposited_mv;

            // No action happened that would have worsened the LTV of the obligation
            if new_ltv > obligation.loan_to_value() {
                msg!(
                    "Obligation new LTV/new unhealthy LTV after repay {:.2}/{:.2} of {}",
                    new_ltv.to_display(),
                    obligation.unhealthy_loan_to_value().to_display(),
                    reserve.token_symbol()
                );
                return err!(LendingError::WorseLtvBlocked);
            }
        }

        Ok(())
    }

    pub fn get_elevation_group(
        elevation_group_id: u8,
        market: &LendingMarket,
    ) -> Result<Option<&ElevationGroup>> {
        // Check the elevation group id is valid
        if elevation_group_id > MAX_NUM_ELEVATION_GROUPS {
            return err!(LendingError::InvalidElevationGroup);
        }

        // Check the elevation group exists in the market
        let elevation_group = market.get_elevation_group(elevation_group_id)?;

        if let Some(elevation_group) = elevation_group {
            require_neq!(
                elevation_group.liquidation_threshold_pct,
                0,
                LendingError::InvalidElevationGroup
            );
            require_neq!(
                elevation_group.ltv_pct,
                0,
                LendingError::InvalidElevationGroup
            );
        }

        Ok(elevation_group)
    }

    pub fn get_max_ltv_and_liquidation_threshold(
        deposit_reserve: &Reserve,
        elevation_group: Option<&ElevationGroup>,
    ) -> (u8, u8) {
        if let Some(elevation_group) = elevation_group {
            (
                elevation_group.ltv_pct,
                elevation_group.liquidation_threshold_pct,
            )
        } else {
            // If the obligation elevation group is 0, we use the reserve config
            (
                deposit_reserve.config.loan_to_value_pct,
                deposit_reserve.config.liquidation_threshold_pct,
            )
        }
    }

    pub fn check_obligation_fully_refreshed_and_not_null(
        obligation: &Obligation,
        slot: Slot,
    ) -> Result<()> {
        if obligation
            .last_update
            .is_stale(slot, PriceStatusFlags::ALL_CHECKS)?
        {
            msg!(
            "Obligation is stale and must be refreshed in the current slot, price status: {:08b}",
            obligation.last_update.get_price_status().0
        );
            return err!(LendingError::ObligationStale);
        }
        if obligation.is_active_deposits_empty() {
            msg!("Obligation has no deposits to borrow against");
            return err!(LendingError::ObligationDepositsEmpty);
        }
        if obligation.deposited_value_sf == 0 {
            msg!("Obligation deposits have zero value");
            return err!(LendingError::ObligationDepositsZero);
        }

        Ok(())
    }

    pub fn assert_obligation_liquidatable(
        repay_reserve: &Reserve,
        withdraw_reserve: &Reserve,
        obligation: &Obligation,
        liquidity_amount: u64,
        slot: Slot,
    ) -> Result<()> {
        if liquidity_amount == 0 {
            msg!("Liquidity amount provided cannot be zero");
            return err!(LendingError::InvalidAmount);
        }

        if repay_reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::LIQUIDATION_CHECKS)?
        {
            msg!(
                "Repay reserve is stale and must be refreshed in the current slot, price status: {:08b}",
                repay_reserve.last_update.get_price_status().0
            );
            return err!(LendingError::ReserveStale);
        }

        if withdraw_reserve
            .last_update
            .is_stale(slot, PriceStatusFlags::LIQUIDATION_CHECKS)?
        {
            msg!(
                "Withdraw reserve is stale and must be refreshed in the current slot, price status: {:08b}",
                withdraw_reserve.last_update.get_price_status().0
            );
            return err!(LendingError::ReserveStale);
        }

        if obligation
            .last_update
            .is_stale(slot, PriceStatusFlags::LIQUIDATION_CHECKS)?
        {
            msg!(
            "Obligation is stale and must be refreshed in the current slot, price status: {:08b}",
            obligation.last_update.get_price_status().0
        );
            return err!(LendingError::ObligationStale);
        }

        if obligation.deposited_value_sf == 0 {
            msg!("Obligation deposited value is zero");
            return err!(LendingError::ObligationDepositsZero);
        }
        if obligation.borrow_factor_adjusted_debt_value_sf == 0 {
            msg!("Obligation borrowed value is zero");
            return err!(LendingError::ObligationBorrowsZero);
        }

        Ok(())
    }

    pub fn is_update_reserve_config_mode_global_admin_only(mode: UpdateConfigMode) -> bool {
        // Warning: All field assigned to the global admin here must also be skipped
        // when updating the entire reserve config in `update_reserve_config`

        // Use match to ensure complete coverage
        match mode {
            UpdateConfigMode::UpdateProtocolTakeRate
            | UpdateConfigMode::UpdateProtocolLiquidationFee
            | UpdateConfigMode::UpdateHostFixedInterestRateBps
            | UpdateConfigMode::UpdateProtocolOrderExecutionFee
            | UpdateConfigMode::UpdateFeesOriginationFee
            | UpdateConfigMode::UpdateFeesFlashLoanFee
            | UpdateConfigMode::UpdateBlockCTokenUsage => true,
            UpdateConfigMode::UpdateLoanToValuePct
            | UpdateConfigMode::UpdateMaxLiquidationBonusBps
            | UpdateConfigMode::UpdateLiquidationThresholdPct
            | UpdateConfigMode::DeprecatedUpdateFeesReferralFeeBps
            | UpdateConfigMode::UpdateDepositLimit
            | UpdateConfigMode::UpdateBorrowLimit
            | UpdateConfigMode::UpdateTokenInfoLowerHeuristic
            | UpdateConfigMode::UpdateTokenInfoUpperHeuristic
            | UpdateConfigMode::UpdateTokenInfoExpHeuristic
            | UpdateConfigMode::UpdateTokenInfoTwapDivergence
            | UpdateConfigMode::UpdateTokenInfoScopeTwap
            | UpdateConfigMode::UpdateTokenInfoScopeChain
            | UpdateConfigMode::UpdateTokenInfoName
            | UpdateConfigMode::UpdateTokenInfoPriceMaxAge
            | UpdateConfigMode::UpdateTokenInfoTwapMaxAge
            | UpdateConfigMode::UpdateScopePriceFeed
            | UpdateConfigMode::UpdatePythPrice
            | UpdateConfigMode::UpdateSwitchboardFeed
            | UpdateConfigMode::UpdateSwitchboardTwapFeed
            | UpdateConfigMode::UpdateBorrowRateCurve
            | UpdateConfigMode::DeprecatedUpdateEntireReserveConfig
            | UpdateConfigMode::UpdateDebtWithdrawalCap
            | UpdateConfigMode::UpdateDepositWithdrawalCap
            | UpdateConfigMode::DeprecatedUpdateDebtWithdrawalCapCurrentTotal
            | UpdateConfigMode::DeprecatedUpdateDepositWithdrawalCapCurrentTotal
            | UpdateConfigMode::UpdateBadDebtLiquidationBonusBps
            | UpdateConfigMode::UpdateMinLiquidationBonusBps
            | UpdateConfigMode::UpdateDeleveragingMarginCallPeriod
            | UpdateConfigMode::UpdateBorrowFactor
            | UpdateConfigMode::DeprecatedUpdateAssetTier
            | UpdateConfigMode::UpdateElevationGroup
            | UpdateConfigMode::UpdateDeleveragingThresholdDecreaseBpsPerDay
            | UpdateConfigMode::DeprecatedUpdateMultiplierSideBoost
            | UpdateConfigMode::DeprecatedUpdateMultiplierTagBoost
            | UpdateConfigMode::UpdateReserveStatus
            | UpdateConfigMode::UpdateFarmCollateral
            | UpdateConfigMode::UpdateFarmDebt
            | UpdateConfigMode::UpdateDisableUsageAsCollateralOutsideEmode
            | UpdateConfigMode::UpdateBlockBorrowingAboveUtilizationPct
            | UpdateConfigMode::UpdateBlockPriceUsage
            | UpdateConfigMode::UpdateBorrowLimitOutsideElevationGroup
            | UpdateConfigMode::UpdateBorrowLimitsInElevationGroupAgainstThisReserve
            | UpdateConfigMode::UpdateAutodeleverageEnabled
            | UpdateConfigMode::UpdateDeleveragingBonusIncreaseBpsPerDay
            | UpdateConfigMode::UpdateMinDeleveragingBonusBps
            | UpdateConfigMode::UpdateDebtMaturityTimestamp
            | UpdateConfigMode::UpdateDebtTermSeconds
            | UpdateConfigMode::UpdateReserveEmergencyMode
            | UpdateConfigMode::UpdateProposerAuthorityLock
            | UpdateConfigMode::UpdateEarlyRepayRemainingInterestPct
            | UpdateConfigMode::UpdateRewardsAmountPerSlot => false,
        }
    }

    pub fn is_update_reserve_config_mode_allowed_for_emergency_council(
        mode: UpdateConfigMode,
        value: &[u8],
    ) -> bool {
        match mode {
            UpdateConfigMode::UpdateBorrowLimit if borsh_deserialize::<u64>(value) == 0 => {
                // Emergency council can block borrowing by setting borrow limit to 0
                true
            }
            UpdateConfigMode::UpdateBlockPriceUsage if borsh_deserialize::<u8>(value) == 1 => {
                // Emergency council can only enable blocking price usage (set to true)
                true
            }
            UpdateConfigMode::UpdateReserveEmergencyMode if borsh_deserialize::<u8>(value) == 1 => {
                // Emergency council can only enable reserve emergency mode
                true
            }
            // Safe to default to false for all other modes even new ones added in the future
            _ => false,
        }
    }

    pub fn is_allowed_signer_to_init_reserve(
        signer: Pubkey,
        lending_market: &LendingMarket,
    ) -> bool {
        // Check if the signer is the lending market owner or proposer authority
        signer == lending_market.lending_market_owner || signer == lending_market.proposer_authority
    }

    pub fn is_allowed_signer_to_update_reserve_config(
        signer: Pubkey,
        mode: UpdateConfigMode,
        value: &[u8],
        lending_market: &LendingMarket,
        reserve: &Reserve,
        global_admin: Pubkey,
    ) -> bool {
        // If initialization phase, the proposer authority can update the reserve config
        let reserve_is_used = reserve.is_used(lending_market.min_initial_deposit_amount);
        let reserve_is_usage_blocked = reserve.is_usage_blocked();

        let initialization_phase = !reserve_is_used
            && reserve_is_usage_blocked
            && reserve.config.proposer_authority_locked == false as u8;

        xmsg!(
            "Reserve is used: {}, is usage blocked: {}, proposer authority locked: {}",
            reserve_is_used,
            reserve_is_usage_blocked,
            reserve.config.proposer_authority_locked != false as u8
        );

        if initialization_phase && signer == lending_market.proposer_authority {
            return true;
        }

        // Not initialization phase or proposer authority is not the signer, check normal permissions
        if is_update_reserve_config_mode_global_admin_only(mode) {
            global_admin == signer
        } else if is_update_reserve_config_mode_allowed_for_emergency_council(mode, value)
            && lending_market.emergency_council == signer
        {
            true
        } else {
            lending_market.lending_market_owner == signer
        }
    }

    /// Whether the given signer can clone a reserve config to the given target reserve.
    ///
    /// Since a separate check ensures that cloning targets a not-yet-used reserve, and that all the
    /// cloned values come from an already-active reserve, the rule here is simple: the ix must be
    /// signed either by the market owner, or by the market proposer authority (if he was not yet
    /// locked out by the reserve).
    pub fn is_allowed_signer_to_clone_reserve_config(
        signer: Pubkey,
        lending_market: &LendingMarket,
        reserve: &Reserve,
    ) -> bool {
        signer == lending_market.lending_market_owner
            || (reserve.config.proposer_authority_locked == false as u8
                && signer == lending_market.proposer_authority)
    }

    pub fn allowed_signer_update_reserve_config(
        mode: UpdateConfigMode,
        lending_market_owner: Pubkey,
        global_admin: Pubkey,
    ) -> Pubkey {
        if is_update_reserve_config_mode_global_admin_only(mode) {
            global_admin
        } else {
            lending_market_owner
        }
    }

    pub fn is_allowed_signer_to_use_destination_token_account(
        signer: Pubkey,
        destination_ta: Pubkey,
        ticket_owner: Pubkey,
        token_mint: Pubkey,
        token_program: Pubkey,
    ) -> bool {
        if signer == ticket_owner {
            return true; // if the ticket owner signed, then he can use an arbitrary TA (and other checks ensure that it's his, valid TA)
        }
        // All other signers have to use the ticket owner's ATA:
        has_ata_address(&destination_ta, &ticket_owner, &token_mint, &token_program)
    }

    pub fn validate_reserve_config_integrity(
        config: &ReserveConfig,
        market: &LendingMarket,
        reserve_address: Pubkey,
    ) -> Result<()> {
        // TODO(after decommissioning the `UpdateEntireReserveConfig` mode): move all the "basic"
        // checks from here to the `update_reserve_config()`. This method should only care about
        // complex validations (e.g. cross-field interactions).
        if ReserveStatus::try_from_primitive(config.status).is_err() {
            msg!("Invalid reserve status");
            return err!(LendingError::InvalidConfig);
        }
        if config.loan_to_value_pct >= 100 {
            msg!("Loan to value ratio must be in range [0, 100)");
            return err!(LendingError::InvalidConfig);
        }
        if config.max_liquidation_bonus_bps > FULL_BPS {
            msg!("Liquidation bonus must be in range [0, 100]");
            return err!(LendingError::InvalidConfig);
        }
        if config.liquidation_threshold_pct < config.loan_to_value_pct
            || config.liquidation_threshold_pct > 100
        {
            msg!("Liquidation threshold must be in range [LTV, 100]");
            return err!(LendingError::InvalidConfig);
        }
        if u128::from(config.fees.origination_fee_sf) >= FRACTION_ONE_SCALED {
            msg!("Origination fee must be in range [0, 100%)");
            return err!(LendingError::InvalidConfig);
        }
        if config.protocol_liquidation_fee_pct > 100 {
            msg!("Protocol liquidation fee must be in range [0, 100]");
            return err!(LendingError::InvalidConfig);
        }
        if config.protocol_order_execution_fee_pct > 100 {
            msg!("Protocol order execution fee must be in range [0, 100]");
            return err!(LendingError::InvalidConfig);
        }
        if config.protocol_take_rate_pct > 100 {
            msg!("Protocol take rate must be in range [0, 100]");
            return err!(LendingError::InvalidConfig);
        }
        if !config.token_info.is_valid() {
            msg!("Invalid reserve token info");
            return err!(LendingError::InvalidOracleConfig);
        }
        if !config.token_info.is_twap_config_valid() {
            msg!("Invalid reserve token twap config");
            return err!(LendingError::InvalidTwapConfig);
        }

        if config.bad_debt_liquidation_bonus_bps >= 100 {
            msg!("Invalid bad debt liquidation bonus, cannot be more than 1%");
            return err!(LendingError::InvalidConfig);
        }
        if config.min_liquidation_bonus_bps > config.max_liquidation_bonus_bps {
            msg!("Invalid min liquidation bonus");
            return err!(LendingError::InvalidConfig);
        }
        if config.min_deleveraging_bonus_bps > config.max_liquidation_bonus_bps {
            msg!("Invalid min deleveraging bonus");
            return err!(LendingError::InvalidConfig);
        }
        if config.borrow_factor_pct < 100 {
            msg!("Invalid borrow factor, it must be greater or equal to 100");
            return err!(LendingError::InvalidConfig);
        }
        if config.is_autodeleverage_enabled() {
            if config.deleveraging_margin_call_period_secs == 0 {
                msg!("Invalid deleveraging_margin_call_period_secs, must be greater than 0 when autodeleverage_enabled");
                return err!(LendingError::InvalidConfig);
            }
            if config.deleveraging_threshold_decrease_bps_per_day == 0 {
                msg!("Invalid deleveraging_threshold_decrease_bps_per_day, must be greater than 0 when autodeleverage_enabled");
                return err!(LendingError::InvalidConfig);
            }
            if config.deleveraging_bonus_increase_bps_per_day == 0 {
                msg!("Invalid deleveraging_bonus_increase_bps_per_day, must be greater than 0 when autodeleverage_enabled");
                return err!(LendingError::InvalidConfig);
            }
        }
        if config.early_repay_remaining_interest_pct > 100 {
            msg!("Early repay penalty remaining interest pct must be in range [0, 100]");
            return err!(LendingError::InvalidConfig);
        }
        if config.borrow_limit_outside_elevation_group != u64::MAX
            && config.borrow_limit < config.borrow_limit_outside_elevation_group
        {
            msg!("Invalid 'borrow limit', must be at least equal to 'borrow limit outside elevation group' when enabled");
            return err!(LendingError::InvalidConfig);
        }

        for elevation_group_id in config.elevation_groups {
            // Check the elevation group id is valid

            if let Some(elevation_group) = get_elevation_group(elevation_group_id, market)? {
                if elevation_group.debt_reserve == Pubkey::default() {
                    msg!("Invalid elevation group debt reserve");
                    return err!(LendingError::InvalidConfig);
                }

                if elevation_group.debt_reserve != reserve_address {
                    if elevation_group.max_liquidation_bonus_bps > config.max_liquidation_bonus_bps
                    {
                        msg!("Invalid max liquidation bonus in elevation group {elevation_group_id}, elevation group's liquidation bonus must be less than the config's",);
                        return err!(LendingError::InvalidConfig);
                    }

                    if elevation_group.liquidation_threshold_pct < config.liquidation_threshold_pct
                    {
                        msg!("Invalid liquidation threshold in elevation group {elevation_group_id}, elevation id liquidation threshold must be greater than the config's",);
                        return err!(LendingError::InvalidConfig);
                    }

                    if elevation_group.ltv_pct < config.loan_to_value_pct {
                        msg!("Invalid ltv ratio in elevation group {elevation_group_id}, cannot be bigger than the reserve's ltv ratio",);
                        return err!(LendingError::InvalidConfig);
                    }

                    if elevation_group.ltv_pct > elevation_group.liquidation_threshold_pct {
                        msg!("Invalid ltv ratio in elevation group {elevation_group_id}, cannot be bigger than the liquidation threshold",);
                        return err!(LendingError::InvalidConfig);
                    }

                    if elevation_group.liquidation_threshold_pct > 100 {
                        msg!("Invalid liquidation threshold in elevation group {elevation_group_id}, must be less than 100%",);
                        return err!(LendingError::InvalidConfig);
                    }
                }

                if elevation_group.max_reserves_as_collateral == 0 {
                    msg!("Invalid elevation group max collateral reserves");
                    return err!(LendingError::InvalidConfig);
                }
            }
            // Else the reserve is removed from an elevation group id
        }

        if config.utilization_limit_block_borrowing_above_pct > 100 {
            msg!("Utilization limit to block borrows above cannot be bigger than 100%");
            return err!(LendingError::InvalidConfig);
        }

        // Warn (don't block) when this reserve has a non-zero `rewards_amount_per_slot` while
        // the market-level reserve rewards are disabled — the RPS is effectively dormant
        // until an admin sets `LendingMarket::reserve_rewards_max_apr_bps > 0`.
        if config.rewards_amount_per_slot > 0 && !market.is_reserve_rewards_enabled() {
            msg!(
                "WARNING: rewards_amount_per_slot={} is set but the market has reserve rewards \
                 disabled (reserve_rewards_max_apr_bps == 0); RPS will be ignored on refresh \
                 until rewards are enabled at the market level",
                config.rewards_amount_per_slot,
            );
        }

        config.borrow_rate_curve.validate()?;
        Ok(())
    }

    /// Checks that the given timestamp is either not set (i.e. `0`), or set in the future.
    pub fn check_not_set_in_the_past(subject_timestamp: u64, clock: &Clock) -> Result<()> {
        let timestamp = u64::try_from(clock.unix_timestamp).unwrap();
        if subject_timestamp != 0 && subject_timestamp < timestamp {
            msg!(
                "Timestamp must not be set in the past; got {} < current timestamp {}",
                subject_timestamp,
                timestamp
            );
            return err!(LendingError::InvalidConfig);
        }
        Ok(())
    }

    /// Ensures that the given [FixedTermBorrowRolloverConfig] is internally consistent and
    /// permitted by the market-level [Obligation::fixed_term_borrow_rollover_config] flag.
    ///
    /// Note: a user is always allowed to opt-out from the auto-rollover, which means that this
    /// check should *not* be applied after the user disabling any of the rollover flavors.
    pub fn check_enabled_rollover_config_integrity(
        market: &LendingMarket,
        config: &FixedTermBorrowRolloverConfig,
    ) -> Result<()> {
        let any_enabled =
            config.is_auto_rollover_enabled() || config.is_migration_to_fixed_enabled();
        if any_enabled && !market.is_obligation_borrow_rollover_configuration_enabled() {
            return err!(LendingError::BorrowRolloverConfigurationDisabled);
        }

        // max_borrow_rate_bps must always be explicitly configured when any rollover flavor is on:
        if any_enabled && config.max_borrow_rate_bps == 0 {
            msg!("max_borrow_rate_bps must be set when rollover/migration is enabled");
            return err!(LendingError::InvalidConfig);
        }

        // min_debt_term_seconds = 0 means "open-term only" — which is consistent with auto-rollover
        // (roll into open-term reserves), but contradicts migration-to-fixed (which requires a
        // fixed-term target). Therefore, we only require min_debt_term_seconds > 0 for migration:
        if config.is_migration_to_fixed_enabled() && config.min_debt_term_seconds == 0 {
            msg!("min_debt_term_seconds must be set when migration to fixed-term is enabled (0 means open-term only)");
            return err!(LendingError::InvalidConfig);
        }
        Ok(())
    }
}

# Protocol Disclosures and Qualification Guardrails

The unchanged source is [`protocol_docs.md`](../context/protocol_docs.md). Section 6 states that §6.1 lists intended behavior that can look like a bug and §6.2 lists known issues in the reviewed code; it says items in either section are not valid findings. The statements below preserve each declared item and the conditions needed to locate its full source discussion.

## Scope and Trust Guardrails

- **Exact file scope controls.** The document describes `programs/metavault/` broadly, while the engagement manifest pins 80 files. Use [`scope.json`](../context/scope.json) for direct file inclusion. `libs/client/` and off-chain keeper, cranker, and solver code are excluded by protocol documentation lines 3–8.
- **Supported vault tokens.** Mints with 6–18 decimals are in the stated policy. Non-zero Token-2022 transfer fees are rejected. Rebasing tokens, fee-on-transfer tokens, and blocklist/pausable behavior beyond USDC/USDT are unsupported; findings premised on them are out of scope. See protocol documentation lines 609–619.
- **Vault admin.** Production vaults are Kamino-operated and the vault admin is fully trusted. Findings requiring a malicious or careless vault admin are out of scope. See lines 643–650 and 1014–1030.
- **Bounded non-admin actors.** The allocation delegate, krfq server, swap authority, order owners, and fillers remain constrained as stated at lines 652–694. A delegate bypass of an on-chain bound or movement of value to an address of its choosing is expressly in scope at full severity.
- **Off-chain assumptions.** Off-chain components are outside direct audit scope and have the liveness/reliability assumptions at lines 760–784. The protocol must remain safe with zero fillers; an unfilled auction expires.

## §6.1 Intended Behavior

### Vault Core and Share Accounting

- **Flow fees are donated to the vault, not collected.** They stay in `token_available`, increase remaining holders' share price, and have no fee recipient or separate accounting line.
- **Depositors are priced against post-fee AUM.** Shares use `net_aum + value(deposit_fee)` so the entrant does not recapture a pro-rata share of the fee.
- **Withdrawers burn shares against the gross amount.** Burn calculation uses the pre-fee redemption value with ceiling rounding and is capped at requested shares.
- **The two zero conventions are inverted.** `max_deviation_bps == 0` disables the target bound; `max_price_divergence_bps == 0` requires an exact price match.
- **Deposits and withdrawals halt at non-positive net AUM.** User flow and views fail, while order exits and obligation operations remain available as described.
- **Direct transfers to the vault are not counted.** Token-account balance above `token_available + locked_total` is untracked surplus and excluded from AUM.
- **The seed deposit is valued at a mocked $1 per whole token.** The 1000 dead seed shares and mocked checkpoint can delay performance fees for a first token priced below $1; only the fee recipient bears this.

Source: protocol documentation lines 808–846.

### Fee Accrual

- **Performance is charged on appreciation from any source.** Market yield, donated flow fees, and rounding count; waived fee shares do not.
- **Performance-fee boundaries have timing effects, in both directions.** Exit-before-boundary avoidance and mid-window depositor charging are declared consequences of discrete per-share charging without per-account cost basis.
- **The checkpoint is a high-water mark and never ratchets down on a drawdown.** Recovery after a loss is free until the checkpoint is exceeded; a Scope feed change may re-anchor the valuation basis.
- **Changing the performance fee rate forgives in-window gain.** Fees are charged at the old rate, then the checkpoint is raised without charging gain at the new rate.
- **Waiving fees requires blocked deposits, and a sandwich residual remains.** `give_up_pending_fees` blocks new deposits but cannot prevent a prior deposit followed by a later withdrawal from capturing part of the waiver.
- **A long gap between fee charges is capped.** Each fee is clamped at 50% post-mint ownership per call; excess management fee after a sufficiently long gap is forgiven.
- **Fee accrual is only as current as the last touch.** Nothing accrues autonomously; `refresh_vault` is permissionless.

Source: protocol documentation lines 848–888.

### AUM Valuation and Oracles

- **Vault liveness is coupled to its weakest input.** A stale/failing Scope feed, stale obligation/reserve state, or price-basis divergence can halt every AUM-touching instruction.
- **klend's cached reserve price is never an AUM input.** MetaVault values quantities using its own Scope price; klend-basis values still drive the LTV ceiling and all-available sizing.

Source: protocol documentation lines 890–902.

### Rebalancing and Dutch Auctions

- **A fill's `amount_in` is clamped down to the remaining deficit.** Oversized input is reduced rather than rejected; the exact requested output must remain under the curve output for the reduced input.
- **`requested_out_amount` is an exact payout, not a minimum.** The program does not scale the ask upward or downward.
- **Restarting a rebalance resets its loss accumulator.** The loss ceiling is per auction; cooldown binds the allocation delegate but not the exact vault admin key.
- **Anyone can end a rebalance early by making it unfillable.** User flow can close an unfillable auction and leave a delegate waiting for the start-anchored cooldown.
- **Obligation operations wait for a rebalance.** Token-moving operations close an ended rebalance and reject while it remains fillable; `init_obligation` is blocked for the whole window, while `request_elevation_group` is not gated.

Source: protocol documentation lines 904–932.

### Deposit and Withdraw Orders

- **A withdraw order releases a slice of every free token, wanted or not.** An unfilled order settles as the raw pro-rata mix.
- **A deposit order settles for whatever the target bounds admit, and refunds the rest.** Sub-one-share absorption mints and absorbs nothing; certain caps revert the whole settlement.
- **Order settles are permissionless, and deposit settles re-price at settle time.** Deposit `max_share_price` and withdrawal `min_tokens_out` apply at their stated stages.
- **Deposit orders follow the vault's live weights and dutch scales.** Running deposit orders can be steered by weight changes; withdraw-order owners choose their weights.
- **`block_deposits` and `block_withdraws` gate only the half of an order that mints or burns.** Cancellation and withdrawal settlement remain available outside emergency mode, subject to the listed settle constraints.

Source: protocol documentation lines 934–963.

### klend Obligation Allocation

- **MetaVault models klend's maths and reverts on a token-movement mismatch.** A configuration that changes transferred amounts may trigger the guard rather than silent corruption.
- **Repay and deposit-collateral are never blocked by the LTV ceiling.** Borrow, collateral withdrawal, and elevation-group requests are gated; rescue operations retain the other listed preconditions.
- **Borrow-all and full repay lose sub-lamport amounts.** klend booking can reduce AUM slightly more than transferred on borrow and send the full-repay remainder to the reserve.

Source: protocol documentation lines 965–981.

### Permissioned Shares, Admin, and Emergency Controls

- **Emergency mode does not stop allocation or administration.** It blocks user flow, fills, and all order instructions while leaving obligation, rebalance-control, fee-withdrawal, and configuration paths available, except where a swap is needed.
- **The emergency council can block exits, and cannot clear its own flags.** A council compromise is declared a griefing risk, not theft; permissionless thaw can let an approved holder undo an account freeze.
- **Removing permissioning leaves frozen accounts frozen.** `delete_shares_config` is one-way and does not thaw existing accounts.
- **`vault_farm` is configurable but inert.** Current kfarms token constraints prevent staking these shares; the field remains for layout stability.
- **The CPI guard covers user flow, not administration.** Admin and obligation instructions remain CPI-callable for multisigs; retained instruction-sysvar accounts are for compatibility or forwarded to klend.

Source: protocol documentation lines 983–1012.

### Trusted-Admin Consequences

The document excludes findings based only on the vault admin choosing an arbitrary oracle mapping or lending market, self-filling through a controlled `swap_authority`, setting fees to caps, or disabling configurable bounds. No on-chain allow-list or timelock constrains these choices; the stated mitigation is Kamino-operated multisig administration.

Source: protocol documentation lines 1014–1030.

## §6.2 Known Issues

- **Flow is not blocked while an obligation can be liquidated.** Certain user flows do not check obligation health, so a pending liquidation or socialized loss can be shifted to remaining holders; the planned LTV-liquidatability check does not cover every non-LTV trigger.
- **Repaying fixed-term debt before its term ends reverts.** The pinned klend early-repay penalty is not modeled, causing `BalanceAfterObligationCpiMismatch` until the term ends.

Source: protocol documentation lines 1032–1047.

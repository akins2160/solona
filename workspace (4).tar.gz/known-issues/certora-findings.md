# Certora Prior Findings

The source report contains **30 findings: 5 Medium, 12 Low, and 13 Informational**. Protocol documentation §5 declares every item known for this engagement. Titles and prior severities below are from the unchanged [report conversion](<../context/Certora - Kamino - Metavault - Draft Report.md>); remediation labels are from [`CERTORA-TRIAGE-2026-09-21.md`](../context/CERTORA-TRIAGE-2026-09-21.md).

| ID | Prior severity | Triage status | Disclosed issue title |
| --- | --- | --- | --- |
| M-01 | Medium | Fixed here | Performance fee has no high-water mark, so the same interest is charged again after a drawdown |
| M-02 | Medium | Acknowledged | Klend oracle reconfiguration can prevent MetaVault from unwinding obligation positions |
| M-03 | Medium | Partially fixed here | Mutable ownership of thawed share accounts bypasses permissioned-vault gating |
| M-04 | Medium | Fixed here | Rebalance swaps have no aggregate loss cap across a rebalance episode - only a per-swap slippage cap |
| M-05 | Medium | Fixed here | Shares are priced against pre-fee AUM, so large deposits recapture most of their deposit fee |
| L-01 | Low | Fixed here | CPI guard prevents administration through on-chain multisigs |
| L-02 | Low | Fixed here | Cumulative earned interest excludes AUM gained during value-moving operations |
| L-03 | Low | Fixed here | Updating a rolling-cap interval can revive an already expired window |
| L-04 | Low | Fixed here | Buy and withdraw can revive a completed rebalance at a mature auction price |
| L-05 | Low | Fixed here | Pre-funding the deterministic shares-mint PDA can block a specific `init_vault` tx |
| L-06 | Low | Acknowledged | All-available obligation operations ignore the MetaVault LTV ceiling |
| L-07 | Low | Fixed here | `rebase_perf_fee_checkpoint` reads `prev_aum` as if it were current, so a config update while net AUM is negative lowers the performance-fee checkpoint and makes the whole recovery chargeable |
| L-08 | Low | Acknowledged | No path to harvest farm rewards accrued by vault obligations |
| L-09 | Low | Acknowledged | External share burns are never reconciled, permanently stranding a proportion of the vault |
| L-10 | Low | Acknowledged | Shares ACL deletion has no corresponding re-enable path, permanently disabling permissioning |
| L-11 | Low | Acknowledged | Mid-window depositors are charged performance fees on appreciation their capital never earned |
| L-12 | Low | Fixed here | Mid-window management-fee minting silently shrinks the performance fee collected at the next |
| I-01 | Informational | Acknowledged | Token account fields named `ata` are not constrained to be associated token accounts |
| I-02 | Informational | Fixed before review ended by `99f0648` | Rebalance target recalculation in obligation operations is unreachable |
| I-03 | Informational | Fixed before review ended by `99f0648` | Obligation AUM assumes every lending market uses the same quote currency |
| I-04 | Informational | Fixed here | Dead `xmsg!`/`dbg_msg!` logging macros are unused and unreachable |
| I-05 | Informational | Fixed here | Asymmetric zero-amount CPI guard between the two token-transfer helpers |
| I-06 | Informational | Acknowledged | Withdraw lacks the same frozen-shares-account UX check as deposit |
| I-07 | Informational | Acknowledged | Repay reverts on reserves that charge an early repay penalty |
| I-08 | Informational | Acknowledged | Permissionless thaw, enabled by default at vault creation, lets a frozen holder immediately undo the emergency council's freeze |
| I-09 | Informational | Acknowledged | Missing signer requirement on `vault_state` allows front-running of `init_vault` |
| I-10 | Informational | Fixed here | `init_obligation` lacks a rebalance-state guard, breaking in-flight solver transactions |
| I-11 | Informational | Acknowledged | Withdraw-and-reenter timing around the fee cooldown lets holders dodge the performance fee entirely |
| I-12 | Informational | Fixed before review ended by `99f0648` | Vault-side and reserve-side oracle configs can diverge, letting AUM blend two inconsistent price bases |
| I-13 | Informational | Fixed here | A normative `CONTEXT.md` spec is cited throughout the code but absent from the repository |

## Status Sources

- **Fixed here:** triage lines 1–17.
- **Fixed before review ended by `99f0648`:** triage lines 19–23.
- **Acknowledged:** triage lines 25–38.

The original PDF and supplied Markdown both end the L-12 title with “at the next.” The detailed description explains that the affected event is the next performance charge; the index does not silently repair the source title.

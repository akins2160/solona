# Prior Disclosures

Use these indexes for known-status matching, then read the linked source section before deciding whether a candidate finding matches the disclosed root cause, conditions, and impact.

## Sources

- [`certora-findings.md`](certora-findings.md): all 30 findings from the September 2026 Certora draft report, reconciled with the customer triage note.
- [`protocol-disclosures.md`](protocol-disclosures.md): all explicit intended behaviors and known issues in protocol documentation §6, plus the document's scope and trust guardrails.

The protocol documentation states that every Certora issue is treated as known and that no finding was disputed. Its fixed, partially fixed, fixed-before-review, and acknowledged labels describe remediation status; they do not remove the prior disclosure.

The Certora report was produced against commit `95760c4dc16f52031d9d6971be42a1d4f2e3505b`. The current engagement is pinned to `2fbe82b37c06282d86992a4ce17bc4ffa701f845`. Compare the disclosed root cause and behavior with the current code rather than assuming the old implementation is unchanged.

For the governing treatment of previous-audit issues, see [`../context/judging-guidelines.md`](../context/judging-guidelines.md#x-list-of-issue-categories-that-are-not-considered-valid). For duplicate grouping between submitted reports, separately apply [`../context/deduplication-guidelines.md`](../context/deduplication-guidelines.md).
